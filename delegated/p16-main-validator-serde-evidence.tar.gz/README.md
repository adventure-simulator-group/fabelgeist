# Bounded P16 catalogue validator and pinned Serde evidence

This packet covers original registry roles 2587 and 2588. Role 2587 belongs to
historical `physical-p16`, a dirty snapshot with recorded base `a120`; the
assigned source alone equals that base file. Role 2588 is package source from
`serde_core 1.0.229`, not a project Git revision. The crate archive and both
the P16 dirty and current 95e Cargo lock records bind the pinned package.

Start with `REPORT.json` and `personal-read-receipt.json`. The current
validator production body was read; only the recorded P16 windows were read
personally. Original 059/774 reviewers' scopes and unread test tails remain
separate. The mechanically identical production bodies and changed unread
test tails do not grant extra personal read or runtime coverage. Historical
registry and queue selections are clearly labeled reconstructions; original 059
and 774 records are preserved unchanged. Git commit/tree proofs and exact
source/lock/package bytes are retained locally.

The later recovered P16 tracked patch is hash-linked to the publication and
matches the original registry. Seven untracked files are separate; no claim is
made of uninterrupted custody or checkpoint 3821 restoration. Prior packet
and published evidence dependencies are hash-linked, rather than copied as
large archives.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` for evidence
checks; the former needs the linked existing audit publication and prior
packets. These checks do not run product code. No repairs, builds, tests,
runtime probes, simulations, rendering or product validation were performed.
Thirteen perspectives cover only this bounded scope.
