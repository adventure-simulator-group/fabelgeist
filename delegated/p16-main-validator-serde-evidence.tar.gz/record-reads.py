from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256((b/p).read_bytes()).hexdigest();r=json.loads((b/'registration.json').read_bytes());s=json.loads((b/'support-registration.json').read_bytes());out=[]
def comp(n,ranges):
 used={i for a,z in ranges for i in range(a,z+1)};x=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if (i>n or i in used) and a is not None:x.append([a,i-1]);a=None
 return x
for e in r['roles']:
 if e['role']==2588:chunks=e['planned_chunks']
 elif e['revision'].startswith('95e'):chunks=e['planned_chunks']
 else:chunks=[[1,120],[601,720],[721,840],[841,960]]
 out.append({'role':e['role'],'identity':e['identity'],'revision':e['revision'],'path':e['path'],'archive':e['archive'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_chunks':chunks,'actual_display_ranges':[[1,1492]] if e['role']==2587 and e['revision'].startswith('95e') else ([[1,120],[601,960]] if e['role']==2587 else chunks),'unread_complement':comp(e['eof'],chunks),'historical_original_effective_ranges':e['original_material_ranges'],'qualification':'Personal bounded untruncated source displays. Remaining archived bytes not independently read; earlier historical reviewers retain their separate receipts. No test bodies executed.'})
x={'reader':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registrations':[{'path':'registration.json','sha256':h('registration.json')},{'path':'support-registration.json','sha256':h('support-registration.json')}],'assigned_personal_reads':out,'support_personal_reads':[{'revision':s['revision'],'path':s['path'],'archive':s['archive'],'sha256':s['sha256'],'eof':s['eof'],'actual_display_chunks':s['registered_ranges'],'actual_display_ranges':s['registered_ranges'],'unread_complement':comp(s['eof'],s['registered_ranges']),'qualification':'Bounded separately registered support for 95e capability default; no transfer of prior review credit.'}],'qualification':'Registration before displays, receipts after; source comparison does not claim historical unread ranges personally read. Lock files structurally parsed for metadata only.'};(b/'personal-read-receipt.json').write_text(json.dumps(x,indent=2)+'\n');print('receipt',h('personal-read-receipt.json'))
