from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',repo,*args])
objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();raw=gzip.decompress(raw) if body.endswith('.gz') else raw;cur=root(rev);chain=[]
 for segment in path.split('/'):
  mode,child=entries(save('tree',cur))[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
rows=json.load(open(b/'registration.json'))['roles']
for e in rows:
 if e['role']==2587:
  proof(e['revision'],e['path'],e['archive'],'assigned P16 base file equivalence or pinned current source')
  if e['transport_path']:proof('f82adcabd9d89c4fa2dd7f99253a45297a0681ee',e['transport_path'],e['archive'],'historical P16 source object, f82 is transport')
 else:proof('f82adcabd9d89c4fa2dd7f99253a45297a0681ee',e['transport_path'],e['archive'],'historical pinned package object, f82 transport not package/project revision')
e=json.load(open(b/'support-registration.json'));proof(e['revision'],e['path'],e['archive'],'bounded current supporting schema')
for e in json.load(open(b/'registration.json'))['locks']:
 rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' if e['identity']=='physical-p16 dirty snapshot' else e['identity'];proof(rev,e['transport_or_git_path'],e['archive_gzip'],'structured metadata lock; no line-by-line read claim')
for e in json.load(open(b/'historical-attribution.json'))['774']:proof(e['transport_revision'],e['transport_path'],e['preserved_bytes'],'original 774 historical record, f82 transport')
r={'schema':'726-p16-main-serde-git-proof-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Raw commit/tree chains prove individual paths only; f82 is archive transport, not source revision. Original P16 was dirty; a120 equals role2587 file only.'};(b/'git-proofs.json').write_text(json.dumps(r,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects))
