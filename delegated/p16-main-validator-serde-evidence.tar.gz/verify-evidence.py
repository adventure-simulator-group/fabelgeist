from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,io,tarfile,tomllib,sys
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda p:json.loads((b/p).read_bytes())
reg=load('registration.json');sr=load('support-registration.json');rr=load('personal-read-receipt.json');hist=load('historical-attribution.json');links=load('evidence-links.json');gp=load('git-proofs.json');report=load('REPORT.json');r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));s=next(x for x in r['snapshots'] if x['id']=='physical-p16');assert len(s['status_porcelain'])==159 and s['base']=='a120390947c89b703dc74c4255a13c035d054c50';assert sha((pub/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes())==s['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for role in (2587,2588):
 row=r['files'][role];e=next(x for x in reg['roles'] if x['role']==role and x['transport_path']);raw=(b/e['archive']).read_bytes();assert len(raw)==row['bytes']==e['bytes'] and sha(raw)==row['sha256']==e['sha256'] and len(raw.splitlines())==row['actual_line_count'];assert any(x['revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' and x['path']==e['transport_path'] and x['sha256']==e['sha256'] for x in gp['paths'])
assert not any(x[3:]=='crates/adventuresim-core/src/item_catalog_validation.rs' for x in s['status_porcelain']);old=(b/'sources/2587-original.rs').read_bytes();now=(b/'sources/2587-current.rs').read_bytes();assert old.splitlines(keepends=True)[:1492]==now.splitlines(keepends=True)[:1492] and old!=now
crate=(b/reg['package_archive']['archive']).read_bytes();assert sha(crate)==reg['package_archive']['sha256']=='67dca2c9c51e58a4791a4b1ed58308b39c64224d349a935ab5039aa360942a48'
with tarfile.open(fileobj=io.BytesIO(crate),mode='r:gz') as tar:member=tar.extractfile(reg['package_archive']['package_member']).read()
assert member==(b/'sources/2588-original.rs').read_bytes()
for x in reg['locks']:
 raw=gzip.decompress((b/x['archive_gzip']).read_bytes());assert sha(raw)==x['sha256'] and len(raw)==x['bytes'];record=next(e for e in tomllib.loads(raw.decode())['package'] if e['name']=='serde_core' and e['version']=='1.0.229');assert record==x['serde_core_record'] and record['checksum']==sha(crate)
 if x['identity']=='physical-p16 dirty snapshot':assert sha(raw)==r['files'][39]['sha256']
for e in links['published']:
 raw=(pub/e['path']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
for p in links['prior_packets']:
 for e in p['records']:
  raw=Path(e['path']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
m=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));mi={e['path']:e for e in m['entries']};assert not hist['missing']
for e in hist['059']:
 raw=(b/e['preserved_bytes']).read_bytes();x=mi[e['original_path']];assert len(raw)==e['bytes']==x['bytes'] and sha(raw)==e['sha256']==x['sha256'] and oid('blob',raw)==e['git_blob']==x['git_blob']
for e in hist['774']:
 raw=(b/e['preserved_bytes']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
objects={}
for key,e in gp['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,c in gp['commits'].items():assert objects[rev].splitlines()[0]==b'tree '+c['root_tree'].encode()
for p in gp['paths']:
 raw=(b/p['preserved_bytes']).read_bytes();raw=gzip.decompress(raw) if p['preserved_bytes'].endswith('.gz') else raw;assert sha(raw)==p['sha256'] and len(raw)==p['bytes'] and oid('blob',raw)==p['git_blob'];cur=gp['commits'][p['revision']]['root_tree'];assert [x['name'] for x in p['path_chain']]==p['path'].split('/')
 for step in p['path_chain']:
  assert step['tree']==cur and entries(objects[cur])[step['name']]==(step['mode'],step['object']);cur=step['object']
 assert cur==p['git_blob']
for x in rr['registrations']:
 assert sha((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(json.loads((b/x['path']).read_bytes())['registered_utc'])<datetime.fromisoformat(rr['recorded_utc'])
reads=rr['assigned_personal_reads']+rr['support_personal_reads']
for e in reads:
 raw=(b/e['archive']).read_bytes();assert sha(raw)==e['sha256'] and len(raw.splitlines())==e['eof'];assert all(1<=a<=z<=e['eof'] for a,z in e['actual_display_chunks']);assert all(any(a<=c<=d<=z for a,z in e['actual_display_ranges']) for c,d in e['actual_display_chunks']);used={i for a,z in e['actual_display_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert used.isdisjoint(unread) and len(used)+len(unread)==e['eof']
def walk(x):
 if isinstance(x,dict):
  if 'archive' in x and 'line_range' in x:
   a,z=x['line_range'];assert sha((b/x['archive']).read_bytes())==x['sha256'];covered={i for e in reads if e['archive']==x['archive'] for u,v in e['actual_display_ranges'] for i in range(u,v+1)};assert all(i in covered for i in range(a,z+1)),x
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(report);assert len(report['lens_perspectives'])==len({x['lens'] for x in report['lens_perspectives']})==13
q=load('queue-selection-reconstructed.json')['entries'];assert {x['original_index_zero_based'] for x in q}=={602,2433}
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','checks':['Original registry roles and dirty P16/base distinction','Later recovered tracked patch hash','Exact package archive checksum, lock metadata and pinned member identity','Personal registration/read partitions and all source citations','Historical 059 transport byte counts, SHA-256 and blob IDs','Exact 774 receipts and offline raw Git commit/tree membership','Prior packet and published evidence hash links','Production-body equality, explicitly unread test tails and thirteen bounded perspectives'],'limits':'Does not independently prove a person read text, runtime behavior, dependency feature activation, historical custody, all consumers or whole-lens completion. No product validation.'}
if '--record' in sys.argv:(b/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: evidence integrity, package and Git proof, original receipts, source read partitions; no product execution')
