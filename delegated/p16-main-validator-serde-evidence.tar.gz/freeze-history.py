from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;old=Path('<LOCAL_PATH_0>');pub=Path('<LOCAL_PATH_1>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();rpath='recovered/original-registry-source-archive/registry.json.gz';mpath='recovered/original-transport-manifest.json.gz';r=json.load(gzip.open(pub/rpath,'rt'));sel={'qualification':'Reconstructed exact registry selection, not an original standalone record. Source identity and reviewer attribution retain original snapshot.','registry_uncompressed_sha256':sha(gzip.decompress((pub/rpath).read_bytes())),'rows':[{'original_index':i,**r['files'][i]} for i in (39,2587,2588)],'snapshot':next(x for x in r['snapshots'] if x['id']=='physical-p16')};(b/'registry-selection-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n')
q=json.loads((pub/'baseline-059/queue.json').read_bytes());wanted=['Q-L11-bc1410a8b8f757677a38','L12-CLOSURE-CATALOG-TYPED-ADMISSION-RESULT'];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'qualification':'Reconstructed historical 059 selections, not checkpoint 3821 or current coverage.','entries':[{'original_index_zero_based':i,'entry':e} for i,e in enumerate(q['entries']) if e.get('contract_id') in wanted]},indent=2)+'\n')
m=json.load(gzip.open(pub/mpath,'rt'));idx={e['path']:e for e in m['entries']};paths=[]
for lens,n in [(11,424),(11,425),(12,878),(12,879)]:
 for k in ['READ','VERIFY','STATE']:paths.append(f'segovb/{k}-L{lens}-{n}.json')
paths += ['segovb/REGISTRATION-SEGOVB-1498.json','segovb/REGISTRATION-SEGOVB-1499.json','parallel-l12-20261029/REGISTRATION-PAR-L12-638.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-638-WINDOWS-ORIGINAL2587.json','parallel-l12-20261029/PROPOSAL-L12-878.json','parallel-l12-20261029/REGISTRATION-PAR-L12-650.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-650-WINDOWS-ORIGINAL2588.json','parallel-l12-20261029/PROPOSAL-L12-879.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-879-SERDE-LOCK-AUTHORITY.json']
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file():missing.append(p);continue
 raw=(old/p).read_bytes();e=idx[p];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(raw)==e['git_blob'];dst=b/'historical-059'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records.append({'original_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
pre='handoff/774/adler-original/audit/continuation/';paths774=[pre+'camera/admission03/'+n for n in ['camera-adm03-f004-detail.json','camera-adm03-f005-detail.json','item-main-admission-026.json']]+[pre+'rig/admission03/catalogue-schema-receiver-witness-001.json'];rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records774=[]
for p in paths774:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+p]);assert oid(raw)==subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+p],text=True).strip();dst=b/'historical-774'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records774.append({'transport_revision':rev,'transport_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
refs=[]
for p in [rpath,mpath,'baseline-059/queue.json','baseline-059/ledger.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','recovered/physical-p16-patch-recovery/tracked.patch','recovered/physical-p16-patch-recovery/live-comparison-redacted.json','ASSESSMENT-L03-CATALOG-DIMENSIONS-95E.json','ASSESSMENT-EQUIPMENT-TOPOLOGY-95E.json']:
 raw=(pub/p).read_bytes();refs.append({'path':p,'sha256':sha(raw),'bytes':len(raw),'qualification':'Previously published evidence; original reviewer, revision, scope and qualification retained.'})
prior=[]
for d,author,names in [('<LOCAL_PATH_2>','/root/rig_identity',['REPORT.json','MANIFEST.json','personal-read-receipt.json']),('<LOCAL_PATH_3>','/root/mhr_character',['report.json','BUNDLE-MANIFEST.json','read-receipt.json','support-read-receipt.json'])]:
 entries=[]
 for n in names:
  raw=(Path(d)/n).read_bytes();entries.append({'path':d+'/'+n,'sha256':sha(raw),'bytes':len(raw)})
 prior.append({'packet':d,'author':author,'records':entries,'qualification':'Hash-link only; independent previous reads retain their own scope and author, no transfer or duplicate count.'})
(b/'evidence-links.json').write_text(json.dumps({'published_repository':str(pub),'published':refs,'prior_packets':prior,'qualification':'Source evidence links; original evidence remains intact and current/earlier state is never promoted to checkpoint 3821.'},indent=2)+'\n');(b/'historical-attribution.json').write_text(json.dumps({'059':records,'774':records774,'missing':missing,'qualification':'Exact original records copied unchanged; dirty P16, PR working, pinned package and current roles remain separate.'},indent=2)+'\n');print('059',len(records),'774',len(records774),'missing',missing)
