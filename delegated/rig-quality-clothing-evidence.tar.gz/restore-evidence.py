import hashlib,json,pathlib,shutil
p=pathlib.Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();a=pathlib.Path('<LOCAL_PATH_1>');b=pathlib.Path('<LOCAL_PATH_2>');paths=['crates/adventuresim-character-creator/src/clothing.rs','crates/adventuresim-character-creator/src/clothing/validation.rs'];records=[]
for path in paths:
 x=(a/'source/rig-quality'/path).read_bytes();y=(b/'source/rig-quality'/path).read_bytes();assert x==y;d=p/'older-continuation'/'rig-quality'/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(x);records.append({'kind':'matching rig-quality source copy in 774 publication and earlier local collection','path':path,'archive':str(d.relative_to(p)),'bytes':len(x),'sha256':h(x)})
for name in ['contract-groups-590.json','contract-groups-591.json']:
 x=(a/name).read_bytes();y=(b/name).read_bytes();assert x==y;d=p/'older-continuation'/name;d.write_bytes(x);records.append({'kind':'774 operations historical contract summary','archive':str(d.relative_to(p)),'bytes':len(x),'sha256':h(x)})
xp=pathlib.Path('<LOCAL_PATH_3>');yp=pathlib.Path('<LOCAL_PATH_4>');x=xp.read_bytes();y=yp.read_bytes();assert x==y;d=p/'older-continuation/rig-admission03-findings.jsonl';d.write_bytes(x);records.append({'kind':'older original canonical findings in matching transport copies','archive':str(d.relative_to(p)),'bytes':len(x),'sha256':h(x),'zero_based_row':10,'id':'RIG-ADMISSION03-F011'})
(p/'older-continuation-index.json').write_text(json.dumps({'qualification':'Exact independently compared earlier local copies; historical author/revision and scope retained, not checkpoint3821.','records':records},indent=2)+'\n')
repo=pathlib.Path('<LOCAL_PATH_5>');rules=[]
for path in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-character-creator/AGENTS.md','crates/fabelgeist-armor/AGENTS.md']:
 d=p/'reference'/path;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/path,d);data=d.read_bytes();rules.append({'archive':str(d.relative_to(p)),'sha256':h(data),'bytes':len(data)})
(p/'rules-evidence.json').write_text(json.dumps({'personally_read':rules,'qualification':'Equipment guide applies to shape work; user explicitly prohibits all implementation, artistic inspection, rendering and product validation for this source-only audit.'},indent=2)+'\n')
