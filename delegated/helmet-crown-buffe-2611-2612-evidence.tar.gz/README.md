# Helmet crown and buffe: checkpoint 17 reconciliation

This is an additive, source-only reconciliation proposal by `/root/rig_identity`
for original roles 2611 and 2612 at working source revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Historical pr-working files match
individual 6533 and 95e Git blobs; the recorded historical snapshot also had
four unrelated modified paths, so that equality does not make its tree clean.
Both old and current role bodies were independently read in full: crown 1–34
and buffe 1–64. Read registrations and receipts preserve source identities,
timestamps, per-registration support windows and unread complements. Full
archived bytes and integrity checks do not establish additional personal reads.

`REPORT.json` records bounded findings, safeguards, open questions and thirteen
perspectives. The established current breath/course record and the historical
paired-ring topology question have different first contracts: no alias or new
count is asserted. The separate two-course upper-seam observation remains an
editor/persistence question. Priors retain their authors and revisions; the
published helmet assessment itself does not identify its reviewer by name.

`history/` contains exact original 059 records checked against the preserved
transport manifest, 774 evidence transported by f82, separate prior assessment
copies, the P16 recovery qualification and tracked patch, and mechanical
registry/queue/ledger selections. Reconstructions are not independent original
receipts. P16 is separate from these pr-working roles; its base is not its dirty
snapshot and its patch match does not establish invocation or full custody.
The 774 earlier 13-row registration pin differs from the recovered later prefix;
that earlier pin predates and does not by itself invalidate rows 056/057.
Nothing is promoted to checkpoint 3821.

The c152 committed baseline and the working baseline captured during packet
construction are stored separately; their full-file hashes differ and their
selected ledger entries 471–472 are equal. Only the committed copy has the
included Git membership proof. The checkpoint 17 published archive contains
reconstructed path-redacted members, although five selected prior members were
compared byte-for-byte. `git-proofs.json` and `git-objects/` preserve commit,
tree, blob, source, and transport identities. Publication review of retained
local path metadata belongs to the central coordinator.

Run the following read-only evidence verifiers from this directory:

```
python3 verify-evidence.py
python3 verify-manifest.py
```

Both print results only; neither runs product code. Construction scripts write
packet files and must not be rerun on the frozen packet. No implementation,
builds, tests, fixtures, shader execution, rendering, probes or product
validation occurred. This packet does not close a lens or settle the ledger.
