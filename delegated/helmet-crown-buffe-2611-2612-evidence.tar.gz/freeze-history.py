from pathlib import Path
import json,gzip,shutil,hashlib,tarfile
b=Path(__file__).resolve().parent;prior=Path('<LOCAL_PATH_0>');common=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');extract=Path('<LOCAL_PATH_3>');sha=lambda d:hashlib.sha256(d).hexdigest();blob=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def cp(src,dst):
 d=(b/dst);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,d);return d
for n in ['original-registry.json.gz','original-transport-manifest.json.gz','baseline-059-queue.json.gz','baseline-059-ledger.json.gz','p16-recovery.json','p16-tracked.patch']:
 cp(common/n,'history/'+n)
for n in ['source-range-registration.jsonl.gz','source-qualifications.jsonl.gz','additional.jsonl.gz','admission03-scope-reconciliation-044.json.gz','completion-112.json.gz']:
 cp(common/'774'/n,'history/774/'+n)
for f in ['BASELINE-95E-20261110.json','ASSESSMENT-HELMET-FOOTWEAR-95E.json','DELEGATED-EVIDENCE-CHECKPOINT-17.json','DELEGATED-CHECKPOINT-17-QUALIFICATION.json']:
 cp(pub/f,'history/published/'+f)
cp(pub/'delegated/helmet-crown-buffe-evidence.tar.gz','history/prior-role/published-evidence.tar.gz')
for f in ['REPORT.json','MANIFEST.json','registration.json','personal-read-receipt.json','historical-attribution.json','evidence-links.json']:
 cp(prior/f,'history/prior-role/'+f)
for path,name in [('<LOCAL_PATH_4>','prior-anime-helmets'),('<LOCAL_PATH_5>','prior-pierced')]:
 for f in ['REPORT.json','MANIFEST.json','read-receipt.json']:cp(Path(path)/f,'history/'+name+'/'+f)
old=json.loads((prior/'historical-attribution.json').read_text())['records_059'];transport=json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()));idx={x['path']:x for x in transport['entries']};records=[]
for x in old:
 path=x['original_path'];src=prior/x['preserved_bytes'];dst=cp(src,'history/059/'+path);d=dst.read_bytes();z=idx[path];assert (len(d),sha(d),blob(d))==(x['bytes'],x['sha256'],x['git_blob'])==(z['bytes'],z['sha256'],z['git_blob']);records.append({'path':path,'archive':'history/059/'+path,'bytes':len(d),'sha256':sha(d),'git_blob':blob(d),'kind':'059 original'})
for path in ['root-l3-extension-20261030/READ-ROOT-L3-EXT-035-042.json','root-l3-extension-20261030/REGISTRATION-ROOT-L3-EXT-035-042.json','root-l3-extension-20261030/CONTRACT-PROPOSALS-ROOT-L3-EXT-035-045.json']:
 dst=cp(extract/path,'history/059/'+path);d=dst.read_bytes();z=idx[path];assert (len(d),sha(d),blob(d))==(z['bytes'],z['sha256'],z['git_blob']);records.append({'path':path,'archive':'history/059/'+path,'bytes':len(d),'sha256':sha(d),'git_blob':blob(d),'kind':'059 original root q3141'})
for n in ['source-range-registration.jsonl.gz','source-qualifications.jsonl.gz','additional.jsonl.gz','admission03-scope-reconciliation-044.json.gz','completion-112.json.gz']:
 x=next(x for x in json.loads((common/'attribution-and-copies.json').read_text())['records'] if x['copy']=='history/774/'+n);records.append(x)
for name in ['prior-role','prior-anime-helmets','prior-pierced']:
 for f in sorted((b/'history'/name).iterdir()):
  if f.is_file() and f.name!='published-evidence.tar.gz':
   d=f.read_bytes();records.append({'kind':'prior-assessment','author':'/root/rig_identity' if name=='prior-role' else '/root/hair_ops','archive':str(f.relative_to(b)),'sha256':sha(d),'bytes':len(d)})
(b/'history/records.json').write_text(json.dumps({'records':records,'qualification':'Copied exact bytes: 059 originals versus earlier independent assessments kept separate; f82 is archival transport. No role/read/lens credit transfer or checkpoint3821 promotion.'},indent=2)+'\n')
reg=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()));queue=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()));ledger=json.loads((b/'history/published/BASELINE-95E-20261110.json').read_text());selection={'qualification':'Mechanically reconstructed exact selections; these are not original independent receipts and do not change status.','registry_sha256':sha(gzip.decompress((b/'history/original-registry.json.gz').read_bytes())),'registry_roles':{str(i):reg['files'][i] for i in [2611,2612]},'queue_sha256':sha(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes())),'queue_entries':{str(i):queue['entries'][i] for i in [1813,2404,2691,3141]},'baseline_sha256':sha((b/'history/published/BASELINE-95E-20261110.json').read_bytes()),'current_ledger_entries':{str(i):ledger['newly_assessed_ledger']['entries'][i] for i in [471,472]}}
(b/'history/selections-reconstructed.json').write_text(json.dumps(selection,indent=2)+'\n')
checkpoint=json.loads((b/'history/published/DELEGATED-EVIDENCE-CHECKPOINT-17.json').read_text());bundle=next(x for x in checkpoint['bundles'] if x['bundle_id']=='helmet-crown-buffe');archive=b/'history/prior-role/published-evidence.tar.gz';assert sha(archive.read_bytes())==bundle['archive_sha256'];cmp=[]
with tarfile.open(archive,'r:gz') as tar:
 for name in ['REPORT.json','MANIFEST.json','registration.json','personal-read-receipt.json','historical-attribution.json']:
  a=(b/'history/prior-role'/name).read_bytes();c=tar.extractfile(name).read();cmp.append({'member':name,'original_sha256':sha(a),'published_sha256':sha(c),'byte_identical':a==c})
(b/'history/prior-role/published-comparison.json').write_text(json.dumps({'archive_sha256':bundle['archive_sha256'],'comparison':cmp,'qualification':'Only selected members compared; some other archive members are reconstructed path-redacted copies. No whole-archive equality is asserted.'},indent=2)+'\n');print('records',len(records),'published member comparisons',len(cmp))
