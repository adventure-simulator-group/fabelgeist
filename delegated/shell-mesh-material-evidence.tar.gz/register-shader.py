from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';g=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);sha=lambda d:hashlib.sha256(d).hexdigest();rows=[]
for path,rs,name in [('crates/fabelgeist-shell/src/wgsl.rs',[[95,135],[210,230],[260,280]],'wgsl.rs'),('crates/fabelgeist-shell/src/selfcollision.rs',[[80,134]],'selfcollision.rs')]:
 d=g('show',rev+':'+path);eof=len(d.splitlines());assert all(1<=a<=z<=eof for a,z in rs);p='support/'+name
 if (b/p).exists():assert (b/p).read_bytes()==d
 else:(b/p).write_bytes(d)
 rows.append({'kind':'current native shader text support only','revision':rev,'path':path,'archive':p,'git_blob':g('rev-parse',rev+':'+path).decode().strip(),'sha256':sha(d),'bytes':len(d),'eof':eof,'registered_ranges':rs,'planned_chunks':rs})
x={'schema':'726-shell-spacing-shader-support-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'WGSL as source text only; no shader compile, simulation or runtime.'};(b/'shader-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(sha((b/'shader-registration.json').read_bytes()))
