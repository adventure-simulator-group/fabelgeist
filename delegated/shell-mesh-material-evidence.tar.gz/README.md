# Bounded shell mesh and material source evidence

This packet records `/root/rig_identity`'s independent source-only review of
original registry roles 2646 (`fabelgeist-shell/src/mesh.rs`) and 2647
(`fabelgeist-shell/src/lib.rs`), plus separately registered support. It supplies
thirteen bounded lens perspectives to the central audit; it does not establish
whole-lens completion, product validation, or unique ledger counts.

The recorded `pr-working` snapshot has head
`6533e444fa37552927070cc8d8190907fd3b413e` and four unrelated status entries.
Both selected file objects independently equal their respective per-file objects
at that head and pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Revision
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee` is a recovered evidence transport,
not the historical product revision. Raw Git commit, tree, and blob membership
proofs are retained in `git-proofs.json` and `git-objects/`.

Original role 2646's historical material was lines 1–139; role 2647's was
lines 1–56 of its 58-line file. This reviewer personally displayed old and
current full bodies after prospective registration. Historical lines 57–58 of
role 2647 are new supporting inspection, not historical role credit. Support
ranges, actual chunk displays and unread complements are in
`personal-read-receipt.json`. Original 059 Lens11's receipt does not identify
an individual reader. Its Lens12 reads belong to `/root/lens12_frontier`; the
root adoption records no personal rereads. Earlier 774 and current-review
readers and their revisions are retained separately in `REPORT.json` and
`historical-attribution.json`.

`REPORT.json` identifies two conditional source questions: direct adjacency
with unvalidated out-of-range endpoints, and the downstream reciprocal of a
radius that may underflow when halving a positive thickness. The canonical
`Shell::new` validates the mesh before adjacency. The latter observation
extends the original 774/059 half-underflow observation; scale policy and device
behavior remain unresolved. Neither question implies a demonstrated product
incident, a confirmed independent count, or a completed repair. The report
also preserves 059's pre-existing additive correction to the historical
no-particles finding: the prior mesh validator rejects that input first.

`registry-selection-reconstructed.json` and
`queue-selection-reconstructed.json` are selected, explicitly reconstructed
records; they are not original standalone files. The original 059 records in
`historical-059/` are exact bytes checked against the recovered original
transport manifest. Historical 774 records and earlier assessments are
hash-linked through `evidence-links.json`; `published-prior-packet-links.json`
checks only the listed selected members against corresponding published
archives, not byte identity of every archive member. These linked published
bundles and exact prior packets remain dependencies of full verification.

The separate P16 dirty snapshot is based on `a120390947c89b703dc74c4255a13c035d054c50`;
that base is not the dirty snapshot's commit. Its later recovered tracked
patch matches the recorded hash, with seven untracked files separate; matching
bytes do not establish the original diff invocation or uninterrupted custody.
This packet does not recover or promote the checkpoint 3821 ledger or queue.

Run `python3 verify-evidence.py` to check evidence integrity, source ranges,
original records and linked proofs; `python3 verify-manifest.py` checks this
packet's frozen files. These are evidence-only checks. No product, GPU, shader,
simulation, fixture, build, test or runtime probe was executed.
