import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';regs=['support-registration.json','support-registration-02.json','support-registration-03.json'];supports=[x for n in regs for x in json.loads((p/n).read_text())['sources']];records=json.loads((p/'registration.json').read_text())['sources']+supports;objdir=p/'git-objects';objdir.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=objdir/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);out[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 assert tree==x['git_blob_sha1'];b=(p/x['archive']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'revision':rev,'path':x['path'],'archive':x['archive'],'commit_tree':root,'chain':chain,'blob':tree})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw Git commit/tree objects and exact source bytes verify revision/path membership only, not personal display credit.','objects':objects,'proofs':proof},indent=2)+'\n')
ranges={0:[],1:[[250,295],[350,417],[475,484]],2:[[1,262],[265,417]],3:[[1,80],[200,415],[740,805],[1030,1225]],4:[[97,130]],5:[[20,48]],6:[[265,315]],7:[[145,290],[455,485]],8:[[50,138]]};reads=[]
for i,x in enumerate(supports):reads.append({'path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':ranges[i]})
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'path':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in regs],'reads':reads,'qualification':'Only listed ranges personally displayed; metadata search and whole archived bytes confer no further read or ordered role credit. Support 0 was not personally displayed. All test source text remains unexecuted.'},indent=2)+'\n');print('proofs',len(proof),'objects',len(objects),'support',len(reads))
