from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';cur='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((r/'registration.json').read_bytes());entries=[];copies={}
plan=[('crates/adventuresim-tactical-client/src/animation/procedural/ik/target_speed.rs',[[1,58]]),('crates/adventuresim-tactical-core/src/combat_config/runtime.rs',[[1,85]]),('crates/adventuresim-tactical-core/src/combat_config.rs',[[121,148],[650,700]]),('crates/adventuresim-tactical-client/src/presentation/recipe_mesh.rs',[[35,87]]),('crates/adventuresim-tactical-client/src/presentation/doors.rs',[[24,61]]),('crates/adventuresim-tactical-client/src/presentation/furniture.rs',[[50,90]])]
for i,(path,ranges) in enumerate(plan):
 b=subprocess.check_output(['git','-C',repo,'show',cur+':'+path]);oid=subprocess.check_output(['git','-C',repo,'rev-parse',cur+':'+path],text=True).strip();local=f'support/{i:02d}.rs';copies[local]=b;entries.append({'path':path,'revision':cur,'local':local,'sha256':h(b),'git_blob':oid,'eof':len(b.splitlines()),'prospective_ranges':ranges,'qualification':'New separately registered 95e support only; no original role credit or other-reader transfer.'})
ext=[]
for v in reg['rows'][0]['versions']:
 ext.append({'path':reg['rows'][0]['path'],'revision':v['revision'],'local':v['local'],'sha256':v['sha256'],'eof':v['eof'],'prospective_ranges':[[121,145]],'qualification':'New contextual extension beyond original 2490 material; prior earlier agent read retained separately.'})
d={'schema':'726-p16-three-roles-support-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','entries':entries,'assigned_role_context_extension':ext,'restriction':'No product, geometry, renderer, simulation, tests, fixtures or runtime probes.'}
with (r/'support-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for p,b in copies.items():(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(b)
print('registered',d['registered_utc'],h((r/'support-registration.json').read_bytes()))
for x in entries:print(x['path'],x['eof'],x['sha256'],x['prospective_ranges'])
