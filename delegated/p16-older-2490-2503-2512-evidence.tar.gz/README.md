# Bounded older physical-p16 source reassessment

`REPORT.json` assesses original P16 roles 2490, 2503 and 2512. Exact fresh
personal read windows, separately registered support, original material and
unread complements are in `read-receipt.json`. Earlier `/root/hair_ops` and
`/root/rig_identity` records retain their own read scopes and attribution.

The P16 registry, content-addressed source archive, earlier reviewer records,
selected prior manifest-verified evidence and later exact-matching tracked
patch are preserved. The patch excludes seven untracked paths and does not prove
original capture custody. f82 is an evidence transport; per-file matches to
clean a120, 039 and 6533 do not make the dirty P16 snapshot clean or restore
checkpoint 3821. Prior packets are hash-linked and only selected files are
copied; selections are expressly distinguished from originals.

`python3 verify-evidence.py` checks evidence offline. No product, geometry,
renderer, fixture, build, test, probe, repair or runtime work was performed.
