from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');rec=Path('<LOCAL_PATH_1>');cur='95e63628f9d70b8dd6e6fede64334696c6995009';base='a120390947c89b703dc74c4255a13c035d054c50';origin='039329518e264f19206cf5b0b98d177433f40c17';pr='6533e444fa37552927070cc8d8190907fd3b413e';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';h=lambda b:hashlib.sha256(b).hexdigest();raw=gzip.decompress((rec/'registry.json.gz').read_bytes());assert h(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);ranges={2490:[[90,120],[240,340],[2935,2973]],2503:[[80,165]],2512:[[1,100],[190,240]]};out=[];contents={}
with tarfile.open(rec/'objects.tar.gz','r:gz') as tar:
 for i in (2490,2503,2512):
  row=registry['files'][i];path=row['source_id'].split(':',1)[1];old=tar.extractfile(row['sha256']).read();assert h(old)==row['sha256'];obj='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];assert subprocess.check_output(['git','-C',str(pub),'show',f82+':'+obj])==old
  now=subprocess.check_output(['git','-C',str(pub),'show',cur+':'+path]);versions=[]
  for tag,b,revision in [('p16',old,'physical-p16 dirty snapshot based on '+base),('current',now,cur)]:
   local=f'source/{i}-{tag}.rs';contents[local]=b;versions.append({'revision':revision,'local':local,'sha256':h(b),'bytes':len(b),'eof':len(b.splitlines()),'prospective_ranges':ranges[i],'role_material_ranges':row['material_ranges'] if tag=='p16' else None,'qualification':'Displayed windows outside original P16 material and original scope additions are separately registered personal support; no original role transfer. Test source only.'})
  comparisons=[]
  for rev in [base,origin,pr,cur]:
   b=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path]);oid=subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+path],text=True).strip();comparisons.append({'revision':rev,'sha256':h(b),'git_blob':oid,'equals_p16':b==old,'equals_current':b==now,'qualification':'Per-file identity only; no whole-snapshot cleanliness or personal read credit.'})
  out.append({'original_index':i,'source_id':row['source_id'],'snapshot':row['snapshot'],'registry_row':row,'path':path,'transport_revision':f82,'transport_path':obj,'versions':versions,'git_comparisons':comparisons})
d={'schema':'726-p16-original-2490-2503-2512-prospective-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','baseline':cur,'registry_uncompressed_sha256':h(raw),'rows':out,'prior_qualification':'Prior /root/hair_ops role2490 and 2512 packets and /root/rig_identity role2503 packet have exact separately retained personal scopes. Re-reading here does not transfer earlier reader credit.','p16_qualification':'Dirty source based a120; f82 transports content, 039 is catalog origin only. Later matching tracked patch is separate with seven untracked paths and original custody limitations. No checkpoint3821.','restriction':'Source text only; no simulation, image, product, builds, tests, fixture, runtime probes, repairs.'}
with (r/'registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for path,b in contents.items():(r/path).parent.mkdir(parents=True,exist_ok=True);(r/path).write_bytes(b)
print('registered',d['registered_utc'],'sha256',h((r/'registration.json').read_bytes()))
for x in out:
 print(x['original_index'],[(v['local'],v['sha256'],v['eof'],v['prospective_ranges']) for v in x['versions']]);print('comparisons',[(c['revision'][:8],c['equals_p16'],c['equals_current']) for c in x['git_comparisons']])
