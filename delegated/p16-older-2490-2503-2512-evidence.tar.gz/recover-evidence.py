from pathlib import Path
import datetime,difflib,gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;rec=Path('<LOCAL_PATH_0>');pub=Path('<LOCAL_PATH_1>');ws=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest();records=[]
def save(src,local,kind):
 b=Path(src).read_bytes();p=r/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);records.append({'origin':str(src),'local':str(local),'bytes':len(b),'sha256':h(b),'kind':kind})
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 save(rec/n,'recovered/'+n,'Recovered exact archived evidence; registry/queue containers and redacted report have recorded qualifications.')
for n in ['COVERAGE-L01-ROLES.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','ASSESSMENT-DELEGATED-ANIMATION-ROOF-2488-2495.json','ASSESSMENT-DELEGATED-BUILDING-P16-2496-2503.json','ASSESSMENT-DELEGATED-BUILDING-P16-2504-2512.json']:
 save(pub/n,'prior/'+n,'Prior central source coverage/recovery, no personal-read transfer.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-tactical-client/src/animation/AGENTS.md']:
 save(ws/n,'rules/'+n,'Applicable repository rules; source-only user constraint supersedes product validation instructions.')
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';root='handoff/774/adler-original/audit/continuation/camera/owner-reached-producer-followup/'
for name in ['source-range-registration.jsonl','additional-sources.jsonl','coverage.jsonl','traces.jsonl']:
 gp=root+name;b=subprocess.check_output(['git','-C',str(pub),'show',f82+':'+gp]);local='historical/774-camera/'+name;p=r/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);records.append({'origin':'git:'+f82+':'+gp,'local':local,'bytes':len(b),'sha256':h(b),'kind':'Exact 774 camera record via f82 evidence transport, not P16 project HEAD.','transport_revision':f82,'git_path':gp})
specs=[('ik',Path('<LOCAL_PATH_3>'),'packet-manifest.json',['historical/','support-registration'],['report.json','read-receipt.json','support-read-receipt.json','registration.json','historical-manifest.json','reference/older-selection.json','support/admission-0-crates__fabelgeist-geometry__src__measurement.rs','support/admission-1-crates__adventuresim-core__src__linear_speed.rs','support/admission-2-crates__adventuresim-tactical-core__src__animation__sample_rate.rs']),('lod',Path('<LOCAL_PATH_4>'),'MANIFEST.json',['historical-059/','historical-774/','support-registration'],['REPORT.json','personal-read-receipt.json','registration.json','original-attribution.json']),('materials',Path('<LOCAL_PATH_5>'),'packet-manifest.json',['historical/','support-registration'],['report.json','read-receipt.json','support-read-receipt.json','registration.json','historical-manifest.json'])]
prior=[]
for label,root,manifest,prefixes,names in specs:
 md=(root/manifest).read_bytes();m=json.loads(md);table={x['path']:x for x in m['files']};save(root/manifest,f'prior/{label}/{manifest}','Exact prior manifest; only listed selections copied here, full prior packet remains hash-linked by original path.')
 selected=sorted({p for p in table if any(p.startswith(x) for x in prefixes)}|{n for n in names if n in table})
 for name in selected:
  b=(root/name).read_bytes();x=table[name];assert len(b)==x['bytes'] and h(b)==x['sha256'];save(root/name,f'prior/{label}/{name}','Exact prior manifest-verified original or earlier assessment/receipt; its own author/scope unchanged.')
 prior.append({'label':label,'source_packet':str(root),'manifest_local':f'prior/{label}/{manifest}','manifest_sha256':h(md),'selected_files':len(selected),'qualification':'This is a verified selection, not a complete copy of that prior packet; its recorded hash and original path are preserved.'})
rr=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());registry=json.loads(rr);qr=gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qr);cat=json.loads((r/'recovered/catalog-774.json').read_bytes());cov=json.loads((r/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=[2490,2503,2512];qs=[42,66,585,804,807,1165,1177,1935,2249]
sel={'kind':'Newly reconstructed selection for navigation; full recovered registry, source archive and 059 queue retained.','registry_uncompressed_sha256':h(rr),'queue_uncompressed_sha256':h(qr),'registry_rows':{str(i):registry['files'][i] for i in ids},'catalog_rows':{str(i):cat['rows'][i] for i in ids},'prior_coverage_rows':{str(i):cov['roles'][i] for i in ids},'queue_rows':{str(i):q['entries'][i] for i in qs},'snapshot_row':next(x for x in registry['snapshots'] if x['id']=='physical-p16'),'qualification':'Earlier author/revision and P16 dirty status retained; no inferred checkpoint3821 record.'}
(r/'historical-selections-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n')
diff=[]
for i in ids:
 a=(r/f'source/{i}-p16.rs').read_text().splitlines();b=(r/f'source/{i}-current.rs').read_text().splitlines();ops=[]
 for tag,al,ah,bl,bh in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if tag!='equal':ops.append({'tag':tag,'p16_line_span':[al+1,ah],'current_line_span':[bl+1,bh]})
 diff.append({'index':i,'p16_eof':len(a),'current_eof':len(b),'changed_line_spans':ops})
(r/'comparison-summary.json').write_text(json.dumps({'kind':'Mechanical whole-file comparison metadata only, not personal display of changed lines.','rows':diff},indent=2)+'\n')
(r/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'prior_packets':prior,'qualification':'Historical original files, reconstructed selections and later patch recovery remain distinctly labeled; no checkpoint3821.'},indent=2)+'\n')
print('selected prior files',[(x['label'],x['selected_files']) for x in prior],'records',len(records),'sha256',h((r/'historical-manifest.json').read_bytes()))
