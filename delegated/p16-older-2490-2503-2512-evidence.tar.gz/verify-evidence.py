'''Evidence-integrity verification only; no product, geometry or tests run.'''
from pathlib import Path
import difflib,gzip,hashlib,json,tarfile
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((r/'registration.json').read_bytes());sp=json.loads((r/'support-registration.json').read_bytes());hist=json.loads((r/'historical-manifest.json').read_bytes());sel=json.loads((r/'historical-selections-reconstructed.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());proof=json.loads((r/'git-proofs.json').read_bytes());report=json.loads((r/'REPORT.json').read_bytes())
for x in hist['records']:
 b=(r/x['local']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
for prior in hist['prior_packets']:
 p=r/f"prior/{prior['label']}";m=json.loads((r/prior['manifest_local']).read_bytes());assert h((r/prior['manifest_local']).read_bytes())==prior['manifest_sha256'];table={x['path']:x for x in m['files']};count=0
 for item in hist['records']:
  prefix=f"prior/{prior['label']}/"
  if item['local'].startswith(prefix):
   name=item['local'][len(prefix):]
   if name in table:assert item['sha256']==table[name]['sha256'] and item['bytes']==table[name]['bytes'];count+=1
 assert count==prior['selected_files']
for x in rec['registrations']:assert h((r/x['path']).read_bytes())==x['sha256']
rr=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());registry=json.loads(rr);assert h(rr)==sel['registry_uncompressed_sha256']==reg['registry_uncompressed_sha256'];m=json.loads((r/'recovered/MANIFEST.json').read_bytes());assert h((r/'recovered/objects.tar.gz').read_bytes())==m['objects_archive_sha256'] and h((r/'recovered/registry.json.gz').read_bytes())==m['registry_gzip_sha256'];qr=gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qr);assert h(qr)==sel['queue_uncompressed_sha256']
for i,row in sel['registry_rows'].items():assert row==registry['files'][int(i)]
for i,row in sel['queue_rows'].items():assert row==q['entries'][int(i)]
snapshot=next(x for x in registry['snapshots'] if x['id']=='physical-p16');assert snapshot==sel['snapshot_row'] and len(snapshot['status_porcelain'])==159;patch=(r/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();recover=json.loads((r/'prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes());assert h(patch)==snapshot['patch_sha256']==recover['recovered_patch']['sha256'] and len(patch)==recover['recovered_patch']['bytes']
with tarfile.open(r/'recovered/objects.tar.gz','r:gz') as tar:
 for row in reg['rows']:
  old,cur=row['versions'];b=(r/old['local']).read_bytes();assert h(b)==old['sha256']==registry['files'][row['original_index']]['sha256'] and tar.extractfile(old['sha256']).read()==b;assert len(b.splitlines())==old['eof'];c=(r/cur['local']).read_bytes();assert h(c)==cur['sha256'] and len(c.splitlines())==cur['eof']
for x in rec['assigned_roles']+rec['current_support']:
 b=(r/x['source']).read_bytes();assert h(b)==x['sha256'] and len(b.splitlines())==x['eof'];occ=[]
 for lo,hi in x['display_union']+x['unread_complement']:
  assert 1<=lo<=hi<=x['eof'];occ.extend(range(lo,hi+1))
 assert len(occ)==x['eof'] and set(occ)==set(range(1,x['eof']+1))
for x in rec['assigned_roles']:
 row=next(y for y in reg['rows'] if y['original_index']==x['index']);v=next(y for y in row['versions'] if y['local']==x['source']);planned=v['prospective_ranges'][:]
 planned += [z for y in sp['assigned_role_context_extension'] if y['local']==x['source'] for z in y['prospective_ranges']]
 expected={i for lo,hi in planned for i in range(lo,hi+1)};actual={i for lo,hi in x['display_union'] for i in range(lo,hi+1)};assert expected==actual
for x in sp['entries']:assert next(y for y in rec['current_support'] if y['source']==x['local'])['display_union']==x['prospective_ranges']
camera=[json.loads(l) for l in (r/'historical/774-camera/additional-sources.jsonl').read_text().splitlines()];a=next(x for x in camera if x.get('id')=='CONT-CAMERA-PP-FOLLOWUP-SOURCE-025');b=next(x for x in camera if x.get('id')=='CONT-CAMERA-PP-FOLLOWUP-SOURCE-029');assert a['material_read_ranges']==[[285,315]] and b['material_read_ranges']==[[2968,2970]] and a['sha256']==b['sha256']==reg['rows'][0]['versions'][0]['sha256']
rig=r/'prior/lod/historical-774/handoff/774/adler-original/audit/continuation/rig/owner-reached-producer-followup';regs=[json.loads(l) for l in (rig/'additional-sources.jsonl').read_text().splitlines()];quals=[json.loads(l) for l in (rig/'source-qualifications.jsonl').read_text().splitlines()];assert regs[30]['id']=='RIG-OWNER-REACHED-PRODUCER-REGISTER-031' and regs[30]['material_ranges']==[[94,160]];assert quals[30]['qualified_material_ranges']==[[95,137]]
objs={}
for k,x in proof['objects'].items():
 b=gzip.decompress((r/x['preserved']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'] and oid(x['type'],b)==k;objs[k]=b
def lookup(b,name):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,n=b[i:z].split(b' ',1);child=b[z+1:z+21].hex();i=z+21
  if n.decode()==name:return mode.decode(),child
 raise KeyError(name)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for node in x['chain']:
  assert tree==node['tree'];mode,child=lookup(objs[tree],node['name']);assert mode==node['mode'] and child==node['object'];tree=child
 b=(r/x['local']).read_bytes();assert oid('blob',b)==tree==x['blob'] and h(b)==x['sha256']
comparison=json.loads((r/'comparison-summary.json').read_bytes())
for row in comparison['rows']:
 i=row['index'];a=(r/f'source/{i}-p16.rs').read_text().splitlines();b=(r/f'source/{i}-current.rs').read_text().splitlines();ops=[]
 for tag,al,ah,bl,bh in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if tag!='equal':ops.append({'tag':tag,'p16_line_span':[al+1,ah],'current_line_span':[bl+1,bh]})
 assert ops==row['changed_line_spans']
assert len(report['lens_perspectives'])==13 and report['implementation']=='not started'
if (r/'MANIFEST.json').exists():
 manifest=json.loads((r/'MANIFEST.json').read_bytes());files={str(x.relative_to(r)) for x in r.rglob('*') if x.is_file() and x!=r/'MANIFEST.json'};assert files=={x['path'] for x in manifest['files']}
 for x in manifest['files']:
  b=(r/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
print('PASS: six separate bounded P16/current displays and unread partitions, exact original material/774 camera and rig scopes, later tracked patch hash, prior manifest selections, 25 offline Git chains, 13 bounded perspectives, packet manifest if present. No product or geometry execution.')
