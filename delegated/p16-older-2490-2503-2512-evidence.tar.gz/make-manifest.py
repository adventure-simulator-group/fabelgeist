from pathlib import Path
import datetime,hashlib,json
r=Path(__file__).resolve().parent;out=r/'MANIFEST.json';assert not out.exists();rows=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p!=out:
  b=p.read_bytes();rows.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
d={'schema':'726-p16-three-roles-packet-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'qualification':'Every packet file, including nested prior manifests, is enumerated; only this top-level manifest is excluded. Original records and reconstructed selections retain their own qualifications.'};out.write_text(json.dumps(d,indent=2)+'\n');print(len(rows),'files sha256',hashlib.sha256(out.read_bytes()).hexdigest())
