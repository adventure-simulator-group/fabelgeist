#!/usr/bin/env python3
"""Read-only evidence, Git-tree, history and bounded privacy verification."""
import argparse,gzip,hashlib,io,json,os,pathlib,re,tarfile
HERE=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest();slash=b'/'
def require(ok,msg):
 if not ok:raise ValueError(msg)
def no_symlink_read(base,relative):
 base=base.absolute()
 for p in [base,*base.parents]:require(not p.is_symlink(),'symbolic-link ancestor')
 p=base
 for part in pathlib.Path(relative).parts:
  require(part not in ('..','.','/'),'invalid relative path');p=p/part;require(not p.is_symlink(),'symbolic-link evidence path')
 return p.read_bytes()
def source_files(root):
 out=set()
 for dirname,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:require(not (pathlib.Path(dirname)/name).is_symlink(),'symbolic link in evidence')
  for name in files:out.add((pathlib.Path(dirname)/name).relative_to(root).as_posix())
 return out
def plain(data):return gzip.decompress(data) if data.startswith(b'\x1f\x8b') else data
def git_hash(kind,data):return hashlib.sha1(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
def parse_tree(data):
 out={};i=0
 while i<len(data):
  space=data.find(b' ',i);nul=data.find(b'\0',space+1);require(space>=0 and nul>=0 and nul+21<=len(data),'malformed Git tree');mode=data[i:space].decode('ascii');name=data[space+1:nul].decode('utf-8');oid=data[nul+1:nul+21].hex();require(name not in out,'duplicate tree name');out[name]=(mode,oid);i=nul+21
 return out
agents={slash+b'root/'+x.encode() for x in ('hair_ops','rig_identity','mhr_character','camera_targeting','rig_garments','native_reports','lens12_frontier','segovb','handoff_portability_review')}
rootrx=slash+rb'(?:home|users|tmp|root|mnt|workspace|workspaces|private|var/(?:tmp|folders))/[^\s"\x27<>\x00\\]+';win=rb'[A-Za-z]:[\\/]+(?:Users|Documents and Settings)[\\/]+[^\s"\x27<>\x00]+'
pathrx=re.compile(rb'(?:(?<![A-Za-z0-9_])|\\[nrt])('+rootrx+rb'|'+win+rb')',re.I);secret=re.compile(rb'gh[pousr]_[A-Za-z0-9_]{25,}|github_pat_[A-Za-z0-9_]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}|-----BEGIN (?:RSA |DSA |OPENSSH |EC |ENCRYPTED )?PRIVATE KEY-----|AKIA[0-9A-Z]{16}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|AIza[0-9A-Za-z_-]{35}|glpat-[0-9A-Za-z_-]{20,}|npm_[0-9A-Za-z]{30,}|eyJ[A-Za-z0-9_-]{18,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}|(?:Bearer\s+)[A-Za-z0-9._~+/-]{24,}',re.I);escape=re.compile(rb'\\/|\\u002[fF]')
def privacy(data):
 norm=escape.sub(slash,data);bad=[];agent_count=0
 for z in pathrx.finditer(norm):
  if z.group(1).rstrip(b'.,;:!?`') in agents:agent_count+=1
  else:bad.append('path')
 if secret.search(norm):bad.append('secret')
 return bad,agent_count
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private-root',type=pathlib.Path);ap.add_argument('--source-root',type=pathlib.Path);ap.add_argument('--publication-root',type=pathlib.Path);args=ap.parse_args()
 manifest=json.loads((HERE/'MANIFEST.json').read_bytes());ls={x['path']:x for x in manifest['files']};actual=source_files(HERE)-{'MANIFEST.json'};require(actual==set(ls),'public manifest membership mismatch')
 for name,r in ls.items():
  b=no_symlink_read(HERE,name);require((H(b),len(b))==(r['sha256'],r['bytes']),'public manifest content mismatch')
 idx=json.loads((HERE/'EVIDENCE-IDENTITIES.json').read_bytes());members=idx['members'];require(len(members)==118 and idx['source_manifest_sha256']=='f3cd0e8482fb8a5d77962696aad2ec46c9c1d0ebb6c1a462849c606492e231c4','source inventory scope mismatch')
 original_manifest=no_symlink_read(HERE,'bundle/BUNDLE-MANIFEST.json');require(H(original_manifest)==idx['source_manifest_sha256'],'original source manifest identity mismatch');original=json.loads(original_manifest);exp={x['path']:(x['sha256'],x['bytes']) for x in original['files']};require(len(exp)==117,'original source manifest size mismatch')
 observed={r['source_path']:r for r in members};require(len(observed)==len(members) and set(observed)==set(exp)|{'BUNDLE-MANIFEST.json'},'original source manifest member set mismatch')
 private={}
 if args.private_root:
  b=no_symlink_read(args.private_root,'PRIVATE-ORIGINAL-MANIFEST.json');require(H(b)==idx['private_original_manifest_sha256'],'private manifest identity mismatch');private={r['sha256']:r for r in json.loads(b)['objects']}
 reconstructed=0;redactions=0;agent_mentions=0;gitobjs=0;source_checked=0
 for rel,r in observed.items():
  if rel in exp:require((r['original_stored_sha256'],r['original_stored_bytes'])==exp[rel] and r['source_manifest_bound'],'original source member binding mismatch')
  else:require(r['source_top_manifest'] and not r['source_manifest_bound'],'top manifest qualification mismatch')
  data=no_symlink_read(HERE,r['public_path']);decoded=plain(data);require((H(data),len(data),H(decoded),len(decoded))==(r['public_stored_sha256'],r['public_stored_bytes'],r['public_decoded_sha256'],r['public_decoded_bytes']),'public member identity mismatch')
  if r['encoding']=='gzip':
   try:
    with tarfile.open(fileobj=io.BytesIO(decoded),mode='r:') as t:
     require(not t.getmembers(),'unexpected opaque or nested tar archive')
   except tarfile.TarError:pass
  bad,n=privacy(decoded);require(not bad,'public evidence privacy candidate');agent_mentions+=n
  ops=r['redactions'];redactions+=len(ops)
  if ops:
   reconstructed+=1;require(r['status']=='privacy-reconstructed','redacted status mismatch')
   for op in ops:
    p=op['public_decoded_offset_0based'];token=op['public_placeholder'].encode();require(decoded[p:p+len(token)]==token,'public placeholder mismatch')
   if args.private_root:
    pr=private.get(r['original_stored_sha256']);require(pr is not None,'missing exact private original');old=no_symlink_read(args.private_root,pr['path']);require((H(old),len(old))==(r['original_stored_sha256'],r['original_stored_bytes']),'private original stored identity mismatch');oldplain=plain(old);require((H(oldplain),len(oldplain))==(r['original_decoded_sha256'],r['original_decoded_bytes']),'private original decoded identity mismatch')
    for op in sorted(ops,key=lambda z:z['original_decoded_offset_0based'],reverse=True):
     p=op['original_decoded_offset_0based'];n=op['original_decoded_bytes'];oldplain=oldplain[:p]+op['public_placeholder'].encode()+oldplain[p+n:]
    require(oldplain==decoded,'original-to-public transformation mismatch')
  else:require(r['status']=='exact-safe-copy' and r['public_stored_sha256']==r['original_stored_sha256'] and r['public_decoded_sha256']==r['original_decoded_sha256'],'exact copy identity mismatch')
  if r['git_object']:
   gitobjs+=1;g=r['git_object'];require(git_hash(g['type'],decoded)==g['git_sha1'] and not ops,'Git object identity mismatch')
  if args.source_root:
   old=no_symlink_read(args.source_root,rel);require((H(old),len(old))==(r['original_stored_sha256'],r['original_stored_bytes']),'source evidence drift');source_checked+=1
 require(reconstructed==7 and redactions==71 and gitobjs==27,'privacy or Git scope mismatch')
 if args.private_root:require(len(private)==7 and set(private)=={x['original_stored_sha256'] for x in members if x['redactions']},'private original inventory mismatch')
 # Recheck the source's Git-object membership chains, not merely stored hashes.
 proofs=json.loads(no_symlink_read(HERE,'bundle/git-proofs.json'));objects={}
 for oid,o in proofs['objects'].items():
  b=plain(no_symlink_read(HERE,'bundle/'+o['archive']));require((len(b),H(b),git_hash(o['type'],b))==(o['bytes'],o['sha256'],oid),'source Git proof object mismatch');objects[oid]=(o['type'],b)
 require(len(objects)==27 and len(proofs['proofs'])==17,'Git proof inventory mismatch')
 for proof in proofs['proofs']:
  typ,commit=objects[proof['revision']];require(typ=='commit' and commit.splitlines()[0]==b'tree '+proof['commit_tree'].encode(),'Git commit tree binding mismatch');chain=proof['chain'];require('/'.join(x['name'] for x in chain)==proof['path'],'Git source path mismatch');parent=proof['commit_tree']
  for item in chain:
   require(item['tree']==parent and objects[parent][0]=='tree','Git tree chain parent mismatch');mode,child=parse_tree(objects[parent][1])[item['name']];require((mode,child)==(item['mode'],item['object']),'Git tree edge mismatch');parent=child
  require(parent==proof['blob'],'Git blob membership mismatch');raw=plain(no_symlink_read(HERE,'bundle/'+proof['archive']));require(H(raw)==proof['sha256'] and git_hash('blob',raw)==proof['blob'],'Git proved source bytes mismatch')
 # Preserve the complete F066 original line and its separately attributed relationship.
 hist=json.loads(no_symlink_read(HERE,'HISTORICAL-RELATIONSHIPS.json'));f=hist['historical_record'];stored=no_symlink_read(HERE,f['source_archive']);dec=gzip.decompress(stored);line=dec.splitlines()[f['original_line_1based']-1];require((H(stored),H(dec),H(line),len(line))==(f['stored_sha256'],f['decoded_sha256'],f['line_sha256'],f['line_bytes_without_terminator']) and line==no_symlink_read(HERE,f['standalone_exact_line']),'F066 historical record identity mismatch');row=json.loads(line);require(row['id']=='RIG-ADMISSION03-F066' and row['source_id']==f['source_id'] and row['source_locations']==f['source_locations'],'F066 source attribution mismatch')
 a=hist['current_candidate'];assessment=no_symlink_read(HERE,a['assessment_path']);require(H(assessment)==a['assessment_sha256'] and json.loads(assessment)['new_current_candidates'][2]['id']==a['id']=='REVIEW-GARMENT-FIT-EDGE-SHAPE-95E','current candidate identity mismatch')
 reg=json.loads(no_symlink_read(HERE,'bundle/registration.json'));receipt=json.loads(no_symlink_read(HERE,'bundle/read-receipt.json'));require(reg['author']==receipt['author']=='/root/mhr_character' and reg['current_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and reg['historical_recorded_head']=='6533e444fa37552927070cc8d8190907fd3b413e' and reg['transport_revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee','reviewer or revision qualification mismatch')
 for role in (2629,2630):
  old=no_symlink_read(HERE,'bundle/source/pr-working-'+str(role)+'.rs');new=no_symlink_read(HERE,'bundle/source/current-'+str(role)+'.rs');require(old==new,'per-file role comparison mismatch')
 prior=json.loads(no_symlink_read(HERE,'bundle/prior-index.json'))
 require(prior['author']=='/root/hair_ops','prior reviewer attribution mismatch')
 for rec in prior['published_members']:
  public=no_symlink_read(HERE,'bundle/'+rec['file']);require(H(public)==rec['published_sha256'],'prior published member identity mismatch')
  historical=observed['prior/'+rec['path']];require(historical['original_stored_sha256']==rec['original_sha256'],'prior original member identity mismatch')
 require(no_symlink_read(HERE,'bundle/prior/historical-manifest.json')==no_symlink_read(HERE,'bundle/reference/public-prior-historical-manifest.json'),'reused prior redaction mismatch')
 g=json.loads(no_symlink_read(HERE,'GIT-IDENTITY-QUALIFICATION.json'))
 for row in g['members']:
  data=no_symlink_read(HERE,'bundle/'+row['member']);require((H(data),len(data))==(row['sha256'],row['bytes']),'Git identity disclosure record mismatch')
 if args.publication_root:
  ir=no_symlink_read(args.publication_root,g['prior_index']);require(H(ir)==g['prior_index_sha256'],'prior published index drift');doc=json.loads(ir);entry=next(x for x in doc['bundles'] if x['bundle_id']==g['prior_bundle']);require(entry['archive']==g['prior_archive'] and entry['archive_sha256']==g['prior_archive_sha256'],'prior archive index mismatch');raw=no_symlink_read(args.publication_root,g['prior_archive']);require((H(raw),len(raw))==(g['prior_archive_sha256'],g['prior_archive_bytes']),'prior archive drift')
  with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
   for row in g['members']:
    item=next(x for x in entry['members'] if x['path']==row['member']);stored=archive.extractfile(row['member']).read();require(stored==no_symlink_read(HERE,'bundle/'+row['member']) and item['published_sha256']==item['original_sha256']==row['sha256'],'prior indexed commit object mismatch')
  pattern_archive=no_symlink_read(args.publication_root,prior['published_archive']);require(H(pattern_archive)==prior['published_archive_sha256'],'prior pattern archive drift')
  with tarfile.open(fileobj=io.BytesIO(pattern_archive),mode='r:gz') as archive:
   for rec in prior['published_members']:
    stored=archive.extractfile(rec['path']).read();require(stored==no_symlink_read(HERE,'bundle/'+rec['file']) and H(stored)==rec['published_sha256'],'prior pattern archive member mismatch')
 # Bounded scan covers public metadata and verifier text, too. Agent identifiers
 # are retained exact; matched private values are never printed.
 for name in actual|{'MANIFEST.json'}:
  if name.startswith('bundle/'):continue
  b=no_symlink_read(HERE,name);bad,n=privacy(plain(b));require(not bad,'public metadata privacy candidate');agent_mentions+=n
 print(json.dumps({'status':'pass','public_members_checked':len(actual),'source_packet_members_checked':len(members),'reconstructed_members':reconstructed,'path_redaction_spans':redactions,'private_originals_checked':bool(args.private_root),'source_packet_checked':bool(args.source_root),'prior_published_git_objects_and_pattern_archive_checked':bool(args.publication_root),'source_files_checked':source_checked,'git_objects_checked':gitobjs,'git_membership_chains_checked':len(proofs['proofs']),'f066_line_sha256':f['line_sha256'],'recorded_agent_identifier_occurrences':agent_mentions,'qualification':'Original and reconstructed stored/decoded identities remain distinct. Scan patterns are bounded. F066 and current edge-shape candidate are related without an alias decision or new defect count. Read scopes and unavailable checkpoint3821 remain as recorded; no product or old verifier was executed.'},indent=2))
if __name__=='__main__':main()
