# Garment-pattern evidence, roles 2629–2630

This packet preserves the frozen source packet and its recorded reader,
revision, source scope and recovery qualifications. It contains all 117
manifest-listed source members and the original top-level manifest. Seven
members have privacy-reconstructed public bytes; the exact stored originals are
held in a separate private collection. Original, public, stored and decompressed
hashes and redaction offsets are recorded in `EVIDENCE-IDENTITIES.json`.

The complete historical 774 rig F066 line is preserved in the unchanged gzip
source and separately as `F066-original-record.json`. Its relationship to the
existing current edge-shape candidate is documented without deciding an alias
or adding a defect count. Prior 059 read credits and the current follow-up
reader remain separately attributed. The historical pr-working snapshot, its
recorded base, the later transport and pinned current revision remain distinct.
The missing checkpoint 3821 ledger and queue are not reconstructed here.

Run `python3 -B verify-stage.py` for a read-only public integrity and Git-tree
proof check. Add `--private-root DIRECTORY` to verify each private original and
its byte-for-byte reconstruction. Add `--source-root DIRECTORY` to compare all
118 frozen source files, and `--publication-root DIRECTORY` to check the
selected earlier indexed Git-object archive. The original packet's manifest
and source scripts bind original bytes and paths, so their original verification
or reconstruction scripts are not equivalent to this public verifier and may
not work with redacted members.

Exact Git commit proof objects retain author and committer identity metadata;
the path and secret pattern scan does not establish broader disclosure
suitability for those identities. An earlier indexed local publication archive
contains byte-identical commit objects; no live remote was checked. Privacy
scanning is bounded and cannot establish the absence of every possible secret
or encoded path. No product or original packet verifier was run.
