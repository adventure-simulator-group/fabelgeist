import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent
repo='<PRIVATE_PATH_0001>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009';base='6533e444fa37552927070cc8d8190907fd3b413e';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();show=lambda r,s:subprocess.check_output(['git','-C',repo,'show',r+':'+s]);entries=[]
roles=[(2629,'crates/fabelgeist-garment-code/src/pattern/spec.rs','091a579552af6da77a2bbcf091a6a7afddf4784dd6f488460940b9eb9fa77ee9',[[1,161],[211,231],[251,261],[277,310],[330,359],[401,455]]),(2630,'crates/fabelgeist-garment-code/src/pattern/core.rs','78a40a867edc2528c4d5bd02bd24b48e21b4e8fdf0e70e4c0cac759b680efa50',[[1,14],[56,195],[244,272]])]
for role,path,expected,ranges in roles:
 tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+expected;old=show(f82,tp);assert sha(old)==expected
 for tag,kind,r,b in [(f'pr-working-{role}','historical-pr-working',None,old),(f'current-{role}','current-assigned',rev,show(rev,path))]:
  dst=p/'source'/(tag+'.rs');dst.write_bytes(b);entries.append(dict(kind=kind,tag=tag,role=role,path=path,revision=r,transport_path=tp if r is None else None,archive=str(dst.relative_to(p)),sha256=sha(b),git_blob=blob(b),EOF=len(b.splitlines()),registered_ranges=ranges,qualification='Fresh independent bounded display; historical source bytes recovered through f82, not a clean snapshot claim.'))
support=[('fit','crates/fabelgeist-garment-fit/src/lib.rs',[[95,116],[132,161],[183,200],[226,242],[259,282]]),('svg','crates/fabelgeist-garment-code/src/pattern/svg.rs',[[137,148],[174,188]]),('component','crates/fabelgeist-garment-code/src/garment/component.rs',[[294,320]]),('cli','crates/fabelgeist-garment-code/src/bin/garment_code.rs',[[65,74]])]
for tag,path,ranges in support:
 b=show(rev,path);dst=p/'source'/(tag+'.rs');dst.write_bytes(b);assert all(1<=a<=z<=len(b.splitlines()) for a,z in ranges);entries.append(dict(kind='current-support',tag=tag,path=path,revision=rev,archive=str(dst.relative_to(p)),sha256=sha(b),git_blob=blob(b),EOF=len(b.splitlines()),registered_ranges=ranges,qualification='Independent bounded current support, no ordered role credit or transfer from earlier readers.'))
reg={'schema':'726-prospective-garment-pattern-followup-v1','author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_revision':rev,'historical_recorded_head':base,'transport_revision':f82,'entries':entries,'qualification':'Registration occurs before personal displays. Per-file equality is not clean-tree identity. 6533 is not separately displayed.'}
(p/'registration.json').write_text(json.dumps(reg,indent=2)+'\n');print('registered',len(entries),'sha256',sha((p/'registration.json').read_bytes()))
