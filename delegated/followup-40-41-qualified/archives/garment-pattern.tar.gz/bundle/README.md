# Garment-pattern source reconciliation

This additive packet records /root/mhr_character's independent bounded review
of historical roles 2629–2630 and current support at pinned 95e. Start with
`report.json`, `registration.json` and `read-receipt.json`. Recovered original
059 and 774 records, reconstructed 059 selections, separately attributed prior
review, original source objects, current source bytes and Git membership proofs
are kept distinct. Full saved source bodies do not imply full personal reads.

`verify-evidence.py` verifies recorded identities and integrity without writing;
`verify-manifest.py` checks every packet file except the root manifest itself,
including nested manifests. These checks do not execute or validate product
behavior. Historical transport f82 is not a product source revision; per-file
6533 equality does not establish a clean pr-working snapshot. Historical 3821
ledger and queue remain unrecovered. Rules, skills, and prior exact originals
can contain private local paths; a public checkpoint needs its own privacy-aware
handling and must preserve original and reconstructed identities separately.
