import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());raw=lambda f:gzip.decompress((p/f).read_bytes());nums=lambda rs:{i for a,b in rs for i in range(a,b+1)}
registry_raw=raw('reference/registry.json.gz');assert sha(registry_raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(registry_raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(registry_raw)
for i in (2629,2630):assert reg['files'][i]==sel['roles'][str(i)] and reg['files'][i]['snapshot']=='pr-working'
for idxname in ('rules.json','skills.json'):
 for e in load(idxname)['records']:
  assert sha((p/e['file']).read_bytes())==e['sha256']
for e in load('reference-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b))==(e['bytes'],e['sha256'])
r=load('registration.json');t=load('read-receipt.json');assert t['registration_sha256']==sha((p/'registration.json').read_bytes()) and len(r['entries'])==len(t['entries'])==8 and datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);views={}
for e,v in zip(r['entries'],t['entries']):
 b=(p/e['archive']).read_bytes();assert e['tag']==v['tag'] and sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'];seen=nums(v['displayed_chunks']);unseen=nums(v['unread_complement']);assert seen==nums(e['registered_ranges']) and seen|unseen==set(range(1,e['EOF']+1)) and not seen&unseen;views[e['tag']]=seen
 if e['kind']=='historical-pr-working':assert e['sha256']==reg['files'][e['role']]['sha256']
for i in (2629,2630):assert (p/f'source/pr-working-{i}.rs').read_bytes()==(p/f'source/current-{i}.rs').read_bytes()
qraw=raw('reference/queue.json.gz');lraw=raw('reference/ledger.json.gz');assert sha(qraw)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(lraw)=='3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac';q=json.loads(qraw);l=json.loads(lraw);x=load('059-selection-reconstructed.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw)
for k,v in x['entries'].items():assert q['entries'][int(k)]==v
for path,v in x['journal_entries'].items():
 z=l
 for part in path.strip('/').split('/'):z=z[int(part)] if isinstance(z,list) else z[part]
 assert z==v
assert q['entries'][316]['contract_id']=='SEGOVB-L12-GARMENT-PANEL-REFERENCE-PROPAGATION' and q['entries'][2092]['contract_id']=='OBL-L12-other_lens_extension_queues-6'
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
ll=load('history-059/segovb/READ-L11-430.json')
for role,n,ranges in [(2629,1545,[[1,141]]),(2630,1546,[[1,14],[67,99]])]:
 e=next(v for v in ll['sources'] if v['original_index']==role);assert e['fresh_personal_body_reads']==ranges and e['sha256']==reg['files'][role]['sha256'] and e['registration_sha256']==sha((p/f'history-059/segovb/REGISTRATION-SEGOVB-{n}.json').read_bytes())
rr=load('history-059/segovb/READ-L12-902.json');rr2=load('history-059/segovb/READ-L12-903.json');u=next(z for z in rr['rows'] if z['original_index']==2629);v=next(z for z in rr2['rows'] if z['original_index']==2630);assert u['fresh_personal_body_reads']==[] and u['new_original_credit']==0 and rr['new_original_roles']==1 and rr['root_personal_rereads']==[];assert v['fresh_personal_body_reads']==[[1,14],[67,99]] and rr2['root_personal_rereads']==[]
for a in (rr,rr2):assert a['proposal_sha256']==sha((p/'history-059'/a['proposal']).read_bytes())
old=load('prior-index.json');manifest=(p/'prior/MANIFEST.json').read_bytes();assert sha(manifest)==old['original_manifest_sha256']=='fac64c7ed950af42ec275c6e2102ab1f51f3f7fe808e7d593e185ae678a7e050';pm={e['path']:e for e in json.loads(manifest)['files']}
for e in old['selected_files']:
 b=(p/'prior'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(pm[e['path']]['bytes'],pm[e['path']]['sha256'])
entry=next(z for z in load('reference/checkpoint18-index.json')['bundles'] if z['bundle_id']=='garment-pattern-hair-ops');assert entry['archive_sha256']==old['published_archive_sha256']=='7ee94591adabdd016b181aa095e4bb40a880c6e3646e4c02ff61db7d632a320b'
for e in old['published_members']:
 x=next(x for x in entry['members'] if x['path']==e['path']);assert (e['original_sha256'],e['published_sha256'],e['changed'])==(x['original_sha256'],x['published_sha256'],x['changed']);assert sha((p/e['file']).read_bytes())==e['published_sha256'];assert sha((p/'prior'/e['path']).read_bytes())==e['original_sha256']
base='history-774/continuation/rig/admission03/';rows=raw(base+'source-range-registration.jsonl.gz').splitlines();adds=raw(base+'additional-contracts.jsonl.gz').splitlines();finds=raw(base+'findings.jsonl.gz').splitlines()
for role,n in [(2629,84),(2630,85)]:assert json.loads(rows[n-1])==reg['files'][role]['admission03_scope_observations'][0]['original_record']
assert json.loads(adds[69])['id']=='RIG-ADMISSION03-ADDITIONAL-084' and json.loads(adds[70])['id']=='RIG-ADMISSION03-ADDITIONAL-085';f=json.loads(finds[69]);assert f['id']=='RIG-ADMISSION03-F066' and f['source_id']=='pr-working:crates/fabelgeist-garment-fit/src/lib.rs'
pin=hist['rig_registration_pin_qualification'];a=json.loads(raw('history-774/continuation/root/admission03-scope-reconciliation-046.json.gz'));b=json.loads(raw('history-774/continuation/root/admission03-scope-reconciliation-050.json.gz'));data=raw(base+'source-range-registration.jsonl.gz');qual=raw(base+'source-qualifications.jsonl.gz');assert a['input_pins'][3]==pin['root046_registration_pin'] and b['input_pins'][2]==pin['root050_registration_pin'];assert a['input_pins'][3]['sha256']!=sha(b''.join(data.splitlines(keepends=True)[:35]))==pin['later_registration_first35_sha256'];assert b['input_pins'][2]['sha256']!=sha(b''.join(data.splitlines(keepends=True)[:139]))==pin['later_registration_first139_sha256'];assert a['input_pins'][4]['sha256']==sha(b''.join(qual.splitlines(keepends=True)[:31])) and b['input_pins'][3]['sha256']==sha(b''.join(qual.splitlines(keepends=True)[:45]))
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 data=raw(e['archive']);assert len(data)==e['bytes'] and sha(data)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;objs[oid]=(e['type'],data)
def trees(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,body=objs[tree];assert typ=='tree';mode,tree=trees(body)[name];assert mode==link['mode'] and tree==link['object']
 body=(p/x['archive']).read_bytes();body=gzip.decompress(body) if x.get('encoding')=='gzip' else body;assert sha(body)==x['sha256'] and blob(body)==x['blob']==tree
report=load('report.json');assert len(report['lens_perspectives'])==13
for item in report['reconciliation']:
 for ref in item['refs']:assert nums(ref['ranges'])<=views[ref['tag']]
ids={x['id'] for x in load('reference/BASELINE-95E-20261110.json')['newly_assessed_ledger']['entries']};assert {'SEGOVB-L12-GARMENT-PANEL-REFERENCE-PROPAGATION','REVIEW-GARMENT-FIT-PANEL-IDENTITY-95E','REVIEW-GARMENT-FIT-UNRESOLVED-STITCH-95E','REVIEW-GARMENT-FIT-EDGE-SHAPE-95E'}<=ids
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_source_entries':len(r['entries']),'historical_records':len(hist['records']),'git_membership_proofs':len(proof['proofs']),'git_objects':len(objs),'selected_059_queue_entries':2,'lens_perspectives':13,'recovered_F066':True,'registration_prefix_mismatches_retained':2,'qualification':'Read-only evidence integrity checks, not source/product/runtime validation. Prior attribution, unread complements, differing original/public member hashes, pr-working dirtiness and no 3821 promotion preserved.'},indent=2))
