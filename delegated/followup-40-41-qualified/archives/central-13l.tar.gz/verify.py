#!/usr/bin/env python3
"""Verify bounded coordinator display evidence; no product execution."""
import gzip,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def j(n):return json.loads((p/n).read_bytes())
base=j('REGISTRATION.json');sources={x['id']:x for x in base['rows']};assert len(sources)==6
for x in sources.values():
 raw=(p/x['stored_copy']).read_bytes();dec=gzip.decompress(raw) if x['id']=='rust-reference-cast' else raw
 assert H(dec)==x.get('source_sha256',x.get('decoded_sha256')) and len(dec.splitlines())==x['eof']
 if x['id']=='rust-reference-cast':assert H(raw)==x['stored_sha256']
 else:assert len(raw)==x['bytes'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==x['git_blob']
covered={k:set() for k in sources}
for regname,receiptname,displayname,kind in [('REGISTRATION.json','READ-RECEIPT.json','DISPLAY.txt','base'),('EXT-REGISTRATION.json','EXT-READ-RECEIPT.json','EXT-DISPLAY.txt','extension'),('EXT2-REGISTRATION.json','EXT2-READ-RECEIPT.json','EXT2-DISPLAY.txt','single')]:
 regraw=(p/regname).read_bytes();reg=json.loads(regraw);receipt=j(receiptname);assert receipt['registered_sha256']==H(regraw) and reg['registered_utc']<receipt['displayed_utc'];out=[]
 if kind!='base':assert reg['prior_registration_sha256']==H((p/'REGISTRATION.json').read_bytes())
 for row,read in zip(reg['rows'],receipt['rows']):
  orig=sources[row['id']];raw=(p/orig['stored_copy']).read_bytes();raw=gzip.decompress(raw) if row['id']=='rust-reference-cast' else raw;lines=raw.decode().splitlines();assert row['planned_display_ranges']==read['displayed_ranges'] and len(lines)==read['eof']
  if kind=='base':out.append('=== '+row['id']+' ===')
  elif kind=='extension':out.append('=== '+row['id']+' extension ===')
  for lo,hi in row['planned_display_ranges']:
   assert 1<=lo<=hi<=len(lines)
   for n in range(lo,hi+1):out.append(f'{n:4d} {lines[n-1]}');covered[row['id']].add(n)
 expected=('\n'.join(out)+'\n').encode();actual=(p/displayname).read_bytes();assert actual==expected and H(actual)==receipt['display_sha256'] and len(reg['rows'])==len(receipt['rows'])
a=j('ASSESSMENT.json');assert a['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and a['proposed_ledger_identity']=='local-candidate-cloth-subdivision-count-overflow'
for ref in a['source_references']:
 for lo,hi in ref['lines']:assert set(range(lo,hi+1))<=covered[ref['id']],(ref['id'],lo,hi)
assert H((p/'ASSESSMENT-REVIEWED-DRAFT.json').read_bytes())=='0ae7d19fb22cea58feede2fba20b5e4da3283fa3a63c5d85904f574c0379ed7c'
assert H((p/'ASSESSMENT-INTERIM-DRAFT.json').read_bytes())=='85e5e502fd99f448e4592d65a4c3abdf7d2f09ca1941241afa3dd68972b328cf'
assert H((p/'ASSESSMENT-REVIEWED-REVISION.json').read_bytes())=='7370c34c6e851d8ba8de247eb70aaf8412fa95cd9bb97547b5c5f709bb182052'
assert a['repair']=='not started' and a['product_validation']=='not performed'
manifest=j('MANIFEST.json');rows=manifest['files'];actual={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()}-{'MANIFEST.json'};assert actual=={x['path'] for x in rows}
for x in rows:
 raw=(p/x['path']).read_bytes();assert (H(raw),len(raw))==(x['sha256'],x['bytes'])
print('Verified six bounded source identities, all registered display transcripts, cited windows and three draft identities; Git path membership and prior attribution are separately evidenced by the cloth packet. No product ran.')
