#!/usr/bin/env python3
"""Read-only successor proof checks; no private replay or product execution."""
import collections,datetime,difflib,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).parent;e=p/'evidence';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((e/f).read_bytes());raw=lambda f:gzip.decompress((e/f).read_bytes());nums=lambda ranges:{i for a,b in ranges for i in range(a,b+1)}
manifest=json.loads((p/'PUBLIC-MANIFEST.json').read_bytes());actual={f.relative_to(p).as_posix() for f in p.rglob('*') if f.is_file() and f.relative_to(p).as_posix()!='PUBLIC-MANIFEST.json'};assert manifest['file_count']==len(manifest['files']) and actual=={x['path'] for x in manifest['files']}
for f in manifest['files']:
 b=(p/f['path']).read_bytes();assert (len(b),sha(b))==(f['bytes'],f['sha256'])
map=json.loads((p/'RECONSTRUCTION-MAP.json').read_bytes());source=(e/'BUNDLE-MANIFEST.json').read_bytes();assert sha(source)==map['original_packet_manifest_sha256']=='bc3777f49f34b53234fed5a4bc5176a87e388ed972e1196bbb4eefaeae9ac967';old=json.loads(source);oldrows={x['path']:x for x in old['files']};oldrows['BUNDLE-MANIFEST.json']={'sha256':sha(source),'bytes':len(source)};entries=map['records'];assert len(entries)==map['record_count']==154 and {x['original_path'] for x in entries}==set(oldrows) and {x['public_path'] for x in entries}=={x for x in actual if x.startswith('evidence/')};by={x['original_path']:x for x in entries};counts=collections.Counter()
def pointer(obj,path):
 for part in path.strip('/').split('/'):
  part=part.replace('~1','/').replace('~0','~');obj=obj[int(part)] if isinstance(obj,list) else obj[part]
 return obj
for x in entries:
 oldrow=oldrows[x['original_path']];assert (x['original_stored_bytes'],x['original_stored_sha256'])==(oldrow['bytes'],oldrow['sha256']);b=(p/x['public_path']).read_bytes();assert (len(b),sha(b))==(x['public_stored_bytes'],x['public_stored_sha256'])
 if not x['transformations']:assert (len(b),sha(b))==(x['original_stored_bytes'],x['original_stored_sha256'])
 for t in x['transformations']:
  kind=t['kind'];counts[kind]+=t['count'];assert t['count']>0
  if kind=='path-literal-redaction':assert b.count(t['public_marker'].encode())>=t['count'] and x['public_path'].endswith('.py.txt')
  elif kind=='json-path-redaction':assert len(t['fields'])==t['count'] and all(pointer(json.loads(b),v['pointer'])==t['public_marker'] for v in t['fields'])
  elif kind=='existing-public-variant':assert b==(e/'reference/public-prior-native-registration.json').read_bytes() and len(t['fields'])==2 and all(pointer(json.loads(b),v['pointer'])==v['public_value'] for v in t['fields'])
  elif kind=='reconstructed-gzip-transport':
   decoded=gzip.decompress(b);assert (len(decoded),sha(decoded),blob(decoded))==(t['public_decoded_bytes'],t['public_decoded_sha256'],t['public_decoded_git_blob']);v=json.loads(decoded);assert len(t['fields'])==t['count'] and all(pointer(v,k['pointer'])==t['public_marker'] for k in t['fields'])
  else:raise AssertionError('unknown public reconstruction')
assert counts=={'path-literal-redaction':5,'json-path-redaction':14,'existing-public-variant':2,'reconstructed-gzip-transport':26}
for path in ('reference/ledger.json.gz','reference/queue.json.gz'):
 t=by[path]['transformations'][0];x=next(r for r in load('reference-index.json')['records'] if r['file']==path);assert (t['original_decoded_sha256'],t['original_decoded_bytes'])==(x['sha256'],x['bytes'])
for n in ('reference-index.json','rules.json','skills.json'):
 for x in load(n)['records']:
  b=(e/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b
  if x['file'] in ('reference/ledger.json.gz','reference/queue.json.gz'):continue
  assert sha(b)==x['sha256'] and ('bytes' not in x or len(b)==x['bytes'])
registry=raw('reference/registry.json.gz');assert sha(registry)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(registry);selected=load('registry-selection-reconstructed.json');assert selected['registry_sha256']==sha(registry)
for i in (2632,2635,2636):assert reg['files'][i]==selected['roles'][str(i)] and reg['files'][i]['snapshot']=='pr-working'
r=load('registration.json');v=load('read-receipt.json');assert v['registration_sha256']==sha((e/'registration.json').read_bytes()) and len(r['entries'])==len(v['entries'])==16 and datetime.datetime.fromisoformat(v['recorded_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);views={};native=[]
for a,b in zip(r['entries'],v['entries']):
 data=(e/a['archive']).read_bytes();assert a['tag']==b['tag'] and sha(data)==a['sha256']==b['sha256'] and len(data.splitlines())==a['EOF'];seen=nums(b['displayed_chunks']);unseen=nums(b['unread_complement']);assert seen==nums(a['registered_ranges']) and seen|unseen==set(range(1,a['EOF']+1)) and not seen&unseen;views[a['tag']]=seen
 if a['kind']=='native-support':native.append(a)
 else:assert blob(data)==a['git_blob']
 if a['kind']=='historical-pr-working':assert a['sha256']==reg['files'][a['role']]['sha256']
 if a['kind']=='lock-support':
  package=[q for q in tomllib.loads(data.decode())['package'] if q['name']=='wgpu-types' and q['version']=='29.0.4'];assert len(package)==1 and package[0]==a['lock_package'] and package[0]['checksum']=='84bf84cd9ca8ca45e2b223a3868f1adf9bfc0c66aeac212e76ee7e40fdadf8f5'
for a in native:
 crate=(e/a['package_archive']).read_bytes();assert sha(crate)==a['package_sha256']=='84bf84cd9ca8ca45e2b223a3868f1adf9bfc0c66aeac212e76ee7e40fdadf8f5'
 with tarfile.open(fileobj=io.BytesIO(crate),mode='r:gz') as tar:assert tar.extractfile(a['member']).read()==(e/a['archive']).read_bytes()
for i in (2632,2636):assert (e/f'source/pr-working-{i}.rs').read_bytes()==(e/f'source/current-{i}.rs').read_bytes()
a=(e/'source/pr-working-2635.rs').read_text().splitlines(keepends=True);b=(e/'source/current-2635.rs').read_text().splitlines(keepends=True);assert a!=b and (e/'source-diff-2635.diff').read_text()==''.join(difflib.unified_diff(a,b,fromfile='registered-pr-working',tofile='pinned-95e'))
q=json.loads(raw('reference/queue.json.gz'));l=json.loads(raw('reference/ledger.json.gz'));s=load('059-selection-reconstructed.json');assert s['queue_source_sha256']==by['reference/queue.json.gz']['transformations'][0]['original_decoded_sha256'] and s['ledger_source_sha256']==by['reference/ledger.json.gz']['transformations'][0]['original_decoded_sha256']
for k,value in s['entries'].items():assert q['entries'][int(k)]==value
for path,value in s['journal_entries'].items():assert pointer(l,path)==value
assert q['entries'][370]['contract_id']=='SEGOVB-L12-GPU-REFLECTION-SPARSE-GROUP-LAYOUT-POSITION' and q['entries'][151]['contract_id']=='ADLER-L11-UNIFORM-ABI-ADMISSION'
tm=raw('reference/original-transport-manifest.json.gz');idx={x['path']:x for x in json.loads(tm)['entries']};hist=load('historical-index.json');assert len(hist['records'])==34 and not hist['unavailable_requested_records']
for x in hist['records']:
 b=(e/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':assert (idx[x['transport_path']]['bytes'],idx[x['transport_path']]['sha256'],idx[x['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for name,role,n,rs in [('READ-L11-430.json',2632,1548,[[1,135]]),('READ-L11-431.json',2635,1551,[[1,88]]),('READ-L11-431.json',2636,1552,[[1,209]])]:
 read=load('history-059/segovb/'+name);x=next(t for t in read['sources'] if t['original_index']==role);assert x['fresh_personal_body_reads']==rs and x['sha256']==reg['files'][role]['sha256'] and x['registration_sha256']==sha((e/f'history-059/segovb/REGISTRATION-SEGOVB-{n}.json').read_bytes())
a=load('history-059/segovb/READ-L12-905.json');b=load('history-059/segovb/READ-L12-907.json');c=load('history-059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-749-SHADER-REFLECTION.json');assert a['root_personal_rereads']==b['root_personal_rereads']==[] and a['new_original_roles']==1 and b['new_original_roles']==2
z=next(x for x in a['rows'] if x['original_index']==2632);assert z['fresh_personal_body_reads']==[[1,135]] and '/root/lens12_frontier' in z['attribution']
for role,rs in [(2635,[[1,88]]),(2636,[[1,209]])]:
 x=next(y for y in b['rows'] if y['original_index']==role);y=next(y for y in c['rows'] if y['original_index']==role);assert x['fresh_personal_body_reads']==[] and x['new_original_credit']==0 and y['fresh_personal_body_reads']==rs and '/root/lens12_frontier' in y['attribution'] and x['registration_sha256']==y['registration_sha256']==sha((e/'history-059'/y['registration']).read_bytes())
for doc in (a,b):assert doc['proposal_sha256']==sha((e/'history-059'/doc['proposal']).read_bytes())
prior=load('prior-index.json');prior_manifest=(e/'prior/MANIFEST.json').read_bytes();assert sha(prior_manifest)==prior['original_manifest_sha256']=='97d297a4a7e74ce0a7f8a4192270d53c07fd91935cfdbd852e131e9d9bec35f9';pm={x['path']:x for x in json.loads(prior_manifest)['files']}
for x in prior['selected_files']:
 d=(e/'prior'/x['path']).read_bytes();assert (x['bytes'],x['sha256'])==(pm[x['path']]['bytes'],pm[x['path']]['sha256'])
 if x['path']=='native-registration.json':assert by['prior/'+x['path']]['original_stored_sha256']==x['sha256'] and d==(e/'reference/public-prior-native-registration.json').read_bytes()
 else:assert (len(d),sha(d))==(x['bytes'],x['sha256'])
entry=next(x for x in load('reference/checkpoint18-index.json')['bundles'] if x['bundle_id']=='gpu-reflection');assert entry['archive_sha256']==prior['published_archive_sha256']=='b9609aed246489680db840971d8b8d49557b161bb003b749fd44b0136b350840'
for x in prior['published_members']:
 y=next(y for y in entry['members'] if y['path']==x['path']);assert (x['original_sha256'],x['published_sha256'],x['changed'])==(y['original_sha256'],y['published_sha256'],y['changed']) and sha((e/x['file']).read_bytes())==x['published_sha256']
 if x['path']=='native-registration.json':assert by['prior/'+x['path']]['original_stored_sha256']==x['original_sha256'] and sha((e/'prior'/x['path']).read_bytes())==x['published_sha256']
 else:assert sha((e/'prior'/x['path']).read_bytes())==x['original_sha256']
base='history-774/continuation/rig/admission03/';rr=raw(base+'source-range-registration.jsonl.gz').splitlines();adds=raw(base+'additional-contracts.jsonl.gz').splitlines();finds=raw(base+'findings.jsonl.gz').splitlines()
for role,n in [(2632,87),(2635,90),(2636,91)]:assert json.loads(rr[n-1])==reg['files'][role]['admission03_scope_observations'][0]['original_record']
assert [json.loads(adds[i-1])['id'] for i in (73,76,77)]==['RIG-ADMISSION03-ADDITIONAL-087','RIG-ADMISSION03-ADDITIONAL-090','RIG-ADMISSION03-ADDITIONAL-091'] and [json.loads(finds[i-1])['id'] for i in (60,61)]==['RIG-ADMISSION03-F057','RIG-ADMISSION03-F058']
pin=hist['rig_registration_pin_qualification'];first=json.loads(raw('history-774/continuation/root/admission03-scope-reconciliation-046.json.gz'));last=json.loads(raw('history-774/continuation/root/admission03-scope-reconciliation-050.json.gz'));regdata=raw(base+'source-range-registration.jsonl.gz');qual=raw(base+'source-qualifications.jsonl.gz');assert first['input_pins'][3]==pin['root046_registration_pin'] and last['input_pins'][2]==pin['root050_registration_pin'];assert first['input_pins'][3]['sha256']!=sha(b''.join(regdata.splitlines(keepends=True)[:35]))==pin['later_registration_first35_sha256'] and last['input_pins'][2]['sha256']!=sha(b''.join(regdata.splitlines(keepends=True)[:139]))==pin['later_registration_first139_sha256'];assert first['input_pins'][4]['sha256']==sha(b''.join(qual.splitlines(keepends=True)[:31])) and last['input_pins'][3]['sha256']==sha(b''.join(qual.splitlines(keepends=True)[:45]))
proof=load('git-proofs.json');objs={}
for oid,x in proof['objects'].items():
 data=raw(x['archive']);assert (len(data),sha(data))==(x['bytes'],x['sha256']) and hashlib.sha1(x['type'].encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;objs[oid]=(x['type'],data)
def trees(data):
 out={};i=0
 while i<len(data):
  s=data.index(b' ',i);z=data.index(b'\0',s);out[data[s+1:z].decode()]=(data[i:s].decode(),data[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,commit=objs[x['revision']];assert typ=='commit';tree=commit.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'] and len(x['chain'])==len(x['path'].split('/'))
 for name,link in zip(x['path'].split('/'),x['chain']):
  assert link['tree']==tree and link['name']==name;typ,body=objs[tree];assert typ=='tree';mode,tree=trees(body)[name];assert mode==link['mode'] and tree==link['object']
 body=(e/x['archive']).read_bytes();body=gzip.decompress(body) if x.get('encoding')=='gzip' else body;assert sha(body)==x['sha256'] and blob(body)==x['blob']==tree
report=load('report.json');assert len(report['lens_perspectives'])==13 and len(proof['objects'])==36 and len(proof['proofs'])==24
for item in report['reconciliation']:
 for ref in item['refs']:assert nums(ref['ranges'])<=views[ref['tag']]
correction=json.loads((p/'PUBLIC-REPORT.json').read_bytes())['registration_wording_correction'];assert len(correction['affected_tags'])==4 and all('role2632 only 1–135' in next(x for x in r['entries'] if x['tag']==tag)['qualification'] for tag in correction['affected_tags'])
scan=json.loads((p/'PUBLIC-PRIVACY-SCAN.json').read_bytes());assert not scan['exceptions'] and len(scan['hits'])==7 and all(x['type']=='windows-drive' and x['view']=='gzip-stored-binary' for x in scan['hits'])
def omitted(node):
 counts=collections.Counter()
 def visit(x):
  if isinstance(x,dict):
   assert not ({'original_value_sha256','public_value_sha256','matched_prefix_sha256'} & x.keys())
   for key,value in x.items():
    if key in ('original_value_digest_omitted_count','public_value_digest_omitted_count'):counts[key+'_fields']+=1;counts[key+'_values']+=value
    elif key=='matched_prefix_digest_omitted':assert value is True;counts[key]+=1
    else:visit(value)
  elif isinstance(x,list):
   for value in x:visit(value)
 visit(node);return counts
omap=omitted(map);assert omap['original_value_digest_omitted_count_fields']==45 and omap['original_value_digest_omitted_count_values']==47 and omap['public_value_digest_omitted_count_fields']==2 and omap['public_value_digest_omitted_count_values']==2
assert omitted(json.loads((p/'ORIGINAL-PRIVACY-SCAN.json').read_bytes()))['matched_prefix_digest_omitted']==53
assert omitted(json.loads((p/'PUBLIC-PRIVACY-SCAN.json').read_bytes()))['matched_prefix_digest_omitted']==7
print('PASS: successor public file identities, markers and bounded source evidence; individual digests omitted. Exact original-to-public replay requires separate private inputs. No product execution.')
