# GPU reflection evidence transport

This is a privacy-aware representation of the frozen evidence for original
roles 2632, 2635 and 2636. `PUBLIC-REPORT.json` records the historical and pinned
current revisions, personally displayed ranges, previously attributed reviews,
conditional findings, open questions and the registration wording correction.
The full assessment and its thirteen bounded lens perspectives are retained in
`evidence/report.json`.

`RECONSTRUCTION-MAP.json` maps all 154 frozen packet files to their public
representations and records original and public hashes. Five local path
literals in script source, 14 skill source paths, two prior registration
values, and 26 local paths in the decoded 059 baseline representations were
redacted. The two 059 records remain reconstructed historical evidence, not
checkpoint 3821 originals. The earlier public prior registration variant was
reused exactly. Gzip stored, decoded and reconstructed identities remain
separate. Other native archives, historical records, source and Git proof
objects were copied without changing their bytes.

The original manifest inside `evidence/` binds the original private packet; it
is retained as a historical identity claim, not a manifest for the public
reconstructions. All historical Python files are `.py.txt` source only. Exact
originals, including private paths, are held in a separate local-only capture.

Run `python3 verify-public-successor.py` for read-only verification of this transport,
source scopes, 059 and 774 provenance, selected native and lock identities,
Git objects and tree proofs. It checks evidence integrity, not runtime behavior
or complete audit coverage. `ORIGINAL-PRIVACY-SCAN.json` and the public scan
record their path-pattern and archive-format limits; they do not constitute a
general privacy or secret clearance.

The successor omits individual redacted-value and scan-prefix digests. Full
file and representation identities, field pointers, counts and source
attributions remain. Exact replay requires the separately retained private
originals; the public verifier does not perform or claim that replay.
