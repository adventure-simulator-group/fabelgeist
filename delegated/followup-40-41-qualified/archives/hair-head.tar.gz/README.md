# Hair head and haircut evidence transport

This transport preserves the frozen source packet for original roles 2637 and
2638. It includes the exact historical 774 rig F067 record, the separate older
059 reviewer scopes, the current bounded read receipts, safeguards, candidate
conditions, open questions, and thirteen partial lens perspectives. Source
revisions and historical attribution are unchanged; no alias or defect count
is decided here.

The original source manifest binds 91 members, plus the original manifest
itself. Five members have reconstructed public bytes containing 49 local-path
redactions. `EVIDENCE-IDENTITIES.json` records original and public hashes, stored
and decoded lengths, and redaction offsets. Exact originals of all 92 members
are held in a separate restricted collection. The original manifests are
historical identity records; their old hash assertions do not describe the
redacted public bytes. The original source scripts are retained as evidence and
may not reproduce from the public variants.

The 059 committed queue and the observed staged queue have different full
original identities and are preserved as separate artifacts. Only the committed
public queue was reconstructed for paths. The selected five historical rows
match; their extracted selection is reconstructed. No checkpoint 3821 ledger or
queue is supplied, and the historical pr-working snapshot had unrelated changes.

Three exact Git commit objects are isolated under `proof-metadata/` and retain
author and committer metadata, including email-like identifiers. They are
necessary for the retained Git membership proofs and have previously recorded
same-machine indexed public counterparts. Their separate disclosure and the
limits of that earlier remote-tracking observation are documented in
`GIT-COMMIT-METADATA.json`; no live remote was checked here.

Run `python3 -B verify-stage.py` for read-only public evidence verification.
`--private-root DIRECTORY` also compares all restricted original members and
replays each redaction against original bytes. `--source-root DIRECTORY` can
additionally compare the frozen source packet. These checks do not execute the
original packet verifiers or product code. The bounded privacy scan covers the
observed gzip contents, Git tree names, escaped slashes, escaped-newline paths,
and listed credential patterns; it cannot establish absence of every possible
sensitive encoding or personal datum.
