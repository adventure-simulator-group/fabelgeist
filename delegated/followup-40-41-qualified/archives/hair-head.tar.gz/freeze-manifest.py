#!/usr/bin/env python3
"""Freeze the public transport once; do not regenerate after publication."""
import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).resolve().parent;m=p/'MANIFEST.json'
if m.exists():raise SystemExit('already frozen')
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f!=m:
  b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
value={'schema':'726-hair-head-public-transport-manifest-v1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/hair_ops','files':files,'qualification':'All public members, including original and prior historical manifest copies; this top manifest is hashed externally.'}
m.write_text(json.dumps(value,indent=2)+'\n');print('manifest members',len(files),'sha256',hashlib.sha256(m.read_bytes()).hexdigest())
