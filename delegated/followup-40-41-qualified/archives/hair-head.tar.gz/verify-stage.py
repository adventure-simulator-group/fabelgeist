#!/usr/bin/env python3
"""Read-only crosswalk, Git membership, historical and bounded privacy checks."""
import argparse,gzip,hashlib,json,os,pathlib,re,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
def req(ok,msg):
 if not ok:raise ValueError(msg)
def read(base,rel):
 p=base
 for x in pathlib.PurePosixPath(rel).parts:
  req(x not in ('.','..','/'),'invalid relative path');p=p/x;req(not p.is_symlink(),'symlink')
 return p.read_bytes()
def inventory(base):
 out=set()
 for root,dirs,files in os.walk(base,followlinks=False):
  for x in dirs+files:req(not (pathlib.Path(root)/x).is_symlink(),'symbolic link')
  for x in files:out.add((pathlib.Path(root)/x).relative_to(base).as_posix())
 return out
def data(raw,enc):
 if enc=='gzip':
  req(raw[:2]==b'\x1f\x8b' and raw[3]==0,'gzip header flags or magic');b=gzip.decompress(raw)
  req(len(b)<=128*1024*1024 and not b.startswith(b'\x1f\x8b') and not (len(b)>262 and b[257:262]==b'ustar'),'nested archive or decode limit');return b
 req(enc=='identity','encoding');return raw
def tree_entries(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j+1);req(k+21<=len(b),'truncated tree');name=b[j+1:k].decode('utf8');req(name not in d,'duplicate tree name');d[name]=(b[i:j].decode('ascii'),b[k+1:k+21].hex());i=k+21
 return d
def git_hash(kind,b):return hashlib.sha1((kind+' '+str(len(b))+'\0').encode()+b).hexdigest()
SLASH=b'/';AGENTS={SLASH+b'root/'+v.encode() for v in ('hair_ops','rig_identity','mhr_character','camera_targeting','rig_garments','native_reports','lens12_frontier','segovb','handoff_portability_review','root')}
PATH=re.compile(rb'(?:(?<![A-Za-z0-9_/])|\\[nrt])('+SLASH+rb'(?:home|users|tmp|root|mnt|workspace|workspaces|private|var/(?:tmp|folders))/[^\s"\x27<>\x00\\]+|[A-Za-z]:[\\/]+(?:Users|Documents and Settings)[\\/]+[^\s"\x27<>\x00]+)',re.I)
SECRET=re.compile(rb'gh[pousr]_[A-Za-z0-9_]{25,}|github_pat_[A-Za-z0-9_]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}|-----BEGIN (?:RSA |DSA |OPENSSH |EC |ENCRYPTED )?PRIVATE KEY-----|AKIA[0-9A-Z]{16}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|AIza[0-9A-Za-z_-]{35}|glpat-[0-9A-Za-z_-]{20,}|npm_[0-9A-Za-z]{30,}|eyJ[A-Za-z0-9_-]{18,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}|(?:Bearer\s+)[A-Za-z0-9._~+/-]{24,}',re.I)
EMAIL=re.compile(rb'(?<![\w.+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w.-])');ESC=re.compile(rb'\\/|\\u002[fF]')
def privacy(b):
 n=ESC.sub(SLASH,b);agents=0
 for m in PATH.finditer(n):
  if m.group(1).rstrip(b'.,;:!?`') in AGENTS:agents+=1
  else:raise ValueError('public privacy path candidate')
 req(not SECRET.search(n),'public credential pattern candidate');return agents

def complement(eof,rr):
 out=[];pos=1
 for a,b in sorted(rr):
  req(1<=a<=b<=eof,'source range');
  if pos<a:out.append([pos,a-1])
  pos=max(pos,b+1)
 if pos<=eof:out.append([pos,eof])
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private-root',type=pathlib.Path);ap.add_argument('--source-root',type=pathlib.Path);args=ap.parse_args()
 m=json.loads(read(P,'MANIFEST.json'));public={x['path']:x for x in m['files']};actual=inventory(P)-{'MANIFEST.json'}
 req(len(public)==len(m['files']) and set(public)==actual,'public manifest membership')
 for name,v in public.items():
  b=read(P,name);req((H(b),len(b))==(v['sha256'],v['bytes']),'public manifest bytes')
 idx=json.loads(read(P,'EVIDENCE-IDENTITIES.json'));rows=idx['members'];lookup={r['source_path']:r for r in rows};req(len(rows)==len(lookup)==92,'source count')
 source_manifest=read(P,lookup['MANIFEST.json']['public_path']);req(H(source_manifest)==idx['source_packet_manifest_sha256']=='cdcb9dbd3169abe0445d76faab9459959da57cca828f68d937d910d4d453ff3a','source manifest identity')
 source=json.loads(source_manifest);original={r['path']:r for r in source['files']};req(len(original)==91 and set(lookup)==set(original)|{'MANIFEST.json'},'source membership')
 private={}
 if args.private_root:
  b=read(args.private_root,'PRIVATE-ORIGINAL-MANIFEST.json');req(H(b)==idx['private_original_manifest_sha256'],'private manifest identity');private={r['source_path']:r for r in json.loads(b)['members']};req(set(private)==set(lookup),'private members')
  req(args.private_root.stat().st_mode & 0o077==0,'private root is not restricted')
 if args.source_root:req(inventory(args.source_root)==set(lookup),'source packet membership changed')
 redacts=changed=agents=commits=gitobjects=0
 for rel,r in lookup.items():
  if rel!='MANIFEST.json':req((r['original_stored_sha256'],r['original_stored_bytes'])==(original[rel]['sha256'],original[rel]['bytes']) and r['source_manifest_bound'],'original manifest binding')
  else:req(r['source_top_manifest'] and not r['source_manifest_bound'],'original top manifest classification')
  raw=read(P,r['public_path']);plain=data(raw,r['encoding']);req((H(raw),len(raw),H(plain),len(plain))==(r['public_stored_sha256'],r['public_stored_bytes'],r['public_decoded_sha256'],r['public_decoded_bytes']),'public member identity')
  if rel.endswith('.json') and r['encoding']=='identity':json.loads(plain)
  if rel.endswith('.json.gz'):json.loads(plain)
  is_tree=rel.startswith('git-objects/') and rel.endswith('.tree.gz');is_commit=rel.startswith('git-objects/') and rel.endswith('.commit.gz')
  if is_tree:agents+=privacy(b'\n'.join(k.encode('utf8') for k in tree_entries(plain)))
  else:agents+=privacy(plain)
  ops=r['redactions'];redacts+=len(ops)
  if ops:
   changed+=1;req(r['status']=='privacy-reconstructed','reconstruction status')
   for op in ops:
    z=op['public_decoded_offset_0based'];token=op['public_placeholder'].encode();req(plain[z:z+len(token)]==token,'placeholder mismatch')
  else:req(r['status']=='exact-copy' and r['original_stored_sha256']==r['public_stored_sha256'] and r['original_decoded_sha256']==r['public_decoded_sha256'],'exact identity mismatch')
  if args.private_root:
   pr=private[rel];old=read(args.private_root,pr['restricted_path']);req((H(old),len(old))==(r['original_stored_sha256'],r['original_stored_bytes'])==(pr['sha256'],pr['bytes']),'private original mismatch')
   oldplain=data(old,r['encoding']);req((H(oldplain),len(oldplain))==(r['original_decoded_sha256'],r['original_decoded_bytes']),'private decoded mismatch')
   for op in sorted(ops,key=lambda x:x['original_decoded_offset_0based'],reverse=True):
    z=op['original_decoded_offset_0based'];n=op['original_decoded_bytes'];oldplain=oldplain[:z]+op['public_placeholder'].encode()+oldplain[z+n:]
   req(oldplain==plain,'redaction reconstruction mismatch')
  if args.source_root:
   b=read(args.source_root,rel);req((H(b),len(b))==(r['original_stored_sha256'],r['original_stored_bytes']),'frozen packet drift')
  if is_tree or is_commit:
   oid,kind,_=pathlib.PurePosixPath(rel).name.split('.');req(git_hash(kind,plain)==oid and not ops,'Git object identity');gitobjects+=1
   if is_commit:req(r['public_path']=='proof-metadata/'+rel and len(EMAIL.findall(plain))==2,'commit disclosure or identity count');commits+=1
 req((changed,redacts,gitobjects,commits)==(5,49,30,3),'transport scope')
 def source_read(rel):
  r=lookup[rel];return data(read(P,r['public_path']),r['encoding'])
 # Validate the complete original Git chain using separately located commits.
 proof=json.loads(source_read('git-proofs.json'));objects={}
 for oid,meta in proof['objects'].items():
  raw=source_read(meta['file']);req((len(raw),H(raw),git_hash(meta['type'],raw))==(meta['bytes'],meta['sha256'],oid),'object proof');objects[oid]=(meta['type'],raw)
 req(len(objects)==30 and len(proof['proofs'])==19,'proof inventory')
 for x in proof['proofs']:
  typ,commit=objects[x['revision']];req(typ=='commit','commit object');current=commit.split(b'\n',1)[0].decode().split(' ')[1];req([z['name'] for z in x['chain']]==x['path'].split('/'),'source path')
  for z in x['chain']:
   req(z['tree']==current and objects[current][0]=='tree','tree continuity');mode,child=tree_entries(objects[current][1])[z['name']];req((mode,child)==(z['mode'],z['object']),'tree edge');current=child
  raw=source_read(x['local']);req(H(raw)==x['sha256'] and git_hash('blob',raw)==x['blob']==current,'leaf membership')
 # Source read scopes remain separate; every displayed interval was registered.
 reg=json.loads(source_read('registration.json'));tie=json.loads(source_read('support-registration-tied.json'));receipt=json.loads(source_read('read-receipt.json'))
 plans={x['source_file']:x for x in reg['sources'] if x['kind']!='historical-evidence-only'}
 plans.update({x['local']:x for x in tie['rows']});req(len(plans)==len(receipt['source_displays'])==14,'receipt count')
 for x in receipt['source_displays']:
  p=plans[x['local']];raw=source_read(x['local']);req(H(raw)==x['sha256']==p['sha256'] and len(raw.splitlines())==x['EOF'],'source read identity');req(x['displayed_ranges']==p['registered_ranges'] and x['unread_complement']==complement(x['EOF'],x['displayed_ranges']),'registered read scope')
 for old,new in [('source/2637-pr-working.rs','source/2637-current-95e.rs'),('source/2638-pr-working.rs','source/2638-current-95e.rs')]:req(source_read(old)==source_read(new),'role byte equality')
 # Original 774 registry and exact F067, 059 records and dual queue snapshots.
 registry=json.loads(source_read('historical/original-registry.json.gz'))
 for i,name,ranges in [(2637,'source/2637-pr-working.rs',[[1,283]]),(2638,'source/2638-pr-working.rs',[[1,373]])]:
  v=registry['files'][i];req(v['snapshot']=='pr-working' and v['sha256']==H(source_read(name)) and v['material_ranges']==ranges,'historical registry role')
 stream=source_read('historical/774-rig-findings.jsonl.gz');line=stream.splitlines()[71];hist=json.loads(read(P,'HISTORICAL-RELATIONSHIPS.json'));f=hist['f067'];req(line==read(P,f['standalone_exact_line']) and H(line)==f['line_sha256_without_terminator']=='67ca7b87e5d258a9b891db17e61dd8659c7ef3b7cc7547f99f996af38b52e43a' and json.loads(line)['id']==f['id']=='RIG-ADMISSION03-F067','historical F067')
 queue0=json.loads(source_read('historical/baseline-059-queue-committed-2e1f.json.gz'));queue1=json.loads(source_read('historical/baseline-059-queue.json.gz'));selected=json.loads(source_read('historical/059-selected-records-reconstructed.json'))
 req(selected['queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08','historical queue identity')
 req([v['index'] for v in selected['queue_rows']]==[164,379,381,619,1839],'selected queue rows')
 for v in selected['queue_rows']:req(queue0['entries'][v['index']]==queue1['entries'][v['index']]==v['entry'],'selected historical row mismatch')
 req(queue0['entries'][1837]==queue1['entries'][1837],'q1837 discrepancy')
 q0=lookup['historical/baseline-059-queue-committed-2e1f.json.gz'];q1=lookup['historical/baseline-059-queue.json.gz']
 req(q0['original_decoded_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and q0['original_decoded_sha256']!=q0['public_decoded_sha256'] and q1['original_decoded_sha256']==q1['public_decoded_sha256']=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173','queue identities')
 baseline=json.loads(source_read('reference/observed-current-baseline.json.gz'));entries=baseline['newly_assessed_ledger']['entries']
 for i,id in [(57,'REVIEW-HAIR-SHAPE-KNOBS-NAN-001'),(634,'REVIEW-HAIR-GUIDE-MAX-PATH-95E'),(636,'REVIEW-HAIR-TIED-AXIS-PROGRESS-95E'),(644,'SEGOVB-L12-CONNECTED-HAIR-CURVE-RESAMPLE-INPUT-EXTENT-ADMISSION')]:req(entries[i]['id']==id,'baseline current entry')
 prior=json.loads(source_read('reference/prior-MANIFEST.json'));prior_idx={r['path']:r for r in prior['files']}
 for old,new in [('REPORT.json','reference/prior-REPORT.json'),('read-receipt.json','reference/prior-read-receipt.json'),('registration.json','reference/prior-registration.json'),('historical-manifest.json','reference/prior-historical-manifest.json'),('git-proofs.json','reference/prior-git-proofs.json')]:req(lookup[new]['original_stored_sha256']==prior_idx[old]['sha256'],'prior manifest original binding')
 prior_hist=json.loads(source_read('reference/prior-historical-manifest.json'))
 for v in prior_hist['exact_original_files']:req(H(source_read(v['local']))==v['sha256'],'prior original 059 receipt')
 disclosure=json.loads(read(P,'GIT-COMMIT-METADATA.json'));req(len(disclosure['members'])==3,'commit disclosure')
 for v in disclosure['members']:
  r=lookup[v['original_path']];req(v['public_path']==r['public_path'] and v['stored_sha256']==r['original_stored_sha256']==r['public_stored_sha256'],'commit counterpart binding')
 req(disclosure['prior_counterpart']['archive_sha256']=='cc7d67d4c70af804c9a260ced01488914825182046e46aa6125bde5392b27611','prior archive qualification')
 # Scan generated metadata and this verifier too; original scripts are only text.
 for name in actual|{'MANIFEST.json'}:
  if name in {v['public_path'] for v in rows}:continue
  b=read(P,name);agents+=privacy(b)
 print(json.dumps({'status':'pass','public_members':len(actual),'source_members':len(rows),'private_originals_verified':len(private),'source_members_verified':len(rows) if args.source_root else 0,'reconstructed_members':changed,'path_redactions':redacts,'git_objects':gitobjects,'git_proofs':len(proof['proofs']),'disclosed_commits':commits,'f067_original_line_sha256':H(line),'agent_identifier_occurrences':agents,'qualification':'Evidence and bounded privacy checks only. Commit metadata remains separately disclosed; no remote, product, validation, repair, alias or checkpoint3821 conclusion.'},indent=2))
if __name__=='__main__':
 try:main()
 except Exception as exc:print('verification failed:',str(exc),file=sys.stderr);sys.exit(1)
