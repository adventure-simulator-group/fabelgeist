#!/usr/bin/env python3
"""Read-only verification of frozen packet identities and bounded receipts."""
import gzip,hashlib,json,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda f:json.loads((P/f).read_bytes())

def ensure(cond,message):
    if not cond:raise ValueError(message)

def complement(n,ranges):
    out=[];pos=1
    for a,b in sorted(ranges):
        ensure(1<=a<=b<=n,'range out of bounds')
        if pos<a:out.append([pos,a-1])
        pos=max(pos,b+1)
    if pos<=n:out.append([pos,n])
    return out

def tree_entries(b):
    d={}; i=0
    while i<len(b):
        j=b.index(b' ',i); k=b.index(b'\0',j+1)
        name=b[j+1:k].decode('utf-8'); ensure(name not in d,'duplicate tree name')
        ensure(k+21<=len(b),'truncated tree'); d[name]=(b[i:j].decode('ascii'),b[k+1:k+21].hex());i=k+21
    return d

def main():
    manifest=load('MANIFEST.json');listed={x['path']:x for x in manifest['files']}
    actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'}
    ensure(len(listed)==len(manifest['files']),'duplicate manifest path');ensure(set(listed)==actual,'manifest membership mismatch')
    for path,meta in listed.items():
        b=(P/path).read_bytes();ensure(len(b)==meta['bytes'] and sha(b)==meta['sha256'],'manifest member mismatch '+path)
    reg=load('registration.json'); extra=load('support-registration-tied.json'); histreg=load('historical-registration-774.json');receipt=load('read-receipt.json')
    for r in receipt['registrations']: ensure(sha((P/r['path']).read_bytes())==r['sha256'],'registration binding')
    planned={s['source_file']:s for s in reg['sources'] if s['kind']!='historical-evidence-only'}
    for r in extra['rows']:planned[r['local']]=r
    ensure(len(planned)==len(receipt['source_displays'])==14,'source receipt count')
    for r in receipt['source_displays']:
        s=planned[r['local']];b=(P/r['local']).read_bytes(); ensure(sha(b)==r['sha256']==s['sha256'],'source sha mismatch')
        ensure(len(b.splitlines())==r['EOF'],'source line count mismatch');ensure(r['displayed_ranges']==s['registered_ranges'],'display registration mismatch')
        ensure(r['unread_complement']==complement(r['EOF'],r['displayed_ranges']),'source unread complement mismatch')
    ensure((P/'source/2637-pr-working.rs').read_bytes()==(P/'source/2637-current-95e.rs').read_bytes(),'head old/current differ')
    ensure((P/'source/2638-pr-working.rs').read_bytes()==(P/'source/2638-current-95e.rs').read_bytes(),'haircut old/current differ')
    tree=load('git-proofs.json');objs={}
    for oid,meta in tree['objects'].items():
        raw=gzip.decompress((P/meta['file']).read_bytes());typ=meta['type']
        ensure(len(raw)==meta['bytes'] and sha(raw)==meta['sha256'],'object body mismatch')
        ensure(hashlib.sha1((typ+' '+str(len(raw))+'\0').encode()+raw).hexdigest()==oid,'git object id mismatch')
        objs[oid]=(typ,raw)
    ensure(sum(v[0]=='commit' for v in objs.values())==3 and len(tree['proofs'])==19,'proof count')
    for proof in tree['proofs']:
        typ,commit=objs[proof['revision']]; ensure(typ=='commit','not commit')
        top=commit.split(b'\n',1)[0].decode().split(' ')[1];expected=top
        names=proof['path'].split('/');ensure(names==[c['name'] for c in proof['chain']],'path chain mismatch')
        for c in proof['chain']:
            ensure(c['tree']==expected,'chain continuity');kind,raw=objs[expected];ensure(kind=='tree','tree object type')
            mode,nextid=tree_entries(raw)[c['name']];ensure((mode,nextid)==(c['mode'],c['object']),'tree entry mismatch');expected=nextid
        local=(P/proof['local']).read_bytes()
        if proof['compression']=='gzip':local=gzip.decompress(local)
        blob=hashlib.sha1(b'blob '+str(len(local)).encode()+b'\0'+local).hexdigest()
        ensure(blob==proof['blob']==expected and sha(local)==proof['sha256'],'leaf mismatch')
    h=load('historical-identity.json'); decoded={}
    for k,v in h.items():
        stored=(P/v['path']).read_bytes(); raw=gzip.decompress(stored)
        ensure(sha(stored)==v['stored_sha256'] and sha(raw)==v['decoded_sha256'],'historical identity mismatch '+k)
        decoded[k]=json.loads(raw)
    registry=decoded['original_registry']
    for role,fn,rg in [(2637,'source/2637-pr-working.rs',[[1,283]]),(2638,'source/2638-pr-working.rs',[[1,373]])]:
        item=registry['files'][role];ensure(item['sha256']==sha((P/fn).read_bytes()) and item['snapshot']=='pr-working' and item['material_ranges']==rg,'registry role mismatch')
    selection=load('historical/059-selected-records-reconstructed.json')
    ensure(selection['queue_sha256']==h['recovered_committed_059_queue']['decoded_sha256'],'original selection provenance mismatch')
    for row in selection['queue_rows']:
        for key in ('observed_staged_queue','recovered_committed_059_queue'):
            ensure(decoded[key]['entries'][row['index']]==row['entry'],'queue selected entry mismatch')
    for rec in load('reference/prior-historical-manifest.json')['exact_original_files']:
        b=(P/rec['local']).read_bytes();ensure(len(b)==rec['bytes'] and sha(b)==rec['sha256'],'059 receipt mismatch')
    prior=load('reference/prior-MANIFEST.json');prior_index={i['path']:i for i in prior['files']}
    for old,new in [('REPORT.json','reference/prior-REPORT.json'),('read-receipt.json','reference/prior-read-receipt.json'),('registration.json','reference/prior-registration.json'),('historical-manifest.json','reference/prior-historical-manifest.json'),('git-proofs.json','reference/prior-git-proofs.json')]:
        b=(P/new).read_bytes();ensure(len(b)==prior_index[old]['bytes'] and sha(b)==prior_index[old]['sha256'],'prior manifest binding mismatch')
    ensure(sha((P/'reference/prior-MANIFEST.json').read_bytes())=='e91a5be07dcdeb3427654593a0ee64e73f9b15b6730475ef941d733f7f1968fe','prior manifest identity mismatch')
    for r in histreg['records']:
        z=(P/r['local']).read_bytes();raw=gzip.decompress(z);ensure(sha(z)==r['stored_sha256'] and sha(raw)==r['decoded_sha256'] and len(raw.splitlines())==r['line_count'],'774 stream mismatch')
    findings=gzip.decompress((P/'historical/774-rig-findings.jsonl.gz').read_bytes()); lines=findings.splitlines()
    ensure(len(lines)==103 and sha(lines[71])=='67ca7b87e5d258a9b891db17e61dd8659c7ef3b7cc7547f99f996af38b52e43a' and json.loads(lines[71])['id']=='RIG-ADMISSION03-F067','F067 mismatch')
    rr=gzip.decompress((P/'historical/774-rig-range-registration.jsonl.gz').read_bytes()).splitlines()
    aa=gzip.decompress((P/'historical/774-rig-additional-contracts.jsonl.gz').read_bytes()).splitlines()
    for pos,role in [(93,2637),(94,2638)]:
        row=json.loads(rr[pos-1]); ensure(row['sha256']==registry['files'][role]['sha256'] and row['material_ranges']==registry['files'][role]['material_ranges'],'774 registration mismatch')
    ensure(json.loads(aa[78])['id']=='RIG-ADMISSION03-ADDITIONAL-093' and json.loads(aa[79])['id']=='RIG-ADMISSION03-ADDITIONAL-094','774 additional mismatch')
    b=gzip.decompress((P/'reference/observed-current-baseline.json.gz').read_bytes());ensure(sha(b)=='36115b9bc3ebb3dec1ae87ef5a3f2431195665ab611a4b1e995e15cb9548a77f','baseline digest')
    entries=json.loads(b)['newly_assessed_ledger']['entries']
    for i,id in [(57,'REVIEW-HAIR-SHAPE-KNOBS-NAN-001'),(634,'REVIEW-HAIR-GUIDE-MAX-PATH-95E'),(636,'REVIEW-HAIR-TIED-AXIS-PROGRESS-95E'),(644,'SEGOVB-L12-CONNECTED-HAIR-CURVE-RESAMPLE-INPUT-EXTENT-ADMISSION')]: ensure(entries[i]['id']==id,'baseline identity mismatch')
    ids={e['id'] for e in entries};ensure(not {'REVIEW-HAIR-GUIDE-LENGTH-BOUND-95E','QUESTION-HAIRCUT-LENGTH-SCALE-SPECIAL-REGIONS-95E'} & ids,'unexpected candidate membership')
    ensure(len(load('REPORT.json')['thirteen_lenses'])==13,'thirteen partial perspective count')
    print(json.dumps({'status':'pass','manifest_members':len(listed),'git_proofs':len(tree['proofs']),'git_objects':len(objs),'read_source_views':len(receipt['source_displays']),'historical_record_streams':3,'scope':'Evidence identity only; no product behavior, runtime, audit clearance or remote privacy conclusion.'},indent=2))

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('evidence verification failed:',e,file=sys.stderr);sys.exit(1)
