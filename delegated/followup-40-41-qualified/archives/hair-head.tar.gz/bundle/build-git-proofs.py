#!/usr/bin/env python3
"""Freeze minimal raw Git object chains for registered evidence; no product execution.
Run only while building this new packet. The frozen verifier is read-only.
"""
import gzip, hashlib, json, pathlib, subprocess
ROOT = pathlib.Path(__file__).resolve().parent
REPO = '<PRIVATE_PATH_0001>'
OLD = '6533e444fa37552927070cc8d8190907fd3b413e'
NEW = '95e63628f9d70b8dd6e6fede64334696c6995009'
TRANS = 'f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
objects = {}

def capture(oid, typ):
    if oid in objects:
        assert objects[oid]['type'] == typ
        return gzip.decompress((ROOT / objects[oid]['file']).read_bytes())
    raw = subprocess.check_output(['git', '-C', REPO, 'cat-file', typ, oid])
    assert hashlib.sha1((typ+' '+str(len(raw))+'\0').encode() + raw).hexdigest() == oid
    rel = 'git-objects/'+oid+'.'+typ+'.gz'
    (ROOT/'git-objects').mkdir(exist_ok=True)
    (ROOT/rel).write_bytes(gzip.compress(raw,mtime=0))
    objects[oid] = {'type':typ, 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest(), 'file':rel}
    return raw

def entries(raw):
    out={}; i=0
    while i < len(raw):
        j=raw.index(b' ',i); k=raw.index(b'\0',j+1)
        mode=raw[i:j].decode('ascii'); name=raw[j+1:k].decode('utf-8'); oid=raw[k+1:k+21].hex()
        assert len(raw[k+1:k+21])==20 and name not in out
        out[name]=(mode,oid); i=k+21
    return out

def prove(rev, path, local, compression='none', qualification=''):
    commit = capture(rev, 'commit')
    tree = commit.split(b'\n',1)[0].decode().split(' ')[1]
    chain=[]
    for name in path.split('/'):
        mode, oid = entries(capture(tree,'tree'))[name]
        chain.append({'tree':tree,'name':name,'mode':mode,'object':oid})
        tree=oid
    raw=(ROOT/local).read_bytes()
    if compression=='gzip': raw=gzip.decompress(raw)
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert blob==tree and chain[-1]['mode'] in ('100644','100755')
    return {'revision':rev,'path':path,'local':local,'compression':compression,'blob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'chain':chain,'qualification':qualification}

reg=json.loads((ROOT/'registration.json').read_text())
proofs=[]
for r in reg['sources']:
    if r['kind']=='assigned-bounded-followup':
        if r['identity'].startswith('recovered'):
            path='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+r['sha256']
            proofs.append(prove(TRANS,path,r['source_file'],qualification='f82 transport of registered pr-working bytes; not project revision'))
            proofs.append(prove(OLD,r['path'],r['source_file'],qualification='Per-file 6533 equality, not separately displayed for assigned role'))
        else:
            proofs.append(prove(NEW,r['path'],r['source_file'],qualification='Pinned current source'))
    elif r['kind']=='current-support-only':
        proofs.append(prove(NEW,r['path'],r['source_file'],qualification='Bounded current support; no ordered-role credit'))
extra=json.loads((ROOT/'support-registration-tied.json').read_text())
for r in extra['rows']:
    proofs.append(prove(r['revision'],r['git_path'],r['local'],qualification='Separately registered bounded Tied support'))
hist=json.loads((ROOT/'historical-registration-774.json').read_text())
for r in hist['records']:
    proofs.append(prove(TRANS,r['git_path'],r['local'],'gzip','Original 774 stream; archived compressed representation'))
proofs.append(prove(TRANS,'handoff/774/adler-original/audit/continuation/rig/admission03/findings.jsonl','historical/774-rig-findings.jsonl.gz','gzip','Original historical 774 findings; fresh read only line 72'))
result={'schema':'726-minimal-git-source-proofs-v1','objects':objects,'proofs':proofs,'qualification':'Only three commits necessary for stated source and transport identity. Raw commit bytes contain author metadata and are not automatically privacy-reviewed. f82 transports historic evidence; it is not a current product revision.'}
(ROOT/'git-proofs.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'objects':len(objects),'proofs':len(proofs),'commits':sum(x['type']=='commit' for x in objects.values())}))
