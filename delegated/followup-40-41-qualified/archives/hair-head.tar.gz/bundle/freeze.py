#!/usr/bin/env python3
"""Create the top-level evidence manifest once, after packet assembly."""
import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).resolve().parent
m=p/'MANIFEST.json'
if m.exists():raise SystemExit('manifest already exists; frozen packet must not be rewritten')
files=[]
for f in sorted(p.rglob('*')):
    if f.is_file() and f != m:
        b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
value={'schema':'726-hair-followup-evidence-manifest-v1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/hair_ops','files':files,'qualification':'All packet files, including nested prior manifests; this top-level manifest does not hash itself. Private originals are retained locally and require privacy review before publication.'}
m.write_text(json.dumps(value,indent=2)+'\n')
print('manifest members',len(files),'sha256',hashlib.sha256(m.read_bytes()).hexdigest())
