#!/usr/bin/env python3
"""Create bounded public representation and private mapping in fresh destinations."""
import argparse,gzip,hashlib,json,re
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--original',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--private-map',type=Path,required=True);args=ap.parse_args();src=args.original;pub=args.output
if pub.exists() or args.private_map.exists():raise SystemExit('refusing to overwrite existing output or mapping')
assert not any(x.is_symlink() for x in src.rglob('*'));original_manifest=(src/'MANIFEST.json').read_bytes();H=lambda b:hashlib.sha256(b).hexdigest();assert H(original_manifest)=='5f259a4df3c3ac59e3bd7567007bd1d33b8f0f2c6106774a2ad04a74d9878981';m=json.loads(original_manifest);names={str(x.relative_to(src)) for x in src.rglob('*') if x.is_file()};assert names==set(m['files'])|{'MANIFEST.json'}
for n,x in m['files'].items():
 b=(src/n).read_bytes();assert (H(b),len(b))==(x['sha256'],x['bytes'])
changed={'prior-mhr/build-proofs.py','prior-mhr/recover-history.py','prior-mhr/register-support.py','prior-mhr/register.py'}
slash=b'/';root=b'(?:'+slash+b'home'+slash+b'|'+slash+b'tmp'+slash+b')';rx=re.compile(root+rb'[^\s"\x27<>]+');byfile={};alltokens=set()
for n in sorted(changed):
 matches=list(rx.finditer((src/n).read_bytes()));assert len(matches)=={'prior-mhr/build-proofs.py':1,'prior-mhr/recover-history.py':3,'prior-mhr/register-support.py':1,'prior-mhr/register.py':2}[n];byfile[n]=matches;alltokens.update(x.group() for x in matches)
markers={v:('<LOCAL_PATH_%d>'%i).encode() for i,v in enumerate(sorted(alltokens))};assert len(markers)==len(set(markers.values()))
pub.mkdir(parents=True);dst=pub/'reconstructed';dst.mkdir();rows=[]
for n in sorted(names):
 original=(src/n).read_bytes();out=original;edits=[]
 if n in changed:
  for match in reversed(byfile[n]):
   token=match.group();mark=markers[token];assert mark not in original;out=out[:match.start()]+mark+out[match.end():];edits.append({'marker':mark.decode(),'original_byte_offset_0based':match.start(),'original_line_1based':original.count(b'\n',0,match.start())+1})
  edits.reverse()
 dest=dst/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(out)
 row={'path':n,'original_stored_sha256':H(original),'original_stored_bytes':len(original),'public_stored_sha256':H(out),'public_stored_bytes':len(out),'representation':'reconstructed-path-redaction' if n in changed else 'exact-original-stored-bytes','edits':edits}
 if original.startswith(b'\x1f\x8b'):
  a=gzip.decompress(original);b=gzip.decompress(out);row.update({'encoding':'gzip','original_uncompressed_sha256':H(a),'original_uncompressed_bytes':len(a),'public_uncompressed_sha256':H(b),'public_uncompressed_bytes':len(b)})
 else:row['encoding']='raw'
 rows.append(row)
index={'schema':'726-hairstyle-tied-public-transport-v1','original_manifest_sha256':H(original_manifest),'prior_mhr_manifest_sha256':'f6a51e5f6c5477c4234d2352a24efeb088333105bae6b79688c0e80d9c967962','original_author':'/root/rig_identity','prior_author':'/root/mhr_character','scope_original_roles':[2639,2640],'working_source_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','historical_source_revision':'6533e444fa37552927070cc8d8190907fd3b413e','transport_object':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','qualification':'The pr-working snapshot contains unrelated modifications, and f82 is a transport object. Four historical helper scripts have seven local path substitutions; all remaining stored bytes, including gzip streams, are exact. Nested manifests retain historical original hashes, not claims of exact public bytes for these four helpers. Current and historical source/read authorship remains distinct; no checkpoint3821 promotion.','redacted_occurrences':sum(len(v) for v in byfile.values()),'distinct_local_path_tokens':len(markers),'files':rows}
(pub/'INDEX.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n');args.private_map.write_text(json.dumps({'qualification':'private original path mapping; do not publish','mapping':{marker.decode():v.decode() for v,marker in markers.items()}},indent=2)+'\n');args.private_map.chmod(0o600)
print('reconstructed',len(rows),'files,',index['redacted_occurrences'],'occurrences in',len(changed),'helper files, distinct markers',len(markers))
