#!/usr/bin/env python3
"""Read-only source/evidence integrity verifier; never executes product or old packet tools."""
from pathlib import Path
import argparse,datetime,gzip,hashlib,json,subprocess,tarfile
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--extraction-059',type=Path);ap.add_argument('--publication',type=Path);args=ap.parse_args()
h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes())
manifest=load('MANIFEST.json');actual={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()}-{'MANIFEST.json'};assert not any(x.is_symlink() for x in p.rglob('*'));assert actual==set(manifest['files'])
for n,x in manifest['files'].items():
 b=(p/n).read_bytes();assert (h(b),len(b))==(x['sha256'],x['bytes']),n
prior=p/'prior-mhr';pm=(prior/'MANIFEST.json').read_bytes();assert h(pm)=='f6a51e5f6c5477c4234d2352a24efeb088333105bae6b79688c0e80d9c967962';pmj=json.loads(pm)
for x in pmj['files']:
 b=(prior/x['path']).read_bytes();assert (h(b),len(b))==(x['sha256'],x['bytes']),x['path']
assert h((prior/'report.json').read_bytes())=='6d7a59cf1335ac5f7785a9a41c99f8201ec66e5fe81f7c504237b4df9ed130eb' and json.loads((prior/'report.json').read_bytes())['author']=='/root/mhr_character'
gp=json.loads((prior/'git-proofs.json').read_bytes());assert len(gp['objects'])==28 and len(gp['proofs'])==18
objects={}
for name,x in gp['objects'].items():
 b=gzip.decompress((prior/x['archive']).read_bytes());assert (h(b),len(b),oid(x['type'],b))==(x['sha256'],x['bytes'],name);objects[name]=(x['type'],b)
def tree_entries(data):
 out={};i=0
 while i<len(data):
  s=data.index(b' ',i);z=data.index(b'\0',s);out[data[s+1:z].decode()]=(data[i:s].decode(),data[z+1:z+21].hex());i=z+21
 assert i==len(data);return out
for x in gp['proofs']:
 kind,commit=objects[x['revision']];assert kind=='commit';tree=commit.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'] and '/'.join(y['name'] for y in x['chain'])==x['path']
 for y in x['chain']:
  assert y['tree']==tree and objects[tree][0]=='tree';mode,child=tree_entries(objects[tree][1])[y['name']];assert (mode,child)==(y['mode'],y['object']);tree=child
 raw=(prior/x['archive']).read_bytes();b=gzip.decompress(raw) if x.get('encoding')=='gzip' else raw;assert (h(b),oid('blob',b),tree)==(x['sha256'],x['blob'],x['blob'])
reg=load('REGISTRATION.json');rec=load('READ-RECEIPT.json');assert h((p/'REGISTRATION.json').read_bytes())==rec['registration_sha256'] and reg['author']==rec['author']=='/root/rig_identity' and reg['registered_utc']<rec['recorded_utc'] and len(reg['entries'])==len(rec['reads'])==10
covered={}
for x in reg['entries']:
 read=next(y for y in rec['reads'] if y['id']==x['id']);raw=(p/x['file']).read_bytes();assert (h(raw),len(raw),len(raw.splitlines()),oid('blob',raw))==(x['sha256'],x['bytes'],x['eof'],x['git_blob']);assert (read['revision'],read['sha256'],read['displayed_ranges'])==(x['revision'],x['sha256'],x['prospective_ranges'])
 seen={i for a,b in read['displayed_chunks'] for i in range(a,b+1)};ranges={i for a,b in read['displayed_ranges'] for i in range(a,b+1)};unread={i for a,b in read['unread_complement'] for i in range(a,b+1)};assert seen==ranges and not seen&unread and seen|unread==set(range(1,x['eof']+1));covered[x['file']]=seen
 z=[q for q in gp['proofs'] if q['revision']==x['revision'] and q['path']==x['path'] and q['archive']==x['proof_archive']];assert len(z)==1 and (z[0]['sha256'],z[0]['blob'])==(x['sha256'],x['git_blob']) and (prior/x['proof_archive']).read_bytes()==raw
for number in (2639,2640):
 a=next(x for x in reg['entries'] if x['id']==str(number)+'-old');b=next(x for x in reg['entries'] if x['id']==str(number)+'-current');assert a['sha256']==b['sha256'] and a['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and b['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009'
lang=load('LANGUAGE-REGISTRATION.json');lr=load('LANGUAGE-READ-RECEIPT.json');html=gzip.decompress((p/lang['archive']).read_bytes());assert (h(html),len(html),len(html.splitlines()))==(lang['uncompressed_sha256'],lang['uncompressed_bytes'],lang['eof']);assert h((p/'LANGUAGE-REGISTRATION.json').read_bytes())==lr['registration_sha256'] and lang['registered_utc']<lr['recorded_utc'] and lr['displayed_ranges']==lang['prospective_ranges'];lcovered={i for a,b in lr['displayed_ranges'] for i in range(a,b+1)};lunread={i for a,b in lr['unread_complement'] for i in range(a,b+1)};assert not lcovered&lunread and lcovered|lunread==set(range(1,lang['eof']+1));covered[lang['archive']]=lcovered
registry_raw=gzip.decompress((p/'history/registry.json.gz').read_bytes());assert h(registry_raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(registry_raw);selected=load('history/registry-selection-reconstructed.json');assert selected['full_registry_sha256']==h(registry_raw) and selected['snapshot']==next(x for x in registry['snapshots'] if x['id']=='pr-working')
for x in selected['rows']:
 n=x['original_index'];assert registry['files'][n]==x['value'];a=next(z for z in reg['entries'] if z['id']==str(n)+'-old');assert a['sha256']==x['value']['sha256'] and len([g for g in gp['proofs'] if g['kind']=='historical-object-transport' and g['sha256']==a['sha256']])==1
transport_raw=(p/'history/transport-manifest.json.gz').read_bytes();assert h(transport_raw)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';transport=json.loads(gzip.decompress(transport_raw));t={x['path']:x for x in transport['entries']};hist=json.loads((prior/'historical-index.json').read_bytes())
for x in hist['records']:
 raw=(prior/x['file']).read_bytes();b=gzip.decompress(raw) if x.get('encoding')=='gzip' else raw;assert (h(b),len(b),oid('blob',b))==(x['sha256'],x['bytes'],x['git_blob'])
 if x['kind']=='original-059':
  y=t[x['transport_path']];assert (x['sha256'],x['bytes'],x['git_blob'])==(y['sha256'],y['bytes'],y['git_blob'])
  if args.extraction_059:assert (args.extraction_059/x['transport_path']).read_bytes()==b
queue=load('history/queue-selection-reconstructed.json');original=queue['selected_from_original_transport'];assert original==t['workflow-20261030/CLOSURE-QUEUE-100.json'];assert original['sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert [x['value']['contract_id'] for x in queue['entries']]==['Q-L12-d8f313545b80add8f16d','Q-L12-f684d32f719ebe9877dc'];assert not queue['original_vs_public_full_bytes_equal']
if args.extraction_059:
 b=(args.extraction_059/original['path']).read_bytes();assert (h(b),len(b),oid('blob',b))==(original['sha256'],original['bytes'],original['git_blob']);allq=json.loads(b)['entries'];assert all(x['value']==allq[int(x['json_pointer'].split('/')[-1])] for x in queue['entries'])
working=gzip.decompress((p/'history/working-baseline-observed.json.gz').read_bytes());committed=gzip.decompress((p/'history/committed-baseline-56f.json.gz').read_bytes());hidx=load('HISTORY-INDEX.json');ledger=load('history/ledger-selection-reconstructed.json');assert (h(working),h(committed),working==committed)==(hidx['working_baseline_sha256'],hidx['committed_56f_baseline_sha256'],False)==(ledger['working_baseline_sha256'],ledger['committed_56f_baseline_sha256'],ledger['working_equals_committed'])
w=json.loads(working)['newly_assessed_ledger']['entries'];c=json.loads(committed)['newly_assessed_ledger']['entries']
for x in ledger['rows']:
 n=int(x['working_pointer'].split('/')[-1]);assert w[n]==x['working_value'] and w[n]['id']==x['id'];assert x['committed_matches']==[{'pointer':f'/newly_assessed_ledger/entries/{i}','value':v} for i,v in enumerate(c) if v['id']==x['id']]
cp=load('history/DELEGATED-EVIDENCE-CHECKPOINT-19.json');b=next(x for x in cp['bundles'] if x['bundle_id']=='hair-style-tied');assert b['agent']=='/root/mhr_character' and b['scope_original_roles']==[2639,2640] and b['archive_sha256']=='b83436c710feaaac280721cfb471800f4a6d852e657d5a6969ee29b892edf31d'
if args.publication:
 pub=args.publication;assert h((pub/b['archive']).read_bytes())==b['archive_sha256'] and h((pub/b['report_path']).read_bytes())==h((prior/'report.json').read_bytes());raw=subprocess.check_output(['git','-C',str(pub),'show','56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e:BASELINE-95E-20261110.json']);assert raw==committed
 recovery=load('history/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');patch=(pub/recovery['recovered_patch']['path']).read_bytes();assert h(patch)==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
 existing=pub/'recovered/physical-p16-revision-comparison/git-objects/f82adcabd9d89c4fa2dd7f99253a45297a0681ee.commit.gz';assert existing.read_bytes()==(prior/'git-objects/f82adcabd9d89c4fa2dd7f99253a45297a0681ee.commit.gz').read_bytes()
for x in load('RULES-INDEX.json')['files']:
 raw=(p/x['file']).read_bytes();assert (h(raw),len(raw))==(x['sha256'],x['bytes'])
report=load('REPORT.json');assert report['author']=='/root/rig_identity' and report['scope']['original_roles']==[2639,2640] and len(report['bounded_lens_perspectives'])==13 and report['accepted_unique_count_change']==0
for observation in report['observations']:
 for ref in observation['references']:
  assert ref['source'] in covered
  for a,b in ref['lines']:assert set(range(a,b+1))<=covered[ref['source']],(observation['id'],ref)
print(json.dumps({'result':'evidence_integrity_pass','reviewer':'/root/rig_identity','assigned_old_current_views':4,'registered_support_views':6,'language_reference_views':1,'independent_prior_reviewer':'/root/mhr_character','prior_git_objects':len(objects),'prior_git_paths':len(gp['proofs']),'original_059_records':sum(x['kind']=='original-059' for x in hist['records']),'history_774_records':sum(x['kind']=='historical-774' for x in hist['records']),'queue_reconstructed_rows':2,'working_baseline_equals_committed_56f':False,'optional_extraction_checked':bool(args.extraction_059),'optional_publication_checked':bool(args.publication),'qualification':'Source and evidence verification only; preserve prior author/revisions, conditional findings, uninspected complements, P16/3821 nonpromotion and no global lens, repair or product validation claim.'},indent=2))
