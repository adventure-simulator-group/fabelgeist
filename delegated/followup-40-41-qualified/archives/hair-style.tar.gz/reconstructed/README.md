# Hairstyle and tied hair: bounded source reconciliation

`REPORT.json` preserves the independent source observations, prior reviewer
attribution, conditions, safeguards, historical relationships, thirteen
bounded lens perspectives and open policy questions for original roles 2639
and 2640. No new unique finding or alias has been decided.

`REGISTRATION.json` and `READ-RECEIPT.json` identify the new reviewer’s actual
prospectively registered displays for each revision and each support range;
their uninspected complements remain explicit. The original `prior-mhr/`
packet retains the earlier checkpoint 19 author, source scopes, raw Git
commit/tree proofs and exact 059/774 records. Its historical scripts are not
executed by this verifier. The three retained commit objects include public
project author/committer metadata; f82 is the evidence transport, not the
dirty project source revision.

`history/` separates the exact archived registry/transport, the original and
public 059 queue identities, reconstructed selected queue and registry rows,
the observed working baseline, and the committed 56f baseline. The working
baseline was observed during central editing and differs from the committed
one. Historical P16 recovery is linked only with its own qualifications and
confers no P16 credit on these pr-working roles. The old checkpoint 3821 ledger
and queue remain unrecovered.

Run `python3 verify.py` for bounded, read-only evidence verification. Optional
`--extraction-059 PATH` and `--publication PATH` repeat checks against the
untouched 059 extraction and earlier published checkpoint evidence. Without
those arguments, the selected original queue rows and committed 56f association
are not rechecked against the external inputs in that invocation. These
checks do not execute product code, shaders, tests, fixtures or builds.

This is a private scratch packet pending central privacy review; copied
historical source metadata can contain local paths. Do not publish it directly.
