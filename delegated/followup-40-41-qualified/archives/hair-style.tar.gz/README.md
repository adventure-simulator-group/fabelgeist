# Hairstyle and tied hair: privacy-reviewed evidence transport

This is a qualified public reconstruction of the frozen source-only review for
original roles 2639 and 2640, pinned to source revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The separately attributed earlier
checkpoint 19 review is retained. The historical pr-working snapshot records
unrelated modifications; the 774 transport object is not a dirty source
commit. No alias, unique defect count or global lens completion is decided.

The source bodies, read receipts, frozen reports, 059 and 774 records, all Git
objects, queue and registry selections, and observed and committed baseline
snapshots retain exact original stored bytes. Four historical helper scripts
have seven local path substitutions. `INDEX.json` lists each member’s original
and public stored hashes and lengths and, for gzip members, both decoded
identities. The original top-level and earlier reviewer manifests are retained
as historical bytes; their original hashes do not describe the four redacted
public files. The prior checkpoint 19 public copies use different placeholder numbering;
`PRIOR-PUBLIC-CROSSWALK.json` and the four `prior-public/` files bind all three
representations and preserve per-occurrence placeholder relationships. Those
historical scripts and the nested original `verify.py` should not be rerun
against this reconstruction. The nested original README
was a caution about the private pre-redaction packet, not the public transport.

The captured working baseline differs from the committed 56f baseline. The
public 059 queue representation also differs from the original transport queue;
the two selected original/public rows were compared equal. The queue, registry
and ledger selections remain explicitly reconstructed records, not original
full-byte files or checkpoint 3821 evidence.

`verify-public.py` checks the public transport manifest and the qualified
original-to-public crosswalk, while retaining the unaffected source, receipt,
Git membership and historical evidence assertions. Optional `--original-dir`
checks the separately retained restricted originals and reverses every path
substitution; optional `--extraction-059` and `--publication` repeat read-only
checks against the original 059 extraction and prior checkpoint evidence.
Without private originals, the public verifier cannot independently prove the
seven substitutions. `prepare-reconstruction.py` rebuilds the public
representations and index in a fresh output directory and writes the sensitive
path mapping to a separately specified private file.

`PROOF-METADATA.json` explicitly identifies the three exact Git commit objects
and earlier published byte-identical counterparts. Their original author and
committer metadata is public project/transport proof metadata and is retained
because it is part of the object identities. The contextual privacy scan is
limited to the listed path and credential patterns; it is not a guarantee that
every possible sensitive item is absent.

No product, test, shader, fixture, build, runtime probe or repair was run. The
missing checkpoint 3821 ledger and queue remain unrecovered.
