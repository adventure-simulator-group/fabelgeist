# Hair input and profile bounded reconciliation

`report.json` records the pinned current and recovered historical source
identities, independently registered personal read scopes, findings and open
questions, historical relationships and thirteen scoped lens perspectives.
This packet does not decide aliases or defect counts and does not close a
whole lens. `personal-read-receipt.json` records exact displayed ranges;
archived bytes outside those ranges are not personal reading credit.

Original 059 and 774 records, earlier reviewer authorship, partial and adopted
credit, the dirty pr-working snapshot, registration prefix discrepancies, and
P16/checkpoint 3821 recovery qualifications remain separate. The selected
working publication ledger was modified when captured, and is distinguished
from the committed source; their selected rows happened to agree.

`tree-proofs*.json` and `proofs/` preserve raw Git tree objects and source
membership. They do not reproduce raw commit objects or author metadata. Their
revision-to-tree anchors refer to the previously published checkpoint 19
archive or can be independently checked against a trusted Git repository.
Archived source and rule/skill files remain distinct from prior reviewer read
credit. `PRIVACY-SCAN.json` describes a bounded scan, not a general clearance.

Run `python3 verify-evidence.py` for read-only packet, source, attribution,
selection and tree-path verification; add `--git` in a repository containing
the recorded revisions to check revision anchors and committed source rows.
`python3 privacy-scan.py` performs a separate read-only bounded privacy scan.
These are evidence checks only; no product, shader, macro, fixture, build, test
or runtime probe was invoked.
