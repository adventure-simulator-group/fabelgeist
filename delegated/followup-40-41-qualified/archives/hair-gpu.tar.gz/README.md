# GPU hair grow reconciliation transport

This is a byte-preserving public transport of a bounded source-only review of
roles 2641 and 2642. `PUBLIC-REPORT.json` gives the source, read-credit,
baseline, Git-anchor, privacy and nonclosure qualifications.

`TRANSPORT-MAP.json` maps all original names and identities to public names.
The 12 original helper scripts have a `.txt` suffix and are evidence only.
The original bundle manifest is preserved under `evidence/` as historical
evidence; `PUBLIC-MANIFEST.json` independently covers this transport.

Run `python3 verify-public.py` and `python3 privacy-check.py` for read-only
evidence checks. These checks do not run product code or establish product
behavior. Commit-to-tree links require the separately available checkpoint19
archive or a trusted repository; no raw Git commit author objects were copied.
