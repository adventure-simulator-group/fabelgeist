#!/usr/bin/env python3
"""Read-only verification of public evidence, not product execution."""
import datetime,gzip,hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent;p=root/'evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
gitblob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
load=lambda f:json.loads((p/f).read_bytes())
raw=lambda f:gzip.decompress((p/f).read_bytes())
numbers=lambda rs:{i for a,b in rs for i in range(a,b+1)}
public=json.loads((root/'PUBLIC-MANIFEST.json').read_bytes())
actual={f.relative_to(root).as_posix() for f in root.rglob('*') if f.is_file() and f.relative_to(root).as_posix()!='PUBLIC-MANIFEST.json'}
assert len(public['files'])==public['file_count'] and actual=={x['path'] for x in public['files']}
for x in public['files']:
 f=root/x['path']; assert not f.is_symlink(); b=f.read_bytes(); assert (len(b),sha(b))==(x['bytes'],x['sha256'])
mapping=json.loads((root/'TRANSPORT-MAP.json').read_bytes()); entries=mapping['entries']
assert len(entries)==mapping['original_file_count']==125 and mapping['content_transformations']==0 and mapping['script_path_renames']==12
assert len({x['original_path'] for x in entries})==len({x['public_path'] for x in entries})==125
for x in entries:
 assert x['public_path']=='evidence/'+x['original_path']+('.txt' if x['original_path'].endswith('.py') else '')
 b=(root/x['public_path']).read_bytes(); assert (len(b),sha(b))==(x['public_bytes'],x['public_sha256'])==(x['original_bytes'],x['original_sha256'])
m=load('BUNDLE-MANIFEST.json');assert sha((p/'BUNDLE-MANIFEST.json').read_bytes())==mapping['original_manifest_sha256']=='e9e7dab41b9d074778445bda7ca5e019f34594eb9de690f1e05f31970a055c2e'
original={x['original_path']:x for x in entries};assert len(m['files'])==m['file_count']==124 and set(original)=={x['path'] for x in m['files']}|{'BUNDLE-MANIFEST.json'}
for x in m['files']:
 a=original[x['path']];assert (a['original_bytes'],a['original_sha256'])==(x['bytes'],x['sha256'])
receipt=load('personal-read-receipt.json');views={};assigned={}
for info in receipt['registrations']:
 data=(p/info['file']).read_bytes();assert sha(data)==info['sha256'];r=json.loads(data);assert r['registered_utc']==info['registered_utc'] and datetime.datetime.fromisoformat(r['registered_utc'])<datetime.datetime.fromisoformat(receipt['recorded_utc'])
 for e in r['entries']:
  v=next(x for x in receipt['reads'] if x['tag']==e['tag']);b=(p/e['archive']).read_bytes();assert (sha(b),len(b.splitlines()),gitblob(b))==(e['sha256'],e['EOF'],e['git_blob']);assert v['registration']==info['file'] and v['revision']==e['revision'] and v['sha256']==e['sha256'];seen=numbers(v['displayed_chunks']);miss=numbers(v['unread_complement']);assert seen==numbers(e['registered_ranges']) and seen|miss==set(range(1,e['EOF']+1)) and not seen&miss;views[e['tag']]=seen
  if e.get('role') is not None:assigned[e['tag']]=e
assert len(receipt['reads'])==len(views)==18 and len(assigned)==4
for i in (2641,2642):assert (p/f'source/historical-{i}.rs').read_bytes()==(p/f'source/current-{i}.rs').read_bytes()
registry=load('history/registry-selection.json');assert registry['snapshot']['id']=='pr-working' and len(registry['snapshot']['status_porcelain'])==4
for i in (2641,2642):assert registry['rows'][str(i)]['sha256']==assigned[f'historical-{i}']['sha256'] and registry['rows'][str(i)]['snapshot']=='pr-working'
prior=load('prior/selected-index.json');assert prior['author']=='/root/rig_identity' and prior['roles']==[2641,2642] and prior['archive_sha256']=='2957a3d7d95723cbe7b0aa49dbbfaf99a1cbc8728ea28f33a02eeb89650031dd'
for x in prior['members']:
 b=(p/'prior'/x['path']).read_bytes();assert sha(b)==x['published_sha256'];assert not x['changed'] and x['original_sha256']==x['published_sha256']
old=load('prior/historical-attribution.json');assert not old['missing']
for x in old['records_059']:
 b=(p/'prior'/x['preserved_bytes']).read_bytes();assert (len(b),sha(b),gitblob(b))==(x['bytes'],x['sha256'],x['git_blob'])
l11=load('prior/historical-059/segovb/READ-L11-432.json');l12=load('prior/historical-059/segovb/READ-L12-911.json');assert l11['current_reconciled'] is False and l12['current_source_reconciled'] is False and l12['root_personal_rereads']==[] and l12['new_original_roles']==3
for i,rs,n in [(2641,[[1,22]],'001'),(2642,[[1,56]],'002')]:
 x=next(q for q in l11['sources'] if q['original_index']==i);assert x['fresh_personal_body_reads']==rs and x.get('attribution') is None
 y=next(q for q in l12['rows'] if q['original_index']==i);part=load('prior/historical-059/parallel-l12-20261029/PARTIAL-PAR-L12-911-'+n+'.json');z=next(q for q in part['rows'] if q['original_index']==i);assert y['fresh_personal_body_reads']==z['fresh_personal_body_reads']==rs and '/root/lens12_frontier' in y['attribution'] and part['new_original_credit']==0
q=load('history/queue-selection.json');cur=load('history/current-ledger-selection.json');assert q['committed_source']['sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and q['equal_selected_entries'] and q['committed_entries']==q['working_entries'] and cur['equal_selected_entries'] and cur['committed_entries']==cur['working_entries'];assert q['committed_entries']['3135']['contract_id']=='L12-CLOSURE-HAIR-GPU-NATIVE-BINDING-PORT'
selected=load('history/774-selected-rows.json');assert selected['author']=='rig' and len(selected['rows'])==4
for x in selected['rows']:
 meta=load(x['source_metadata']);body=raw(meta['compressed_path']);line=body.splitlines(keepends=True)[x['row_1based']-1];assert sha(line)==x['line_sha256_including_terminator'] and json.loads(line)==x['record'] and x['id']==x['record']['id']
pin=load('history/774-rig-pin-qualification.json');a=json.loads(raw('history/774-root046.gz'));b=json.loads(raw('history/774-root050.gz'));rd=raw('history/774-source-range-registration.jsonl.gz');qual=raw('history/774-qualifications.gz');assert a['input_pins'][3]['sha256']==pin['first35']['earlier_pin']!=sha(b''.join(rd.splitlines(keepends=True)[:35]))==pin['first35']['later_prefix'];assert b['input_pins'][2]['sha256']==pin['first139']['earlier_pin']!=sha(b''.join(rd.splitlines(keepends=True)[:139]))==pin['first139']['later_prefix'];assert a['input_pins'][4]['sha256']==sha(b''.join(qual.splitlines(keepends=True)[:31]))==pin['qualification_first31']['later_prefix'] and b['input_pins'][3]['sha256']==sha(b''.join(qual.splitlines(keepends=True)[:45]))==pin['qualification_first45']['later_prefix']
rootmap=load('prior/git-proofs.json')['commits'];proof_count=0
def tree_entries(b):
 result={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);result[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return result
for file in ['tree-proofs.json','tree-proofs-history.json','tree-proofs-pin.json']:
 doc=load(file);objs={}
 for oid,v in doc['objects'].items():
  b=raw(v['archive']);assert (len(b),sha(b))==(v['bytes'],v['sha256']) and hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=b
 for x in doc['proofs']:
  tree=x['root_tree'];assert tree==rootmap[x['revision']]['root_tree'] and len(x['path'].split('/'))==len(x['chain'])
  for name,link in zip(x['path'].split('/'),x['chain']):
   assert link['tree']==tree and link['name']==name;mode,oid=tree_entries(objs[tree])[name];assert int(mode,8)==int(link['mode'],8) and oid==link['object'];tree=oid
  data=(p/x['archive']).read_bytes();data=gzip.decompress(data) if x.get('encoding')=='gzip' else data;assert (sha(data),gitblob(data))==(x['sha256'],x['blob']) and tree==x['blob'];proof_count+=1
assert proof_count==25
for x in load('rules-and-skills.json')['records']:assert sha((p/x['file']).read_bytes())==x['sha256']
report=load('report.json');assert len(report['lens_perspectives'])==13
for item in report['observations']:
 for ref in item['trace']:assert numbers(ref['ranges'])<=views[ref['tag']]

assert sha((p/'report.json').read_bytes())=='139f47cf543b2cfe4421a2180820a15a4b636d74a6c5bbe250e87a09a3960b4d'
assert sha((p/'personal-read-receipt.json').read_bytes())=='74dd6853530ea62e7b847edcb51deb0084e5867a169d49c4218d1fcca99ceccb'
assert q['working_source_observed']['sha256']=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
assert cur['committed_source']['sha256']=='28138b4548101716246fee073984868472996f0e350d3f3526d237d61c6a67f9' and cur['working_source']['sha256']=='36115b9bc3ebb3dec1ae87ef5a3f2431195665ab611a4b1e995e15cb9548a77f'
assert prior['source_checkpoint_sha256']=='012df221f17211e027cd1d9f15f9424ae0d3186f44dd9aa4e0ac0b12229076c9'
print('PASS: public and original manifests, 125 exact bytes, 12 inert names, 18 prospectively registered personal scopes, 25 Git tree paths with externally qualified revision anchors, selected 059/774 provenance and mismatched prefixes, prior member links, separate committed/working selected rows, and 13 bounded perspectives. No product behavior validated.')
