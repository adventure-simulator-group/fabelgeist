#!/usr/bin/env python3
"""Freeze the public transport once, with top-level manifest hashed externally."""
import pathlib,hashlib,json,datetime
p=pathlib.Path(__file__).resolve().parent;m=p/'MANIFEST.json'
if m.exists():raise SystemExit('already frozen')
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f!=m:
  b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m.write_text(json.dumps({'schema':'726-13l-review-public-transport-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/hair_ops','files':files,'qualification':'Every public file including nested historical manifests; this top manifest is hashed externally.'},indent=2)+'\n');print('members',len(files),'manifest sha256',hashlib.sha256(m.read_bytes()).hexdigest())
