#!/usr/bin/env python3
"""Create an evidence manifest once after assembling this review."""
import pathlib,hashlib,json,datetime
p=pathlib.Path(__file__).resolve().parent;m=p/'MANIFEST.json'
if m.exists():raise SystemExit('already frozen')
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f!=m:
  b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m.write_text(json.dumps({'schema':'726-cloth-13l-review-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/hair_ops','files':files,'qualification':'Every review member, including nested prior manifests; this top manifest is hashed externally. Local paths require privacy review before public use.'},indent=2)+'\n');print('manifest members',len(files),'sha256',hashlib.sha256(m.read_bytes()).hexdigest())
