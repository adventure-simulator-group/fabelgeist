#!/usr/bin/env python3
"""Read-only verification of review evidence, receipts, and identities."""
import gzip,hashlib,json,pathlib,re,sys
P=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda f:json.loads((P/f).read_bytes())
def req(ok,msg):
 if not ok:raise ValueError(msg)
def lines_for(ranges):return [i for a,b in ranges for i in range(a,b+1)]
def complement(n,rs):
 out=[];pos=1
 for a,b in sorted(rs):
  req(1<=a<=b<=n,'range');
  if pos<a:out.append([pos,a-1])
  pos=max(pos,b+1)
 if pos<=n:out.append([pos,n])
 return out
def decode(p):
 b=(P/p).read_bytes();return gzip.decompress(b) if b.startswith(b'\x1f\x8b') else b
def main():
 m=load('MANIFEST.json');index={v['path']:v for v in m['files']};actual={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p!=P/'MANIFEST.json'}
 req(len(index)==len(m['files']) and actual==set(index),'manifest membership')
 for path,v in index.items():
  b=(P/path).read_bytes();req((len(b),sha(b))==(v['bytes'],v['sha256']),'manifest bytes '+path)
 reg=load('REGISTRATION.json');co=load('inputs/coordinator/REGISTRATION.json');rec=load('inputs/coordinator/READ-RECEIPT.json');ext=load('inputs/coordinator/EXT-REGISTRATION.json');extrec=load('inputs/coordinator/EXT-READ-RECEIPT.json');ext2=load('inputs/coordinator/EXT2-REGISTRATION.json');ext2rec=load('inputs/coordinator/EXT2-READ-RECEIPT.json');review=load('READ-RECEIPT.json');sources={s['id']:s for s in reg['source_rows']}
 for r in review['registrations']:req(sha((P/r['path']).read_bytes())==r['sha256'],'review registration hash')
 for r in reg['reference_inputs']:
  b=(P/r['path']).read_bytes();req((len(b),sha(b))==(r['bytes'],r['sha256']),'reference identity')
 for s in reg['source_rows']:
  stored=(P/s['stored_copy']).read_bytes();raw=decode(s['stored_copy']);req(sha(stored)==s['stored_sha256'] and sha(raw)==s['decoded_sha256'] and len(raw.splitlines())==s['decoded_lines'],'registered source bytes')
  if s['git_blob']:req(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==s['git_blob'],'Git blob identity')
 planned={s['id']:s for s in reg['source_rows']};extra=load('REGISTRATION-EXTENSION.json');initial=[r for r in review['personally_displayed'] if r['registration']=='REGISTRATION.json'];req(len(initial)==6,'review source count')
 for r in initial:
  s=planned[r['id']];req(r['actual_displayed_ranges']==s['planned_personal_display'] and r['unread_complement']==complement(s['decoded_lines'],r['actual_displayed_ranges']),'review display scope')
 ownextra=next(r for r in review['personally_displayed'] if r['id']=='fit-settings-extra');req(ownextra['actual_displayed_ranges']==extra['planned_display_ranges'] and ownextra['unread_complement']==complement(715,extra['planned_display_ranges']),'review extension scope')
 f=load('F32-REGISTRATION.json');fext=load('F32-REGISTRATION-EXT.json');f32=decode('sources/rust-std-f32.html.gz');req(sha(f32)==f['decoded_sha256']==fext['decoded_sha256'] and sha((P/'sources/rust-std-f32.html.gz').read_bytes())==f['stored_sha256'],'standard f32 reference identity')
 req(fext['prior_registration_sha256']==sha((P/'F32-REGISTRATION.json').read_bytes()),'f32 registration chain');
 for id,doc in [('rust-std-f32',f),('rust-std-f32-ext',fext)]:
  r=next(x for x in review['personally_displayed'] if x['id']==id);req(r['actual_displayed_byte_ranges_0based_half_open']==doc['planned_personal_byte_ranges_0based_half_open'],'f32 displayed range')
 a,b=f['planned_personal_byte_ranges_0based_half_open'][0];c,d=fext['planned_personal_byte_ranges_0based_half_open'][0];first=f32[a:b];second=f32[c:d];req(b'MIN_POSITIVE' in first and b'1.17549435e-38_f32' in first and b'MIN_EXP' in first and b'MIN_EXP' in second and b'= -125' in second,'f32 reference window')
 for doc,receipt,rfile,display in [(co,rec,'inputs/coordinator/REGISTRATION.json','inputs/coordinator/DISPLAY.txt'),(ext,extrec,'inputs/coordinator/EXT-REGISTRATION.json','inputs/coordinator/EXT-DISPLAY.txt'),(ext2,ext2rec,'inputs/coordinator/EXT2-REGISTRATION.json','inputs/coordinator/EXT2-DISPLAY.txt')]:
  req(sha((P/rfile).read_bytes())==receipt['registered_sha256'] and sha((P/display).read_bytes())==receipt['display_sha256'] and doc['registered_utc']<receipt['displayed_utc'],'coordinator registration receipt')
  req([x['planned_display_ranges'] for x in doc['rows']]==[x['displayed_ranges'] for x in receipt['rows']],'coordinator receipt range')
 def checktrans(filename,doc,header=True):
  blocks={};active=None;display=(P/filename).read_text().splitlines()
  for line in display:
   if line.startswith('=== ') and line.endswith(' ==='):
    active=line[4:-4].removesuffix(' extension');req(active not in blocks,'duplicate display header');blocks[active]=[];continue
   if not header and active is None:active=doc['rows'][0]['id'];blocks[active]=[]
   m=re.match(r'^\s*(\d+) (.*)$',line);req(bool(m) and active is not None,'display format');blocks[active].append((int(m.group(1)),m.group(2)))
  req(set(blocks)=={r['id'] for r in doc['rows']},'display block set');n=0
  for r in doc['rows']:
   content=decode(sources[r['id']]['stored_copy']).decode().splitlines();got=blocks[r['id']];req([i for i,v in got]==lines_for(r['planned_display_ranges']),'display numbering');
   for i,v in got:req(v==content[i-1],'display text')
   n+=len(got)
  return n
 counts=[checktrans('inputs/coordinator/DISPLAY.txt',co),checktrans('inputs/coordinator/EXT-DISPLAY.txt',ext),checktrans('inputs/coordinator/EXT2-DISPLAY.txt',ext2,False)];req(counts==[315,121,10],'display line counts')
 final=load('inputs/coordinator/ASSESSMENT-final.json');req(sha((P/'inputs/coordinator/ASSESSMENT-final.json').read_bytes())=='7370c34c6e851d8ba8de247eb70aaf8412fa95cd9bb97547b5c5f709bb182052','reviewed final digest')
 req(sha((P/'inputs/coordinator/ASSESSMENT-REVIEWED-DRAFT.json').read_bytes())=='0ae7d19fb22cea58feede2fba20b5e4da3283fa3a63c5d85904f574c0379ed7c' and sha((P/'inputs/coordinator/ASSESSMENT-INTERIM-DRAFT.json').read_bytes())=='85e5e502fd99f448e4592d65a4c3abdf7d2f09ca1941241afa3dd68972b328cf','draft preservation')
 for s in final['source_references']:
  covered=set()
  for doc in (co,ext,ext2):
   for r in doc['rows']:
    if r['id']==s['id']:covered.update(lines_for(r['planned_display_ranges']))
  for rr in s['lines']:req(set(lines_for([rr]))<=covered,'final assessment citation scope')
 for folder,mapping in [('prior-hair',{'REPORT.json':'REPORT.json','read-receipt.json':'read-receipt.json','READ-L11-430.json':'historical/059--segovb--READ-L11-430.json','059-selected.json':'historical/059-selected-records-reconstructed.json'}),('prior-mhr',{'report.json':'report.json'}),('prior-rig',{'REPORT.json':'REPORT.json','READ-RECEIPT.json':'READ-RECEIPT.json'})]:
  prev=load('inputs/'+folder+'/MANIFEST.json');lookup={v['path']:v for v in prev['files']}
  for local,old in mapping.items():
   b=(P/'inputs'/folder/local).read_bytes();req((len(b),sha(b))==(lookup[old]['bytes'],lookup[old]['sha256']),'prior manifest link')
 prev={v['path']:v for v in load('inputs/prior-rig/MANIFEST.json')['files']};history=load('ADDITIONAL-HISTORY.json')
 for r in history['inputs']:
  b=(P/r['local']).read_bytes();req((len(b),sha(b))==(r['bytes'],r['sha256'])==(prev[r['prior_manifest_path']]['bytes'],prev[r['prior_manifest_path']]['sha256']),'additional history link')
 f003=decode(history['historical_f003']['stream']).splitlines()[2];req(sha(f003)==history['historical_f003']['sha256_without_newline']=='ae780fc8895addda7279e06f948ce6489302b59e9bf53927c649b606e01d69c1' and json.loads(f003)['id']=='RIG-INITIAL06-F003','774 F003')
 old=load('inputs/prior-hair/READ-L11-430.json');req('segments+1' in old['role_dispositions'][5],'059 original count record')
 selected=load('inputs/prior-hair/059-selected.json');q=next(v['entry'] for v in selected['queue_rows'] if v['index']==614);rigq=load('inputs/prior-rig/history/059-queue-selection-reconstructed.json');req(q['contract_id']=='Q-L11-311564a4d1d7c857a062' and q==rigq['entries'][0]['value'],'q614 history')
 latest=load('CURRENT-LEDGER-SELECTION.json');prior=load('inputs/prior-rig/history/current-ledger-selection-reconstructed.json');req(latest['value']==prior['value'] and latest['value']['id']=='REVIEW-CLOTH-POSITIVE-RESOLUTION-95E' and latest['matches_earlier_rig_selection'],'current ledger selection')
 req(load('inputs/prior-hair/REPORT.json')['author']=='/root/hair_ops' and load('inputs/prior-mhr/report.json')['author']=='/root/mhr_character' and load('inputs/prior-rig/REPORT.json')['author']=='/root/rig_identity','prior authors')
 print(json.dumps({'status':'pass','manifest_members':len(index),'reviewer_source_views':len(review['personally_displayed']),'coordinator_transcript_lines':sum(counts),'current_source_blob_identities':5,'reviewed_final_sha256':sha((P/'inputs/coordinator/ASSESSMENT-final.json').read_bytes()),'historical_queue_and_f003':'preserved with separate attribution','qualification':'Read-only evidence verification; Git path comparison record relies on prior local check, no product validation, remote proof, alias or checkpoint3821 conclusion.'},indent=2))
if __name__=='__main__':
 try:main()
 except Exception as exc:print('review verification failed:',exc,file=sys.stderr);sys.exit(1)
