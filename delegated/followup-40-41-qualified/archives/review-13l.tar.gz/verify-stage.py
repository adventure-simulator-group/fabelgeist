#!/usr/bin/env python3
"""Read-only privacy crosswalk, review receipt and historical identity checks."""
import argparse,gzip,hashlib,json,os,pathlib,re,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
def req(ok,msg):
 if not ok:raise ValueError(msg)
def read(base,rel):
 p=base
 for x in pathlib.PurePosixPath(rel).parts:
  req(x not in ('.','..','/'),'invalid path');p=p/x;req(not p.is_symlink(),'symlink')
 return p.read_bytes()
def inventory(base):
 out=set()
 for root,dirs,files in os.walk(base,followlinks=False):
  for n in dirs+files:req(not (pathlib.Path(root)/n).is_symlink(),'symlink')
  for n in files:out.add((pathlib.Path(root)/n).relative_to(base).as_posix())
 return out
def decode(b,enc):
 if enc=='gzip':
  req(b[:2]==b'\x1f\x8b' and b[3]==0,'gzip header');p=gzip.decompress(b)
  req(len(p)<=128*1024*1024 and not p.startswith(b'\x1f\x8b') and not (len(p)>262 and p[257:262]==b'ustar'),'nested archive or size limit');return p
 req(enc=='identity','unknown encoding');return b
def seq(ranges):return [i for a,b in ranges for i in range(a,b+1)]
def complement(n,rs):
 out=[];pos=1
 for a,b in sorted(rs):
  req(1<=a<=b<=n,'source range');
  if pos<a:out.append([pos,a-1])
  pos=max(pos,b+1)
 if pos<=n:out.append([pos,n])
 return out
SLASH=b'/';AGENTS={SLASH+b'root/'+v.encode() for v in ('hair_ops','rig_identity','mhr_character','camera_targeting','rig_garments','native_reports','lens12_frontier','segovb','handoff_portability_review','root')}
PATH=re.compile(rb'(?:(?<![A-Za-z0-9_/])|\\[nrt])('+SLASH+rb'(?:home|users|tmp|root|mnt|workspace|workspaces|private|var/(?:tmp|folders))/[^\s"\x27<>\x00\\]+|[A-Za-z]:[\\/]+(?:Users|Documents and Settings)[\\/]+[^\s"\x27<>\x00]+)',re.I)
SECRET=re.compile(rb'gh[pousr]_[A-Za-z0-9_]{25,}|github_pat_[A-Za-z0-9_]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}|-----BEGIN (?:RSA |DSA |OPENSSH |EC |ENCRYPTED )?PRIVATE KEY-----|AKIA[0-9A-Z]{16}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|AIza[0-9A-Za-z_-]{35}|glpat-[0-9A-Za-z_-]{20,}|npm_[0-9A-Za-z]{30,}|eyJ[A-Za-z0-9_-]{18,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}|(?:Bearer\s+)[A-Za-z0-9._~+/-]{24,}',re.I);EMAIL=re.compile(rb'(?<![\w.+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w.-])');ESC=re.compile(rb'\\/|\\u002[fF]')
def privacy(b):
 n=ESC.sub(SLASH,b);agents=0
 for m in PATH.finditer(n):
  if m.group(1).rstrip(b'.,;:!?`') in AGENTS:agents+=1
  else:raise ValueError('public path candidate')
 req(not SECRET.search(n),'credential-pattern candidate');return agents

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private-root',type=pathlib.Path);ap.add_argument('--source-root',type=pathlib.Path);args=ap.parse_args()
 m=json.loads(read(P,'MANIFEST.json'));files={v['path']:v for v in m['files']};actual=inventory(P)-{'MANIFEST.json'};req(len(files)==len(m['files']) and actual==set(files),'public manifest membership')
 for path,v in files.items():
  b=read(P,path);req((len(b),H(b))==(v['bytes'],v['sha256']),'public manifest bytes')
 idx=json.loads(read(P,'EVIDENCE-IDENTITIES.json'));rows=idx['members'];lookup={v['source_path']:v for v in rows};req(len(rows)==len(lookup)==48,'source member count')
 original_top=read(P,lookup['MANIFEST.json']['public_path']);req(H(original_top)==idx['source_manifest_sha256']=='8c620a12c4a3bdc69872888fcdced05204221064019a6fb470ac10cf34fffad0','source manifest identity');orig={v['path']:v for v in json.loads(original_top)['files']};req(len(orig)==47 and set(lookup)==set(orig)|{'MANIFEST.json'},'source inventory')
 private={}
 if args.private_root:
  b=read(args.private_root,'PRIVATE-ORIGINAL-MANIFEST.json');req(H(b)==idx['private_original_manifest_sha256'],'private manifest identity');private={v['source_path']:v for v in json.loads(b)['members']};req(set(private)==set(lookup) and args.private_root.stat().st_mode & 0o077==0,'private inventory/mode')
 if args.source_root:req(inventory(args.source_root)==set(lookup),'source inventory changed')
 changed=redacts=agents=emails=0
 for name,r in lookup.items():
  if name!='MANIFEST.json':req((r['original_stored_sha256'],r['original_stored_bytes'])==(orig[name]['sha256'],orig[name]['bytes']) and r['source_manifest_bound'],'original manifest binding')
  else:req(r['source_top_manifest'] and not r['source_manifest_bound'],'source top manifest')
  stored=read(P,r['public_path']);plain=decode(stored,r['encoding']);req((H(stored),len(stored),H(plain),len(plain))==(r['public_stored_sha256'],r['public_stored_bytes'],r['public_decoded_sha256'],r['public_decoded_bytes']),'public member identity');agents+=privacy(plain);emails+=len(EMAIL.findall(plain))
  if name.endswith(('.json','.json.gz')):json.loads(plain)
  if name.endswith('.jsonl.gz'):
   for l in plain.splitlines():json.loads(l)
  ops=r['redactions'];redacts+=len(ops)
  if ops:
   changed+=1;req(r['status']=='privacy-reconstructed','reconstructed status')
   for op in ops:
    pos=op['public_decoded_offset_0based'];t=op['public_placeholder'].encode();req(plain[pos:pos+len(t)]==t,'redaction placeholder')
  else:req(r['status']=='exact-copy' and r['original_stored_sha256']==r['public_stored_sha256'] and r['original_decoded_sha256']==r['public_decoded_sha256'],'exact copy identity')
  if args.private_root:
   r0=private[name];old=read(args.private_root,r0['restricted_path']);req((H(old),len(old))==(r['original_stored_sha256'],r['original_stored_bytes'])==(r0['sha256'],r0['bytes']),'private original identity');oldplain=decode(old,r['encoding']);req((H(oldplain),len(oldplain))==(r['original_decoded_sha256'],r['original_decoded_bytes']),'private decoded identity')
   for op in sorted(ops,key=lambda v:v['original_decoded_offset_0based'],reverse=True):
    pos=op['original_decoded_offset_0based'];length=op['original_decoded_bytes'];oldplain=oldplain[:pos]+op['public_placeholder'].encode()+oldplain[pos+length:]
   req(oldplain==plain,'privacy transformation')
  if args.source_root:
   old=read(args.source_root,name);req((H(old),len(old))==(r['original_stored_sha256'],r['original_stored_bytes']),'frozen packet drift')
 req((changed,redacts,emails)==(2,2,0),'privacy scope')
 def raw(name):
  r=lookup[name];return decode(read(P,r['public_path']),r['encoding'])
 def obj(name):return json.loads(raw(name))
 cross=json.loads(read(P,'HISTORICAL-ASSERTION-CROSSWALK.json'));assertions={v['original_subject']:v for v in cross['assertions']};req(set(assertions)=={'F32-REGISTRATION.json','inputs/prior-hair/059-selected.json'},'crosswalk subjects')
 for name,v in assertions.items():
  r=lookup[name];req((v['original_sha256'],v['reconstructed_public_sha256'])==(r['original_stored_sha256'],r['public_stored_sha256']) and r['status']=='privacy-reconstructed','crosswalk identity')
 # Original registration and receipt links are historical original hashes.
 receipt=obj('READ-RECEIPT.json');reg=obj('REGISTRATION.json');f32=obj('F32-REGISTRATION.json');fext=obj('F32-REGISTRATION-EXT.json');rprior=obj('inputs/prior-hair/MANIFEST.json');earlier={v['path']:v for v in rprior['files']}
 for v in receipt['registrations']:req(v['sha256']==lookup[v['path']]['original_stored_sha256'],'reviewer original registration binding')
 req(fext['prior_registration_sha256']==lookup['F32-REGISTRATION.json']['original_stored_sha256'],'float extension original link')
 qold=lookup['inputs/prior-hair/059-selected.json']['original_stored_sha256'];req(earlier['historical/059-selected-records-reconstructed.json']['sha256']==qold and next(v for v in reg['reference_inputs'] if v['path']=='inputs/prior-hair/059-selected.json')['sha256']==qold,'original selection assertions')
 # Recheck registered source bytes and reviewer scopes; registration paths are historical, not public equality.
 src={v['id']:v for v in reg['source_rows']};req(len(src)==6,'registered source count')
 for r in reg['source_rows']:
  rr=lookup[r['stored_copy']];data=raw(r['stored_copy']);req(H(data)==r['decoded_sha256'] and rr['original_stored_sha256']==r['stored_sha256'] and len(data.splitlines())==r['decoded_lines'],'registered source bytes')
  if r['git_blob']:req(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==r['git_blob'],'source blob id')
 for r in [v for v in receipt['personally_displayed'] if v['registration']=='REGISTRATION.json']:
  p=src[r['id']];req(r['actual_displayed_ranges']==p['planned_personal_display'] and r['unread_complement']==complement(p['decoded_lines'],r['actual_displayed_ranges']),'personal source scope')
 ext=obj('REGISTRATION-EXTENSION.json');r=next(v for v in receipt['personally_displayed'] if v['id']=='fit-settings-extra');req(r['actual_displayed_ranges']==ext['planned_display_ranges'] and r['unread_complement']==complement(715,ext['planned_display_ranges']),'fit support scope')
 std=raw('sources/rust-std-f32.html.gz');req(H(std)==f32['decoded_sha256']==fext['decoded_sha256'],'float reference decoded identity')
 for id,doc in [('rust-std-f32',f32),('rust-std-f32-ext',fext)]:
  r=next(v for v in receipt['personally_displayed'] if v['id']==id);req(r['actual_displayed_byte_ranges_0based_half_open']==doc['planned_personal_byte_ranges_0based_half_open'],'float source scope')
 a,b=f32['planned_personal_byte_ranges_0based_half_open'][0];c,d=fext['planned_personal_byte_ranges_0based_half_open'][0];req(b'MIN_POSITIVE' in std[a:b] and b'1.17549435e-38_f32' in std[a:b] and b'MIN_EXP' in std[a:b] and b'= -125' in std[c:d],'float reference windows')
 # Exact drafts are kept separately, including the assessment actually reviewed.
 expected={'inputs/coordinator/ASSESSMENT-REVIEWED-DRAFT.json':'0ae7d19fb22cea58feede2fba20b5e4da3283fa3a63c5d85904f574c0379ed7c','inputs/coordinator/ASSESSMENT-INTERIM-DRAFT.json':'85e5e502fd99f448e4592d65a4c3abdf7d2f09ca1941241afa3dd68972b328cf','inputs/coordinator/ASSESSMENT-final.json':'7370c34c6e851d8ba8de247eb70aaf8412fa95cd9bb97547b5c5f709bb182052'}
 for k,v in expected.items():req(H(raw(k))==v and lookup[k]['status']=='exact-copy','assessment draft identity')
 req(raw('inputs/coordinator/ASSESSMENT.json')==raw('inputs/coordinator/ASSESSMENT-REVIEWED-DRAFT.json'),'original assessment duplicate')
 docs=[obj('inputs/coordinator/REGISTRATION.json'),obj('inputs/coordinator/EXT-REGISTRATION.json'),obj('inputs/coordinator/EXT2-REGISTRATION.json')];receipts=[obj('inputs/coordinator/READ-RECEIPT.json'),obj('inputs/coordinator/EXT-READ-RECEIPT.json'),obj('inputs/coordinator/EXT2-READ-RECEIPT.json')];names=['REGISTRATION.json','EXT-REGISTRATION.json','EXT2-REGISTRATION.json'];displays=['DISPLAY.txt','EXT-DISPLAY.txt','EXT2-DISPLAY.txt'];counts=[]
 for k,(doc,rc,nm,disp) in enumerate(zip(docs,receipts,names,displays)):
  req(H(raw('inputs/coordinator/'+nm))==rc['registered_sha256'] and H(raw('inputs/coordinator/'+disp))==rc['display_sha256'] and doc['registered_utc']<rc['displayed_utc'],'coordinator receipt');req([x['planned_display_ranges'] for x in doc['rows']]==[x['displayed_ranges'] for x in rc['rows']],'coordinator range')
  blocks={};current=None
  for line in raw('inputs/coordinator/'+disp).decode().splitlines():
   if line.startswith('=== ') and line.endswith(' ==='):
    current=line[4:-4].removesuffix(' extension');req(current not in blocks,'display duplicate');blocks[current]=[];continue
   if k==2 and current is None:current=doc['rows'][0]['id'];blocks[current]=[]
   match=re.match(r'^\s*(\d+) (.*)$',line);req(bool(match) and current is not None,'transcript format');blocks[current].append((int(match.group(1)),match.group(2)))
  req(set(blocks)=={r['id'] for r in doc['rows']},'transcript blocks');count=0
  for row in doc['rows']:
   text=raw(src[row['id']]['stored_copy']).decode().splitlines();view=blocks[row['id']];req([i for i,_ in view]==seq(row['planned_display_ranges']),'transcript range');
   for i,v in view:req(v==text[i-1],'transcript source line')
   count+=len(view)
  counts.append(count)
 req(counts==[315,121,10],'transcript counts')
 final=obj('inputs/coordinator/ASSESSMENT-final.json')
 for r in final['source_references']:
  coverage=set()
  for doc in docs:
   for row in doc['rows']:
    if row['id']==r['id']:coverage.update(seq(row['planned_display_ranges']))
  for interval in r['lines']:req(set(seq([interval]))<=coverage,'assessment source scope')
 # Preserve exact 774 record and reconstructed q614 without promoting authorship or authority.
 h=obj('ADDITIONAL-HISTORY.json');f003=raw(h['historical_f003']['stream']).splitlines()[2];req(H(f003)==h['historical_f003']['sha256_without_newline']=='ae780fc8895addda7279e06f948ce6489302b59e9bf53927c649b606e01d69c1' and json.loads(f003)['id']=='RIG-INITIAL06-F003','historical F003')
 req('segments+1' in obj('inputs/prior-hair/READ-L11-430.json')['role_dispositions'][5],'original 059 observation');q=next(x['entry'] for x in obj('inputs/prior-hair/059-selected.json')['queue_rows'] if x['index']==614);rigq=obj('inputs/prior-rig/history/059-queue-selection-reconstructed.json');req(q['contract_id']=='Q-L11-311564a4d1d7c857a062' and q==rigq['entries'][0]['value'],'q614 reconstruction')
 latest=obj('CURRENT-LEDGER-SELECTION.json');prior=obj('inputs/prior-rig/history/current-ledger-selection-reconstructed.json');req(latest['value']==prior['value'] and latest['value']['id']=='REVIEW-CLOTH-POSITIVE-RESOLUTION-95E','observed ledger selection')
 for folder,expectedauthor in [('prior-hair','/root/hair_ops'),('prior-mhr','/root/mhr_character'),('prior-rig','/root/rig_identity')]:
  report='report.json' if folder=='prior-mhr' else 'REPORT.json';req(obj('inputs/'+folder+'/'+report)['author']==expectedauthor,'prior reviewer identity')
 gm=json.loads(read(P,'GIT-METADATA-QUALIFICATION.json'));req(gm['raw_git_commit_objects_in_source_packet']==gm['raw_git_tree_objects_in_source_packet']==0 and not any(v.endswith(('.commit.gz','.tree.gz')) for v in lookup),'Git metadata disclosure')
 for name in actual|{'MANIFEST.json'}:
  if name in {v['public_path'] for v in rows}:continue
  b=read(P,name);agents+=privacy(b);emails+=len(EMAIL.findall(b))
 req(emails==0,'unexpected email-pattern match')
 print(json.dumps({'status':'pass','public_manifest_members':len(files),'source_members':len(rows),'restricted_originals_verified':len(private),'source_members_verified':len(rows) if args.source_root else 0,'reconstructed_members':changed,'path_redactions':redacts,'coordinator_transcript_lines':sum(counts),'reviewed_assessment_sha256':expected['inputs/coordinator/ASSESSMENT-final.json'],'git_blob_identities_checked':5,'raw_git_commit_objects':0,'qualification':'Read-only evidence/limited privacy verification only; subsequent wording, live remote, product behavior, alias and checkpoint3821 remain separate.'},indent=2))
if __name__=='__main__':
 try:main()
 except Exception as exc:print('transport verification failed:',exc,file=sys.stderr);sys.exit(1)
