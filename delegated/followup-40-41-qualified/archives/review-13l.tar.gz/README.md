# 13L cloth review evidence transport

This transport preserves the separately attributed 13L review, including the
exact assessment it reviewed (SHA-256 `7370c34c…`), the original and interim
drafts, coordinator source-display receipts, and the reviewer's own registered
source and Rust floating-point documentation windows. A later coordinator
wording correction is outside that reviewed packet and is not substituted or
approved here.

All 47 source-manifest members and the source manifest itself are represented.
Two members have one genuine local-path redaction each; their exact original
bytes are held in a separate owner-restricted collection. Original/public hashes,
lengths and offsets appear in `EVIDENCE-IDENTITIES.json`. The unchanged original
receipt and prior manifests still bind original bytes; their qualified relationship
to the reconstructed public files is in `HISTORICAL-ASSERTION-CROSSWALK.json`.
The old verifier is retained as evidence text and does not apply unchanged to
the reconstructed public packet.

Earlier historical 774 and 059 sources, reconstructed queue/baseline selections,
checkpoint18 readers, and newly assessed material retain their separate
attributions and revisions. No 3821 ledger or queue is supplied, and no alias
or defect count is decided. The transport includes no raw Git commit or tree
object files; stored blob checks do not themselves prove a revision path or live
remote state. See `GIT-METADATA-QUALIFICATION.json`.

Run `python3 -B verify-stage.py` for read-only integrity and bounded privacy
checks. Add `--private-root DIRECTORY` to replay both redactions against all 48
restricted originals, or `--source-root DIRECTORY` to compare the frozen packet.
The scan covers the observed gzip streams, escaped slashes and escaped-newline
paths and specified credential patterns; it cannot rule out every sensitive
encoding, identifier, or form of metadata. No product, compiler, fixture, test,
build or runtime probe was run.
