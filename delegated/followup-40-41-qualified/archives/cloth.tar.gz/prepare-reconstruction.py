#!/usr/bin/env python3
"""Create a bounded reconstruction without writing any preexisting evidence."""
import argparse,gzip,hashlib,json,re
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--original',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();src=args.original;pub=args.output
if pub.exists():raise SystemExit('refusing to overwrite an existing output directory')
pub.mkdir(parents=True);dst=pub/'reconstructed';dst.mkdir()
h=lambda b:hashlib.sha256(b).hexdigest();orig_manifest=(src/'MANIFEST.json').read_bytes();assert h(orig_manifest)=='7ea0779b008517a3a4363309e5df516079dff9d9f636b96df0e78f613d42c315';m=json.loads(orig_manifest)
assert all(not x.is_symlink() for x in src.rglob('*'))
expected={x['path']:(x['sha256'],x['bytes']) for x in m['files']}; names={str(x.relative_to(src)) for x in src.rglob('*') if x.is_file()};assert names==set(expected)|{'MANIFEST.json'}
for name,(digest,n) in expected.items():
 b=(src/name).read_bytes();assert (h(b),len(b))==(digest,n)
change={'build-git-proofs.py','reference/language.json'}; rows=[]
for name in sorted(names):
 old=(src/name).read_bytes();out=old; kind='exact-original-stored-bytes'; edits=[]
 if name in change:
  captures=list(re.finditer(b'/' + b'home' + b'/' + rb'[^\s"\x27<>]+',old));assert len(captures)==1
  before=captures[0].group();assert old.count(before)==1 and b'<LOCAL_PATH_0>' not in old
  out=old.replace(before,b'<LOCAL_PATH_0>',1);kind='reconstructed-one-local-path-substitution';edits=[{'kind':'local path token','marker':'<LOCAL_PATH_0>','count':1}]
 f=dst/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(out)
 row={'path':name,'original_stored_sha256':h(old),'original_stored_bytes':len(old),'public_stored_sha256':h(out),'public_stored_bytes':len(out),'representation':kind,'edits':edits}
 if old.startswith(b'\x1f\x8b'):
  original=gzip.decompress(old);published=gzip.decompress(out);row.update({'encoding':'gzip','original_uncompressed_sha256':h(original),'original_uncompressed_bytes':len(original),'public_uncompressed_sha256':h(published),'public_uncompressed_bytes':len(published)})
 else:row['encoding']='raw'
 rows.append(row)
index={'schema':'726-cloth-public-reconstruction-index-v1','original_manifest_sha256':h(orig_manifest),'original_manifest_bytes':len(orig_manifest),'original_author':'/root/rig_identity','scope_original_roles':[2631,2633,2634],'excluded_role':'2632 is not a cloth role and is not claimed by this packet','source_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','original_historical_source_commit':'6533e444fa37552927070cc8d8190907fd3b413e','historical_snapshot_qualification':'The original pr-working snapshot recorded unrelated modifications; equal file bytes do not establish a clean whole snapshot. The transport f82 object is distinct from project source commits.','qualification':'Reconstruction, not a lossless public copy: two local paths redacted. Original manifest and receipts remain historical hashes, not claims that those two published files are unchanged. Current ledger and queue excerpts were already explicitly reconstructed selections. No new source-read credit, alias decision, defect count or checkpoint 3821 promotion.','files':rows}
(pub/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n');print('reconstructed',len(rows),'files with',len(change),'single-path substitutions; all original stored gzip bytes preserved exactly')
