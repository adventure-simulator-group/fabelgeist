#!/usr/bin/env python3
"""Read-only source/evidence verifier; runs no source, product, test or fixture.
Set EXTRACTION_059 and PUBLICATION_EVIDENCE to repeat optional external checks.
"""
from pathlib import Path
import json,gzip,hashlib,os
# Qualified successor for the separately indexed public reconstruction.
import argparse,re
ap=argparse.ArgumentParser();ap.add_argument('--original-dir',type=Path,help='optional retained exact originals, compared read-only');args=ap.parse_args()
public=Path(__file__).resolve().parent;p=public/'reconstructed'
h=lambda b:hashlib.sha256(b).hexdigest()
def oid(t,b):return hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(f):return json.loads(f.read_bytes())
# Historical MANIFEST describes exact old bytes; public INDEX distinguishes
# its two reconstructed representations without changing the old tuples.
original_manifest=(p/'MANIFEST.json').read_bytes();assert h(original_manifest)=='7ea0779b008517a3a4363309e5df516079dff9d9f636b96df0e78f613d42c315'
index=load(public/'INDEX.json');assert index['original_manifest_sha256']==h(original_manifest) and index['scope_original_roles']==[2631,2633,2634]
oldrows={x['path']:x for x in json.loads(original_manifest)['files']};rows={x['path']:x for x in index['files']};assert set(rows)==set(oldrows)|{'MANIFEST.json'}
assert {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}==set(rows) and not any(f.is_symlink() for f in p.rglob('*'))
changed={'build-git-proofs.py','reference/language.json'}
for name,row in rows.items():
 b=(p/name).read_bytes();assert (h(b),len(b))==(row['public_stored_sha256'],row['public_stored_bytes'])
 if name!='MANIFEST.json':assert (row['original_stored_sha256'],row['original_stored_bytes'])==(oldrows[name]['sha256'],oldrows[name]['bytes'])
 else:assert (row['original_stored_sha256'],row['original_stored_bytes'])==(h(original_manifest),len(original_manifest))
 if name in changed:assert row['representation']=='reconstructed-one-local-path-substitution' and row['edits']==[{'kind':'local path token','marker':'<LOCAL_PATH_0>','count':1}] and b.count(b'<LOCAL_PATH_0>')==1 and row['original_stored_sha256']!=row['public_stored_sha256']
 else:assert row['representation']=='exact-original-stored-bytes' and not row['edits'] and row['original_stored_sha256']==row['public_stored_sha256'] and row['original_stored_bytes']==row['public_stored_bytes']
 if row['encoding']=='gzip':
  u=gzip.decompress(b);assert (h(u),len(u))==(row['public_uncompressed_sha256'],row['public_uncompressed_bytes'])==(row['original_uncompressed_sha256'],row['original_uncompressed_bytes'])
 else:assert row['encoding']=='raw'
if args.original_dir:
 q=args.original_dir;actual={str(f.relative_to(q)) for f in q.rglob('*') if f.is_file()};assert actual==set(rows) and not any(f.is_symlink() for f in q.rglob('*'))
 for name,row in rows.items():
  orig=(q/name).read_bytes();now=(p/name).read_bytes();assert (h(orig),len(orig))==(row['original_stored_sha256'],row['original_stored_bytes'])
  if name in changed:
   pat=b'/' + b'home' + b'/' + rb'[^\s"\x27<>]+';ms=list(re.finditer(pat,orig));assert len(ms)==1 and orig.count(ms[0].group())==1 and orig.replace(ms[0].group(),b'<LOCAL_PATH_0>',1)==now
  else:assert orig==now
 print('Verified all retained originals and both exact path substitutions; no prior evidence was changed.')
else:print('Original bytes not supplied: exact transformation of the two redacted path values remains unverified in this invocation.')
regs={name:load(p/name) for name in ['REGISTRATION.json','SUPPORT-REGISTRATION-2.json','SUPPORT-REGISTRATION-3.json']};receipt=load(p/'READ-RECEIPT.json');assert receipt['author']=='/root/rig_identity'
for group in receipt['registrations']:
 r=regs[group['registration']];assert h((p/group['registration']).read_bytes())==group['registration_sha256'] and r['registered_utc']<receipt['recorded_utc']
 for view in group['reads']:
  x=next(t for t in r['entries'] if t['id']==view['id']);b=(p/x['archive']).read_bytes();assert (h(b),len(b),len(b.splitlines()))==(x['sha256'],x['bytes'],x['eof']);assert view['displayed_ranges']==x['prospective_display_ranges']
  displayed={i for a,z in view['displayed_ranges'] for i in range(a,z+1)};chunked={i for a,z in view['displayed_chunks'] for i in range(a,z+1)};unread={i for a,z in view['unread_complement'] for i in range(a,z+1)}
  assert displayed==chunked and not displayed&unread and displayed|unread==set(range(1,x['eof']+1))
doc=load(p/'DOC-REGISTRATION.json');dr=load(p/'DOC-READ-RECEIPT.json');ref=doc['entries'][0];raw=gzip.decompress((p/ref['archive']).read_bytes());assert h(raw)==ref['uncompressed_sha256'] and len(raw.splitlines())==ref['eof'] and h((p/'DOC-REGISTRATION.json').read_bytes())==dr['registration_sha256'] and doc['registered_utc']<dr['recorded_utc'] and dr['reads'][0]['displayed_ranges']==ref['prospective_display_ranges']
proof=load(p/'GIT-PROOFS.json');objects={}
for name,row in proof['objects'].items():
 b=gzip.decompress((p/row['archive']).read_bytes());assert (h(b),len(b),oid(row['type'],b))==(row['sha256'],row['bytes'],name);objects[name]=(row['type'],b)
def parse_tree(b):
 d={};i=0
 while i<len(b):
  end=b.index(b'\0',i);mode,name=b[i:end].split(b' ',1);d[name.decode()]=(mode.decode(),b[end+1:end+21].hex());i=end+21
 assert i==len(b);return d
verified=set()
for x in proof['paths']:
 typ,commit=objects[x['revision']];assert typ=='commit';root=commit.split(b'\n',1)[0].split()[1].decode();assert x['chain'][0]['tree']==root and '/'.join(z['name'] for z in x['chain'])==x['path']
 for i,z in enumerate(x['chain']):
  kind,raw=objects[z['tree']];assert kind=='tree';mode,child=parse_tree(raw)[z['name']];assert (mode,child)==(z['mode'],z['object'])
  if i+1<len(x['chain']):assert child==x['chain'][i+1]['tree']
 raw=(p/x['archive']).read_bytes();b=gzip.decompress(raw) if x['encoding']=='gzip' else raw;assert (h(b),len(b),oid('blob',b))==(x['sha256'],x['bytes'],x['blob']) and x['chain'][-1]['object']==x['blob'];verified.add((x['revision'],x['path'],x['sha256']))
registry_raw=gzip.decompress((p/'history/original-registry.json.gz').read_bytes());assert h(registry_raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(registry_raw);selected=load(p/'history/registry-selection-reconstructed.json');assert selected['full_registry_uncompressed_sha256']==h(registry_raw)
for x in selected['rows']:
 n=x['original_index'];r=registry['files'][n];assert x['row']==r
 old=next(z for z in regs['REGISTRATION.json']['entries'] if z['id']==f'{n}-pr-working-object');now=next(z for z in regs['REGISTRATION.json']['entries'] if z['id']==f'{n}-current')
 assert old['sha256']==now['sha256']==r['sha256'];assert ('6533e444fa37552927070cc8d8190907fd3b413e',old['project_path'],r['sha256']) in verified and ('95e63628f9d70b8dd6e6fede64334696c6995009',old['project_path'],r['sha256']) in verified and ('f82adcabd9d89c4fa2dd7f99253a45297a0681ee',old['git_transport_path'],r['sha256']) in verified
assert selected['snapshot']==next(z for z in registry['snapshots'] if z['id']=='pr-working')
transport_raw=(p/'history/original-transport-manifest.json.gz').read_bytes();assert h(transport_raw)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';transport=json.loads(gzip.decompress(transport_raw));by_path={r['path']:r for r in transport['entries']};hist=load(p/'HISTORY-INDEX.json');extraction=os.environ.get('EXTRACTION_059')
for r in hist['059_exact_records']:
 b=(p/r['archive']).read_bytes();t=by_path[r['original_transport_path']];assert (h(b),len(b),oid('blob',b))==(r['sha256'],r['bytes'],r['git_blob'])==(t['sha256'],t['bytes'],t['git_blob'])
 if extraction:assert b==(Path(extraction)/r['original_transport_path']).read_bytes()
q=load(p/'history/059-queue-selection-reconstructed.json');q408=load(p/'history/059-q408-selection-reconstructed.json');t=by_path[q['original_transport_path']];assert (q['original_sha256'],q['original_bytes'],q['original_git_blob'])==(t['sha256'],t['bytes'],t['git_blob']) and q408['original_sha256']==t['sha256'];assert [v['value']['contract_id'] for v in q['entries']]==['Q-L11-311564a4d1d7c857a062','Q-L11-84366f72527a3a826889','L12-CLOSURE-GARMENT-POSE-PANEL-IDENTITY-SCOPE'] and q408['value']['contract_id']=='SEGOVB-L13-OPENING-DIMENSION-PROPAGATION'
if extraction:
 b=(Path(extraction)/q['original_transport_path']).read_bytes();assert (h(b),len(b),oid('blob',b))==(t['sha256'],t['bytes'],t['git_blob']);allq=json.loads(b)['entries'];assert all(v['value']==allq[int(v['json_pointer'].split('/')[-1])] for v in q['entries']) and q408['value']==allq[408]
baseline=gzip.decompress((p/'history/working-baseline-observed.json.gz').read_bytes());select=load(p/'history/current-ledger-selection-reconstructed.json');assert h(baseline)==select['baseline_sha256']==hist['working_baseline_sha256'];assert json.loads(baseline)['newly_assessed_ledger']['entries'][554]==select['value'] and select['value']['id']=='REVIEW-CLOTH-POSITIVE-RESOLUTION-95E'
cpraw=(p/'prior/CHECKPOINT-18-INDEX.json').read_bytes();assert h(cpraw)==hist['prior_checkpoint18_index_sha256'];cp=json.loads(cpraw);publication=os.environ.get('PUBLICATION_EVIDENCE')
for r in hist['prior_packets']:
 b=next(x for x in cp['bundles'] if x['bundle_id']==r['bundle_id']);assert (b['agent'],b['scope_original_roles'],b['archive_sha256'])==(r['agent'],r['roles'],r['archive_sha256']);report=(p/'prior'/Path(r['report_path']).name).read_bytes();assert h(report)==r['report_sha256'] and json.loads(report)['author']==r['agent']
 if publication:
  arc=(Path(publication)/r['archive']).read_bytes();assert h(arc)==r['archive_sha256'] and (Path(publication)/r['report_path']).read_bytes()==report
rules=load(p/'RULES-INDEX.json')
for r in rules['rules']:assert h((p/r['archive']).read_bytes())==r['sha256']
# Every cited source range must have actually been displayed for this packet;
# archived full bytes alone do not confer personal coverage.
displayed_by_archive={}
for group in receipt['registrations']:
 for read in group['reads']:
  covered=displayed_by_archive.setdefault(read['archive'],set())
  for start,end in read['displayed_ranges']:covered.update(range(start,end+1))
displayed_by_archive[ref['archive']]={i for start,end in dr['reads'][0]['displayed_ranges'] for i in range(start,end+1)}
for observation in load(p/'REPORT.json')['observations']:
 for source in observation['refs']:
  assert source['source'] in displayed_by_archive
  for start,end in source['lines']:assert set(range(start,end+1))<=displayed_by_archive[source['source']],(observation['id'],source)
print(json.dumps({'result':'evidence_integrity_pass','assigned_role_objects':3,'personal_source_displays':sum(len(x['reads']) for x in receipt['registrations']),'historical_774_path_proofs':4,'git_objects':len(objects),'git_path_proofs':len(proof['paths']),'original_059_records':len(hist['059_exact_records']),'queue_records_reconstructed':4,'prior_packets':len(hist['prior_packets']),'optional_059_extraction_checked':bool(extraction),'optional_prior_archives_checked':bool(publication),'qualification':'Read/metadata proofs preserve original reviewer and revisions, do not imply product validation, whole-lens clearance, duplicate count, or checkpoint3821 credit.'},indent=2))

# Packet-only integrity and bounded privacy scan, read-only. Git commit
# author/committer metadata is intentionally retained as original proof.
package=load(public/'MANIFEST.json');actual={str(f.relative_to(public)) for f in public.rglob('*') if f.is_file()}-{'MANIFEST.json'};assert actual==set(package['files']) and not any(f.is_symlink() for f in public.rglob('*'))
for name,row in package['files'].items():
 raw=(public/name).read_bytes();assert (h(raw),len(raw))==(row['sha256'],row['bytes'])
slash=b'/'
roots=slash+rb'(?:home|users|tmp|root|mnt|workspace|workspaces|private|var/(?:tmp|folders))/[^\s"\x27<>]+'
windows=rb'[A-Za-z]:[\\/]{1,4}(?:users|documents and settings)[\\/]{1,4}[^\s"\x27<>]+'
pathrx=re.compile(rb'(?i)(?<![a-z0-9_])(?:'+roots+rb'|'+windows+rb')')
secret=re.compile(rb'gh[pousr]_[A-Za-z0-9_]{25,}|github_pat_[A-Za-z0-9_]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}|-----BEGIN (?:RSA |DSA |OPENSSH |EC |ENCRYPTED )?PRIVATE KEY-----|AKIA[0-9A-Z]{16}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|AIza[0-9A-Za-z_-]{35}|glpat-[0-9A-Za-z_-]{20,}|npm_[0-9A-Za-z]{30,}',re.I)
agents={slash+b'root/'+x.encode() for x in ('rig_identity','hair_ops','mhr_character','camera_targeting','rig_garments','native_reports','lens12_frontier','segovb')}
contexts=(b'author',b'reviewer',b'agent',b'attribution',b'attributed',b'read',b'prior',b'earlier',b'independent',b'subagent',b'record',b'owner',b'historical',b'lens',b'original',b'finding',b'parallel',b'packet',b'checked')
count=0
for f in sorted(public.rglob('*')):
 if not f.is_file():continue
 b=f.read_bytes();b=gzip.decompress(b) if b.startswith(b'\x1f\x8b') else b;b=re.sub(rb'(?i)\\u002f',slash,b.replace(b'\\/',slash));assert not secret.search(b),str(f.relative_to(public))
 for line in b.splitlines():
  for match in pathrx.finditer(line):
   token=match.group().rstrip(b'.,;:!?');assert token in agents and any(k in line.lower() for k in contexts),(str(f.relative_to(public)),'unclassified path candidate');count+=1
print('Verified public packet integrity and',count,'contextually retained agent-identity tokens; bounded path/secret patterns are not a general privacy clearance.')
