#!/usr/bin/env python3
# Source-evidence capture only; this script writes solely under this new packet.
from pathlib import Path
import subprocess,json,gzip,hashlib
p=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda b:hashlib.sha256(b).hexdigest();objects={};proofs=[]
def fetch(oid,kind):
 if oid not in objects:
  raw=g('cat-file',kind,oid);assert hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
  path='git-objects/'+oid+'.'+kind+'.gz';(p/path).write_bytes(gzip.compress(raw,mtime=0));objects[oid]={'type':kind,'bytes':len(raw),'sha256':sha(raw),'archive':path}
 else:raw=gzip.decompress((p/objects[oid]['archive']).read_bytes())
 return raw
def tree(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 return out
def add(rev,path,archive,encoding,kind):
 commit=fetch(rev,'commit');current=commit.split(b'\n',1)[0].split()[1].decode();chain=[];parts=path.split('/')
 for name in parts:
  raw=fetch(current,'tree');mode,nxt=tree(raw)[name];chain.append({'tree':current,'name':name,'mode':mode,'object':nxt});current=nxt
 b=(p/archive).read_bytes();data=gzip.decompress(b) if encoding=='gzip' else b
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==current
 proofs.append({'kind':kind,'revision':rev,'path':path,'archive':archive,'encoding':encoding,'sha256':sha(data),'bytes':len(data),'blob':current,'chain':chain})
reg=json.loads((p/'REGISTRATION.json').read_bytes()); seen=set()
for x in reg['entries']:
 key=(x['git_transport_revision'],x['git_transport_path'])
 if key not in seen:add(*key,x['archive'],'raw',x['purpose']);seen.add(key)
 if x.get('original_role') and x['purpose']=='assigned historical object':
  key=('6533e444fa37552927070cc8d8190907fd3b413e',x['project_path']);add(*key,x['archive'],'raw','recorded historical HEAD per-file equality; does not prove whole snapshot clean');seen.add(key)
for fname in ['SUPPORT-REGISTRATION-2.json','SUPPORT-REGISTRATION-3.json']:
 for x in json.loads((p/fname).read_bytes())['entries']:
  key=(x['git_transport_revision'],x['git_transport_path'])
  if key not in seen:add(*key,x['archive'],'raw',x['purpose']);seen.add(key)
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for prefix,names in [('handoff/774/adler-original/audit/continuation/rig/admission03/',['source-range-registration.jsonl','additional-contracts.jsonl']),('handoff/774/adler-original/audit/continuation/rig/initial06-type-ownership/',['contracts-013.json','findings.jsonl'])]:
 for name in names:add(f82,prefix+name,'history-774/'+name+'.gz','gzip','historical 774 record through f82 transport; not project source revision')
(p/'GIT-PROOFS.json').write_text(json.dumps({'schema':'726-cloth-2631-2634-raw-git-proofs-v1','objects':objects,'paths':proofs,'qualification':'Path chains and raw objects preserve commit/tree/blob identity only. f82 is historical evidence transport, not the source revision; equal individual files do not prove the dirty historical tree clean or transfer reader credit.'},indent=2)+'\n')
print('captured',len(objects),'commit/tree objects and',len(proofs),'path proofs')
