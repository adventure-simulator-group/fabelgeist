# Cloth roles: qualified public evidence reconstruction

This packet preserves the independently attributed cloth reconciliation for
original roles 2631, 2633 and 2634. Role 2632 is outside its scope. The working
source comparison is pinned to revision `95e63628f9d70b8dd6e6fede64334696c6995009`;
the historical pr-working records have their own revision and dirty-snapshot
qualification. The transport commit is not represented as the source commit.

`reconstructed/REPORT.json` is the exact frozen report, with the actual
historical and personal read ranges, source references, thirteen bounded lens
perspectives, guards, conditions, open questions and prior reviewer credits.
The earlier selected registry, queue and working-baseline records were already
marked reconstructed or observed; this packaging does not make them originals
or turn an observed working baseline into a committed one.

Only two local path tokens were changed, in `build-git-proofs.py` and
`reference/language.json`. The public index separately lists original and public
stored identities for every member, plus decoded identities for gzip members.
All source bodies, Git objects, receipts, historical selections, prior reports,
the original manifest and the frozen report retain their exact stored bytes.
The original manifest and old verifier are retained as historical evidence;
their original hash assertions do not apply to the two redacted public files.
The initial `write-report.py` generator is also historical; do not rerun it
against this frozen record.

`verify-public.py` checks the qualified public identities and preserves the
original evidence verifier's other checks. Set `EXTRACTION_059` and
`PUBLICATION_EVIDENCE` to repeat the optional external read-only checks. Pass
`--original-dir ORIGINAL` to independently verify the two substitutions
against separately retained private originals. Without those originals the
public verifier cannot prove the original-to-redacted transformations.
`prepare-reconstruction.py` can recreate the representations and index in a
new directory using an exact original packet; it refuses an existing output.

The preserved raw Git commit objects include public project author/committer
metadata, which forms part of their object identity. The previously published
physical-P16 proof already contains the same transport commit object. The
privacy scan covers named path and secret patterns and is not a general
privacy clearance. The missing original checkpoint 3821 remains unrecovered;
this packet confers no transferred source-read credit or global lens closure,
resolves no alias or unique-count decision, and reports no product validation.
