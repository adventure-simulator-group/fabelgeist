from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();objects={};proofs=[]
def save(t,k):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,b)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(b,mtime=0));objects[k]={'type':t,'size':len(b),'sha256':h(b),'local':p}
 return b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);m,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return m.decode(),k
 raise KeyError(n)
def proof(rev,path,local,kind,encoding=None):
 b=(r/local).read_bytes();b=gzip.decompress(b) if encoding=='gzip' else b;root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,k=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':k});tree=k
 assert tree==oid('blob',b),(rev,path,local);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'encoding':encoding,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(b)})
reg=json.loads((r/'registration.json').read_bytes());f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for e in reg['entries']:
 if e.get('transport_path'):proof(e['transport_revision'],e['transport_path'],e['versions'][0]['path'],'f82 transport, not project/native package source revision')
 if e.get('project_path'):
  v=e['versions'][0];proof(v['revision'],e['project_path'],v['path'],'95e source support')
for rev in ['a120390947c89b703dc74c4255a13c035d054c50','6533e444fa37552927070cc8d8190907fd3b413e']:proof(rev,'Cargo.lock','support/historical-lock-497.source','individual clean commit equals pr-working lock object; does not establish whole dirty snapshot clean')
proof('90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696','crates/fabelgeist-geometry/src/length.rs','support/positive-length.source','report-p17 path equals current file bytes; historical body not freshly displayed')
proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/7ce3b7a0720e800087df009c9726c0869988dfad3c24cc4a67bfbf49e059f48e','support/positive-length.source','p17 role2680 original object; equality only, no transferred display')
rev='eb407672813424d64ec31f208193969f5a62620c'
for path,local in [('handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json','recovered/original-059-queue.json.gz'),('handoff/726-audit-20261030-adler/evidence/continuation-segovb/ledger.json','recovered/original-059-ledger.json.gz')]:proof(rev,path,local,'exact original 059 checkpoint, not 3821','gzip')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-reflect-checkpoint13-git-proofs-v1','objects':objects,'proofs':proofs,'qualification':'Exact path membership only; no old personal-read transfer, whole historical tree clean, feature activation or checkpoint3821 adoption.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'sha',h((r/'git-proofs.json').read_bytes()))
