from pathlib import Path
import gzip,hashlib,json,shutil
r=Path(__file__).resolve().parent;src=Path('<LOCAL_PATH_0>'); user=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest()
for d in ['recovered','historical','prior']:(r/d).mkdir()
for n in ['MANIFEST.json','registry.json.gz','objects.tar.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:shutil.copyfile(src/n,r/'recovered'/n)
(r/'recovered/p16').mkdir();shutil.copyfile(src/'physical-p16-patch-recovery/tracked.patch',r/'recovered/p16/tracked.patch');shutil.copyfile(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json',r/'recovered/p16/RECOVERY.json')
q=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'));led=json.load(gzip.open(r/'recovered/original-059-ledger.json.gz','rt'));registry=json.load(gzip.open(r/'recovered/registry.json.gz','rt'));inds=[2332,3445];rows={str(i):q['entries'][i] for i in inds};findings={e['contract_id']:led['discovery_findings_and_dependencies'][e['contract_id']] for e in rows.values() if e['contract_id'] in led['discovery_findings_and_dependencies']}
(r/'historical/selections-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed selection of exact preserved 059 queue and ledger; not an independent original or checkpoint3821.','queue_rows':rows,'ledger_findings':findings,'p17_role2680':registry['files'][2680]},indent=2,ensure_ascii=False)+'\n')
ref={}
for e in rows.values():
 for g in e.get('granular_contract_views',[]):
  b=g.get('bundle')
  if b and b.get('path') and b.get('sha256'):ref[b['path']]=b['sha256']
  c=g.get('contract_update_as_proposed',g)
  for s in c.get('exact_source_identities_and_assessed_ranges',[]):
   if ('2571' in str(s.get('original_index')) or '2572' in str(s.get('original_index')) or '2680' in str(s.get('original_index'))):
    for key in ['receipt','prospective_registration']:
     rec=s.get(key)
     if rec and rec.get('path') and rec.get('sha256'):ref[rec['path']]=rec['sha256']
for name,digest in ref.items():
 p=user/name
 if not p.exists():print('Missing exact 059 path',name);continue
 b=p.read_bytes();assert h(b)==digest,(name,h(b),digest);out=r/'historical'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
packets=[('mhr-native','<LOCAL_PATH_3>','BUNDLE-MANIFEST.json',['report.json','read-receipt.json','support-read-receipt.json','registration.json','historical-059-index.json','historical-774-index.json','historical-059/segovb/READ-L11-422.json','historical-059/segovb/READ-L12-873.json','historical-059/parallel-l12-20261029/QUALIFICATION-PAR-L12-621-WINDOWS-ORIGINAL2571.json','historical-059/parallel-l12-20261029/QUALIFICATION-PAR-L12-622-WINDOWS-ORIGINAL2572.json','historical-774/registration-observed-first13.jsonl','historical-774/qualification-pin-matching-first13.jsonl','historical-774/root/admission03-scope-reconciliation-044.json.gz','historical-774/rig/admission03/source-range-registration.jsonl.gz','historical-774/rig/admission03/source-qualifications.jsonl.gz','historical-774/rig/admission03/reflection-witness-001.json.gz','historical-774/rig/admission03/completion-112.json.gz']),('rig-derive-reconcile','<LOCAL_PATH_4>','MANIFEST.json',['REPORT.json','personal-read-receipt.json','registration.json']),('mhr-opaque','<LOCAL_PATH_5>','BUNDLE-MANIFEST.json',['report.json','read-receipt.json','support-read-receipt.json'])]
index=[]
for label,path,mname,files in packets:
 p=Path(path);dest=r/'prior'/label;dest.mkdir();mb=(p/mname).read_bytes();m=json.loads(mb);mapping={e['path']:e['sha256'] for e in m['files']};(dest/mname).write_bytes(mb)
 for f in files:
  b=(p/f).read_bytes();assert mapping[f]==h(b),(label,f);out=dest/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 index.append({'label':label,'original_directory':path,'manifest':mname,'manifest_sha256':h(mb),'copied_files':files})
info={'qualification':'Original 059 receipts and selected historical proposals are verified against exact queue hashes. Prior packet members are verified by their own frozen manifests. Historical root044/completion112 rig registration digests differ from later recovered registration stream; neither missing earlier bytes nor an alias is silently replaced. No prior verifiers invoked.','historical_059_receipts':ref,'prior_packets':index}
(r/'historical/evidence-index.json').write_text(json.dumps(info,indent=2,ensure_ascii=False)+'\n');print('Original 059 references',len(ref),'prior packet selections',len(index))
