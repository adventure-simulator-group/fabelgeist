# Checkpoint 13: Bevy reflect roles 2571–2572

This additive source-only packet connects two original Bevy reflect 0.19.1
native roles to exactly two historical 059 records, q2332 and q3445. Current
first-party declarations and consumers are separately registered support.
Fresh actual source windows and their unread complements appear in
`read-receipt.json`; earlier readers retain their own attribution.

The native archive and original source members match the separately displayed
P16, pr-working and 95e lock identities. Historical lock roles are support and
the P16 snapshot remains dirty. The historical 774 rig earlier registration pins
do not match the later recovered registration stream; the matching independent
qualification prefix and bounded-search limits are preserved explicitly.

The original 059 queue and ledger are gzip-preserved with Git proofs. Selected
records are expressly reconstructed. Report-p17 90a and 95e length-file byte
identity is proved, but the old P17 copy was not freshly displayed in this
packet. No historic evidence is promoted to missing checkpoint 3821.

Run `python3 <LOCAL_PATH_0>
for read-only evidence-integrity verification. It does not call earlier packet
verifiers or execute product code, macros, builds, tests or runtime probes.
