from pathlib import Path
import datetime,hashlib,json
r=Path(__file__).resolve().parent;out=r/'MANIFEST.json';files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p!=out:
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
out.write_text(json.dumps({'schema':'726-reflect-2571-2572-checkpoint13-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'qualification':'All nested manifests are included, excluding only this top-level manifest; archived bytes are not personal body-read credit.'},indent=2)+'\n');print('manifest',hashlib.sha256(out.read_bytes()).hexdigest(),'files',len(files),'bytes',sum(x['bytes'] for x in files))
