from pathlib import Path
import gzip,hashlib,io,json,tarfile,tomllib
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();m=json.loads((r/'recovered/MANIFEST.json').read_bytes());rb=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());original=json.loads(rb);assert h(rb)==m['registry_sha256'];assert h((r/'recovered/registry.json.gz').read_bytes())==m['registry_gzip_sha256'];assert h((r/'recovered/objects.tar.gz').read_bytes())==m['objects_archive_sha256']
reg=json.loads((r/'registration.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());assert rec['registration_sha256']==h((r/'registration.json').read_bytes());archive=(r/'native/bevy_reflect-0.19.1.crate').read_bytes();assert h(archive)==reg['package_sha256']
for path in ['support/historical-lock-39.source','support/historical-lock-497.source','support/current-lock.source']:
 p=next(x for x in tomllib.loads((r/path).read_text())['package'] if x['name']=='bevy_reflect' and x['version']=='0.19.1');assert p['source']=='registry+https://github.com/rust-lang/crates.io-index' and p['checksum']==h(archive)
with tarfile.open(r/'recovered/objects.tar.gz') as tar,tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as crate:
 for e in reg['entries']:
  if 'original_index' in e:
   row=original['files'][e['original_index']];assert e['historical_registry_row']==row;b=tar.extractfile(row['sha256']).read();assert b==crate.extractfile(e['package_member']).read()==(r/e['versions'][0]['path']).read_bytes()
  elif 'original_index_lock' in e:
   row=original['files'][e['original_index_lock']];assert e['historical_registry_row']==row and tar.extractfile(row['sha256']).read()==(r/e['versions'][0]['path']).read_bytes()
  elif e.get('archive_member'):assert crate.extractfile(e['archive_member']).read()==(r/e['versions'][0]['path']).read_bytes()
  for v in e['versions']:
   b=(r/v['path']).read_bytes();assert h(b)==v['sha256'] and len(b.splitlines())==v['eof'];s=next(x for x in rec['reads'] if x['path']==v['path']);assert s['display_windows']==v['registered_windows'];observed=set();unread=set()
   for a,z in s['display_windows']:observed.update(range(a,z+1))
   for a,z in s['unread_complement']:unread.update(range(a,z+1))
   assert not observed.intersection(unread) and observed.union(unread)==set(range(1,v['eof']+1))
proof=json.loads((r/'git-proofs.json').read_bytes());objs={}
for k,v in proof['objects'].items():
 b=gzip.decompress((r/v['local']).read_bytes());assert len(b)==v['size'] and h(b)==v['sha256'] and oid(v['type'],b)==k;objs[k]=b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),k
 raise AssertionError(n)
for p in proof['proofs']:
 tree=objs[p['revision']].splitlines()[0].split()[1].decode();assert tree==p['root_tree']
 for c in p['chain']:
  assert tree==c['tree'];mode,k=lookup(objs[tree],c['name']);assert mode==c['mode'] and k==c['object'];tree=k
 assert p['path'].split('/')==[c['name'] for c in p['chain']];b=(r/p['local']).read_bytes();b=gzip.decompress(b) if p.get('encoding')=='gzip' else b;assert h(b)==p['sha256'] and oid('blob',b)==tree==p['blob']
queue=json.loads(gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes()));ledger=json.loads(gzip.decompress((r/'recovered/original-059-ledger.json.gz').read_bytes()));sel=json.loads((r/'historical/selections-reconstructed.json').read_bytes());idx=json.loads((r/'historical/evidence-index.json').read_bytes());assert sel['p17_role2680']==original['files'][2680]
for i in [2332,3445]:
 row=queue['entries'][i];assert sel['queue_rows'][str(i)]==row
 if row['contract_id'] in sel['ledger_findings']:assert sel['ledger_findings'][row['contract_id']]==ledger['discovery_findings_and_dependencies'][row['contract_id']]
for p,digest in idx['historical_059_receipts'].items():assert h((r/'historical'/p).read_bytes())==digest
for e in idx['prior_packets']:
 base=r/'prior'/e['label'];m=base/e['manifest'];assert h(m.read_bytes())==e['manifest_sha256'];m=json.loads(m.read_bytes());known={y['path']:y['sha256'] for y in m['files']}
 for p in e['copied_files']:assert h((base/p).read_bytes())==known[p]
base=r/'prior/mhr-native/historical-774';assert h((base/'registration-observed-first13.jsonl').read_bytes())=='442704cfbcdb6f971a06981c68f1442451ccbd9eb7e039dfda32e5d639a772d9';assert h((base/'qualification-pin-matching-first13.jsonl').read_bytes())=='70717aa1c0908935341afa5297937f1bf79513146453c1328076848d00e94e53';assert h(gzip.decompress((base/'rig/admission03/source-range-registration.jsonl.gz').read_bytes()))=='24fb01a82c91de97fd9895740404dc79a73877fcd79a846c832c45cbf2495bdb'
patch=(r/'recovered/p16/tracked.patch').read_bytes();assert len(patch)==524542 and h(patch)==next(x['patch_sha256'] for x in original['snapshots'] if x['id']=='physical-p16')
report=json.loads((r/'REPORT.json').read_bytes());assert [x['queue_index'] for x in report['reconciliations']]==[2332,3445] and len(report['lens_perspectives'])==13
manifest=r/'MANIFEST.json'
if manifest.exists():
 files=json.loads(manifest.read_bytes())['files'];entries={e['path']:e for e in files};actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p!=manifest};assert set(entries)==actual
 for n,e in entries.items():b=(r/n).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],n
print('PASS: registry/archive and native members; P16/pr/95e lock checksums; f82/95e/90a and 059 Git proofs; personal display partitions; original 059 and prior manifest evidence; 774 pin distinctions; matching tracked patch; thirteen bounded perspectives'+('; complete manifest' if manifest.exists() else '; before manifest'))
print('Evidence-only: no feature resolution, macro, product, build, test, fixture, probe, repair or runtime validation.')
