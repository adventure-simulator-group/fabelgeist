import datetime,hashlib,json,pathlib,re
p=pathlib.Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_text());reads=[]
for x in reg['sources']:
 current=next(y for y in x['project'] if y['name']=='current');reads.extend([{'kind':'historical-physical-p16','original_role':x['original_role'],'path':x['source_path'],'archive':x['archive'],'actual_display_chunks':x['planned_display'],'actual_display_union':x['planned_display'],'unread_ranges':[],'full_body_displayed':True},{'kind':'current-project','original_role':x['original_role'],'revision':current['revision'],'path':current['path'],'archive':current['archive'],'actual_display_chunks':current['planned_display'],'actual_display_union':current['planned_display'],'unread_ranges':[],'full_body_displayed':True}])
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':h((p/'registration.json').read_bytes()),'reads':reads,'git_body_comparisons':'a120 and 6533 bytes compared only; no separate personal Git body display claimed.'},indent=2)+'\n')
nav={str(i):[] for i in range(7)}
for line in (p/'navigation.txt').read_text().splitlines():
 m=re.match(r'.*support-(\d+)\.source:(\d+):',line)
 if m:nav[m.group(1)].append(int(m.group(2)))
for name,i in [('navigation-02.txt','3'),('navigation-03.txt','6')]:
 for line in (p/name).read_text().splitlines():
  m=re.match(r'(\d+):',line)
  if m:nav[i].append(int(m.group(1)))
nav={i:sorted(set(v)) for i,v in nav.items()};(p/'navigation-exposures.json').write_text(json.dumps({'exposed_line_numbers':nav,'qualification':'Untruncated symbol navigation outputs, exact singleton exposures included in personal display unions; navigation alone gives no unrelated body or ordered-role credit.'},indent=2)+'\n')
plans={0:[[1,95],[96,183]],1:[[1,110],[111,219]],2:[[1,40],[80,205],[300,350]],3:[[110,150],[220,285],[760,850],[850,930],[200,220],[285,335]],4:[[1,50]],5:[[1,49]],6:[[225,280]]}
def merge(rr):
 o=[]
 for a,b in sorted(rr):
  if o and a<=o[-1][1]+1:o[-1][1]=max(o[-1][1],b)
  else:o.append([a,b])
 return o
def comp(rr,n):
 k=1;o=[]
 for a,b in rr:
  if k<a:o.append([k,a-1])
  k=b+1
 if k<=n:o.append([k,n])
 return o
regs=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json'];allx={}
for name in regs:
 for x in json.loads((p/name).read_text())['sources']:allx[x['archive']]=x
out=[]
for i,chunks in plans.items():
 x=allx[f'source/support-{i}.source'];rr=merge(chunks+[[n,n] for n in nav[str(i)]]);u=comp(rr,x['lines']);out.append({'kind':'current-project','revision':x['revision'],'path':x['path'],'archive':x['archive'],'actual_body_display_chunks':chunks,'navigation_singletons':nav[str(i)],'actual_display_union':rr,'unread_ranges':u,'full_body_displayed':not u,'qualification':'Current support only; included test text is not executed.'})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'file':n,'sha256':h((p/n).read_bytes())} for n in regs],'reads':out},indent=2)+'\n');print('assigned',len(reads),'support',len(out),'nav singletons',sum(len(x) for x in nav.values()));print('support coverage',[(x['path'],x['actual_display_union'],x['unread_ranges']) for x in out])
