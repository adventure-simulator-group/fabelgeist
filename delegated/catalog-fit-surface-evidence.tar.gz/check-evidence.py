import datetime,gzip,hashlib,json,pathlib,re
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());rec=json.loads((p/'read-receipt.json').read_text());sr=json.loads((p/'support-read-receipt.json').read_text());assert H((p/'registration.json').read_bytes())==rec['registration_sha256']
for x in sr['registrations']:assert H((p/x['file']).read_bytes())==x['sha256']
prior=json.loads((p/'prior-references.json').read_text());manifests={}
for label,x in prior['packets'].items():
 b=(p/x['manifest_copy']).read_bytes();assert H(b)==x['manifest_sha256'];manifests[label]={z['path']:z for z in json.loads(b)['files']}
for x in prior['references']:
 b=pathlib.Path(x['original_path']).read_bytes();e=manifests[x['packet']][x['manifest_path']];assert (len(b),H(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256'])
saphyr=pathlib.Path(prior['packets']['saphyr']['path']);previous=pathlib.Path(prior['packets']['placement']['path']);lookup={};phys={}
for x in reg['sources']:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b))==(x['bytes'],x['lines'],x['sha256']);phys[x['source_path']]=x
 for y in x['project']:
  assert y['status']=='present';z=(p/y['archive']).read_bytes();assert (len(z),len(z.splitlines()),H(z),O('blob',z))==(y['bytes'],y['lines'],y['sha256'],y['git_blob_sha1']);assert y['same_as_p16'] and z==b;lookup[y['revision'],y['path']]=y
support={};permitted={}
for n in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json']:
 for x in json.loads((p/n).read_text())['sources']:
  b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1']);support[x['revision'],x['path']]=x;permitted.setdefault(x['archive'],[]).extend(x['planned_display'])
lookup.update(support);displays={}
def check(r,n):
 rr=r['actual_display_union'];u=r['unread_ranges'];assert all(1<=a<=b<=n for a,b in rr+u);read={i for a,b in rr for i in range(a,b+1)};unread={i for a,b in u for i in range(a,b+1)};assert not read&unread and read|unread==set(range(1,n+1));assert r['full_body_displayed']==(not unread)
for x in rec['reads']:
 if x['kind']=='historical-physical-p16':y=phys[x['path']];key=(x['kind'],x['path'])
 else:y=lookup[x['revision'],x['path']];key=(x['kind'],x['revision'],x['path'])
 check(x,y['lines']);assert x['actual_display_union']==y['planned_display'];displays[key]=x['actual_display_union']
nav={str(i):[] for i in range(7)}
for line in (p/'navigation.txt').read_text().splitlines():
 m=re.match(r'.*support-(\d+)\.source:(\d+):',line)
 if m:nav[m.group(1)].append(int(m.group(2)))
for name,i in [('navigation-02.txt','3'),('navigation-03.txt','6')]:
 for line in (p/name).read_text().splitlines():
  m=re.match(r'(\d+):',line)
  if m:nav[i].append(int(m.group(1)))
nav={i:sorted(set(v)) for i,v in nav.items()};assert nav==json.loads((p/'navigation-exposures.json').read_text())['exposed_line_numbers']
for x in sr['reads']:
 y=lookup[x['revision'],x['path']];check(x,y['lines']);i=re.search(r'support-(\d+)\.source$',x['archive']).group(1);assert x['navigation_singletons']==nav[i]
 actual={z for a,b in x['actual_body_display_chunks'] for z in range(a,b+1)};allowed={z for a,b in permitted[x['archive']] for z in range(a,b+1)};union={z for a,b in x['actual_display_union'] for z in range(a,b+1)};assert actual<=allowed and actual|set(nav[i])==union;displays['current-project',x['revision'],x['path']]=x['actual_display_union']
proof=json.loads((p/'git-proofs.json').read_text());objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in proof['proofs']:
 tree=objects[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for e in x['chain']:
  assert e['tree']==tree and entries(objects[tree])[e['name']]==(e['mode'],e['object']);tree=e['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert tree==x['blob']==O('blob',b) and H(b)==x['sha256']
 if x['kind'] in ['base-project-role','historical-pr-project-role','current-project-role','current-support']:assert tree==lookup[x['revision'],x['path']]['git_blob_sha1']
report=json.loads((p/'report.json').read_text());refs=0
for a in report['assessments']:
 for x in a['source_refs']:
  key=(x['source_kind'],x['path']) if x['source_kind']=='historical-physical-p16' else (x['source_kind'],x['revision'],x['path']);rr=displays[key]
  for start,end in x['lines']:assert any(c<=start<=end<=d for c,d in rr),(key,start,end,rr);refs+=1
with gzip.open(saphyr/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((saphyr/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
r=json.load(gzip.open(saphyr/'reference/original-registry.json.gz','rt'))
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']:assert x['entry']==r['files'][x['index']]
for x in reg['sources']:assert x['original_registry_entry']==r['files'][x['original_role']] and x['registry_snapshot']=='physical-p16';assert r['files'][938]['sha256']==r['files'][2581]['sha256'] and r['files'][940]['sha256']==r['files'][2582]['sha256']
old774=json.loads((p/'historical-774-index.json').read_text())
for x in old774['records']:
 b=gzip.decompress((p/x['copy']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
hq=old774['hash_qualifications'];assert H((p/'historical-774/registration-observed-first35.jsonl').read_bytes())==hq['later_first35_sha256']!=hq['root046_rig_registration_expected'];assert H((p/'historical-774/qualification-pin-matching-first31.jsonl').read_bytes())==hq['root046_qualification_expected']==hq['later_first31_qualification_sha256'];oldroot=json.loads(gzip.decompress((p/'historical-774/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));assert hq['root046_rig_registration_expected'] in [x['sha256'] for x in oldroot['input_pins'] if x['supplier']=='rig'] and hq['root046_qualification_expected'] in [x['sha256'] for x in oldroot['input_pins'] if x['supplier']=='rig']
l11=json.loads((p/'historical-059/segovb/READ-L11-424.json').read_text());l12=json.loads((p/'historical-059/segovb/READ-L12-876.json').read_text());assert not l12['root_personal_rereads']
for i,rg,rr in [(2581,1492,[[1,46]]),(2582,1493,[[1,47]])]:
 x=next(z for z in l11['sources'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==rr and H((p/f'historical-059/segovb/REGISTRATION-SEGOVB-{rg}.json').read_bytes())==x['registration_sha256'];x=next(z for z in l12['rows'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==rr and H((p/'historical-059'/x['registration']).read_bytes())==x['registration_sha256'] and H((p/'historical-059'/x['identity_specific_windows_qualification']['path']).read_bytes())==x['identity_specific_windows_qualification']['sha256']
assert H((p/'historical-059/parallel-l12-20261029/PROPOSAL-L12-876.json').read_bytes())==l12['proposal_sha256'];hair=json.loads((previous/'later-hair-ops/p16-live-comparison.json').read_text());assert hair['recomputed_patch_sha256']==hair['recorded_patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and hair['patch_hash_exact_match'] and hair['patch_saved']==False and hair['head']==reg['p16_recorded_base'];assert len(report['perspectives'])==13
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','linked_prior_manifests':{k:v['manifest_sha256'] for k,v in prior['packets'].items()},'assigned_p16_and_current_displays':len(rec['reads']),'registered_support_objects':len(support),'navigation_singleton_lines':sum(len(v) for v in nav.values()),'git_path_proofs':len(proof['proofs']),'raw_git_objects':len(objects),'source_reference_ranges_within_personal_displays':refs,'original_059_exact_records':len(hist['records']),'older_774_exact_transport_records':len(old774['records']),'rig_046_registration_prefix_match':False,'rig_046_qualification_prefix_match':True,'qualification':'Hash-linked prior packets must remain available for registry and later P16 recovery. Evidence verification only; no product execution. Bounded earlier rig registry pin remains unmatched.'};print(json.dumps(result,indent=2))
