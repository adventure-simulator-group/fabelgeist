import datetime,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');s1=json.loads((p/'support-registration.json').read_text())['sources'][3];s2=json.loads((p/'support-registration-03.json').read_text())['sources'][1];rows=[]
for x,rr in [(s1,[[200,220],[285,335]]),(s2,[[225,280]])]:
 rows.append({k:x[k] for k in ['revision','path','archive','sha256','git_blob_sha1','bytes','lines']}|{'planned_display':rr})
(p/'support-registration-04.json').write_text(json.dumps({'agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Read build catalog validation and its diagnostics/typed-decode boundary; static source only.','sources':rows},indent=2)+'\n');print([(x['path'],x['planned_display']) for x in rows])
