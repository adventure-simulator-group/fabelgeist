import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');reg=json.loads((p/'support-registration.json').read_text());plans={2:[[1,40],[80,205],[300,350]],3:[[110,150],[220,285],[760,850]],4:[[1,50]]};rows=[]
for i,ranges in plans.items():
 x=reg['sources'][i];rows.append({'revision':x['revision'],'path':x['path'],'archive':x['archive'],'sha256':x['sha256'],'bytes':x['bytes'],'lines':x['lines'],'git_blob_sha1':x['git_blob_sha1'],'planned_display':ranges,'planned_navigation':'additional exact surface::validate_equipment_surface and positive_f32_in symbol lines in validation.rs' if i==3 else None})
(p/'support-registration-02.json').write_text(json.dumps({'agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Read bounded schema, validator and runtime embedding context; initial navigation exposure separately retained.','sources':rows},indent=2)+'\n');print([(x['path'],x['planned_display']) for x in rows])
