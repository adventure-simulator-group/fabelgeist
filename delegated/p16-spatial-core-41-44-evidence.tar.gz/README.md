# Bounded P16 spatial geometry evidence: roles 41–44

`REPORT.json` records `/root/hair_ops`'s source inspection of exact dirty P16
registry objects and pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. `registration.json` and
`read-receipt.json` distinguish prospective plans, personal old/current source
displays, match-only navigation and separately registered support. The P16
objects equal their corresponding a120, 6533, 039 and current files per file;
only the old and current source windows were displayed, and this does not
make the dirty P16 snapshot clean or transfer source credit.

Historical role 43's original material is 1–100; helper 101–105 is a distinct
registered overlay. Old requests for coordinates 1–170 and orientation
1–151 exceed the respective 140- and 142-line files. Retain the other
reviewers' exact role and context qualifications. Earlier central camera
traces are bounded c100 observations with matching bytes, not fresh 95e reads.
`prior-personal-read-correction.json` discloses prior support reads discovered
after the new registration and displays; it is additive and does not rewrite
the original registration or transfer any role credit.

The current trace reconnects existing ROOT-ADM-F003: sibling-visible point and
displacement fields allow a representable invariant bypass. The inspected
bounds union selects already admitted values; no bad caller or runtime incident
is claimed. The separate scene leaf aggregate question remains conditional.
The later recovered tracked P16 patch and seven untracked-status limitations
remain as recorded; historical evidence is not promoted to checkpoint 3821.

`git-proofs.json` and `git-objects/` preserve offline commit/tree/blob proofs.
`historical-manifest.json` distinguishes exact original records from prior
copies; `historical-selections-reconstructed.json` is a newly reconstructed
selection. `MANIFEST.json` inventories every file except itself, including
nested manifests. To verify evidence integrity only:

```sh
python3 verify-evidence.py
```

The verifier checks hashes, source identity, registry rows, historical reader
links, display partitions and the manifest. It cannot independently establish
a personal source display; that is the reviewer's recorded receipt. No
product, tests, fixtures, builds, probes or repairs were executed.
