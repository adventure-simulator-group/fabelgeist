'''Offline evidence and source identity integrity only; no product execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,re,tarfile
b=Path(__file__).resolve().parent
h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();L=lambda n:json.loads((b/n).read_bytes())
reg=L('registration.json');rec=L('read-receipt.json');hist=L('historical-manifest.json');sel=L('historical-selections-reconstructed.json');proof=L('git-proofs.json');report=L('REPORT.json');ids=[41,42,43,44];expected={41:[[1,29]],42:[[1,140]],43:[[1,100]],44:[[1,142]]}
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
arch=L('recovered/MANIFEST.json');rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256']==arch['registry_sha256'];assert h((b/'recovered/registry.json.gz').read_bytes())==arch['registry_gzip_sha256'];assert h((b/'recovered/objects.tar.gz').read_bytes())==arch['objects_archive_sha256'];r=json.loads(rbytes);original=r['files'];assert all(original[i]==sel['registry_rows'][str(i)] for i in ids);assert sel['snapshot_rows']==[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')]
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];cv=L('prior/COVERAGE-L01-ROLES.json');assert h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes())==sel['prior_coverage_sha256'];assert all(next(x for x in cv['roles'] if x['original_index']==i)==sel['prior_coverage_roles'][str(i)] for i in ids);assert cv['roles'][42]['status']=='bounded-current-trace-only' and cv['roles'][44]['status']=='bounded-current-trace-only'
snap=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=L('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['live_comparison']['status_counts']['??']==7
catalog=L('recovered/catalog-774.json')['rows']
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];raw=(b/old['local']).read_bytes();assert t.extractfile(old['sha256']).read()==raw and h(raw)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256'];assert row['original_material_ranges']==original[i].get('material_ranges') and row['fresh_display_plan']==expected[i];assert catalog[i]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path'];assert (b/cur['local']).read_bytes()==raw and cur['equals_historical_object']
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==raw and c['equals_historical_object'] and not c['display_planned']
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(x['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(rr):return [i for a,z in rr for i in range(a,z+1)]
def part(n,rr,extra=[]):
 v=nums(rr)+extra;return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  x=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/x['local']).read_bytes();assert h(raw)==v['sha256']==x['sha256'] and len(raw.splitlines())==v['eof']==x['eof'];assert set(nums(x['actual_display_chunks']))==set(nums(expected[row['original_index']]));assert part(v['eof'],x['actual_display_chunks']+x['unread_complement'],x['navigation_only_lines_at_assigned_scope']);assert x['original_registry_material_ranges']==(row['original_material_ranges'] if not j else None)
plans={x['name']:x for n in ['support-registration.json','support-registration-bounds.json'] for x in L(n)['entries']};assert len(plans)==len(rec['support'])
for x in rec['support']:
 p=plans[x['name']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==p['sha256'] and len(raw.splitlines())==x['eof'] and x['ordered_role_credit']==0;assert set(nums(x['full_line_body_displays']))==set(nums(p['ranges']));assert part(x['eof'],x['full_line_body_displays']+x['prior_assigned_displays_of_same_version']+x['unread_complement'],x['navigation_only_lines'])
for v in ['historical','95e6']:
 z=next(x for x in rec['support'] if x['name']=='dimensions-tail-'+v);assert z['full_line_body_displays']==[[101,105]] and z['prior_assigned_displays_of_same_version']==[[1,50],[51,100]]
nav={}
for x in rec['navigation_output_receipts']:
 raw=(b/x['output']).read_bytes();lines=raw.decode().splitlines();assert h(raw)==x['sha256'] and len(lines)==x['saved_output_lines'];displayed=nums(x['personally_displayed_output_lines']);unread=nums(x['unread_saved_output_lines']);assert set(displayed+unread)==set(range(1,len(lines)+1)) and len(displayed)+len(unread)==len(lines)
 for j in displayed:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):(.*)$',lines[j-1]);assert m;path,num,body=m.group(1),int(m.group(2)),m.group(3);nav.setdefault(path,set()).add(num)
  for p in rec['support']:
   if p['path']==path and p['revision']:assert (b/p['local']).read_text().splitlines()[num-1]==body
  for row in reg['rows']:
   if row['path']==path:assert (b/row['versions'][1]['local']).read_text().splitlines()[num-1]==body
assert {k:sorted(v) for k,v in nav.items()}==rec['navigation_actual_source_lines']
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
coverage=readjsonl('historical/059/evidence/audit11/inherited-coverage.jsonl');contract=L('historical/059/segovb/INHERITED-L11-CONTRACT-010.json');assert h((b/'historical/059/evidence/audit11/inherited-coverage.jsonl').read_bytes())=='4cfe8fd09dd49043595c0aff0f002e1939a80a138fdd6fae60f78d92f8e00a4a' and h((b/'historical/059/segovb/INHERITED-L11-CONTRACT-010.json').read_bytes())=='228e4d70930617c6be2f1e654ccc92a9240ba3e2f8b75ecb24986b2c87a11191'
for i in ids:
 x=next(x for x in coverage if x.get('scope_index')==i);assert x['sha256']==original[i]['sha256'] and x['ranges']==expected[i]
a=L('historical/059/segovb/READ-L11-469.json');overlay=next(x for x in a['rows'] if x.get('original_role_identity')==43);assert overlay['fresh_personal_body_reads']==[] and overlay['same_lens_ranges']==[[101,105]] and overlay['separate_overlay_receipt']['ranges']==[[101,105]]
a=L('historical/059/segovb/READ-L11-473.json')
for i in [42,44]:
 x=next(x for x in a['rows'] if x.get('historical_coverage_entry',{}).get('scope_index')==i);assert x['fresh_personal_body_reads']==[] and x['historical_coverage_entry']['ranges']==expected[i]
native=readjsonl('historical/774/03-source-range-registration.jsonl');nq={x.get('id'):x for x in readjsonl('historical/774/04-source-qualifications.jsonl')}
for i in [42,44]:
 x=original[i]['admission03_increment046_role_observations'][0];assert native[x['row_1based']-1]==x['original_record'];assert x['effective_material_ranges']==([[1,29],[51,89]] if i==42 else [[109,142]])
assert nq['RIG-ADMISSION03-QUALIFICATION-REG030']['material_ranges']==[[108,142]] and nq['RIG-ADMISSION03-QUALIFICATION-REG029-MATERIAL']['qualified_material_ranges']==[[1,29],[51,89]] and nq['RIG-ADMISSION03-QUALIFICATION-REG030-MATERIAL']['qualified_material_ranges']==[[109,142]]
cam=readjsonl('historical/774/00-additional-sources.jsonl')
for i in [42,44]:
 x=original[i]['owner_contract_proofs'][0];row=cam[x['row']];assert row['source_id']==original[i]['source_id'] and row['sha256']==original[i]['sha256'] and row['read_ranges']==x['read_ranges']
roottraces=readjsonl('historical/774/02-traces.jsonl');camtraces=readjsonl('historical/774/01-traces.jsonl')
for i in [41,42]:
 for x in original[i]['producer_reached_contract_observations']:
  traces=roottraces if '/root/' in x['record'] else camtraces;t=next(y for y in traces if y.get('id',y.get('trace_id'))==x['receipt']);node=t
  for c in x['json_pointer'].strip('/').split('/'):node=node[int(c)] if isinstance(node,list) else node[c]
  assert node==x['source_context'] and node['read_ranges']==x['read_ranges_as_recorded']
rootcamera=L('prior/ASSESSMENT-L01-CAMERA-ROOT.json');assert rootcamera['current_revision']=='c100638b720a7281a5fc96f6a3c5c23d5dda85da'
for i,wanted in [(42,[[32,41],[86,110]]),(44,[[86,108]])]:
 row=next(x for x in reg['rows'] if x['original_index']==i);v=next(x for x in rootcamera['current_sources'] if x['path']==row['path']);assert v['ranges']==wanted and v['sha256']==row['versions'][1]['sha256'] and v['git_blob']==row['versions'][1]['git_blob']
assert any(x.get('id')=='ROOT-ADM-F003' for x in readjsonl('historical/774/09-root-findings.jsonl'));assert any(x.get('id')=='RIG-ADMISSION03-REFERENCE-002' and x['canonical_finding']=='ROOT-ADM-F003' for x in readjsonl('historical/774/11-rig-reference-qualifications.jsonl'));assert any(x.get('id')=='RIG-ADMISSION03-CONTRACT-001' for x in readjsonl('historical/774/06-contract-groups.jsonl'))
corr=L('prior-personal-read-correction.json');assert datetime.fromisoformat(corr['created_utc'])>datetime.fromisoformat(reg['created_utc'])
for x in corr['entries']:
 assert h((b/x['receipt']).read_bytes())==x['receipt_sha256'];r0=L(x['receipt']);ls=r0.get('reads',r0.get('support',[]));y=next(z for z in ls if z.get('path')==x['source_path']);assert y['revision']==x['revision'] and y.get('actual_display_windows',y.get('displayed'))==x['actual_display']
assert len(proof['proofs'])==41 and len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and report['support_personal_displays']==rec['support']
for x in report['related_evidence']:assert h((b/x['path']).read_bytes())==x['sha256']
if (b/'MANIFEST.json').exists():
 seen=set()
 for x in L('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert h(raw)==x['sha256'] and len(raw)==x['bytes'],x['path'];seen.add(x['path'])
 assert seen=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p!=b/'MANIFEST.json'}
print('PASS: roles 41–44; independent old/current bounded displays, historic reader/overlay qualifications, late prior-read disclosure, 41 Git proofs and 13 bounded lenses. Evidence integrity only; no product execution.')
