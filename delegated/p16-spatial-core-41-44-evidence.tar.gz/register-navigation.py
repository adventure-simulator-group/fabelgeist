from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','purpose':'Prospective source match-only navigation for canonical geometry owners and relevant producer/consumers. Matches are not full body or ordered-role credit.','patterns':['LeafDimensions','PlanDimensions','PlanExtents','SpatialDirection','RigidRotation','from_quaternion','fn finite','CuboidDimensions'],'paths':['crates/adventuresim-building-generator/src/spatial_geometry','crates/fabelgeist-geometry/src','crates/adventuresim-tactical-core/src/scene_input','crates/adventuresim-tactical-client/src/presentation']}
Path('navigation-registration.json').write_text(json.dumps(x,indent=2)+'\n')
