from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent
rows=[]
for p in sorted(x for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'):
 raw=p.read_bytes();rows.append({'path':str(p.relative_to(b)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(b/'MANIFEST.json').write_text(json.dumps({'schema':'726-evidence-manifest-v1','created_utc':datetime.now(timezone.utc).isoformat(),'files':rows,'qualification':'Packet integrity only; historical source attribution, chronology and unrecovered whole-file registration identity remain as stated in report.'},indent=2)+'\n')
