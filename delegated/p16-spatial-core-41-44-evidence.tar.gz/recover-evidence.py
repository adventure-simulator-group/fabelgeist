from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,shutil
b=Path.cwd();pub=Path('<LOCAL_PATH_0>');orig=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');ws=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:copy(prev/'recovered'/n,'recovered/'+n,'Recovered archive or specifically labelled reconstructed catalog/later patch; preserve original qualifications.')
for n in ['AGENTS.md','crates/AGENTS.md']:copy(ws/n,'rules/'+n,'Applicable source rules; source-only task restrictions prevail.')
for n in ['COVERAGE-L01-ROLES.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','ASSESSMENT-L1-CAMERA.json','ASSESSMENT-L01-CAMERA-ROOT.json']:copy(pub/n,'prior/'+n,'Central prior record: retain its c100 or historical revision and authors/ranges, never credit it as 95e fresh read.')
for n in ['segovb/READ-L11-469.json','segovb/READ-L11-473.json','segovb/INHERITED-L11-CONTRACT-010.json','evidence/audit11/inherited-coverage.jsonl']:copy(orig/n,'historical/059/'+n,'Exact historical 059 inherited/overlay record; keep its own revision/reader/reuse qualifications.')
prevs=[('<LOCAL_PATH_4>','own-2679'),('<LOCAL_PATH_5>','own-2715'),('<LOCAL_PATH_6>','own-p16-geometry-lighting'),('<LOCAL_PATH_7>','own-p16-building-member-shapes'),('<LOCAL_PATH_8>','own-p16-window-instances'),('<LOCAL_PATH_9>','mhr-scene-window-spatial')]
for root,label in prevs:
 src=Path(root)
 for n in ['REPORT.json','report.json','MANIFEST.json','packet-manifest.json','BUNDLE-MANIFEST.json','read-receipt.json','support-read-receipt.json','support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json']:
  if (src/n).exists():copy(src/n,'prior/'+label+'/'+n,'Prior packet evidence only; no author or ordered-role transfer.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';gps=[
'records/final-acceptance-20261021/wave-01/audit-existing-type-owners/camera/additional-sources.jsonl',
'records/final-acceptance-20261021/wave-01/producer-supplement-after-owner/camera/traces.jsonl',
'records/final-acceptance-20261021/wave-01/producer-supplement-after-owner/root/traces.jsonl',
'continuation/rig/admission03/source-range-registration.jsonl','continuation/rig/admission03/source-qualifications.jsonl','continuation/rig/admission03/coverage.jsonl','continuation/rig/admission03/contract-groups.jsonl','continuation/rig/owner-reached-producer-followup/traces.jsonl','continuation/root/admission03/new-parallel-admission-177.json']
for i,g in enumerate(gps):
 gp='handoff/774/adler-original/audit/'+g;raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{i:02d}-'+Path(g).name,'git:'+rev+':'+gp,'Exact original 774 source record, f82 evidence transport only.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw);qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());cv=json.loads((b/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=[41,42,43,44]
s={'kind':'Newly reconstructed selected rows, not original historical record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in ids},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')],'queue_uncompressed_sha256':h(qraw),'prior_coverage_sha256':h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes()),'prior_coverage_roles':{str(i):next(x for x in cv['roles'] if x['original_index']==i) for i in ids},'qualification':'P16 dirty frozen state based a120; later matching tracked patch and seven untracked items retain custody/recovery limits. Different historical reviewers and later current traces never transfer.'};(b/'historical-selections-reconstructed.json').write_text(json.dumps(s,indent=2)+'\n');(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'Exact original records and separately labelled copied prior packets; f82 is evidence transport.'},indent=2)+'\n');print('recovered',len(records),'historical manifest',h((b/'historical-manifest.json').read_bytes()))
