from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
plans=[('finite','crates/adventuresim-building-generator/src/spatial_geometry/error.rs',[[1,99]]),('cuboid','crates/fabelgeist-geometry/src/cuboid.rs',[[1,120]]),('door','crates/adventuresim-tactical-core/src/scene_input/buildings.rs',[[145,220]]),('window','crates/adventuresim-tactical-core/src/scene_input/buildings/window.rs',[[1,75]]),('closure-meshes','crates/adventuresim-tactical-client/src/presentation/closure_meshes.rs',[[1,72]])]
entries=[];pending=[]
for name,path,ranges in plans:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';eof=len(raw.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':eof,'ranges':ranges,'local':loc});pending.append((loc,raw))
for label in ['historical','95e6']:
 path='crates/adventuresim-building-generator/src/spatial_geometry/dimensions.rs';raw=(b/f'source/43-{label}.rs').read_bytes();entries.append({'name':'dimensions-tail-'+label,'path':path,'identity':'physical-p16 exact historical object' if label=='historical' else 'pinned 95e','revision':None if label=='historical' else rev,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':[[101,105]],'local':f'source/43-{label}.rs','qualification':'Separate support/overlay, never historical role 43 original 1–100 credit.'})
(b/'support-registration.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively register dimension helper tail as separate historic/current support and bounded owners/consumers; no credit for historical role43 tail or another reviewer.','entries':entries},indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
