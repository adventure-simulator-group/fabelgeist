from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json,gzip,tarfile
b=Path(__file__).resolve().parent;pub='<LOCAL_PATH_0>';transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';reg=json.loads(gzip.open(pub+'/recovered/original-registry-source-archive/registry.json.gz','rb').read());packages={'wgpu':'76e8840e1ba2881d4cbb18d2147627a56af426ff064c0401eb0c8410c6325d07','wgpu-types':'84bf84cd9ca8ca45e2b223a3868f1adf9bfc0c66aeac212e76ee7e40fdadf8f5'};pkgroot=Path('<LOCAL_PATH_1>');g=lambda *a:subprocess.check_output(['git','-C',pub,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
for name,h in packages.items():
 data=(pkgroot/f'{name}-29.0.4.crate').read_bytes();assert sha(data)==h;(b/f'packages/{name}-29.0.4.crate').write_bytes(data)
es=[]
for role in [0,27,28,29,30]:
 x=reg['files'][role];parts=x['path'].split('/');name=parts[1].removesuffix('-29.0.4');path='/'.join(parts[2:]);member=f'{name}-29.0.4/{path}';arc=f'packages/{name}-29.0.4.crate'
 with tarfile.open(b/arc) as t:raw=t.extractfile(member).read()
 h=sha(raw);tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+h;assert h==x['sha256'] and raw==g('show',transport+':'+tp);eof=len(raw.splitlines());ranges=x['owner_contract_proofs'][0]['read_ranges'];assert max(z for a,z in ranges)<=eof;dest=f'sources/{role}-{name}-{Path(path).name}';(b/dest).write_bytes(raw)
 es.append({'id':str(role),'role':role,'original_source_id':x['source_id'],'snapshot':x['snapshot'],'package':name,'version':'29.0.4','package_checksum':packages[name],'package_archive':arc,'member_path':member,'archive':dest,'sha256':h,'git_blob':oid(raw),'bytes':len(raw),'eof':eof,'transport_revision':transport,'transport_path':tp,'prospective_personal_read_ranges':ranges,'qualification':'Exact historical native registry role/ranges only. Package source checksum/lock selected separately from project Git. Same file may have multiple original roles with distinct ranges and attribution. No native calls.'})
(b/'registration.json').write_text(json.dumps({'schema':'726-wgpu-native-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':es,'restriction':'Static source/evidence only, no GPU, shader, product execution, fixture, build, test or runtime probe.'},indent=2)+'\n');print([(e['id'],e['original_source_id'],e['eof'],e['prospective_personal_read_ranges']) for e in es])
