from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tomllib,tarfile
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');report=load('REPORT.json');names=['registration.json','support-registration.json','support-registration-2.json'];groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858'
roles=[0,27,28,29,30];sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==roles
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
checks={'wgpu':'76e8840e1ba2881d4cbb18d2147627a56af426ff064c0401eb0c8410c6325d07','wgpu-types':'84bf84cd9ca8ca45e2b223a3868f1adf9bfc0c66aeac212e76ee7e40fdadf8f5'}
for n,h in checks.items():assert sha((b/f'packages/{n}-29.0.4.crate').read_bytes())==h
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
 if name=='registration.json' or x['repo_kind']=='crate-archive':
  assert x['package_checksum']==checks[x['package']]
  with tarfile.open(b/x['package_archive']) as tar:assert tar.extractfile(x['member_path']).read()==d
 else:assert oid('blob',d)==x['git_blob']
for i in roles:
 x=regs[('registration.json',str(i))];r=registry['files'][i];assert x['original_source_id']==r['source_id'] and x['sha256']==r['sha256'] and x['prospective_personal_read_ranges']==r['owner_contract_proofs'][0]['read_ranges']
a=regs[('registration.json','0')];z=regs[('registration.json','28')];assert a['original_source_id']!=z['original_source_id'] and a['sha256']==z['sha256'] and (b/a['archive']).read_bytes()==(b/z['archive']).read_bytes() and a['prospective_personal_read_ranges']!=z['prospective_personal_read_ranges']
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];selection=load('queue-selection-reconstructed.json')
for x in selection['entries']:assert x['entry']==q[x['original_index_zero_based']]
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
a=[json.loads(z) for z in gun('history/774/rig-owner-redacted.jsonl.gz').splitlines()];c=[json.loads(z) for z in gun('history/774/rig-owner-original-paths.jsonl.gz').splitlines()];assert sha(gun('history/774/rig-owner-redacted.jsonl.gz'))!=sha(gun('history/774/rig-owner-original-paths.jsonl.gz'))
for x in hist['selected_rig_variant_comparisons']:
 r=registry['files'][x['role']];j=r['owner_contract_proofs'][0]['row'];assert x['registry_row_zero_based']==j and x['physical_line_1based']==j+1;u,v=a[j],c[j];assert u['source_id']==v['source_id']==r['source_id'] and u['observed_sha256']==v['observed_sha256']==r['sha256'] and u['read_ranges']==v['read_ranges']==r['owner_contract_proofs'][0]['read_ranges'] and {k:w for k,w in u.items() if k!='path'}=={k:w for k,w in v.items() if k!='path'} and u['path']==x['redacted_path'] and v['path']==x['original_path']
owner=[json.loads(z) for z in gun('history/774/rig-owner-contracts.jsonl.gz').splitlines()];assert all(any(x.get('id')==id for x in owner) for id in ['RIG-OWNER-PROBE-015','RIG-OWNER-NATIVE-CAUSE-023'])
adm=[json.loads(z) for z in gun('history/774/rig-admission-contracts.jsonl.gz').splitlines()]
for role,id in [(0,10),(27,18),(28,19),(29,20),(30,21)]:
 x=next(x for x in adm if x.get('id')==f'RIG-ADMISSION03-CONTRACT-{id:03d}');assert x['source_id']==registry['files'][role]['source_id'] and x['actual_read_ranges']==registry['files'][role]['owner_contract_proofs'][0]['read_ranges']
camera=[json.loads(z) for z in gun('history/774/camera-contracts.jsonl.gz').splitlines()];assert all(any(x.get('id')==id for x in camera) for id in ['CAMERA-INITIAL07-CONTRACT-005','CAMERA-INITIAL07-CONTRACT-006'])
g=json.loads(gun('history/774/native-aggregate-064.json.gz'));assert g['id']=='NATIVE-INITIAL05-GROUP-064'
for role,scope,context in [(27,[[849,870]],[[835,848],[871,880]]),(28,[[698,745]],[[685,697],[746,750]]),(29,[[460,505]],[[430,459]]),(30,[[182,262]],[[175,181],[263,300]])]:
 x=next(x for x in g['source_members'] if x.get('scope038_index')==role);assert x['scoped_ranges_compared']==scope and x['context_only_ranges']==context
prior=hist['prior_lock_packet_report_manifest'];manifest=json.loads((b/prior['MANIFEST.json']['preserved']).read_bytes());e=next(x for x in manifest['files'] if x['path']=='REPORT.json');assert e['sha256']==prior['REPORT.json']['sha256']
for n in ['REPORT.json','MANIFEST.json']:
 x=prior[n];raw=(b/x['preserved']).read_bytes();assert sha(raw)==x['sha256'] and len(raw)==x['bytes']
for x in hist['copied_prior_lock_evidence']:
 raw=(b/x['preserved']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
lreg=load('wgpu-lock-registration.json');inv=load('wgpu-lock-inventory.json');assert lreg['prior_registration_sha256']==sha((b/'lock-registration.json').read_bytes()) and inv['registration_sha256']==sha((b/'wgpu-lock-registration.json').read_bytes()) and datetime.fromisoformat(lreg['at_utc'])<datetime.fromisoformat(inv['at_utc']) and len(lreg['entries'])==len(inv['entries'])==8
for x,y in zip(lreg['entries'],inv['entries']):
 raw=(b/x['archive']).read_bytes();assert x['id']==y['id'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']==y['sha256'];packages=tomllib.loads(raw.decode())['package'];matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in packages if p['name'] in checks and p['version']=='29.0.4'];assert len(packages)==y['package_count'] and matches==y['matches'];expected=2 if x['git_path'] in ['Cargo.lock','crates/adventuresim-character-creator/Cargo.lock'] else 0;assert len(matches)==expected
 for p in matches:assert p['checksum']==checks[p['name']] and p['source']=='registry+https://github.com/rust-lang/crates.io-index'
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
assert len(proof['paths'])==28 and not proof['absent_paths']
coverage={}
for receipt in ['read-receipt.json','support-read-receipt.json','support-read-receipt-2.json']:
 r=load(receipt);name=r['registration'];assert r['registration_sha256']==sha((b/name).read_bytes()) and datetime.fromisoformat(groups[name]['at_utc'])<datetime.fromisoformat(r['at_utc'])
 for e in r['entries']:
  x=regs[(name,e['id'])];assert e['sha256']==x['sha256'];actual={i for a,z in e['actual_personal_display_ranges'] for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in e['unread_ranges'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage[e['id']]=actual
assert len(regs)==len(coverage)==13
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(e['id']==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','native_roles':roles,'personal_scopes':len(regs),'separate_duplicate_device_role_ids':True,'774_records_git_proved':len(hist['records_774']),'rig_selected_rows':'5 match except path, zero-based indices; separate exact variants preserved','prior_native_aggregate_scope':'semantic ranges distinguished from context','git_paths_proved':len(proof['paths']),'lockfiles_structurally_verified':8,'package_archives_and_members_verified':2,'bounded_lenses':13,'feature_resolution':'not inferred','gpu_device_build_test_fixture_product_execution_probe_validation':'not performed'},indent=2))
