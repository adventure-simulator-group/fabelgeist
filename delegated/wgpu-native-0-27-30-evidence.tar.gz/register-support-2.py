from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';es=[]
for name,path in [('validation-observation','crates/fabelgeist-gpu/src/globals/validation_observation.rs'),('validation-scope','crates/fabelgeist-gpu/src/globals/validation_scope.rs')]:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);dest='support/'+name+'.rs';(b/dest).write_bytes(raw);es.append({'id':name,'repo_kind':'project','revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),'bytes':len(raw),'eof':len(raw.splitlines()),'prospective_personal_read_ranges':[[1,len(raw.splitlines())]],'qualification':'Separate current support; no original-role credit or operation executed.'})
(b/'support-registration-2.json').write_text(json.dumps({'schema':'726-wgpu-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':es},indent=2)+'\n')
