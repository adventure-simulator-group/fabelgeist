# wgpu 29.0.4 roles 0 and 27–30

`REPORT.json` covers five independently registered native-package roles, their
bounded source windows, exact prior reviewer attribution, related existing GPU
error records, open policy questions and thirteen scoped perspectives. Roles 0
and 28 intentionally remain separate historical identities even though they use
identical `device.rs` bytes. Source outside registered displayed ranges is not
read credit. Native SDK declarations do not establish a GPU result.

The included `wgpu-29.0.4` and `wgpu-types-29.0.4` archives match the selected
historical and current root and character-creator lock checksums; every exact
member also matches the original registry and f82 recovered source object. The
other two enumerated locks at each revision do not select these versions. This
is a bounded lock inventory, not feature resolution or execution evidence.
Historical project pr-working state had unrelated modifications.

`history/` retains the original registry and transport manifest, mechanically
compressed historical 059 queue/ledger, original 774 reviewer records, prior
current assessments and the prior lock packet's report and manifest. The two
exact 774 supplier-list variants have distinct hashes and selected rows that
match except for `CARGO_REGISTRY` redaction versus absolute local paths. Registry
row positions are zero-based. The absolute-path variant is locally preserved and
requires separate privacy review before public reproduction. Historical native
aggregate reviewers' narrower semantic ranges remain distinct from their context
and from this author's displays. Missing checkpoint 3821 is not reconstructed.

`git-proofs.json` and `git-objects/` retain 28 project/transport path proofs;
package identities additionally use checksums and exact archive members. Run
`verify-evidence.py` and `verify-manifest.py` for evidence checks only. No GPU,
shader, device, product, fixture, build, test or runtime probe was executed.
