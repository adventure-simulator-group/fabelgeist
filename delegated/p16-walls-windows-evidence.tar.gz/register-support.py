from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[('crates/adventuresim-building-generator/src/spatial_geometry/orientation.rs',[(1,85)]),('crates/adventuresim-building-generator/src/audit/wall_openings.rs',[(1,100)]),('crates/adventuresim-building-generator/src/model/plan.rs',[(1,65)]),('crates/adventuresim-building-generator/src/model/resolved_shapes.rs',[(1,30),(340,390)]),('crates/adventuresim-building-generator/src/windows/spec.rs',[(1,120)]),('crates/AGENTS.md',[(1,86),(143,153)])]
entries=[]
for path,ranges in items:
 raw=subprocess.check_output(['git','show',rev+':'+path]);eof=len(raw.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/95e/'+path;p=b/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);oid=subprocess.check_output(['git','rev-parse',rev+':'+path],text=True).strip();entries.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':oid,'bytes':len(raw),'actual_eof':eof,'planned_ranges':ranges,'source_archive':dest,'purpose':'bounded related evidence; no original P16 role or other reviewer credit'})
r={'schema':'726-p16-walls-windows-support-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries};x=(json.dumps(r,indent=2)+'\n').encode();(b/'support-registration.json').write_bytes(x);print('registered',len(entries),'sha256',hashlib.sha256(x).hexdigest());print('\n'.join(f"{e['path']} EOF {e['actual_eof']} {e['planned_ranges']}" for e in entries))
