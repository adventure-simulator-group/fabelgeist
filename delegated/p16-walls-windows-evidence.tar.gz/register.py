from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');reg=json.load(gzip.open('<LOCAL_PATH_1>','rt'))['files'];entries=[];pending=[];f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';cur='95e63628f9d70b8dd6e6fede64334696c6995009'
for i in [2506,2507]:
 row=reg[i];p=row['source_id'].split(':',1)[1];archive='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256']
 for label,rev,gitpath in [('p16',f82,archive),('95e6',cur,p)]:
  raw=subprocess.check_output(['git','show',rev+':'+gitpath]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+gitpath],text=True).strip()
  if label=='p16':assert sha==row['sha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['actual_line_count']
  dest=f'sources/{label}/{p}';pending.append((dest,raw));entries.append({'original_role':i,'source_identity':'physical-p16 dirty snapshot' if label=='p16' else rev,'transport_revision':rev,'transport_path':gitpath,'path':p,'source_id_as_recorded':row['source_id'],'original_registry_locator':row['path'],'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_eof':len(raw.splitlines()),'planned_ranges':[[1,len(raw.splitlines())]],'original_material_ranges':row['material_ranges'] if label=='p16' else None,'source_archive':dest,'qualification':'F82 is archive transport only; P16 was recorded dirty based on a120. Prospective whole body includes separately accounted support beyond the original material role.'})
r={'schema':'726-p16-walls-windows-prospective-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries};x=(json.dumps(r,indent=2)+'\n').encode();(b/'registration.json').write_bytes(x)
for p,raw in pending:
 d=b/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('registration sha',hashlib.sha256(x).hexdigest());print(json.dumps(entries,indent=2))
