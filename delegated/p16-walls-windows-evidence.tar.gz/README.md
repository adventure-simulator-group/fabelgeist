# Bounded P16 wall and window evidence

This packet contains /root/rig_identity's bounded audit of original roles 2506
and 2507, separately registered P16 recovered source and pinned 95e current
source, eight bounded current support reads, thirteen scoped perspectives, and
conditional findings. Start with `REPORT.json`, `registration.json`, and
`personal-read-receipt.json`.

The P16 registry records a dirty snapshot based at a120. The f82 Git objects
are transport for recovered bytes. Both assigned objects match their individual
files at a120, 6533, and 95e; the original dirty patch bytes remain unrecovered
and this equality does not establish the state of the entire snapshot.

`historical-059/` and `historical-774/` contain unmodified historical records.
The registry and queue selections are explicitly reconstructed, not original
records. `prior-packets/` retains the complete independently authored collision
and door review packets with their manifests and original read receipts.
Historical evidence does not become checkpoint 3821 evidence or this reader's
prior read.

`git-proofs.json` and `git-objects/` provide raw commit/tree inclusion chains;
`evidence-verification.json` covers hashes, identities, citations, scoped
reads, and archival completeness only. `MANIFEST.json` inventories all packet
files. Run `python3 verify-manifest.py` on the frozen packet to check its
inventory. Run `python3 verify-evidence.py` only on a copied packet to repeat
structural checks: it rewrites that copy’s verification timestamp.
No product implementation, repair, build, test, fixture, UI, simulation, runtime
probe, or product validation was performed.
