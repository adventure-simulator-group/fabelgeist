# Bounded rand 0.9.5 source evidence, roles 2757–2760

This packet contains `/root/mhr_character`'s independent, static assessment of
four original rand 0.9.5 source roles, selected native helper text and selected
first-party consumers at project revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. `report.json` records findings,
nonfindings, open questions, original historical relationships and thirteen
bounded lens perspectives. Exact personal displays and unread complements are
in the source registration and receipt files; archived full bytes do not confer
whole-file read credit.

The original registry snapshot is `native-rand0.9.5`; no same-named project
snapshot table row exists. All four original object bytes are carried by f82
and match their respective members of the preserved `rand-0.9.5.crate`. Its
SHA-256 matches the 0.9.5 entries in both the 6533 and 95e project lockfiles.
The pinned first-party manifest directly requests alloc with default features
false, but this does not determine the aggregate Cargo feature graph. Rand
0.8.8 and 0.10.2 remain different version identities, not replacements for
this role. Native package source does not become project Git source.

Original 774 Root registrations and contract 014, 059 Lens11 personal reads,
and the separately registered line 416 extension retain their original
attributions and scope limits. Prior root L1 evidence at e275 and separate
95e assessments retain their own reviewers and revisions. Queue selections are
reconstructed from the preserved original 059 queue; no checkpoint 3821 or
whole-lens closure is inferred.

The bounded source proof covers the concrete constructed u64 weighted-index
and rejection-sampling route, including the separately inspected full-word and
widening-product bridges. Unread float, custom-weight, single-sample, SIMD and
feature-dependent deserialization paths remain open. Existing first-party
language-default, name-error and finite-float-range records are reconnected
without new unique counts. No native example, macro, dependency, fixture,
product, test, build or runtime probe was executed.

Run `python3 verify-evidence.py` for offline archive/member, checksum, record,
receipt and raw Git path integrity; `python3 verify-manifest.py` verifies every
packet member, including the nested native manifest. These are evidence-only
checks, not product validation.
