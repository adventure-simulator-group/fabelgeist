import gzip,hashlib,io,json,pathlib,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');src=pathlib.Path('<LOCAL_PATH_1>');m=json.loads((src/'MANIFEST.json').read_text());H=lambda b:hashlib.sha256(b).hexdigest()
for x in m['files']:
 b=(src/x['path']).read_bytes();assert (len(b),H(b))==(x['bytes'],x['sha256']),x['path']
out=p/'prior-web-medical-packet.tar.gz'
with out.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for f in sorted(src.rglob('*')):
    if f.is_file():
     b=f.read_bytes();ti=tarfile.TarInfo('726-delegate-web-medical/'+str(f.relative_to(src)));ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
(p/'prior-packet-index.json').write_text(json.dumps({'archive':out.name,'archive_sha256':H(out.read_bytes()),'source_manifest_sha256':H((src/'MANIFEST.json').read_bytes()),'manifest_entries_verified':len(m['files']),'qualification':'Complete earlier web-medical source-only packet preserved with its manifest, including prior-current web-data author /root/hair_ops and its gap-policy observation. Historical and prior reads remain theirs and provide no new personal credit.'},indent=2)+'\n');print('prior files verified',len(m['files']),'archive bytes',out.stat().st_size)
