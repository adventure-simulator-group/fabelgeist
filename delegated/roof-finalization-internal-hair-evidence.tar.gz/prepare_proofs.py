import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());names=['support-registration.json','support-registration-02.json'];sup=[x for n in names for x in json.loads((p/n).read_bytes())['sources']];hist=json.loads((p/'historical-manifest.json').read_bytes());objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for role in reg['roles']:
 for v in role['versions']:members.append({'revision':v['revision'],'git_path':role['path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob']})
 v=role['recovered'];members.append({'revision':v['archive_revision'],'git_path':v['archive_path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob'],'qualification':'f82 transport object only; not whole pr-working snapshot.'})
members+=sup
for x in hist['records']:
 if x['scope']=='native-original-f82':
  b=(p/x['copy']).read_bytes();members.append({'revision':x['revision'],'git_path':x['origin'],'local':x['copy'],'sha256':x['sha256'],'git_blob':blob(b),'qualification':'Original native producer record, no read-credit transfer.'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['git_path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==blob(b);proofs.append({'revision':s['revision'],'path':s['git_path'],'archive':s['local'],'commit_tree':root,'chain':chain,'blob':tree,'qualification':s.get('qualification')})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Per-file recovered source objects, 6533 and 95e memberships only; historical pr-working snapshot includes four unrelated dirty paths and is not claimed clean.','objects':objects,'proofs':proofs},indent=2)+'\n')
def comp(eof,w):
 a=set()
 for lo,hi in w:a.update(range(lo,hi+1))
 out=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in a and start is None:start=i
  if start is not None and (i==eof+1 or i in a):out.append([start,i-1]);start=None
 return out
reads=[]
for role in reg['roles']:
 i=role['original_index'];oe=role['versions'][0]['prospective_range'][1];ce=role['versions'][1]['prospective_range'][1];reads.append({'original_index':i,'historical_revision':role['versions'][0]['revision'],'historical_eof':oe,'historical_display_windows':[[1,oe]],'historical_unread_complement':[],'current_revision':role['versions'][1]['revision'],'current_eof':ce,'current_display_windows':[[1,ce]],'current_unread_complement':[],'recovered_archive_personal_display_windows':[],'qualification':'6533 and 95e copies personally displayed separately. Recovered object verified byte-equal, not separately displayed.','prior_personal_support':None})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration_sha256':sha((p/'registration.json').read_bytes()),'roles':reads,'qualification':'Historical 6533 and current 95e bodies separately displayed after registration. f82 transport copies only hash/Git verified.'},indent=2)+'\n')
r=[]
for s in sup:
 w=s['prospective_ranges'];r.append({'index':s['index'],'path':s['path'],'revision':s['revision'],'archive':s['local'],'sha256':s['sha256'],'eof':s['eof'],'actual_display_windows':w,'unread_complement':comp(s['eof'],w)})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in names],'reads':r,'qualification':'Only displayed support ranges credited; prior agent and prior own reads stay separate.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'support reads',len(sup))
