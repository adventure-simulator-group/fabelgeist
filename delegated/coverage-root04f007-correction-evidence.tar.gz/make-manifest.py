from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;rows=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and p!=b/'MANIFEST.json':
  raw=p.read_bytes();rows.append({'path':str(p.relative_to(b)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
d={'schema':'726-coverage-root04f007-correction-manifest-v1','created_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/hair_ops','files':rows,'exclusions':['Only top-level MANIFEST.json; nested manifests included.'],'qualification':'Evidence integrity only; not a product test or whole-lens or ledger closure.'}
(b/'MANIFEST.json').write_text(json.dumps(d,indent=2)+'\n')
print('files',len(rows),'total_bytes',sum(x['bytes'] for x in rows),'manifest_sha256',hashlib.sha256((b/'MANIFEST.json').read_bytes()).hexdigest())
