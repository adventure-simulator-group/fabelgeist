from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub='<LOCAL_PATH_0>';prev=Path('<LOCAL_PATH_1>');rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';h=lambda r:hashlib.sha256(r).hexdigest();records=[];objects={};proofs=[]
def store(raw,local,origin):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'local':local,'origin':origin,'sha256':h(raw),'bytes':len(raw)})
def oid(t,raw):return hashlib.sha1(t.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def save_obj(t,k):
 raw=subprocess.check_output(['git','-C',pub,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objects:
  local=f'git-objects/{k}.{t}.gz';p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'local':local}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise ValueError(n)
def prove(revision,path,local):
 raw=(b/local).read_bytes();tree=save_obj('commit',revision).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save_obj('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw);proofs.append({'revision':revision,'path':path,'local':local,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw)})
for n in ['REPORT.json','MANIFEST.json','read-receipt.json','source/2766-pr-working.rs','source/2766-95e6.rs']:
 store((prev/n).read_bytes(),'prior/'+n,str(prev/n))
paths=[('root-findings.jsonl','handoff/774/adler-original/audit/continuation/root/initial04-invariant-operations/findings.jsonl'),('root-contract-015.json','handoff/774/adler-original/audit/continuation/root/initial04-invariant-operations/contract-groups-015.json'),('native-contract-023.json','handoff/774/adler-original/audit/continuation/native/initial05-aggregate-states/contract-groups-023.json')]
for local,path in paths:
 raw=subprocess.check_output(['git','-C',pub,'show',rev+':'+path]);store(raw,local,'git:'+rev+':'+path);prove(rev,path,local)
for revision,path,local in [('6533e444fa37552927070cc8d8190907fd3b413e','crates/adventuresim-core/src/combat/coverage.rs','prior/source/2766-pr-working.rs'),('95e63628f9d70b8dd6e6fede64334696c6995009','crates/adventuresim-core/src/combat/coverage.rs','prior/source/2766-95e6.rs'),(rev,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/8bebf038e281f0b1529dd8008a42379c43eac3e0c2f9767d9a29606eb69ddced','prior/source/2766-pr-working.rs')]:prove(revision,path,local)
(b/'git-proofs.json').write_text(json.dumps({'objects':objects,'proofs':proofs},indent=2)+'\n')
prior=next(x for x in records if x['local']=='prior/REPORT.json');assert prior['sha256']=='c9eb1ba655cc50f1d0e98d8382a63156b2a47829c7da525c69930527c4c97ec1'
f=next(json.loads(s) for s in (b/'root-findings.jsonl').read_text().splitlines() if 'ROOT-INITIAL04-F007' in s);assert f['id']=='ROOT-INITIAL04-F007'
d={'schema':'726-additive-historical-reconciliation-v1','author':'/root/hair_ops','created_utc':datetime.now(timezone.utc).isoformat(),'correction':'The frozen prior role2766 report missed the exact historical ROOT-INITIAL04-F007 identity. Its current from_span bypass observation is an independent 95e reassessment of that existing first failure, not a newly counted finding. Preserve the source-level example, 059 Segovb 452 question and original old attributions; no automatic alias of unrelated consequences.','prior_report_sha256':prior['sha256'],'prior_manifest_sha256':'8540a7d57788da9f918164be00fc1c39028f3d366c290b587cc4e24a38226b9b','original_findings_record':'root-findings.jsonl, exact line id ROOT-INITIAL04-F007','source_id':f['source'],'historical_snapshot':'pr-working, 6533-based with unrelated dirty paths; per-file 6533 match independently proved','historical_reader':'Original root invariant-operations, fresh role2766 1–142 according to root-contract-015; camera original fresh post-registration 1–142 (premature 1–150 uncredited). Native aggregate-state contract023 consumed that finding, preserve its own scope and attribution.','current_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','qualification':'f82 is evidence transport, not historical source HEAD; no checkpoint3821 reconstruction, cross-lens read transfer, implementation or validation. Prior packet and extracted evidence remain unchanged.','records':records,'git_proofs':'git-proofs.json'}
(b/'REPORT.json').write_text(json.dumps(d,indent=2)+'\n');print('report_sha256',h((b/'REPORT.json').read_bytes()))
