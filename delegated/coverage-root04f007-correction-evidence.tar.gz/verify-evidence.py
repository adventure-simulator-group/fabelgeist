from pathlib import Path
import gzip,hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda p:json.loads((b/p).read_bytes());r=load('REPORT.json');g=load('git-proofs.json')
for x in r['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256']
assert h((b/'prior/REPORT.json').read_bytes())==r['prior_report_sha256'];assert h((b/'prior/MANIFEST.json').read_bytes())==r['prior_manifest_sha256']
manifest=load('prior/MANIFEST.json')['files']
for name in ['REPORT.json','read-receipt.json','source/2766-pr-working.rs','source/2766-95e6.rs']:
 m=next(x for x in manifest if x['path']==name);raw=(b/'prior'/name).read_bytes();assert h(raw)==m['sha256'] and len(raw)==m['bytes']
f=next(json.loads(s) for s in (b/'root-findings.jsonl').read_text().splitlines() if 'ROOT-INITIAL04-F007' in s);assert f['id']=='ROOT-INITIAL04-F007' and f['source']==r['source_id']
c=load('root-contract-015.json');x=next(x for x in c['source_roles'] if x['source_id']==r['source_id']);assert x['actual_read_ranges']==[[1,142]] and x['registration']=='CAMERA-INITIAL07-REG-003'
n=load('native-contract-023.json');x=next(x for x in n['source_members'] if x['source_id']==r['source_id']);assert 'Root04F007' in x['actual05_comparison'] and x['scoped_ranges_compared']==[[1,142]]
objects={}
for k,x in g['objects'].items():
 raw=gzip.decompress((b/x['local']).read_bytes());assert len(raw)==x['bytes'] and h(raw)==x['sha256'] and oid(x['type'],raw)==k;objects[k]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise ValueError(n)
for p in g['proofs']:
 tree=objects[p['revision']].splitlines()[0].split()[1].decode();assert tree==p['root_tree']
 for c in p['chain']:
  assert tree==c['tree'] and lookup(objects[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/p['local']).read_bytes();assert oid('blob',raw)==tree==p['blob'] and h(raw)==p['sha256']
if (b/'MANIFEST.json').exists():
 seen=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert h(raw)==x['sha256'] and len(raw)==x['bytes'];seen.add(x['path'])
 assert seen=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p!=b/'MANIFEST.json'}
print('PASS: exact original ROOT-INITIAL04-F007, root/native contracts, prior frozen report/manifest, source and 6 raw Git membership proofs; additive only, no product execution.')
