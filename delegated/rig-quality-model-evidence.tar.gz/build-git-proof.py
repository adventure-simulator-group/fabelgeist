import gzip,hashlib,json,pathlib,subprocess
b=pathlib.Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
objects={};commits={};proofs=[];absences=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();cur=root(rev);chain=[]
 for segment in path.split('/'):
  mode,child=entries(save('tree',cur))[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
def absence(rev,path):
 cur=root(rev);chain=[];parts=path.split('/')
 for i,segment in enumerate(parts):
  rows=entries(save('tree',cur))
  if segment not in rows:
   absences.append({'revision':rev,'path':path,'path_chain':chain,'absent_from_tree':cur,'missing_segment':segment,'unvisited_segments':parts[i+1:]});return
  mode,child=rows[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 raise AssertionError('claimed absent but present '+path)
for e in json.load(open(b/'old-registration.json'))['entries']:proof(e['revision'],e['path'],f"sources/cbbb/{e['path']}",'historical report-p17 assigned role')
for e in json.load(open(b/'current-registration.json'))['entries']:
 
 if e['status']=='absent_at_current':absence(e['revision'],e['path'])
 else:proof(e['revision'],e['path'],f"sources/95e6/{e['path']}",'current assigned role')
for name in ['support-registration.json','support2-registration.json','support3-registration.json']:
 for e in json.load(open(b/name))['entries']:proof(e['revision'],e['path'],f"support/{e['revision'][:4]}/{e['path']}",'bounded support or rule')
for e in json.load(open(b/'original-attribution.json'))['older_774_receipts']:proof(e['transport_revision'],e['transport_path'],e['preserved_bytes'],'774 historical transport record')
rev='6533e444fa37552927070cc8d8190907fd3b413e'
proof(rev,'crates/fabelgeist-mhr/src/model.rs','prior-mhr-model/historical-2321.rs','prior reviewer historical source; no read transfer')
proof(rev,'crates/fabelgeist-mhr/src/skel_state.rs','support/cbbb/crates/fabelgeist-mhr/src/skel_state.rs','historical source object equality only')
absence(rev,'crates/fabelgeist-mhr/src/model/tensor_upload.rs')
r={'schema':'726-rig-quality-model-git-proof-v1','commits':commits,'objects':objects,'paths':proofs,'absent_paths':absences,'qualification':'Raw commit/tree bytes prove membership and exact nonmembership. Full archived bytes do not grant read credit. Historical 774 f82 is transport, not checkpoint3821; 6533 source object equality is not whole dirty-tree state.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'git-proofs.json').write_bytes(raw);print('proofs',len(proofs),'absences',len(absences),'objects',len(objects),'SHA',sha(raw))
