from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');cur='95e63628f9d70b8dd6e6fede64334696c6995009';old='cbbbca08c89a8768926799371f54cf6057312e5e';m='crates/fabelgeist-mhr/src/';rig='crates/fabelgeist-rig/src/'
scopes={(old,m+'skel_state.rs'):([[1,21],[112,164]],[16,17,18,123,125,143,144,148,149,152,155,260,281,282,284,287]),(cur,m+'skel_state.rs'):([[1,21],[112,164]],[]),(cur,m+'model/rig.rs'):([[1,32]],[]),(cur,m+'model/upload.rs'):([[1,221]],[]),(cur,m+'character.rs'):([[25,75]],[19,33,34,35,37,48,54,75]),(cur,rig+'lib.rs'):([[35,100]],[48,52,57]),(cur,rig+'part.rs'):([[1,85]],[]),(cur,m+'character/skin.rs'):([[1,152]],[]),(cur,m+'character/skeleton.rs'):([[1,136]],[7,9,11,12,18,20,25,26,30,59,60,62,69,70,78,102,103,104,109,115,123,124,126,132]),(cur,rig+'table.rs'):([[1,108]],[]),(cur,'crates/AGENTS.md'):([[21,86],[141,153],[182,192]],[])}
entries=[]
for name in ['support-registration.json','support2-registration.json','support3-registration.json']:
 for e in json.loads((b/name).read_bytes())['entries']:
  displayed,snips=scopes[(e['revision'],e['path'])];n=e['actual_line_count'];covered={j for lo,hi in displayed for j in range(lo,hi+1)};missing=[];start=None
  for i in range(1,n+2):
   if i<=n and i not in covered:
    if start is None:start=i
   elif start is not None:missing.append([start,i-1]);start=None
  entries.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'actual_eof':n,'contiguously_displayed_body_ranges':displayed,'search_result_lines_outside_body_ranges':sorted(set(snips)-covered),'not_contiguously_displayed_ranges':missing,'scope':'Support/rule only. Search snippets are not full read coverage; unread ranges can include listed snippets.'})
assigned=[]
for f in ['old-registration.json','current-registration.json']:
 for e in json.loads((b/f).read_bytes())['entries']:
  assigned.append({'revision':e['revision'],'role':e['original_role'],'path':e['path'],'ranges':[] if e.get('status')=='absent_at_current' else [[1,e['actual_line_count']]],'registration':f,'qualification':e.get('status','historical present')})
r={'schema':'726-rig-quality-model-personal-display-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','assigned_personal_reads':assigned,'support_personal_reads':entries,'prior_qualification':'/root/mhr_character prior 6533 1–626 and 95e 1–474 model reads plus support scopes retain original authorship. This packet separately registered and read current 1–474; no earlier reviewer transfer.','patch_qualification':'Reconstructed complete rig-quality diff is archived and hashed; this assignment did not personally display all its unrelated path bodies. Assigned bodies were independently fully displayed.','execution':'Source displays/searches, symbolic math and evidence verification only; no product, model, GPU, build, test, probe, fixture or repair.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'personal-read-receipt.json').write_bytes(raw);print('receipt SHA',hashlib.sha256(raw).hexdigest(),'assigned',len(assigned),'support',len(entries))
