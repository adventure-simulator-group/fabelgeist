from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');old='cbbbca08c89a8768926799371f54cf6057312e5e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[(cur,'crates/fabelgeist-mhr/src/character/skin.rs')];entries=[];pending=[]
for rev,p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_maximum_range':[1,len(raw.splitlines())],'scope':'bounded producer, upload, or retained metadata support only; no assigned role credit'});pending.append((rev,p,raw))
r={'schema':'726-rig-quality-model-prospective-support-v3','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','entries':entries};(b/'support3-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for rev,p,raw in pending:
 d=b/'support'/rev[:4]/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support SHA',hashlib.sha256((b/'support3-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
