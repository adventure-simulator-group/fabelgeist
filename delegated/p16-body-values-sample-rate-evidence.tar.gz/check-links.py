import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=p/'historical-059';H=lambda b:hashlib.sha256(b).hexdigest()
def check(n,sha):
 n=n.replace('\\','/').removeprefix('target/726-audit-adler-20261027/');assert H((h/n).read_bytes())==sha,n
for n,i,fresh in [('READ-L11-416.json',2510,[]),('READ-L11-421.json',2557,[[1,43]])]:
 x=json.loads((h/'segovb'/n).read_text());r=next(z for z in x['sources'] if z['original_index']==i);assert r['fresh_personal_body_reads']==fresh;check(r['registration'],r['registration_sha256']);prior=r['same_lens_prior'];check(prior['receipt'],prior['receipt_sha256']);check(prior['entry']['registration'],prior['entry']['registration_sha256'])
for n,i,scope in [('READ-L12-853.json',2510,[[1,85],[124,147]]),('READ-L12-867.json',2557,[[1,86]])]:
 x=json.loads((h/'segovb'/n).read_text());check(x['proposal'],x['proposal_sha256']);assert not x['root_personal_rereads'];r=next(z for z in x['rows'] if z.get('original_index')==i);check(r['registration'],r['registration_sha256']);assert r['fresh_personal_body_reads']==scope
 if 'identity_specific_windows_qualification' in r:
  z=r['identity_specific_windows_qualification'];check(z['path'],z['sha256'])
 if 'validated_bundle' in x:check(x['validated_bundle']['path'],x['validated_bundle']['sha256'])
for x in json.loads((p/'prior-references.json').read_text())['packets']:
 o=pathlib.Path(x['prior_location']);assert H((o/x['manifest_name']).read_bytes())==x['manifest_sha256'];m=json.loads((o/x['manifest_name']).read_text());rows={v['path']:v for v in m['files']}
 for z in x['copies']:
  q=p/z['path'];assert H(q.read_bytes())==z['sha256']
  if q.name==x['report_name']:assert rows[x['report_name']]['sha256']==z['sha256']
result={'schema':'726-evidence-link-verification-v1','status':'passed','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'059 L11 original same-lens receipts and registration hashes, exact root fresh/reuse distinctions, delegated L12 proposals, registration and Windows qualification, and prior report/manifest hashes.','qualification':'Earlier source attributions retained; full prior packets hash-linked separately. Evidence verification only; no product validation.'};(p/'evidence-links-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
