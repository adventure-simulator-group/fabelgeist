import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());names=['support-registration.json','support-registration-02.json','support-registration-03.json'];sup=[x for n in names for x in json.loads((p/n).read_bytes())['sources']];hist=json.loads((p/'historical-manifest.json').read_bytes());(p/'git-objects').mkdir(exist_ok=True);objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for role in reg['roles']:
 for v in role['versions']:
  if v['present']:members.append({'revision':v['revision'],'path':role['path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob']})
 v=role['p16'];members.append({'revision':v['archive_revision'],'path':v['archive_path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob'],'qualification':'Archive transport, not P16 source revision or a complete dirty patch.'})
members+=sup
for x in hist['records']:
 if x['scope'] in ['adler-original-f82','prior-publication']:members.append({'revision':x['archive_revision'],'path':x['original_path'],'local':x['copy'],'sha256':x['sha256'],'git_blob':x['git_blob'],'qualification':x['scope']+' record; not product source or current read'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();proofs.append({'revision':s['revision'],'path':s['path'],'archive':s['local'],'commit_tree':root,'chain':chain,'blob':tree,'qualification':s.get('qualification')})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'P16 is a dirty recorded 159-path delta at a120, not a clean source commit. f82 only transports individual recovered objects and prior records; the whole recorded patch remains unrecovered. Per-file equality with 0393/a120/6533/95e does not reclassify snapshot identity.','objects':objects,'proofs':proofs},indent=2)+'\n')
def complement(eof,w):
 covered=set()
 for a,b in w:covered.update(range(a,b+1))
 missing=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in covered and start is None:start=i
  if start is not None and (i==eof+1 or i in covered):missing.append([start,i-1]);start=None
 return missing
reads=[]
for role,w,pw in [(reg['roles'][0],[[1,44]],[[1,68]]),(reg['roles'][1],[[1,30],[199,230],[250,320],[344,391],[393,428],[430,447]],[[1,90],[91,180],[181,270],[271,360],[361,447]])]:
 eof=role['p16']['prospective_range'][1];reads.append({'original_index':role['original_index'],'eof':eof,'p16_display_windows':pw,'p16_unread_complement':complement(eof,pw),'current_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','current_display_windows':w,'current_unread_complement':complement(eof,w),'0393_a120_6533_personal_display_windows':[],'qualification':'Test-source display is not test execution; old full P16 source display does not confer independent read of byte-identical 0393/a120/6533/current archived versions.'})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration_sha256':sha((p/'registration.json').read_bytes()),'roles':reads},indent=2)+'\n')
ranges={'furniture/finish.rs':[[1,115]],'detail/cuboids.rs':[[1,110],[120,175]],'detail/kit.rs':[],'collision.rs':[[1,100]],'audit/resolved_geometry.rs':[[1,40],[455,490]],'audit/resolved_geometry_helpers.rs':[[190,232],[245,272]],'lib.rs':[[38,62]],'lod.rs':[[80,165]],'generator/wall_assemblies.rs':[[330,400]],'detail.rs':[[15,30]],'furniture/builder.rs':[[1,155]],'spatial_geometry/orientation.rs':[[1,115]],'collision/cuboid.rs':[[1,65]]};r=[]
for s in sup:
 k=s['path'].split('/src/',1)[1];w=ranges[k];eof=s['registered_range'][1];r.append({'path':s['path'],'revision':s['revision'],'archive':s['local'],'sha256':s['sha256'],'eof':eof,'actual_display_windows':w,'unread_complement':complement(eof,w)})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in names],'reads':r,'qualification':'Support only, no ordered-role credit; token-only rg navigation confers no full-line read. All other archived ranges remain unread.'},indent=2)+'\n');print('proofs',len(proofs),'tree objects',len(objects),'support',len(sup))
