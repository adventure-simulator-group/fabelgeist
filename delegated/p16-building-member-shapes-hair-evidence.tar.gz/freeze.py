import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');rows=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='packet-manifest.json':
  b=f.read_bytes();rows.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m={'schema':'726-bounded-evidence-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file_count':len(rows),'files':rows,'qualification':'Recoverable packet only; prior evidence retains its origin and is not checkpoint3821.'};f=p/'packet-manifest.json';f.write_text(json.dumps(m,indent=2)+'\n');print('files',len(rows),'packet-manifest sha256',hashlib.sha256(f.read_bytes()).hexdigest(),'report sha256',hashlib.sha256((p/'report.json').read_bytes()).hexdigest())
