import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());reg=load('registration.json');rr=load('read-receipt.json');sr=load('support-read-receipt.json');proof=load('git-proofs.json');hist=load('historical-manifest.json');report=load('report.json');original=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));older=json.loads(gzip.decompress((p/'reference/older-774-handoff-manifest.json.gz').read_bytes()));registry=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()));queue=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()));
assert rr['prospective_registration_sha256']==sha((p/'registration.json').read_bytes());assert datetime.datetime.fromisoformat(reg['registered_utc'])<datetime.datetime.fromisoformat(rr['recorded_utc']);reads={}
def partition(eof,windows,unread):
 a=set();b=set()
 for lo,hi in windows:assert 1<=lo<=hi<=eof;a.update(range(lo,hi+1))
 for lo,hi in unread:assert 1<=lo<=hi<=eof;b.update(range(lo,hi+1))
 assert not a&b and a|b==set(range(1,eof+1));return a
for role,r in zip(reg['roles'],rr['roles']):
 idx=role['original_index'];assert idx==r['original_index'];v=role['p16'];b=(p/v['local']).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']==registry['files'][idx]['sha256']==catalog['rows'][idx]['expected_sha256'] and blob(b)==v['git_blob'];assert pathlib.Path(catalog['rows'][idx]['object']).read_bytes()==b;assert subprocess.check_output(['git','-C',repo,'show',v['archive_revision']+':'+v['archive_path']])==b
 assert r['0393_a120_6533_personal_display_windows']==[];partition(r['eof'],r['p16_display_windows'],r['p16_unread_complement']);reads[role['path']]=partition(r['eof'],r['current_display_windows'],r['current_unread_complement'])
 for s in role['versions']:
  assert s['present'];q=(p/s['local']).read_bytes();assert q==b and s['equals_p16'] and sha(q)==s['sha256'] and blob(q)==s['git_blob'] and len(q)==s['bytes'];assert subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+role['path']])==q
snapshot=next(x for x in registry['snapshots'] if x['id']=='physical-p16');assert snapshot['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snapshot['changed_variants']==159 and snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for f in sr['prospective_registrations']:assert sha((p/f['path']).read_bytes())==f['sha256'] and datetime.datetime.fromisoformat(load(f['path'])['registered_utc'])<datetime.datetime.fromisoformat(sr['recorded_utc'])
sup=[s for f in sr['prospective_registrations'] for s in load(f['path'])['sources']];assert len(sup)==len(sr['reads'])
for s,r in zip(sup,sr['reads']):
 b=(p/s['local']).read_bytes();assert s['path']==r['path'] and sha(b)==s['sha256']==r['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==r['eof'] and blob(b)==s['git_blob'];assert subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['path']])==b;reads[s['path']]=partition(r['eof'],r['actual_display_windows'],r['unread_complement'])
objs={}
for oid,o in proof['objects'].items():
 b=gzip.decompress((p/o['archive']).read_bytes());assert len(b)==o['bytes'] and sha(b)==o['sha256'] and hashlib.sha1(o['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
for q in proof['proofs']:
 assert objs[q['revision']].splitlines()[0].split()[1].decode()==q['commit_tree'];tree=q['commit_tree'];assert len(q['path'].split('/'))==len(q['chain'])
 for name,chain in zip(q['path'].split('/'),q['chain']):
  assert chain['tree']==tree and chain['name']==name;mode,tree=entries(objs[tree])[name];assert mode==chain['mode'] and tree==chain['object']
 assert tree==q['blob']==blob((p/q['archive']).read_bytes())
for o in hist['records']:
 b=(p/o['copy']).read_bytes();assert sha(b)==o['sha256'] and len(b)==o['bytes'] and blob(b)==o['git_blob']
 if o['scope'] in ['059','774']:
  index=original['entries'] if o['scope']=='059' else older['files'];match=next(x for x in index if x['path']==o['original_path']);assert match['bytes']==len(b) and match['sha256']==sha(b);assert o['scope']!='059' or match['git_blob']==blob(b)
 else: assert subprocess.check_output(['git','-C',repo,'show',o['archive_revision']+':'+o['original_path']])==b
assert not hist['unavailable']; assert queue['entries'][1935]['contract_id']=='Q-L12-63ce82a40701fd194206' and queue['entries'][1935]['status']=='open-evidence-or-disposition';assert len(report['lenses'])==13 and len(set(x['lens'] for x in report['lenses']))==13
base='historical/adler-original/';rig=load(base+'producer-reached-owner81/findings.jsonl') if False else [json.loads(l) for l in (p/base/'producer-reached-owner81/findings.jsonl').read_text().splitlines()];assert any(x['id']=='RIG-OWNER81-F002' for x in rig)
refs=[]
def visit(x):
 if isinstance(x,dict):
  if {'revision','path','lines'}<=x.keys():refs.append(x)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
for r in refs:
 assert r['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and r['path'] in reads
 for lo,hi in r['lines']:assert all(i in reads[r['path']] for i in range(lo,hi+1)),(r['path'],lo,hi)
y={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'exact_p16_role_objects_and_per_revision_git_comparisons':len(reg['roles']),'p16_recorded_dirty_snapshot_and_unrecovered_patch_qualification':True,'independent_commit_tree_membership_proofs':len(proof['proofs']),'support_source_objects_and_actual_read_partitions':len(sup),'preserved_historical_and_prior_publication_records':len(hist['records']),'current_references_within_actual_personal_windows':len(refs),'bounded_lens_perspectives':len(report['lenses']),'original_rig_owner81_f002_present':True,'old_059_q1935_identity_and_open_status':True},'qualification':'Evidence-integrity verification only. No product/geometry execution, tests, builds, probes, simulation or validation.'};(p/'evidence-verification.json').write_text(json.dumps(y,indent=2)+'\n');print(json.dumps(y,indent=2))
