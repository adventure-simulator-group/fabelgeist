# Bounded cloth triangulation source audit

Author: `/root/hair_ops`. Original registry roles 2633–2634. Working revision:
`95e63628f9d70b8dd6e6fede64334696c6995009`. The historical objects are
registered `pr-working` sources individually equal to
`6533e444fa37552927070cc8d8190907fd3b413e`; the containing historical
snapshot had unrelated changes. `f82adcabd9d89c4fa2dd7f99253a45297a0681ee`
is source transport, not their revision. Old and current bodies were
independently displayed after registration. The 6533 copies were compared,
not separately displayed. The separately located test body was not read or
executed.

`REPORT.json` gives thirteen bounded perspectives, source-backed observations,
conditions, historical relationships and open questions. `registration.json`,
`support-registration.json`, `read-receipt.json` and `git-proofs.json` retain
exact bytes, prospective scopes, actual displays and Git membership.
`historical-manifest.json` lists original 059 receipts and hash-linked earlier
records. Selected 059 queue rows are reconstructed selections, not recovered
checkpoint3821 records. Existing shell and mesh findings retain their original
reviewers. `signed-area-navigation.txt` is scoped text-search output only, not
source-read coverage. `MANIFEST.json` hashes every packet file.

Run `python3 verify-evidence.py` solely for evidence-integrity verification;
it reads hash-linked evidence dependencies and does not run or validate product
code. The resolution bound and signed-area observations require policy and
consumer decisions before any repair. No geometry, product, tests, builds or
runtime probes were executed.
