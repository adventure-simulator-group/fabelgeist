from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,shutil,subprocess
b=Path('<LOCAL_PATH_0>');prev=Path('<LOCAL_PATH_1>');old=Path('<LOCAL_PATH_2>');pub=Path('<LOCAL_PATH_3>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
for n in ['original-registry.json.gz','original-transport-manifest.json.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:shutil.copyfile(prev/n,b/n)
r=json.load(gzip.open(b/'original-registry.json.gz','rt'));sel={'schema':'726-registry-selection-reconstructed-v1','qualification':'Reconstructed selection from original 059; not an original historical record or checkpoint3821','original_registry_sha256_uncompressed':sha(gzip.decompress((b/'original-registry.json.gz').read_bytes())),'rows':[{'original_index':i,**r['files'][i]} for i in [2501,2502,2503,2508]],'snapshot':next(x for x in r['snapshots'] if x['id']=='physical-p16'),'unrecovered_patch':'Metadata SHA records P16 patch; original patch bytes remain unrecovered in this packet. Do not infer entire dirty state from matching individual base files.'};(b/'registry-selection-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n')
m=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in m['entries']};paths=[]
for lens,n in [(11,415),(12,850),(12,851)]:
 for k in ['READ','VERIFY','STATE']:paths.append(f'segovb/{k}-L{lens}-{n}.json')
for n in [1405,1406]:paths.append(f'segovb/REGISTRATION-SEGOVB-{n}.json')
for n,i in [(520,2502),(521,2503)]:paths += [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json',f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{n}-WINDOWS-ORIGINAL{i}.json']
for n in [850,851]:paths.append(f'parallel-l12-20261029/PROPOSAL-L12-{n}.json')
paths += ['evidence/audit11/successor-066.json','evidence/audit11/successor-094.json','parallel-l12-20261029/CLOSURE-QUEUE-PROPOSAL-PAR-L12-001.json']
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file():missing.append(p);continue
 raw=(old/p).read_bytes();e=idx[p];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(raw)==e['git_blob'];dst=b/'historical-059'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records.append({'original_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
prefix='handoff/774/adler-original/audit/continuation/';paths774=[prefix+'rig/owner-reached-producer-followup/'+n for n in ['additional-sources.jsonl','source-qualifications.jsonl','traces.jsonl','findings.jsonl','coverage.jsonl','coverage-errata.jsonl','findings-errata.jsonl']]+[prefix+'root/producer-followup-acceptance-028.json',prefix+'root/producer-scope-extension-authority-022.json',prefix+'native/producer-registry-reconciliation/candidate-002.json'];rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records774=[]
for p in paths774:
 raw=subprocess.check_output(['git','show',rev+':'+p]);assert oid(raw)==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();dst=b/'historical-774'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records774.append({'transport_revision':rev,'transport_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
previous=[]
for p in ['ASSESSMENT-L01-FURNITURE-SAFEGUARDS-95E.json','ASSESSMENT-L01-BELFRY-SHELL-95E.json','ASSESSMENT-L01-HISTORICAL-562-570.json','ASSESSMENT-L01-HISTORICAL-639-645.json']:
 raw=(pub/p).read_bytes();dst=b/'prior-publication'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);x=json.loads(raw);selected=[]
 for e in x.get('current_sources',[]):
  if e.get('path') in ['crates/adventuresim-building-generator/src/lod.rs','crates/adventuresim-building-generator/src/furniture/builder.rs']:
   src=e['preserved_bytes'];z=(pub/src).read_bytes();assert sha(gzip.decompress(z))==e['sha256'];target=b/'prior-publication'/src;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z);selected.append({'path':src,'compressed_sha256':sha(z),'uncompressed_sha256':e['sha256'],'ranges':e['ranges']})
 previous.append({'path':p,'sha256':sha(raw),'bytes':len(raw),'preserved_bytes':str(dst.relative_to(b)),'selected_source_archives':selected,'qualification':'Existing publication assessment; read provenance recorded there, recorder name not explicitly specified. Not this delegate\'s past read or checkpoint3821.'})
r={'schema':'726-original-attribution-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'original_059_records':records,'older_774_receipts':records774,'prior_publication_assessments':previous,'missing_originals':missing,'qualification':'Exact historical and current assessment bytes retain their own revisions/readers; no historical promotion or unqualified attribution transfer.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'original-attribution.json').write_bytes(raw);print('059',len(records),'774',len(records774),'prior',len(previous),'missing',missing,'sha',sha(raw))
