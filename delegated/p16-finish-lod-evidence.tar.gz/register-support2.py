from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-building-generator/src/furniture/key.rs','crates/adventuresim-building-generator/src/furniture/spec.rs'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();dest='support/95e6/'+p;pending.append((dest,raw));entries.append({'revision':rev,'path':p,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'actual_eof':len(raw.splitlines()),'planned_ranges':[[1,len(raw.splitlines())]],'source_archive':dest,'qualification':'Prospective producer admission support only; read subset recorded later.'})
r={'schema':'726-prospective-support-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries};x=(json.dumps(r,indent=2)+'\n').encode();(b/'support-registration-02.json').write_bytes(x)
for p,raw in pending:
 d=b/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('sha',hashlib.sha256(x).hexdigest(),'sizes',[(e['path'],e['actual_eof']) for e in entries])
