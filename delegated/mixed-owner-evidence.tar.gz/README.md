# Roles 2475, 2479 and 2480: mixed-snapshot source audit

This delegated packet preserves newly assessed source, original 059 records,
derived navigation selections and earlier 774 evidence separately. It does not
establish or reconstruct checkpoint 3821.

Role 2475 is from the clean rig-quality snapshot
`cbbbca08c89a8768926799371f54cf6057312e5e`, whose parent is
`6533e444fa37552927070cc8d8190907fd3b413e`. Roles 2479–2480 are from the
recorded pr-working 6533 snapshot, which lists four unrelated dirty paths.
Both building files match their 6533 Git blobs and the recovered snapshot hashes.
The pinned current revision is `95e63628f9d70b8dd6e6fede64334696c6995009`.
Raw Git commit/tree proof and exact revision bodies are included.

Both historical and current building owner files were personally displayed in
full. For rust-quality.toml only 1–225, 600–700 and 950–EOF were displayed
at each revision; 226–599 and 701–949 remain unread. Complete source bytes are
preserved. The whole-file TOML parse and line-difference navigation do not grant
personal display credit or constitute lint execution. Earlier e275 quality
readers and their full scopes remain separately attributed despite matching the
current file hash.

`report.json` records thirteen bounded perspectives and a conditional policy
candidate: TimberFrameMember documents member-local material for later repairs
and additions, while the joint audit requires each participant's material to
equal the frame default. The current builder supplies uniform material; no
supported mixed-material producer, runtime rejection or overall failure was
established. Default-empty participant deserialization and downstream validation
remain a separate open policy question. StoreyIndex rounding before below-ground
classification is documented behavior, not a demonstrated bug.

Original 059 records are checked against their transport manifest. Root 774
original and path-normalized exports, old storey/timber source copies, and the
595 historical summary retain their earlier revisions and reviewers. A separate
older rust-quality file has a different hash and is identified as earlier
nonmatching evidence, never as the cbbb file. `check-evidence.py` verifies
archive hashes, Git paths, actual-read ranges, old transport and TOML navigation;
no lint, test, build, product, probe, simulation or repair occurred.
