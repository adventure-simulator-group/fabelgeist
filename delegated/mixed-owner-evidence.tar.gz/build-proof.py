import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';regs=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json','support-registration-06.json'];supports=[x for n in regs for x in json.loads((p/n).read_text())['sources']];records=json.loads((p/'registration.json').read_text())['sources']+supports;objdir=p/'git-objects';objdir.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=objdir/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);out[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 assert tree==x['git_blob_sha1'];b=(p/x['archive']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'revision':rev,'path':x['path'],'archive':x['archive'],'commit_tree':root,'chain':chain,'blob':tree})
absences=[]
for x in json.loads((p/'registration.json').read_text())['absent']:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[];parts=x['path'].split('/')
 for name in parts[:-1]:
  mode,child=entries(get('tree',tree))[name];assert mode in ('40000','040000');chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 parent=get('tree',tree);assert parts[-1] not in entries(parent)
 absences.append({'revision':rev,'path':x['path'],'commit_tree':root,'parent_chain':chain,'parent_tree':tree,'missing_name':parts[-1]})
(p/'git-absence-proofs.json').write_text(json.dumps({'qualification':'Raw Git trees prove path nonmembership; this is not another revision body read.','proofs':absences},indent=2)+'\n')
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw Git commit/tree objects and exact source bytes verify revision/path membership only, not personal display credit.','objects':objects,'proofs':proof},indent=2)+'\n')



import datetime
registration=json.loads((p/'registration.json').read_text());rows=[]
for x in registration['sources']:
 if x['original_role']==2475:
  ranges=[[1,100],[101,200],[201,225],[600,700],[950,x['lines']]];union=[[1,225],[600,700],[950,x['lines']]];unread=[[226,599],[701,949]];deviation='Only chosen windows including all actual changed hunks were displayed; remainder is unread despite original full registration.'
 else:
  ranges=x['planned_display_chunks'];union=[[1,x['lines']]];unread=[];deviation='none'
 rows.append({'revision':x['revision'],'path':x['path'],'archive':x['archive'],'role':x['original_role'],'actual_display_ranges':ranges,'actual_display_union':union,'unread_ranges':unread,'full_body_displayed':not unread,'planned_deviation':deviation})
(p/'read-receipt.json').write_text(json.dumps({'schema':'726-assigned-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest(),'reads':rows,'qualification':'Only listed ranges personally displayed. Whole-file TOML parse and metadata-only comparison are derived navigation, not body-read credit; no lint/tests run.'},indent=2)+'\n')
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'path':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in regs],'reads':[{'path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':x['planned_ranges']} for x in supports],'qualification':'Only listed support ranges displayed; no ordered-role credit.'},indent=2)+'\n')
print('proofs',len(proof),'objects',len(objects),'support',len(supports))
