import datetime,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');old=json.loads((p/'support-registration.json').read_text())['sources'];spec=[(3,[[1,42],[340,405]]),(4,[[1,35],[200,225]])];rows=[]
for i,(j,ranges) in enumerate(spec,7):
 x=dict(old[j]);x['archive']=f'source/support-{i}.rs';x['planned_ranges']=ranges;(p/x['archive']).write_bytes((p/old[j]['archive']).read_bytes());rows.append(x)
(p/'support-registration-03.json').write_text(json.dumps({'schema':'726-support-prospective-v1','agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Trace initial material producer and joint-audit scope; source inspection only.','sources':rows},indent=2)+'\n')
