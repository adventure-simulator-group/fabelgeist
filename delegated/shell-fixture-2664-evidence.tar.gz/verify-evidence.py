#!/usr/bin/env python3
"""Check evidence integrity, recorded registration/read scopes and history; no fixture or product validation."""
import gzip,hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['timestamp_utc'] and len(receipt['actual_displays'])==2
for x in receipt['actual_displays']:
 row=next(y for y in r['rows'] if y['original_index']==x['role']);o=next(y for y in row['objects'] if y['label']==x['revision']);b=(p/o['local_file']).read_bytes();assert sha(b)==o['sha256'] and len(b.splitlines())==o['eof'];covered=set()
 for a,z in x['ranges']:covered.update(range(a,z+1))
 assert covered==set(range(1,o['eof']+1)) and not x['unread']
assert r['rows'][0]['objects'][0]['sha256']==r['rows'][0]['registry_entry']['sha256']==r['rows'][0]['objects'][1]['sha256']
checks.append('Distinct historical/current fixture bytes and recorded complete actual text windows; per-file identity only')
for reg,rec,expected in [('support-registration.json','support-read-receipt.json',5),('pair-registration.json','pair-read-receipt.json',1)]:
 sr=load(reg);s=load(rec);assert s['registration_sha256']==sha((p/reg).read_bytes()) and sr['at']<s['at'] and len(s['reads'])==expected
 for x in s['reads']:
  b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof']
  assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['prospective_ranges']==x['actual_ranges'] and y['file']==x['source_file'] for y in sr['rows'])
  cov={i for a,z in x['actual_ranges'] for i in range(a,z+1)};unread={i for a,z in x['unread_for_this_registration'] for i in range(a,z+1)};assert not cov & unread and cov|unread==set(range(1,x['eof']+1))
checks.append('Six bounded current support reads registered before display and exact complements recorded')
arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==r['registry_uncompressed_sha256'];registry=json.loads(orig)
 trans=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in trans['entries']}
for x in r['rows']:assert x['registry_entry']==registry['files'][x['original_index']]
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==32 and sum(x['kind']=='historical-774' for x in hi['records'])==5
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original registry, thirty-two exact 059 records and five 774 records retain transport identity')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==14
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Fourteen raw commit/tree/blob chains prove source identities and f82 transport membership')
part1=load('history-059/READ-L11-435-PARTIAL-001.json');part2=load('history-059/READ-L11-435-PARTIAL-002.json');finish=load('history-059/READ-L11-435.json');row=next(x for x in finish['sources'] if x['original_index']==2664)
assert part1['assessed_union']==[[1,1440]] and part1['unread']==[[1441,4396]] and part2['assessed_union_with_predecessor']==[[1,2880]] and part2['unread']==[[2881,4396]] and part1['at']<part2['at']<finish['at'] and len(row['actual_windows'])==25
assert {i for a,z in row['actual_windows'] for i in range(a,z+1)}==set(range(1,4397))
prop=load('history-059/PROPOSAL-L12-921.json');adopt=load('history-059/READ-L12-921.json');assert adopt['root_personal_rereads']==[] and len(prop['partial_read_receipts'])==23
windows=[]
for x in prop['partial_read_receipts']:
 b=(p/'history-059'/pathlib.Path(x['path']).name).read_bytes();assert sha(b)==x['sha256'];part=json.loads(b);row=part['rows'][0];assert '/root/lens12_frontier' in row['attribution'] and row['registered_at']<part['at'] and row['frozen_git_revision']=='6533e444fa37552927070cc8d8190907fd3b413e';windows.extend(row['fresh_personal_body_reads'])
assert len(windows)==23 and sum(z-a+1 for a,z in windows)==4396 and {i for a,z in windows for i in range(a,z+1)}==set(range(1,4397))
old=gzip.decompress((p/'history-774/additional-contracts.jsonl.gz').read_bytes()).splitlines();entry=json.loads(old[112]);assert entry['id']=='RIG-ADMISSION03-ADDITIONAL-127' and 'reread after truncated output' in entry['current_admission_comparison']
old=gzip.decompress((p/'history-774/source-range-registration.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[126])['id']=='RIG-ADMISSION03-REG-127';assert 'original-contact-native-word-fixture' in json.loads(gzip.decompress((p/'history-774/contracts-014.json.gz').read_bytes()))['groups']
checks.append('Original 774 truncation/reread and independent 059 Lens11 and Lens12 chronology and authorship')
assert sha((p/'prior-current/MANIFEST.json').read_bytes())=='a2961d869c06ee286d15ef85f4e223ed842835342d29e252e4edadc64bd6b9fb';prev=load('prior-current/MANIFEST.json');prevfiles={x['path']:x for x in prev['files']}
for name in ['REPORT.json','registration.json','support-registration.json','extra-registration.json','personal-read-receipt.json']:
 b=(p/'prior-current'/name).read_bytes();e=prevfiles[name];assert (len(b),sha(b))==(e['bytes'],e['sha256'])
prevreceipt=load('prior-current/personal-read-receipt.json');assert prevreceipt['author']=='/root/rig_identity'
fixture_reads=[x for x in prevreceipt['reads'] if x.get('sha256')=='6660cc916030d6d4ac23b18ea228ebdeceeb96802dddc6c503b6b907e07e05e8'];windows=[w for x in fixture_reads for w in x['actual_display_ranges']];assert sorted(windows)==[[1,60],[1711,1832],[4330,4396]]
links=load('published-links.json')['links']
for x in links:
 b=(pub/x['publication_relative_path']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
assert next(x for x in links if x['publication_relative_path']=='delegated/shell-xpbd-test-sources-report.json')['sha256']==sha((p/'prior-current/REPORT.json').read_bytes())
checks.append('Previously published /root/rig_identity support scopes and report verified without transfer of read credit')
q=load('queue-selection-reconstructed.json');queuebytes=(pub/'baseline-059/queue.json').read_bytes();assert sha(queuebytes)==q['source_sha256'];queue=json.loads(queuebytes)
for idx,x in q['entries'].items():assert queue['entries'][int(idx)]==x
assert q['entries']['445']['contract_id']=='SEGOVB-L12-CONNECTED-SURFACE-SOLVE-MASS-VALIDITY-ADMISSION' and q['entries']['3440']['contract_id']=='L12-CLOSURE-CONTACT-FIXTURE-NATIVE-GRAMMAR'
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14)) and report['support_reads']==load('support-read-receipt.json')['reads']+load('pair-read-receipt.json')['reads']
recovery=json.loads((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes());assert sha((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007' and sha((pub/recovery['recovered_patch']['path']).read_bytes())==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
checks.append('Selected 059 queue entries, thirteen bounded lenses, rules and separate P16 recovery hash links')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and recorded scope only. Fixture text was not parsed through product code, executed or validated. No product execution, testing, build, probe, simulation, implementation, publication edit, whole-lens closure or checkpoint3821 promotion.'},indent=2))
