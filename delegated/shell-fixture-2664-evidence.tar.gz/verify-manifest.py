import pathlib,hashlib,json
p=pathlib.Path(__file__).parent;m=json.loads((p/'BUNDLE-MANIFEST.json').read_bytes());files={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f.name!='BUNDLE-MANIFEST.json'};assert len(m['files'])==m['file_count'] and files=={x['path'] for x in m['files']}
for x in m['files']:
 b=(p/x['path']).read_bytes();assert (len(b),hashlib.sha256(b).hexdigest())==(x['bytes'],x['sha256'])
print('PASS: manifest member bytes and scope; no product or fixture validation')
