# Native Eidolon roles 31–38: bounded source packet

`REPORT.json` records eight independently registered, personally displayed full
native source roles and thirteen scoped lens perspectives. Two source-level
historical questions concern zero-width fade arithmetic and generic shader
normal transforms; additional global-camera, existing allocator and culling
questions remain open. The source does not establish a current 95e product
failure, a whole-lens clearance, or a device or shader outcome.

The package revision is native Git `1a5aff8d4809287e5f5713fb4cf72181b2285fff`,
not project Git. The earlier retained lock inventory proves that 6533's root
lock selects it and that four specifically enumerated tracked 95e lockfiles do
not. This does not resolve features, targets, external builds or runtime use.
The historical pr-working snapshot had unrelated modifications. The earlier
lock registration, inventory and eight full lock bytes remain separately
attributed; 46 independent Git path proofs and an exact 95e path absence are
retained here.

`registration.json`, `support-registration*.json` and their read receipts record
exact prospective and personally displayed partitions. Full archived bytes
outside those ranges are not reading credit. Naga Oil 0.22.0's source is bound
to the exact package archive checksum selected in the historical root lock, and
members are checked against the archive; selected composer source is inspected
as text only.

`history/` retains the original registry, 059 manifest and mechanically
compressed 059 queue/ledger summaries, historical 774 reviewer records, prior
report/manifest identities and current grass assessment. The two exact 774 rig
owner source-list variants have different whole-file hashes. Their eight
selected rows agree except for redacted versus original absolute local paths;
registry row positions are zero-based. The original-path variant is retained
locally and needs separate privacy review before public reproduction. No record
is promoted into missing checkpoint 3821.

`verify-evidence.py` and `verify-manifest.py` perform integrity and source-scope
checks only. Shader/native/product code, builds, tests, fixtures, devices,
renderers and runtime probes were not executed.
