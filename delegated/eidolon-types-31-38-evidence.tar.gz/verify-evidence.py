from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tomllib,tarfile
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');report=load('REPORT.json');names=['registration.json']+[f'support-registration{x}.json' for x in ['', '-2','-3','-4']];groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858'
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==list(range(31,39))
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
package=b/'support/naga_oil-0.22.0.crate';assert sha(package.read_bytes())=='319f03062940ed85c03da020042618356bb8ca5263020322930883b05e30208e'
for (_,id),x in regs.items():
 source=x.get('source_copy',x['archive']);d=(b/source).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
 if x.get('repo_kind')=='crate-archive':
  with tarfile.open(package) as tar: assert tar.extractfile(x['member_path']).read()==d
 else:assert oid('blob',d)==x['git_blob']
for i in range(31,39):
 x=regs[('registration.json',str(i))];r=registry['files'][i];assert x['sha256']==r['sha256'] and x['prospective_personal_read_ranges']==r['owner_contract_proofs'][0]['read_ranges'] and x['native_revision']=='1a5aff8d4809287e5f5713fb4cf72181b2285fff'
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];selection=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in selection['entries']]==[1313,1314,1315]
for x in selection['entries']:assert x['entry']==q[x['original_index_zero_based']]
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
a=[json.loads(z) for z in gun('history/774/rig-owner-redacted.jsonl.gz').splitlines()];c=[json.loads(z) for z in gun('history/774/rig-owner-original-paths.jsonl.gz').splitlines()];assert sha(gun('history/774/rig-owner-redacted.jsonl.gz'))!=sha(gun('history/774/rig-owner-original-paths.jsonl.gz'))
for x in hist['selected_rig_variant_comparisons']:
 r=registry['files'][x['role']];j=r['owner_contract_proofs'][0]['row'];assert x['registry_row_zero_based']==j and x['physical_line_1based']==j+1;u,v=a[j],c[j];assert u['source_id']==v['source_id']==r['source_id'] and u['observed_sha256']==v['observed_sha256']==r['sha256'] and u['read_ranges']==v['read_ranges']==r['owner_contract_proofs'][0]['read_ranges'] and {k:w for k,w in u.items() if k!='path'}=={k:w for k,w in v.items() if k!='path'} and u['path']=='LOCAL_PATH_REDACTED' and v['path']==x['original_path']
for path,id in [('history/774/rig-owner-contracts.jsonl.gz','RIG-OWNER-EIDOLON-LITTER-055'),('history/774/camera-contracts.jsonl.gz','CAMERA-INITIAL07-CONTRACT-009'),('history/774/root-findings.jsonl.gz','ROOT-INITIAL04-F053')]:assert any(json.loads(z).get('id')==id for z in gun(path).splitlines())
a=[json.loads(z) for z in gun('history/774/rig-admission-contracts.jsonl.gz').splitlines()]
for i in range(31,39):
 x=next(x for x in a if x.get('id')==f'RIG-ADMISSION03-CONTRACT-{i-9:03d}');assert x['source_id']==registry['files'][i]['source_id'] and x['actual_read_ranges']==registry['files'][i]['owner_contract_proofs'][0]['read_ranges']
g=json.loads(gun('history/774/native-aggregate-068.json.gz'));assert g['id']=='NATIVE-INITIAL05-GROUP-068';assert {x['scope040_index'] for x in g['source_members']}==set(range(31,39))
for p in hist['prior_reports_manifests']:
 for name in [p['report_name'],p['manifest_name']]:
  x=p[name];raw=(b/x['preserved']).read_bytes();assert sha(raw)==x['sha256'] and len(raw)==x['bytes']
 manifest=json.loads((b/p[p['manifest_name']]['preserved']).read_bytes());entry=next(x for x in manifest['files'] if x['path']==p['report_name']);assert entry['sha256']==p[p['report_name']]['sha256']
for x in hist['copied_prior_lock_evidence']:
 raw=(b/x['preserved']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
lreg=load('lock-registration.json');inv=load('lock-inventory.json');assert inv['registration_sha256']==sha((b/'lock-registration.json').read_bytes()) and datetime.fromisoformat(lreg['at_utc'])<datetime.fromisoformat(inv['at_utc']) and len(lreg['entries'])==len(inv['entries'])==8
for x,y in zip(lreg['entries'],inv['entries']):
 raw=(b/x['archive']).read_bytes();assert x['id']==y['id'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']==y['sha256'] and oid('blob',raw)==x['git_blob'];doc=tomllib.loads(raw.decode());packages=doc.get('package',[]);matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in packages if p['name']=='bevy_eidolon'];consumers=[p['name'] for p in packages if any(a.split(' ',1)[0]=='bevy_eidolon' for a in p.get('dependencies',[]))];assert len(packages)==y['package_count'] and matches==y['matches'] and consumers==y['consumer_names']
 if x['revision'].startswith('95e'):assert matches==[]
 if x['id']=='6533e44:Cargo.lock':
  n=next(p for p in packages if p['name']=='naga_oil' and p['version']=='0.22.0');assert n['checksum']==sha(package.read_bytes())
old=next(x for x in inv['entries'] if x['id']=='6533e44:Cargo.lock');assert old['matches']==[{'name':'bevy_eidolon','version':'0.5.0','source':'git+https://github.com/barsoosayque/bevy_eidolon?branch=fablegeist-0.19#1a5aff8d4809287e5f5713fb4cf72181b2285fff','checksum':None}]
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
for x in proof['absent_paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');chain=x['path_chain_to_parent']
 for name,s in zip(parts,chain):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 assert x['parent_tree']==cur and parts[len(chain)]==x['missing_segment'] and x['missing_segment'] not in entries(objects[cur])
assert len(proof['paths'])==46 and len(proof['absent_paths'])==1
coverage={}
for receipt in ['read-receipt.json']+[f'support-read-receipt{x}.json' for x in ['', '-2','-3','-4']]:
 r=load(receipt);name=r['registration'];assert r['registration_sha256']==sha((b/name).read_bytes()) and datetime.fromisoformat(groups[name]['at_utc'])<datetime.fromisoformat(r['at_utc'])
 for e in r['entries']:
  x=regs[(name,e['id'])];assert e['sha256']==x['sha256'];actual={i for a,z in e['actual_personal_display_ranges'] for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in e['unread_ranges'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage[e['id']]=actual
assert len(regs)==len(coverage)==25
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(e['id']==x['id'] and e['sha256']==x['sha256'] and e.get('source_copy',e['archive'])==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','native_roles':list(range(31,39)),'personal_scopes':len(regs),'774_records_git_proved':len(hist['records_774']),'rig_selected_rows':'8 match except path, zero-based indices; distinct exact transport variants preserved','git_paths_proved':len(proof['paths']),'git_tree_absences_proved':len(proof['absent_paths']),'prior_reports_manifest_hashes_linked':len(hist['prior_reports_manifests']),'locks_structurally_verified':8,'naga_oil_archive_checksum_and_members_verified':True,'bounded_lenses':13,'feature_resolution':'not inferred','wgsl_gpu_build_test_fixture_product_execution_probe_validation':'not performed'},indent=2))
