# Bounded collision test-source evidence

This packet records `/root/rig_identity`'s independent source-only review of
original registry roles 2650 (`fabelgeist-physics/src/contact/tests.rs`) and
2651 (`fabelgeist-physics/src/contact/count/tests.rs`). It provides thirteen
bounded perspectives and context for the connected audit. It does not prove
that tests passed, establish whole-lens completion, or add unique ledger
counts.

The recorded `pr-working` snapshot has head
`6533e444fa37552927070cc8d8190907fd3b413e` and four unrelated status entries.
Each selected file object independently equals its respective file at that
head and pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Revision
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports recovered evidence; it
is not a project revision. Raw Git commit, tree and blob proofs are in
`git-proofs.json` and `git-objects/`.

Both historical and current role bodies were independently displayed in full
following prospective registration: lines 1–54 for role 2650 and 1–19 for role
2651. The current count, contact, collider and fixture-text support was
separately registered; `personal-read-receipt.json` records exact displayed
chunks and unread complements. The fixture's Git object is the same at 6533
and 95e, but no historical personal fixture read is claimed. Original 774
ADD107 explicitly leaves its body unread. The 059 Lens11 receipt does not name
an individual reader. Its Lens12 historical reads belong to
`/root/lens12_frontier`, with zero root rereads; earlier current reviewer scopes
are retained separately.

The 64-bit fixture contains expectations for narrowing very large counts that
relate to existing q479, not proof of safe allocation or a new finding. The
source test for a mismatch in `update_colliders` covers a different path from
existing q480's possible partial state when `set_colliders` cannot replace a
buffer. The earlier current packet narrowed q480 to a symbolic zero-capacity
case; it did not prove the older hypothesis of capacity exceeding the retained
buffer. The ordinary packing assertion uses the same production packer to form
its expected bytes, so it does not independently specify the word layout.
All observations are source-only and retain their stated conditions.

`registry-selection-reconstructed.json` and
`queue-selection-reconstructed.json` are selected reconstructed records, not
original standalone files. The 059 records in `historical-059/` are exact
bytes checked against the recovered original transport manifest. Historical
774 records and earlier assessments are hash-linked in `evidence-links.json`.
`published-prior-packet-links.json` verifies only the listed selected members
against published archives; it does not assert every archive member is an
exact original. These published bundles and exact prior packets are dependencies
of the full verifier.

The separate P16 dirty snapshot is based on `a120390947c89b703dc74c4255a13c035d054c50`;
that base is not the dirty snapshot's commit. Its later recovered tracked
patch matches the recorded hash, with seven untracked files separate; matching
bytes do not establish the original diff invocation or uninterrupted custody.
This packet does not recover or promote the checkpoint 3821 ledger or queue.

Run `python3 verify-evidence.py` to verify source/evidence integrity,
provenance and ranges; run `python3 verify-manifest.py` to check frozen packet
files. These are evidence-only checks. No test, fixture execution, product,
GPU, shader, simulation, build or runtime probe was performed.
