from pathlib import Path
from datetime import datetime, timezone
import subprocess, hashlib, json
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009'; sha=lambda d:hashlib.sha256(d).hexdigest()
plans=[('crates/fabelgeist-physics/src/contact.rs','support/contact.rs',[[1,132]],[[1,66],[67,132]]),('crates/fabelgeist-physics/src/contact/count.rs','support/count.rs',[[1,55]],[[1,55]]),('crates/fabelgeist-physics/src/collider.rs','support/collider.rs',[[1,90],[210,218]],[[1,45],[46,90],[210,218]]),('crates/fabelgeist-physics/tests/fixtures/collider-capacity.txt','support/collider-capacity.txt',[[1,11]],[[1,11]])]
rows=[]
for path,dest,ranges,chunks in plans:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]); eof=len(raw.splitlines()); assert all(1<=a<=z<=eof for a,z in chunks)
 (b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(raw)
 rows.append({'kind':'connected current support, source text only','revision':rev,'path':path,'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path]).decode().strip(),'sha256':sha(raw),'bytes':len(raw),'eof':eof,'archive':dest,'registered_ranges':ranges,'planned_chunks':chunks})
r={'schema':'726-physics-contact-test-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'Prospective source-only connected support; fixture text is not executed. No ordered role or other reviewer read credit.'};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((b/'support-registration.json').read_bytes()));print(json.dumps(rows,indent=2))
