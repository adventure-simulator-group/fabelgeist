from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,sys,tarfile
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads(Path(p).read_bytes());gun=lambda p:gzip.decompress(Path(p).read_bytes())
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
def objects(proof,base):
 result={}
 for k,x in proof['objects'].items():
  d=gun(base/x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;result[k]=d
 for rev,x in proof['commits'].items():assert result[rev].splitlines()[0].split()[1].decode()==x['root_tree']
 return result
def paths(proof,objs,base,selected):
 for x in selected:
  cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
  for name,s in zip(parts,x['path_chain']):
   assert s['tree']==cur and s['name']==name;mode,child=entries(objs[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
  p=base/x['preserved_bytes'];d=gun(p) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
for x in load(b/'evidence-links.json')['links']:
 d=Path(x['path']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes'],x['path']
orig_raw=gun(pub/'recovered/original-registry-source-archive/registry.json.gz');assert sha(orig_raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';orig=json.loads(orig_raw);sel=load(b/'registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2650,2651]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==orig['files'][x['original_index']]
for x in sel['snapshots']:assert x in orig['snapshots']
pr=next(x for x in orig['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
p16=next(x for x in orig['snapshots'] if x['id']=='physical-p16');assert p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256'] and recovery['recovered_patch']['bytes']==524542 and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7};assert sha((pub/recovery['recovered_patch']['path']).read_bytes())==p16['patch_sha256']
reg=load(b/'registration.json');rec=load(b/'personal-read-receipt.json');report=load(b/'REPORT.json')
for x in reg['roles']:
 d=(b/x['archive']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes'] and len(d.splitlines())==x['eof']
 if x['label']=='historical-f82':
  z=orig['files'][x['role']];assert x['sha256']==z['sha256'] and x['original_material_ranges']==z['material_ranges'] and x['matches_6533_per_file'] and not x['recorded_pr_status_for_file'];assert not any(t[3:]==x['path'] for t in pr['status_porcelain'])
for i,eof in [(2650,54),(2651,19)]:
 assert orig['files'][i]['material_ranges']==[[1,eof]] and (b/f'sources/{i}-historical-f82.rs').read_bytes()==(b/f'sources/{i}-current-95e.rs').read_bytes()
q=load(pub/'baseline-059/queue.json')['entries']
for x in load(b/'queue-selection-reconstructed.json')['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert [q[i]['contract_id'] for i in [435,479,480]]==['SEGOVB-L12-PHYSICS-COLLIDER-UPDATE-COUNT-REASON','SEGOVB-L12-CONNECTED-PHYSICS-COLLIDER-NATIVE-COUNT-ADMISSION','SEGOVB-L12-CONNECTED-PHYSICS-COLLIDER-CAPACITY-ERROR-STATE']
mi=json.loads(gun(pub/'recovered/original-transport-manifest.json.gz'));idx={x['path']:x for x in mi['entries']};at=load(b/'historical-attribution.json');assert not at['missing'] and len(at['records_059'])==13
for x in at['records_059']:
 d=(b/x['preserved_bytes']).read_bytes();m=idx[x['original_path']];assert sha(d)==x['sha256']==m['sha256'] and len(d)==x['bytes']==m['bytes'] and oid('blob',d)==x['git_blob']==m['git_blob']
l11=load(b/'historical-059/segovb/READ-L11-433.json');l12=load(b/'historical-059/segovb/READ-L12-914.json');assert l12['root_personal_rereads']==[]
for i in [2650,2651]:
 x=next(x for x in l11['sources'] if x['original_index']==i);y=next(x for x in l12['rows'] if x['original_index']==i);expected=orig['files'][i]['material_ranges'];assert x['fresh_personal_body_reads']==y['fresh_personal_body_reads']==expected and '/root/lens12_frontier' in y['attribution']
old=Path('<LOCAL_PATH_1>');lines=[json.loads(x) for x in (old/'historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl').read_bytes().splitlines()]
for i in [2650,2651]:
 for x in orig['files'][i]['admission03_scope_observations']:assert lines[x['row_1based']-1]==x['original_record']
add=[json.loads(x) for x in gun(old/'historical-774-compressed/additional-contracts.jsonl.gz').splitlines()];aa={x['id']:x for x in add};assert {'RIG-ADMISSION03-ADDITIONAL-106','RIG-ADMISSION03-ADDITIONAL-107'}<=set(aa);assert 'pendingregistration/read' in aa['RIG-ADMISSION03-ADDITIONAL-107']['admission_comparison']
find=[json.loads(x) for x in gun('<LOCAL_PATH_2>').splitlines()];assert 'RIG-ADMISSION03-F073-SUPPLEMENT-001' in {x['id'] for x in find}
proof=load(b/'git-proofs.json');objs=objects(proof,b);assert len(proof['paths'])==11;paths(proof,objs,b,proof['paths'])
assert len([x for x in proof['paths'] if x['path']=='crates/fabelgeist-physics/tests/fixtures/collider-capacity.txt'])==2
for base,suffixes in [(old,['/source-range-registration.jsonl','/additional-contracts.jsonl']),(Path('<LOCAL_PATH_3>'),['/findings.jsonl'])]:
 gp=load(base/'git-proofs.json');prev=objects(gp,base);wanted=[]
 for suffix in suffixes:
  choices=[p for p in gp['paths'] if p['path'].endswith(suffix)];assert len(choices)==1 and choices[0]['revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';wanted+=choices
 paths(gp,prev,base,wanted)
for packet in load(b/'published-prior-packet-links.json')['archives']:
 d=Path(packet['published_archive']).read_bytes();assert sha(d)==packet['sha256'] and len(d)==packet['bytes']
 with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
  for x in packet['byte_identical_members']:
   raw=t.extractfile(x['member']).read();assert sha(raw)==x['sha256'] and len(raw)==x['bytes'] and raw==(Path(packet['local_original_bundle'])/x['member']).read_bytes()
for x in rec['registrations']:
 d=(b/x['path']).read_bytes();assert sha(d)==x['sha256'] and datetime.fromisoformat(json.loads(d)['registered_utc'])<datetime.fromisoformat(rec['recorded_utc'])
scopes={}
for x in rec['reads']:
 data=(b/x['archive']).read_bytes();assert sha(data)==x['sha256'] and len(data.splitlines())==x['eof'];r=load(b/x['registration']);es=r.get('roles',r.get('entries'));hits=[v for v in es if v['archive']==x['archive']];assert len(hits)==1 and hits[0]['sha256']==x['sha256'] and hits[0]['registered_ranges']==x['actual_display_ranges'];seen={i for a,z in x['actual_display_ranges'] for i in range(a,z+1)};chunks={i for a,z in x['actual_display_chunks'] for i in range(a,z+1)};other={i for a,z in x['unread_complement'] for i in range(a,z+1)};assert seen==chunks and not seen&other and seen|other==set(range(1,x['eof']+1));scopes.setdefault((x['archive'],x['sha256']),set()).update(seen)
assert len(rec['reads'])==8 and len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
def visit(x):
 if isinstance(x,dict):
  if all(k in x for k in ('archive','lines','sha256')):
   a,z=x['lines'];assert set(range(a,z+1))<=scopes[(x['archive'],x['sha256'])],x
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','counts':{'original_roles':2,'personal_read_entries':8,'raw_git_path_proofs':len(proof['paths']),'original_059_records':len(at['records_059']),'bounded_lens_perspectives':13},'checks':['Original registry/queue reconstructions and original 059 receipts and 774 records with raw f82 Git proofs','Per-file historical/current source and fixture Git equality only; dirty pr-working and P16/3821 qualifications','Prospective actual source-only read partitions, source citations and selected byte-identical published prior members','Evidence only; no product, tests, fixture execution, GPU, shader, simulation, build or runtime probe.']};raw=(json.dumps(result,indent=2)+'\n').encode()
if '--record' in sys.argv:(b/'evidence-verification.json').write_bytes(raw)
print('PASS',sha(raw),result['counts'])
