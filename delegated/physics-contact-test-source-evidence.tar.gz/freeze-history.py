from pathlib import Path
import gzip,hashlib,json
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');ex=Path('<LOCAL_PATH_1>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));mi=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in mi['entries']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-registry-reconstruction-v1','qualification':'Selected original registry rows and snapshots reconstructed, not a historical standalone record or checkpoint3821.','rows':[{'original_index':i,**r['files'][i]} for i in (2650,2651)],'snapshots':[x for x in r['snapshots'] if x['id'] in ('pr-working','physical-p16')]},indent=2)+'\n')
q=json.load(open(pub/'baseline-059/queue.json'))['entries'];ids=[435,479,480];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-queue-reconstruction-v1','qualification':'Selected 059 queue rows retain original status, revision and attribution; no automatic aliases or new unique counts.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in ids]},indent=2)+'\n')
paths=[f'segovb/{k}-L11-433.json' for k in ('READ','VERIFY','STATE')]+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in (1567,1568)]+[f'segovb/{k}-L12-914.json' for k in ('READ','VERIFY','STATE')]+['parallel-l12-20261029/PROPOSAL-L12-914.json']+[f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json' for i in (715,716)]+[f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{j}-ORIGINAL{i}.json' for i,j in [(2650,715),(2651,716)]]
records=[];missing=[]
for path in paths:
 f=ex/path
 if not f.exists() or path not in idx:missing.append({'path':path,'exists':f.exists(),'in_transport_manifest':path in idx});continue
 raw=f.read_bytes();m=idx[path];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];dest=b/'historical-059'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);records.append({'original_path':path,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dest.relative_to(b))})
assert not missing,missing
links=[]
def link(p,origin,note):
 raw=p.read_bytes();links.append({'path':str(p),'sha256':sha(raw),'bytes':len(raw),'origin':origin,'qualification':note})
for p in ['recovered/original-registry-source-archive/registry.json.gz','recovered/original-transport-manifest.json.gz','baseline-059/queue.json','baseline-059/ledger.json','ASSESSMENT-DELEGATED-RECONCILIATION-3-95E.json','ASSESSMENT-DELEGATED-RECONCILIATION-10C-95E.json','delegated/physics-contact-report.json','delegated/physics-collider-count-report.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','recovered/physical-p16-patch-recovery/tracked.patch']:
 link(pub/p,'published original and earlier current evidence','Retain own revision and reviewer scopes; no 3821 or personal read credit transfer.')
old=Path('<LOCAL_PATH_2>')
for p in ['MANIFEST.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774-compressed/additional-contracts.jsonl.gz','git-proofs.json']:
 link(old/p,'prior frozen evidence packet','Original rig 774 registration and additional-contract records with f82 Git proof.')
old=Path('<LOCAL_PATH_3>')
for p in ['MANIFEST.json','historical-774/rig-findings.jsonl.gz','git-proofs.json']:
 link(old/p,'prior frozen evidence packet','Original rig F073-SUPPLEMENT-001 and raw Git proof, no automatic alias.')
(b/'historical-attribution.json').write_text(json.dumps({'schema':'726-physics-contact-tests-historical-attribution-v1','records_059':records,'missing':missing,'qualification':'774 supplier rig REGISTER106/107 ADD106/107 reports source-only tests; fixture body not read. F073-SUPPLEMENT-001 records count/native representability. 059 READ-L11-433 records fresh test bodies without naming an individual; /root/lens12_frontier personally read 2650/2651 in READ-L12-914 with root adoption zero rereads and explicit fixture omission. Current fixture read is independent; same Git blob at 6533 does not establish a historical personal fixture read. Earlier current physics reports keep author and source scopes. f82 is transport, not project revision; P16 and 3821 not promoted.'},indent=2)+'\n');(b/'evidence-links.json').write_text(json.dumps({'schema':'726-physics-contact-test-hash-links-v1','links':links},indent=2)+'\n');print('059 records',len(records),'links',len(links),'missing',missing)
