import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());support=json.loads((p/'support-registration.json').read_text());ns=[x for n in ['native-support-registration.json','native-support-registration-02.json'] for x in json.loads((p/n).read_text())['sources']];rec=json.loads((p/'read-receipt.json').read_text());srec=json.loads((p/'support-read-receipt.json').read_text());assert H((p/'registration.json').read_bytes())==rec['registration_sha256']
for x in srec['registrations']:assert H((p/x['file']).read_bytes())==x['sha256']
pkg=(p/reg['package_archive']['path']).read_bytes();assert H(pkg)==reg['package_archive']['sha256']=='3afb591f9cdb6223c88ba39269aff895620c7f0716dc42b705b5733d5c7c0823'
with tarfile.open(fileobj=io.BytesIO(pkg),mode='r:gz') as t:
 for x in reg['sources']+ns:
  b=(p/(x.get('source_archive') or x['archive'])).read_bytes();assert (len(b),len(b.splitlines()),H(b))==(x['bytes'],x['lines'],x['sha256']);assert t.extractfile(x['package_member']).read()==b
lock=(p/reg['current_lock']['archive']).read_bytes();x=reg['current_lock'];assert (len(lock),len(lock.splitlines()),H(lock),O('blob',lock))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1']);matches=[z for z in tomllib.loads(lock.decode())['package'] if z.get('name')=='serde-saphyr' and z.get('version')=='1.2.0'];assert len(matches)==1 and matches[0]['checksum']==H(pkg)
for x in support['sources']:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1'])
lookup={(x['revision'],x['path']):x for x in support['sources']};lookup[reg['current_lock']['revision'],'Cargo.lock']=reg['current_lock'];nd={x['archive']:x for x in ns};displays={}
def check(r,n):
 rr=r['actual_display_union'];u=r['unread_ranges'];assert all(1<=a<=b<=n for a,b in rr+u);read={i for a,b in rr for i in range(a,b+1)};unread={i for a,b in u for i in range(a,b+1)};assert not read&unread and read|unread==set(range(1,n+1));assert r['full_body_displayed']==(not unread)
for x in rec['reads']:
 if x['kind']=='current-lock':y=reg['current_lock'];key=('current-lock',x['revision'],x['path'])
 else:y=next(z for z in reg['sources'] if z['original_role']==x['original_role']);key=('native-package',y['package_member'].split('serde-saphyr-1.2.0/')[1])
 check(x,y['lines']);assert x['actual_display_union']==y['planned_display'];displays[key]=x['actual_display_union']
for x in srec['project_reads']:
 y=lookup[x['revision'],x['path']];check(x,y['lines']);assert x['actual_display_union']==y['planned_display'];displays[x['kind'],x['revision'],x['path']]=x['actual_display_union']
for x in srec['native_reads']:
 y=nd[x['archive']];check(x,y['lines']);assert x['actual_display_union']==y['planned_display'];displays.setdefault(('native-package',x['path']),[]).extend(x['actual_display_union'])
proof=json.loads((p/'git-proofs.json').read_text());objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in proof['proofs']:
 tree=objects[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for e in x['chain']:
  assert e['tree']==tree and entries(objects[tree])[e['name']]==(e['mode'],e['object']);tree=e['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert tree==x['blob']==O('blob',b) and H(b)==x['sha256']
 if x['kind'] in ['current-lock','current-project-support','historical-project-support']:assert tree==lookup[x['revision'],x['path']]['git_blob_sha1']
report=json.loads((p/'report.json').read_text());refs=0
for a in report['assessments']:
 for x in a['source_refs']:
  key=('native-package',x['path']) if x['source_kind']=='native-package' else (x['source_kind'],x['revision'],x['path']);rr=displays[key]
  for start,end in x['lines']:assert any(c<=start<=end<=d for c,d in rr),(key,start,end,rr);refs+=1
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((p/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
r=json.load(gzip.open(p/'reference/original-registry.json.gz','rt'))
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']:assert x['entry']==r['files'][x['index']]
for x in reg['sources']:assert x['original_registry_entry']==r['files'][x['original_role']] and x['sha256']==r['files'][x['original_role']]['sha256']
assert next(z for z in support['sources'] if z['revision'].startswith('6533'))['sha256']==r['files'][1530]['sha256']
old774=json.loads((p/'historical-774-index.json').read_text())
for x in old774['records']:
 b=gzip.decompress((p/x['copy']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
hq=old774['hash_qualifications'];assert H((p/'historical-774/registration-observed-first18.jsonl').read_bytes())==hq['root046_later_registry_first18_sha256']!=hq['root046_prior_registration_sha256'];assert H((p/'historical-774/qualification-pin-matching-first10.jsonl').read_bytes())==hq['root046_qualification_expected_sha256']==hq['root046_later_qualification_first10_sha256']
oldlock=json.loads((p/'historical-059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-873-REFLECT-YAML-LOCK-AUTHORITY.json').read_text());locks=json.loads((p/'historical-locks-index.json').read_text())['records']
for x in locks:
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1']);item=next(z for z in oldlock['rows'] if z['original_index']==x['original_role']);assert item['source_sha256']==x['sha256'];assert H((p/'historical-059'/item['registration']).read_bytes())==item['registration_sha256'];match=[z for z in tomllib.loads(b.decode())['package'] if z.get('name')=='serde-saphyr' and z.get('version')=='1.2.0'];assert len(match)==1 and match[0]['checksum']==H(pkg)
l11=json.loads((p/'historical-059/segovb/READ-L11-423.json').read_text());l12=json.loads((p/'historical-059/segovb/READ-L12-874.json').read_text());assert not l12['root_personal_rereads']
for i,rg,mat,l12rg in [(2575,1484,[[484,501],[577,623],[978,989]],[[484,525],[577,675],[978,991]]),(2576,1485,[[271,334]],[[271,351]])]:
 x=next(z for z in l11['sources'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==mat and H((p/f'historical-059/segovb/REGISTRATION-SEGOVB-{rg}.json').read_bytes())==x['registration_sha256'];row=next(z for z in l12['rows'] if z.get('original_index')==i);assert row['fresh_personal_body_reads']==l12rg;assert H((p/'historical-059'/row['registration']).read_bytes())==row['registration_sha256'];assert H((p/'historical-059'/row['identity_specific_windows_qualification']['path']).read_bytes())==row['identity_specific_windows_qualification']['sha256'];assert row['package_archive_sha256']==H(pkg)
for rg,rr in [(1487,[[624,660]]),(1488,[[661,675]])]:
 x=next(z for z in l11['sources'] if z.get('registration','').endswith(f'REGISTRATION-SEGOVB-{rg}.json'));assert x['fresh_personal_body_reads']==rr and H((p/f'historical-059/segovb/REGISTRATION-SEGOVB-{rg}.json').read_bytes())==x['registration_sha256']
assert H((p/'historical-059/parallel-l12-20261029/PROPOSAL-L12-874.json').read_bytes())==l12['proposal_sha256'];assert len(report['perspectives'])==13
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','native_archive_sha256':H(pkg),'assigned_members':len(reg['sources']),'native_support_registrations':len(ns),'current_and_historical_project_support_objects':len(support['sources']),'git_path_proofs':len(proof['proofs']),'raw_git_objects':len(objects),'assessment_source_ranges_within_personal_displays':refs,'original_059_exact_records':len(hist['records']),'historical_locks':len(locks),'older_774_exact_transport_records':len(old774['records']),'root046_registration_prefix_match':False,'root046_qualification_prefix_match':True,'qualification':'Source/archive/Git/record integrity checks only; earlier root046 pinned registration bytes unmatched in bounded search. No product execution.'};print(json.dumps(result,indent=2))
