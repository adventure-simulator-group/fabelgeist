import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_text());sup=json.loads((p/'support-registration.json').read_text());ns=json.loads((p/'native-support-registration.json').read_text());extra=json.loads((p/'native-support-registration-02.json').read_text());C=reg['current_project_revision']
def comp(rr,n):
 k=1;out=[]
 for a,b in rr:
  if k<a:out.append([k,a-1])
  k=b+1
 if k<=n:out.append([k,n])
 return out
reads=[]
for x in reg['sources']:
 rr=x['planned_display'];reads.append({'original_role':x['original_role'],'kind':'native-package','path':x['package_member'],'archive':x['source_archive'],'actual_display_union':rr,'unread_ranges':comp(rr,x['lines']),'full_body_displayed':False,'qualification':'Personally displayed after registration; remaining archive bytes not read.'})
x=reg['current_lock'];rr=x['planned_display'];reads.append({'kind':'current-lock','revision':x['revision'],'path':x['path'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':comp(rr,x['lines']),'full_body_displayed':False,'qualification':'Current lock package clause; remaining clauses unread.'});(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':h((p/'registration.json').read_bytes()),'reads':reads},indent=2)+'\n')
project=[]
for x in sup['sources']:
 rr=x['planned_display'];u=comp(rr,x['lines']);project.append({'kind':'current-project' if x['revision']==C else 'historical-project','path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':rr,'actual_display_chunks':[[k,min(k+104,x['lines'])] for k in range(1,x['lines']+1,105)],'unread_ranges':u,'full_body_displayed':not u})
native=[]
for x in ns['sources']:
 rr=x['planned_display'];u=comp(rr,x['lines']);native.append({'kind':'native-package-support','path':x['path'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':u,'full_body_displayed':not u,'qualification':'Additional independently registered bounded support only; do not claim another ordered role.'})
for x in extra['sources']:
 rr=x['planned_display'];u=comp(rr,x['lines']);native.append({'kind':'native-package-support','path':x['path'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':u,'full_body_displayed':not u,'qualification':'Independently registered additional wiring; separate read even when same path appears in earlier registration.'})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'file':n,'sha256':h((p/n).read_bytes())} for n in ['support-registration.json','native-support-registration.json','native-support-registration-02.json']],'project_reads':project,'native_reads':native},indent=2)+'\n');print('personal assigned',[(x['original_role'],x['actual_display_union'],x['unread_ranges']) for x in reads if 'original_role'in x])
