import datetime,hashlib,io,json,pathlib,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');pkg=(p/'source/serde-saphyr-1.2.0.crate').read_bytes();local=pathlib.Path('<LOCAL_PATH_1>');rows=[]
with tarfile.open(fileobj=io.BytesIO(pkg),mode='r:gz') as t:
 for i,path in enumerate(['src/de/cfg.rs','src/de/with_deserializer.rs']):
  member='serde-saphyr-1.2.0/'+path;b=t.extractfile(member).read();assert b==(local/path).read_bytes();n=len(b.splitlines());d=p/f'source/native-support-extra-{i}.source';d.write_bytes(b);rr=[[1,n]] if i==0 else [[1,109]];rows.append({'package':'serde-saphyr','version':'1.2.0','path':path,'package_member':member,'archive':str(d.relative_to(p)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'lines':n,'planned_display':rr,'qualification':'Supplemental exact decoder wiring, not ordered-role credit.'})
(p/'native-support-registration-02.json').write_text(json.dumps({'agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Independently trace configuration default and deserialize closure into typed decoder.','sources':rows},indent=2)+'\n');print([(x['path'],x['lines'],x['planned_display']) for x in rows])
