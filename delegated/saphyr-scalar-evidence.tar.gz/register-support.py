import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';C='95e63628f9d70b8dd6e6fede64334696c6995009';H='6533e444fa37552927070cc8d8190907fd3b413e';path='crates/adventuresim-tactical-client/src/presentation/config.rs';rows=[]
for i,rev in enumerate([H,C]):
 try:b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path],stderr=subprocess.PIPE)
 except subprocess.CalledProcessError as e:
  rows.append({'revision':rev,'path':path,'status':'absent','proof_needed':True});continue
 n=len(b.splitlines());d=p/f'source/support-{i}.source';d.write_bytes(b);rows.append({'revision':rev,'path':path,'archive':str(d.relative_to(p)),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b),'lines':n,'planned_display':[[1,n]],'scope':'Historical 6533 per-file object and pinned current; full personally read as bounded support, not ordered role coverage.'})
(p/'support-registration.json').write_text(json.dumps({'schema':'726-prospective-project-support-v1','agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Inspect historical graphics owner referenced by older evidence and independently assess current exact same path.','sources':rows},indent=2)+'\n');print([(x['revision'][:7],x.get('lines'),x.get('status','present'),x.get('sha256')) for x in rows])
