# Report-p17 root motion and sample source review

This packet records `/root/mhr_character`'s independent inspection of original
report-p17 roles 2442–2443 at `90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696`
and comparison to pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The recovered registry's clean P17
head, the two 774 source copies and raw Git tree/blob objects agree. Both P17
bodies and the current root-motion body were fully displayed after prospective
registration. The current `capture/sample.rs` path is absent; raw tree objects
prove this separately. Its related current inline capture logic is independently
registered and read only in the ranges recorded as support.

`report.json` records the conditional missing-height landing observation,
clearance-admission contrast, the separately attributed previous bouncy finding,
source references, future repair directions, thirteen bounded lens perspectives
and open questions. `root-motion-diff.patch` preserves the exact change. The
prior task's P17 sample lines 1–60 remain support-only; this task independently
read all 132 P17 sample lines and does not transfer the old scope.

`historical-059` contains exact original records verified against the original
transport manifest. Registry and queue subsets are reconstructed navigation aids;
the full compressed original bytes remain in `reference/`. The original and
normalized 774 records, P17 snapshot copies, and 586 historical landing summary
are retained separately. One metadata-only search for the landing helper preceded
its explicit registration; it grants no body credit, and the exact helper body
was independently registered before its display. Nothing is promoted to 3821.

`evidence-verification.json` documents source hashes, Git membership and
nonmembership, displayed source-reference ranges, and historical proof checks.
The prior orientation packet is archived intact with its own original manifest.
No tests, viewer, browser, fixtures, product builds, runtime probes or repairs
were performed. The user stop before product validation overrides later native
diagnostic instructions in the animation guide. Central coordination owns
reconciliation, the repair ledger and publication.
