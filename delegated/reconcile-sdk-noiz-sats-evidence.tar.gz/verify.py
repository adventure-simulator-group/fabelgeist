#!/usr/bin/env python3
"""Read-only evidence integrity check; this does not run product code."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tomllib

root = Path(__file__).resolve().parent
if len(sys.argv) not in (2, 3):
    raise SystemExit('usage: verify.py PUBLICATION_DIRECTORY [PUBLICATION_GIT_DIRECTORY]')
pub = Path(sys.argv[1])
p = json.loads((root / 'proposal.json').read_bytes())
a = p['authority']
sha = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
checks = []
manifest = json.loads((root / 'MANIFEST.json').read_bytes())
for item in manifest['files']:
    b = (root / item['path']).read_bytes()
    assert (len(b), sha(b)) == (item['bytes'], item['sha256']), item['path']
checks.append('all local packet files match manifest')
for r in p['historical_records']:
    b = (root / r['local_file']).read_bytes()
    assert (len(b), sha(b), blob(b)) == (r['bytes'], r['sha256'], r['git_blob'])
checks.append('six exact original 059 record bytes and Git blobs')
reg = (root / 'delegate-original-registration.json').read_bytes()
assert sha(reg) == p['delegate_scope']['registration_original_sha256']
checks.append('unredacted original delegate registration matches original receipt hash')
for path_key, sha_key in [('checkpoint_path','checkpoint_sha256'), ('archive_path','archive_sha256'), ('report_path','report_sha256'), ('ledger_path','ledger_sha256'), ('queue_path','queue_sha256'), ('earlier_assessment_path','earlier_assessment_sha256')]:
    assert sha((pub / a[path_key]).read_bytes()) == a[sha_key], path_key
checkpoint = json.loads((pub / a['checkpoint_path']).read_bytes())
bundle = next(x for x in checkpoint['bundles'] if x['bundle_id'] == 'sdk-noiz-sats-hair')
assert bundle['archive_sha256'] == a['archive_sha256']
checks.append('published checkpoint, archive, report, ledger, queue and earlier role495 assessment hashes')
with tarfile.open(pub / a['archive_path'], 'r:gz') as t:
    assert len(t.getnames()) == len(bundle['members']) == 94
    for m in bundle['members']:
        b = t.extractfile(m['path']).read()
        assert (len(b), sha(b)) == (m['published_bytes'], m['published_sha256']), m['path']
    assert (pub / a['report_path']).read_bytes() == t.extractfile('report.json').read()
    receipt = json.load(t.extractfile('read-receipt.json'))
    public_registration = t.extractfile('registration.json').read()
    assert receipt['prospective_registration']['sha256'] == sha(reg)
    assert sha(public_registration) == p['delegate_scope']['registration_reconstructed_public_sha256'] != sha(reg)
    for role in p['native_roles']:
        package = 'noiz-0.5.0' if role['original_index'] == 2476 else 'spacetimedb-sats-2.6.1'
        archive = t.extractfile('archives/' + package + '.crate').read()
        assert sha(archive) == role['archive_sha256']
        with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as nt:
            body = nt.extractfile(role['member']).read()
        assert body == t.extractfile('source/' + str(role['original_index']) + '.rs').read()
        assert sha(body) == role['member_sha256'] and len(body.splitlines()) == role['lines']
        for lock in ['6533', '95e6']:
            data = tomllib.loads(t.extractfile('lock/' + lock + '-Cargo.lock').read().decode())
            name, version = package.rsplit('-', 1)
            entry = next(x for x in data['package'] if x['name'] == name and x['version'] == version)
            assert entry['checksum'] == sha(archive)
    checks.append('all 94 published member byte identities; report equality; registration reconstruction distinction; both native package members and lock checksums')
    gp = json.load(t.extractfile('git-proofs.json'))
    def object_data(oid):
        x = gp['objects'][oid]
        b = gzip.decompress(t.extractfile(x['archive']).read())
        oid_actual = hashlib.sha1(x['type'].encode() + b' ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        assert (len(b), sha(b), oid_actual) == (x['bytes'], x['sha256'], oid)
        return b
    def tree_entries(b):
        d = {}
        i = 0
        while i < len(b):
            j = b.index(b' ', i)
            z = b.index(b'\0', j)
            d[b[j+1:z].decode()] = (b[i:j].decode(), b[z+1:z+21].hex())
            i = z+21
        return d
    for oid in gp['objects']:
        object_data(oid)
    assert len(gp['proofs']) == 13
    for proof in gp['proofs']:
        commit = object_data(proof['revision'])
        tree = commit.splitlines()[0].split()[1].decode()
        assert tree == proof['commit_tree']
        for e in proof['chain']:
            assert e['tree'] == tree and tree_entries(object_data(tree))[e['name']] == (e['mode'], e['object'])
            tree = e['object']
        assert tree == proof['blob'] == blob(t.extractfile(proof['archive']).read())
    checks.append('13 archived raw Git commit/tree/blob membership chains')
    transport = json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()))
    entries = {e['path']: e for e in transport['entries']}
    for r in p['historical_records']:
        e = entries[r['transport_path']]
        assert (e['bytes'], e['sha256'], e['git_blob']) == (r['bytes'], r['sha256'], r['git_blob'])
    checks.append('six exact original 059 records match original transport manifest identities')
    if len(sys.argv) == 3:
        repo = sys.argv[2]
        support = json.load(t.extractfile('support-read-receipt.json'))
        count = 0
        for x in support['reads']:
            if x['kind'] != 'project git support':
                continue
            actual = subprocess.check_output(['git','-C',repo,'show',x['revision'] + ':' + x['path']])
            assert actual == t.extractfile(x['archive']).read() and sha(actual) == x['sha256']
            count += 1
        for rev, short in [(a['current_project_revision'],'95e6'),(a['historical_lock_revision'],'6533')]:
            actual = subprocess.check_output(['git','-C',repo,'show',rev + ':Cargo.lock'])
            assert actual == t.extractfile('lock/' + short + '-Cargo.lock').read()
            count += 1
        assert count == 13
        checks.append('live publication Git objects: eleven scoped support bodies and two lockfiles')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence identity/accountancy only; no source reread credit, product execution, build, test, runtime probe, repair or validation.'}, indent=2))
