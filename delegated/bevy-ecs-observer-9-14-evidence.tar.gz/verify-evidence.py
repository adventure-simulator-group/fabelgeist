import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(reg['files'][e['original_index']]==e['row'] for e in sel['rows']);assert [e['original_index'] for e in sel['rows']]==list(range(9,15));related=load('registry-related-reconstructed.json');assert all(reg['files'][int(k)]==v for k,v in related['roles'].items());assert related['snapshots']==[s for s in reg['snapshots'] if s['id'] in ('physical-p16','pr-working','native-dependency')]
t=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(t)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';m={e['path']:e for e in json.loads(gzip.decompress(t))['entries']};b=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());assert sha(b)=='3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac';ledger=json.loads(b);assert all(ledger['segovb_continuation']['current_connected_dispositions'][int(k)]==v for k,v in load('ledger-selection-reconstructed.json')['entries'].items())
for n in ('reference-index.json','rules.json','skills.json'):
 for e in load(n)['records']:assert sha((p/e['file']).read_bytes())==e['sha256'],e['file']
snap=next(e for e in reg['snapshots'] if e['id']=='physical-p16');patch=(p/'reference/p16-tracked.patch').read_bytes();z=load('p16-per-file-qualification.json');assert sha(patch)==snap['patch_sha256']==z['patch_observed_sha256']==z['patch_recorded_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';assert z['base_head']==snap['head'] and z['status_rows']==len(snap['status_porcelain'])==159
for e in z['files']:
 path=e['path'];assert e['snapshot_status_matches']==[a for a in snap['status_porcelain'] if a[3:]==path];assert e['tracked_patch_contains_diff_header']==(f'diff --git a/{path} b/{path}\n'.encode() in patch)
r=load('registration.json');pkg=(p/r['package']['archive']).read_bytes();assert sha(pkg)==r['package']['sha256']=='a350b2e4c2e47f7903d688affb8a723b31bca63af9789f1da88703f1ba04e354'
with tarfile.open(fileobj=io.BytesIO(pkg),mode='r:gz') as tar:
 for e in r['sources']:assert tar.extractfile(e['package_member']).read()==(p/e['archive']).read_bytes() and e['sha256']==reg['files'][e['original_index']]['sha256']
 mf=tar.extractfile(r['package']['manifest_member']).read();assert mf==(p/r['package']['manifest_archive']).read_bytes() and sha(mf)==r['package']['manifest_sha256'];meta=tomllib.loads(mf.decode());assert (meta['package']['name'],meta['package']['version'])==('bevy_ecs','0.19.1')
 for e in load('support2-registration.json')['entries']:
  if e['kind']=='native-package':assert tar.extractfile(e['package_member']).read()==(p/e['archive']).read_bytes()
for e in r['locks']:
 b=(p/e['archive']).read_bytes();xs=[a for a in tomllib.loads(b.decode())['package'] if a.get('name')=='bevy_ecs' and a.get('version')=='0.19.1'];assert len(xs)==1 and xs[0]==e['package'] and xs[0]['checksum']==sha(pkg)
 if e['label']=='p16':assert e['sha256']==reg['files'][39]['sha256']
 if e['label']=='historical_pr':assert e['sha256']==reg['files'][497]['sha256']
groups=[('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('support2','support2-registration.json','support2-read-receipt.json'),('support3','support3-registration.json','support3-read-receipt.json')]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);a=r['sources']+r['locks'] if name=='assigned' else r['entries'];assert len(a)==len(t['entries'])
 for e,view in zip(a,t['entries']):
  body=(p/e['archive']).read_bytes();assert sha(body)==e['sha256']==view['sha256'] and blob(body)==e['git_blob'] and len(body.splitlines())==e['EOF'] and e['archive']==view['archive'];planned={i for lo,hi in e['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in view['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in view['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and seen|missing==set(range(1,e['EOF']+1)) and not seen&missing
 counts[name]=len(a)
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  a=m[e['transport_path']];assert (a['bytes'],a['sha256'],a['git_blob'])==(len(b),sha(b),blob(b))
h=p/'history-059'
for n in (680,681):
 read=(h/f'segovb/READ-L11-{n}.json').read_bytes();state=(h/f'segovb/STATE-L11-{n}.json').read_bytes();verify=json.loads((h/f'segovb/VERIFY-L11-{n}.json').read_bytes());assert verify['receipt_sha256']==sha(read) and verify['state_sha256']==sha(state) and not verify['gate'];a=json.loads(read);assert a['proposal_sha256']==sha((h/a['proposal']).read_bytes());assert a['plans'][0]['sha256']==sha((h/a['plans'][0]['path']).read_bytes())
x=load('history-reconciliation.json');lines=gzip.decompress((p/x['file']).read_bytes()).splitlines();assert len(x['rows'])==6
for e in x['rows']:
 a=json.loads(lines[e['recorded_row_zero_based']]);row=reg['files'][e['role']];assert a['source_id']==row['source_id'] and a['observed_sha256']==row['sha256'] and a['read_ranges']==e['ranges']
f=next(e for e in load('historical-index.json')['records'] if e['transport_path'].endswith('audit-existing-type-owners/native/findings.jsonl'));rows=[json.loads(l) for l in gzip.decompress((p/f['file']).read_bytes()).splitlines()];assert rows[8]['id']=='NATIVE-OWNER-F009' and 'NATIVE-PP-018' in rows[8]['dedup']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==25;report=load('report.json');assert len(report['lens_perspectives'])==13 and len({e['lens'] for e in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','scope':'Offline native archive/lock/member identity, P16 dirty patch/base distinctions, 059 historical records and earlier reader scopes, 774 native owner records, prospective registration and exact personal read/unread partition, raw Git proofs; not product validation.','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
