# Bounded native Bevy ECS observer review

`report.json` records six original roles, exact package and lock identities,
independent bounded source displays, historical attribution, thirteen scoped
perspectives, and the existing observer-error contract. `registration.json`
and `personal-read-receipt.json` record the material native source windows and
P16, 6533, and pinned 95e lock stanzas. Support receipts separately record
bounded Bevy error and P16/current iteration source displays. All complements
remain unread even when full bytes are archived.

`source/bevy_ecs-0.19.1.crate` is the exact checksummed package; its members
match recovered source objects and the three independently recorded lock
stanzas. Package identity does not prove Cargo feature resolution. The P16
lock and iteration/logging support are dirty-snapshot bytes, not their a120
base. The recovered tracked patch excludes seven separately archived untracked
files. f82 is historical transport. `git-proofs.json` and `git-objects/`
provide raw Git membership evidence for source transport and project sources.

`history-059/` contains exact manifest-matched earlier records, including the
prior e275 personal scopes and root adoption. `history-774/` contains exact
f82 native owner/source/finding records. Registry and ledger subsets are
reconstructed, and the earlier records are not checkpoint 3821 evidence. A
pre-registration metadata-only working-tree Cargo.lock search is documented in
`report.json`, with no baseline source-read credit.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` for evidence
integrity only. No observer, product, build, test, fixture, macro, simulation,
probe or repair was run. Central review owns counts, aliases, the ledger and
publication.
