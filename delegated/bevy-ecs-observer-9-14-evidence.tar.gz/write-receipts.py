import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def missing(n,ranges):
 vals={i for lo,hi in ranges for i in range(lo,hi+1)};u=sorted(set(range(1,n+1))-vals);out=[]
 for i in u:
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
def emit(reg,dst,entries):
 obj={'author':'/root/mhr_character','receipt_utc':now,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':entries,'qualification':'Numbered untruncated personal source displays after prospective registration. Actual displayed chunks and complementary unread source bodies are explicit; no other reviewer or lens read credit transferred.'};(p/dst).write_text(json.dumps(obj,indent=2)+'\n');print(dst,sha((p/dst).read_bytes()))
r=json.loads((p/'registration.json').read_bytes());out=[]
for e in r['sources']+r['locks']:
 chunks=[[1,75],[76,150]] if e.get('original_index')==11 else e['registered_ranges'];out.append({'archive':e['archive'],'sha256':e['sha256'],'displayed_chunks':chunks,'unread_complement':missing(e['EOF'],chunks)})
emit('registration.json','personal-read-receipt.json',out)
r=json.loads((p/'support-registration.json').read_bytes());out=[]
for e in r['entries']:
 chunks=[[140,175]] if e['original_index']==406 else [[185,235],[236,285],[286,335]];out.append({'archive':e['archive'],'sha256':e['sha256'],'displayed_chunks':chunks,'unread_complement':missing(e['EOF'],chunks)})
emit('support-registration.json','support-read-receipt.json',out)
r=json.loads((p/'support2-registration.json').read_bytes());out=[]
for e in r['entries']:
 chunks={'handler':[[1,75],[76,150]],'bevy-error':[[1,90],[380,420]],'system-error':[[370,430]],'logging-header-historical_p16':[[1,50],[51,100]],'logging-header-current':[[1,50],[51,100]]}[e['tag']];out.append({'archive':e['archive'],'sha256':e['sha256'],'displayed_chunks':chunks,'unread_complement':missing(e['EOF'],chunks)})
emit('support2-registration.json','support2-read-receipt.json',out)
