#!/usr/bin/env python3
"""Self-contained source/evidence hashes and recorded read scopes, never Cargo resolution."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('personal-read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['recorded_utc'] and len(receipt['reads'])==len(r['entries'])==8
for x in receipt['reads']:
 e=next(y for y in r['entries'] if y['original_index']==x['original_index'] and y['snapshot']==x['snapshot']);b=(p/x['archive']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['actual_display_chunks']==e['planned_chunks'] and x['actual_display_ranges']==e['registered_ranges'];a={i for f,t in x['actual_display_ranges'] for i in range(f,t+1)};u={i for f,t in x['unread_complement'] for i in range(f,t+1)};assert not a&u and a|u==set(range(1,e['actual_EOF']+1))
for i in range(2683,2687):
 es=[e for e in r['entries'] if e['original_index']==i];assert len(es)==2 and es[0]['sha256']!=es[1]['sha256']
assert next(x for x in receipt['reads'] if x['original_index']==2686 and x['snapshot'].startswith('report-p17'))['unread_complement']==[[1,1433],[1444,2306],[2367,2659],[2703,13101]]
assert next(x for x in receipt['reads'] if x['original_index']==2686 and x['snapshot'].startswith('pinned'))['unread_complement']==[[1,1416],[1427,2138],[2199,2491],[2535,12545]]
checks.append('Eight separately registered displays and exact unread complements; four per-file identities differ')
old=(p/'source/2686-historical.lock').read_bytes().splitlines(keepends=True);cur=(p/'source/2686-current.lock').read_bytes().splitlines(keepends=True);cmp=load('lock-window-comparison.json');assert len(cmp['records'])==4
for x in cmp['records']:
 a=x['historical_lines'];b=x['current_lines'];before=b''.join(old[a[0]-1:a[1]]);after=b''.join(cur[b[0]-1:b[1]]);assert sha(before)==x['historical_sha256'] and sha(after)==x['current_sha256'] and (before==after)==x['exact_text_equal']==True
checks.append('Four displayed historical/current lock package records have identical raw text; no full-lock or feature conclusion')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['original_registry_sha256_uncompressed']==sha(raw)
for x in sel['rows']:assert reg['files'][x['original_index']]==x['entry']
snap=next(x for x in reg['snapshots'] if x['id']=='report-p17');assert sel['report_p17_snapshot']==snap and snap['base']=='18360adba0fb43add88c75dfbd2f45d7e71d8ace' and snap['head']=='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696' and snap['status_porcelain']==[] and snap['patch_sha256']=='3c72c8c4f9816b49ae6306994d55571ceeff420b5a47bb5ff8bcec3c6668c9cd'
for i in range(2683,2687):
 row=reg['files'][i];e=next(x for x in r['entries'] if x['original_index']==i and x['snapshot'].startswith('report-p17'));assert row['sha256']==e['sha256'] and row['material_ranges']==e['original_material_ranges']
assert sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));entries={x['path']:x for x in manifest['entries']}
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==24 and sum(x['kind']=='historical-774' for x in hi['records'])==4
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original report-p17 registry snapshot, recorded patch metadata, 24 exact 059 records and four original 774 records')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==16
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Sixteen raw 90a/95e/f82 commit/tree/blob membership chains; f82 is transport only')
expected={2683:[[1,27]],2684:[[1,19]],2685:[[85,85],[95,95]],2686:[[1434,1443],[2307,2366],[2660,2702]]};l11=load('history-059/segovb/READ-L11-438.json');proposal=load('history-059/parallel-l12-20261029/PROPOSAL-L12-931.json');adopt=load('history-059/segovb/READ-L12-931.json');assert adopt['root_personal_rereads']==[] and len(proposal['partial_read_receipts'])==4
for j,i in enumerate(range(2683,2687),1):
 x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected[i]
 registration=load(f'history-059/parallel-l12-20261029/REGISTRATION-PAR-L12-{746+j}.json');part=load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-931-{j:03d}.json');row=next(x for x in part['rows'] if x['original_index']==i);assert row['fresh_personal_body_reads']==expected[i] and row['registered_at']==registration['registered_at'] and row['registered_at']<part['at']<proposal['at']<adopt['at'] and '/root/lens12_frontier' in row['attribution']
native=gzip.decompress((p/'history-774/native/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines()
for n in range(39,44):assert json.loads(native[n-1])['id']==f'NATIVE-ADMISSION03-REG-{n:03d}'
groups=json.loads(gzip.decompress((p/'history-774/native/admission03/contract-groups-059.json.gz').read_bytes()));assert 'p17-capture-selected-observation-admission' in groups['groups']
checks.append('Original 774 registrations and separate 059 Lens11/Lens12 prospective partial chronology and authorship')
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert json.loads(raw)['entries'][2332]==q['entries']['2332'] and q['entries']['2332']['contract_id']=='L12-CLOSURE-NATIVE-SATS-REFLECTION-ADAPTER-OWNERS'
for x in load('prior-evidence-index.json')['records']:
 b=(p/x['preserved_bytes']).read_bytes();assert (sha(b),len(b))==(x['sha256'],x['bytes'])
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
assert {x['number'] for x in load('report.json')['lenses']}==set(range(1,14))
checks.append('Exact 059 queue selection, separately attributed prior reports, applicable rules and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and recorded scope only. Report-p17 patch bytes are not independently verified. No Cargo resolution, feature inference, macro/product execution, build, tests, runtime probes, repairs, validation or checkpoint3821 promotion.'},indent=2))
