# P17 dependency manifest and lockfile evidence

This source-only packet covers original report-P17 registry roles 2683–2686
and their pinned current counterparts at
`95e63628f9d70b8dd6e6fede64334696c6995009`. The registry records report-P17
base `18360adba0fb43add88c75dfbd2f45d7e71d8ace`, clean-status head
`90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696` and a separate historical patch
hash. The exact source objects are proven against 90a and f82 evidence
transport; the recorded patch bytes are not independently recovered or verified
by this packet. F82 is not a project source revision.

`registration.json` preceded all eight source displays in
`personal-read-receipt.json`. Building and geometry manifests were displayed
in full; the workspace manifest and both lockfiles only in bounded windows,
with every unread complement recorded. Original 774/059 role 2683 material was
only lines 1–27 and role 2685 material only lines 85 and 95. This review's
separately registered context does not enlarge those historical reads.
`lock-window-comparison.json` compares only the four displayed package records;
`building-manifest.diff` and `geometry-manifest.diff` compare the two completely
displayed small manifests.

`history-059/` preserves exact original registrations, partials, proposals and
receipts; `history-774/` stores losslessly compressed native and rig records.
`reference/` includes the original registry and transport manifest, recovered
059 queue and small prior separately attributed assessments. Reconstructed
selections are labeled. Archived commit/tree objects in `git-objects/` and
`git-proofs.json` prove historical, current and f82 memberships; they do not
transfer reviewer or ordered-role credit.

Run `python3 verify-evidence.py` for self-contained evidence integrity and
recorded scope accounting, and `python3 verify-manifest.py` for packet member
hashes. These checks do not invoke Cargo, resolve features, expand macros,
execute product, build, run tests or probes, or validate product behavior.
No repair, source or publication edit, checkpoint 3821 promotion or whole-lens
completion is claimed.
