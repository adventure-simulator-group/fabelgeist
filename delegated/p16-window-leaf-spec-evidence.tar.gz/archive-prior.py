import gzip,hashlib,io,json,pathlib,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');out=p/'prior-packets';out.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
spec=[('p16-doors-builder','<LOCAL_PATH_1>','/root/mhr_character')];records=[]
for name,loc,author in spec:
 base=pathlib.Path(loc);files=sorted(x for x in base.rglob('*') if x.is_file())
 mf=base/('MANIFEST.json' if name=='p17-continuity' else 'BUNDLE-MANIFEST.json');manifest_verified=None
 if mf.exists():
  assert h(mf.read_bytes())=='20a65126f176e5dab67d792b1bef69a1b19a958e6157a834174a5b7bcea1a8e4';m=json.loads(mf.read_text());listed={x['path']:x for x in m['files']};actual={str(f.relative_to(base)) for f in files if f!=mf};assert actual==set(listed),(name,actual-set(listed),set(listed)-actual)
  for n,e in listed.items():
   b=(base/n).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],(name,n)
  manifest_verified=True
 details=[];dst=out/(name+'.tar.gz')
 with dst.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for x in files:
     rel=str(x.relative_to(base));b=x.read_bytes();info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(b));details.append({'path':rel,'bytes':len(b),'sha256':h(b)})
 records.append({'name':name,'recorded_agent':author,'archive':str(dst.relative_to(p)),'sha256':h(dst.read_bytes()),'bytes':dst.stat().st_size,'upstream_manifest_verified':manifest_verified,'entries':details})
(p/'prior-packets-index.json').write_text(json.dumps({'qualification':'Frozen complete separate upstream packets, never transferred as personal reads; prior original attribution, revision, ranges, findings and qualifications remain in archived reports. Prior P16 door-builder support windows remain independently attributed and do not grant new ordered-role credit; no role or support reads are transferred.','packets':records},indent=2)+'\n');print([(x['name'],len(x['entries']),x['upstream_manifest_verified']) for x in records])
