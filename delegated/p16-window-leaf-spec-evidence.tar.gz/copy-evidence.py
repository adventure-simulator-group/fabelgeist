import gzip,hashlib,json,pathlib,shutil
p=pathlib.Path('<LOCAL_PATH_0>'); orig=pathlib.Path('<LOCAL_PATH_1>'); prior=pathlib.Path('<LOCAL_PATH_2>');refs=p/'reference';refs.mkdir(exist_ok=True);h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
for n in ['059-queue-original-bytes.json.gz','original-transport-manifest.json.gz','original-registry.json.gz']:shutil.copyfile(prior/'reference'/n,refs/n)
for n in ['AGENTS.md','crates/AGENTS.md']:
 d=refs/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(prior/'reference'/n,d)

t={x['path']:x for x in json.load(gzip.open(refs/'original-transport-manifest.json.gz','rt'))['entries']}
names=['evidence/audit11/successor-103.json', 'segovb/READ-L11-415.json', 'segovb/REGISTRATION-SEGOVB-1411.json', 'segovb/REGISTRATION-SEGOVB-1412.json', 'segovb/READ-L12-852.json', 'parallel-l12-20261029/PROPOSAL-L12-852.json', 'parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-851-853.json', 'parallel-l12-20261029/REGISTRATION-PAR-L12-527.json', 'parallel-l12-20261029/REGISTRATION-PAR-L12-528.json']
rows=[];missing=[]
for n in names:
 if n not in t or not (orig/n).is_file():missing.append(n);continue
 b=(orig/n).read_bytes();e=t[n];assert (len(b),h(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']),n
 d=p/'historical-059'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);rows.append({'original_path':n,'copy':str(d.relative_to(p)),'bytes':len(b),'sha256':h(b),'git_blob':blob(b)})
q=json.load(gzip.open(refs/'059-queue-original-bytes.json.gz','rt'));inds=[583,1300,1399,1597,1934,1935,1936,1937,1938,1939,2107,2244,2249];(p/'historical-queue-selected.json').write_text(json.dumps({'qualification':'Derived navigation subset of exact 059 original; preserve all historical statuses, sources and authors; no checkpoint3821 credit.','entries':[{'index':i,'entry':q['entries'][i]} for i in inds]},indent=2)+'\n')
r=json.load(gzip.open(refs/'original-registry.json.gz','rt'));(p/'historical-registry-selected.json').write_text(json.dumps({'qualification':'Derived navigation subset of original registry; retained old metadata and exact scopes, not new credits.','roles':[{'index':i,'entry':r['files'][i]} for i in [2508,2509]]},indent=2)+'\n');(p/'historical-059-index.json').write_text(json.dumps({'records':rows,'unavailable':missing,'qualification':'Exact read-only extraction copies checked against original transport; no later adoption or revision inference.'},indent=2)+'\n')
old=pathlib.Path('<LOCAL_PATH_3>');ori=old/'semantic-goal/pr774-plan-execution-20261020';exp=old/'774-publication-branch/handoff/774/adler-original/audit';shutil.copyfile(exp/'EXPORT-MANIFEST.json',p/'older-774-export-manifest.json');m=json.loads((p/'older-774-export-manifest.json').read_text());lookup={x['file']:x for x in m['files']};paths=['final-acceptance-20261021/wave-01/audit-existing-type-owners/rig/coverage.jsonl','final-acceptance-20261021/wave-01/audit-existing-type-owners/rig/receiver-closure.json'];oldrows=[]
for r in paths:
 e=lookup['records/'+r];a=(ori/r).read_bytes();b=(exp/'records'/r).read_bytes();ha=h(a);hb=h(b);assert (ha,hb)==(e['original_record_sha256'],e['published_export_sha256'])
 for kind,content in [('original',a),('normalized-export',b)]:
  d=p/'older-774'/kind/r;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(content)
 oldrows.append({'path':r,'original_sha256':ha,'normalized_export_sha256':hb,'distinct':ha!=hb,'original_copy':'older-774/original/'+r,'normalized_copy':'older-774/normalized-export/'+r})
cont=old/'774-publication-branch/handoff/774/audit/reconcile-adler-20261023/audit/continuation';cpaths=['rig/owner-reached-producer-followup/findings.jsonl','rig/initial06-type-ownership/coverage.jsonl','owner-range-extensions.jsonl'];crow=[]
for path in cpaths:
 data=(cont/path).read_bytes();d=p/'older-774/continuation'/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data);crow.append({'original_export_path':str(cont/path),'copy':str(d.relative_to(p)),'sha256':h(data),'qualification':'Verbatim local recovered continuation export, independently hashed; no original author or peer-review transfer.'})
(p/'older-774-index.json').write_text(json.dumps({'records':oldrows,'continuation':crow,'qualification':'Original and normalized records separately copied and checked against export manifest; continuation copies independently hashed. Standalone rig producer registration and qualification files were not located; exact original rows are embedded in registry metadata, no implied acceptance.'},indent=2)+'\n');print('059',len(rows),'missing',missing,'774 pairs',len(oldrows),'continuation',len(crow))
