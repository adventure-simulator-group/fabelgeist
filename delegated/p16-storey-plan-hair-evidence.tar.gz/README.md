# Bounded P16 storey and plan-geometry evidence

This `/root/hair_ops` source-only review covers physical-P16 original roles
2554 and 2555 against `95e63628f9d70b8dd6e6fede64334696c6995009`. The
recorded P16 snapshot is a 159-path dirty delta based on a120; the registry's
patch hash remains a historical assertion because the complete patch bytes were
not recovered. A bounded central search did not find them in the specified older
collections and does not prove absence elsewhere. Both selected source objects
match f82 transport, their 0393 catalog origin, a120, 6533 and 95e per file;
that does not reconstruct the whole dirty snapshot.

The P16 and 95e bodies were separately personally displayed after prospective
registration: storey 1–137 and plan geometry 1–341. The original P16 material
scopes were storey 79–90 and plan 1–49; other body text is a fresh extension.
Storey 92–137 and plan 245–341 are test source text only, not executed. P16
role 2554 remains distinct from the same-byte pr-working role 2479; prior
reviewer attribution and scoped reads remain separate.

`report.json` gives thirteen bounded perspectives, exact citations, open
questions and source/historical relations. It independently corroborates the
already published mixed-scale polygon-area finding and uses symbolic IEEE
arithmetic to show that the same orientation cancellation can classify a
mathematical triangle as a line segment in the hull code. It does not establish
that a real cuboid, building or accepted product input reaches that condition;
no new unique count is asserted. The room/storey and retained-wall-frame owner
questions are preserved with their original historical attribution.

`read-receipt.json`, `support-read-receipt.json`, `git-proofs.json` and
`git-objects/` record actual displays and per-file object membership. Exact
selected 059/774 records and the compressed source inventory are retained;
selected queue records are reconstructed excerpts linked to the complete queue,
never checkpoint3821 evidence. Earlier packet reports and manifests remain
hash-linked with their original authors.

`verify_evidence.py` checks evidence integrity and read windows only; run it in
a copy to preserve the timestamped frozen output. `verify_manifest.py` checks
the frozen set without writing. No product or geometry execution, builds,
tests, probes, simulations, repairs or source/publication edits occurred.
Central coordination owns aliases, the ledger and checkpoint publication.
