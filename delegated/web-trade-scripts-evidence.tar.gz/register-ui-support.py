import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/strategic-web/static/css/strategic-scene.css','crates/strategic-web/static/css/strategic.css'];sources=[]
for i,path in enumerate(paths,start=11):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);o=p/'source'/('support-'+str(i)+'.source');o.write_bytes(b)
 sources.append({'path':path,'revision':rev,'archive':str(o.relative_to(p)),'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'planned_display_scope':[1,len(b.splitlines())]})
(p/'support-registration-03.json').write_text(json.dumps({'schema':'726-prospective-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','purpose':'Bounded source-only modal and merchant draft focus/interaction layout; metadata search first, then scoped display.','sources':sources},indent=2)+'\n')
