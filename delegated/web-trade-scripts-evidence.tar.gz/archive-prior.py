import gzip,hashlib,io,json,pathlib,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');out=p/'prior-packets';out.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
spec=[('trade-templates','<LOCAL_PATH_1>','/root/rig_identity'),('web-quest-templates','<LOCAL_PATH_2>','/root/rig_identity'),('web-equipment','<LOCAL_PATH_3>','/root/hair_ops')];records=[]
for name,loc,author in spec:
 base=pathlib.Path(loc);files=sorted(x for x in base.rglob('*') if x.is_file())
 mf=base/'MANIFEST.json';manifest_verified=None
 if mf.exists():
  m=json.loads(mf.read_text());listed={x['path']:x for x in m['files']};actual={str(f.relative_to(base)) for f in files if f!=mf};assert actual==set(listed),(name,actual-set(listed),set(listed)-actual)
  for n,e in listed.items():
   b=(base/n).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],(name,n)
  manifest_verified=True
 details=[];dst=out/(name+'.tar.gz')
 with dst.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for x in files:
     rel=str(x.relative_to(base));b=x.read_bytes();info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(b));details.append({'path':rel,'bytes':len(b),'sha256':h(b)})
 records.append({'name':name,'recorded_agent':author,'archive':str(dst.relative_to(p)),'sha256':h(dst.read_bytes()),'bytes':dst.stat().st_size,'upstream_manifest_verified':manifest_verified,'entries':details})
(p/'prior-packets-index.json').write_text(json.dumps({'qualification':'Frozen complete separate upstream packets, never transferred as personal reads; prior original attribution, revision, ranges, findings and qualifications remain in archived reports. web-equipment had no upstream whole-packet manifest, so its exact recovered file set and hashes are indexed here.','packets':records},indent=2)+'\n');print([(x['name'],len(x['entries']),x['upstream_manifest_verified']) for x in records])
