from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');ex=Path('<LOCAL_PATH_1>');rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d);return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[]
for src,dest,kind in [('recovered/original-registry-source-archive/registry.json.gz','history/original-registry.json.gz','exact recovered 059 registry'),('recovered/original-transport-manifest.json.gz','history/original-transport-manifest.json.gz','059 extraction manifest'),('ASSESSMENT-UNDERSTORY-LITTER-95E.json','history/prior-understory-95e.json','prior current botanical assessment')]:refs.append({'kind':kind,'original':src,**save((pub/src).read_bytes(),dest)})
for src,dest in [('baseline-059/queue.json','history/baseline-059-queue.json.gz'),('baseline-059/ledger.json','history/baseline-059-ledger.json.gz')]:
 raw=(pub/src).read_bytes();refs.append({'kind':'059 historical summary mechanically compressed; not checkpoint 3821','original':src,'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(gzip.compress(raw,mtime=0),dest)})
r=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()));idx={v['path']:v for v in json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()))['entries']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanical selection from preserved original registry; metadata is not read credit or checkpoint 3821.','rows':[{'original_index':i,**r['files'][i]} for i in [2816,2817]],'snapshots':[x for x in r['snapshots'] if x['id']=='pr-working']},indent=2)+'\n')
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries'];qi=[1845,1856,1857,1858];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-059-queue-reconstruction-v1','qualification':'Related native/shell questions only; no alias, closure or count assumed.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in qi]},indent=2)+'\n')
paths=['segovb/READ-L11-458.json','segovb/STATE-L11-458.json','segovb/VERIFY-L11-458.json','segovb/REGISTRATION-SEGOVB-1737.json','segovb/REGISTRATION-SEGOVB-1738.json','segovb/READ-L12-912.json','segovb/STATE-L12-912.json','segovb/VERIFY-L12-912.json'];records=[]
for p in paths:
 raw=(ex/p).read_bytes();m=idx[p];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];records.append({'original_path':p,'git_blob':m['git_blob'],**save(raw,'history/059/'+p)})
old=[];prefix='handoff/774/adler-original/audit/continuation/'
for p in ['rig/initial06-type-ownership/source-range-registration.jsonl','rig/initial06-type-ownership/qualifications.jsonl','rig/initial06-type-ownership/coverage.jsonl','rig/initial06-type-ownership/contracts-122.json','rig/initial06-type-ownership/contracts-123.json','rig/initial06-type-ownership/findings.jsonl','root/initial04-invariant-operations/findings.jsonl']:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+prefix+p]);old.append({'revision':rev,'transport_path':prefix+p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+p+'.gz')})
raw=gzip.decompress((b/'history/774/rig/initial06-type-ownership/source-range-registration.jsonl.gz').read_bytes());rows=[json.loads(x) for x in raw.splitlines()];m=[]
for i in [2816,2817]:
 e=r['files'][i]['scope_registration'][0];assert rows[e['row_1based']-1]==e['original_record'];m.append({'role':i,'row':e['row_1based'],'registry_recorded_whole_file_sha256':e['sha256'],'f82_whole_file_sha256':sha(raw),'selected_row_equal':True})
prior=[]
for d in ['<LOCAL_PATH_2>','<LOCAL_PATH_3>']:
 p=Path(d);entry={'original_directory':str(p),'qualification':'Original prior report and manifest preserved; full earlier packet remains at its original directory/publication, no transferred personal read or role credit.'}
 for name in ['REPORT.json','MANIFEST.json']:entry[name]=save((p/name).read_bytes(),'history/prior/'+p.name+'/'+name)
 prior.append(entry)
out={'schema':'726-mesh-data-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_059':records,'records_774':old,'registration_file_hash_mismatches':m,'prior_packet_reports_and_manifests':prior,'qualification':'059 original selected records match transport manifest size/SHA/Git blob; original 059 payload Git path unavailable in inspected collections. f82 is transport only, recorded pr-working snapshot had unrelated modifications. Registry and f82 registration whole-file variants differ although selected rows match; cause unknown. No evidence promoted to checkpoint 3821.'}
(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('refs',len(refs),'059',len(records),'774',len(old),'mismatches',m)
