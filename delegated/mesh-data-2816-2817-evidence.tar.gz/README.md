# Mesh library and data roles 2816–2817

`REPORT.json` contains this bounded source audit, thirteen lens perspectives,
two conditional displacement-path questions and their unresolved reachability,
feature and device-policy qualifications. No product or fixture was created,
run, built, tested, rendered or probed; no shader was compiled or executed and
no repair or publication edit was made.

The assigned archived historical file bodies match project revision
`6533e444fa37552927070cc8d8190907fd3b413e` and pinned current project revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Both were prospectively registered
and personally displayed at each revision. The original pr-working snapshot
records four unrelated changes; individual file identity does not make that
snapshot clean. Revision `f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports
historical objects and reviewer records; it is not the product source snapshot.

`registration.json` and `read-receipt.json` record independent original/current
personal displays, preserving the original reviewer scope and later complements
separately. `support-registration*.json` and `support-read-receipt.json` record
current support and unread lines, without original-role or past reviewer credit.
The two `gpu.rs` support partitions are separate receipts. Source test and WGSL
text were inspected without execution. `caller-navigation.json` is limited
literal search evidence, not a complete call graph or feature resolution.

`history/` retains the exact recovered original registry and extraction
manifest, selected original 059 receipts, losslessly compressed 059 queue and
ledger summaries, selected exact 774 records and prior assessment references.
Prior delegated reports/manifests are hash-linked, with their full packets at
the recorded locations. Selected 774 registration rows equal the embedded
original rows, but the whole-file registration hashes differ; the original
variant and cause remain unknown. Reconstructed selections are identified and
no evidence is promoted to the unavailable checkpoint 3821.

`git-proofs.json` and `git-objects/` preserve exact Git commit/tree evidence for
assigned sources, bounded support, applicable rules and transported 774 records.
`python3 verify-evidence.py` and `python3 verify-manifest.py` check evidence
integrity only; they do not validate the product or run native GPU code.
