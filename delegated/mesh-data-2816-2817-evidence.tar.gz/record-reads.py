from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;raw=(b/'registration.json').read_bytes();r=json.loads(raw);entries=[]
for x in r['entries']:
 chunks=[[1,22]] if x['role']==2816 else [[1,145],[146,293]];entries.append({'id':x['id'],'sha256':x['sha256'],'actual_display_chunks':chunks,'unread_complement':[],'original_material_ranges':x['original_registry_material_ranges'],'qualification':'Personal display after registration at exact revision. Extra original historical ranges are new support, not earlier reviewer credit. Tests are inspected as text only.'})
out={'schema':'726-bounded-personal-read-receipt-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(raw).hexdigest(),'entries':entries};(b/'read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('read receipts',len(entries))
