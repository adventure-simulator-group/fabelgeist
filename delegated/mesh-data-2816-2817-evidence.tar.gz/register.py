from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
cur='95e63628f9d70b8dd6e6fede64334696c6995009';old='6533e444fa37552927070cc8d8190907fd3b413e';t='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
spec=[(2816,'crates/fabelgeist-mesh/src/lib.rs','6a0d874f4c07665cb0c5f3e477bd5a79d6c431a46aea2be921a7fab150e5e04b',[[1,22]]),(2817,'crates/fabelgeist-mesh/src/data.rs','41c300bd088e2a69594225a867cee9f1bc3fe5f19410bf77d3c8de73a383f1b4',[[1,11],[41,68]])];entries=[]
for role,path,expected,orig in spec:
 tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+expected;raw=g('show',old+':'+path);assert sha(raw)==expected and raw==g('show',t+':'+tp)
 for label,rev in [('historical',old),('current',cur)]:
  raw=g('show',rev+':'+path);n=len(raw.splitlines());dest=f'sources/{role}-{label}.rs';(b/dest).write_bytes(raw)
  entries.append({'id':f'{role}-{label}','role':role,'revision':rev,'git_path':path,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'archive':dest,'original_registry_material_ranges':orig,'prospective_personal_read_ranges':[[1,n]],'transport_revision':t if label=='historical' else None,'transport_path':tp if label=='historical' else None,'qualification':'Full personal source display planned; original historic material and newly inspected complementary source have separate credit. The individual 6533 file matches recovered f82 bytes; pr-working snapshot contains unrelated modifications.' if label=='historical' else 'Independent pinned 95e personal source display; no inferred historical or prior reviewer credit.'})
out={'schema':'726-prospective-mesh-role-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':entries,'restriction':'Static text only, including test code; no product execution, builds, tests, probes, shader execution or repairs.'};(b/'registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
