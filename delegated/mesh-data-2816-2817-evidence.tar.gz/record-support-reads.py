from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;names=['support-registration.json','support-registration-2.json','support-registration-3.json'];spec={'manifest':([[1,25]],[]),'front':([[1,31]],[]),'topology':([[1,37]],[]),'gpu-mesh':([[1,100],[101,200]],[[201,525]]),'shell-mesh':([[1,70],[71,139]],[]),'shell':([[1,70],[71,140]],[[141,408]]),'plant-mesh':([[1,82],[83,164]],[]),'gpu-displacement-tail':([[201,250],[251,300]],[[1,200],[301,525]]),'buffer':([[1,89],[90,178]],[]),'upload':([[1,58]],[]),'bind-group':([[1,100],[101,200]],[[201,303]])};entries=[];registrations=[]
for n in names:
 raw=(b/n).read_bytes();reg=json.loads(raw);registrations.append({'path':n,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for x in reg['entries']:
  chunks,unread=spec[x['id']];entries.append({'registration':n,'id':x['id'],'sha256':x['sha256'],'actual_display_chunks':chunks,'unread_complement':unread,'qualification':'Personally displayed the registered bounded current support only; source text including shader and test declarations, never executed.'})
r={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':registrations,'entries':entries};(b/'support-read-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('read support',len(entries))
