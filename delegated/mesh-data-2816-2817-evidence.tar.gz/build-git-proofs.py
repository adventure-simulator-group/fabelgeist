from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
r=json.loads((b/'registration.json').read_bytes())['entries'];f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009'
for x in r:
 proof(x['revision'],x['git_path'],x['archive'],'independently registered personally displayed role at exact project revision')
 if x['transport_revision']:proof(f82,x['transport_path'],x['archive'],'recovered original object at f82 transport, not source revision')
for n in ['support-registration.json','support-registration-2.json','support-registration-3.json']:
 for x in json.loads((b/n).read_bytes())['entries']:
  proof(cur,x['git_path'],x['archive'],'independent current bounded support')
for path in ['AGENTS.md','crates/AGENTS.md']:
 dest='rules/'+path.replace('/','-');(b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(git('show',cur+':'+path));proof(cur,path,dest,'applicable pinned source guide')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(x['revision'],x['transport_path'],x['preserved'],'exact historical 774 reviewer record at f82')
out={'schema':'726-mesh-data-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Per-file objects only; 6533 is original source commit for proven matching files, f82 evidence transport, 95e pinned current; individual equality does not prove recorded pr-working snapshot clean or confer another reviewer/lens credit.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('git paths',len(proofs),'objects',len(objects))
