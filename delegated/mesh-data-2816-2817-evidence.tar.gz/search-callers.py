from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';args=['git','-C',repo,'grep','-l','-F','GpuMesh::displacement','95e63628f9d70b8dd6e6fede64334696c6995009','--','crates'];r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==1 and r.stdout==b'' and r.stderr==b''
out={'schema':'726-literal-navigation-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'args':args,'returncode':r.returncode,'stdout':r.stdout.decode(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':r.stderr.decode(),'qualification':'Exact literal in tracked crates at 95e only. Aliases, alternate names, line breaks, external callers, feature selection and runtime invocation remain open. Navigation gives no source-body read credit.'};(b/'caller-navigation.json').write_text(json.dumps(out,indent=2)+'\n')
