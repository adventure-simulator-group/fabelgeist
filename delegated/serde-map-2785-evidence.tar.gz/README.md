# Bounded serde_json Map evidence: role 2785

This packet records static source review by `/root/mhr_character`. Its
`report.json` contains thirteen bounded perspectives, a conditional current
confirmation of historical `CAMERA-INITIAL07-F020`, related records,
nonfindings and open questions. It does not close any complete lens or audit.

The recorded role is `dependency-serde_json1.0.151:src/map.rs` in the original
`pinned-cargo` snapshot. The archived historical object and the saved
`serde_json` 1.0.151 crate member are identical by SHA-256. The saved project
lock stanzas at 6533 and pinned 95e both name the same version and archive
checksum. Package and lock identities do not establish resolved feature sets.
`f82...` transports historical evidence; it is not a project source revision.

The original camera registration planned lines 29–36 and 120–130, and its
qualification excludes blank 130 from material reads. The 059 reviewer read
29–36 and 120–129. This reviewer separately registered and displayed both
recovered and crate-member copies at 29–36 and 120–129. All remaining map
lines are unread in this packet. Bounded support windows and every unread
complement are recorded in registrations, receipts and
`read-scope-summary.json`. The earlier independently attributed Value and
number packet is represented by a selected manifest-verified subset only.

The F020 source records cite dirty historical P16 and pr-working snapshots.
Three relevant recovered dialogue objects individually match their a120,
6533 and 95e Git path blobs; this does not make either snapshot clean. Later
P16 tracked-patch reproduction matches the recorded hash, with the original
invocation, uninterrupted custody and seven untracked files separately
qualified. The original checkpoint 3821 ledger and queue are not established
here and no earlier evidence is promoted into that checkpoint.

`python3 verify-evidence.py` checks source receipts, native archive and lock
identity, recovered 059/774 records, later patch checksum and raw Git path
proofs. `python3 verify-manifest.py` checks every packet file, including nested
manifests. These are offline evidence integrity checks, not product validation.
No product or dependency parser, fixture, macro, code generator, build, test,
viewer or runtime probe was executed.
