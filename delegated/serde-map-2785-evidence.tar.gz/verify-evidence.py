import datetime,gzip,hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);row=registry['files'][2785];assert row['snapshot']=='pinned-cargo' and row['material_ranges']==[[29,36],[120,129]];trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and b'CAMERA-INITIAL07-F020' not in queue;q=json.loads(queue);sel=load('queue-selection-reconstructed.json');assert all(q['entries'][int(k)]==v for k,v in sel['entries'].items());sel=load('registry-selection-reconstructed.json');assert all(registry['files'][int(k)]==v for k,v in sel['roles'].items()) and sel['snapshot_rows']==registry['snapshots']
for n in ['reference-index.json','rules.json','skills.json']:
 for e in load(n)['records']:
  b=(p/e['file']).read_bytes();assert sha(b)==e['sha256'],e['file']
groups=[('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('support2','support2-registration.json','support2-read-receipt.json'),('support3','support3-registration.json','support3-read-receipt.json'),('support4','support4-registration.json','support4-read-receipt.json'),('support5','support5-registration.json','support5-read-receipt.json')]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'];assert blob(body)==a.get('git_blob',a.get('git_blob_for_content'));assert len(body.splitlines())==a['EOF'] and a['archive']==b['archive'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[name]=len(r['entries'])
r=load('registration.json');assert len(r['entries'])==2
for e in r['entries']:assert (e['source_id'],e['snapshot'],e['sha256'],e['EOF'],e['original_material_ranges'])==(row['source_id'],row['snapshot'],row['sha256'],row['actual_line_count'],row['material_ranges'])
assert (p/'source/2785-historical.rs').read_bytes()==(p/'source/2785-package.rs').read_bytes()
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
hist=p/'history-059/segovb';receipt=json.loads((hist/'READ-L11-454.json').read_bytes());state=json.loads((hist/'STATE-L11-454.json').read_bytes());verification=json.loads((hist/'VERIFY-L11-454.json').read_bytes());assert receipt['current_reconciled'] is False and receipt['accepted_unique_count_change']==0 and state['accepted_unique_count_change']==0 and verification['gate'] is False;assert state['receipt_sha256']==sha((hist/'READ-L11-454.json').read_bytes())==verification['receipt_sha256'];assert verification['state_sha256']==sha((hist/'STATE-L11-454.json').read_bytes())
f=hist/'REGISTRATION-SEGOVB-1705.json';x=json.loads(f.read_bytes());src=[s for s in receipt['sources'] if s['original_index']==2785];assert len(src)==1 and src[0]['registration_sha256']==sha(f.read_bytes()) and src[0]['assessed_ranges']==src[0]['fresh_personal_body_reads']==x['ranges']==[[29,36],[120,129]] and x['sha256']==row['sha256'] and x['prospective']
f=hist/'REGISTRATION-SEGOVB-1648.json';rr=json.loads((hist/'READ-L11-446.json').read_bytes());src=[s for s in rr['sources'] if s['original_index']==2729];assert len(src)==1 and src[0]['registration_sha256']==sha(f.read_bytes()) and src[0]['assessed_ranges']==[[1,540]]
rp=p/'history-774/camera/initial07-redundant-authority';rows=[json.loads(l) for l in gzip.decompress((rp/'source-range-registration.jsonl.gz').read_bytes()).splitlines()];assert rows[16]==row['scope_registration'][0]['original_record'] and rows[16]['material_ranges']==[[29,36],[120,130]] and rows[15]['registration_id']=='CAMERA-INITIAL07-REG016';extra=[json.loads(l) for l in gzip.decompress((rp/'additional-sources.jsonl.gz').read_bytes()).splitlines()];a=next(x for x in extra if x.get('registration_id')=='CAMERA-INITIAL07-REG017');assert a['actual_material_body_ranges']==[[29,36],[120,129]];qual=[json.loads(l) for l in gzip.decompress((rp/'qualifications.jsonl.gz').read_bytes()).splitlines()];v=next(x for x in qual if x.get('registration_id')=='CAMERA-INITIAL07-REG017');assert v['context_only_excluded']==[[130,130]];contracts=[json.loads(l) for l in gzip.decompress((rp/'contracts.jsonl.gz').read_bytes()).splitlines()];assert all(any(x.get('id')==k for x in contracts) for k in ['CAMERA-INITIAL07-CONTRACT-101','CAMERA-INITIAL07-CONTRACT-108']);findings=[json.loads(l) for l in gzip.decompress((rp/'findings.jsonl.gz').read_bytes()).splitlines()];assert any(x.get('id')=='CAMERA-INITIAL07-F020' for x in findings)
prior=(p/'prior-number/BUNDLE-MANIFEST.json').read_bytes();assert sha(prior)=='260836a10fef67e1af7d0197e5cdbd6ccf4debf49b12592fe576e7d43c06694e';pr={x['path']:x for x in json.loads(prior)['files']}
for n in ['report.json','registration.json','read-receipt.json']:
 b=(p/'prior-number'/n).read_bytes();assert (len(b),sha(b))==(pr[n]['bytes'],pr[n]['sha256'])
oldreg=load('prior-number/registration.json');oldrec=load('prior-number/read-receipt.json');assert oldrec['registration_sha256']==sha((p/'prior-number/registration.json').read_bytes());assert datetime.datetime.fromisoformat(oldreg['registered_utc'])<datetime.datetime.fromisoformat(oldrec['recorded_utc'])<datetime.datetime.fromisoformat(r['registered_utc']);assert next(x for x in oldrec['reads'] if x.get('original_role')==2589)['actual_display_union']==[[160,205],[300,325]]
archive=p/'native/serde_json-1.0.151.crate';pack=archive.read_bytes();assert sha(pack)=='c841b55ecdae098c80dcae9cf767f6f8a0c2cdb3416bbef72181df4d0fe73f14';m=load('native/MANIFEST.json');assert m['sha256']==sha(pack) and m['bytes']==len(pack)
with tarfile.open(archive,'r:gz') as t:
 assert t.extractfile('serde_json-1.0.151/src/map.rs').read()==(p/'source/2785-historical.rs').read_bytes()
 for rf in ['support-registration.json','support2-registration.json','support3-registration.json','support4-registration.json','support5-registration.json']:
  for e in load(rf)['entries']:
   if e['kind']=='package-member':assert t.extractfile(e['path']).read()==(p/e['archive']).read_bytes()
for f,n in [('support/lock-old.lock',9814),('support/lock-current.lock',9418)]:
 ls=(p/f).read_text().splitlines();assert ls[n-1]=='name = "serde_json"' and ls[n]=='version = "1.0.151"' and sha(pack) in ls[n+2]
p16=load('reference/p16-patch-recovery.json');patch=(p/'reference/p16-tracked.patch').read_bytes();assert sha(patch)=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'==p16['recovered_patch']['sha256'] and len(patch)==p16['recovered_patch']['bytes'];assert p16['live_comparison']['status_counts']['??']==7
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==24
report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13 and len(load('read-scope-summary.json')['scopes'])==len(groups)
print(json.dumps({'status':'pass','scope':'Offline original registry/059/774 records, exact read receipts and unread complements, a120/6533/95e/f82 raw Git proofs, recorded P16 tracked patch checksum, native archive/lock/member identity, selected earlier packet records and 13 bounded perspectives; no product validation','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
