import gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';prior='6533e444fa37552927070cc8d8190907fd3b413e';p16='a120390947c89b703dc74c4255a13c035d054c50';records=[];seen=set()
def add(kind,rev,path,archive,sha,blob,**extra):
 k=(rev,path)
 if k in seen:return
 seen.add(k);records.append(dict(kind=kind,revision=rev,path=path,archive=archive,sha256=sha,blob=blob,**extra))
for e in json.loads((p/'registration.json').read_bytes())['entries']:
 if e['label']=='historical':add('original native source object transported via f82',f82,e['transport_path'],e['archive'],e['sha256'],e['git_blob_for_content'])
for rf in ['support-registration.json','support2-registration.json','support3-registration.json','support4-registration.json']:
 for e in json.loads((p/rf).read_bytes())['entries']:
  if e['kind']=='project-git':add('bounded project source',e['revision'],e['path'],e['archive'],e['sha256'],e['git_blob'])
for name in ['dialogue-build','dialogue-lib','authored-topic']:
 es=[]
 for rf in ['support-registration.json','support4-registration.json']:es.extend(json.loads((p/rf).read_bytes())['entries'])
 e=next(x for x in es if x['name']==name)
 for rev in [prior,p16]:add('individual historical base path equality, not entire snapshot',rev,e['path'],e['archive'],e['sha256'],e['git_blob'])
 add('original archived dialogue source object via f82',f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+e['sha256'],e['archive'],e['sha256'],e['git_blob'])
e=next(x for x in json.loads((p/'support-registration.json').read_bytes())['entries'] if x['name']=='value-de');add('original archived native Value object via f82',f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+e['sha256'],e['archive'],e['sha256'],e['git_blob'])
for e in json.loads((p/'historical-index.json').read_bytes())['records']:
 if e['kind']=='historical-774':add('original 774 camera record via f82',f82,e['transport_path'],e['file'],e['sha256'],e['git_blob'],encoding='gzip')
(p/'git-objects').mkdir(exist_ok=True);objs={};proof=[]
def data(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objs:
  dst=p/'git-objects'/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objs[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in records:
 commit=data('commit',x['revision']);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(data('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (hashlib.sha256(b).hexdigest(),oid,tree)==(x['sha256'],x['blob'],x['blob']);proof.append(dict(x,commit_tree=root,chain=chain))
(p/'git-proofs.json').write_text(json.dumps({'objects':objs,'proofs':proof,'qualification':'Historical package/object evidence via f82 is not project Git; dialogue archived individual objects match a120,6533,95e paths but P16 and pr-working overall snapshots are dirty. Personal reads remain as registered.'},indent=2)+'\n');print('proofs',len(proof),'objects',len(objs))
