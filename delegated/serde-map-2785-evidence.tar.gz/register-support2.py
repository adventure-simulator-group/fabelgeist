import datetime,hashlib,json,pathlib,subprocess,tarfile
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';cur='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();out=[]
specs=[('dialogue-lib-provenance','crates/adventuresim-dialogue/src/lib.rs','support/dialogue-lib.rs',[[440,470],[580,605]]),('workspace-manifest','Cargo.toml','support/workspace-manifest.toml',[[130,145]])]
for name,path,f,ranges in specs:
 b=subprocess.check_output(['git','-C',repo,'show',cur+':'+path]);dst=p/f
 if dst.exists():assert dst.read_bytes()==b
 else:dst.write_bytes(b)
 out.append({'kind':'project-git','name':name,'revision':cur,'path':path,'archive':f,'sha256':sha(b),'git_blob':blob(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
for name,member,f,ranges in [('value-implementation','serde_json-1.0.151/src/value/de.rs','support/value-de.rs',[[1,30],[145,155],[1320,1390]]),('json-deserializer-entry','serde_json-1.0.151/src/de.rs','support/json-de.rs',[[2495,2525],[2655,2685]])]:
 with tarfile.open(p/'native/serde_json-1.0.151.crate','r:gz') as t:b=t.extractfile(member).read()
 dst=p/f
 if dst.exists():assert dst.read_bytes()==b
 else:dst.write_bytes(b)
 out.append({'kind':'package-member','name':name,'revision':'serde_json 1.0.151','path':member,'archive':f,'sha256':sha(b),'git_blob':blob(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':out,'qualification':'Supplemental current adapter and package deserialization entry and key classifier; separately registered from earlier scopes and no project/code execution.'};(p/'support2-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('registration sha256',sha((p/'support2-registration.json').read_bytes()));print([(e['name'],e['EOF']) for e in out])
