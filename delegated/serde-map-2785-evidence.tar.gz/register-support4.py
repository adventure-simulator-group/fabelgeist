import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';cur='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();out=[]
for name,path,f,ranges in [('authored-topic','crates/adventuresim-dialogue/src/authoring_schema.rs','support/authoring-schema.rs',[[40,65]]),('runtime-topic','crates/adventuresim-dialogue/src/lib.rs','support/dialogue-lib.rs',[[50,80]])]:
 b=subprocess.check_output(['git','-C',repo,'show',cur+':'+path]);dst=p/f
 if dst.exists():assert dst.read_bytes()==b
 else:dst.write_bytes(b)
 out.append({'kind':'project-git','name':name,'revision':cur,'path':path,'archive':f,'sha256':sha(b),'git_blob':blob(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':out,'qualification':'Supplemental authored and runtime topic label shape; source inspection only.'};(p/'support4-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('registration',sha((p/'support4-registration.json').read_bytes()))
