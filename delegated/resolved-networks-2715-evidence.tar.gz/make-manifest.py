from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();files=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and p!=b/'MANIFEST.json':
  raw=p.read_bytes();files.append({'path':str(p.relative_to(b)),'sha256':h(raw),'bytes':len(raw)})
d={'schema':'726-pr-working-resolved-networks-2715-manifest-v1','created_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/hair_ops','files':files,'exclusions':['MANIFEST.json only'],'qualification':'Original and reconstructed records separately labelled; no checkpoint3821 promotion.'};(b/'MANIFEST.json').write_text(json.dumps(d,indent=2)+'\n');print('files',len(files),'manifest_sha256',h((b/'MANIFEST.json').read_bytes()))
