'''Offline evidence-integrity checks only; never executes product, geometry or tests.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files'];assert all(original[i]==sel['registry_rows'][str(i)] for i in [531,2715]);assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id']=='pr-working']
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];assert json.loads(qbytes)['entries'][639]==sel['queue_rows']['639'];lbytes=gzip.decompress((b/'recovered/original-059-ledger.json.gz').read_bytes());assert h(lbytes)==sel['ledger_uncompressed_sha256'];assert json.loads(lbytes)['segovb_continuation']['lens13']['delegated_connected_contracts_pending_alias'][96]==sel['ledger_selections']['/segovb_continuation/lens13/delegated_connected_contracts_pending_alias/96']
catalog=load('recovered/catalog-774.json')['rows'];old,cur=reg['versions'];body=(b/old['local']).read_bytes()
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:assert t.extractfile(old['sha256']).read()==body
assert h(body)==old['sha256']==original[2715]['sha256']==catalog[2715]['expected_sha256'];assert catalog[2715]['origin']=='git:6533e444fa37552927070cc8d8190907fd3b413e:'+reg['path']
for c in reg['comparison_git_paths']+load('e275-comparison-registration.json')['entries']:assert (b/c['local']).read_bytes()==body and c['display_planned']==False
assert (b/cur['local']).read_bytes()==body
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def partition(n,ranges):
 nums=[i for a,z in ranges for i in range(a,z+1)];return len(nums)==n and set(nums)==set(range(1,n+1))
for v in reg['versions']:
 p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'];assert p['actual_assigned_displays']==[[1,110],[111,192],[202,209]] and partition(v['eof'],p['actual_assigned_displays']+p['additional_context_displays']+p['unread_complement'])
assert rec['assigned'][0]['unread_complement']==[[193,201],[210,463]] and rec['assigned'][1]['unread_complement']==[]
planned={}
for n in ['support-registration.json','more-support-registration.json']:
 for x in load(n)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];assert partition(x['eof'],x['displayed']+x['unread_complement']);assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
r774=[json.loads(s) for s in (b/'historical/774/native-range-registration.jsonl').read_text().splitlines()];q774=[json.loads(s) for s in (b/'historical/774/native-final-qualifications.jsonl').read_text().splitlines()];batch=[json.loads(s) for s in (b/'historical/774/native-batch3-qualifications.jsonl').read_text().splitlines()];ob=original[2715]['admission03_scope_observations'][0];assert r774[ob['row_1based']-1]==ob['original_record'];assert next(x for x in q774 if x['registration_id']=='NATIVE-ADMISSION03-REG-071')==ob['local_qualifications'][0];assert batch[3]==ob['local_qualifications'][0]['qualification_history'][0]['payload'];assert ob['effective_material_ranges']==[[1,192],[202,209]]
ob=original[531]['producer_reached_contract_observations'][0];traces=[json.loads(s) for s in (b/'historical/774/root-producer-traces.jsonl').read_text().splitlines()];t=next(x for x in traces if x['id']==ob['receipt']);key,index=ob['json_pointer'].strip('/').split('/');assert t[key][int(index)]==ob['source_context'] and ob['read_ranges_as_recorded']==[[1,126]]
l11=load('historical/059/segovb/READ-L11-442.json');x=next(x for x in l11['sources'] if x['original_index']==2715);assert x['fresh_personal_body_reads']==[[1,192],[202,209]] and h((b/'historical/059/segovb/REGISTRATION-SEGOVB-1634.json').read_bytes())==x['registration_sha256']
p=load('historical/059/segovb/READ-L11-648.json');x=next(x for x in p['rows'] if x.get('registration')=='PL11-0845');assert x['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and x['fresh_personal_body_ranges']==[[120,175],[364,463]] and 'lens11_reconcile' in x['attribution'];assert h((b/'historical/059'/p['proposal']).read_bytes())==p['proposal_sha256']
p=load('historical/059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-865-BVH-GAPS-RESOLVED-STATE.json');x=next(x for x in p['rows'] if x['original_index']==2715);assert x['fresh_personal_body_reads']==[[360,463]] and x['unread_source_ranges']==[[1,359]] and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-945.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False;x=next(x for x in p['rows'] if x['original_index']==2715);assert x['fresh_personal_body_reads']==[[1,192],[202,209]] and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256'];q=x['identity_specific_windows_qualification'];assert h((b/'historical/059'/q['path']).read_bytes())==q['sha256']
for x in p['partial_read_receipts']:assert h((b/'historical/059'/x['path']).read_bytes())==x['sha256']
p=load('historical/059/segovb/READ-L13-PARALLEL-029.json');assert p['root_personal_rereads']==[] and h((b/'historical/059/parallel-l13-20261029/READ-PL13-031.json').read_bytes())==p['delegated_receipt']['sha256'];x=next(x for x in p['evidence']['rows'] if x['original']==531);assert x['fresh_personal_assessed_ranges']==[[1,126]]
p=load('prior/measurement-2679-read-receipt.json');x=next(x for x in p['support'] if x['path']==reg['path']);assert x['displayed']==[[190,220]] and x['ordered_role_credit']==0;assert 'before extra-support registration' in p['pre_registration_navigation']['known_support_navigation']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: original pr-working and pinned95e role2715 separately displayed; excluded current lines separately registered support, historical authors/partial union and unadopted proposal preserved; %d Git proofs and %d bounded supports. Thirteen partial perspectives; offline evidence integrity only, no product/geometry/build/test/probe.'%(len(proof['proofs']),len(rec['support'])))
