# Resolved networks: original pr-working role 2715

This source-only packet is by `/root/hair_ops`. Start with `REPORT.json`,
`registration.json` and `read-receipt.json`. The original archive object and
pinned 95e copy were separately displayed at original material ranges 1–192
and 202–209. The excluded current ranges 193–201 and 210–463 were separately
registered and displayed only as support. They are not historical material or
other-lens credit, and the archived historical copies were not displayed there.

The pr-working snapshot records 6533 HEAD plus unrelated modifications, and
matching one source object does not make its whole state clean. f82 is an
evidence transport. The 774 native reviewer, 059 root and delegate, 059 Lens13
bonding reviewer, later unadopted proposal 945 and previous same-agent support
retain their exact revision, ranges and attribution. The earlier role 2679
receipt also preserves prior navigation that preceded its support registration.

`recovered/` contains the original registry, source archive and 059 ledger and
queue, plus the older reconstructed catalogue. `historical/` contains exact
historical records; `historical-selections-reconstructed.json` contains newly
reconstructed selections. `git-proofs.json` and `git-objects/` support offline
per-file membership proofs. `MANIFEST.json` hashes every packet file except the
top-level manifest itself, including the nested recovered manifest.

Run `python3 verify-evidence.py` only for offline evidence integrity. The
thirteen perspectives are bounded, not whole-lens clearance. No checkpoint
3821 promotion, product or geometry execution, fixture, build, test, runtime
probe, repair or publication edit was performed.
