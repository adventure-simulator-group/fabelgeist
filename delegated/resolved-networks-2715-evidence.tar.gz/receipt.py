from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def missing(n,r):
 a=set(range(1,n+1));[a.difference_update(range(x,y+1)) for x,y in r];out=[]
 for x in sorted(a):
  if not out or x!=out[-1][1]+1:out.append([x,x])
  else:out[-1][1]=x
 return out
reg=load('registration.json');assigned=[]
for i,v in enumerate(reg['versions']):
 d=[[1,110],[111,192],[202,209]];c=[] if i==0 else [[193,201],[210,340],[341,463]];assigned.append({'original_index':2715,'source_id':reg['source_id'],'identity':v.get('identity','pinned95e current source'),'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_assigned_displays':d,'additional_context_displays':c,'unread_complement':missing(v['eof'],d+c),'qualification':'Only1–192 and202–209 original material; additional current excluded lines separately registered support, no retroactive historical role or lens credit.'})
w={'crates/fabelgeist-geometry/src/measurement.rs':[[1,104]],'crates/adventuresim-building-generator/src/generator/wall_corner_bonds.rs':[[145,215]],'crates/adventuresim-building-generator/src/audit/bonding_metrics.rs':[[1,126]],'crates/adventuresim-building-generator/src/audit/junction_bearing.rs':[[1,70]],'crates/adventuresim-building-generator/src/audit/resolved_geometry.rs':[[1,80],[220,255],[280,305],[330,420]],'crates/adventuresim-building-generator/src/audit/resolved_geometry_helpers.rs':[[80,175]],'crates/adventuresim-building-generator/src/audit/support.rs':[[1,139]],'crates/adventuresim-building-generator/src/generator/roof_edge_binding.rs':[[1,164]],'crates/adventuresim-building-generator/src/spatial_geometry/coordinates.rs':[[1,140]],'crates/adventuresim-building-generator/src/spatial_geometry/bounds.rs':[[1,98]],'crates/adventuresim-building-generator/src/audit/bearing.rs':[[1,138]],'crates/adventuresim-building-generator/src/generator/roof_finalization.rs':[[1,138]]};supports=[]
for n in ['support-registration.json','more-support-registration.json']:
 for x in load(n)['entries']:
  d=w[x['path']];supports.append({'revision':x['revision'],'path':x['path'],'sha256':x['sha256'],'local':x['local'],'eof':x['eof'],'displayed':d,'unread_complement':missing(x['eof'],d),'registration':n,'ordered_role_credit':0})
refs=[]
for n in ['registration.json','support-registration.json','more-support-registration.json','e275-comparison-registration.json']:refs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','method':'Independently prospective registrations then bounded line-numbered personal displays; navigation grep output within reported windows. Test source only, no test execution. Current receipt is reconstructed from this work, not an original historical receipt.','registrations':refs,'assigned':assigned,'support':supports,'prior_disclosure':'Earlier same-agent role2679 95e resolved_networks190–220 support and its prior unregistered navigation grep remain explicitly disclosed in prior/measurement-2679-read-receipt.json. Earlier role2542 independent 6533/95e full source displays remain separately recorded.','runtime_validation':'None; no product, geometry, fixture, tests, builds, probes or repairs.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
