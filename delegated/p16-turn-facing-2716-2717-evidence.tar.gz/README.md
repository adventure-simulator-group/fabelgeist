# P16 turn and downed-facing audit evidence

This is a bounded source-only review by `/root/rig_identity` of original
physical-p16 roles 2716 (`turn_deadline.rs`, lines 1–208) and 2717
(`downed_facing.rs`, lines 1–325), with separately registered personal reads
at pinned project revision `95e63628f9d70b8dd6e6fede64334696c6995009`.
`REPORT.json` contains the source trace, conditional sector-tuning candidate,
existing turn and lattice relationships, open policy questions, and thirteen
bounded lens dispositions. None implies whole-lens completion.

`registration.json`, the support/native registration files and
`personal-read-receipt.json` document source identities, prospective scopes,
actual displayed chunks and uninspected complements. Full retained source bytes
are not automatically read coverage. Original 774 Native, 059 Segovb/Adler,
e275 Root and earlier current-session scopes and their attribution are kept
separate. Source test text is never executed.

`history/` preserves exact 774 and selected 059 records, the full original
registry and transport manifest, historical 059 queue/ledger summaries, and
previous current assessments. Selected registry and queue files are separately
marked reconstructions. The historical L13 root row and proposed disposition
are recovered transcript extracts only; the complete original packet,
qualification and adoption remain unrecovered. Earlier read attribution and
revisions are not promoted into checkpoint 3821. The original 059 payload Git
path was unavailable in the inspected object stores, so selected 059 bytes are
matched to the recovered original transport manifest rather than claimed as a
locally recovered Git path.

`git-proofs.json` and the retained commit/tree objects bind the source paths.
The f82 commit transports evidence; a120 is the P16 base, not a dirty commit.
The reproduced tracked P16 patch matches the recorded digest; seven untracked
paths are outside that patch. It does not establish the original invocation,
uninterrupted custody or current state of the old worktree. Per-file identity
with other revisions never establishes whole-snapshot cleanliness.

The nightly Rust reference and source evidence are separately identified; a
matching project toolchain pin does not establish the compiler or flags of any
actual product build. Local source paths and historical records may require
review and path redaction before public publication; preserve exact original
bytes and hash separately and identify reconstructed/redacted copies.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` for evidence
integrity only. No product code, fixture, animation, build, test, probe or
runtime validation is performed by these checks.
