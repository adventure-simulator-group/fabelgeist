from pathlib import Path
from datetime import datetime,timezone
import json
b=Path(__file__).resolve().parent;x=next(z for z in json.loads((b/'support-registration.json').read_bytes())['entries'] if z['id']=='state-wire');x=dict(x);x['id']='state-transition-support';x['prospective_personal_read_ranges']=[[1290,1360],[1410,1440]];x['qualification']='Separately registered 95e body-transition and accessor support; earlier line-search was navigation only.';out={'schema':'726-prospective-support-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':[x]};(b/'state-tail-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
