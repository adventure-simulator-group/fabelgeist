from pathlib import Path
from datetime import datetime
import gzip,hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json');receipt=load('personal-read-receipt.json');names=['registration.json','support-registration.json','extra-registration.json','tail-registration.json','state-tail-registration.json','body-registration.json','native-registration.json','native-ref-registration.json'];groups={n:load(n) for n in names};allregs={(name,e['id']):e for name,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[1783,1789,2716,2717]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
p16=next(x for x in registry['snapshots'] if x['id']=='physical-p16');pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert p16['base']==p16['head']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(p16['status_porcelain'])==159;assert sha((b/'history/p16-tracked.patch').read_bytes())==p16['patch_sha256'];assert pr['base']=='3a50b708381ad00c116445c2c999a49c3943088b' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4;assert sha((b/'sources/turn-pr-base-3a50-not-read.rs').read_bytes())==registry['files'][1789]['base_sha256']
for r in groups.values():
 for x in r['entries']:
  d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
  if 'git_blob' in x:assert oid('blob',d)==x['git_blob']
for role,hi,end in [(2716,1789,208),(2717,1783,325)]:
 old=next(x for x in groups['registration.json']['entries'] if x['id']==f'{role}-p16');cur=next(x for x in groups['registration.json']['entries'] if x['id']==f'{role}-current');assert old['sha256']==cur['sha256']==registry['files'][role]['sha256']==registry['files'][hi]['sha256'] and old['prospective_personal_read_ranges']==registry['files'][role]['material_ranges']==[[1,end]] and (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes();assert all(v['equal_to_p16'] and v['equal_to_current'] for v in old['comparison_metadata'].values())
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in sel['entries']]==[98,789,791,1461,1466,1467]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[98]['contract_id']=='ADLER-L11-DOWNED-ROLL-LATTICE-RANGE' and q[791]['contract_id']=='Q-L1-df76d180ba05ef794292' and q[1461]['contract_id']=='Q-L12-9c0f42671d4d966b6fd9'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
r=load('history/059/segovb/READ-L11-443.json')
for role,end in [(2716,208),(2717,325)]:
 e=next(x for x in r['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==[[1,end]]
for fn,role,intervals in [('adler/READ-L11-263.json',1783,[[1,180],[181,353]]),('adler/READ-L11-264.json',1789,[[1,200],[201,400],[401,432]])]:
 e=next(x for x in load('history/059/'+fn)['sources'] if x['original_index']==role);assert e['fresh_reads']==intervals
for fn,role,end in [('segovb/READ-L12-577.json',1783,353),('segovb/READ-L12-580.json',1789,432)]:
 e=next(x for x in load('history/059/'+fn)['rows'] if x['original_index']==role);assert e['fresh_personal_body_reads']==[[1,end]] and e['same_lens_reuse']==[]
e=next(x for x in load('history/059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-036.json')['rows'] if x['git_path'].endswith('state/downed_facing.rs'));assert e['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and e['fresh_personal_body_ranges']==[[1,353]]
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
regs=[json.loads(z) for z in gun('history/774/native/admission03/source-range-registration.jsonl.gz').splitlines()];quals={x['registration_id']:x for x in map(json.loads,gun('history/774/native/admission03/source-qualifications-final-current.jsonl.gz').splitlines())}
for role,end in [(2716,208),(2717,325)]:
 r=registry['files'][role]['admission03_scope_observations'][0];assert regs[r['row_1based']-1]==r['original_record'] and r['effective_material_ranges']==[[1,end]] and quals[r['registration_id']]==r['local_qualifications'][0]
l13=load('history/l13-root-712-manifest.json');assert sha((b/'history/l13-root-712-prior-row-extracts.json').read_bytes())==l13['prior_row_extracts_sha256'];proposal=load('history/l13-root-712-proposal-extract.json');assert proposal['proposed_question'] is None and all('zero reread' in next(z['assessment'] for z in proposal['source_assessments'] if z['original']==i) for i in [2716,2717]);assert (b/'support/native-primitive-docs.rs').read_bytes()==gun('history/rust-nightly-primitive-docs.rs.gz')
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==30
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
assert len(receipt['entries'])==len(allregs)==20;cover={}
for e in receipt['entries']:
 source=allregs[(e['registration'],e['id'])];rr=groups[e['registration']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']) and e['registration_sha256']==sha((b/e['registration']).read_bytes()) and e['sha256']==source['sha256'];actual={i for a,z in e['actual_personal_display_chunks'] for i in range(a,z+1)};planned={i for a,z in source['prospective_personal_read_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement_for_this_registration'] for i in range(a,z+1)};assert actual<=planned and actual.isdisjoint(unread) and actual|unread==set(range(1,source['eof']+1));cover.setdefault(e['id'],set()).update(actual)
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   possible=[e for e in allregs.values() if e['id']==x['id']];assert len(possible)==1 and x['sha256']==possible[0]['sha256'] and x['archive']==possible[0]['archive'];assert all(set(range(a,z+1))<=cover[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','roles_2716_2717':{'2716':[[1,208]],'2717':[[1,325]]},'historic_tests_excluded':True,'registered_personal_scopes':len(receipt['entries']),'historical_059_manifest_matched':len(history['records_059']),'historical_774_git_paths_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'bounded_lenses':len(report['thirteen_lens_dispositions']),'p16_reproduced_tracked_patch_digest_verified':True,'original_059_git_payload_path':'unavailable in inspected stores; selected exact records match recovered transport manifest','l13_recovery':'partial transcript extract and proposal; complete packet, qualification and adoption unrecovered','product_build_test_execution_probe_validation':'not performed'},indent=2))
