from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
spec=[('config-root','crates/adventuresim-tactical-core/src/combat_config.rs',[[400,670]]),('maneuvers-config','crates/adventuresim-tactical-core/src/combat_config/maneuvers.rs',[[1,120]]),('elapsed','crates/adventuresim-core/src/elapsed.rs',[[1,120]]),('yaml','content/tactical/combat.yaml',[[95,110],[190,205]]),('server-startup','crates/adventuresim-tactical-server/src/startup.rs',[[1,90]]),('runtime','crates/adventuresim-tactical-core/src/combat_config/runtime.rs',[[1,57]])]
rows=[]
for tag,path,ranges in spec:
 d=git('show',rev+':'+path);eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/'+tag+'.src';(b/dest).write_bytes(d);rows.append({'id':tag,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Bounded current support only; no parse, loading, installation or execution of product config.'})
out={'schema':'726-prospective-extra-support-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'extra-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
