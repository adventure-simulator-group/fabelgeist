from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();(b/'support').mkdir(exist_ok=True)
spec=[('server-posture','crates/adventuresim-tactical-server/src/player_projection/posture_facing.rs',[[1,162]]),('transitions-config','crates/adventuresim-tactical-core/src/combat_config/state_transitions.rs',[[1,200]]),('animation-measure','crates/adventuresim-tactical-core/src/animation/measurement.rs',[[1,150]]),('state-wire','crates/adventuresim-tactical-core/src/animation/state.rs',[[1080,1235]]),('capture-viewer','crates/adventuresim-tactical-client/src/animation_viewer/capture.rs',[[300,345]])]
rows=[]
for tag,path,ranges in spec:
 d=git('show',rev+':'+path);eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/'+tag+'.rs';(b/dest).write_bytes(d);rows.append({'id':tag,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Current source support only; prior grep matches are navigation and prior reviewers keep their own scopes.'})
out={'schema':'726-prospective-support-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
