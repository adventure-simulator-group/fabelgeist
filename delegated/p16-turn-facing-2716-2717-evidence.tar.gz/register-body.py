from pathlib import Path
from datetime import datetime,timezone
import json
b=Path(__file__).resolve().parent;x=next(z for z in json.loads((b/'support-registration.json').read_bytes())['entries'] if z['id']=='state-wire');x=dict(x);x['id']='state-body-support';x['prospective_personal_read_ranges']=[[40,90]];x['qualification']='Separately registered 95e body mode support.';out={'schema':'726-prospective-support-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':[x]};(b/'body-registration.json').write_text(json.dumps(out,indent=2)+'\n')
