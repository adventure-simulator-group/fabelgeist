from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
b=Path(__file__).resolve().parent;old=json.loads((b/'extra-registration.json').read_bytes());x=next(z for z in old['entries'] if z['id']=='config-root');x=dict(x);x['id']='config-root-tail';x['prospective_personal_read_ranges']=[[671,x['eof']]];x['qualification']='Separately registered 95e config tail; no config execution or validation.';out={'schema':'726-prospective-support-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':[x]};(b/'tail-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
