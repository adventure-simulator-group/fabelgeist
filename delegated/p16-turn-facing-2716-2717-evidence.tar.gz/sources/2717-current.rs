//! Continuous downed-roll coordinates, contact-sector policy and camera admission.

use super::turn_deadline::body_yaw;
use super::*;

/// Finite signed, unwrapped half turns around the downed body's longitudinal axis.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize, derive_more::Into)]
#[serde(try_from = "f32", into = "f32")]
pub struct SignedHalfTurns(f32);

/// Finite nonnegative maximum half-turn travel for one camera observation.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize, derive_more::Into)]
#[serde(try_from = "f32", into = "f32")]
pub struct DownedFacingStep(f32);

/// Signed roll command in [-1,1], distinct from metres/second and cycle phase.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize, derive_more::Into)]
#[serde(try_from = "f32", into = "f32")]
pub struct DownedRollMotion(f32);

#[derive(Deserialize)]
struct DownedFacingWire {
    half_turns: f32,
    target: DownedFacingPose,
    lateral_motion: f32,
}

/// Camera-driven roll around a downed character's head-to-feet axis. The
/// target is one of four sticky sectors; `half_turns` is the transient
/// interpolation coordinate. Values remain unwrapped so crossing the rear
/// camera seam does not reverse an in-progress roll.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(from = "DownedFacingWire")]
pub struct DownedFacingState {
    half_turns: SignedHalfTurns,
    target: DownedFacingPose,
    lateral_motion: DownedRollMotion,
}

/// Whether camera aim is holding a sector or releasing to stable contact.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DownedFacingAim {
    Held,
    Released,
}

/// Discrete camera-facing pose selected while a character is downed.
/// Interpolation occurs only while moving between these four sector centers.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum DownedFacingPose {
    #[default]
    Prone,
    RollRight,
    Supine,
    RollLeft,
}

impl SignedHalfTurns {
    pub const ZERO: Self = Self(0.0);
    pub fn from_half_turns(value: f32) -> AnimationValueResult<Self> {
        if !value.is_finite() {
            return Err(AnimationValueError::NonFinite {
                quantity: AnimationQuantity::DownedFacing,
            });
        }
        Ok(Self(value))
    }
    /// Project only at the roll's lattice/interpolation, scalar fixture or wire math.
    pub fn half_turns(self) -> f32 {
        self.0
    }
}

impl DownedFacingStep {
    pub const ZERO: Self = Self(0.0);
    pub const SETTLE_CONTACT: Self = Self(1.0);
    pub fn from_half_turns(value: f32) -> AnimationValueResult<Self> {
        super::super::measurement::checked_nonnegative(value, AnimationQuantity::DownedFacingStep)
            .map(Self)
    }
    /// Camera timestep production preserves the prior no-motion sanitation for
    /// a nonfinite computed step; the checked scalar constructor never repairs it.
    pub fn for_frame(elapsed: AnimationElapsed, full_turn: PositiveAnimationDuration) -> Self {
        let step = elapsed.seconds() / full_turn.seconds();
        Self(if step.is_finite() { step.max(0.0) } else { 0.0 })
    }
    fn half_turns(self) -> f32 {
        self.0
    }
}

impl DownedRollMotion {
    pub const REST: Self = Self(0.0);
    pub const LEFT: Self = Self(-1.0);
    pub const RIGHT: Self = Self(1.0);
    pub fn from_fraction(value: f32) -> AnimationValueResult<Self> {
        let quantity = AnimationQuantity::DownedRollMotion;
        if !value.is_finite() {
            return Err(AnimationValueError::NonFinite { quantity });
        }
        if !(-1.0..=1.0).contains(&value) {
            return Err(AnimationValueError::OutsideSignedUnitInterval { quantity });
        }
        Ok(Self(value))
    }
    /// Native controller speed multiplication or movement-vector component.
    pub fn fraction(self) -> f32 {
        self.0
    }
    pub fn is_moving(self) -> bool {
        self.0.abs() > 0.0
    }
    fn from_change(change: f32) -> Self {
        Self(if change.abs() > 1.0e-5 {
            change.signum()
        } else {
            0.0
        })
    }
}

impl From<DownedFacingWire> for DownedFacingState {
    fn from(wire: DownedFacingWire) -> Self {
        // Preserve the existing snapshot normalization at its actual wire boundary.
        Self {
            half_turns: SignedHalfTurns(if wire.half_turns.is_finite() {
                wire.half_turns
            } else {
                0.0
            }),
            target: wire.target,
            lateral_motion: DownedRollMotion(if wire.lateral_motion.is_finite() {
                wire.lateral_motion.clamp(-1.0, 1.0)
            } else {
                0.0
            }),
        }
    }
}

impl TryFrom<f32> for SignedHalfTurns {
    type Error = AnimationValueError;
    fn try_from(value: f32) -> AnimationValueResult<Self> {
        Self::from_half_turns(value)
    }
}
impl TryFrom<f32> for DownedFacingStep {
    type Error = AnimationValueError;
    fn try_from(value: f32) -> AnimationValueResult<Self> {
        Self::from_half_turns(value)
    }
}
impl TryFrom<f32> for DownedRollMotion {
    type Error = AnimationValueError;
    fn try_from(value: f32) -> AnimationValueResult<Self> {
        Self::from_fraction(value)
    }
}

impl DownedFacingPose {
    fn from_half_turns(value: f32) -> Self {
        match (value * 2.0).round() as i64 % 4 {
            0 => Self::Prone,
            1 | -3 => Self::RollRight,
            2 | -2 => Self::Supine,
            3 | -1 => Self::RollLeft,
            _ => unreachable!("remainder is bounded to four downed poses"),
        }
    }

    fn canonical_half_turns(self) -> f32 {
        match self {
            Self::Prone => 0.0,
            Self::RollRight => 0.5,
            Self::Supine => 1.0,
            Self::RollLeft => -0.5,
        }
    }

    fn half_turns_near(self, reference: f32) -> f32 {
        let canonical = self.canonical_half_turns();
        canonical + ((reference - canonical) / 2.0).round() * 2.0
    }
}

impl DownedFacingState {
    pub(super) fn landed(target: DownedFacingPose) -> Self {
        Self {
            half_turns: SignedHalfTurns(target.canonical_half_turns()),
            target,
            lateral_motion: DownedRollMotion::REST,
        }
    }
    pub(super) fn normalized(mut self) -> Self {
        self.target = DownedFacingPose::from_half_turns(
            self.target.half_turns_near(self.half_turns.half_turns()),
        );
        self
    }

    pub fn roll_coordinate(self) -> SignedHalfTurns {
        self.half_turns
    }

    pub fn lateral_motion(self) -> DownedRollMotion {
        self.lateral_motion
    }

    pub fn target(self) -> DownedFacingPose {
        self.target
    }
}

impl SkeletonState {
    /// Follows or settles the downed roll. Held aim selects one of four sticky
    /// camera sectors; only a sector change interpolates the pose. After
    /// release, the retained roll coordinate settles to the nearest whole
    /// contact pose, keeping body parity at exact half-roll ties.
    /// Returns true while the camera-driven state remains active.
    pub fn advance_downed_facing(
        &mut self,
        camera_target_half_turns: SignedHalfTurns,
        aim: DownedFacingAim,
        maximum_step: DownedFacingStep,
    ) -> AnimationValueResult<bool> {
        if !matches!(self.body, BodyState::Prone | BodyState::Supine)
            || self.posture_transition.is_some()
        {
            self.downed_facing = None;
            return Ok(false);
        }
        let aim_held = aim == DownedFacingAim::Held;
        let camera_target = camera_target_half_turns.half_turns();
        let initial_target = match self.body {
            BodyState::Prone => DownedFacingPose::Prone,
            BodyState::Supine => DownedFacingPose::Supine,
            _ => unreachable!("downed body checked above"),
        };
        let initial = initial_target.half_turns_near(camera_target);
        let previous = self.downed_facing;
        let current = previous
            .map(|state| state.half_turns.half_turns())
            .unwrap_or(initial);
        let target = if aim_held {
            let tuning = crate::combat_config::runtime_animation_config().state_transitions;
            let committed = previous.map(|state| state.target).unwrap_or(initial_target);
            let committed_half_turns = committed.half_turns_near(current);
            let camera_unwrapped =
                camera_target + ((committed_half_turns - camera_target) / 2.0).round() * 2.0;
            let target_pose = if (camera_unwrapped - committed_half_turns).abs()
                > tuning.downed_facing_sector_half_width.half_turns()
                    + tuning.downed_facing_edge_stickiness.half_turns()
            {
                DownedFacingPose::from_half_turns(camera_unwrapped)
            } else {
                committed
            };
            target_pose.half_turns_near(camera_unwrapped)
        } else {
            let lower = current.floor();
            if (current - lower - 0.5).abs() <= 1.0e-4 {
                match self.body {
                    BodyState::Prone => (current / 2.0).round() * 2.0,
                    BodyState::Supine => ((current - 1.0) / 2.0).round() * 2.0 + 1.0,
                    _ => unreachable!("downed body checked above"),
                }
            } else {
                current.round()
            }
        };
        let target_pose = if aim_held {
            DownedFacingPose::from_half_turns(target)
        } else if (target as i64).rem_euclid(2) == 0 {
            DownedFacingPose::Prone
        } else {
            DownedFacingPose::Supine
        };
        let step = maximum_step.half_turns().max(0.0);
        let next = current + (target - current).clamp(-step, step);
        self.downed_facing = Some(DownedFacingState {
            half_turns: SignedHalfTurns::from_half_turns(next).map_err(|_| {
                AnimationValueError::Overflow {
                    quantity: AnimationQuantity::DownedFacing,
                }
            })?,
            target: target_pose,
            lateral_motion: DownedRollMotion::from_change(next - current),
        });

        if (next - next.round()).abs() <= 1.0e-4 {
            let contact = next.round() as i64;
            self.transition_body(if contact.rem_euclid(2) == 0 {
                BodyState::Prone
            } else {
                BodyState::Supine
            });
            if !aim_held {
                self.downed_facing = None;
                return Ok(false);
            }
        }
        Ok(true)
    }
}

/// Converts camera yaw into the continuous downed-roll coordinate relative to
/// the body's fixed head direction. A quarter turn is the half-roll pose and a
/// half turn is the opposite contact pose.
pub fn downed_camera_roll_target(
    body_rotation: Quat,
    controller_orientation: Quat,
) -> SignedHalfTurns {
    let body = body_yaw(body_rotation);
    let camera_forward = controller_yaw(controller_orientation) * Vec3::NEG_Z;
    let camera = camera_forward.x.atan2(camera_forward.z);
    let mut delta = (camera - body + std::f32::consts::PI).rem_euclid(std::f32::consts::TAU)
        - std::f32::consts::PI;
    if (delta + std::f32::consts::PI).abs() <= 1.0e-5 {
        delta = std::f32::consts::PI;
    }
    let target = delta / std::f32::consts::PI;
    // This is the original camera-observation sanitation, now at its producer.
    SignedHalfTurns(if target.is_finite() { target } else { 0.0 })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn camera_yaw_maps_quarter_and_half_turns_to_downed_roll() {
        let body = Quat::IDENTITY;
        let same_heading = Quat::from_rotation_y(std::f32::consts::PI);
        let side_heading = Quat::from_rotation_y(std::f32::consts::FRAC_PI_2);
        assert!(
            downed_camera_roll_target(body, same_heading)
                .half_turns()
                .abs()
                < 0.0001
        );
        assert!(
            (downed_camera_roll_target(body, side_heading)
                .half_turns()
                .abs()
                - 0.5)
                .abs()
                < 0.0001
        );
        assert!(
            (downed_camera_roll_target(body, Quat::IDENTITY).half_turns() - 1.0).abs() < 0.0001
        );
    }
}
