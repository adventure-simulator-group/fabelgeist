from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda x:hashlib.sha256(x).hexdigest();groups=['registration.json','support-registration.json','extra-registration.json','tail-registration.json','state-tail-registration.json','body-registration.json','native-registration.json','native-ref-registration.json'];chunks=lambda z:[[a,min(a+54,z)] for a in range(1,z+1,55)];actual={'2716-p16':chunks(208),'2716-current':chunks(208),'2717-p16':chunks(325),'2717-current':chunks(325),'server-posture':[[1,55],[56,110],[111,162]],'transitions-config':[[1,25]],'animation-measure':[[1,55],[56,107]],'state-wire':[[1080,1132],[1133,1184],[1185,1235]],'capture-viewer':[[300,345]],'config-root':[[400,450],[451,500],[501,550],[551,600],[601,650],[651,670]],'maneuvers-config':[[1,19]],'elapsed':[[1,60],[61,120]],'yaml':[[95,110],[190,205]],'server-startup':[[1,55],[56,90]],'runtime':[[1,57]],'config-root-tail':[[671,720],[721,770]],'state-transition-support':[[1290,1339],[1340,1360],[1410,1440]],'state-body-support':[[40,90]],'native-primitive-docs':[[1172,1233]],'native-rust-reference':[[1898,1922]]}
def complement(eof,ranges):
 s={i for a,z in ranges for i in range(a,z+1)};out=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in s and start is None:start=i
  if (i>eof or i in s) and start is not None:out.append([start,i-1]);start=None
 return out
rows=[]
for name in groups:
 r=json.loads((b/name).read_bytes())
 for e in r['entries']:
  ranges=actual[e['id']];rows.append({'id':e['id'],'registration':name,'registration_sha256':sha((b/name).read_bytes()),'archive':e['archive'],'revision':e.get('revision',e.get('source_package')),'sha256':e['sha256'],'actual_personal_display_chunks':ranges,'unread_complement_for_this_registration':complement(e['eof'],ranges),'qualification':'Historical role body and separate current support have separate receipts even for byte-identical files; all test source only, never executed.'})
out={'schema':'726-personal-read-receipt-v1','author':'/root/rig_identity','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows,'navigation':'Earlier git-grep individual matching lines are locator context only, including test-source lines; they are not qualified body coverage.','additional_scope':'config-root and config-root-tail are separately registered displays of the same 95e file; their combined personally displayed contiguous source is 400–770, while 1–399 and 771–779 remain unread.'};(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('read scopes',len(rows))
