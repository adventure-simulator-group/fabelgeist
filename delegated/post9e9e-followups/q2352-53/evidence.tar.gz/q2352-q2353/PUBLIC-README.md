# Disclosure q2352–q2353 evidence

All archived bodies are exact captured representations. Selected 059 queue
and ledger projections and the selected older-774 JSONL field view are
reconstructed objects; original selected queue bytes, older JSONL lines, stored
and decoded transport identities, and historical reviewer scopes remain
separate. Read READ-LIMITS.json for actual personal source displays and unread
complements. The corrected F023 metadata-locator chronology is retained.

Run VERIFY-EVIDENCE.py beside the manifest and archive for read-only evidence
checks; passing --repo adds commit-to-tree and exact original-record checks.
The retained source-display helper writes files and must not be run against a
frozen packet. The review does not execute product code, validate behavior,
close a queue or lens, or decide a repair alias.
