# Investigation q2336–q2337 source-evidence packet

Every archived body is the exact captured representation. The selected queue
and ledger projections are reconstructed JSON objects; raw selected 059 queue
bytes, their whole-source identities, revision and attribution remain separate.
READ-LIMITS.json and its e275 addendum distinguish current personal source views
from captured but unread bodies. The six initial escaped display artifacts and
malformed receipt suffixes are preserved and are not counted as personal read
credit. Their registered windows were later redisplayed with valid receipts.

Run VERIFY-EVIDENCE.py in this directory for read-only identity checks; passing
--repo with a Git object database adds commit-to-tree and original-record
checks. Retained display helpers are historic artifacts, not verifiers; they
write files and should not be run against a frozen packet. The review does not
execute product code, validate behavior, close a lens or assign an alias.
