# q2336–q2337: investigation identity and participant timing

A saturated capability version can preserve the same attempt identity after a
seed or state change. A matching earlier receipt is returned as a retry before
later checks. Actual exhaustion and the intended retry policy remain open.

If independently offset participant clocks persist through a partial interval,
the maximum participant clock minus the leader start includes a pre-existing
offset in the interrupted receipt duration. This is a conditional mathematical
source observation; supported reachability and intended duration semantics are
not established.

The report contains exact source references, protections, related historic
records and unresolved clock-boundary/transaction questions. Personal source
ranges and excluded first displays are recorded separately. No product execution
or validation occurred.
