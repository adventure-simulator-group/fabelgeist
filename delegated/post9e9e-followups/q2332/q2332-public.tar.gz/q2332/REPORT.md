# q2332: native SATS and reflection owners (bounded source review)

The selected SATS source shows a conditional direct-construction path that does
not call an aggregate owner constructor in the displayed product templates.
The selected land-use importer reconstructs and validates its aggregate before
update or insertion. This does not establish a supported invalid wire input or
close the wider decoder question. The current opaque `SignedLength` route did
not itself demonstrate a reflected inner-value admission bypass.

The independent report, exact references, historical attribution, source
proofs, current and historical qualifications, 13 bounded perspectives, guards,
open questions and no-closure statement are in `REPORT.json`. Actual personal
source displays and unread complements are in `READ-LIMITS.json` plus the later
`READ-LIMITS-ADDENDUM.json`; registration and display receipts remain separate.
See `FAILED-DISPLAY-RECEIPT.json` for the two failed argument-order attempts.

The exact historical records are held in the restricted original packet. A
public packet must distinguish any path-redacted reconstructed records from
those original whole-file identities, without reporting path values or their
individual digests. The optional feature declarations are not a resolved Cargo
feature graph. The f82 commit is a transport for a dirty P16 source object, not
a clean P16 tree identity. No product execution or validation occurred.
