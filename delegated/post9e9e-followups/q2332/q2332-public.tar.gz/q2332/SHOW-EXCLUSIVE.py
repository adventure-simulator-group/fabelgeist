import datetime,hashlib,json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent;name=sys.argv[1];lo=int(sys.argv[2]);hi=int(sys.argv[3]);lines=(p/name).read_text().splitlines();v="".join(f"{i:6}\t{lines[i-1]}\n" for i in range(lo,hi+1));f=p/f"DISPLAY-{pathlib.Path(name).stem}-{lo}-{hi}.txt"
with f.open("x") as out:out.write(v)
r={"registration":sys.argv[4],"source":name,"range":[lo,hi],"display":f.name,"view_sha256":hashlib.sha256(v.encode()).hexdigest(),"displayed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"truncated":False}
with (p/(f.name+".receipt.json")).open("x") as out:out.write(json.dumps(r,indent=2)+"\n")
print(v,end="")
