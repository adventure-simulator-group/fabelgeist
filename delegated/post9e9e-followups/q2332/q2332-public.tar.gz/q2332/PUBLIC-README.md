# Public reconstruction of q2332 evidence

The archive contains exact pinned-source, native package, Git tree and selected
queue evidence together with a path-redacted reconstruction of some historical
records. The reconstruction map records whole-file original/public identities
and replacement counts. The historical capture metadata identifies exact
originals; it must not be interpreted as saying reconstructed public bodies are
byte-identical. Exact originals and a separate replay receipt remain in an
owner-restricted same-machine capture. No individual path or path-value digest is
published.

Run VERIFY-PUBLIC.py next to PUBLIC-MANIFEST.json and the archive for
read-only public identity checks. An independently supplied --repo adds
commit-to-root checks. Public verification does not replay private redactions,
resolve Cargo features, execute macros or validate product behavior. The helper
scripts retained inside the archive are historical evidence only; some write
output and should not be run on a frozen packet. The current proof anchors are
Git tree objects; no raw commit author metadata is included.

The initial private scan counted 39 home-path occurrences in 19 direct-record
files. After capturing nine additional explicitly referenced historical records,
a second private scan counted 42 occurrences across 22 files. All 42 are
reconstructed in the public archive. The limited scanners and their exclusions
are documented by the external scan receipt.
