import gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>')
repo='<LOCAL_PATH_1>'
current='95e63628f9d70b8dd6e6fede64334696c6995009'
old='6533e444fa37552927070cc8d8190907fd3b413e'
def digest(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def fromgit(rev,path):return subprocess.run(['git','-C',repo,'show',rev+':'+path],check=True,stdout=subprocess.PIPE).stdout
reg=json.loads((p/'registration.json').read_text())
for x in reg['ordered_roles']:
 b=(p/'source'/pathlib.Path(x['path']).name).read_bytes()
 assert (digest(b),blob(b),len(b),b.count(b'\n'))==(x['sha256'],x['git_blob'],x['bytes'],x['lines'][1]),x['path']
 assert b==fromgit(current,x['path'])==fromgit(old,x['path']),x['path']
count=0
for name in ['support-registration-01.json','support-registration-02.json']:
 data=json.loads((p/name).read_text())
 for x in data['registered_sources']:
  b=(p/'source'/('support-'+x['path'].replace('/','__'))).read_bytes()
  assert (digest(b),blob(b),len(b),b.count(b'\n'))==(x['sha256'],x['blob'],x['bytes'],x['range'][1]),x['path']
  assert b==fromgit(current,x['path']),x['path'];count+=1
base=json.loads((p/'support-registration-base.json').read_text());x=base['registered_sources'][0]
b=(p/'source'/('base-'+x['path'].replace('/','__'))).read_bytes()
assert (digest(b),blob(b),len(b),b.count(b'\n'))==(x['sha256'],x['blob'],x['bytes'],x['range'][1])
assert b==fromgit(base['revision'],x['path'])
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:transport={x['path']:x for x in json.load(f)['entries']}
history=json.loads((p/'historical-manifest.json').read_text())
for x in history['records']:
 b=(p/x['copy_path']).read_bytes(); e=transport[x['original_transport_path']]
 assert (len(b),digest(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob']),x['copy_path']
refs=json.loads((p/'reference/manifest.json').read_text())
for x in refs['records']:
 b=(p/x['copy']).read_bytes(); assert (len(b),digest(b))==(x['bytes'],x['sha256'])
r=json.loads((p/'report.json').read_text())
assert r['registration']['sha256']==digest((p/r['registration']['path']).read_bytes())
assert r['historical_manifest']['sha256']==digest((p/r['historical_manifest']['path']).read_bytes())
assert r['reference_archives']['sha256']==digest((p/r['reference_archives']['manifest']).read_bytes())
assert r['base_support']['sha256']==digest((p/r['base_support']['registration']).read_bytes())
for x in r['support']:assert x['sha256']==digest((p/x['registration']).read_bytes())
for x in r['prior_current_copies']:assert x['sha256']==digest((p/x['path']).read_bytes())
a=r['previous_personal_support'];assert a['sha256']==digest((p/a['path']).read_bytes());assert a['supporting_report_sha256']==digest((p/a['supporting_report']).read_bytes())
print('Evidence integrity passed:',len(reg['ordered_roles']),'current and historic identical source objects,',count,'registered current support objects, base manifest,',len(history['records']),'transport-manifest-verified historical receipts, 2 archived reference files, 3 prior current assessments, all registration hashes.')
print('Only Git object reads, hash comparisons and evidence JSON/gzip parsing were performed; no product build, test, fixture, algorithm or runtime probe ran.')
