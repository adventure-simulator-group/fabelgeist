import gzip, hashlib, json, pathlib
src=pathlib.Path('<LOCAL_PATH_0>')
pub=pathlib.Path('<LOCAL_PATH_1>')
out=pathlib.Path('<LOCAL_PATH_2>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f: transport=json.load(f)
entries={e['path']:e for e in transport['entries']}
paths=['adler/READ-L11-369.json','adler/STATE-L11-369.json','adler/VERIFY-L11-369.json','adler/REGISTRATION-ADLER-1169.json','adler/REGISTRATION-ADLER-1170.json','adler/REGISTRATION-ADLER-1171.json','segovb/READ-L12-761.json','segovb/REGISTRATION-SEGOVB-L12-761.json','segovb/VERIFY-L12-761.json','parallel-l12-20261029/PROPOSAL-L12-761.json','parallel-l12-20261029/REGISTRATION-PAR-L12-270.json','parallel-l12-20261029/REGISTRATION-PAR-L12-271.json','parallel-l12-20261029/REGISTRATION-PAR-L12-272.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-761-764.json']
rows=[]
for p in paths:
 b=(src/p).read_bytes();e=entries[p];h=hashlib.sha256(b).hexdigest(); blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),p
 dest=out/'historical'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists(): assert dest.read_bytes()==b,p
 else: dest.write_bytes(b)
 rows.append({'original_transport_path':p,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+p})
report={'schema':'delegated-recovered-historical-evidence-v1','qualification':'Exact copies from the read-only original extraction, each checked against original transport manifest SHA-256, byte length and Git blob. Preserve each recorded source revision and reviewer. Not checkpoint3821 and no current personal-read credit. Original bytes may contain nonessential local paths; apply documented redaction before public publication.','records':rows}
(out/'historical-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print('verified records',len(rows))
print('manifest sha256',hashlib.sha256((out/'historical-manifest.json').read_bytes()).hexdigest())
