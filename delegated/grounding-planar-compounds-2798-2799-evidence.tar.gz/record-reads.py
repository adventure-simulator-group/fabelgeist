from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;reg=(b/'registration.json').read_bytes();r=json.loads(reg);entries=[]
for x in r['entries']:
 n=x['eof'];chunks=[[1,83]] if n==83 else [[1,150],[151,294]]
 entries.append({'id':x['id'],'sha256':x['sha256'],'actual_display_chunks':chunks,'unread_complement':[],'historic_original_material_only':x['original_registry_material_ranges'],'qualification':'Personally displayed at this registered Git identity after registration; original material versus newly inspected complement remain separate. Source text only.'})
out={'schema':'726-bounded-personal-read-receipt-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(reg).hexdigest(),'entries':entries};(b/'read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('read receipts',len(entries))
