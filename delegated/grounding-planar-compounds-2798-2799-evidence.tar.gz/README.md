# Grounding planar and scene compounds roles 2798–2799

`REPORT.json` contains this bounded source-only audit, thirteen lens
perspectives, the two previously recorded coverage/physical-cell relationships,
a conditional rear-member admission question and open policies. No product or
fixture was constructed, run, built, tested, rendered or probed; no repairs or
publication edits were made.

The archived role files match both historical project revision
`6533e444fa37552927070cc8d8190907fd3b413e` and pinned current project revision
`95e63628f9d70b8dd6e6fede64334696c6995009`, with separately registered personal
displays. The original pr-working snapshot records four unrelated modifications;
individual file equality does not make it clean. Revision
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports historical objects and
reviewer records, not the project source snapshot.

`registration.json` and `read-receipt.json` record both exact historical and
current full-body displays. Their original historic material scopes remain
separate from newly read complements. `support-registration*.json` and
`support-read-receipt.json` record independent current support and unread lines;
they confer no original-role or prior reviewer credit. The two registered
GroundTriangle source partitions are distinct receipts, even though their union
covers the full body. Any test module declaration is source text only.

`history/` retains the exact recovered original registry and extraction
manifest, relevant original 059 reviewer receipts, losslessly compressed 059
queue and ledger summaries, 774 reviewer records and earlier current assessment
reports. Prior delegated reports and manifests are hash-linked, with their full
packets remaining at their documented locations. Reconstructed JSON files are
mechanical selections of originals and do not replace them. Selected 774
registration rows equal the registry embedded rows, but whole-file registration
hashes differ and the cause and exact original variants remain unresolved. No
record is promoted to unavailable checkpoint 3821.

`git-proofs.json` and `git-objects/` retain exact Git tree/commit evidence for
assigned source bodies, separate bounded support, applicable rules and the 774
transport records. Run `python3 verify-evidence.py` and
`python3 verify-manifest.py` for evidence integrity only. Verification cannot
establish a reachable product incident, resolved policy or runtime behavior.
