from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();p='crates/adventuresim-tactical-core/src/city_layout/grounding/'
specs=[('members',p+'members.rs',[[1,52]]),('projection',p+'enclosure/projection.rs',[[1,140]])];entries=[]
for id,path,ranges in specs:
 raw=g('show',rev+':'+path);n=len(raw.splitlines());assert max(z for a,z in ranges)<=n;dest=f'support/{id}.rs';(b/dest).write_bytes(raw);entries.append({'id':id,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'prospective_personal_read_ranges':ranges,'qualification':'Separately registered current support only. Unread remainder no credit; no execution.'})
r={'schema':'726-bounded-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':entries};(b/'support-registration-3.json').write_text(json.dumps(r,indent=2)+'\n');print('registered',len(entries))
