from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;names=['support-registration.json','support-registration-2.json','support-registration-3.json'];spec={'binding':([[1,105],[106,209]],[]),'enclosure':([[1,90],[91,180],[181,263]],[]),'foundation':([[300,390]],[[1,299]]),'ground-triangle':([[1,80],[81,160]],[[161,242]]),'ground-source':([[1,90],[91,181]],[]),'ground-triangle-tail':([[161,242]],[[1,160]]),'access':([[1,69],[70,138]],[]),'routes':([[1,65]],[]),'clearance':([[1,73],[74,146]],[]),'members':([[1,52]],[]),'projection':([[1,70],[71,140]],[[141,272]])};entries=[];registrations=[]
for n in names:
 raw=(b/n).read_bytes();reg=json.loads(raw);registrations.append({'path':n,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for x in reg['entries']:
  c,u=spec[x['id']];entries.append({'registration':n,'id':x['id'],'sha256':x['sha256'],'actual_display_chunks':c,'unread_complement':u,'qualification':'Personally displayed only these prospectively registered support chunks; not original ordered-role credit. Tests and doctests were source text only, not run.'})
out={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':registrations,'entries':entries};(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('recorded support',len(entries))
