from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>'
g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
cur='95e63628f9d70b8dd6e6fede64334696c6995009';old='6533e444fa37552927070cc8d8190907fd3b413e';t='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
specs=[(2798,'crates/adventuresim-tactical-core/src/city_layout/grounding/planar.rs','443ff701ad79a52b06623fc199de7ea1df011b7527ed2ef8056057b9b8fac059',[[3,66]]),(2799,'crates/adventuresim-tactical-core/src/scene_input/compounds.rs','1749661a3b0a1baf513595ff7076a7670510285e556b3e2cf7acbc5888f89583',[[7,100],[218,252]])]
entries=[]
for role,path,expected,orig in specs:
 tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+expected
 historical=g('show',old+':'+path);assert sha(historical)==expected and historical==g('show',t+':'+tp)
 for label,rev in [('historical',old),('current',cur)]:
  raw=g('show',rev+':'+path);n=len(raw.splitlines());dest=f'sources/{role}-{label}.rs';(b/dest).write_bytes(raw)
  entries.append({'id':f'{role}-{label}','role':role,'revision':rev,'git_path':path,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'archive':dest,'original_registry_material_ranges':orig,'prospective_personal_read_ranges':[[1,n]],'transport_revision':t if label=='historical' else None,'transport_path':tp if label=='historical' else None,'qualification':'Personal full-source display planned separately; only exact original historical material ranges preserve original role scopes. Remaining lines are newly registered support, not original reviewer credit. Individual historical object matches 6533 and f82; overall pr-working snapshot contains unrelated changes.' if label=='historical' else 'Independent pinned 95e personal display; no automatic historical, prior reviewer or test execution credit.'})
r={'schema':'726-prospective-roles-2798-2799-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':entries,'restriction':'Source text only; no product, fixture, test, build, codegen, render or runtime execution, repairs or publication edits.'};(b/'registration.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
