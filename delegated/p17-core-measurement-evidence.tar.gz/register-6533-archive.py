from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='6533e444fa37552927070cc8d8190907fd3b413e';reg=json.load(open(b/'registry-selection-reconstructed.json'));rs={x['original_index']:x for x in reg['rows']};entries=[];pending=[]
for i in [1752,1764,1768]:
 p=rs[i]['path'];raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'original_pr_working_role':i,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'registry_sha256':rs[i]['sha256'],'equal_to_pr_working_registry':sha==rs[i]['sha256'],'planned_personal_body_ranges':[],'qualification':'Raw Git object archived for identity comparison only; no personal body display or role credit. Whole pr-working tree may be dirty.'});pending.append((p,raw))
r={'schema':'726-p17-core-6533-archive-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'entries':entries};(b/'archive-6533-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'archive'/'6533'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('archive sha',hashlib.sha256((b/'archive-6533-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
