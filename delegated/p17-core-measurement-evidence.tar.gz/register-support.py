from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-tactical-core/src/animation/mod.rs','crates/adventuresim-tactical-core/src/animation/landing.rs','crates/adventuresim-tactical-core/src/animation/sample_values.rs','crates/adventuresim-tactical-core/src/animation/locomotion.rs','crates/adventuresim-tactical-core/src/combat_config/landing.rs','crates/adventuresim-tactical-client/src/animation/procedural/height.rs','crates/adventuresim-core/src/elapsed.rs','crates/adventuresim-core/src/unit_interval.rs','crates/adventuresim-core/src/linear_speed.rs'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_maximum_range':[1,len(raw.splitlines())],'scope':'bounded supporting quantity, configuration or caller only; no original-role credit'});pending.append((p,raw))
r={'schema':'726-p17-core-measurement-prospective-support-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','entries':entries};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'support'/'95e6'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support registration sha',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
