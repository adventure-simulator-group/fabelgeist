from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';p='crates/adventuresim-tactical-core/src/animation/';cl='crates/adventuresim-tactical-client/src/animation/';core='crates/adventuresim-core/src/'
scopes={p+'mod.rs':([[1,17],[45,56]],[16,17,28,31,48,55]),p+'landing.rs':([[1,61]],[]),p+'sample_values.rs':([[1,105]],[176,194,195]),p+'locomotion.rs':([[35,62],[230,247]],[46,50,55,162,234,238,243,258]),'crates/adventuresim-tactical-core/src/combat_config/landing.rs':([[1,33]],[]),cl+'procedural/height.rs':([[1,28],[44,58],[125,199]],[44,139,160,169,178,189,193]),core+'elapsed.rs':([[1,45]],[54,55,56,59,71,72,75,78,84,85,88,93,94,103,122,123,124,125,126,127]),core+'unit_interval.rs':([[1,42],[69,72],[84,90]],[43,47,48,49,62,64,66,67]),core+'linear_speed.rs':([[1,68]],[98,111,128,149,150,160,239,245,251]),'crates/AGENTS.md':([[21,86],[141,153],[182,192]],[]),'crates/adventuresim-tactical-core/AGENTS.md':([[1,17]],[]),cl+'AGENTS.md':([[1,19],[76,88]],[])}
entries=[]
for name in ['support-registration.json','rules-registration.json']:
 for e in json.loads((b/name).read_bytes())['entries']:
  displayed,snips=scopes[e['path']];n=e['actual_line_count'];covered={j for lo,hi in displayed for j in range(lo,hi+1)};missing=[];start=None
  for i in range(1,n+2):
   if i<=n and i not in covered:
    if start is None:start=i
   elif start is not None:missing.append([start,i-1]);start=None
  entries.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'actual_eof':n,'contiguously_displayed_body_ranges':displayed,'search_result_lines_outside_body_ranges':sorted(set(snips)-covered),'not_contiguously_displayed_ranges':missing,'scope':'Bounded support/rule only. Search snippets do not expand full body coverage; unread ranges may include listed snippets.'})
assigned=[]
for f in ['old-registration.json','current-registration.json']:
 for e in json.loads((b/f).read_bytes())['entries']:
  assigned.append({'revision':e['revision'],'role':e['original_role'],'path':e['path'],'ranges':[[1,e['actual_line_count']]],'registration':f})
r={'schema':'726-p17-core-measurement-personal-read-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','assigned_personal_reads':assigned,'support_personal_reads':entries,'prior_support_qualifications':'Earlier supported-slip packet retained separately and credited its own partial ranges only. Archive 6533 bytes were never displayed as body during this assignment.','historic_reviewer_qualifications':'Original 059 and 774 reviewers retain revision and scope as recorded; no cross-lens or current reader transfer.','execution':'Source display/search, mathematical reasoning and evidence verification only. No product, viewer, build, test, runtime probe, simulation or repair.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'personal-read-receipt.json').write_bytes(raw);print('receipt SHA',hashlib.sha256(raw).hexdigest(),'assigned',len(assigned),'support',len(entries))
