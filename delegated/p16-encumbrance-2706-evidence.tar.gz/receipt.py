from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
r=load('registration.json');assigned=[]
for x in r['rows']:
 for v in x['versions']:
  rs=[[1,160],[161,320],[321,484]];assigned.append({'original_index':2706,'source_id':x['source_id'],'identity':v.get('identity','pinned current'),'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'displayed':rs,'unread_complement':complement(v['eof'],rs),'qualification':'Archive and 95e copies independently prospectively registered and displayed; original role356–484, additional1–355 is fresh context without retroactive historical credit.'})
windows={'crates/strategic-web/src/routes/data.rs':[[1,308]],'crates/strategic-web/src/routes/quests.rs':[[1,30],[565,610],[1140,1475],[1850,1894],[2024,2040],[2050,2061],[2068,2080]],'crates/strategic-web/src/routes/settlements/mod.rs':[[1,164]],'crates/adventuresim-stdb-module/src/strategic/party_readiness.rs':[[1,198]],'crates/strategic-web/src/routes/scene_equipment.rs':[[1,306]],'crates/strategic-web/src/routes/settlements/rest.rs':[[375,385]],'crates/strategic-web/src/routes/settlements/rendering.rs':[[40,120],[340,355]],'crates/strategic-web/src/templates/settlement/trade/inventory.rs':[[1,55],[145,155],[355,385]],'crates/adventuresim-core/src/equipment.rs':[[450,520],[650,675],[835,880]],'crates/strategic-web/src/routes/settlements/service_quests.rs':[[30,50]],'crates/strategic-web/src/routes/mod.rs':[[180,195]]};regs=[];supports=[]
for n in ['registration.json','support-registration.json','living-registration.json','historical-comparisons-registration.json']:
 d=load(n);regs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':d['created_utc']})
 if n in ['support-registration.json','living-registration.json']:
  for e in d['entries']:
   rs=windows[e['path']];supports.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'local':e['local'],'eof':e['eof'],'displayed':rs,'unread_complement':complement(e['eof'],rs),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','basis':'Full original P16 archive and 95e source each personally displayed after prospective registration in bounded chunks, including test text without execution. Support source windows after respective registration.','assigned':assigned,'support':supports,'registrations':regs,'comparison_copies':'a120, 6533, 039 and e275 comparison bodies archived and Git-proved but not separately displayed in this pass; no historical read, snapshot cleanliness or role credit inferred.','prior_same_agent':'Earlier <LOCAL_PATH_0> role2375 records one full1–484 display of byte-identical copies but not which 6533/95e copy; central ASSESSMENT-DELEGATED-SOURCE-ROLES-6 expressly preserves revision unspecified. Prior web-residence support265–278 remains separately credited.','navigation':'Before support registrations only Git file names were listed. Later rg context is within reported displayed ranges. Earlier reviewers retain exact personal ranges and no checkpoint3821 credit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
