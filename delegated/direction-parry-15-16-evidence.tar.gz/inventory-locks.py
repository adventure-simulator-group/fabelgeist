from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tomllib
b=Path(__file__).parent;reg=json.load(open(b/'direction-lock-registration.json'));out=[];want={'bevy_math':'0.19.1','parry3d':'0.27.0','glam':'0.32.1'}
for e in reg['entries']:
 d=(b/e['archive']).read_bytes();assert hashlib.sha256(d).hexdigest()==e['sha256'];pkgs=tomllib.loads(d.decode())['package'];m=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum'),'dependencies':p.get('dependencies',[])} for p in pkgs if want.get(p['name'])==p['version']];out.append({'id':e['id'],'sha256':e['sha256'],'package_count':len(pkgs),'matches':m,'qualification':'Version-qualified structural lock entries; not feature resolution or runtime proof.'})
(b/'direction-lock-inventory.json').write_text(json.dumps({'schema':'726-direction-parry-lock-inventory-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256((b/'direction-lock-registration.json').read_bytes()).hexdigest(),'entries':out},indent=2)+'\n')
