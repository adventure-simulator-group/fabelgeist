from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile
b=Path(__file__).parent;members=[('glam-division','glam-0.32.1/src/f32/vec3.rs',[[1410,1458]]),('glam-assert','glam-0.32.1/src/macros.rs',[[1,35]])];out=[]
with tarfile.open(b/'packages/glam-0.32.1.crate') as tar:
 for ident,m,ranges in members:
  d=tar.extractfile(m).read();eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges];assert all(a<=z for a,z in ranges);f='support/'+ident+'.rs';(b/f).write_bytes(d);out.append({'id':ident,'repo_kind':'crate-archive','package_archive':'packages/glam-0.32.1.crate','member_path':m,'archive':f,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'eof':eof,'prospective_read_ranges':ranges,'qualification':'Additional registered native support; no feature graph or original role credit.'})
(b/'support-registration-3.json').write_text(json.dumps({'schema':'726-direction-parry-support3-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':out},indent=2)+'\n');print(json.dumps(out,indent=2))
