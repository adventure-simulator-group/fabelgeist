from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,hashlib
b=Path(__file__).parent;pub='<LOCAL_PATH_0>';rev='e2755a732c84e67296b5e3441a4259a84f461b2f';reg=json.load(open(b/'support-registration.json'));out=[]
for e in reg['entries']:
 if e.get('repo_kind')!='project':continue
 d=subprocess.check_output(['git','-C',pub,'show',rev+':'+e['git_path']]);h=hashlib.sha256(d).hexdigest();assert h==e['sha256'];out.append({'id':e['id'],'revision':rev,'git_path':e['git_path'],'archive':e['archive'],'sha256':h,'bytes':len(d),'qualification':'Exact e275 committed object byte-identical to independently displayed bounded 95e source. No personal historical body read or additional scope credit.'})
(b/'historical-project-comparison.json').write_text(json.dumps({'schema':'726-e275-byte-comparison-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':out},indent=2)+'\n')
