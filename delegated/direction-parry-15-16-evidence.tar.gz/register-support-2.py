from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
b=Path(__file__).parent;pub='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';out=[]
for ident,p,ranges in [('workspace-manifest','Cargo.toml',[[100,122]]),('core-manifest','crates/adventuresim-tactical-core/Cargo.toml',[[1,44]])]:
 d=subprocess.check_output(['git','-C',pub,'show',rev+':'+p]);eof=len(d.splitlines());assert all(a<=z<=eof for a,z in ranges);f='support/'+ident+'.toml';(b/f).write_bytes(d);out.append({'id':ident,'repo_kind':'project','revision':rev,'git_path':p,'archive':f,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'eof':eof,'prospective_read_ranges':ranges,'qualification':'Current project manifest declaration support only, not enabled feature resolution.'})
(b/'support-registration-2.json').write_text(json.dumps({'schema':'726-direction-parry-support2-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':out},indent=2)+'\n')
