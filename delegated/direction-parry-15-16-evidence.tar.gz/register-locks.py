from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).parent;regs=['lock-registration.json','historical-lock-registration.json'];es=[]
for n in regs:
 r=json.load(open(b/n))
 for e in r['entries']:
  d=(b/e['archive']).read_bytes();assert hashlib.sha256(d).hexdigest()==e['sha256'];es.append({'id':e['id'],'revision':e['revision'],'git_path':e['git_path'],'archive':e['archive'],'sha256':e['sha256'],'bytes':len(d),'qualification':'Reused exact prior registered lock bytes; prospective structural package inventory only; no full body display or feature resolution.'})
out={'schema':'726-direction-parry-lock-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'prior_registration_sha256':{n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in regs},'entries':es};(b/'direction-lock-registration.json').write_text(json.dumps(out,indent=2)+'\n')
