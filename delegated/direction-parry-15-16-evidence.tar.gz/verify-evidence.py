from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tomllib,tarfile
b=Path(__file__).parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');report=load('REPORT.json')
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:assert sha(gzip.decompress(d))==x['uncompressed_sha256']
registry=json.loads(gun('history/original-registry.json.gz'));assert sha(gun('history/original-registry.json.gz'))=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';assert sha(gun('history/original-transport-manifest.json.gz'))=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858'
roles=[15,16];sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==roles+[44,318,319,323]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
checks={'bevy_math':('0.19.1','98ead494dcfaa9b4594eed7f09a27d868b7cc7fc9ebd655c5643322778f4a8a2'),'parry3d':('0.27.0','99613136af5c3ae1e26907eb8ef90183636f54d02341c0a1121caa813a242cb5'),'glam':('0.32.1','f70749695b063ecbf6b62949ccccde2e733ec3ecbbd71d467dca4e5c6c97cca0')}
for n,(v,h) in checks.items():assert sha((b/f'packages/{n}-{v}.crate').read_bytes())==h
names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json'];groups={n:load(n) for n in names};regs={(n,str(e['id'])):e for n,r in groups.items() for e in r['entries']}
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
 if name=='registration.json' or x.get('repo_kind')=='crate-archive':
  with tarfile.open(b/x['package_archive']) as tar:assert tar.extractfile(x['member_path']).read()==d
for i in roles:
 x=regs[('registration.json',str(i))];r=registry['files'][i];assert x['original_source_id']==r['source_id'] and x['sha256']==r['sha256'] and (x['version'],x['package_checksum'])==checks[x['package']] and not r.get('owner_contract_proofs') and x['historical_producer_scopes']==r['expanded_producer_contract_observations'] and x['historical_admission_scopes']==r.get('admission03_increment046_role_observations',[])
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];s=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in s['entries']]==[5,2346,2347,2348]
for x in s['entries']:assert x['entry']==q[x['original_index_zero_based']]
r=load('history/059/segovb/READ-L11-473.json');row=next(x for x in r['rows'] if x['overlay_index']==79);assert r['new_original_role_credit']==0 and row['fresh_personal_body_reads']==[] and row['reused_ranges']==[[1,205],[550,660]]
r=load('history/059/segovb/READ-REVISIT-L12-633-015.json');assert r['original_index']==15 and r['fresh_personal_body_reads']==[[1,81],[550,611]] and sha((b/'history/059/segovb/REGISTRATION-REVISIT-L12-633-015.json').read_bytes())==r['registration_sha256']
r=load('history/059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-079.json');x=next(e for e in r['rows'] if 'glam@0.32.1:src/f32/vec3.rs' in e.get('source_id',''));assert [1419,1430] in x['fresh_personal_body_ranges'] and 'Root personal' in x['attribution']
for i in [2346,2347,2348]:
 for x in q[i]['exact_source_identities_and_assessed_ranges']:
  if not isinstance(x,dict):continue
  for k in ['body_receipt','registration_ref_and_sha256']:
   z=x.get(k,{});p=z.get('path','').replace('target/726-audit-adler-20261027/','')
   if p and z.get('sha256'):assert sha((b/'history/059'/p).read_bytes())==z['sha256']
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
variants=[]
for n in ['redacted','original-paths']:
 xs=[json.loads(z) for z in gun(f'history/774/camera-producer-{n}.jsonl.gz').splitlines()];variants.append(next(x for x in xs if x.get('trace_id')=='CAM-PPS-CAMERA-BOUNDARIES-048'))
assert sha(gun('history/774/camera-producer-redacted.jsonl.gz'))!=sha(gun('history/774/camera-producer-original-paths.jsonl.gz'))
for x in hist['selected_camera_variant_comparisons']:
 r=registry['files'][x['role']];j=x['proof_index_zero_based'];u,v=[z['additional_actual_source_proofs'][j] for z in variants];assert u['sha256']==v['sha256']==r['sha256'] and u['read_ranges']==v['read_ranges']==r['expanded_producer_contract_observations'][0]['read_ranges_as_recorded']==x['original_read_ranges'];assert sorted(k for k in set(u)|set(v) if u.get(k)!=v.get(k))==x['different_top_level_keys']==['path'] and u['path']==x['redacted_path'] and v['path']==x['original_path']
assert sorted(k for k in set(variants[0])|set(variants[1]) if variants[0].get(k)!=variants[1].get(k))==['additional_actual_source_proofs','current_sources']
adm=[json.loads(z) for z in gun('history/774/native-admission-coverage.jsonl.gz').splitlines()]
for role,no,ranges in [(15,11,[[1,205],[550,660]]),(16,12,[[60,87]])]:
 x=next(x for x in adm if x.get('id')==f'NATIVE-ADMISSION03-SOURCE-{no:03d}');assert x['source_id']==registry['files'][role]['source_id'] and x['sha256']==registry['files'][role]['sha256'] and x['read_ranges']==ranges
g=json.loads(gun('history/774/native-aggregate-075.json.gz'));m=next(x for x in g['source_members'] if x['source_id']==registry['files'][15]['source_id']);assert m['scoped_ranges_compared']==[[1,201],[559,616]] and m['context_only_ranges']==[[203,205],[550,558],[618,660]]
c=[json.loads(z) for z in gun('history/774/camera-redundant-contracts.jsonl.gz').splitlines()];x=next(x for x in c if x.get('id')=='CAMERA-INITIAL07-CONTRACT-007')
for role,ranges in [(15,[[1,205],[550,660]]),(16,[[60,87]])]:
 m=next(m for m in x['members'] if m.get('scope016_index')==role);assert m['source_id']==registry['files'][role]['source_id'] and m['material_ranges']==ranges
prior=hist['prior_lock_packet_report_manifest'];manifest=json.loads((b/prior['MANIFEST.json']['preserved']).read_bytes());assert next(x for x in manifest['files'] if x['path']=='REPORT.json')['sha256']==prior['REPORT.json']['sha256']
for n in ['REPORT.json','MANIFEST.json']:
 x=prior[n];d=(b/x['preserved']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes']
for x in hist['copied_prior_lock_evidence']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
lreg=load('direction-lock-registration.json');inv=load('direction-lock-inventory.json');assert inv['registration_sha256']==sha((b/'direction-lock-registration.json').read_bytes()) and datetime.fromisoformat(lreg['at_utc'])<datetime.fromisoformat(inv['at_utc']) and len(lreg['entries'])==len(inv['entries'])==9
for n,h in lreg['prior_registration_sha256'].items():assert sha((b/n).read_bytes())==h
for x,y in zip(lreg['entries'],inv['entries']):
 raw=(b/x['archive']).read_bytes();assert x['id']==y['id'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']==y['sha256'];packages=tomllib.loads(raw.decode())['package'];matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum'),'dependencies':p.get('dependencies',[])} for p in packages if p['name'] in checks and p['version']==checks[p['name']][0]];assert len(packages)==y['package_count'] and matches==y['matches'];expected=3 if x['git_path']=='Cargo.lock' else 2 if x['git_path']=='crates/adventuresim-character-creator/Cargo.lock' else 0;assert len(matches)==expected
 for p in matches:
  assert p['checksum']==checks[p['name']][1] and p['source']=='registry+https://github.com/rust-lang/crates.io-index'
  if p['name']=='bevy_math':assert 'glam 0.32.1' in p['dependencies'] or ('glam' in p['dependencies'] and [z['version'] for z in packages if z['name']=='glam']==['0.32.1'])
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
assert len(proof['paths'])==29 and not proof['absent_paths']
for e in load('historical-project-comparison.json')['entries']:
 assert e['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and any(x['revision']==e['revision'] and x['path']==e['git_path'] and x['sha256']==e['sha256'] for x in proof['paths']) and any(x['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and x['path']==e['git_path'] and x['sha256']==e['sha256'] for x in proof['paths'])
coverage={}
for receipt in ['read-receipt.json','support-read-receipt.json','support-read-receipt-2.json','support-read-receipt-3.json']:
 r=load(receipt);name=r['registration'];assert r['registration_sha256']==sha((b/name).read_bytes()) and datetime.fromisoformat(groups[name]['at_utc'])<datetime.fromisoformat(r['recorded_at_utc'])
 for e in r['entries']:
  id=str(e['id']);x=regs[(name,id)];assert e['sha256']==x['sha256'];actual={i for a,z in e['actual_display_chunks'] for i in range(a,z+1)};planned={i for a,z in x.get('prospective_personal_read_ranges',x.get('prospective_read_ranges',[])) for i in range(a,z+1)};remaining={i for a,z in e['unread_existing_lines'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage[id]=actual
assert len(regs)==len(coverage)==11
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(str(e['id'])==str(x['id']) and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[str(x['id'])] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','native_roles':roles,'personal_registered_scopes':len(regs),'774_records_git_proved':len(hist['records_774']),'camera_variants':'selected proof rows differ path; full trace differs additional_current_source proofs and current_sources','059_receipts':'exact historical source/read and reused attribution; 079 already covers glam division','git_paths_proved':len(proof['paths']),'lockfiles_structurally_verified':9,'package_archives_verified':3,'bounded_lenses':13,'feature_resolution':'not inferred','build_test_example_physics_product_execution_probe_validation':'not performed'},indent=2))
