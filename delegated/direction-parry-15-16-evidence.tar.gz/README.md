# Bounded native direction and Parry review: roles 15–16

`REPORT.json` contains the source review, historical links, conditions, and open
questions. `registration.json` and `read-receipt.json` record the assigned
source ranges. Separate registrations and receipts record bounded current
camera, manifest, Bevy export and glam support. Full native members are retained
for recovery, but their unread complements are not credited.

`packages/` contains exact checksum-bound bevy_math 0.19.1, parry3d 0.27.0 and
glam 0.32.1 archives. `locks/` preserves root and selected child lockfiles at
6533 and 95e and the earlier e275 root lock. Structural parsing authenticates
individual package selections and the Bevy-to-glam lock edge; it does not resolve
enabled features. Git path proofs bind each project support, three e275 source
comparisons, package-member transport objects, lockfile and 774 record to the
proper transporting commit. f82 is not a native package revision or historical
working-tree head. Matching files at e275 and 95e do not imply whole-tree identity.

`history/059/` preserves exact historical receipts, registrations and proof
records; historical fresh and reused source scopes are distinct. The 774 camera
producer record is kept in both exact variants. Selected native proof rows differ
in their paths; the selected whole trace has other variant differences too.
Original-path variants and some exact receipts include local paths. Redact and
hash public copies separately while retaining exact original local bytes.
The registry and queue selection files are mechanical reconstructions, not
original standalone records or checkpoint 3821.

Verify the packet with evidence-only checks:

```sh
python3 <LOCAL_PATH_0>
python3 <LOCAL_PATH_1>
```

No implementation, builds, tests, examples, physics queries, runtime probes,
fixtures, or product validation were performed. The thirteen lens perspectives
apply only to displayed source windows and do not imply whole-lens completion.
