from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).parent;pub=Path('<LOCAL_PATH_0>');rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';prev=Path('<LOCAL_PATH_1>');locks=Path('<LOCAL_PATH_2>');ex=Path('<LOCAL_PATH_3>');sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d);return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[];pm=json.loads((prev/'MANIFEST.json').read_bytes());pi={x['path']:x for x in pm['files']}
for f in ['history/original-registry.json.gz','history/original-transport-manifest.json.gz','history/baseline-059-queue.json.gz','history/baseline-059-ledger.json.gz']:
 d=(prev/f).read_bytes();assert sha(d)==pi[f]['sha256'];refs.append({'kind':'original recovered 059 registry/transport or compressed historical summary, not checkpoint3821','from_verified_packet':str(prev),'original_packet_path':f,'uncompressed_sha256':sha(gzip.decompress(d)),**save(d,f)})
r=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()));roles=[15,16,44,318,319,323];(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanical selection; 15/16 assigned native roles, others historical related sources only. No current, read-credit or checkpoint3821 transfer.','rows':[{'original_index':i,**r['files'][i]} for i in roles],'snapshots':[x for x in r['snapshots'] if x['id'] in ['pr-working','physical-p16']]},indent=2)+'\n')
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries'];ids=[5,2346,2347,2348];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-059-queue-reconstruction-v1','qualification':'Mechanical historical selection; e275 is earlier separately attributed, no 95e or checkpoint3821 promotion.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in ids]},indent=2)+'\n')
files={'segovb/READ-L11-473.json':'f6f2592edfdc04a087b89acdfadd73508dbd6ccdb7a11ffe87e269cd5687d2de','evidence/audit11/inherited-coverage.jsonl':'4cfe8fd09dd49043595c0aff0f002e1939a80a138fdd6fae60f78d92f8e00a4a','segovb/INHERITED-L11-CONTRACT-003.json':'c3636c37fe7117570fa67d031c47cc81342c96d9fafe8af1ee685b3bd8b9132c','segovb/READ-REVISIT-L12-633-015.json':'479189b91704a3845bd0f3e3c6f77ee32078f043d571f46c7d066bdcf258a493','segovb/REGISTRATION-REVISIT-L12-633-015.json':'211cac1a7e242cb614619eb59e645d206d04ec2d3da066f69d7ea4b24b6da98f'}
for i in [2346,2347,2348]:
 for s in q[i]['exact_source_identities_and_assessed_ranges']:
  if not isinstance(s,dict):continue
  for field in ['body_receipt','registration_ref_and_sha256']:
   z=s.get(field,{});p=z.get('path','').replace('target/726-audit-adler-20261027/','');h=z.get('sha256')
   if p and h:files[p]=h
for p,h in files.items():
 d=(ex/p).read_bytes();assert sha(d)==h;refs.append({'kind':'exact original 059 receipt, registration or historical proof; original attribution unchanged','original_locator':p,**save(d,'history/059/'+p)})
for n in ['ASSESSMENT-CAMERA-CLEARANCE-95E.json','ASSESSMENT-OWNED-GROUND-SUPPORT-95E.json']:
 d=(pub/n).read_bytes();refs.append({'kind':'prior independently attributed 95e assessment; no transferred personal reads','original':n,**save(d,'history/prior/'+n)})
paths=[]
for fam,lab in [('adler-original/audit/records','redacted'),('historical-family-execution','original-paths')]: paths.append((f'handoff/774/{fam}/final-acceptance-20261021/wave-01/producer-supplement-after-owner/camera/traces.jsonl',f'camera-producer-{lab}.jsonl'))
for stem,name in [('rig/expanded-producer-delta-map-049.json','rig-delta-map.json'),('native/admission03/coverage.jsonl','native-admission-coverage.jsonl'),('native/admission03/source-range-registration.jsonl','native-admission-registration.jsonl'),('native/admission03/source-qualifications-final-082.jsonl','native-admission-qualifications.jsonl'),('camera/initial07-redundant-authority/contracts.jsonl','camera-redundant-contracts.jsonl'),('native/initial05-aggregate-states/contract-groups-075.json','native-aggregate-075.json')]:paths.append(('handoff/774/adler-original/audit/continuation/'+stem,name))
old=[]
for p,n in paths:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+p]);old.append({'revision':rev,'transport_path':p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+n+'.gz')})
variants=[]
for name in ['redacted','original-paths']:
 a=[json.loads(z) for z in gzip.decompress((b/f'history/774/camera-producer-{name}.jsonl.gz').read_bytes()).splitlines()];matches=[x for x in a if x.get('trace_id')=='CAM-PPS-CAMERA-BOUNDARIES-048'];assert len(matches)==1;variants.append(matches[0])
compare=[]
for role,index in [(15,7),(16,10)]:
 x,y=[a['additional_actual_source_proofs'][index] for a in variants];e=r['files'][role];assert x['sha256']==y['sha256']==e['sha256'] and x['read_ranges']==y['read_ranges']==e['expanded_producer_contract_observations'][0]['read_ranges_as_recorded'];diff=[k for k in sorted(set(x)|set(y)) if x.get(k)!=y.get(k)];compare.append({'role':role,'trace_id':'CAM-PPS-CAMERA-BOUNDARIES-048','proof_index_zero_based':index,'different_top_level_keys':diff,'redacted_path':x.get('path'),'original_path':y.get('path'),'original_read_ranges':x['read_ranges']})
lm=json.loads((locks/'MANIFEST.json').read_bytes());li={x['path']:x for x in lm['files']};copied=[]
for path in ['lock-registration.json','lock-inventory.json']+[x['archive'] for x in json.loads((locks/'lock-registration.json').read_bytes())['entries']]:
 d=(locks/path).read_bytes();assert sha(d)==li[path]['sha256'];copied.append({'original_packet':str(locks),'original_path':path,**save(d,path)})
prior={'author':'/root/rig_identity','original_directory':str(locks),'qualification':'Prior separate lock inventory; current structural parse is separate, no full body or feature resolution.'}
for n in ['REPORT.json','MANIFEST.json']:prior[n]=save((locks/n).read_bytes(),'history/prior/eidolon-2790-2793/'+n)
for f in ['locks/e2755a7/Cargo.lock','historical-lock-registration.json']:
 d=(prev/f).read_bytes();assert sha(d)==pi[f]['sha256'];refs.append({'kind':'exact earlier e275 lock and prior registration, reused as evidence bytes; new prospective structural parse separately registered','original_packet':str(prev),'original_path':f,**save(d,f)})
out={'schema':'726-direction-parry-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_774':old,'selected_camera_variant_comparisons':compare,'prior_lock_packet_report_manifest':prior,'copied_prior_lock_evidence':copied,'qualification':'Original role15/16 are reached-producer metadata, not fabricated owner_contract_proofs. 774 camera actual source proof ranges are 15–47/550–611 and60–87; later native admission and camera redundancy scopes are separate. Both camera supplier file variants preserved, selected proofs differ path; entire selected trace differs current_sources and additional_actual_source_proofs. 059 overlay473 reuses earlier scope with fresh_personal_body_reads empty; 059 L12 revisit is separate personal read, e275 is historical. No checkpoint3821 promotion.'};(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('references',len(refs),'774',len(old),'camera proofs',json.dumps(compare))
