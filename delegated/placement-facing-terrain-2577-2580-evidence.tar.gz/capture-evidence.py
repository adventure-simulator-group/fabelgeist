from pathlib import Path
import gzip,json,hashlib,shutil,datetime
r=Path(__file__).resolve().parent;prev=Path('<LOCAL_PATH_0>');user=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest()
for d in ['recovered','historical','prior','central']:(r/d).mkdir()
for n in ['MANIFEST.json','registry.json.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:
 shutil.copyfile(prev/'recovered'/n,r/'recovered'/n)
(r/'recovered/p16').mkdir();
for n in ['tracked.patch','RECOVERY.json']:shutil.copyfile(prev/'recovered/p16'/n,r/'recovered/p16'/n)
q=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'));ledger=json.load(gzip.open(r/'recovered/original-059-ledger.json.gz','rt'));inds=[72,127,133,287,1663,2427,2428,2429,2432];rows={str(i):q['entries'][i] for i in inds};findings={e['contract_id']:ledger['discovery_findings_and_dependencies'][e['contract_id']] for e in rows.values() if e['contract_id'] in ledger['discovery_findings_and_dependencies']}
(r/'historical/selections-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed selections of exact recovered 059 queue and ledger bytes; neither independent original records nor checkpoint3821.','queue_rows':rows,'ledger_findings':findings},indent=2,ensure_ascii=False)+'\n')
refs={}
def walk(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str) and len(x['sha256'])==64:refs[x['path']]=x['sha256']
  if isinstance(x.get('verification'),str) and isinstance(x.get('verification_sha256'),str):refs[x['verification']]=x['verification_sha256']
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for y in x:walk(y)
for row in rows.values():walk(row)
for p,d in refs.items():
 b=(user/p).read_bytes();assert h(b)==d,p;out=r/'historical'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
packets=[('prior-roles','<LOCAL_PATH_0>','MANIFEST.json','55519222bf366afc5927ab5fd51d5669e038a1547a8f03892900ac55fdacf969',['REPORT.json','registration.json','guard-registration.json','read-receipt.json','historical/evidence-index.json','prior/mhr-placement/report.json','prior/mhr-placement/read-receipt.json','prior/mhr-placement/BUNDLE-MANIFEST.json','prior/hair-facing-terrain/REPORT.json','prior/hair-facing-terrain/read-receipt.json','prior/hair-facing-terrain/MANIFEST.json','prior/mhr-placement/historical-774/root/admission03-scope-reconciliation-046.json.gz','prior/mhr-placement/historical-774/camera-registration-observed-first7.jsonl']),('prior-terrain','<LOCAL_PATH_3>','BUNDLE-MANIFEST.json','e398e4751aa4221b354d14dfdd95e5c52e646197e53aea7518f05cd6f9d281ed',['report.json','registration.json','personal-read-receipt.json','support-registration.json','support-read-receipt.json','support2-registration.json','support2-read-receipt.json','historical-index.json','history-774/root/admission03/world-route-admission-030.json.gz'])]
pktinfo=[]
for label,old,mname,expected,files in packets:
 p=Path(old);mb=(p/mname).read_bytes();assert h(mb)==expected; mapping={v['path']:v['sha256'] for v in json.loads(mb)['files']};dest=r/'prior'/label;dest.mkdir();(dest/mname).write_bytes(mb)
 for f in files:
  b=(p/f).read_bytes();assert h(b)==mapping[f],(label,f);out=dest/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 pktinfo.append({'label':label,'previous_directory':old,'manifest':mname,'manifest_sha256':expected,'members':files})
central=['RECONCILIATION-059.json','ASSESSMENT-CENTRAL-HOLDER-13F-95E.json','ASSESSMENT-DELEGATED-RECONCILIATION-13D-95E.json','ASSESSMENT-WEAPON-IDENTITY-95E.json','ASSESSMENT-WEAPON-FRAMES-95E.json','ASSESSMENT-WORLD-SCHEMA-ADMISSION-95E.json','ASSESSMENT-GRAPHICS-CONFIG-ADMISSION-95E.json','ASSESSMENT-GEOLOGY-AND-ESTABLISHMENTS-95E.json']
centralmeta=[]
for n in central:
 b=(pub/n).read_bytes();out='central/'+n+'.gz';(r/out).write_bytes(gzip.compress(b,mtime=0));centralmeta.append({'path':n,'local':out,'sha256':h(b),'bytes':len(b)})
o={'schema':'726-central-reconciliation-evidence-index-v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_059_receipts':refs,'prior_frozen_packets':pktinfo,'central_working_snapshot':centralmeta,'qualification':'Exact source receipt copies match 059 queue hash references. Central files are captured working snapshots, potentially staged/uncommitted, not independently asserted to be a published commit. Prior manifest members were checked by hash without invoking prior verifiers; only selected members copied, no attribution or historical checkpoint promotion. 774 Root046 camera pin mismatch is retained unchanged. The full source archive is not duplicated here; registered source bytes have f82 Git paths and original registry bindings; other source objects remain in the prior packet/remote publication.'}
(r/'historical/evidence-index.json').write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n');print('059 exact receipts',len(refs),'prior packets',len(pktinfo),'central snapshot files',len(centralmeta))
