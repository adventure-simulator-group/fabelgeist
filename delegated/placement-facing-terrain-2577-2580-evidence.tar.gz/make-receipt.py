from pathlib import Path
import json,hashlib,datetime
r=Path(__file__).resolve().parent; b=(r/'registration.json').read_bytes();o=json.loads(b);reads=[]
for e in o['entries']:
 for v in e['versions']:
  windows=v['registered_windows'];got=set(n for a,z in windows for n in range(a,z+1));un=[];run=None
  for n in range(1,v['eof']+1):
   if n not in got and run is None:run=n
   if n in got and run is not None:un.append([run,n-1]);run=None
  if run is not None:un.append([run,v['eof']])
  reads.append({'local':v['local'],'project_path':e['project_path'],'original_index':e.get('original_index'),'identity':v['identity'],'revision':v.get('revision'),'sha256':v['sha256'],'displayed_ranges':windows,'unread_complement':un})
receipt={'schema':'726-bounded-reconciliation-personal-displays-v1','reader':'/root/hair_ops','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(b).hexdigest(),'actual_displays':reads,'qualification':'All listed historical and current source windows were separately displayed via tool output after the prospective registration; output was not truncated. This is support-only credit. EOF complements remain unread within this packet even if earlier packets separately record fuller reads. 2579 lines 1–14 are support outside the original 15–70 material scope. Earlier 059, 774 and other current readers retain their own attributions and registrations.'}
out=(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n').encode();(r/'read-receipt.json').write_bytes(out);print('receipt',hashlib.sha256(out).hexdigest(),'views',len(reads))
