# Bounded reconciliation support for original roles 2577–2580

This packet proposes connections to existing 059 contracts for weapon facing,
placement, terrain and the native YAML boundary. It adds no finding count and
does not declare any lens complete. Fresh P16 and 95e facing/terrain source
windows, plus selected 95e geology producer and consumer windows, were
registered before separately displayed reads. See `registration.json`,
`read-receipt.json`, and `REPORT.json` for exact windows and unread complements.

Raw compressed 059 queue and ledger are byte-identical to their original Git
objects. Extracted selections are explicitly reconstructed; selected historical
receipts are copied exactly and linked by their original 059 hashes. Prior
reports and receipts remain separately attributed. The current central files
are captured working snapshots and can have been staged or uncommitted when
copied; their compressed copies expand to the hashes in the evidence index.

The recovered physical-P16 objects are separately bound to f82 transport, their
individual a120 clean-base files, and the pinned 95e project paths. This does
not establish a clean historical snapshot. The matching later tracked patch
omits seven untracked files. The original registry mismatch and Root046 camera
registration pin mismatch remain unresolved; no recovered evidence is promoted
to missing checkpoint 3821.

Run `python3 verify-evidence.py` from any directory for a read-only offline
check of evidence identities and the manifest. This is evidence verification,
not a product test, build, runtime probe, repair or behavioral validation.
