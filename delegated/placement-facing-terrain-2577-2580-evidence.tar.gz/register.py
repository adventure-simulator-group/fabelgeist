from pathlib import Path
import gzip,hashlib,json,tarfile,subprocess,datetime
r=Path(__file__).resolve().parent
prev=Path('<LOCAL_PATH_0>')
repo='<LOCAL_PATH_1>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009';base='a120390947c89b703dc74c4255a13c035d054c50';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
h=lambda b:hashlib.sha256(b).hexdigest()
reg=json.load(gzip.open(prev/'registry.json.gz','rt'));(r/'source').mkdir(); entries=[]
with tarfile.open(prev/'objects.tar.gz') as archive:
 for index,windows in [(2579,[[1,70]]),(437,[[20,45],[145,170]]),(432,[[65,95]]),(434,[[136,163],[216,222]]),(2580,[[15,35]])]:
  row=reg['files'][index];path=row['source_id'].split(':',1)[1];b=archive.extractfile(row['sha256']).read();assert h(b)==row['sha256']; transport='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];assert b==subprocess.check_output(['git','-C',repo,'show',f82+':'+transport]); assert b==subprocess.check_output(['git','-C',repo,'show',base+':'+path]); versions=[]
  for label,identity,payload in [('historical','physical-p16 dirty snapshot object; a120 is recorded clean base and f82 transports the object',b),('current','pinned project current 95e',subprocess.check_output(['git','-C',repo,'show',rev+':'+path]))]:
   loc=f'source/{index}-{label}.rs';(r/loc).write_bytes(payload);assert max(z for a,z in windows)<=len(payload.splitlines());versions.append({'identity':identity,'local':loc,'sha256':h(payload),'eof':len(payload.splitlines()),'registered_windows':windows,**({'revision':rev} if label=='current' else {})})
  entries.append({'original_index':index,'purpose':'bounded support for facing and terrain reconciliation; no new original role credit','project_path':path,'original_registry_row':row,'historical_transport_revision':f82,'historical_transport_path':transport,'versions':versions})
for name,path,windows in [('geology-producer','crates/adventuresim-world-import/src/sources/geology/windows.rs',[[32,100]]),('geology-consumer','crates/adventuresim-tactical-server-dispatcher/src/scene_input/geological_landforms.rs',[[250,295]]),('geology-window','crates/adventuresim-world-schema/src/geologic_window.rs',[[8,35]])]:
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);loc=f'source/{name}.rs';(r/loc).write_bytes(b);assert max(z for a,z in windows)<=len(b.splitlines());entries.append({'purpose':'bounded current support only; no original role credit','project_path':path,'versions':[{'identity':'pinned project current 95e','revision':rev,'local':loc,'sha256':h(b),'eof':len(b.splitlines()),'registered_windows':windows}]})
o={'schema':'726-central-2577-2580-bounded-prospective-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','entries':entries,'qualification':'Support views only; exact windows to be displayed separately per identity. Previous personal displays of roles2579/2580 and support are retained separately in prior receipts. 2579 original material is 15–70; 1–14 here is separate support, never retroactive role credit. 2579 registry snapshot pinned-native-dependency conflicts with physical-p16 source ID, p16 path and Camera registration. All historical per-file base matches do not establish clean P16. f82 is evidence transport only; role2580 P16 and pr-working role2712 remain distinct identities despite byte equality. No implementation, execution or validation.'}
b=(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode();(r/'registration.json').write_bytes(b)
print('registered',h(b),'entries',len(entries),'versions',sum(len(e['versions']) for e in entries))
for e in entries:
 for v in e['versions']:print(v['local'],v['sha256'],v['eof'],v['registered_windows'])
