from pathlib import Path
import hashlib,json,tarfile,io
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();d=Path('<LOCAL_PATH_0>').read_bytes();dest='metadata/spacetimedb-bindings-macro-2.6.1.crate';(b/dest).write_bytes(d);reg=json.loads((b/'registration.json').read_bytes());prior=Path('<LOCAL_PATH_1>');pr=json.loads((prior/'registration.json').read_bytes());assert sha(d)==pr['package_archive']['sha256'];rows=[]
with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
 for x in pr['roles']:
  z=t.extractfile(x['archive_member']).read();assert z==(prior/x['source_archive']).read_bytes() and sha(z)==x['sha256'];rows.append({'prior_role':x['original_index'],'member':x['archive_member'],'sha256':sha(z),'prior_source':x['source_archive']})
for lock in reg['lock_metadata']+[reg['p16_dirty_lock']]:assert next(x for x in lock['records'] if x['name']=='spacetimedb-bindings-macro' and x['version']=='2.6.1')['checksum']==sha(d)
out={'schema':'726-prior-macro-archive-link-v1','package':'spacetimedb-bindings-macro','version':'2.6.1','preserved':dest,'sha256':sha(d),'bytes':len(d),'member_links':rows,'qualification':'Prior separately attributed source reads; no fresh macro body read or execution by this packet. Lock/archive/member identity only; does not prove feature selection or expansion.'};(b/'prior-macro-archive.json').write_text(json.dumps(out,indent=2)+'\n');print('archive',sha(d),'members',len(rows))
