from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile,io,tomllib
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');g=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);sha=lambda d:hashlib.sha256(d).hexdigest();r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';pre='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/';cache=Path('<LOCAL_PATH_1>');(b/'metadata').mkdir();(b/'sources').mkdir();archives={}
for name in ['spacetimedb-lib','spacetimedb-sats']:
 f=cache/(name+'-2.6.1.crate');raw=f.read_bytes();p='metadata/'+f.name;(b/p).write_bytes(raw);archives[name]={'name':name,'version':'2.6.1','preserved':p,'bytes':len(raw),'sha256':sha(raw),'source':'crates.io cache, verified against explicit lock checksum'}
rows=[]
for i in [2672,2673,2674]:
 x=r['files'][i];ident=x['source_id'].split(':',1)[1];package,relative=ident.split('-2.6.1/',1);member=package+'-2.6.1/'+relative;raw=g('show',transport+':'+pre+x['sha256'])
 with tarfile.open(fileobj=io.BytesIO((b/archives[package]['preserved']).read_bytes()),mode='r:gz') as t:assert raw==t.extractfile(member).read()
 assert sha(raw)==x['sha256'] and len(raw)==x['bytes'] and len(raw.splitlines())==x['actual_line_count'];dest=f'sources/{i}.rs';(b/dest).write_bytes(raw);chunks=[]
 for a,z in x['material_ranges']:
  for k in range(a,z+1,60):chunks.append([k,min(k+59,z)])
 rows.append({'role':i,'source_id':x['source_id'],'package':package,'version':'2.6.1','native_identity':'crates.io package archive member, not project Git','archive_member':member,'archive_sha256':archives[package]['sha256'],'transport_revision':transport,'transport_path':pre+x['sha256'],'preserved_source':dest,'sha256':sha(raw),'bytes':len(raw),'eof':len(raw.splitlines()),'registered_ranges':x['material_ranges'],'planned_chunks':chunks,'historical_material_ranges':x['material_ranges']})
locks=[]
for label,rev in [('pr-working-base','6533e444fa37552927070cc8d8190907fd3b413e'),('current','95e63628f9d70b8dd6e6fede64334696c6995009')]:
 raw=g('show',rev+':Cargo.lock');sel=[x for x in tomllib.loads(raw.decode())['package'] if x['name'] in ('spacetimedb-lib','spacetimedb-sats','spacetimedb-bindings-macro')];dest='metadata/'+label+'-Cargo.lock.gz';(b/dest).write_bytes(gzip.compress(raw,mtime=0));locks.append({'label':label,'revision':rev,'path':'Cargo.lock','git_blob':g('rev-parse',rev+':Cargo.lock').decode().strip(),'sha256':sha(raw),'preserved_gzip':dest,'records':sel})
p=Path('<LOCAL_PATH_2>');compressed=p.read_bytes();raw=gzip.decompress(compressed);dest='metadata/p16-dirty-Cargo.lock.gz';(b/dest).write_bytes(compressed);sel=[x for x in tomllib.loads(raw.decode())['package'] if x['name'] in ('spacetimedb-lib','spacetimedb-sats','spacetimedb-bindings-macro')];p16={'label':'physical-p16 dirty recorded lock','base':'a120390947c89b703dc74c4255a13c035d054c50','sha256':sha(raw),'compressed_sha256':sha(compressed),'preserved_gzip':dest,'records':sel,'qualification':'Recorded dirty snapshot separate from clean base; exact tracked patch recovered later, not proof of original invocation or uninterrupted custody.'}
for lock in locks+[p16]:
 for name,arc in archives.items():
  v=[x for x in lock['records'] if x['name']==name and x['version']=='2.6.1'];assert len(v)==1 and v[0]['checksum']==arc['sha256']
out={'schema':'726-sats-namespace-prospective-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','roles':rows,'package_archives':list(archives.values()),'lock_metadata':locks,'p16_dirty_lock':p16,'qualification':'Exact original native role ranges registered before display. Full archive/member bytes and parsed lock metadata support identity only; no feature resolution, macro execution, decoder coverage, product test or runtime inference.'};(b/'registration.json').write_text(json.dumps(out,indent=2)+'\n');print('registration',sha((b/'registration.json').read_bytes()),'roles',[(x['role'],x['registered_ranges']) for x in rows],'archives',[(x['name'],x['sha256']) for x in archives.values()]);print('lock hashes',[(x['label'],x['sha256']) for x in locks+[p16]])
