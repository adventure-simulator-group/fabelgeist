from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,io,tarfile,json,gzip
b=Path(__file__).resolve().parent;pub='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',pub,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();rev='95e63628f9d70b8dd6e6fede64334696c6995009';tr='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';pre='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/';orig=json.load(gzip.open(Path(pub)/'recovered/original-registry-source-archive/registry.json.gz','rt'));(b/'support').mkdir(exist_ok=True);rows=[]
def add(kind,path,dest,raw,ranges,revision=None,extra=None):
 eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in ranges);chunks=[[s,min(s+59,z)] for a,z in ranges for s in range(a,z+1,60)];(b/dest).write_bytes(raw);x={'kind':kind,'path':path,'archive':dest,'sha256':sha(raw),'bytes':len(raw),'eof':eof,'revision':revision,'registered_ranges':ranges,'planned_chunks':chunks};x.update(extra or {});rows.append(x)
for index,path,dest,ranges in [(2670,'crates/adventuresim-world-schema/Cargo.toml','support/p16-world-cargo.toml',[[1,31]]),(2671,'Cargo.toml','support/p16-workspace-cargo.toml',[[178,182]]),(439,'crates/adventuresim-world-schema/src/basis_points.rs','support/p16-basis-points.rs',[[1,30],[90,125]])]:
 raw=g('show',tr+':'+pre+orig['files'][index]['sha256']);assert sha(raw)==orig['files'][index]['sha256'];add('physical-p16 historical source transport, no ordered credit',path,dest,raw,ranges,tr,{'historical_role':index,'transport_path':pre+sha(raw)})
for path,dest,ranges in [('crates/adventuresim-world-schema/Cargo.toml','support/current-world-cargo.toml',[[1,31]]),('Cargo.toml','support/current-workspace-cargo.toml',[[174,181]]),('crates/adventuresim-world-schema/src/basis_points.rs','support/current-basis-points.rs',[[1,30],[90,125]])]:
 raw=g('show',rev+':'+path);add('pinned current project source support',path,dest,raw,ranges,rev)
for package in ['spacetimedb-lib','spacetimedb-sats']:
 arc=b/'metadata'/f'{package}-2.6.1.crate';member=f'{package}-2.6.1/Cargo.toml'
 with tarfile.open(fileobj=io.BytesIO(arc.read_bytes()),mode='r:gz') as t:raw=t.extractfile(member).read()
 eof=len(raw.splitlines());add('native package manifest support',member,'support/'+package+'-Cargo.toml',raw,[[1,eof]],None,{'package':package,'version':'2.6.1','archive_sha256':sha(arc.read_bytes()),'member':member})
out={'schema':'726-sats-namespace-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'Prospective source-only supporting ranges; P16 transport not base commit, native package not project Git. No original ordered role credit, macro execution or feature activation inferred.'};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print('registration',sha((b/'support-registration.json').read_bytes()));print(json.dumps(rows,indent=2))
