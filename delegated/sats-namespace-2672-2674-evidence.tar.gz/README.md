# Bounded SATS namespace source evidence

This packet records `/root/rig_identity`'s independent review of original
registry roles 2672–2674. These are source members of the crates.io packages
`spacetimedb-lib` 2.6.1 and `spacetimedb-sats` 2.6.1, not project Git files.
Their archives and the bindings-macro 2.6.1 archive are retained in
`metadata/`; their SHA-256 values match the separately preserved 6533, pinned
95e, and dirty P16 lock selections. Lock parsing establishes package identity,
not a resolved feature graph.

The personally displayed original role ranges are 2672 lines 39–49, 2673 lines
74–96, and 2674 line 320. Typespace lines 300–325 were separately registered
and displayed as context; the rest of the package sources remain unread in this
review despite their full archived bytes. The historical P16 and pinned 95e
world-schema declarations, selected workspace manifest ranges and native package
manifests were independently registered as support. The P16 and current world
manifest and basis-point source match per file; their workspace manifests differ
as whole files. `personal-read-receipt.json` records exact chunks and unread
complements.

The original 774 qualification describes role 2674 line 320 as a trait method.
The actual line is a macro re-export; the trait method appears at line 317 in
separately read context. The earlier 059 L12-926 receipt and q3443 already
corrected this description. The original qualification and correction are both
preserved. The 059 Lens11 receipt does not name an individual;
`/root/lens12_frontier` independently read the three historical ranges in
Lens12, with zero root rereads.

The historical native witness 042 initially left the exact P16 SATS route
pending. Native contract 043 later documented a scoped source relationship to
camera's named-product macro review. The current source has a feature-gated
basis-point derive and the same namespace chain, but the declarations and
lockfiles do not establish an enabled feature, generated expansion or actual
product ingress. Existing basis-point admission and native-macro questions
retain their distinct prior attribution and do not produce a new count here.

The packet includes exact recovered 059 registry and transport manifests, the
selected 059 baseline records and exact receipts, exact f82 774 supplier records,
raw Git membership proofs, the later P16 recovery report and tracked patch, and
the complete exact prior local macro packet. The separately preserved published
macro report differs from that original in one redacted local-path field; both
hashes and the difference are checked. Selected registry and queue JSON files
are reconstructed views, not historical standalone records. The exact prior
local packet contains local path information: preserve it as original evidence
and separately identify any public redacted reconstruction.

P16 is a dirty snapshot based on `a120390947c89b703dc74c4255a13c035d054c50`,
not a commit. Its later recovered tracked patch matches the recorded hash, with
seven untracked files separate. Matching bytes do not prove the original diff
invocation or uninterrupted custody. This packet does not recover or promote
the checkpoint 3821 ledger or queue.

Run `python3 verify-evidence.py` to check the self-contained evidence,
provenance, archive membership, lock metadata and source read partitions; run
`python3 verify-manifest.py` to verify frozen packet files. No Cargo resolution,
macro expansion, product execution, build, test, simulation or runtime probe was
performed.
