from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reads=[]
def complement(eof,rs):
 seen={i for a,z in rs for i in range(a,z+1)};out=[]
 for i in sorted(set(range(1,eof+1))-seen):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for fn,key in [('registration.json','roles'),('support-registration.json','entries'),('native-extra-registration.json','entries')]:
 for x in load(fn)[key]:
  a=x.get('archive',x.get('preserved_source'));rs=x['registered_ranges'];chunks=x['planned_chunks'];reads.append({'kind':x.get('kind','assigned native package original role'),'role':x.get('role'),'archive':a,'sha256':x['sha256'],'revision':x.get('revision'),'package':x.get('package'),'eof':x['eof'],'registration':fn,'actual_display_ranges':rs,'actual_display_chunks':chunks,'unread_complement':complement(x['eof'],rs),'qualification':'Personally displayed after prospective registration, without truncation. Native archive source and P16 support do not confer project revision or other reviewer/role credit.'})
regs=[]
for f in ['registration.json','support-registration.json','native-extra-registration.json']:
 d=(b/f).read_bytes();regs.append({'path':f,'sha256':sha(d),'registered_utc':json.loads(d)['registered_utc']})
out={'schema':'726-sats-namespace-personal-reads-v1','author':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registrations':regs,'reads':reads};(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('reads',len(reads),'receipt_sha',sha((b/'personal-read-receipt.json').read_bytes()))
