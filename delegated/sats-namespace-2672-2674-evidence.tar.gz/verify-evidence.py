from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,sys,tarfile,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads(Path(p).read_bytes());gun=lambda p:gzip.decompress(Path(p).read_bytes());r=load(b/'registration.json');support=load(b/'support-registration.json');rec=load(b/'personal-read-receipt.json');report=load(b/'REPORT.json');hist=load(b/'historical-attribution.json')
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes']
 if 'uncompressed_sha256' in x:
  z=gzip.decompress(d);assert sha(z)==x['uncompressed_sha256'] and len(z)==x['uncompressed_bytes']
origraw=gun(b/'historical/registry.json.gz');assert sha(origraw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';orig=json.loads(origraw);sel=load(b/'registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2672,2673,2674,2670,2671,439,39]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==orig['files'][x['original_index']]
for x in sel['snapshots']:assert x in orig['snapshots']
pr=next(x for x in orig['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
p16=next(x for x in orig['snapshots'] if x['id']=='physical-p16');assert p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load(b/'historical/p16-recovery.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256'] and recovery['recovered_patch']['bytes']==524542 and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7};assert sha((b/'historical/p16-tracked.patch').read_bytes())==p16['patch_sha256']
archives={x['name']:x for x in r['package_archives']};assert set(archives)=={'spacetimedb-lib','spacetimedb-sats'}
for name,x in archives.items():
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and x['version']=='2.6.1'
for x in r['roles']:
 arc=(b/archives[x['package']]['preserved']).read_bytes();data=(b/x['preserved_source']).read_bytes();o=orig['files'][x['role']]
 with tarfile.open(fileobj=io.BytesIO(arc),mode='r:gz') as t:assert t.extractfile(x['archive_member']).read()==data
 assert sha(data)==x['sha256']==o['sha256'] and len(data)==x['bytes']==o['bytes'] and len(data.splitlines())==x['eof']==o['actual_line_count'] and x['registered_ranges']==o['material_ranges'] and x['archive_sha256']==sha(arc)
for x in support['entries']:
 d=(b/x['archive']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes'] and len(d.splitlines())==x['eof']
 if x['kind'].startswith('native'):
  arc=(b/archives[x['package']]['preserved']).read_bytes();assert sha(arc)==x['archive_sha256']
  with tarfile.open(fileobj=io.BytesIO(arc),mode='r:gz') as t:assert t.extractfile(x['member']).read()==d
 elif x['kind'].startswith('physical'):assert sha(d)==orig['files'][x['historical_role']]['sha256']
for a,c in [('support/p16-world-cargo.toml','support/current-world-cargo.toml'),('support/p16-basis-points.rs','support/current-basis-points.rs')]:assert (b/a).read_bytes()==(b/c).read_bytes()
assert (b/'support/p16-workspace-cargo.toml').read_bytes()!=(b/'support/current-workspace-cargo.toml').read_bytes()
assert (b/'sources/2674.rs').read_bytes().splitlines()[319]==b'pub use spacetimedb_bindings_macro::SpacetimeType;'
macro=load(b/'prior-macro-archive.json');macrodata=(b/macro['preserved']).read_bytes();assert len(macrodata)==macro['bytes'] and sha(macrodata)==macro['sha256']=='fce86c7657dcb42a33ce55f0100f98964dc15b64e79f06803a478676b74d6c82'
for lock in r['lock_metadata']+[r['p16_dirty_lock']]:
 raw=gun(b/lock['preserved_gzip']);assert sha(raw)==lock['sha256'];selected=[x for x in tomllib.loads(raw.decode())['package'] if x['name'] in ('spacetimedb-lib','spacetimedb-sats','spacetimedb-bindings-macro')];assert selected==lock['records']
 for name,x in archives.items():assert next(v for v in selected if v['name']==name and v['version']=='2.6.1')['checksum']==x['sha256']
 assert next(v for v in selected if v['name']=='spacetimedb-bindings-macro' and v['version']=='2.6.1')['checksum']==sha(macrodata)
assert r['p16_dirty_lock']['sha256']==orig['files'][39]['sha256'] and sha((b/r['p16_dirty_lock']['preserved_gzip']).read_bytes())==r['p16_dirty_lock']['compressed_sha256']
q=json.loads(gun(b/'historical/baseline-059-queue.json.gz'))['entries']
for x in load(b/'queue-selection-reconstructed.json')['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert [q[i]['contract_id'] for i in (131,2332,3443)]==['ADLER-L11-BASIS-POINTS-WIRE-ADMISSION','L12-CLOSURE-NATIVE-SATS-REFLECTION-ADAPTER-OWNERS','L12-CLOSURE-PHYSICAL-SATS-NAMESPACE']
mi=json.loads(gun(b/'historical/original-transport-manifest.json.gz'));idx={x['path']:x for x in mi['entries']};assert not hist['missing'] and len(hist['records_059'])==21
for x in hist['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert sha(d)==x['sha256']==m['sha256'] and len(d)==x['bytes']==m['bytes'] and oid('blob',d)==x['git_blob']==m['git_blob']
l11=load(b/'historical/059/segovb/READ-L11-437.json');l12=load(b/'historical/059/segovb/READ-L12-926.json');assert l12['root_personal_rereads']==[]
for i in (2672,2673,2674):
 x=next(x for x in l11['sources'] if x['original_index']==i);y=next(x for x in l12['rows'] if x['original_index']==i);expected=orig['files'][i]['material_ranges'];assert x['fresh_personal_body_reads']==y['fresh_personal_body_reads']==expected and '/root/lens12_frontier' in y['attribution']
assert 'traitmethod' in json.dumps(orig['files'][2674]).lower() and 'macro reexport' in json.dumps(next(x for x in l12['rows'] if x['original_index']==2674)).lower()
reglines=[json.loads(x) for x in gun(b/'historical/774/native/admission03/source-range-registration.jsonl.gz').splitlines()];qllines={x['id']:x for x in [json.loads(z) for z in gun(b/'historical/774/native/admission03/source-qualifications-final-082.jsonl.gz').splitlines()]}
for i in (2672,2673,2674):
 x=orig['files'][i]['admission03_scope_observations'][0];assert reglines[x['row_1based']-1]==x['original_record']
 for qual in x['local_qualifications']:assert qllines[qual['id']]==qual
assert json.loads(gun(b/'historical/774/native/admission03/p16-basispoints-admission-witness-042.json.gz'))['id']=='NATIVE-ADMISSION03-P16-BASISPOINTS-WITNESS-042'
assert json.loads(gun(b/'historical/774/native/admission03/contract-groups-043.json.gz'))['id']=='NATIVE-ADMISSION03-CONTRACT-GROUPS-043'
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
proof=load(b/'git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(b/x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==19
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gun(p) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
prior=hist['prior_current_macro'];pd=(b/prior['exact_local_archive']['preserved']).read_bytes();assert len(pd)==prior['exact_local_archive']['bytes'] and sha(pd)==prior['exact_local_archive']['sha256']
with tarfile.open(fileobj=io.BytesIO(pd),mode='r:gz') as t:
 mf=t.extractfile('MANIFEST.json').read();assert sha(mf)==prior['original_manifest_sha256'];manifest=json.loads(mf)
 for x in manifest['files']:
  raw=t.extractfile(x['path']).read();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
 oldreport=t.extractfile('REPORT.json').read();pubreport=(b/'historical/published-stdb-macro-report.json').read_bytes();assert sha(oldreport)==prior['original_report_sha256'] and sha(pubreport)==prior['published_report_sha256'] and (oldreport==pubreport)==prior['published_report_byte_identical_to_original'] is False
 oldjson=json.loads(oldreport);publicjson=json.loads(pubreport);assert oldjson['historical_attribution'][7]['record']=='published-references.json: <LOCAL_PATH_0>' and publicjson['historical_attribution'][7]['record']=='published-references.json: <LOCAL_PATH_0>';oldjson['historical_attribution'][7]['record']=publicjson['historical_attribution'][7]['record'];assert oldjson==publicjson
 oldreceipt=json.loads(t.extractfile('personal-read-receipt.json').read());assert oldreceipt['author']=='/root/rig_identity'
 for source,expected in [('support/spacetimedb-lib__lib.rs',[[1,55]]),('support/spacetimedb-sats__lib.rs',[[1,45],[75,100]]),('support/spacetimedb-sats__typespace.rs',[[300,325]])]:
  x=next(z for z in oldreceipt['read_entries'] if z['source']==source);assert x['displayed_chunks']==expected
 with tarfile.open(fileobj=io.BytesIO(macrodata),mode='r:gz') as mt:
  for x in macro['member_links']:
   d=mt.extractfile(x['member']).read();assert sha(d)==x['sha256'] and d==t.extractfile(x['prior_source']).read()
for x in rec['registrations']:
 d=(b/x['path']).read_bytes();assert sha(d)==x['sha256'] and datetime.fromisoformat(json.loads(d)['registered_utc'])<datetime.fromisoformat(rec['recorded_utc'])
scopes={}
for x in rec['reads']:
 d=(b/x['archive']).read_bytes();assert sha(d)==x['sha256'] and len(d.splitlines())==x['eof'];reg=load(b/x['registration']);pool=reg.get('roles',reg.get('entries'));matches=[v for v in pool if v.get('archive',v.get('preserved_source'))==x['archive']];assert len(matches)==1 and matches[0]['sha256']==x['sha256'] and matches[0]['registered_ranges']==x['actual_display_ranges'];covered={i for a,z in x['actual_display_ranges'] for i in range(a,z+1)};chunks={i for a,z in x['actual_display_chunks'] for i in range(a,z+1)};other={i for a,z in x['unread_complement'] for i in range(a,z+1)};assert covered==chunks and not covered&other and covered|other==set(range(1,x['eof']+1));scopes.setdefault((x['archive'],x['sha256']),set()).update(covered)
assert len(rec['reads'])==12 and len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
def visit(x):
 if isinstance(x,dict):
  if all(k in x for k in ('archive','lines','sha256')):
   a,z=x['lines'];assert set(range(a,z+1))<=scopes[(x['archive'],x['sha256'])],x
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','counts':{'original_roles':3,'personal_read_entries':12,'raw_git_path_proofs':len(proof['paths']),'original_059_records':len(hist['records_059']),'exact_774_records':len(hist['records_774']),'bounded_lens_perspectives':13},'checks':['Self-contained native archive/member/checksum identity across historical, current and recorded dirty P16 locks; no Cargo resolution','Raw Git membership for f82 transported native/P16/774 evidence and 6533/95e project support and locks','Original 059 registry/transport evidence, exact records and selected 059 queue reconstruction; 774 registry/qualification equality and historical correction','Exact original prior macro packet and native archive, distinct hash of reconstructed published report, reviewer/read attribution','Prospective actual read partitions, cited source ranges, P16 recovery qualifications and no checkpoint3821 promotion','Evidence integrity and structured lock parsing only; no product, macros, build, tests or runtime probes.']};raw=(json.dumps(result,indent=2)+'\n').encode()
if '--record' in sys.argv:(b/'evidence-verification.json').write_bytes(raw)
print('PASS',sha(raw),result['counts'])
