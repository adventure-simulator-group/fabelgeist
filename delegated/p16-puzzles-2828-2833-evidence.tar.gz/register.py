from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent
repo=Path('<LOCAL_PATH_0>')
base=repo/'recovered/original-registry-source-archive';h=lambda x:hashlib.sha256(x).hexdigest()
r=json.load(gzip.open(base/'registry.json.gz','rt'));rows=[];pending=[]
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 for i in [2828,2829,2830,2831,2832,2833]:
  x=r['files'][i];path=x['source_id'].split(':',1)[1]
  old=t.extractfile(x['sha256']).read();assert h(old)==x['sha256'] and len(old.splitlines())==x['actual_line_count']
  loc=f'source/{i}-historical.rs';pending.append((loc,old))
  vs=[{'identity':'exact archived '+x['snapshot']+' registry object','sha256':h(old),'bytes':len(old),'eof':len(old.splitlines()),'local':loc,'original_material_planned':x['material_ranges']}];compare=[]
  revs=(['a120390947c89b703dc74c4255a13c035d054c50','039329518e264f19206cf5b0b98d177433f40c17','6533e444fa37552927070cc8d8190907fd3b413e'] if x['snapshot']=='physical-p16' else ['6533e444fa37552927070cc8d8190907fd3b413e'])+['95e63628f9d70b8dd6e6fede64334696c6995009']
  for rev in revs:
   obj=subprocess.run(['git','-C',str(repo),'show',rev+':'+path],capture_output=True)
   if obj.returncode:
    d={'revision':rev,'path_absent':True,'stderr':obj.stderr.decode(errors='replace'),'display_planned':False};(vs if rev.startswith('95e') else compare).append(d);continue
   raw=obj.stdout;blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+path],text=True).strip()
   assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
   loc=f'source/{i}-{rev[:4]}.rs';pending.append((loc,raw))
   d={'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':loc,'equals_historical_object':raw==old}
   if rev.startswith('95e'):d['current_body_planned']=x['material_ranges'] if raw==old else [[1,len(raw.splitlines())]];vs.append(d)
   else:d['display_planned']=False;compare.append(d)
  rows.append({'original_index':i,'source_id':x['source_id'],'snapshot':x['snapshot'],'path':path,'original_material_ranges':x['material_ranges'],'historical_scope_limits':x['scope_limits'],'versions':vs,'comparison_git_paths':compare})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively register exact historical material and separately pinned current counterparts; if changed, full current source registered for bounded selection; only actual displays will be credited, exact personal displays and unread complement recorded later. Historical P16 roles and prior reader attribution retained separately. Additional historical exclusions and support require prior registration. Diff display after this registration allowed but not full line body credit.','original_registry_uncompressed_sha256':h(gzip.decompress((base/'registry.json.gz').read_bytes())),'snapshot_qualification':'P16 is dirty based a120; later reproduced tracked patch matches historical digest but command and uninterrupted custody unproved, seven untracked objects separately qualified. PR 6533-based with unrelated dirty paths. f82 transports records; 039 is cataloged per-file origin, not P16 HEAD. No checkpoint3821 promotion.','rows':rows,'limits':'Static source/evidence inspection only. Test/fixture text is not executed. No product, generated code, macro, test, build, probe, repair or publication edit.'}
(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('REGISTRATION_SHA256',h((b/'registration.json').read_bytes()))
