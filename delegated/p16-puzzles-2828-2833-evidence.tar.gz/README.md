# P16 puzzle roles 2828–2833

This packet contains source-only evidence for the six original physical-p16
puzzle manifest, module, choice and authority roles, against pinned current
revision `95e63628f9d70b8dd6e6fede64334696c6995009`. Each registered historical
body range and current counterpart was separately displayed. The exact per-file
bytes match a120, cataloged origin 039, 6533 and 95e; that does not establish
whole-tree equality or a clean P16 snapshot. Role 2826 was assigned elsewhere.

`REPORT.json` contains source references, 13 partial lens perspectives, the
existing route-admission and repeated-operation policy relationships, and open
questions. `registration.json` and `support-registration.json` predate displays;
`read-receipt.json` records exact chunks and unread fixture tails. Full archived
bytes are preservation, not read credit. Challenge support is not ordered-role
credit. No puzzle or fixture was generated or executed.

The old native REG040 nominal Sigil range includes blank line 62; QUAL066 and
Root206 restrict material to 1–61. Segovb's older fresh reads, the PL13 partial
receipts, and the previous current 95e assessment retain their original readers,
ranges and revisions. Original records are under `historical/`; selected registry
and queue rows are reconstructed and labelled. Earlier registry-file SHA and the
f82 file SHA differ even though the six embedded JSON rows agree; no whole-file
recovery or global absence is inferred from this row match.

`git-proofs.json` and `git-objects/` retain path membership proofs. The later P16
tracked patch matches the historical digest but has independent custody, original
command and seven untracked-object qualifications. `MANIFEST.json` covers every
packet file except itself, including nested manifests. Run
`python3 verify-evidence.py` for offline evidence-integrity verification only;
it does not execute product code, fixtures, or tests.
