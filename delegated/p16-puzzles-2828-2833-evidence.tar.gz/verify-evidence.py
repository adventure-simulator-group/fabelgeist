'''Offline source/evidence integrity verification only, never product execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();L=lambda n:json.loads((b/n).read_bytes())
reg=L('registration.json');rec=L('read-receipt.json');hist=L('historical-manifest.json');sel=L('historical-selections-reconstructed.json');proof=L('git-proofs.json');report=L('REPORT.json');ids=list(range(2828,2834));expected={2828:[[1,15]],2829:[[1,19]],2830:[[1,6]],2831:[[1,61]],2832:[[1,53]],2833:[[1,944]]}
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
assert not hist['linked_059_missing_originals'];arch=L('recovered/MANIFEST.json');rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256']==arch['registry_sha256'];assert h((b/'recovered/registry.json.gz').read_bytes())==arch['registry_gzip_sha256'];assert h((b/'recovered/objects.tar.gz').read_bytes())==arch['objects_archive_sha256'];r=json.loads(rbytes);original=r['files'];assert all(original[i]==sel['registry_rows'][str(i)] for i in ids);assert sel['snapshot_rows']==[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')]
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qbytes);assert h(qbytes)==sel['queue_uncompressed_sha256'] and all(q['entries'][int(k)]==v for k,v in sel['queue_entries'].items());cv=L('prior/COVERAGE-L01-ROLES.json');assert h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes())==sel['prior_coverage_sha256'];assert all(next(x for x in cv['roles'] if x['original_index']==i)==sel['prior_coverage_roles'][str(i)] for i in ids)
snap=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=L('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['live_comparison']['status_counts']['??']==7
catalog=L('recovered/catalog-774.json')['rows']
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];raw=(b/old['local']).read_bytes();assert t.extractfile(old['sha256']).read()==raw and h(raw)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256'];assert original[i]['material_ranges']==row['original_material_ranges']==expected[i];assert catalog[i]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path'];assert (b/cur['local']).read_bytes()==raw and cur['equals_historical_object']
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==raw and c['equals_historical_object'] and not c['display_planned']
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(x['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(rr):return [i for a,z in rr for i in range(a,z+1)]
def part(n,rr):
 v=nums(rr);return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  x=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/x['local']).read_bytes();assert h(raw)==v['sha256']==x['sha256'] and len(raw.splitlines())==v['eof']==x['eof'];assert set(nums(x['actual_display_chunks']))==set(nums(expected[row['original_index']]));assert part(v['eof'],x['actual_display_chunks']+x['unread_complement']);assert x['original_material_ranges']==(expected[row['original_index']] if not j else [])
plans={x['name']:x for x in L('support-registration.json')['entries']}
for x in rec['support']:
 p=plans[x['name']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==p['sha256'] and len(raw.splitlines())==x['eof'] and x['ordered_role_credit']==0;assert nums(x['full_line_body_displays'])==nums(p['ranges']) and part(x['eof'],x['full_line_body_displays']+x['unread_complement'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()];raw=(b/'historical/774/native-source-range-registration.jsonl').read_bytes();parts=raw.splitlines(keepends=True);native=readjsonl('historical/774/native-source-range-registration.jsonl');quals=readjsonl('historical/774/native-source-qualifications.jsonl');qual=L('registry-file-qualification.json');root=L('historical/774/root-new-parallel-admission-206.json');assert h(raw)=='0bb2e7a6198efc2e3db19800dd507c9a5ec91dc47c9fa388e612162d133f5bed' and len(parts)==qual['file_line_count']
for i in ids:
 ob=original[i]['scope_registration'][0];assert native[ob['row_1based']-1]==ob['original_record'];qid='NATIVE-INITIAL05-QUAL%03d'%(63+i-2828);qu=next(x for x in quals if x.get('id')==qid);assert qu['qualified_material_ranges']==expected[i];assert next(x for x in root['source_roles'] if x.get('registration_id')==ob['id'])['actual_compared_ranges']==expected[i];qr=next(x for x in qual['roles'] if x['role']==i);assert qr['recorded_earlier_file_sha256']==ob['sha256'] and qr['f82_file_sha256']==h(raw) and qr['parsed_row_equals_original_registry_record'] and qr['complete_line_prefix_matches']==[j for j in range(1,len(parts)+1) if h(b''.join(parts[:j]))==ob['sha256']]==[]
 seg=L('historical/059/segovb/READ-L11-459.json' if i<=2832 else 'historical/059/segovb/READ-L11-460.json');x=next(x for x in seg['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected[i]==x['assessed_ranges'];assert h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{1749+i-2828}.json').read_bytes())==x['registration_sha256']
q66=next(x for x in quals if x.get('id')=='NATIVE-INITIAL05-QUAL066');assert q66['original_registered_ranges']==[[1,62]] and q66['context_only_ranges']==[[62,62]]
g203=L('historical/774/native-contract-groups-203.json');g208=L('historical/774/native-contract-groups-208.json');assert 'NATIVE-INITIAL05-F045' in g203['finding_support'] and any('NATIVE-INITIAL05-F045' in x for x in g208['finding_support']);assert any(x.get('id')=='NATIVE-INITIAL05-F045' for x in readjsonl('historical/774/native-findings.jsonl'));assert any(x.get('id')=='ROOT-ADM-F008' for x in readjsonl('historical/774/root-findings.jsonl'))
assert L('prior/ASSESSMENT-L05-RUNE-ROUTE-95E.json')['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009';assert len(proof['proofs'])==40 and len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 seen=set()
 for x in L('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert h(raw)==x['sha256'] and len(raw)==x['bytes'],x['path'];seen.add(x['path'])
 assert seen=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p!=b/'MANIFEST.json'}
print('PASS: roles 2828–2833; separate old/current displays, historical reader/registry qualifications, P16 archive/patch, 40 Git proofs and 13 partial lenses. Evidence integrity only; no product execution.')
