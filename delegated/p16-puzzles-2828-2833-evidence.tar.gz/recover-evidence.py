from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path.cwd();pub=Path('<LOCAL_PATH_0>');orig=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');workspace=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/n,'recovered/'+n,'Archive/registry and 059 original copies where labelled, catalog reconstructed; later tracked patch recovered with custody and untracked qualifications.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-core/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Current governing source rules; source-only prohibition prevails.')
for n in ['COVERAGE-L01-ROLES.json','ASSESSMENT-L05-RUNE-ROUTE-95E.json','ASSESSMENT-L01-HISTORICAL-1061-1070.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Published prior bounded assessment or later recovery; scopes and attribution remain as recorded.')
names=['segovb/READ-L11-459.json','segovb/STATE-L11-459.json','segovb/VERIFY-L11-459.json','segovb/READ-L11-460.json','segovb/STATE-L11-460.json','segovb/VERIFY-L11-460.json']+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in range(1749,1755)]
for n in names:copy(orig/n,'historical/059/'+n,'Exact extracted 059 receipt/registration, prior reviewer and scope preserved.')
a=json.loads((b/'prior/ASSESSMENT-L05-RUNE-ROUTE-95E.json').read_bytes());seen={r['local'] for r in records};missing=[]
for x in a['recovered_historical_receipts']+a['recovered_historical_support']:
 n=x['original_path'];src=(orig/n).resolve();assert src.is_relative_to(orig.resolve());local='historical/059/'+n
 if not src.is_file():missing.append({'path':n,'sha256':x['sha256']});continue
 raw=src.read_bytes();assert h(raw)==x['sha256']
 if local in seen:assert (b/local).read_bytes()==raw;continue
 save(raw,local,src,'Exact 059 linked prior receipt; reader/partial ranges retained.');seen.add(local)
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';paths=[('native','initial05-aggregate-states',n) for n in ['source-range-registration.jsonl','source-qualifications.jsonl','contract-groups-203.json','contract-groups-208.json','findings.jsonl']]+[('root','admission03',n) for n in ['new-parallel-admission-206.json','puzzle-admission-032.json','findings.jsonl']]+[('root','','parallel-scope-qualification-200.json')]
for owner,folder,n in paths:
 gp='/'.join(x for x in ['handoff/774/adler-original/audit/continuation',owner,folder,n] if x);raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,'historical/774/'+owner+'-'+n,'git:'+rev+':'+gp,'Original 774 record via f82 transport; earlier whole-file recorded hash separately qualified.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw);qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw);cv=json.loads((b/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=list(range(2828,2834));s={'kind':'Newly reconstructed selected rows, not original record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in ids},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')],'queue_uncompressed_sha256':h(qraw),'queue_entries':{str(i):q['entries'][i] for i in [3294]},'prior_coverage_sha256':h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes()),'prior_coverage_roles':{str(i):next(x for x in cv['roles'] if x['original_index']==i) for i in ids},'qualification':'P16 dirty a120-based snapshot distinct from 039 per-file origin/f82 transport and PR identity. No 3821 promotion.'};(b/'historical-selections-reconstructed.json').write_text(json.dumps(s,indent=2)+'\n');(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'linked_059_missing_originals':missing,'qualification':'Prior reviewer/revision/range retained; f82 transports evidence only.'},indent=2)+'\n');print('recovered',len(records),'missing',len(missing),'manifest',h((b/'historical-manifest.json').read_bytes()))
