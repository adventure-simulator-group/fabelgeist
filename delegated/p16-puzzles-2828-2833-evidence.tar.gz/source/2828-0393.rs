[package]
name = "adventuresim-puzzles"
version.workspace = true
edition.workspace = true
repository.workspace = true
license.workspace = true

[dependencies]
serde.workspace = true
serde_json.workspace = true
clap.workspace = true
fabelgeist-determinism.workspace = true

[lints]
workspace = true
