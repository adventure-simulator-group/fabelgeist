from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path.cwd();h=lambda x:hashlib.sha256(x).hexdigest();L=lambda n:json.loads((b/n).read_bytes());reg=L('registration.json');supportreg=L('support-registration.json')
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2828:[[1,15]],2829:[[1,19]],2830:[[1,6]],2831:[[1,61]],2832:[[1,53]],2833:[[1,160],[161,320],[321,480],[481,640],[641,800],[801,944]]};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if not j else v['revision'],'local':v['local'],'sha256':v['sha256'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if not j else [],'unread_complement':comp(v['eof'],nums(d)),'qualification':'Historical and pinned current were separately displayed after registration; a120/039/6533 are mechanically compared, not separate displays.'})
support=[]
for x in supportreg['entries']:
 d=x['ranges'];support.append({'name':x['name'],'registration':'support-registration.json','path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'unread_complement':comp(x['eof'],nums(d)),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Reconstructed personal display receipt after prospective registrations; no historical read credit transferred.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':L(n)['created_utc']} for n in ['registration.json','support-registration.json']],'assigned':assigned,'support':support,'limits':'No role2826 inspection; no execution of puzzle, fixtures, macro, test, build, runtime probe, repair or publication edit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt',h((b/'read-receipt.json').read_bytes()))
