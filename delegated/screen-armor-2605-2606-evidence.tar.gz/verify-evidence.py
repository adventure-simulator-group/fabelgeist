#!/usr/bin/env python3
"""Read-only integrity checks of this packet. Never executes product or old verifiers."""
from pathlib import Path
import gzip, hashlib, json, tarfile
b=Path(__file__).resolve().parent
read=lambda p:(b/p).read_bytes()
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest()
js=lambda p:json.loads(read(p))
jgz=lambda p:json.loads(gzip.decompress(read(p)))
rr={}
for regfile,receiptfile in [('registration.json','personal-read-receipt.json'),('supplement-registration.json','supplement-read-receipt.json')]:
 reg=js(regfile); rec=js(receiptfile)
 assert rec['registration']==regfile and rec['registration_sha256']==sha(read(regfile)) and rec['recorded_utc']>=reg['registered_utc']
 by={x['id']:x for x in rec['reads']};assert len(by)==len(reg['entries'])
 for e in reg['entries']:
  d=read(e['archive']);x=by[e['id']]
  assert (len(d),sha(d),len(d.splitlines()))==(e['bytes'],e['sha256'],e['eof'])
  assert x['sha256']==e['sha256'] and x['eof']==e['eof'] and x['actual_display_ranges']==e['prospective_display_ranges']
  yes={i for a,z in x['actual_display_ranges'] for i in range(a,z+1)};no={i for a,z in x['unread_complement'] for i in range(a,z+1)}
  assert not yes&no and yes|no==set(range(1,e['eof']+1));rr[e['id']]=x
report=js('REPORT.json')
for a in report['findings_and_safeguards']:
 for ref in a.get('references',[]):
  covered={i for x,y in rr[ref['source']]['actual_display_ranges'] for i in range(x,y+1)}
  assert all(i in covered for x,y in ref['lines'] for i in range(x,y+1))
gp=js('git-proofs.json');raw={}
for key,x in gp['objects'].items():
 d=gzip.decompress(read(x['preserved_bytes']));assert (len(d),sha(d),oid(x['type'],d))==(x['bytes'],x['sha256'],key);raw[key]=d
for rev,x in gp['commits'].items(): assert raw[rev].splitlines()[0]==b'tree '+x['root_tree'].encode()
def ents(d):
 z={};i=0
 while i<len(d):
  j=d.index(b'\0',i);m,n=d[i:j].split(b' ',1);z[n.decode()]=(m.decode(),d[j+1:j+21].hex());i=j+21
 return z
for x in gp['paths']:
 d=read(x['preserved_bytes']);d=gzip.decompress(d) if x.get('preserved_encoding')=='gzip' else d
 assert (len(d),sha(d),oid('blob',d))==(x['bytes'],x['sha256'],x['git_blob'])
 cur=gp['commits'][x['revision']]['root_tree'];names=[]
 for y in x['path_chain']:
  assert cur==y['tree'];mode,child=ents(raw[cur])[y['name']];assert (mode,child)==(y['mode'],y['object']);cur=child;names.append(y['name'])
 assert '/'.join(names)==x['path'] and cur==x['git_blob']
registry=jgz('history/original-registry.json.gz');queue=jgz('history/baseline-059-queue.json.gz');ledger=jgz('history/baseline-059-ledger.json.gz');transport=jgz('history/original-transport-manifest.json.gz');idx={x['path']:x for x in transport['entries']}
for path,file in [('evidence/audit05/original-scope-072.json','history/original-registry.json.gz'),('workflow-20261030/CLOSURE-QUEUE-100.json','history/baseline-059-queue.json.gz'),('evidence/continuation-segovb/ledger.json','history/baseline-059-ledger.json.gz')]:
 d=gzip.decompress(read(file));assert (len(d),sha(d),oid('blob',d))==(idx[path]['bytes'],idx[path]['sha256'],idx[path]['git_blob'])
s=js('history/reconstructed-selections.json')
for i,v in s['registry_roles'].items():assert v==registry['files'][int(i)]
for i,v in s['queue_entries'].items():assert v==queue['entries'][int(i)]
assert s['ledger_rows']['/segovb_continuation/conditional_connected_contracts/4']==ledger['segovb_continuation']['conditional_connected_contracts'][4]
for k,f in [('registry_sha256','history/original-registry.json.gz'),('queue_sha256','history/baseline-059-queue.json.gz'),('ledger_sha256','history/baseline-059-ledger.json.gz')]:assert s[k]==sha(gzip.decompress(read(f)))
a=js('history/attribution-and-copies.json')['records']
for x in a:
 d=read(x['copy'])
 if x['kind']=='059':
  y=idx[x['original_path']];assert (len(d),sha(d),oid('blob',d))==(x['bytes'],x['sha256'],x['git_blob'])==(y['bytes'],y['sha256'],y['git_blob'])
 elif x['kind']=='774-f82':
  d=gzip.decompress(d);assert (len(d),sha(d),oid('blob',d))==(x['bytes_uncompressed'],x['sha256_uncompressed'],x['git_blob'])
  assert any(y['revision']==x['transport_revision'] and y['path']==x['transport_path'] and y['git_blob']==x['git_blob'] for y in gp['paths'])
 elif x['kind']=='prior-assessment':assert (len(d),sha(d))==(x['bytes'],x['sha256'])
 else:raise AssertionError(x['kind'])
for name in ['prior-screen-armor','prior-p16-armor','prior-armor-anime']:
 p='history/'+name+'/';m=js(p+'MANIFEST.json');mi={x['path']:x for x in m['files']}
 for x in a:
  if x['kind']=='prior-assessment' and x['copy'].startswith(p) and not x['copy'].endswith('MANIFEST.json'):
   y=mi[x['copy'][len(p):]];assert (x['bytes'],x['sha256'])==(y['bytes'],y['sha256'])
old=read('sources/armor-old').splitlines(keepends=True);cur=read('sources/armor-current').splitlines(keepends=True);d=b''.join(old[89:171]);c=js('source-comparison.json')
assert d==b''.join(cur[157:239]) and sha(d)==c['same_line_bytes_sha256'] and sha(read('sources/armor-old'))==c['full_file_sha256_historical']!=c['full_file_sha256_current']==sha(read('sources/armor-current'))
assert read('sources/screen-old')==read('sources/screen-current') and read('sources/anime-old')==read('sources/anime-current')
for n,src in [(2605,'screen-old'),(2606,'armor-old')]:assert registry['files'][n]['sha256']==rr[src]['sha256']
root=jgz('history/774/admission03-scope-reconciliation-044.json.gz');pins=root['input_pins'];rp=next(x for x in pins if x.get('supplier')=='rig' and x.get('rows')==13);qp=next(x for x in pins if x.get('supplier')=='rig' and x.get('kind')=='qualification')
registration=gzip.decompress(read('history/774/source-range-registration.jsonl.gz'));qualification=gzip.decompress(read('history/774/source-qualifications.jsonl.gz'))
assert sha(registration)== '24fb01a82c91de97fd9895740404dc79a73877fcd79a846c832c45cbf2495bdb'
assert sha(b''.join(registration.splitlines(keepends=True)[:13]))=='442704cfbcdb6f971a06981c68f1442451ccbd9eb7e039dfda32e5d639a772d9'!=rp['sha256']=='c75d93513422266bff64a096b243766fbd002d346f1d8c3c5b58f54af25ba06c'
assert sha(b''.join(qualification.splitlines(keepends=True)[:13]))==qp['sha256']=='70717aa1c0908935341afa5297937f1bf79513146453c1328076848d00e94e53'
completion=jgz('history/774/completion-112.json.gz');assert completion['pins'][4]['sha256']=='698ec787519f08585b75f3ce7f2fd08f0e8793f4f4837f91d88151c2c7783db1'!=sha(registration)
findings=[json.loads(x) for x in gzip.decompress(read('history/774/findings.jsonl.gz')).splitlines()];additional=[json.loads(x) for x in gzip.decompress(read('history/774/additional.jsonl.gz')).splitlines()]
assert findings[48]['id']=='RIG-ADMISSION03-F049'
for i,n in [(33,'048'),(34,'049'),(37,'052')]:assert additional[i]['id']=='RIG-ADMISSION03-ADDITIONAL-'+n
f=js('history/fragments-selected-reconstructed.json');i=jgz('history/fragments/EXTENDED-INDEX.json.gz');assert i['snapshot_sha256']==f['snapshot_sha256']
ids={'ADLER-L11-ICON-PNG-ERROR-OWNERSHIP','Q-L11-5804bd738c3307701b02','Q-L12-193e15950f2d17b11208'};assert f['index_hits']==[x for x in i['entries'] if x['contract_id'] in ids]
keys={x['normalized_sha256'] for x in f['index_hits']};allvals=[json.loads(x) for x in gzip.decompress(read('history/fragments/PRINTED-VALUES.jsonl.gz')).splitlines()];assert f['values']==[x for x in allvals if x['normalized_sha256'] in keys]
for x in f['values']:assert sha((json.dumps(x['value'],indent=2,ensure_ascii=False)+'\n').encode())==x['normalized_sha256']
r=js('history/p16-recovery.json');assert sha(read('history/p16-tracked.patch'))==r['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
pub=js('history/prior-screen-armor/published-comparison.json');assert sha(read(pub['archive']))==pub['archive_sha256']
ck=js('history/checkpoint17.json');entry=next(x for x in ck['bundles'] if x['bundle_id']=='screen-armor');assert entry['archive_sha256']==pub['archive_sha256'] and entry['scope_original_roles']==[2605,2606]
assert ck['working_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009'
with tarfile.open(b/pub['archive'],'r:gz') as t:
 for x in pub['comparison']:
  original=read('history/prior-screen-armor/'+x['member']);published=t.extractfile(x['member']).read()
  assert sha(original)==x['original_sha256'] and sha(published)==x['published_sha256'] and (original==published)==x['byte_identical']
print(json.dumps({'status':'passed','registered_read_entries':len(rr),'git_commits':len(gp['commits']),'git_objects':len(gp['objects']),'git_path_proofs':len(gp['paths']),'historical_records':len(a),'registry_roles':sorted(s['registry_roles']),'queue_indices':sorted(s['queue_entries']),'partial_printed_values':len(f['values']),'selected_published_member_comparisons':len(pub['comparison']),'product_or_macro_execution':'none; evidence verification only','writes':'none'},indent=2))
