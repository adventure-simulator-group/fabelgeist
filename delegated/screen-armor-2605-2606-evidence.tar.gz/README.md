# Bounded checkpoint 17 screen and armor reconciliation

This is a fresh, source-only reconciliation proposal by `/root/rig_identity` for
original registry roles 2605 and 2606. The pinned working source revision is
`95e63628f9d70b8dd6e6fede64334696c6995009`. The pr-working historical snapshot
had unrelated modifications: equality of an individual file to Git revision
`6533e444fa37552927070cc8d8190907fd3b413e` does not make that snapshot clean.
The old screen body is 1–50. The original armor role covers only 86–171; this
review independently displayed that old range and the current 1–239, leaving
old armor 1–85 unread. Related files are support and never receive role credit.
The role identities are retained even where evidence bytes match.

`REPORT.json` contains qualified findings, safeguards, source references,
open questions, historical relationships, and thirteen bounded perspectives.
`registration.json` and `supplement-registration.json` predate the respective
personal displays; the receipts list exact read windows and unread complements.
Archived full file bytes and integrity checks are not themselves personal reads.
The prior role, reviewer, revision, and status survive in `history/` separately
from these new assessments. `history/reconstructed-selections.json` and the
selected printed fragments are mechanically reconstructed records, not original
additional receipts or checkpoint 3821 status. Historical 774 rig's earlier
13-row registration pin does not match the later recovered prefix; that earlier
pin does not itself include or invalidate later rows 048/049. P16 was a dirty
snapshot based at `a120390947c89b703dc74c4255a13c035d054c50`, not that clean
commit. A later matching tracked patch is preserved; the original invocation,
interrupted custody, and metadata remain unresolved, and untracked files are not
included in the patch.

`git-proofs.json` and `git-objects/` preserve commit and tree object bytes for
per-file identity, historical source transport, and published checkpoint 17
metadata; transport commits do not become source revisions. Historical 059
records are checked against its preserved transport manifest, and selected
checkpoint 17 members are compared to the published archive. This comparison
does not imply all archive members are byte-identical; some published files are
reconstructed with path redactions. The original paths and peer authors may need
publication review by the central coordinator. `MANIFEST.json` binds this packet
but does not replace the older records' own checksums or qualifications.

Safe, read-only evidence verification from this directory:

```
python3 verify-evidence.py
python3 verify-manifest.py
```

Both print results only and do not invoke project code. The construction scripts
`register.py`, `freeze-history.py`, `build-proofs.py`, and `write-report.py`
write packet files and must not be rerun on the frozen packet. No repairs, builds,
tests, fixtures, macros, rendering, runtime probes, or product validation were
performed. Central review decides aliases, ledger counts, publication, and any
later work; this packet claims no whole-lens completion.
