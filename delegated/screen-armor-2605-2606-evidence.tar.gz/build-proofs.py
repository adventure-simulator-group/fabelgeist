from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  d=g('cat-file',t,k);assert oid(t,d)==k;p='git-objects/'+k+'.'+t+'.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(d,mtime=0));objects[k]={'type':t,'sha256':sha(d),'bytes':len(d),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def ents(raw):
 out={};i=0
 while i<len(raw):
  end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1);out[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());i=end+21
 return out
def root(rev):
 if rev not in commits:
  d=save('commit',rev);commits[rev]={'root_tree':d.splitlines()[0].split()[1].decode(),'parents':[x.split()[1].decode() for x in d.splitlines() if x.startswith(b'parent ')]}
 return commits[rev]['root_tree']
def proof(rev,path,file,kind,raw_storage=False):
 d=(b/file).read_bytes();d=gzip.decompress(d) if file.endswith('.gz') and not raw_storage else d;cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=ents(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',d)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(d),'bytes':len(d),'git_blob':cur,'preserved_bytes':file,'preserved_encoding':'raw' if raw_storage else ('gzip' if file.endswith('.gz') else 'raw'),'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for file in ['registration.json','supplement-registration.json']:
 for x in json.loads((b/file).read_bytes())['entries']:
  proof(x['revision'],x['git_path'],x['archive'],'committed project file; historical dirty snapshot per-file equality only, actual windows in receipts')
  if x['id'] in ('screen-old','armor-old','anime-old'):proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],x['archive'],'original source object transported by f82, not source revision')
for x in json.loads((b/'history/attribution-and-copies.json').read_bytes())['records']:
 if x['kind']=='774-f82':proof(f82,x['transport_path'],x['copy'],'original 774 rig authored evidence transported by f82')
rev='c15289d7b23f6253e01fb02de79551a89ff10c47'
for path,file in [('DELEGATED-EVIDENCE-CHECKPOINT-17.json','history/checkpoint17.json'),('DELEGATED-CHECKPOINT-17-QUALIFICATION.json','history/checkpoint17-qualification.json')]:proof(rev,path,file,'checkpoint publication metadata at captured publication commit; no implication of central finding adoption')
for path,file in [('recovered/original-transport-manifest.json.gz','history/original-transport-manifest.json.gz'),('recovered/original-registry-source-archive/registry.json.gz','history/original-registry.json.gz'),('recovered/physical-p16-patch-recovery/tracked.patch','history/p16-tracked.patch')]:proof(rev,path,file,'checkpoint17 published compressed evidence or recovered tracked patch; transport and P16 custody limits apply',raw_storage=True)
(b/'git-proofs.json').write_text(json.dumps({'schema':'726-screen-armor-reconciliation-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Per-file object equality and historical transport only; pr-working snapshot had unrelated changes, P16 dirty state has separate recovery limits, and checkpoint metadata is not user-scope or 3821 body credit.'},indent=2)+'\n');print('paths',len(proofs),'objects',len(objects))
