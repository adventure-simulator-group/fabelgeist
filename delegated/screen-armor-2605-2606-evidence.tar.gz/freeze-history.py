from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,tarfile
b=Path(__file__).resolve().parent;prior=Path('<LOCAL_PATH_0>');base=Path('<LOCAL_PATH_1>');extract=Path('<LOCAL_PATH_2>');pub=Path('<LOCAL_PATH_3>');sha=lambda d:hashlib.sha256(d).hexdigest();gb=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();w=lambda p,d:(b/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def receipt(regfile,dst):
 reg=json.loads((b/regfile).read_bytes());reads=[]
 for e in reg['entries']:
  covered=set(i for a,z in e['prospective_display_ranges'] for i in range(a,z+1));unread=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covered:
    if start is None:start=i
   elif start is not None:unread.append([start,i-1]);start=None
  reads.append({'id':e['id'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_ranges':e['prospective_display_ranges'],'unread_complement':unread})
 w(dst,{'recorded_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','registration':regfile,'registration_sha256':sha((b/regfile).read_bytes()),'reads':reads,'qualification':'Exact registered windows displayed in bounded numbered chunks; archive contents and prior reviewer receipts do not transfer read credit.'})
receipt('registration.json','personal-read-receipt.json');receipt('supplement-registration.json','supplement-read-receipt.json')
(b/'history').mkdir(exist_ok=True)
for n in ['original-registry.json.gz','original-transport-manifest.json.gz','baseline-059-queue.json.gz','baseline-059-ledger.json.gz']:shutil.copyfile(base/n,b/'history'/n)
orig=json.load(gzip.open(b/'history/original-registry.json.gz','rt'));q=json.load(gzip.open(b/'history/baseline-059-queue.json.gz','rt'))['entries'];l=json.load(gzip.open(b/'history/baseline-059-ledger.json.gz','rt'));ids=[123,124,641,1791,2483,2689];w('history/reconstructed-selections.json',{'qualification':'Mechanically reconstructed from exact 059 registry, queue and ledger; not separately recovered original records or checkpoint3821 status. q123/q124 are distinct background, not separate new findings.','registry_sha256':sha(gzip.decompress((b/'history/original-registry.json.gz').read_bytes())),'registry_roles':{str(i):orig['files'][i] for i in [2605,2606,2609,2724,2725]},'queue_sha256':sha(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes())),'queue_entries':{str(i):q[i] for i in ids},'ledger_sha256':sha(gzip.decompress((b/'history/baseline-059-ledger.json.gz').read_bytes())),'ledger_rows':{'/segovb_continuation/conditional_connected_contracts/4':l['segovb_continuation']['conditional_connected_contracts'][4]}})
transport=json.load(gzip.open(b/'history/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in transport['entries']};hist=json.loads((prior/'historical-attribution.json').read_bytes());records=[]
for x in hist['records_059']:
 path=x['original_path'];d=(extract/path).read_bytes();m=idx[path];assert (len(d),sha(d),gb(d))==(m['bytes'],m['sha256'],m['git_blob']);dst='history/059/'+path;(b/dst).parent.mkdir(parents=True,exist_ok=True);(b/dst).write_bytes(d);records.append({'kind':'059','original_path':path,'copy':dst,'sha256':sha(d),'bytes':len(d),'git_blob':gb(d)})
old=Path('<LOCAL_PATH_4>');olda=json.loads((old/'history/attribution-and-copies.json').read_bytes())
for x in olda['records']:
 if x['kind']=='774-f82' and any(z in x['transport_path'] for z in ['source-range-registration.jsonl','source-qualifications.jsonl','admission03-scope-reconciliation-044.json','completion-112.json']):
  dst='history/774/'+Path(x['copy']).name;(b/dst).parent.mkdir(exist_ok=True);shutil.copyfile(old/x['copy'],b/dst);records.append({**x,'copy':dst})
for name,src,gitpath in [('findings','<LOCAL_PATH_0>/historical-774/rig-findings.jsonl.gz','handoff/774/adler-original/audit/continuation/rig/admission03/findings.jsonl'),('additional','<LOCAL_PATH_6>','handoff/774/adler-original/audit/continuation/rig/admission03/additional-contracts.jsonl')]:
 dst='history/774/'+name+'.jsonl.gz';shutil.copyfile(src,b/dst);d=gzip.decompress((b/dst).read_bytes());records.append({'kind':'774-f82','transport_revision':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','transport_path':gitpath,'copy':dst,'encoding':'gzip','sha256_uncompressed':sha(d),'bytes_uncompressed':len(d),'git_blob':gb(d)})
for name,root,files in [('screen-armor',prior,['REPORT.json','registration.json','support-registration.json','personal-read-receipt.json','historical-attribution.json','MANIFEST.json']),('armor-anime',Path('<LOCAL_PATH_7>'),['REPORT.json','read-receipt.json','MANIFEST.json']),('p16-armor',Path('<LOCAL_PATH_8>'),['REPORT.json','read-receipt.json','MANIFEST.json'])]:
 dst='history/prior-'+name;(b/dst).mkdir(exist_ok=True)
 for f in files:
  d=(root/f).read_bytes();(b/dst/f).write_bytes(d);records.append({'kind':'prior-assessment','author':'/root/rig_identity' if name=='screen-armor' else '/root/hair_ops','copy':dst+'/'+f,'sha256':sha(d),'bytes':len(d)})
a=pub/'delegated/screen-armor-evidence.tar.gz';shutil.copyfile(a,b/'history/prior-screen-armor/published-evidence.tar.gz');compare=[]
with tarfile.open(a,'r:gz') as t:
 for n in ['REPORT.json','registration.json','support-registration.json','personal-read-receipt.json','historical-attribution.json','MANIFEST.json']:
  d=t.extractfile(n).read();o=(prior/n).read_bytes();compare.append({'member':n,'original_sha256':sha(o),'published_sha256':sha(d),'byte_identical':o==d})
w('history/prior-screen-armor/published-comparison.json',{'archive':'history/prior-screen-armor/published-evidence.tar.gz','archive_sha256':sha(a.read_bytes()),'comparison':compare,'qualification':'Selected members only; this does not prove whole-archive equality or later checkpoint status.'})
for src,dst in [(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json',b/'history/p16-recovery.json'),(pub/'recovered/physical-p16-patch-recovery/tracked.patch',b/'history/p16-tracked.patch'),(pub/'DELEGATED-EVIDENCE-CHECKPOINT-17.json',b/'history/checkpoint17.json'),(pub/'DELEGATED-CHECKPOINT-17-QUALIFICATION.json',b/'history/checkpoint17-qualification.json')]:shutil.copyfile(src,dst)
fr=Path('<LOCAL_PATH_9>');shutil.copytree(fr,b/'history/fragments',dirs_exist_ok=True);index=json.load(gzip.open(b/'history/fragments/EXTENDED-INDEX.json.gz','rt'));wanted={q[i]['contract_id'] for i in [124,641,1791]};hits=[x for x in index['entries'] if x['contract_id'] in wanted];keys={x['normalized_sha256'] for x in hits};values=[json.loads(x) for x in gzip.decompress((b/'history/fragments/PRINTED-VALUES.jsonl.gz').read_bytes()).splitlines()];w('history/fragments-selected-reconstructed.json',{'snapshot_sha256':index['snapshot_sha256'],'index_hits':hits,'values':[x for x in values if x['normalized_sha256'] in keys],'qualification':'Selected normalized printed projections, not original ledger/queue bytes, complete current state or checkpoint3821; source command/custody can remain unknown.'})
a=(b/'sources/armor-old').read_bytes().splitlines(keepends=True)[89:171];c=(b/'sources/armor-current').read_bytes().splitlines(keepends=True)[157:239];assert a==c;w('source-comparison.json',{'armor_historical_lines':[90,171],'armor_current_lines':[158,239],'same_line_bytes_sha256':sha(b''.join(a)),'full_file_sha256_historical':sha((b/'sources/armor-old').read_bytes()),'full_file_sha256_current':sha((b/'sources/armor-current').read_bytes()),'qualification':'Per-file and exact line comparison, not whole-tree equality or historical read transfer.'})
w('history/attribution-and-copies.json',{'records':records,'qualification':'059 extraction copies matched original manifest; 774 original authors transported through f82, not source Git revision. Peer source read scopes and original 774 pin mismatch remain separately preserved.'});print('historical records',len(records),'normalized hits',len(hits))
