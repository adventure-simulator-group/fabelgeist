import gzip,hashlib,json,pathlib,shutil
p=pathlib.Path('<LOCAL_PATH_0>')
orig=pathlib.Path('<LOCAL_PATH_1>')
prior=pathlib.Path('<LOCAL_PATH_2>')
refs=p/'reference';refs.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
for n in ['059-queue-original-bytes.json.gz','original-transport-manifest.json.gz','original-registry.json.gz']:shutil.copyfile(prior/'reference'/n,refs/n)
for n in ['AGENTS.md','crates/AGENTS.md','crates/strategic-web/AGENTS.md']:
 d=refs/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(prior/'reference'/n,d)
shutil.copyfile(prior/'rules-evidence.json',p/'rules-evidence.json')
t={x['path']:x for x in json.load(gzip.open(refs/'original-transport-manifest.json.gz','rt'))['entries']}
names=['segovb/READ-L11-406.json','segovb/READ-L11-407.json','segovb/REGISTRATION-SEGOVB-1347.json','segovb/REGISTRATION-SEGOVB-1348.json','segovb/READ-L12-827.json','segovb/READ-L12-828.json','parallel-l12-20261029/PROPOSAL-L12-827.json','parallel-l12-20261029/PROPOSAL-L12-828.json','parallel-l12-20261029/REGISTRATION-PAR-L12-461.json','parallel-l12-20261029/REGISTRATION-PAR-L12-462.json','parallel-l12-20261029/READ-PARTIAL-PAR-L12-827-ORIGINAL2452-001.json']
rows=[];missing=[]
for n in names:
 if n not in t or not (orig/n).is_file():missing.append(n);continue
 b=(orig/n).read_bytes();e=t[n];assert (len(b),h(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']),n
 d=p/'historical-059'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 rows.append({'original_path':n,'copy':str(d.relative_to(p)),'bytes':len(b),'sha256':h(b),'git_blob':blob(b)})
q=json.load(gzip.open(refs/'059-queue-original-bytes.json.gz','rt'));inds=[562,565,1216,1231,1236]
(p/'historical-queue-selected.json').write_text(json.dumps({'qualification':'Reconstructed navigation subset only; exact 059 original retained separately. Original statuses/authors unchanged; no checkpoint3821 or body credit.','entries':[{'index':i,'entry':q['entries'][i]} for i in inds]},indent=2)+'\n')
r=json.load(gzip.open(refs/'original-registry.json.gz','rt'));(p/'historical-registry-selected.json').write_text(json.dumps({'qualification':'Derived navigation subset, original producer receipts and ranges unchanged; Windows path retained.','roles':[{'index':i,'entry':r['files'][i]} for i in [2452,2453]]},indent=2)+'\n')
(p/'historical-059-index.json').write_text(json.dumps({'records':rows,'unavailable':missing,'qualification':'Exact read-only extraction copies checked against original transport; preserve old author and revision, no checkpoint3821 promotion.'},indent=2)+'\n')
old=pathlib.Path('<LOCAL_PATH_3>');ori=old/'semantic-goal/pr774-plan-execution-20261020';exp=old/'774-publication-branch/handoff/774/adler-original/audit';shutil.copyfile(exp/'EXPORT-MANIFEST.json',p/'older-774-export-manifest.json');m=json.loads((p/'older-774-export-manifest.json').read_text());lookup={x['file']:x for x in m['files']};paths=['final-acceptance-20261021/wave-01/audit-existing-type-owners/native/coverage.jsonl', 'final-acceptance-20261021/wave-01/producer-supplement-after-owner/native/traces.jsonl'];oldrows=[]
for r in paths:
 e=lookup['records/'+r];a=(ori/r).read_bytes();b=(exp/'records'/r).read_bytes();ha=h(a);hb=h(b);assert (ha,hb)==(e['original_record_sha256'],e['published_export_sha256'])
 for kind,content in [('original',a),('normalized-export',b)]:
  d=p/'older-774'/kind/r;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(content)
 oldrows.append({'path':r,'original_sha256':ha,'normalized_export_sha256':hb,'distinct':ha!=hb,'original_copy':'older-774/original/'+r,'normalized_copy':'older-774/normalized-export/'+r})
(p/'older-774-index.json').write_text(json.dumps({'records':oldrows,'qualification':'Exact older local original and separate path-normalized export checked against export manifest; neither transport nor reviewer implies later source revision or ownership transfer.'},indent=2)+'\n')
print('059 records',len(rows),'unavailable',missing,'774 pairs',len(oldrows))
