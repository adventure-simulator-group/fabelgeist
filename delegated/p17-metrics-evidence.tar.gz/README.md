# Roles 2452–2453: P17 metric and clearance source audit

This is a delegated evidence packet for central reconciliation. It preserves
separately recovered 059 originals, reconstructed navigation selections,
older 774 evidence, prior agent packets, and new source-level assessment.
It does not establish or reconstruct checkpoint 3821.

P17 is the clean recorded snapshot at commit
`90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696`; pinned current is
`95e63628f9d70b8dd6e6fede64334696c6995009`. Raw Git commit and tree proofs,
including current clearance.rs nonmembership, are in `git-proofs.json` and
`git-absence-proofs.json`. Exact source blobs and independently compared P17
snapshot copies are included. Git proof and whole-source byte preservation
never imply body-read credit.

See `read-receipt.json` for exactly displayed source ranges. This agent read
P17 metrics 1–409 and current metrics 1–1283, and all 182 lines of P17
clearance. Test-only source sections P17 410–1184 and current 1284–2050
remain unread by this agent despite prospective registration and complete
archival bytes. Support ranges are separate in `support-read-receipt.json`.
No test source was executed.

`report.json` records bounded thirteen-lens perspectives, old and current
source references, conditions and open questions. Current missing-terrain zero
is an independent corroboration of `/root/hair_ops`'s earlier conditional
observation; the prior capture nonfinite-admission observation is related but
not automatically the same contract. Existing canonical F065 was identified
and attributed from older 774 records. Full packets for those prior agents are
in `prior-packets/` with their manifest and range qualifications.

`historical-059/` contains exact original bytes verified against the extracted
transport manifest. The queue and registry selection files are derived
navigation only; their complete original compressed inputs are in `reference/`.
`older-774/` keeps old original and path-normalized exports distinct;
`older-continuation/` preserves historical summary and finding bytes. All
records retain their original reviewer and revision.

`check-evidence.py` verifies hashes, Git membership/nonmembership, actual-read
bounds, older source copies, original transport and prior packet archives. Its
result is evidence verification only. No product execution, repair, build,
test, viewer, browser, fixture, simulation, shader or runtime probe occurred.
