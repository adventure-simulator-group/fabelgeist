'''Prospective bounded current-source support registration only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/fabelgeist-hair/src/rng.rs',[[1,55],[110,135]]),('crates/fabelgeist-hair/src/hairdo.rs',[[175,230]]),('crates/fabelgeist-hair/src/ops/interpolate.rs',[[240,325]]),('crates/fabelgeist-hair/src/ops/mod.rs',[[215,260]]),('crates/fabelgeist-hair/src/export/ply.rs',[[170,245]]),('crates/fabelgeist-bvh/src/cpu/mod.rs',[[40,100],[380,415]])];a=[]
for i,(path,ranges) in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);ranges=[[x,min(y,eof)] for x,y in ranges if x<=eof];a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Current bounded support only, no historical or ordered-role credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest());print([(x['path'],x['eof'],x['prospective_ranges']) for x in a])
