import pathlib,json,sys,hashlib,datetime
p=pathlib.Path(__file__).resolve().parent;name=sys.argv[1];lo=int(sys.argv[2]);hi=int(sys.argv[3]);planname=sys.argv[4];plan=json.loads((p/planname).read_text());xs=[x for x in plan['items'] if x['file']==name and [lo,hi] in x['display_ranges']]
if len(xs)!=1:raise ValueError('unregistered view')
b=(p/name).read_bytes()
if hashlib.sha256(b).hexdigest()!=xs[0]['sha256']:raise ValueError('source identity')
lines=b.decode().splitlines()
if not 1<=lo<=hi<=len(lines):raise ValueError('range')
v=''.join(f'{i:5}\t{lines[i-1]}\n' for i in range(lo,hi+1));out='VIEW-'+name+'-'+str(lo)+'-'+str(hi)+'.txt'
with (p/out).open('x') as f:f.write(v)
r={'registration':planname,'source':name,'range':[lo,hi],'view':out,'sha256':hashlib.sha256(v.encode()).hexdigest(),'displayed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'truncated':False}
with (p/(out+'.receipt.json')).open('x') as f:json.dump(r,f,indent=2)
print('SOURCE',xs[0]['revision'],xs[0]['path'],lo,hi);print(v,end='')
