import datetime,gzip,hashlib,json,pathlib,subprocess,traceback
P=pathlib.Path(__file__).resolve().parent;reg=json.loads((P/'REGISTRATION-002.json').read_text());root=pathlib.Path(reg['current_checkout'])
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def put(path,b):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as f:f.write(b)
def jw(path,x):put(path,(json.dumps(x,indent=2,sort_keys=True)+'\n').encode())
def parse(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
try:
 obj=pathlib.Path(reg['recovered_source']['path']).read_bytes();assert sha(obj)==reg['recovered_source']['expected_sha256'];put(P/'evidence/recovered-6533-ordered_sigils.rs',obj)
 inventory=pathlib.Path(reg['inventory']).read_bytes();lines=inventory.decode().splitlines();candidates={};inventory_rows={}
 for path in reg['candidates']:
  b=(root/path).read_bytes();put(P/'evidence/current'/path,b);candidates[path]=b;hits=[l for l in lines if l.endswith('\t'+path)];inventory_rows[path]=hits
  if hits:assert len(hits)==1 and oid('blob',b)==hits[0].split()[2]
 trees={};routes={};fails=[];paths=[]
 def gettree(cur):
  if cur in trees:return trees[cur]
  for loc in reg['tree_sources']:
   folder=pathlib.Path(loc)
   for suffix in ('.tree','.tree.gz'):
    candidate=folder/(cur+suffix)
    if candidate.is_file():
     data=candidate.read_bytes();b=gzip.decompress(data) if suffix.endswith('.gz') else data;assert oid('tree',b)==cur;routes[cur]='prior-proof-tree';break
   else:continue
   break
  else:
   p=subprocess.run(['git','-C',str(root),'cat-file','tree',cur],capture_output=True)
   if p.returncode:fails.append({'tree':cur,'exit':p.returncode,'stderr':p.stderr.decode(errors='replace')});raise FileNotFoundError(cur)
   b=p.stdout;assert oid('tree',b)==cur;routes[cur]='git-cat-file-tree'
  trees[cur]=b;put(P/'evidence/proof/trees'/(cur+'.tree'),b);return b
 for rev,anchor in reg['commits'].items():
  b=pathlib.Path(anchor).read_bytes();assert oid('commit',b)==rev;root_oid=b.split(b'\n',1)[0].split()[1].decode()
  for path in reg['candidates']:
   if path.endswith('AGENTS.md') and rev!='95e63628f9d70b8dd6e6fede64334696c6995009':continue
   cur=root_oid;chain=[]
   try:
    for comp in path.split('/'):
     mode,nxt=parse(gettree(cur))[comp];chain.append({'tree':cur,'component':comp,'mode':mode,'oid':nxt});cur=nxt
    item={'revision':rev,'path':path,'chain':chain,'blob':cur,'current_candidate_blob':oid('blob',candidates[path]),'current_candidate_sha256':sha(candidates[path]),'current_candidate_matches':oid('blob',candidates[path])==cur,'historical_recovered_blob':oid('blob',obj) if path.endswith('ordered_sigils.rs') else None,'historical_recovered_matches':oid('blob',obj)==cur if path.endswith('ordered_sigils.rs') else None};paths.append(item)
   except Exception as e:paths.append({'revision':rev,'path':path,'chain':chain,'error':repr(e)})
 report={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recovered_source':{'sha256':sha(obj),'bytes':len(obj),'lines':len(obj.decode().splitlines()),'git_blob':oid('blob',obj)},'current_candidates':{p:{'sha256':sha(b),'bytes':len(b),'lines':len(b.decode().splitlines()),'git_blob':oid('blob',b),'inventory_rows':inventory_rows[p]} for p,b in candidates.items()},'inventory_sha256':sha(inventory),'paths':paths,'tree_routes':routes,'fallback_failures':fails,'qualification':'Recovered prior source object and recorded history remain attributed to original revision and Lens3; current source qualifies as 95e only where commit tree proof matches. Per-file equality is not tree equivalence.'}
 jw(P/'PROOF-RESULT.json',report);print(json.dumps(report,indent=2))
except Exception as e:jw(P/'PROOF-ERROR.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
