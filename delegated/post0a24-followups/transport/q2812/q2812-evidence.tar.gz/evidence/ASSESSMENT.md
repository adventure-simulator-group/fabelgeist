# q2812: independent Lens 12 string-owner assessment

## Scope and evidence roles

This is a new source-only review by `<PRIVATE-PATH-0001>` of 059 entry 2812,
`OBLIGATION-ROOT-L3-EXT-0009-LENS-12`, against product revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The registered historical scope
is `crates/adventuresim-puzzles/src/ordered_sigils.rs:1-392`. The protected
6533 source object was recovered and verified by SHA-256; separately checked
commit/tree/blob chains show the same individual blob in 6533, e275 and 95e.
The current identical body received a new prospective, complete, untruncated
personal Lens 12 display. This proves individual-file identity, not tree
identity; it does not transfer Root's Lens 3 credit to this reader or lens.
Original and reconstructed 059 queue files have different whole-file hashes;
the exact q2812 and selected related q2697, q2698, q2699 and q2708 entries are
byte-identical across them. None is checkpoint 3821. Missing 3821 and the
historical 73 nontext/no-positive-EOF recovery qualification remain intact.

The historical Root record is a Lens 3 body read at 6533 and a qualified
e275 same-file reuse, not a new e275 personal read. The prior c100 Lens 1
assessment is separately preserved in `RELATED2-ASSESSMENT-0.json`; its
selected assessment does not identify a personal author. q2708 is a new Lens 4
assessment by `<PRIVATE-PATH-0002>` at 95e, sealed after the 15A selection and
not credited there. Their results are relationships, not transferred credit.
The displayed support windows and unreviewed complements are recorded in
`DEPENDENCY-DISPLAY-REGISTRATION.json` and `READ-LIMITS.json`.

## String inventory and owned boundaries

The registered, full-body literal/signature navigation finds the following:

* `OrderedSigilSpec::validate` at 36-42 returns two `&'static str` reasons for
  disabled clue families and invalid clue maximum. `generate_versioned`,
  `generate_with_spec`, puzzle `validate`, public `minimum_clues`, and private
  subset search at 118-125, 156-181, 234-246, 285-306 propagate further static
  reasons for unsupported version, invalid spec or solution, invalid clue
  coordinates, failure to prove a solution, solution absent from permutation
  space, inability to meet a clue bound, and exceeding the subset limit. The
  unsupported-version text appears at two sites. These are descriptive domain
  failures crossing public library APIs rather than demonstrated stable error
  identifiers. `PuzzleAuthority::{generate_request,validate,replay}` forwards
  the `&'static str` (`puzzles.rs:170-188,249-277`); selected puzzle-lab paths
  append seed context or convert errors to owned presentation text
  (`puzzle-lab.rs:322-346`). The selected backend discards validation detail via
  `.ok()?` (`strategic/challenges.rs:394-408`). This is a connected typed-error
  ownership opportunity under the focused skill and `crates/AGENTS.md:21-86`;
  no selected caller is shown comparing or branching on the reason text.
  The existing typed `SubmissionError` and `PuzzleSubmissionError` describe
  different submission contracts and do not automatically own these reasons.
* `OrderedSigilClue::text` at 56-80 formats four human-facing sentences for
  Exact, Before, Adjacent, and NotAt. It receives typed `Sigil`, whose
  `label()` owns the visible names and whose `stable_id()` owns separate
  submission keys (`choices/sigil.rs:7-40`). The selected puzzle-lab render
  maps clues to strings (`puzzle-lab.rs:357-373`); its replay branch validates
  decoded authority before projecting and rendering (338-346). Human prose is
  a terminal presentation boundary, not established string classification.
* `"puzzle.ordered_sigil"` at 128 is passed into typed `StreamId::new`;
  `seed.rs:5-13,23-46` shows the purpose bytes are length-framed into the
  deterministic seed. This is an owned, replay-significant purpose name, not
  generic diagnostic prose. Any later change must preserve deterministic
  identity unless an explicit product decision authorizes otherwise.
* The generator's `expect("current ordered-sigil rules are supported")`
  at 114-115 is a panic diagnostic for the chosen default-spec assumption.
  The `#[expect(..., reason = ...)]` literal at 288-291 is a compiler/lint
  justification, not a game identity or user-facing error classification.
  No path, fixture or wire string is present in the 392-line target body.

## Connected position and helper contracts

`OrderedSigilClue` is public and derives deserialization; Exact and NotAt own a
public `u8` position (`ordered_sigils.rs:6-12`). Formatting adds one at 60, 75:
a directly constructed or deserialized value 255 reaches arithmetic overflow;
with overflow checks enabled the operation traps, while disabled checks wrap.
This is a symbolic source-level case, not an observed incident. It is distinct
from `fey_clue_text` (`errantry.rs:270-289,294-369`), where position 5 indexes
outside a five-entry row. q2697 recorded the latter conditional admission
question; q2708 independently corroborated it and attributed both operations
to the c100 Lens 1 assessment. The predecessor ledger's selected
`REVIEW-ORDERED-SIGIL-POSITIONS-001` row retains partial discovery and no repair
or validation. No additional defect count or alias decision is made here.

The inspected clue generator enumerates positions 0..5 and validates the
completed puzzle (`ordered_sigils.rs:125-181,193-225`). The selected backend
then decodes authority, validates and serializes a projection
(`strategic/challenges.rs:394-408`); selected web route decodes that projection
and the template calls the fey lookup (`routes/challenges.rs:72-103`,
`templates/challenge.rs:100-105`). This narrows the selected normal path; it
does not prove all alternate direct or serialized producers safe, nor establish
a reachable malformed user request. Exact ownership of public clue/projection
admission remains open.

q2698 separately records `minimum_clues`' raw unvalidated-spec precondition:
an empty pool can reach `masks[index]` before a descriptive returned reason
(`ordered_sigils.rs:234-241,261-274,324-330`). q2699 separately records
`clue_holds`' permutation assumption and `unwrap` (372-381). Those first
operations, the position cases, and the static-reason API must remain connected
without presuming they are aliases or one repair. The validated generator and
`solutions` paths narrow the selected normal uses; neither proves the policy
for all public callers.

## Remaining decisions and later acceptance

Choose the supported admission boundary for direct/deserialized clues and
projections; determine alternate producers and consumers; decide whether public
minimum search and predicate helpers require checked inputs or expose typed
failure; trace all remaining reason consumers and wire/diagnostic expectations.
For any later, separately authorized repair, retain valid positions 0 and 4,
zero-based stored coordinates and one-based prose, separate fey wording,
submission vocabulary and deterministic stream purpose. A meaningful later
acceptance should cover 5 and 255 through supported direct and deserialized
paths, invalid specifications and candidates, normal validated generation,
exact error categories and all established boundaries. No repair or product
validation is authorized or performed here.

## Qualifications

Evidence restoration, Git object inspection and evidence-only verification are
not product execution. No product build, test, parser, fixture, renderer, macro,
runtime probe or repair was performed. Physical-worktree searches are
navigation only; verified source displays use pinned objects. One combined
support output was truncated by 117 tokens; all 11 saved, registered windows
were redisplayed in separate bounded outputs and this history is retained.
The q2708 report and q2697 view were registered before display but matched to
q2708's manifest only afterwards. Related 059 q2698/q2699 selected fields
were displayed after original-anchor verification and before comparing the
reconstructed entry; both comparisons subsequently passed. The 31e search was
restricted to named ledger sections and terms; absence of a name there is not
a global absence proof. There is no whole-lens, all-queue, implementation or
runtime completion claim.
