#!/usr/bin/env python3
"""Verify q2812 evidence identities and displays, never product behavior."""
import argparse,datetime,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(n):return json.loads((P/n).read_text())
def objects(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def instant(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for n in ('commit-6533','commit-e275','commit-95e','original-queue','reconstructed-queue','current-inventory','ledger-31e'):ap.add_argument('--'+n,type=Path,required=True)
 a=ap.parse_args();m=load('MANIFEST.json');actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and str(x.relative_to(P))!='MANIFEST.json'};assert actual==set(m['files'])
 for n,x in m['files'].items():
  b=(P/n).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],n
 queues=[a.original_queue.read_bytes(),a.reconstructed_queue.read_bytes()];q=load('QUEUE-EXTRACTION.json');assert q['zero_based_array_index']==2812 and q['exact_byte_equal'];parts=[]
 for i,b in enumerate(queues):
  z=q['records'][i];assert sha(b)==z['queue_sha256'];part=b[z['start']:z['end']];assert len(part)==z['bytes'] and sha(part)==z['entry_sha256'] and part==(P/f'QUEUE-ENTRY-{i}.json').read_bytes() and json.loads(part)==json.loads(b)['entries'][2812];parts.append(part)
 assert parts[0]==parts[1];entry=json.loads(parts[0]);assert entry['lens']==12 and entry['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,392]]
 for filename,prefix in [('RELATED-QUEUE-EXTRACTION.json','RELATED-QUEUE'),('RELATED5-RECEIPT.json','RELATED5-QUEUE')]:
  for x in load(filename)['results' if prefix=='RELATED-QUEUE' else 'records']:
   b=queues[x['queue']];lo,hi=x['offsets'] if 'offsets' in x else (x['start'],x['end']);part=b[lo:hi];assert sha(part)==x['sha256'] and len(part)==x['bytes'] and part==(P/f'{prefix}-{x["index"]}-{x["queue"]}.json').read_bytes() and json.loads(part)==json.loads(b)['entries'][x['index']]
 for n in (2697,2698,2699,2708):
  pref='RELATED-QUEUE' if n in (2697,2708) else 'RELATED5-QUEUE';assert (P/f'{pref}-{n}-0.json').read_bytes()==(P/f'{pref}-{n}-1.json').read_bytes()
 for x in load('HISTORY-SELECTED.json'):
  b=(P/'history'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert json.loads(b)['rows'][int(x['pointer'].split('/')[-1])]==x['row']
 commits={};ids={x['revision']:x for x in load('COMMIT-ANCHOR-IDENTITIES.json')}
 for rev,path in [('6533e444fa37552927070cc8d8190907fd3b413e',a.commit_6533),('e2755a732c84e67296b5e3441a4259a84f461b2f',a.commit_e275),('95e63628f9d70b8dd6e6fede64334696c6995009',a.commit_95e)]:
  b=path.read_bytes();assert oid('commit',b)==rev and len(b)==ids[rev]['bytes'] and sha(b)==ids[rev]['sha256'];commits[rev]=b.split(b'\n',1)[0].split()[1].decode()
 inventory=a.current_inventory.read_bytes();lines=inventory.decode().splitlines();proof=load('PROOF-RESULT.json');assert sha(inventory)==proof['inventory_sha256']
 def chain(x,root):
  cur=commits[x['revision']];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
  for part,item in zip(parts,x['chain']):
   b=(P/root/(cur+'.tree')).read_bytes();assert oid('tree',b)==cur;mode,nxt=objects(b)[part];assert item=={'tree':cur,'component':part,'mode':mode,'oid':nxt};cur=nxt
  assert cur==x['blob'];return cur
 old=(P/'evidence/recovered-6533-ordered_sigils.rs').read_bytes();assert sha(old)==entry['exact_source_identities_and_assessed_ranges'][0]['source_sha256']==proof['recovered_source']['sha256'] and len(old.decode().splitlines())==392
 assert len(proof['paths'])==4 and not proof['fallback_failures']
 for x in proof['paths']:
  cur=chain(x,'evidence/proof/trees');b=(P/'evidence/current'/x['path']).read_bytes();assert sha(b)==x['current_candidate_sha256'] and (oid('blob',b)==cur)==x['current_candidate_matches']
  if x['path'].endswith('ordered_sigils.rs'):assert oid('blob',old)==cur and b==old
 for x in proof['current_candidates'].values():
  for row in x['inventory_rows']:assert row in lines
 dep=load('DEPENDENCY-PROOF.json');assert sha(inventory)==dep['inventory_sha256'] and not dep['fallback_failures'] and len(dep['paths'])==8
 for x in dep['paths']:
  assert chain(x,'evidence/dependencies/trees')==x['blob'];b=(P/'evidence/dependencies/sources'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and oid('blob',b)==x['blob'] and x['inventory_row'] in lines
 reg=load('REGISTRATION-003.json');displays=load('DISPLAY-RECEIPTS.json')['displays'];assert len(displays)==3
 for x,w in zip(displays,reg['windows']):
  assert x['source']==w['source'] and x['revision']==w['revision'] and x['range']==w['range'] and instant(x['at_utc'])>=instant(reg['at_utc']);b=(P/x['source']).read_bytes();ls=b.decode().splitlines();lo,hi=x['range'];d=(f'SOURCE {x["source"]} REVISION {x["revision"]}:{lo}-{hi}\n'+''.join(f'{i:4} {ls[i-1]}\n' for i in range(lo,hi+1))).encode();assert sha(b)==x['source_sha256'] and len(ls)==x['eof'] and d==(P/x['display']).read_bytes() and sha(d)==x['display_sha256']
 reg=load('DEPENDENCY-DISPLAY-REGISTRATION.json');rs=load('DEPENDENCY-DISPLAY-RECEIPTS.json');assert len(rs)==len(reg['windows'])==11
 for x,w in zip(rs,reg['windows']):
  assert all(x[k]==w[k] for k in ('name','file','first','last')) and instant(x['at_utc'])>=instant(reg['at_utc']);b=(P/x['file']).read_bytes();ls=b.decode().splitlines();d=''.join(f'{i}: {ls[i-1]}\n' for i in range(x['first'],x['last']+1)).encode();assert sha(b)==x['source_sha256'] and len(ls)==x['actual_source_lines'] and d==(P/x['output']).read_bytes() and sha(d)==x['output_sha256']
 pm=load('RELATED-private-PRIVATE-MANIFEST.json');rows={x['path']:x for x in pm['files']};copy=load('RELATED-COPY-RECORD.json');assert sha((P/'RELATED-private-PRIVATE-MANIFEST.json').read_bytes())==next(x['supplied_manifest_sha256'] for x in copy['copies'] if x['label']=='private')
 for prefix,files in [('RELATED-private-',['REPORT.json','HISTORIC-Q2697-CAPTURE.json','HISTORIC-Q2697-VIEW.json','Q2697-REVISIT.json','QUEUE-PROJECTION.json']),('RELATED2-',['PREDECESSOR-ROW.json','PREDECESSOR-ROW-RECEIPT.json','PREDECESSOR-CAPTURE.json','RELATED-ASSESSMENT-CAPTURE.json','ASSESSMENT-0.json','ASSESSMENT-1.json','ASSESSMENT-2.json'])]:
  for n in files:
   b=(P/(prefix+n)).read_bytes();assert len(b)==rows[n]['bytes'] and sha(b)==rows[n]['sha256']
 assert load('RELATED2-PREDECESSOR-ROW.json')['id']=='REVIEW-ORDERED-SIGIL-POSITIONS-001'
 assert load('RELATED-private-REPORT.json')['author']=='<PRIVATE-PATH-0002>'
 ledger=a.ledger_31e.read_bytes();nav=load('NAV-REGISTRATION.json')['ledger'];assert sha(ledger)==nav['sha256'];lr=json.loads(ledger)['newly_assessed_ledger']['entries'];hits=load('LEDGER-IDENTIFIER-HITS.json')
 for t in nav['terms']:
  expected=[{'index':i,'id':row.get('id',row.get('finding_id',row.get('record_id','<id field absent>')))} for i,row in enumerate(lr) if t.lower() in json.dumps(row,ensure_ascii=False).lower()];assert hits[t]==expected
 for name in ('NAV-RECEIPTS.json','NAV2-RECEIPTS.json'):
  for x in load(name)['results']:
   prefix='NAV-' if name=='NAV-RECEIPTS.json' else 'NAV2-'
   for ext in ('stdout','stderr'):
    b=(P/(prefix+x['name']+'.'+ext)).read_bytes();assert len(b)==x[ext+'_bytes'] and sha(b)==x[ext+'_sha256']
 print('Evidence verified: q2812 and four related exact queue pairs, selected historical receipts, three commit anchors, 12 path proofs, 14 registered target/support windows, selected q2708 manifest members and bounded 31e identifiers.')
 print('Evidence verification only: no product parser, fixture, build, test, renderer, macro, runtime probe or repair.')
if __name__=='__main__':main()
