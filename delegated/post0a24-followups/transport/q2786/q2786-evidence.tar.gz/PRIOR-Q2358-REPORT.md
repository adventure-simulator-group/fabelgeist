# q2357–q2358 bounded source reconciliation

At pinned 95e, the canonical mesh producer derives three attribute columns from
one vertex list. The packed decoder checks complete element widths but the
selected boundary does not check column or index coherence. Bevy 0.19.1 source
documents truncation to the shortest attribute if packed vertex data is formed.
A supported mismatched payload and any runtime effect remain unproved. The
prepared installation route traced here is gated to wasm; see REPORT.json for
its exact conditions and source references.

Regional surface state retains typed source, request, weather, elevation and
explicit Empty/Drawn coverage. Its source/request/weather/grass reuse key is
related to a separately attributed current conditional same-key content identity
question; the historical limited field classification does not close that
question or global audit scope.

The five selected historical files have identical per-file objects at 6533,
e275 and 95e. Root’s historical 6533 reads and e275 same-Lens2 adoption are
separate from this author’s registered current reads; the pr-working snapshot
as a whole is not asserted clean. Exact sources, selected historical records,
read ranges, truncation qualification, lock/checksum and Git tree evidence are
included. No checkpoint3821 promotion, aliases or unique counts are assigned.
No product execution, tests, builds, probes, repairs or publication edits occur.
