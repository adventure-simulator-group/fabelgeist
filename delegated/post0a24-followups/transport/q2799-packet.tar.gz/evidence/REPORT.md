# q2799: independent Lens 11 GPU identity granularity review

This is a fresh source-only type-granularity review by `/root/verifier_scope`
of `OBLIGATION-ROOT-L3-EXT-0008-LENS-11`. The coordinator owns obligation
adjudication, aliases, the connected repair ledger, counts and publication.
This packet does not close a whole lens or establish native behavior, runtime
success, implementation or product validation. No product code, build,
test, fixture, macro, shader, renderer or runtime probe was executed.

## Baseline, chronology and reader attribution

Original 059 `/entries/2799` at
`56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e` records
`own-lens-proof-qualification-or-read-pending`, zero foreign/body/population
credit and a false implementation gate. It requires Lens 11 qualification or
reading of all 50 lines of
`crates/adventuresim-tactical-client/src/tactical_scene_viewer/gpu_readiness.rs`
at frozen `6533e444fa37552927070cc8d8190907fd3b413e`, with an exact e275
`e2755a732c84e67296b5e3441a4259a84f461b2f` revisit. Pinned authoritative
`95e63628f9d70b8dd6e6fede64334696c6995009` (95e), e275 and frozen file bytes
are identical: SHA-256
`3fc7f599e45d69c79994c4044060d1cb7552f2d501830a6661d033a4fff9441e`,
Git blob `942902fabe916a0dad6e3e3b8554f5cd3bb5b929`, 1,496 bytes, EOF 50.
The eight captured first-party support files are also individually identical
at e275 and 95e; no whole-tree identity is claimed. The original and
reconstructed 059 queue streams differ, while this entry's exact slices match.

The root's earlier 6533 Lens 3 receipt specifically credits a fresh personal
read of lines 1–13 and a qualified inherited same-Lens 3 supplier for 14–50;
it does not claim a root personal tail reread. Its e275 registration is
same-Lens evidence reuse, not a new current personal read. All three referenced
supplier documents were specifically recovered from the protected extraction,
verified against their cited hashes, and the embedded receipt and queue
selections were matched to the source documents. The earlier Adler Lens 11
registration is hash-cited, and the separately recovered Adler batch-250
receipt states its own fresh 6533 full-file Lens 11 read (1–13 and 14–50).
The latter receipt is cited by name without a digest in the selected Lens 3
registration: its full-file digest was newly measured and a transport match
is not retrospective authentication. An exact string search of original 059
queue and ledger found the name in the ledger but not that measured digest;
this does not search all older evidence. Neither Lens 3 nor the earlier q2359
Lens 2 review transfers personal Lens 11 credit. The separately attributed
older Lens 11 proof is preserved for central qualification, while the present
review independently registered and displayed 95e lines 1–50. The original
059 pending status remains historical; there is no checkpoint-3821 promotion.

Nine selected historical records, including the three Lens 3 supplier documents,
match same-machine transport metadata 9/9. This is not independent custody,
proof of reading or complete transitive recovery. The prior q2359 Lens 2
report and its sealed manifest are also captured and checked, not treated as
this fresh Lens 11 assessment. `SOURCE-READ-RECEIPT-v2.json` supersedes but
preserves the earlier receipt after the garden follow-up: 17 registered
numbered displays cover 1,684 distinct lines across nine first-party and six
checksum-pinned Bevy source files, with 8,005 captured support lines unread.
Hashes and local timestamps support integrity and ordering, not comprehension.

## Type distinctions and actual consumers

- **Keep mesh and image identities distinct.** `gpu_readiness.rs:14–50` makes
  a scoped `GpuReadiness` resource around one shared
  `Arc<Mutex<ResidentAssets>>`. `ResidentAssets` keeps
  `HashSet<AssetId<Mesh>>` and `HashSet<AssetId<Image>>` separately. The
  observer replaces both sets under one lock from their respective render
  asset iterators; `contains` checks the supplied mesh ID and every supplied
  image ID under a lock. The shared resource type is meaningful as the Bevy
  resource and shared-snapshot owner, rather than an unneeded renaming of a
  bare number. The generic native IDs prevent, for example, supplying an
  image ID to the mesh set. The predicate needs membership and does not require
  image ordering or multiplicity, so a set and an image-ID iterator are
  adequate for that selected question; no extra first-party wrapper or
  untyped merged identifier is justified by the inspected path.

  The checked-in lock selects Bevy 0.19.1. Captured source extracted from
  checksum-matched local crate archives shows that `AssetId<A>` carries its
  asset type (`bevy_asset/src/id.rs:15–43`), `Handle<A>::id()` returns
  `AssetId<A>` (`handle.rs:189–199`), and `RenderAssets<A>` stores and yields
  `AssetId<A::SourceAsset>` (`bevy_render/src/render_asset.rs:204–233`).
  `RenderMesh::SourceAsset = Mesh` and `GpuImage::SourceAsset = Image`
  (`mesh/mod.rs:120–121`, `texture/gpu_image.rs:14–27`). These are exact
  locked source contracts, not a native execution. The captured original
  Bevy license notices are included; each package offers MIT or Apache-2.0.

- **Do not overstate what a native ID or the Boolean proves.** Pinned Bevy
  identifies `AssetId` as a runtime identifier not tied to asset lifetime.
  The selected application snapshot records IDs, not a content revision,
  source semantic validity, render pipeline outcome, completed frame or
  persistence receipt. A true `contains` is therefore the selected snapshot
  membership observation, not a universal readiness certificate. The mutex
  protects the two copied sets as one local snapshot; the exact timing of
  extraction, replacement, mutation and later consumption remains open.
  No stale snapshot, live failure or need for a new version type is established
  without a concrete required-freshness contract and reachable sequence.

- **Preserve native image identity at the residency port without flattening
  material semantics.** Building review obtains the standard material and
  supplies present base-color, normal and metallic-roughness image IDs
  (`building_review/readiness.rs:112–155`). Furniture review checks its
  selected material and ground extension IDs
  (`furniture_readiness.rs:73–105`); the ground iterator exposes soil,
  stone and traffic image handles (`vista/streets/material.rs:97–120,143–152`).
  The garden consumer supplies six leaf image IDs, and deliberately supplies
  an empty iterator for branch mesh membership
  (`building_review/gardens.rs:78–110`). Empty `all` is true, but the mesh
  ID must still be present. Image `AssetId<Image>` intentionally does not
  encode albedo versus normal roles: the selected operation asks only whether
  each named source asset is present, while its material fields own channel
  meaning. This observation does not prove role correctness, all texture slots
  or all capture profiles, and does not justify erasing the distinct
  mesh/image type parameters.

  The selected freshly prepared managed-hazel branch uses its cached bark
  material (`ground_scatter/gardens.rs:61–97`), initialized with a color and
  roughness plus `StandardMaterial::default()` (`specimens.rs:41–64`). The
  checksum-pinned Bevy PBR 0.19.1 default sets the displayed texture fields to
  `None` (`pbr_material.rs:851–923`). Consequently, an empty image list is
  consistent with that fresh constructor; no missing-texture defect follows
  merely from the empty list. Existing cache contents, later material edits,
  alternate source paths and all backend dependencies remain untraced.

- **Keep adjacent readiness/failure axes separate.** The selected viewer
  plugins install/share the resource and consume residency in larger review
  checks (`building_review/readiness.rs:14–29,133–155,252–285`;
  `furniture_readiness.rs:13–28,109–134`). A membership Boolean does not say
  whether an asset is still pending or has terminally failed. Existing 31e
  row 201 and original 059 texture-residency failure record concern a separate
  per-recipe terminal failure/cause, while row 197/q1214 concern a capture
  readiness timeout. Row 229 concerns a different city GPU preparation and
  resource-generation question; rows 211, 212 and 299 concern diagnostic or
  persistence outcomes. Earlier q2303 concerns an authored capture progression
  gate and is not the same first operation as this asset-ID snapshot. Preserve
  all reader, revision, disposition, policy and reachability qualifications;
  no automatic alias or unique count is claimed.

## Recovered evidence and remaining questions

Original and reconstructed 059 slices for q1214, q2303 and q2359 are exactly
byte-equal, although their whole streams differ. The three separately selected
059 historical ledger objects are structurally equal reserializations, not
original byte slices. Seven selected current rows come from the exact 31e
checkpoint `31e130bfa8f8914f759c7d5cddc3db92962704c7`, SHA-256
`b10132337fad5f1cf91fbd23c01a3ed4330793e79aac65ec4921aece591d1c50`;
those are also reserialized selections. The q2359 report's own Lens 2
conclusion preserves its narrower named scope, original and reconstructed
identities, prior readers and open current/native/alias questions; it is not
an independent Lens 11 read.

The full pinned `Cargo.lock` and selected full native source/notice files are
retained. They can be read from this packet without a registry cache. Optional
verification against separately held local `.crate` archives repeats the
locked archive checksums and extracts the captured files; archive access is a
replay dependency, not independent public custody. The initial lock identity
record was correctly metadata-only when created; a later prospectively
registered `LOCK-CAPTURE.dat` now preserves the whole lock without claiming a
full personal line read.

Open scope includes other support lines and consumers, original proof's
unrecovered transitive references, exact source/asset revision and lifetime
contracts, material/channel admission and edits, complete pipeline/device
readiness, native scheduler order, failure versus pending policy, timeouts,
artifact persistence and semantic aliases beyond selected ledgers. Preserve
native mesh/image distinction and shared resource ownership in any later
repair; only add a content-generation or readiness-stage distinction after
establishing the actual producer/consumer contract it must protect. These are
future audit/acceptance questions, not authorization to implement or validate.
`VERIFY-EVIDENCE.py` and the separate bounded privacy seal check evidence,
not semantic correctness or independently preserved custody.
