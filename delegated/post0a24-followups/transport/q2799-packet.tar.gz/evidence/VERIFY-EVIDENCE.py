#!/usr/bin/env python3
"""Verify q2799 bounded source evidence only; never execute product code."""
import argparse,datetime,gzip,hashlib,io,json,os,pathlib,subprocess,tarfile,tomllib
P=pathlib.Path(__file__).resolve().parent
REV='95e63628f9d70b8dd6e6fede64334696c6995009'
OLD='e2755a732c84e67296b5e3441a4259a84f461b2f'
FROZEN='6533e444fa37552927070cc8d8190907fd3b413e'
LEDGER='31e130bfa8f8914f759c7d5cddc3db92962704c7'
LEDGER_SHA='b10132337fad5f1cf91fbd23c01a3ed4330793e79aac65ec4921aece591d1c50'
def j(n):return json.loads((P/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def union(spans):
 out=[]
 for lo,hi in sorted(spans):
  if out and lo<=out[-1][1]+1:out[-1][1]=max(out[-1][1],hi)
  else:out.append([lo,hi])
 return out
def check_manifest():
 m=j('MANIFEST.json');items=list(P.iterdir());assert all(x.is_file() and not x.is_symlink() for x in items)
 assert {x.name for x in items if x.name!='MANIFEST.json'}==set(m['files'])
 for n,v in m['files'].items():
  assert pathlib.Path(n).name==n;b=(P/n).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']
def refs(v,out):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str) and len(v['sha256'])==64:out.add((v['path'],v['sha256']))
  for x in v.values():refs(x,out)
 elif isinstance(v,list):
  for x in v:refs(x,out)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--git-repo',type=pathlib.Path);ap.add_argument('--transport-manifest',type=pathlib.Path);ap.add_argument('--live-ledger',type=pathlib.Path);ap.add_argument('--registry-cache',type=pathlib.Path);a=ap.parse_args();check_manifest()
 assert sha((P/'FOCUSED-SKILL.md').read_bytes())=='3a1fbf7f53c752e35eefe7763cbd49b9f280bd4b978ea998f74c3a68e45dc106'
 first=[]
 for f in sorted(P.glob('SOURCE-CAPTURES*.json')):first.extend(json.loads(f.read_text()))
 native=[]
 for f in sorted(P.glob('NATIVE-CAPTURES*.json')):native.extend(json.loads(f.read_text()))
 assert len(first)==9 and len(native)==6 and len({x['path'] for x in first})==9;fc={x['capture']:x for x in first};nc={x['capture']:x for x in native}
 for x in first:
  b=(P/x['capture']).read_bytes();assert x['revision']==REV and sha(b)==x['sha256'] and blob(b)==x['blob'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof']
  if x['capture']=='SOURCE-000.dat':assert x['eof']==50 and x['all_three_same'] and set(x['versions'])=={REV,OLD,FROZEN} and all(z['sha256']==x['sha256'] and z['blob']==x['blob'] for z in x['versions'].values())
  else:assert x['e275_same_bytes'] and x['e275_sha256']==x['sha256']
 for x in native:
  b=(P/x['capture']).read_bytes();assert x['version']=='0.19.1' and sha(b)==x['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof']
 licenses=[]
 for f in sorted(P.glob('NATIVE-LICENSE-CAPTURES*.json')):licenses.extend(json.loads(f.read_text()))
 assert len(licenses)==6
 for x in licenses:
  b=(P/x['capture']).read_bytes();assert sha(b)==x['sha256'] and len(b)==x['bytes']
 lock=(P/'LOCK-CAPTURE.dat').read_bytes();li=j('LOCK-IDENTITY.json');assert sha(lock)==li['lock_sha256'] and blob(lock)==li['lock_blob'] and len(lock)==li['lock_bytes'];packages=tomllib.loads(lock.decode())['package'];plook={x['name']:x for x in packages if x['name'] in ('bevy','bevy_asset','bevy_render','bevy_mesh','bevy_image','bevy_pbr') and x['version']=='0.19.1'};assert len(plook)==6
 for x in li['packages']+[j('NATIVE-PBR-LOCATOR-RESULT.json')['package']]:assert all(plook[x['name']].get(k)==v for k,v in x.items())
 for x in native:assert plook[x['package']]['checksum']==x['archive_sha256']
 fregs={f.name:json.loads(f.read_text()) for f in P.glob('SOURCE*REGISTRATION.json')};nregs={n:j(n) for n in ('NATIVE-EXACT-REGISTRATION.json','NATIVE-PBR-EXACT-REGISTRATION.json')};receipt=j('SOURCE-READ-RECEIPT-v2.json');assert receipt['predecessor']=='SOURCE-READ-RECEIPT.json' and len(receipt['displays'])==17;spans={x['capture']:[] for x in first+native}
 for x in receipt['displays']:
  lo,hi=x['range'];c=(fc if x['kind']=='first_party' else nc)[x['capture']];r=(fregs if x['kind']=='first_party' else nregs)[x['registration']]
  assert r['registered_utc']==x['registration_time_utc'] and datetime.datetime.fromisoformat(x['registration_time_utc'])<=datetime.datetime.fromisoformat(x['display_file_mtime_utc'])
  if x['kind']=='first_party':assert r['revision']==REV and any(z['path']==x['path']==c['path'] and z['range']==x['registered_range'] and z['range'][0]<=lo<=hi<=z['range'][1] for z in r['sources'])
  else:assert any(z['package']==x['package']==c['package'] and z['member']==x['member']==c['member'] and z['range']==x['registered_range'] and z['range'][0]<=lo<=hi<=z['range'][1] for z in r['sources'])
  lines=(P/c['capture']).read_text().splitlines();assert 1<=lo<=hi<=len(lines);b=''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert b==(P/x['display']).read_bytes() and sha(b)==x['sha256'];spans[c['capture']].append((lo,hi))
 assert {x['capture'] for x in receipt['coverage']}==set(fc)|set(nc)
 for x in receipt['coverage']:
  c=(fc|nc)[x['capture']];merged=union(spans[x['capture']]);assert x['eof']==c['eof'] and x['personally_displayed_union']==merged and x['personal_displayed_lines']==sum(b-a+1 for a,b in merged) and x['unread_lines']==x['eof']-x['personal_displayed_lines']
 assert union(spans['SOURCE-000.dat'])==[[1,50]] and sum(x['personal_displayed_lines'] for x in receipt['coverage'])==1684 and sum(x['unread_lines'] for x in receipt['coverage'])==8005
 missing=[]
 for n,r in fregs.items():
  for z in r['sources']:
   lo,hi=z['range']
   if hi==1000000:continue
   c=next(x for x in first if x['path']==z['path']);present={i for a,b in spans[c['capture']] for i in range(a,b+1)};m=union([(i,i) for i in range(lo,hi+1) if i not in present])
   if m:missing.append({'registration':n,'capture':c['capture'],'registered_range':[lo,hi],'unread_subranges':m})
 for n,r in nregs.items():
  for z in r['sources']:
   c=next(x for x in native if x['package']==z['package'] and x['member']==z['member']);lo,hi=z['range'];present={i for a,b in spans[c['capture']] for i in range(a,b+1)};m=union([(i,i) for i in range(lo,hi+1) if i not in present])
   if m:missing.append({'registration':n,'capture':c['capture'],'registered_range':[lo,hi],'unread_subranges':m})
 assert not missing and receipt['precise_windows_with_unread_subranges']==missing
 ids=j('HISTORY-IDENTITIES.json');assert len(ids)==2
 for x in ids:
  b=(P/x['capture']).read_bytes();assert len(b)==x['entry_bytes'] and sha(b)==x['entry_sha256']
 b=(P/'Q2799-ORIGINAL-EXACT.json').read_bytes();assert b==(P/'Q2799-RECONSTRUCTED-EXACT.json').read_bytes();q=json.loads(b);direct=set();refs(q,direct)
 assert q['contract_id']=='OBLIGATION-ROOT-L3-EXT-0008-LENS-11' and q['lens']==11 and q['status']=='own-lens-proof-qualification-or-read-pending' and q['body_or_population_credit']==0 and not q['implementation_gate_complete']
 x=q['exact_source_identities_and_assessed_ranges'][0];assert x['revision']==FROZEN and x['source_sha256']==fc['SOURCE-000.dat']['sha256'] and x['actual_EOF']==50 and x['required_ranges']==[[1,50]] and x['assessed_ranges']==[] and x['foreign_body_credit']==0
 x=q['exact_current_revision_revisit_requirements'][0];assert x['target_revision']==OLD and x['required_ranges']==[[1,50]] and x['body_credit']==0 and x['own_lens_evidence_still_required']
 recovery=j('RECOVERY-RESULT.json');nested=j('NESTED-RESULT.json');supplier=j('SUPPLIER-RESULT.json');assert len(recovery)==len(nested)==len(supplier)==3 and direct=={(x['reference'],x['expected_sha256']) for x in recovery}
 for x in recovery+nested+supplier:
  b=(P/x['capture']).read_bytes();h=x.get('expected_sha256') or x.get('actual_sha256');assert sha(b)==h and len(b)==x['bytes']
 assert nested[1]['expected_sha256'] is None and j('TRANSPORT-RESULT.json')['matched']==j('TRANSPORT-RESULT.json')['total']==9
 old=j('HISTORICAL-001-FOCUS.json')['row'];assert old['fresh_personal_ranges']==[[1,13]] and old['qualified_inherited_same_lens_ranges']==[[14,50]]
 proof=json.loads((P/'NESTED-002.dat').read_bytes());assert j('SUPPLIER-001.dat')['receipts'][6]==proof['raw_prior_receipt_row'] and j('SUPPLIER-002.dat')['entries'][47]==proof['raw_queue_row']
 prior=j('PRIOR-Q2359-IDENTITIES.json');assert len(prior)==3 and sha((P/'PRIOR-Q2359-000.dat').read_bytes())=='f21f5d81aff391f58a115f8faae16d47136bb175a440b34f0354310b27db1a52';pm=json.loads((P/'PRIOR-Q2359-000.dat').read_bytes())
 for x in prior:
  b=(P/x['capture']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
  if x['selection']!='MANIFEST.json':assert pm['files'][x['selection']]['sha256']==x['sha256'] and pm['files'][x['selection']]['bytes']==x['bytes']
 related=j('RELATED-HISTORY-IDENTITIES.json');assert len(related)==6
 for x in related:assert sha((P/x['capture']).read_bytes())==x['sha256']
 for n in (1214,2303,2359):assert (P/f'RELATED-Q{n}-ORIGINAL.json').read_bytes()==(P/f'RELATED-Q{n}-RECONSTRUCTED.json').read_bytes()
 hist=j('HIST-LEDGER-IDENTITIES.json');assert len(hist)==6
 for i in range(3):assert j(f'HIST-LEDGER-{i:02}-ORIGINAL.json')==j(f'HIST-LEDGER-{i:02}-RECONSTRUCTED.json')
 indices={197:'REVIEW-CAPTURE-PREAPPLIED-READINESS-TIMEOUT-001',201:'ADLER-L11-TEXTURE-RESIDENCY-FAILURE-STATE',211:'REVIEW-DIAGNOSTIC-CAPTURE-UNSETTLED-001',212:'CONT08-CAPTURE-SAVE-OUTCOME-ERASURE',229:'ADLER-L11-CITY-GPU-PREPARATION-OUTCOME',255:'REVIEW-INTERIOR-EXPOSURE-GPU-RESIDENCY-001',299:'SEGOVB-L12-SCENE-CAPTURE-PERSISTENCE-OUTCOME'}
 for i,k in indices.items():assert j(f'LEDGER-{i}.json')['id']==k
 print('PASS manifest, skill, 9 pinned sources, 6 native sources/notices, 17 displays, historical qualification and related records.')
 def ledger_check(b):
  assert len(b)==1457605 and sha(b)==LEDGER_SHA;rows=json.loads(b)['newly_assessed_ledger']['entries'];assert len(rows)==1072
  for i in indices:assert rows[i]==j(f'LEDGER-{i}.json')
  r=j('EXACT-LEDGER-LOCATOR-REGISTRATION.json');expected=[]
  for t in r['terms']:
   hits=[{'index':i,'id':x.get('id')} for i,x in enumerate(rows) if t.lower() in json.dumps(x).lower()];expected.append({'term':t,'total':len(hits),'retained':hits,'omitted':0})
  assert expected==j('EXACT-LEDGER-LOCATOR-RESULT.json')
 if a.git_repo:
  env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
  def git(*args):return subprocess.check_output(['git','-C',str(a.git_repo),'--no-replace-objects',*args],env=env)
  for x in first:
   b=git('show',f'{REV}:{x["path"]}');ob=git('show',f'{OLD}:{x["path"]}');assert b==(P/x['capture']).read_bytes() and ob==b
   if x['capture']=='SOURCE-000.dat':assert git('show',f'{FROZEN}:{x["path"]}')==b
  assert git('show',f'{REV}:Cargo.lock')==lock
  streams={}
  for x in ids:
   key=(x['revision'],x['path']);b=git('show',f'{key[0]}:{key[1]}');streams[key]=b
   assert len(b)==x['stream_bytes'] and sha(b)==x['stream_sha256'] and blob(b)==x['git_blob'] and b[x['start']:x['end']]==(P/x['capture']).read_bytes() and json.loads(b)['entries'][2799]==q
  for x in related:
   b=streams[(x['revision'],'baseline-059/queue.json')];assert b[x['start']:x['end']]==(P/x['capture']).read_bytes() and json.loads(b)['entries'][int(x['selector'].split('/')[-1])]==j(x['capture'])
  histstreams={}
  for x in hist:
   if x['revision'] not in histstreams:histstreams[x['revision']]=git('show',f'{x["revision"]}:{x["path"]}')
   b=histstreams[x['revision']];assert len(b)==x['stream_bytes'] and sha(b)==x['stream_sha256'] and json.loads(b)['discovery_findings_and_dependencies'][x['key']]==j(x['capture'])
  ledger_check(git('show',f'{LEDGER}:BASELINE-95E-20261110.json'))
  for stem in ('LOCATOR','GARDEN-LOCATOR','BARK-LOCATOR'):
   reg=j(stem+'-REGISTRATION.json');stored=j(stem+'-RESULT.json')
   for x in stored:
    r=subprocess.run(['git','-C',str(a.git_repo),'--no-replace-objects','grep','-n','-F',x['pattern'],REV,'--',reg['scope']],env=env,capture_output=True,text=True);assert r.returncode in (0,1);lines=r.stdout.splitlines();assert lines==x['retained'] and len(lines)==x['total']
  print('PASS Git: pinned/e275 sources, frozen scope, lock, both 059 streams/ledger memberships, 31e ledger and recorded source locators.')
 else:print('NOT REPEATED: Git source and record membership (supply --git-repo).')
 if a.transport_manifest:
  d=json.load(gzip.open(a.transport_manifest,'rt'));assert d['transport_only'] and not d['source_read_credit']
  for x in recovery+nested+supplier:
   b=(P/x['capture']).read_bytes();h=x.get('expected_sha256') or x.get('actual_sha256');suffix=x['reference'].removeprefix('target/726-audit-adler-20261027/');assert any(e['path'].endswith(suffix) and e['sha256']==h and e['bytes']==len(b) for e in d['entries'])
  print('PASS nine same-machine transport matches; one receipt digest was newly measured and is not historically authenticated by the selected name-only citation.')
 else:print('NOT REPEATED: transport correspondence (supply --transport-manifest).')
 if a.live_ledger:ledger_check(a.live_ledger.read_bytes());print('PASS supplied exact 31e ledger and seven selected objects.')
 else:print('NOT REPEATED: supplied ledger anchor (supply --live-ledger).')
 if a.registry_cache:
  archives={}
  for name in ('bevy_asset','bevy_render','bevy_mesh','bevy_image','bevy_pbr'):
   paths=list(a.registry_cache.glob('*/'+name+'-0.19.1.crate'));assert len(paths)==1;b=paths[0].read_bytes();assert sha(b)==plook[name]['checksum'];archives[name]=b
  for x in native+licenses:
   with tarfile.open(fileobj=io.BytesIO(archives[x['package']]),mode='r:gz') as t:assert t.extractfile(x['member']).read()==(P/x['capture']).read_bytes()
  print('PASS five lock-checksummed registry archives and captured native source/license member bytes; archive custody is external.')
 else:print('NOT REPEATED: package archive membership (supply --registry-cache).')
 print('LIMITS: hashes, timestamps and source text do not prove comprehension, all consumers, temporal validity, policy, runtime behavior, global aliases or independent custody.')
if __name__=='__main__':main()
