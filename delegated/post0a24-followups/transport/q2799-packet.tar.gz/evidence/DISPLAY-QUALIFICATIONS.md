# Navigation and evidence qualifications

- The first-party and native capture files are not wholesale personal reads.
  `SOURCE-READ-RECEIPT-v2.json` records actual independent displays and
  supersedes the earlier `SOURCE-READ-RECEIPT.json` after adding three
  first-party garden/bark files and one Bevy PBR file. All exact planned
  windows were displayed; 8,005 other captured support lines remain unread.
  The full lock is captured for recovery but has only selected metadata read.
- One unregistered `rg --files` navigation of publication paths for q2359 was
  truncated (123 matching lines, tool output truncated). It was not used as a
  source display or as evidence of completeness: the related earlier packet
  was subsequently selected by its existing exact sealed manifest hash, with
  separate registration and captures. The 31e metadata locator retained all
  116 rows but displayed only the first 100; its 16 omitted displays remain
  explicitly unreviewed. A later exact-string locator is bounded to 31e and
  cannot exclude indirect aliases. The garden `TreeBranch` locator retained 73
  snippets and displayed 40; 33 were not displayed. Other matched source
  locators have recorded totals and omissions, and include literal false
  positives such as an unrelated `gpu.contains` on a string.
- The q2799/q1214/q2303/q2359 queue records are exact byte slices, with whole
  original and reconstructed stream identities. Historical and 31e ledger
  objects are reserialized selections. The historical Adler batch-250 receipt
  is name-cited in the selected registration; the newly measured digest and
  same-machine transport match do not authenticate that citation. Three
  specifically cited older Lens3 suppliers were independently hash-matched;
  transitive recovery remains incomplete.
- Bevy 0.19.1 source was extracted from local package archives whose SHA-256
  equals the pinned lock checksums; selected full files and original license
  notices are in this packet, archives are not. Optional registry-cache
  replay can recheck membership. Neither same-machine registry nor transport
  metadata is independent public custody. License choices are MIT OR Apache-2.0.
- Initial lock metadata preceded the later full-lock capture. Local UTC/file
  modification times are not a trusted timestamp service and do not prove
  comprehension. Reading test text or derive attributes does not execute them.
