#!/usr/bin/env python3
import json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent
name,lo,hi=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
c=[x for x in json.loads((p/"NATIVE-CAPTURES.json").read_text()) if x["capture"]==name];assert len(c)==1;c=c[0]
r=json.loads((p/"NATIVE-EXACT-REGISTRATION.json").read_text());assert any(x["package"]==c["package"] and x["member"]==c["member"] and x["range"][0]<=lo<=hi<=x["range"][1] for x in r["sources"])
lines=(p/name).read_text().splitlines();assert 1<=lo<=hi<=len(lines)
out="".join(f"{i:4d} {lines[i-1]}\n" for i in range(lo,hi+1))
with (p/f"NATIVE-DISPLAY-{name[7:10]}-{lo}-{hi}.txt").open("x") as f:f.write(out)
print(out,end="")
