# Preflight qualification

Before `MANIFEST.json` existed, an in-memory preflight of
`VERIFY-EVIDENCE.py` replaced only `check_manifest()` with a no-op. Its generic
first PASS line still mentioned the manifest, but did not check it in that
preflight. Only the separately sealed unmodified standalone and full runs
after manifest creation assert packet-manifest integrity. Checks execute
only evidence verification and do not run product code.
