# q2734: independent Lens 6 type-ownership assessment

## Identity, scope and credit

The recovered 059 queue's zero-based entry 2734 is
`OBLIGATION-ROOT-L3-EXT-0003-LENS-06`. Its 6533 source identity is
`crates/adventuresim-procedural-textures/src/runtime.rs`, SHA-256
`4351bf685bda2d29433f4b23698ef5377f466b51528b0e3400af6147b7d63931`,
1–167 of 167 lines. Exact object bytes were recovered from the protected source
object collection and matched the recorded hash. Raw commit-to-tree-to-blob
proofs establish that body at both 6533 and e275, individually, not whole-tree
equivalence. Original registration and receipt identify the 6533 full-body
read as the root's personal Lens 3 read; Lens 3 cannot confer Lens 6 credit.
The independent Lens 6 reader for this packet displayed the recovered body
1–167 after registering that precise read and proof. The e275 identity is
proved by its own commit path; no separate e275 object recovery is claimed.

Pinned 95e has a different body, SHA-256
`26cf50d8ebbd69f45bf05b257a168c6255227b83e0da994068b46c6173584ddb`,
174 lines. A prospective independent Lens 6 display covered 1–174 after its
own 95e commit/tree/blob and inventory match. The complete bounded textual
diff adds `installed_count` at 95e lines 60–65. Prior historical credit remains
at its original revision and reader; no 3821 evidence is inferred.

## Actual type owners and selected consumers

- `catalogue.rs:1–59` owns `TextureRecipeId` and slugs; the runtime module's
  `runtime.rs:150–155` attaches the asset-root-specific path adapter. The same
  crate owns `MapChannel`, `PixelEncoding`, `BakedMap` and `BakedRecipe` in
  `bake.rs:11–95`, re-exported by `lib.rs:8–16,37–40`. `wire.rs:9–26,60–123`
  admits native encoded metadata to that representation; `runtime.rs:109–147`
  adapts it to the Bevy asset loader and checks the filename against recipe ID.
  In the traced sources these are uses of the same owners, not a demonstrated
  duplicate bespoke type or contrary crate dependency.
- `runtime.rs:27–81,84–107,157–174` owns private loaded-map state, the
  requested/installed residency resource, reserved image destinations, the
  installation system and the Bevy image conversion. `runtime/handles.rs:8–110`
  reserves named presentation destinations; `lib.rs:69–144` owns their
  typed presentation groupings. `presentation/procedural_texture_setup.rs:11–29`
  reserves those destinations before optionally requesting the catalogue.
  `art_demo/residency.rs:57–63,146–155` requests and gates selected recipes;
  `strategic_scene/world.rs:51–70` and `status.rs:105–151` gate the scene on
  the catalogue. `loading_screen/sources.rs:48–55` uses the newly added count
  against that catalogue. This selected call trace is not all callers.
- `catalogue.rs:76–123,136–163` owns `TextureOutput`, an output-description
  vocabulary. It is not automatically the same contract as concrete
  `MapChannel`: foliage uses front/back channels, and ForestLitter has a packed
  surface and normal (`bake.rs:160–170,206–211` and
  `ground.rs:1795–1804,1869–1887`). The catalogue uses general surface output
  descriptors. Treat their mapping and policy as an open ownership/design
  question rather than merging equal-sounding variants by name.

## Connected conditional contract gap

The generator lists concrete recipe-to-channel sets at `bake.rs:136–226`;
`runtime/handles.rs:8–110` separately lists the channels for reserved
presentation destinations. `bake/wire.rs:60–123` checks map count, finite
metadata, map dimensions and mip bounds, duplicate channels, byte extents and
trailing bytes, but in that visible function does not check the map set against
the selected recipe. `runtime.rs:123–142` checks recipe ID against the filename
but retains each accepted channel. `runtime.rs:95–105` expects a destination
for every returned map and marks the recipe installed after the loop.

Consequently, conditional on a structurally admitted, correctly named bake with
an otherwise valid but unreserved extra channel, the displayed installation
path reaches a missing-destination `expect`. Conditional on a nonempty proper
subset of expected channels, the displayed loop can mark the recipe installed
while an expected reserved destination remains its default image. These are
static implications of the inspected source and not observations of an actual
committed asset, parser execution, failed runtime, rendered output or exploit.
`request` itself also does not reserve destinations; the selected startup path
reserves first, but the supported contract for other callers is open.

A connected repair candidate for central ledger adjudication is to decide which
shared owner defines the exact concrete channel set per recipe, then align
producer dispatch, admission, reservation and readiness with that authority.
Acceptance would need to specify how missing/extra channels and failed loads
are reported, ensure no partial or falsely ready installation, and exercise
legitimate supported recipes and consumers later. This is a source-only candidate,
not an implementation request, accepted unique count or assumption that
catalogue output descriptors must be collapsed into channel identity.

Historical `adler/REGISTRATION-ADLER-269.json` and `adler/READ-L11-205.json`
retain a separately attributed Lens 11 observation that requested/installed
state does not retain loader failure, and explicitly no other-lens transfer.
The former's observed hash matches the latter's recorded reference; the latter
is a recovered named record with an observed hash, not an invented expected
hash. Current scene and loading paths separately listen for asset failures under
`textures/procedural` (`scene_readiness.rs:51–56`, `status.rs:81–90`,
`loading_screen.rs:158–168`). Selected art-demo code tests texture readiness
without a texture-specific failure query, though it separately checks impostor
failure. Runtime delivery, other error consumers, event scheduling, policy and
any asserted user-visible stall remain unassessed. Do not automatically alias
this historical failure-state question with the channel-set question.

## Recovery and read qualifications

The first combined dependency display response was truncated by the tool
wrapper. Its full pre-registered source display file was retained and the
visibly affected bake body and related decoding ranges were re-read separately;
the receipt of truncation remains in the packet. Historical Adler record
navigation initially looked for `rows` in two differently shaped JSON records;
the bounded zero-match result and corrected source/connected-reinspection
selection are both retained. A Python regex registration emitted a warning;
its exact resulting search command is preserved. The earlier q2366/q2367 queue
index correction belongs to that separately attributed packet; this q2734
extraction used zero-based array indices and independently verified selected
bytes against both full queues.

Navigation searches used the physical checkout and confer no pinned body
credit. Every displayed dependency was independently matched to the 95e commit
and path/blob inventory, with windows recorded prospectively. Search for five
texture terms in one older 1,072-row ledger snapshot found no matches; that is
not a global absence or later-ledger claim. All 73 nontext/no-positive-EOF and
missing checkpoint 3821 qualifications remain; no binary fixture, asset payload,
product execution, parser, test, build, renderer, macro or runtime probe was run.
