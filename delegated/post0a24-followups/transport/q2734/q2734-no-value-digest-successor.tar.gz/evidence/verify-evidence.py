#!/usr/bin/env python3
"""Verify q2734 source-only evidence and registered displays, not product behavior."""
import argparse,datetime,difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(n):return json.loads((P/n).read_text())
def entries(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for n in ('commit-6533','commit-e275','commit-95e','original-queue','reconstructed-queue','current-inventory','ledger-snapshot'):ap.add_argument('--'+n,type=Path,required=True)
 a=ap.parse_args();m=load('MANIFEST.json');actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and str(x.relative_to(P))!='MANIFEST.json'};assert actual==set(m['files'])
 for n,x in m['files'].items():
  b=(P/n).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],n
 q=load('QUEUE-EXTRACTION.json');assert q['zero_based_array_index']==2734 and q['exact_byte_equal'];parts=[]
 for i,path in enumerate((a.original_queue,a.reconstructed_queue)):
  b=path.read_bytes();r=q['records'][i];assert sha(b)==r['queue_sha256'];part=b[r['start']:r['end']];assert len(part)==r['bytes'] and sha(part)==r['entry_sha256'];assert part==(P/f'QUEUE-ENTRY-{i}.json').read_bytes();assert json.loads(part)==json.loads(b)['entries'][2734];parts.append(part)
 assert parts[0]==parts[1];entry=json.loads(parts[0]);assert entry['lens']==6 and entry['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,167]]
 for x in load('HISTORY-SELECTED.json'):
  b=(P/'history'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert json.loads(b)['rows'][int(x['pointer'].split('/')[-1])]==x['row']
 reg=json.loads((P/'history/adler/REGISTRATION-ADLER-269.json').read_bytes());read=json.loads((P/'history/adler/READ-L11-205.json').read_bytes());summary=load('HISTORY-ADLER-CORRECTED.json');assert summary['registration']==reg and summary['lens11_matches'][0]['value']==read['connected_reinspection'][0];assert sha((P/'history/adler/REGISTRATION-ADLER-269.json').read_bytes())==read['connected_reinspection'][0]['registration_sha256']
 commits={};anchors=[('6533e444fa37552927070cc8d8190907fd3b413e',a.commit_6533),('e2755a732c84e67296b5e3441a4259a84f461b2f',a.commit_e275),('95e63628f9d70b8dd6e6fede64334696c6995009',a.commit_95e)]
 identities={x['revision']:x for x in load('COMMIT-ANCHOR-IDENTITIES.json')}
 for rev,path in anchors:
  b=path.read_bytes();assert oid('commit',b)==rev and len(b)==identities[rev]['bytes'] and sha(b)==identities[rev]['sha256'];commits[rev]=b.split(b'\n',1)[0].split()[1].decode()
 inv=a.current_inventory.read_bytes();proof=load('PROOF-RESULT.json');assert sha(inv)==proof['inventory_sha256'];invlines=inv.decode().splitlines()
 def verify_path(x,tree_root):
  cur=commits[x['revision']];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
  for part,item in zip(parts,x['chain']):
   b=(P/tree_root/(cur+'.tree')).read_bytes();assert oid('tree',b)==cur;mode,nxt=entries(b)[part];assert item=={'tree':cur,'component':part,'mode':mode,'oid':nxt};cur=nxt
  assert cur==x['blob'];return cur
 old=(P/'evidence/recovered-6533-runtime.rs').read_bytes();assert sha(old)==entry['exact_source_identities_and_assessed_ranges'][0]['source_sha256']==proof['recovered_source']['sha256'];assert len(old.decode().splitlines())==167
 for x in proof['paths']:
  cur=verify_path(x,'evidence/proof/trees');b=(P/'evidence/current'/x['path']).read_bytes();assert sha(b)==x['current_candidate_sha256'];assert (oid('blob',b)==cur)==x['current_candidate_matches']
  if x['path'].endswith('runtime.rs'):assert (oid('blob',old)==cur)==x['historical_recovered_matches']
  if x['revision'].startswith('95e'):assert x['current_candidate_matches']
 assert len(proof['paths'])==4 and not proof['fallback_failures']
 for x in proof['current_candidates'].values():
  for row in x['inventory_rows']:assert row in invlines
 for name,root in [('DEPENDENCY-PROOF.json','evidence/dependencies'),('EXTRA-PROOF.json','evidence/extra')]:
  record=load(name);assert sha(inv)==record['inventory_sha256'] and not record['fallback_failures']
  for x in record['paths']:
   assert verify_path(x,root+'/trees')==x['blob'];b=(P/root/'sources'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and oid('blob',b)==x['blob'];assert x['inventory_row'] in invlines
 assert len(load('DEPENDENCY-PROOF.json')['paths'])==13 and len(load('EXTRA-PROOF.json')['paths'])==3
 def verify_displays(regname,receiptname,sourcebase):
  reg=load(regname);receipts=load(receiptname)
  for x in receipts:
   path=x['source'];lo,hi=x['range'];assert [lo,hi] in reg['windows'][path];assert datetime.datetime.fromisoformat(x['at_utc'])>=datetime.datetime.fromisoformat(reg['at_utc']);b=(P/sourcebase/path).read_bytes();lines=b.decode().splitlines();assert sha(b)==x['source_sha256'] and len(lines)==x['eof'];d=(f'SOURCE {path}:{lo}-{hi}\n'+''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1))).encode();assert d==(P/x['display']).read_bytes() and sha(d)==x['display_sha256']
  return len(receipts)
 reg=load('REGISTRATION-004.json');r=load('DISPLAY-RECEIPTS.json')
 for x,w in zip(r['displays'],reg['windows']):
  assert x['source']==w['source'] and x['revision']==w['revision'] and x['range']==w['range'] and datetime.datetime.fromisoformat(x['at_utc'])>=datetime.datetime.fromisoformat(reg['at_utc']);b=(P/x['source']).read_bytes();lines=b.decode().splitlines();lo,hi=x['range'];d=(f'SOURCE {x["source"]} REVISION {x["revision"]}:{lo}-{hi}\n'+''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1))).encode();assert sha(b)==x['source_sha256'] and len(lines)==x['eof'] and d==(P/x['display']).read_bytes() and sha(d)==x['display_sha256']
 oldlines=old.decode().splitlines(keepends=True);newlines=(P/reg['windows'][1]['source']).read_text().splitlines(keepends=True);diff=''.join(difflib.unified_diff(oldlines,newlines,fromfile='6533-and-e275/runtime.rs',tofile='95e/runtime.rs')).encode();assert diff==(P/'RUNTIME-DIFF.txt').read_bytes() and sha(diff)==r['diff_sha256']
 assert verify_displays('REGISTRATION-008.json','DEPENDENCY-DISPLAY-RECEIPTS.json','evidence/dependencies/sources')==13
 assert verify_displays('REGISTRATION-015.json','EXTRA-DISPLAY-RECEIPTS.json','evidence/extra/sources')==3
 extra=load('REGISTRATION-012.json')['extra_source_display'];receipt=load('DEPENDENCY-EXTRA-RECEIPT.json');b=(P/'evidence/dependencies/sources'/extra['path']).read_bytes();lines=b.decode().splitlines();lo,hi=extra['range'];d=(f'SOURCE {extra["path"]}:{lo}-{hi}\n'+''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1))).encode();assert sha(b)==extra['sha256']==receipt['source_sha256'] and d==(P/'DEPENDENCY-EXTRA.txt').read_bytes() and sha(d)==receipt['display_sha256']
 ledger=a.ledger_snapshot.read_bytes();nav=load('LEDGER-NAV.json');assert sha(ledger)==nav['ledger_sha256'];rows=json.loads(ledger)['newly_assessed_ledger']['entries'];assert len(rows)==nav['row_count']
 for t,res in nav['terms'].items():
  hits=[{'index':i,'id':row.get('id')} for i,row in enumerate(rows) if t.casefold() in json.dumps(row,ensure_ascii=False).casefold()];assert len(hits)==res['count'] and hits[:40]==res['shown'] and (len(hits)>40)==res['truncated']
 print('Evidence verified: exact q2734 queues, recovered history, three revision anchors, 20 path proofs, registered Lens6 displays and bounded ledger navigation.')
 print('No product code, parser, fixture, test, build, renderer, macro or runtime probe executed.')
if __name__=='__main__':main()
