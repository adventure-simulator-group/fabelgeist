import datetime,hashlib,json,pathlib,subprocess,traceback
P=pathlib.Path(__file__).resolve().parent;r=json.loads((P/'REGISTRATION-014.json').read_text());repo=pathlib.Path(r['repo'])
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def jw(p,x):put(p,(json.dumps(x,indent=2,sort_keys=True)+'\n').encode())
def parse(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
try:
 commit=pathlib.Path(r['commit_anchor']).read_bytes();assert oid('commit',commit)==r['revision'];rootoid=commit.split(b'\n',1)[0].split()[1].decode();inv=pathlib.Path(r['inventory']).read_bytes();lines=inv.decode().splitlines();trees={};routes={};failures=[];proof=[]
 def gettree(cur):
  if cur in trees:return trees[cur]
  for prefix in r['tree_roots']:
   f=pathlib.Path(prefix)/(cur+'.tree')
   if f.is_file():b=f.read_bytes();assert oid('tree',b)==cur;routes[cur]='prior-verified-tree';break
  else:
   z=subprocess.run(['git','-C',str(repo),'cat-file','tree',cur],capture_output=True)
   if z.returncode:failures.append({'tree':cur,'exit':z.returncode,'stderr':z.stderr.decode(errors='replace')});raise FileNotFoundError(cur)
   b=z.stdout;assert oid('tree',b)==cur;routes[cur]='git-cat-file-tree'
  put(P/'evidence/extra/trees'/(cur+'.tree'),b);trees[cur]=b;return b
 for path in r['source_paths']:
  b=(repo/path).read_bytes();put(P/'evidence/extra/sources'/path,b);hits=[l for l in lines if l.endswith('\t'+path)];assert len(hits)==1 and oid('blob',b)==hits[0].split()[2];cur=rootoid;chain=[]
  for part in path.split('/'):
   mode,nxt=parse(gettree(cur))[part];chain.append({'tree':cur,'component':part,'mode':mode,'oid':nxt});cur=nxt
  assert oid('blob',b)==cur;proof.append({'path':path,'revision':r['revision'],'sha256':sha(b),'bytes':len(b),'lines':len(b.decode().splitlines()),'blob':cur,'chain':chain,'inventory_row':hits[0]})
 result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inventory_sha256':sha(inv),'paths':proof,'tree_routes':routes,'fallback_failures':failures};jw(P/'EXTRA-PROOF.json',result);print(json.dumps({'paths':[{'path':x['path'],'sha256':x['sha256'],'lines':x['lines']} for x in proof],'trees':len(trees),'fallback_failures':failures},indent=2))
except Exception as e:jw(P/'EXTRA-PROOF-ERROR.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
