# q2884: independent Lens 12 compressed-bake string review

## Scope, selection and provenance

This is a newly assessed, source-only Lens 12 review by `wrapped_scope` of 059
entry 2884, `OBLIGATION-ROOT-L3-EXT-0015-LENS-12`, at product revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The required historical scope is
`crates/adventuresim-procedural-textures/src/bake/compressed.rs:1-69`. The
protected 6533 object was recovered and SHA-256 checked. Independent Git
commit/tree/blob chains prove the same 2,534-byte individual source at 6533,
e275 and 95e; this is not whole-tree equivalence. The entire 95e body received
a fresh, prospectively registered personal Lens 12 read. Historical Root's
6533 personal Lens 3 read and e275 same-Lens-3 qualified reuse are separate;
they confer no new reader or Lens 12 body credit. The e275 record says no
fresh personal read. Original and reconstructed 059 queues differ as whole
files; the exact selected q2884 and related q49, q1252, q2355, q2701 and
q2934 entries compare byte-for-byte equal. None recovers checkpoint 3821.
The prior 73 nontext/no-positive-EOF recovery qualification remains.

The published 059 reconciliation records q2884 as unassessed. The bounded
published/staged filename and exact-ID search found no separately named q2884
packet. This search and agent reservations are not a global proof of absence.
A separately staged 95e Lens 2 owner-fit review by `verifier_scope` covers
this codec as support and is not Lens 12 credit. The complete private selection
navigation, including its large filename listing, is held separately under the
selection manifest and must accompany this packet for full overlap replay.

## String inventory and trace

* The decompressed-size error at `compressed.rs:26-29` and unexpected trailing
  compressed-data error at 31-32 are source-authored descriptive diagnostic
  strings. Both enter `io::Error::other`, yielding `ErrorKind::Other`. The
  gzip decoder's own I/O errors propagate from `read_to_end` (19-25); this
  bounded review makes no claim about their native variants or CRC behavior.
* `BakedRecipe::from_bytes` at `bake/wire.rs:60-115` returns `Result<Self,
  String>`. Its header, map and payload failures are text; JSON decode errors
  are converted to `String` at 70-75. `compressed.rs:34` turns each such wire
  string into `io::Error::other`. Thus the selected compressed API exposes
  several distinct local admissions as unstructured diagnostic payloads with
  the same I/O kind; the original Serde error is already stringified. Whether
  consumers need stable distinctions is a design question, not an observed
  string-comparison bug. Typed codec/admission reasons with an I/O/framework
  adapter are a connected migration direction to evaluate, not a prescribed
  schema or an added defect count.
* The selected `RuntimeTextureLoader` declares `std::io::Error`, reads the
  asset and propagates `from_compressed_bytes` with `?` (`runtime.rs:109-125`);
  its separately authored filename/recipe mismatch is another `Other` at
  126-135. Its recipe stem compares against typed `TextureRecipeId::slug`, not
  either of the two target error messages (`catalogue.rs:1-59`). The selected
  authoring binary returns `Box<dyn Error>` and propagates encode/decode I/O
  errors (`bin/bake-procedural-textures.rs:9-34`). Neither selected consumer
  compares or branches on the target diagnostic text. Bevy and other external
  error behavior and any other supported caller remain outside this proof.
* The target test assertion's `"{}"` at 57 is a formatting token for the
  typed recipe's slug (`catalogue.rs:1-59`), not a stored status identifier.
  `b"not a texture bake"` at 67 is deliberately malformed test input, not a
  production message or accepted wire tag. All test source was read as text;
  no test or fixture was executed. No other target string literals occur.

The loader's typed recipe path and suffix at `runtime.rs:126-153` are an
external asset-name boundary, distinct from diagnostic strings. Existing
wire encoding and supported inputs are not implicitly authorized to change.

## Relationships and open boundaries

* The prior 059 Lens 2 q2355 and its separate 95e `verifier_scope` assessment
  concern BakedMap/BakedRecipe admission, native image fit and physical scale;
  q2701 and q2934 preserve the Lens 3 recipe/channel installation question.
  These intersect the decoder but have different first contracts. No alias or
  unique count is assigned here.
* 31e `ADLER-L11-TEXTURE-RESIDENCY-FAILURE-STATE` is the earlier conditional
  per-recipe failure/readiness record, itself q49; its q1252 reference is a
  related open Lens 12 residency contract with no exact source identity and a
  required locator resolution, not a misidentified q49 record. The current
  loader propagates an error; `ProceduralTextureResidency` tracks requested and
  installed recipes (`runtime.rs:32-58,84-105`) and selected loading/scene
  consumers use installed counts or readiness (`loading_screen/sources.rs:
  48-55`, `strategic_scene/status.rs:125-150`, `strategic_scene/world.rs:
  60-70`). The selected art-demo `LoadState::Failed` check concerns a tree
  impostor handle, not proof of texture-failure handling. Other consumers,
  framework failure propagation, retry policy and runtime effects remain open.
* Resolve the supported public compressed/wire error contracts and actual
  callers, desired machine-readable distinctions, native I/O and Serde cause
  preservation, and how any owned error maps to the framework loader. Preserve
  valid wire/payload acceptance and named recipe identity. If future repairs are
  authorized separately, acceptance should cover oversized decoded payloads,
  extra compressed bytes, each invalid wire category and real native I/O/JSON
  cause, while checking valid round trips and loader/status presentation. This
  paragraph is a future acceptance outline, not a repair or test result.

## Read and recovery qualifications

`READ-LIMITS.json` records exact pinned support windows and unread complements.
The physical-tree navigation is unpinned. One broad navigation returned exit 2
because a guessed `crates/adventuresim-assets` directory did not exist; its
stdout, stderr and successful narrower searches are retained, so it is not a
claim of exhaustive callers. For the selected related q49/q1252/q2355/q2701/
q2934 records, the original queue was hash checked before selected fields were
displayed; original/reconstructed byte equality was checked afterwards. The
staged related report and summaries were manifest-checked before display.
Evidence-only object/JSON verification does not establish runtime behavior.
No product parser, code, fixture, build, test, renderer, macro, runtime probe or
repair was run. No whole lens, queue, thirteen-lens or implementation closure is
asserted.
