#!/usr/bin/env python3
"""Verify q2884 evidence identities and displays, never product behavior."""
import argparse,datetime,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(n):return json.loads((P/n).read_text())
def objects(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def instant(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for n in ('commit-6533','commit-e275','commit-95e','original-queue','reconstructed-queue','current-inventory','ledger-31e','selection-dir','reconciliation'):ap.add_argument('--'+n,type=Path,required=True)
 a=ap.parse_args();m=load('MANIFEST.json');actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and str(x.relative_to(P))!='MANIFEST.json'};assert actual==set(m['files'])
 for n,x in m['files'].items():
  b=(P/n).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],n
 custody=load('SELECTION-CUSTODY.json');sm=(a.selection_dir/'SELECTION-MANIFEST.json').read_bytes();assert sha(sm)==custody['manifest_sha256'] and sm==(P/'SELECTION-MANIFEST.json').read_bytes();sel=json.loads(sm);assert {x.name for x in a.selection_dir.iterdir() if x.is_file()}==set(sel['files'])|{'SELECTION-MANIFEST.json'}
 for n,x in sel['files'].items():
  f=a.selection_dir/n;assert not f.is_symlink();b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 recon=a.reconciliation.read_bytes();sr=load('Q2884-INTAKE-REGISTRATION.json');assert sha(recon)==sr['reconciliation_sha256'];assert json.loads(recon)['entries'][2884]==load('Q2884-RECONCILIATION-ROW.json') and load('Q2884-RECONCILIATION-ROW.json')['current_reconciliation']=='unassessed'
 queues=[a.original_queue.read_bytes(),a.reconstructed_queue.read_bytes()];q=load('Q2884-INTAKE-RECEIPT.json');parts=[]
 for i,b in enumerate(queues):
  z=q['records'][i];assert sha(b)==z['queue_sha256'];part=b[z['start']:z['end']];assert len(part)==z['bytes'] and sha(part)==z['sha256'] and part==(P/f'Q2884-ENTRY-{i}.json').read_bytes() and json.loads(part)==json.loads(b)['entries'][2884];parts.append(part)
 assert parts[0]==parts[1];entry=json.loads(parts[0]);assert entry['lens']==12 and entry['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,69]]
 for x in load('RELATED-RECEIPT.json')['records']:
  b=queues[x['queue']];part=b[x['start']:x['end']];assert sha(part)==x['sha256'] and len(part)==x['bytes'] and part==(P/f'RELATED-{x["index"]}-{x["queue"]}.json').read_bytes() and json.loads(part)==json.loads(b)['entries'][x['index']]
 for n in (49,1252,2355,2701,2934):assert (P/f'RELATED-{n}-0.json').read_bytes()==(P/f'RELATED-{n}-1.json').read_bytes()
 for x in load('HISTORY-SELECTED.json'):
  b=(P/'history'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert json.loads(b)['rows'][int(x['pointer'].split('/')[-1])]==x['row']
 commits={};ids={x['revision']:x for x in load('COMMIT-ANCHOR-IDENTITIES.json')}
 for rev,path in [('6533e444fa37552927070cc8d8190907fd3b413e',a.commit_6533),('e2755a732c84e67296b5e3441a4259a84f461b2f',a.commit_e275),('95e63628f9d70b8dd6e6fede64334696c6995009',a.commit_95e)]:
  b=path.read_bytes();assert oid('commit',b)==rev and len(b)==ids[rev]['bytes'] and sha(b)==ids[rev]['sha256'];commits[rev]=b.split(b'\n',1)[0].split()[1].decode()
 inventory=a.current_inventory.read_bytes();lines=inventory.decode().splitlines();proof=load('PROOF-RESULT.json');assert sha(inventory)==proof['inventory_sha256']
 def chain(x,root):
  cur=commits[x['revision']];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
  for part,item in zip(parts,x['chain']):
   b=(P/root/(cur+'.tree')).read_bytes();assert oid('tree',b)==cur;mode,nxt=objects(b)[part];assert item=={'tree':cur,'component':part,'mode':mode,'oid':nxt};cur=nxt
  assert cur==x['blob'];return cur
 old=(P/'evidence/recovered-6533-compressed.rs').read_bytes();assert sha(old)==entry['exact_source_identities_and_assessed_ranges'][0]['source_sha256']==proof['recovered_source']['sha256'] and len(old.decode().splitlines())==69
 assert len(proof['paths'])==4 and not proof['fallback_failures']
 for x in proof['paths']:
  cur=chain(x,'evidence/proof/trees');b=(P/'evidence/current'/x['path']).read_bytes();assert sha(b)==x['current_candidate_sha256'] and (oid('blob',b)==cur)==x['current_candidate_matches']
  if x['path'].endswith('compressed.rs'):assert oid('blob',old)==cur and b==old
 for x in proof['current_candidates'].values():
  for row in x['inventory_rows']:assert row in lines
 for filename,root,count in [('DEPENDENCY-PROOF.json','evidence/dependencies',4),('EXTRA-PROOF.json','evidence/extra',5)]:
  record=load(filename);assert sha(inventory)==record['inventory_sha256'] and not record['fallback_failures'] and len(record['paths'])==count
  for x in record['paths']:
   assert chain(x,root+'/trees')==x['blob'];b=(P/root/'sources'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and oid('blob',b)==x['blob'] and x['inventory_row'] in lines
 reg=load('REGISTRATION-003.json');displays=load('DISPLAY-RECEIPTS.json')['displays'];assert len(displays)==2
 for x,w in zip(displays,reg['windows']):
  assert x['source']==w['source'] and x['revision']==w['revision'] and x['range']==w['range'] and instant(x['at_utc'])>=instant(reg['at_utc']);b=(P/x['source']).read_bytes();ls=b.decode().splitlines();lo,hi=x['range'];d=(f'SOURCE {x["source"]} REVISION {x["revision"]}:{lo}-{hi}\n'+''.join(f'{i:4} {ls[i-1]}\n' for i in range(lo,hi+1))).encode();assert sha(b)==x['source_sha256'] and len(ls)==x['eof'] and d==(P/x['display']).read_bytes() and sha(d)==x['display_sha256']
 for regname,receipt,count in [('DEPENDENCY-DISPLAY-REGISTRATION.json','DEPENDENCY-DISPLAY-RECEIPTS.json',4),('EXTRA-DISPLAY-REGISTRATION.json','EXTRA-DISPLAY-RECEIPTS.json',5)]:
  reg=load(regname);rs=load(receipt);assert len(rs)==len(reg['windows'])==count
  for x,w in zip(rs,reg['windows']):
   assert all(x[k]==w[k] for k in ('name','file','first','last')) and instant(x['at_utc'])>=instant(reg['at_utc']);b=(P/x['file']).read_bytes();ls=b.decode().splitlines();d=''.join(f'{i}: {ls[i-1]}\n' for i in range(x['first'],x['last']+1)).encode();assert sha(b)==x['source_sha256'] and len(ls)==x['actual_source_lines'] and d==(P/x['output']).read_bytes() and sha(d)==x['output_sha256']
 st=load('STAGED-MANIFEST.json')['files']
 for n in ('REPORT-v3.md','Q2355-SUMMARY.json','Q2356-SUMMARY.json'):
  b=(P/('STAGED-'+n)).read_bytes();assert len(b)==st[n]['bytes'] and sha(b)==st[n]['sha256']
 ledger=a.ledger_31e.read_bytes();nav=load('NAV2-REGISTRATION.json')['ledger_select'];assert sha(ledger)==nav['sha256'];row=json.loads(ledger)['newly_assessed_ledger']['entries'][nav['index']];assert row==load('LEDGER-201.json') and row['id']==nav['expect_id']
 for name,pre in [('NAV-RECEIPT.json','NAV-'),('NAV2-RECEIPT.json','NAV2-')]:
  for x in load(name)['results']:
   for ext in ('stdout','stderr'):
    b=(P/(pre+str(x['index'])+'.'+ext)).read_bytes();assert len(b)==x[ext+'_bytes'] and sha(b)==x[ext+'_sha256']
 assert load('NAV-RECEIPT.json')['results'][2]['exit']==2
 print('Evidence verified: q2884 and five related exact queue pairs, separate selection custody and reconciliation, historical records, three commit anchors, 13 path proofs, 11 registered windows, selected staged review and 31e relationship.')
 print('Evidence only: no product parser, fixture, build, test, renderer, macro, runtime probe or repair.')
if __name__=='__main__':main()
