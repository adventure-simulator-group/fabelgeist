# q2884 Lens 12 reconstructed evidence successor

This is a path-redacted reconstruction of a separately held exact private
source-only packet. Whole-file hashes, offsets, lengths and opaque aliases
permit comparison against that original; removed values cannot be recovered
from this successor. Nine separately held replay anchors are required,
including the complete private selection directory and reconciliation file.
The private selection includes a retained unpinned filename inventory omitted
from this packet; it is necessary to replay the overlap-selection evidence.

The recovered 6533 source object is file-identical at e275 and 95e, without
whole-tree equivalence. The new Lens 12 reader is wrapped_scope. Root's
historical Lens 3 read and the separate 95e Lens 2 support review by
verifier_scope retain attribution. The linked q1252 Lens 12 residency
contract lacks an exact source identity and remains separate. Missing checkpoint
3821, 73 nontext/no-positive-EOF, failed navigation and historical display
ordering qualifications persist. No product code, parser, fixtures, builds,
tests, renderers, macros, runtime probes or repairs were executed.
