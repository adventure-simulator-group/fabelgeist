#!/usr/bin/env python3
"""Verify q2721 source evidence only; no product execution or closure inference."""
import argparse,datetime,gzip,hashlib,json,os,pathlib,subprocess
P=pathlib.Path(__file__).resolve().parent
REV='95e63628f9d70b8dd6e6fede64334696c6995009'
OLD='e2755a732c84e67296b5e3441a4259a84f461b2f'
FROZEN='6533e444fa37552927070cc8d8190907fd3b413e'
LEDGER='31e130bfa8f8914f759c7d5cddc3db92962704c7'
LEDGER_SHA='b10132337fad5f1cf91fbd23c01a3ed4330793e79aac65ec4921aece591d1c50'
def j(n):return json.loads((P/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def union(spans):
 out=[]
 for lo,hi in sorted(spans):
  if out and lo<=out[-1][1]+1:out[-1][1]=max(out[-1][1],hi)
  else:out.append([lo,hi])
 return out
def check_manifest():
 m=j('MANIFEST.json');items=list(P.iterdir());assert all(x.is_file() and not x.is_symlink() for x in items)
 assert {x.name for x in items if x.name!='MANIFEST.json'}==set(m['files'])
 for n,v in m['files'].items():
  assert pathlib.Path(n).name==n
  b=(P/n).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']
def refs(v,out):
 if isinstance(v,dict):
  for a,b in [('path','sha256'),('verification','verification_sha256'),('receipt','receipt_sha256'),('registration','registration_sha256')]:
   if isinstance(v.get(a),str) and isinstance(v.get(b),str) and len(v[b])==64:out.add((v[a],v[b]))
  for x in v.values():refs(x,out)
 elif isinstance(v,list):
  for x in v:refs(x,out)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--git-repo',type=pathlib.Path);ap.add_argument('--transport-manifest',type=pathlib.Path);ap.add_argument('--live-ledger',type=pathlib.Path);a=ap.parse_args();check_manifest()
 caps=[]
 for f in sorted(P.glob('SOURCE-CAPTURES*.json')):
  d=json.loads(f.read_text());caps.extend(d if isinstance(d,list) else [d])
 assert len(caps)==21 and len({x['path'] for x in caps})==21;bypath={x['path']:x for x in caps};bycap={x['capture']:x for x in caps}
 for x in caps:
  b=(P/x['capture']).read_bytes();assert x['revision']==REV and sha(b)==x['sha256'] and blob(b)==x['blob'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof']
  if x['capture']=='SOURCE-000.dat':
   assert x['eof']==1095 and x['all_three_same'] and all(z['sha256']==x['sha256'] and z['blob']==x['blob'] for z in x['versions'].values()) and set(x['versions'])=={REV,OLD,FROZEN}
  else:assert x['e275_present'] and x['e275_same_bytes'] and x['e275_sha256']==x['sha256']
 regs={f.name:json.loads(f.read_text()) for f in P.glob('SOURCE*REGISTRATION.json')};receipt=j('SOURCE-READ-RECEIPT.json');assert len(receipt['displays'])==82;spans={x['path']:[] for x in caps}
 for x in receipt['displays']:
  lo,hi=x['range'];r=regs[x['registration']];c=bypath[x['path']];assert r['revision']==x['revision']==REV and x['registered_before_display']
  assert any(z['path']==x['path'] and z['range']==x['registered_range'] and z['range'][0]<=lo<=hi<=z['range'][1] for z in r['sources'])
  assert r['registered_utc']==x['registration_time_utc'] and datetime.datetime.fromisoformat(x['registration_time_utc'])<=datetime.datetime.fromisoformat(x['display_file_mtime_utc'])
  lines=(P/c['capture']).read_text().splitlines();assert 1<=lo<=hi<=len(lines);b=''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
  assert b==(P/x['display']).read_bytes() and sha(b)==x['sha256'];spans[x['path']].append((lo,hi))
 assert {x['path'] for x in receipt['coverage']}==set(bypath)
 for x in receipt['coverage']:
  merged=union(spans[x['path']]);assert x['personally_displayed_union']==merged and x['personal_displayed_lines']==sum(b-a+1 for a,b in merged) and x['unread_lines']==x['eof']-x['personal_displayed_lines'] and x['eof']==bypath[x['path']]['eof']
 assert union(spans[bycap['SOURCE-000.dat']['path']])==[[1,1095]]
 assert sum(x['personal_displayed_lines'] for x in receipt['coverage'])==6973 and sum(x['unread_lines'] for x in receipt['coverage'])==19479
 ignored=set(receipt['broad_capture_only_registrations_excluded_from_window_completion_check']);missing=[]
 for n,r in regs.items():
  if n in ignored:continue
  for z in r['sources']:
   lo,hi=z['range'];present={i for a,b in spans[z['path']] for i in range(a,b+1)};m=union([(i,i) for i in range(lo,hi+1) if i not in present])
   if m:missing.append({'registration':n,'path':z['path'],'registered_range':[lo,hi],'unread_subranges':m})
 assert not missing and receipt['registered_precise_windows_with_unread_subranges']==missing
 ids=j('HISTORY-IDENTITIES.json');assert len(ids)==2
 for x in ids:
  b=(P/x['capture']).read_bytes();assert sha(b)==x['entry_sha256'] and len(b)==x['entry_bytes']
 b=(P/'Q2721-ORIGINAL-EXACT.json').read_bytes();assert b==(P/'Q2721-RECONSTRUCTED-EXACT.json').read_bytes();q=json.loads(b);direct=set();refs(q,direct)
 assert q['contract_id']=='OBLIGATION-ROOT-L3-EXT-0002-LENS-05' and q['lens']==5 and q['status']=='own-lens-proof-qualification-or-read-pending' and q['body_or_population_credit']==0 and not q['implementation_gate_complete']
 x=q['exact_source_identities_and_assessed_ranges'][0];assert x['revision']==FROZEN and x['source_sha256']==bycap['SOURCE-000.dat']['sha256'] and x['actual_EOF']==1095 and x['required_ranges']==[[1,1095]] and x['assessed_ranges']==[] and x['foreign_body_credit']==0
 x=q['exact_current_revision_revisit_requirements'][0];assert x['target_revision']==OLD and x['required_ranges']==[[1,1095]] and x['body_credit']==0 and x['own_lens_evidence_still_required']
 registered={(x['path'],x['expected_sha256']) for x in j('RECOVERY-REGISTRATION.json')['references']};assert direct==registered and len(direct)==3
 recovered=j('RECOVERY-RESULT.json');assert len(recovered)==3
 for x in recovered:
  b=(P/x['capture']).read_bytes();assert x['matched'] and (x['reference'],x['expected_sha256']) in registered and len(b)==x['bytes'] and sha(b)==x['expected_sha256']
 base=(P/'BASE-REGISTRATION.dat').read_bytes();assert sha(base)=='6fb3a6b3a9f0282f04359daf06a2409d710eb4ee436284c228b3ce7d994aefce'
 assert j('TRANSPORT-RESULT.json')['matched']==j('TRANSPORT-RESULT.json')['total']==4
 related=j('RELATED-HISTORY-IDENTITIES.json');assert len(related)==6
 for x in related:assert sha((P/x['capture']).read_bytes())==x['sha256']
 for n in (180,230,2338):assert (P/f'RELATED-Q{n}-ORIGINAL.json').read_bytes()==(P/f'RELATED-Q{n}-RECONSTRUCTED.json').read_bytes()
 hist=j('HIST-LEDGER-IDENTITIES.json');assert len(hist)==8
 for i in range(4):assert j(f'HIST-LEDGER-{i:02}-ORIGINAL.json')==j(f'HIST-LEDGER-{i:02}-RECONSTRUCTED.json')
 indices={14:'REVIEW-DIALOGUE-ACTION-RECEIPT-001',91:'REVIEW-DIALOGUE-PRIORITY-OVERLAP-001',104:'PL13-260-INVESTIGATION-CORRECTION-PROPOSITION-IDENTITY-PENDING',127:'SEGOVB-L12-DIALOGUE-OBJECTIVE-PRIVATE-KEY',170:'SEGOVB-L12-DIALOGUE-TOPIC-PRIVATE-ATTEMPT-KEY-TEXT',749:'ADLER-L11-DIALOGUE-PAYLOAD-ADMISSION',758:'SEGOVB-L12-DIALOGUE-EVENT-FRAGMENTS-JSON-CAUSE-ERASURE',759:'SEGOVB-L12-DIALOGUE-EVENT-SOURCE-REFS-JSON-CAUSE-ERASURE',773:'REVIEW-DIALOGUE-REFERRAL-SOURCE-SHAPE-95E'}
 for i,k in indices.items():assert j(f'LIVE-LEDGER-{i}.json')['id']==k
 authored=j('AUTHORED-CAPTURES.json');assert len(authored)==3;actions=[];prompts=[];catalog=[]
 def visit(v,path,pointer):
  if isinstance(v,dict):
   if v.get('kind')=='investigation_action':actions.append({'path':path,'pointer':pointer,'action':v.get('action')})
   for k,z in v.items():visit(z,path,pointer+'/'+k.replace('~','~0').replace('/','~1'))
  elif isinstance(v,list):
   for i,z in enumerate(v):visit(z,path,pointer+'/'+str(i))
 for x in authored:
  b=(P/x['capture']).read_bytes();assert x['revision']==REV and sha(b)==x['sha256'] and blob(b)==x['blob'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof'];d=json.loads(b);visit(d,x['path'],'')
  for ci,c in enumerate(d['conversations']):
   roles=[k for k,v in c['roles'].items() if v.get('kind')=='npc'];found=[]
   for ti,t in enumerate(c['topics']):
    for ri,r in enumerate(t['responses']):
     pr=r.get('prompt')
     if pr:
      at=f'/conversations/{ci}/topics/{ti}/responses/{ri}/prompt';prompts.append({'path':x['path'],'pointer':at,'conversation':c['id'],'topic':t['id'],'response':r['id'],'prompt_id':pr['id'],'mode':pr.get('mode','<missing>'),'resolution':pr.get('resolution','<missing>'),'respondent':pr.get('respondent','<missing>'),'min_choices':pr.get('min_choices','<missing>'),'max_choices':pr.get('max_choices','<missing>'),'choice_count':len(pr.get('choices',[]))})
   prefix=f'/conversations/{ci}/'
   for hit in actions:
    if hit['path']==x['path'] and hit['pointer'].startswith(prefix):
     assert '/responses/' in hit['pointer'] and '/effects/' in hit['pointer'] and '/choices/' not in hit['pointer'];found.append({'location':hit['pointer'],'scope':'response','action':hit['action']})
   if len(roles)>1 or found:catalog.append({'path':x['path'],'conversation_index':ci,'conversation_id':c['id'],'npc_roles':roles,'investigation_actions':found})
 assert actions==j('AUTHORED-ACTION-EXT-RESULT.json') and len(actions)==6 and prompts==j('AUTHORED-PROMPT-RESULT.json') and len(prompts)==8 and all(x['mode']!='multi' for x in prompts) and catalog==j('AUTHORED-LOCATOR-RESULT.json')
 print('PASS packet manifest, 21 source identities, 82 registered displays, historical qualification, nine selected ledger rows and static catalog selections.')
 def ledger_check(b):
  assert len(b)==1457605 and sha(b)==LEDGER_SHA;d=json.loads(b)['newly_assessed_ledger']['entries'];assert len(d)==1072
  for i in indices:assert d[i]==j(f'LIVE-LEDGER-{i}.json')
 if a.git_repo:
  env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
  def git(*args):return subprocess.check_output(['git','-C',str(a.git_repo),'--no-replace-objects',*args],env=env)
  for x in caps:
   b=git('show',f'{REV}:{x["path"]}');ob=git('show',f'{OLD}:{x["path"]}');assert b==(P/x['capture']).read_bytes() and ob==b
   if x['capture']=='SOURCE-000.dat':assert git('show',f'{FROZEN}:{x["path"]}')==b
  for x in authored:assert git('show',f'{REV}:{x["path"]}')==(P/x['capture']).read_bytes()
  tree=git('ls-tree','-r','--name-only',REV,'--','content/dialogue').decode().splitlines();selected=sorted(p for p in tree if p.startswith('content/dialogue/') and '/' not in p[len('content/dialogue/'):] and p.endswith('.yaml'));assert selected==sorted(x['path'] for x in authored)
  streams={}
  for x in ids:
   key=(x['revision'],x['path']);b=git('show',f'{key[0]}:{key[1]}');streams[key]=b
   assert sha(b)==x['stream_sha256'] and len(b)==x['stream_bytes'] and blob(b)==x['git_blob'] and b[x['entry_start_byte']:x['entry_end_byte_exclusive']]==(P/x['capture']).read_bytes() and json.loads(b)['entries'][2721]==q
  for x in related:
   b=streams[(x['revision'],'baseline-059/queue.json')];assert b[x['start']:x['end']]==(P/x['capture']).read_bytes() and json.loads(b)['entries'][int(x['selector'].split('/')[-1])]==json.loads((P/x['capture']).read_bytes())
  hs={}
  for x in hist:
   if x['revision'] not in hs:hs[x['revision']]=git('show',f'{x["revision"]}:baseline-059/ledger.json')
   b=hs[x['revision']];assert sha(b)==x['stream_sha256'] and len(b)==x['stream_bytes'] and json.loads(b)['discovery_findings_and_dependencies'][x['key']]==j(x['capture'])
  ledger_check(git('show',f'{LEDGER}:BASELINE-95E-20261110.json'))
  print('PASS Git object store: pinned/e275 source, frozen primary, authored inventory, original/reconstructed queue and ledger membership, exact 31e ledger membership.')
 else:print('NOT REPEATED: Git object membership (supply --git-repo).')
 if a.transport_manifest:
  d=json.load(gzip.open(a.transport_manifest,'rt'));assert d['transport_only'] and not d['source_read_credit']
  pairs=[(x['reference'],x['expected_sha256'],x['bytes']) for x in recovered]+[(j('BASE-REGISTRATION-RECOVERY.json')['reference'],sha(base),len(base))]
  for reference,h,n in pairs:
   suffix=reference.removeprefix('target/726-audit-adler-20261027/');assert any(e['path'].endswith(suffix) and e['sha256']==h and e['bytes']==n for e in d['entries'])
  print('PASS four supplied same-machine transport-metadata matches, including one newly measured name-only identity; no independent custody or source credit.')
 else:print('NOT REPEATED: transport correspondence (supply --transport-manifest).')
 if a.live_ledger:ledger_check(a.live_ledger.read_bytes());print('PASS separately supplied exact 31e ledger anchor and nine selected objects.')
 else:print('NOT REPEATED: separately supplied ledger anchor (supply --live-ledger).')
 print('LIMITS: integrity, recorded timestamps and text evidence do not prove comprehension, all admission paths, policy, runtime behavior, global alias disposition, product validation or independent custody.')
if __name__=='__main__':main()
