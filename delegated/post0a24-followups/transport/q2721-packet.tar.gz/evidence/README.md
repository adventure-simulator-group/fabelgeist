# q2721 source-only evidence packet

Read `REPORT.md` for the source assessment, historical chronology,
attribution, relationships and limits. `SOURCE-READ-RECEIPT.json` and the
numbered displays distinguish the full q2721 read from bounded support.
`DISPLAY-QUALIFICATIONS.md` records locator limits. This is not a closure,
repair or product validation report.

Run `python3 VERIFY-EVIDENCE.py` for the flat packet and captured evidence.
Optional `--git-repo`, `--transport-manifest` and `--live-ledger` supply the
respective object store, same-machine recovered transport manifest and exact
31e ledger anchor for stronger membership checks. The separately sealed scan
receipt binds the manifest and records its privacy checks; see that receipt
for its private-input dependency and limitations. Historical credit does not
transfer between lenses or revisions, and the original 059 status remains
historical.
