# Preflight qualification

Before `MANIFEST.json` existed, an in-memory preflight of
`VERIFY-EVIDENCE.py` replaced only its `check_manifest()` call with a no-op.
Its generic first PASS line still mentioned the manifest, but did not check
it in that preflight. The separate sealed `VERIFY-STANDALONE` and
`VERIFY-FULL` runs execute the unmodified script after manifest creation and
are the only runs here that assert its integrity. The preflight and final
checks execute evidence verification only, not product code.
