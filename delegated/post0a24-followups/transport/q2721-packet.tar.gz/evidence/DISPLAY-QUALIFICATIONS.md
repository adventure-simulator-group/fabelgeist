# Display and locator qualifications

- `SOURCE-READ-RECEIPT.json` distinguishes actual numbered displays from full
  captures, and computes unique displayed coverage; capture-only ranges and
  structurally scanned catalog files have no personal line-reading credit.
- A locator is navigation, not a body read. The associated registered results
  retain hit totals and the bounded printed selections. Early
  `validate_quest_generation_authority` navigation found 36 hits and printed
  the first 30; it is explicitly incomplete. Other capped locator results
  preserve their own totals and any truncation. No broad negative inference is
  based on a truncated selection.
- Initial navigation for developer entrypoints also located source text in
  test string literals in `mission_bootstrap.rs` at 2693, 2722 and 2881.
  These are not production calls. The later independently registered
  `:2421–2512` production path supplies the cited gate and call context.
- The authored scan only covers the three top-level `content/dialogue/*.yaml`
  inputs selected by the pinned `build.rs:526–555`; JSON-subset decoding and
  recursive structural search are evidence-only operations, not the product
  authoring parser or a build. The absence of Multi and choice investigation
  actions is limited to these static inputs. Missing prompt fields in the
  structural result are absent keys, not interpreted default values.
- 059 exact queue slices have original and reconstructed stream identities;
  the separate ledger objects are reserialized and are not original byte
  slices. The 31e ledger rows are likewise reserialized. Current source
  attribution is independent of the historical readers.
- Recorded UTC registration/display file modification time order is useful
  provenance but is not an independently trusted clock or proof of reading.
  No product code, fixtures, test, macro, shader, build or probe was run.
