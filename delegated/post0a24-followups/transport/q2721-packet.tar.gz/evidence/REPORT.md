# q2721: independent Lens 5 dialogue-binding review

This is a fresh, bounded source-only aggregate-state review by
`/root/verifier_scope` of `OBLIGATION-ROOT-L3-EXT-0002-LENS-05`. The
coordinator owns obligation disposition, cross-lens reconciliation, repair
ledger and checkpoint publication. This packet neither assigns a unique defect
count nor claims a whole lens, native behavior, implementation gate or product
validation is complete. No product code, test, fixture, macro, build script,
renderer or runtime probe was executed.

## Source identity and historical attribution

The original 059 queue entry at revision
`56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e`, `/entries/2721`, requires
independent Lens 5 qualification or reading of lines 1–1095 of
`crates/adventuresim-stdb-module/src/strategic/dialogue_bindings.rs` at frozen
`6533e444fa37552927070cc8d8190907fd3b413e`; its assessed ranges are empty,
foreign body credit and body/population credit zero, and implementation gate
false. It also requires the full range at e275
`e2755a732c84e67296b5e3441a4259a84f461b2f`. The authoritative audit source is
`95e63628f9d70b8dd6e6fede64334696c6995009` (95e). All three file versions
are byte-identical: SHA-256
`775c9d22ecc0823474a0e4941da7a73e63c7fe7ca755ffc29cc479d95c611dfe`,
Git blob `8cff95893978abd26ca4493f9d353343f57d8e68`, 40,825 bytes, EOF 1095.
This equality is limited to this exact file. Supporting files in the packet
are also individually compared between e275 and 95e; it is not a whole-tree
identity claim.

The original queue stream and the separately identified reconstructed 059
stream differ, while the exact q2721 object slices are byte-identical. Three
hash-cited historical records were recovered and verified individually; they
show the root's original prospective and personal Lens 3 read of lines
1–1095 at 6533, followed by an e275 same-Lens 3 evidence reuse registration,
not a fresh current read. A cited earlier Adler Lens 11 registration concerns
lines 216–240. Its historical citation names the record without a full-file
hash: this packet records a newly measured full-file hash and transport match,
not retrospective authentication. None of these other-lens records confers
Lens 5 body or population credit or is promoted into checkpoint 3821. The
original 059 disposition remains a historical statement; this fresh work does
not rewrite it. The direct three hash-cited records and the name-only record
match same-machine transport metadata 4/4, which is not independent custody;
transitive completeness is not claimed.

The separate prospective 95e registration and this reviewer's eight numbered,
untruncated displays cover the whole required file under Lens 5. Supporting
construction and consumer ranges are independently registered and displayed;
82 displays cover 6,973 distinct source lines across 21 captured files, with
19,479 other captured source lines unread. Every precisely planned display
window was covered; broad capture registrations do not imply a complete read.
See `SOURCE-READ-RECEIPT.json` for exact ranges and attribution. Recorded times
and hashes can support display ordering and integrity, but cannot prove human
or agent comprehension. Three authored JSON-subset YAML files were structurally
scanned, not counted as line-by-line personal source reads.

## Aggregate-state observations

1. **Claim-to-fragment alignment and admitted producer shape.** The obligated
   file `dialogue_bindings.rs:75–139` derives witness claims from the selected
   session/event and requires resolved-fragment count, sequence and text to
   agree. Withheld output is separately constructed with an absent source per
   resolved fragment at `:142–213`. The authority path inspected in
   `investigation/claims.rs:464–519,564–623`,
   `authority_model.rs:71–136` and `quest_generation/validation.rs:724–760`
   validates the generated authority and requires a nonempty trimmed challenge
   occurring exactly once in spoken text. It therefore limits an apparent
   empty-spoken-fragment misalignment for accepted authority; do not count that
   initial hypothesis as a demonstrated defect. This does not exhaust other
   authority admission paths or native/transaction semantics.

2. **Bindings and effect authority.** `dialogue_bindings.rs:301–588` derives
   and checks provenance, recipient, matching action and evidence; `:590–849`
   selects a unique relevant case/objective/recipient and carries session,
   actor, party, action, scope and revision into the binding. In the selected
   relying path, `dialogue_effects.rs:300–397,404–535` reloads and rechecks
   authority and the custody version before recording consumption. These are
   concrete guards, not a proof for every producer, mutation, rollback or
   alternate consumer. The public-case aggregation and topic refresh at
   `dialogue_bindings.rs:852–1065` reject multiple distinct public cases and
   bind eligible response/choice actions. A normal topic request in
   `dialogue_prompts.rs:115–148,222–245` does not use the same option check as
   its corpse branch. Whether a future otherwise admitted prompt choice with
   an unavailable investigation binding should be materialized is an open
   policy/reach question, not a demonstrated current failure: the statically
   inspected catalog has no investigation action in a choice, and an
   unbound direct action is rejected. Rollback was not assessed.

3. **Conditional ballot aggregate outside the obligated file.** The selected
   `dialogue_prompts.rs:430–505` uses a set to reject duplicate selected IDs
   and enforces cardinality, but stores the submitted sequence. Unanimity
   compares the sequences; independently valid multi-choice ballots `[a,b]`
   and `[b,a]` therefore compare unequal at that source operation. If Multi is
   intended to denote an unordered choice set, this is a relationship to
   adjudicate. If order is intended to be meaningful, the same observation may
   be correct. The AllRespondents branch chooses a single highest-voted choice,
   another Multi resolution policy question. The inspected admission at
   `adventuresim-dialogue/src/lib.rs:711–735` and build source at
   `adventuresim-dialogue/build.rs:348–375` constrain mode/cardinality but do
   not visibly relate resolution mode to Multi. The three catalog files contain
   eight prompt objects and no Multi: no current authored product occurrence,
   runtime incident, browser reachability or global producer conclusion is
   established. Published ledger `REVIEW-DIALOGUE-ACTION-RECEIPT-001` already
   leaves ballot ordering and retry policy open; its receipt/request first
   operation is distinct, so no automatic alias or count is assigned.

4. **Conditional duplicate proposition occurrence.** The obligated file's
   `:86–139` can construct separately ordered claims and verify each against
   its fragment. The selected `social.rs:911–960` persistence path skips a
   later assessment for the same `(session, observer, event_sequence,
   proposition_id)` without including claim order. The web mapping at
   `routes/dialogue.rs:1366–1418` and `routes/dialogue/claims.rs:16–26`
   associates each claim by event sequence, claim order and displayed text.
   If an admitted witness emitted two separately ordered challenge fragments
   with the same proposition in one event, the latter would have no matching
   persisted assessment at this selected mapping boundary. Whether distinct
   occurrences should receive separate assessments is a policy question, and
   no complete accepted duplicate-proposition definition or live occurrence
   has been established. The developer definition admits a witness vector,
   checks some declared IDs and individually checks testimony references
   (`developer_quest.rs:42–69,301–470,592–600,1022–1053,1179–1188,
   1222–1235,1456–1472,1726–1779`); selected validation
   (`quest_generation/validation.rs:724–805`) does not visibly enforce this
   within-witness uniqueness. Other diagnostics and admission constraints
   remain unread. The developer entry is development-gated
   (`mission_bootstrap.rs:2421–2512`; `routes/developer_quests.rs:267–275,
   311–360`). Selected normal generation builds distinct proposition IDs for
   its primary witness and reuses one for a different witness; the latter alone
   is not the hypothesized same-event collision. Do not infer all generators
   exclude it. `PL13-260-INVESTIGATION-CORRECTION-PROPOSITION-IDENTITY-PENDING`
   and historical q2338 concern a different cross-proposition correction
   relationship, with distinct first operation; neither is silently aliased or
   counted with this question.

5. **Other retained relationships.** The file's `:216–267` and
   `adventuresim-dialogue/src/lib.rs:290–327,482–542,663–686,711–735`
   align authored/resolved fragments and restrict the validated testimony slot.
   The separately read start/choice paths and ordinary one-to-one runtime slots
   limit the apparent multi-slot case; unvalidated callers remain open. The
   fallback at `dialogue_bindings.rs:619–630` selects an NPC from the session
   set; session construction can have multiple NPC roles
   (`dialogue_sessions.rs:152–207`). The inspected catalog's six investigation
   actions occur in three one-NPC conversations, while its multi-NPC example has
   no such action. This establishes neither a current multi-NPC mismatch nor
   its absence in other inputs; intended recipient and future-admission policy
   remain open. This file's functions are all displayed, but full producer,
   consumer, persistent-state, rollback, native and cross-lens populations are
   not exhausted.

## Related records and recovery

Original 059 q180, q230 and q2338 are preserved as separate exact original and
reconstructed slices. Four related historical ledger selections are
reserialized structurally equal objects, not byte-exact ledger slices; their
whole original/reconstructed streams differ. The selected published ledger
is the exact 31e checkpoint
`31e130bfa8f8914f759c7d5cddc3db92962704c7`, stream SHA-256
`b10132337fad5f1cf91fbd23c01a3ed4330793e79aac65ec4921aece591d1c50`,
1,072 entries. Selected rows 14, 91, 104, 127, 170, 749, 758, 759 and 773 are
reserialized snapshots, not raw byte slices; row 773 is a separate referral
source-shape question. The selected 059 and 31e records retain their original
revision, reader and disposition. Relations are leads for central
reconciliation, not implicit aliases, new counts, or credits.

`VERIFY-EVIDENCE.py` verifies local integrity and, when supplied, independently
checks the named Git objects, transport metadata and exact 31e ledger anchor.
The packet retains raw source and historical selections for recovery; Git
object availability and same-machine transport metadata are external replay
dependencies, not independent public custody. Recorded registrations,
selectors and captures do not establish every transitive historical record.
The privacy scan and its separate receipt document their bounded pattern and
private-input checks; they cannot establish absence of all sensitive data.
Nothing here authorizes implementation, testing, a product run or a
checkpoint-3821 promotion.
