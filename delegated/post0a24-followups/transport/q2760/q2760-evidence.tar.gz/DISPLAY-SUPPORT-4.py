import pathlib,json,sys,hashlib,datetime
p=pathlib.Path(__file__).resolve().parent;name=sys.argv[1];lo=int(sys.argv[2]);hi=int(sys.argv[3]);plan=json.loads((p/'SUPPORT-DISPLAY-PLAN-4.json').read_text());matches=[x for x in plan['items'] if x['file']==name and [lo,hi] in x['display_ranges']]
if len(matches)!=1:raise ValueError('not registered')
b=(p/name).read_bytes()
if hashlib.sha256(b).hexdigest()!=matches[0]['sha256']:raise ValueError('identity mismatch')
lines=b.decode().splitlines()
if not 1<=lo<=hi<=len(lines):raise ValueError('range')
v=''.join(f'{i:5}\t{lines[i-1]}\n' for i in range(lo,hi+1));out='VIEW-'+name+'-'+str(lo)+'-'+str(hi)+'.txt'
with (p/out).open('x') as f:f.write(v)
receipt={'registration':'SUPPORT-DISPLAY-PLAN-4.json','source':name,'range':[lo,hi],'view':out,'sha256':hashlib.sha256(v.encode()).hexdigest(),'displayed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'truncated':False}
with (p/(out+'.receipt.json')).open('x') as f:json.dump(receipt,f,indent=2)
print('SOURCE',matches[0]['revision'],matches[0]['path'],lo,hi);print(v,end='')
