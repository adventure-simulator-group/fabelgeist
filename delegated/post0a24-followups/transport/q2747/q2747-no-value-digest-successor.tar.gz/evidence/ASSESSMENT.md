# q2747: independent Lens 7 redundant-authority assessment

## Recovered history and independent source scope

Recovered 059 queue entry 2747 is
`OBLIGATION-ROOT-L3-EXT-0004-LENS-07`. The registered 6533 file is
`crates/adventuresim-tactical-client/src/presentation/materials.rs`, SHA-256
`ccff04d8f8288d9f670097d34527841e9a8f2f91472692b25e5dd53b85c5aba8`,
1–35 of 35 lines. Its exact original source object was recovered from the
protected collection and matched by SHA-256. Raw commit-to-tree-to-blob proofs
individually establish the same bytes at 6533 and e275. The historical receipt
attributes a fresh, untruncated full-body read to the root under Lens 3; that
read confers no Lens 7 credit. The current subagent separately registered and
displayed all 35 historical lines under Lens 7. Per-file identity is not
whole-tree identity and does not transfer other reviewers' work.

The pinned 95e body is 40 lines, SHA-256
`e12ef47cca13c862efbcd2db69dbde2408609cdf34a3afd48842d377fc3aa6a0`,
independently proved and displayed 1–40 under Lens 7. The bounded diff replaces
the two standard pebble material registrations with chunk-instanced material
plugins and adds an instanced vista-tree material registration. No historical
body or reviewer credit is promoted to checkpoint 3821.

## Plugin and ownership trace

`materials.rs:7–38` groups distinct material and presentation plugins, then
installs `BakedTexturesPlugin`. `presentation/mod.rs:227–256` adds the material
plugin after the instanced-grass plugin and chains texture/material startup
systems. `chunk_instancing.rs:39–93` implements the selected generic material
plugin: the source checks whether the common `ChunkInstancingPlugin` has been
added and initializes distinct per-material stores, extraction and render
queues. `instanced_grass.rs:130–142` registers different grass/shrub material
types. Source enumeration and this guard do not establish duplicate plugin
registration or independently competing authorities; Bevy's native plugin
semantics and actual application execution were not examined.

The door and window plugins (`doors.rs:15–25`, `windows.rs:11–17`) both call
`init_resource` for the same `ClosureMeshes` type and add separate observers.
This is not, by itself, proof of two independent caches; the framework's
resource-init behavior is outside the inspected source. The tuple-splitting
comment expresses the author's stated framework-arity reason, not newly
verified SDK behavior.

## Existing celestial-material relationship

`sky/mod.rs:208–300` owns a presented snapshot derived from the active scene's
environment. `celestial_materials.rs:14–76` owns the update into multiple
material stores. It skips entirely when the snapshot resource is unchanged;
even after a changed snapshot it skips when both values remain within the
stored last-written tolerance. This cached pair is global to the updater and
is not keyed by material asset identity. `loose_stone/spawn.rs:78–122` creates
a new pebble billboard material with fixed default lighting and ambient;
`ground_scatter/mod.rs:335–343,410–453` shows the scene-scatter path to that
constructor. `materials.rs:27–28` installs the corresponding chunk material
plugins. `presentation/mod.rs:278–303` orders the updater after the celestial
snapshot update and pending trees; it does not specify relative ordering against
`present_ground_scatter` in the displayed schedule.

If a new eligible material is created after the last celestial write, and its
default differs from the current snapshot while the resource remains unchanged
or its next change is below tolerance, the displayed updater will not bring the
new asset into step until a sufficiently different snapshot is written. This
is a conditional source-level lifecycle relationship: actual Bevy scheduling,
asset timing, field equality, rendered impact and supported scene witness were
not observed. The earlier 95e source assessment already records this same
named concern as 31e row 251 `REVIEW-CELESTIAL-MATERIAL-NEW-ASSET-001`; this
review independently corroborates it, not a new defect or count. Row 250's
pebble chunk extent is a separate question. The earlier report's shader and
other source reads retain their original attribution; this review did not read
or execute shader source.

A connected later repair needs to give each newly eligible material the current
snapshot while preserving the intended suppression of unnecessary subsequent
asset writes. The exact mechanism and runtime acceptance remain for central
ledger reconciliation and future work; none was implemented or validated here.

## Vista source and cache dependency question

The selected `vista.rs:80–100,141–168` passes the current optional prepared
asset into `vista/details.rs:221–255`, which selects a fixed vista variant seed
and competition 0.5, obtains a species-dependent cached entry and derives the
card height from that entry's provenance. `tree/presentation.rs:81–91,781–817`
keys `VistaTreePresentationCache` by seed, rounded competition and species,
and returns an existing mesh/material/provenance entry before considering the
current optional prepared asset. The cache entry keeps those three outputs
together. `vista/tree_cards.rs:81–115,121–159` groups by source material and mesh
and carries the first matching group's provenance-derived height. No selected
caller is shown producing conflicting heights for the same cache entry, so the
height grouping is an open invariant, not a demonstrated defect. In particular,
the traced production caller supplies fixed competition; no quantization
collision is asserted for it.

`PreparedTreeImpostorAssets` obtains an optional current Bevy asset
(`impostor_assets.rs:202–262`); `demo_lifecycle.rs:5–20` resets the vista tree
cache on demo-scene clearing, while the separate scene-entity clearing path is
intended to retain preparation. If a supported later call can use the same
cache key after the prepared asset's availability or bytes change without an
applicable reset, the earlier cached entry is returned. Whether such a
transition is supported/reachable, the assets can differ, another invalidation
exists, or a visible consequence occurs remains unproved. This is an open
cache-authority question, not a claimed defect or exact alias. 31e rows 258,
260, 262 and 274 concern related tree-bake provenance, prepared admission,
focused variant oracle and vista near-distance questions; their original
reviewers, revisions, scopes and open conditions remain distinct.

## Custody and limits

The 6533 registration, original root Lens3 read and e275 same-lens registration
were copied from protected recovered evidence and matched their recorded whole
file hashes. The earlier `adler/REGISTRATION-ADLER-275.json` was located by an
exact filename search and its observed hash matched the reference in recovered
`adler/READ-L11-206.json`; the latter's identity is an observed whole-file hash,
not a fabricated external expected hash. That prior Lens11 record expressly
limits the old plugin-source observation and transfers no other-lens coverage.
The prior current celestial assessment was copied with observed whole-file hash
and its limits preserved; it is distinct from this new independent read.

Physical-checkout navigation and ledger term searches are locator aids, not
pinned source credit. All displayed dependencies were independently matched to
95e path/blob and inventory and registered before display. A combined
navigation response and a separate ledger-ID display were truncated by the
tool wrapper; full navigation artifacts were retained, and relevant portions
were reread. Three regex-registration Python warnings and one orchestration
syntax failure occurred before source actions and are recorded. The published
31e ledger snapshot is a bounded historical view, not later global alias
inventory. The 73 nontext/no-positive-EOF and missing checkpoint 3821
qualifications remain. No product code, parser, fixture, shader, renderer, build,
test or runtime probe was executed; publication and product files were not
edited.
