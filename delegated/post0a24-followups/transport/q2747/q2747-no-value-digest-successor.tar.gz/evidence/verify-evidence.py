#!/usr/bin/env python3
"""Verify q2747 source evidence and registered displays, not product behavior."""
import argparse,datetime,difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(n):return json.loads((P/n).read_text())
def entries(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for n in ('commit-6533','commit-e275','commit-95e','original-queue','reconstructed-queue','current-inventory','ledger-31e'):ap.add_argument('--'+n,type=Path,required=True)
 a=ap.parse_args();m=load('MANIFEST.json');actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and str(x.relative_to(P))!='MANIFEST.json'};assert actual==set(m['files'])
 for n,x in m['files'].items():
  b=(P/n).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],n
 q=load('QUEUE-EXTRACTION.json');assert q['zero_based_array_index']==2747 and q['exact_byte_equal'];parts=[]
 for i,path in enumerate((a.original_queue,a.reconstructed_queue)):
  b=path.read_bytes();r=q['records'][i];assert sha(b)==r['queue_sha256'];part=b[r['start']:r['end']];assert len(part)==r['bytes'] and sha(part)==r['entry_sha256'] and part==(P/f'QUEUE-ENTRY-{i}.json').read_bytes();assert json.loads(part)==json.loads(b)['entries'][2747];parts.append(part)
 assert parts[0]==parts[1];entry=json.loads(parts[0]);assert entry['lens']==7 and entry['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,35]]
 for x in load('HISTORY-SELECTED.json'):
  b=(P/'history'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert json.loads(b)['rows'][int(x['pointer'].split('/')[-1])]==x['row']
 meta=load('HISTORY-ADDITIONAL-METADATA.json')
 for x in meta['historical']:
  b=(P/'history/adler'/x['name']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256_observed']
 reg=json.loads((P/'history/adler/REGISTRATION-ADLER-275.json').read_bytes());read=json.loads((P/'history/adler/READ-L11-206.json').read_bytes());ctx=load('HISTORY-CONTEXT.json');assert ctx['registration']==reg and ctx['lens11_matches'][0]['value']==read['connected_reinspection'][1];assert sha((P/'history/adler/REGISTRATION-ADLER-275.json').read_bytes())==read['connected_reinspection'][1]['registration_sha256']
 pb=(P/'history/PRIOR-PEBBLE-CELESTIAL.json').read_bytes();assert len(pb)==meta['prior_assessment']['bytes'] and sha(pb)==meta['prior_assessment']['sha256_observed'];pr=json.loads(pb)
 for k,v in ctx['prior_assessment'].items():assert pr[k]==v
 commits={};ids={x['revision']:x for x in load('COMMIT-ANCHOR-IDENTITIES.json')}
 for rev,path in [('6533e444fa37552927070cc8d8190907fd3b413e',a.commit_6533),('e2755a732c84e67296b5e3441a4259a84f461b2f',a.commit_e275),('95e63628f9d70b8dd6e6fede64334696c6995009',a.commit_95e)]:
  b=path.read_bytes();assert oid('commit',b)==rev and len(b)==ids[rev]['bytes'] and sha(b)==ids[rev]['sha256'];commits[rev]=b.split(b'\n',1)[0].split()[1].decode()
 inventory=a.current_inventory.read_bytes();lines=inventory.decode().splitlines();proof=load('PROOF-RESULT.json');assert sha(inventory)==proof['inventory_sha256']
 def verify_path(x,tree_root):
  cur=commits[x['revision']];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
  for part,item in zip(parts,x['chain']):
   b=(P/tree_root/(cur+'.tree')).read_bytes();assert oid('tree',b)==cur;mode,nxt=entries(b)[part];assert item=={'tree':cur,'component':part,'mode':mode,'oid':nxt};cur=nxt
  assert cur==x['blob'];return cur
 old=(P/'evidence/recovered-6533-materials.rs').read_bytes();assert sha(old)==entry['exact_source_identities_and_assessed_ranges'][0]['source_sha256']==proof['recovered_source']['sha256'] and len(old.decode().splitlines())==35
 for x in proof['paths']:
  cur=verify_path(x,'evidence/proof/trees');b=(P/'evidence/current'/x['path']).read_bytes();assert sha(b)==x['current_candidate_sha256'] and (oid('blob',b)==cur)==x['current_candidate_matches']
  if x['path'].endswith('materials.rs'):assert (oid('blob',old)==cur)==x['historical_recovered_matches']
  if x['revision'].startswith('95e'):assert x['current_candidate_matches']
 assert len(proof['paths'])==4 and not proof['fallback_failures']
 for x in proof['current_candidates'].values():
  for row in x['inventory_rows']:assert row in lines
 count=4
 for name,root,expected in [('DEPENDENCY-PROOF.json','evidence/dependencies',13),('EXTRA-PROOF.json','evidence/extra',4),('VISTA-PROOF.json','evidence/vista',1),('CACHE-PROOF.json','evidence/cache',1),('LIFETIME-PROOF.json','evidence/lifetime',3)]:
  record=load(name);assert sha(inventory)==record['inventory_sha256'] and not record['fallback_failures'] and len(record['paths'])==expected;count+=len(record['paths'])
  for x in record['paths']:
   assert verify_path(x,root+'/trees')==x['blob'];b=(P/root/'sources'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and oid('blob',b)==x['blob'] and x['inventory_row'] in lines
 assert count==26
 def check_display(x,reg,sourcebase,windowmap):
  path=x['source'];lo,hi=x['range'];assert [lo,hi] in windowmap[path];assert datetime.datetime.fromisoformat(x['at_utc'])>=datetime.datetime.fromisoformat(reg['at_utc']);b=(P/sourcebase/path).read_bytes();ls=b.decode().splitlines();assert sha(b)==x['source_sha256'] and len(ls)==x.get('eof',len(ls));d=(f'SOURCE {path}:{lo}-{hi}\n'+''.join(f'{i:4} {ls[i-1]}\n' for i in range(lo,hi+1))).encode();assert d==(P/x['display']).read_bytes() and sha(d)==x['display_sha256']
 reg=load('REGISTRATION-003.json');receipts=load('DISPLAY-RECEIPTS.json')
 for x,w in zip(receipts['displays'],reg['windows']):
  assert x['source']==w['source'] and x['revision']==w['revision'] and x['range']==w['range'] and datetime.datetime.fromisoformat(x['at_utc'])>=datetime.datetime.fromisoformat(reg['at_utc']);b=(P/x['source']).read_bytes();ls=b.decode().splitlines();lo,hi=x['range'];d=(f'SOURCE {x["source"]} REVISION {x["revision"]}:{lo}-{hi}\n'+''.join(f'{i:4} {ls[i-1]}\n' for i in range(lo,hi+1))).encode();assert sha(b)==x['source_sha256'] and len(ls)==x['eof'] and d==(P/x['display']).read_bytes() and sha(d)==x['display_sha256']
 before=old.decode().splitlines(keepends=True);after=(P/reg['windows'][1]['source']).read_text().splitlines(keepends=True);d=''.join(difflib.unified_diff(before,after,fromfile='6533-and-e275/materials.rs',tofile='95e/materials.rs')).encode();assert d==(P/'MATERIALS-DIFF.txt').read_bytes() and sha(d)==receipts['diff_sha256']
 reg=load('REGISTRATION-006.json');rs=load('DEPENDENCY-DISPLAY-RECEIPTS.json');assert len(rs)==15
 for x in rs:check_display(x,reg,'evidence/dependencies/sources',reg['windows'])
 reg=load('REGISTRATION-011.json');rs=load('TRACE-DISPLAY-RECEIPTS.json');assert len(rs)==6
 for x in rs:
  w=reg['existing_windows'] if x['source_folder']=='evidence/dependencies/sources' else reg['extra_windows'];check_display(x,reg,x['source_folder'],w)
 reg=load('REGISTRATION-014.json');x=load('VISTA-DISPLAY-RECEIPT.json');x['display']='VISTA-DISPLAY.txt';check_display(x,reg,'evidence/vista/sources',{reg['source']:[reg['range']]})
 reg=load('REGISTRATION-017.json');rs=load('CACHE-DISPLAY-RECEIPTS.json');assert len(rs)==2
 for x in rs:check_display(x,reg,'evidence/cache/sources',{reg['source']:reg['windows']})
 reg=load('REGISTRATION-021.json');rs=load('LIFETIME-DISPLAY-RECEIPTS.json');assert len(rs)==4
 for x in rs:check_display(x,reg,'evidence/lifetime/sources',reg['windows'])
 ledger=a.ledger_31e.read_bytes();nav=load('LEDGER-31E-NAV.json');assert sha(ledger)==nav['snapshot_sha256'] and len(ledger)==nav['snapshot_bytes'];rows=json.loads(ledger)['newly_assessed_ledger']['entries'];assert len(rows)==nav['row_count']
 for filename,limit in [('LEDGER-31E-NAV.json',50),('LEDGER-VISTA-NAV.json',50),('LEDGER-CACHE-NAV.json',100)]:
  n=load(filename);assert n['snapshot_sha256']==sha(ledger) and n['row_count']==len(rows)
  for t,res in n['terms'].items():
   hits=[{'index':i,'id':row.get('id')} for i,row in enumerate(rows) if t.casefold() in json.dumps(row,ensure_ascii=False).casefold()];assert len(hits)==res['count'] and hits[:limit]==res['shown'] and (len(hits)>limit)==res['truncated']
 for filename in ('LEDGER-31E-SELECTED.json','LEDGER-CACHE-SELECTED.json'):
  s=load(filename);assert s['snapshot_sha256']==sha(ledger)
  for x in s['selections']:assert rows[int(x['pointer'].split('/')[-1])]==x['row']
 v=load('LEDGER-VISTA-SELECTED.json');assert v['snapshot_sha256']==sha(ledger) and rows[274]==v['row']
 print('Evidence verified: q2747 queue, recovered history, three commit anchors, 26 source path proofs, 31 registered displays and bounded 31e ledger relations.')
 print('No product code, parser, fixture, shader, build, test, renderer, macro or runtime probe executed.')
if __name__=='__main__':main()
