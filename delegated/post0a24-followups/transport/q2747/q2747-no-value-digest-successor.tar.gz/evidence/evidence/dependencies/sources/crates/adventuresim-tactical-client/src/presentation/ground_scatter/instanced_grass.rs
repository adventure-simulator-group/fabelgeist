//! Chunk-instanced grass for every sward in the scene.
//!
//! One instance is a multi-blade tuft whose mesh reuses the shared blade,
//! species, and pigment construction (`grass_tuft_mesh`). Placement keeps the
//! jittered cell grid, the cover gate, and the slope rejection, then
//! subdivides each eligible cell into tufts. Ground-cover coverage is sampled
//! on the CPU at placement time and packed into each instance's seed byte, so
//! the shader needs no mask texture.
//!
//! The playable scene and the vista rings differ only in where height,
//! coverage, and community come from, so both go through [`TuftPlacement`] and
//! share one lattice walk and one batching path.

use fabelgeist_determinism::Seed;

use adventuresim_building_generator::spatial_geometry::GeometryResult;
use adventuresim_tactical_core::{
    city_layout::grounding::{SupportElevation, SupportQuery},
    prelude::{SceneEnvironment, SceneGround, SceneTerrain},
    scene_coordinates::ScenePlanPoint,
};
use bevy::{color::Color, prelude::*};

use crate::presentation::{
    bps,
    chunk_instancing::{ChunkInstance, ChunkMaterialPlugin, FadeBand, InstanceReach},
    stable_text_seed,
};

use super::{
    GrassInteractor, GroundScatterLayer,
    grass::{
        GrassCommunity, GrassCommunityField, GrassCommunityProfile, GrassMeshLod, GrassSpecies,
        cell_allows_grass, configured_tuft_footprint_metres, grass_species, grass_tuft_mesh,
    },
    grass_pigment, grass_scatter_density,
};

use super::cover_mask::CoverageMask;
pub(in crate::presentation) use batches::spawn_tuft_batches;
pub(crate) use diagnostics::GrassTriangleCount;
pub(in crate::presentation) use material::TacticalGrassInstancedMaterial;

mod batches;
mod diagnostics;
mod material;
mod streams;
mod variation;

const TIERS: [GrassMeshLod; 4] = [
    GrassMeshLod::Near,
    GrassMeshLod::NearEdge,
    GrassMeshLod::Far,
    GrassMeshLod::Vista,
];

/// Maximum blade reach above a tuft root: authored ribbon height times the
/// largest height/species scaling the mesh generator produces.
const TUFT_HEIGHT_MARGIN_METRES: f32 = 1.5;
/// Roots sit on sampled terrain; this covers sinking into a steeper slope.
const TUFT_DEPTH_MARGIN_METRES: f32 = 0.3;

/// Grass rejects any site steeper than this surface normal tilt.
pub(in crate::presentation) const MINIMUM_GRASS_SLOPE_NORMAL_Y: f32 = 0.72;

/// Instance batches keyed by LOD tier, then by species within the tier.
pub(in crate::presentation) type TierSpeciesBatches =
    [[Vec<ChunkInstance>; GrassSpecies::ALL.len()]; TIERS.len()];

pub(crate) struct InstancedGrassPlugin;

/// Marks scenes whose instanced sward has been generated.
#[derive(Component)]
pub(in crate::presentation) struct InstancedGrassPresented;

/// Smoothing state for the grass interaction uniforms.
#[derive(Resource, Default)]
pub(in crate::presentation) struct InstancedGrassInteractionState {
    previous_position: Option<Vec3>,
    smoothed_velocity: Vec3,
    /// Last values written to the materials, to skip redundant asset writes
    /// (each write re-uploads the uniform and re-queues the batch).
    written: Option<(Vec3, Vec3)>,
}

/// The command buffer and asset stores a sward spawn writes through.
pub(in crate::presentation) struct GrassWorld<'a, 'w, 's> {
    pub(in crate::presentation) commands: &'a mut Commands<'w, 's>,
    pub(in crate::presentation) meshes: &'a mut Assets<Mesh>,
    pub(in crate::presentation) materials: &'a mut Assets<TacticalGrassInstancedMaterial>,
}

/// The playable scene's authoritative terrain, cover mask, and community profile.
struct ScenePlacement<'a> {
    terrain: &'a SceneTerrain,
    ground: &'a SceneGround,
    mask: CoverageMask,
    profile: GrassCommunityProfile,
    communities: GrassCommunityField,
}

/// The scene-wide pigment and wind inputs every tuft mesh and material shares.
#[derive(Clone, Copy)]
pub(in crate::presentation) struct TuftPigment {
    pub(in crate::presentation) color: Color,
    pub(in crate::presentation) density: f32,
    pub(in crate::presentation) dryness: f32,
    pub(in crate::presentation) wind_scale: f32,
}

/// Site sampling shared by playable terrain and vista heightfields. Both use
/// the same lattice walk, species selection, and batching below.
pub(in crate::presentation) trait TuftPlacement {
    /// Inclusive cell range to walk, in whole `cell_spacing` steps.
    fn lattice_bounds(&self, cell_spacing: f32) -> (IVec2, IVec2);

    /// Whether this jittered lattice cell may carry tufts at all.
    fn cell_allows(&self, cell_hash: Seed, cell: IVec2, cell_spacing: f32, jitter: f32) -> bool;

    /// Ground-cover coverage at a tuft centre; 0 leaves the site bare.
    fn coverage(&self, centre: ScenePlanPoint) -> u8;

    /// Ground height at a tuft centre, or `None` where the slope rejects grass.
    fn height(&self, centre: ScenePlanPoint) -> Option<SupportElevation>;

    /// Which community - and so which species pool - claims this site.
    fn community(&mut self, centre: ScenePlanPoint) -> GrassCommunity;
}

impl Plugin for InstancedGrassPlugin {
    fn build(&self, app: &mut App) {
        app.add_plugins((
            ChunkMaterialPlugin::<TacticalGrassInstancedMaterial>::default(),
            ChunkMaterialPlugin::<super::TacticalShrubBarkInstancedMaterial>::default(),
            ChunkMaterialPlugin::<super::TacticalShrubLeafInstancedMaterial>::default(),
        ))
        .init_resource::<InstancedGrassInteractionState>()
        .add_systems(
            Update,
            (present_instanced_grass, update_instanced_grass_interaction),
        );
    }
}

impl TuftPlacement for ScenePlacement<'_> {
    fn lattice_bounds(&self, cell_spacing: f32) -> (IVec2, IVec2) {
        let half = Vec2::new(self.terrain.width(), self.terrain.depth()) * 0.5;
        (
            (-half / cell_spacing).floor().as_ivec2(),
            (half / cell_spacing).ceil().as_ivec2(),
        )
    }

    fn cell_allows(&self, cell_hash: Seed, cell: IVec2, cell_spacing: f32, jitter: f32) -> bool {
        cell_allows_grass(
            self.terrain,
            self.ground,
            cell_hash,
            cell.x,
            cell.y,
            cell_spacing,
            jitter,
        )
    }

    fn coverage(&self, centre: ScenePlanPoint) -> u8 {
        self.mask.coverage_byte(centre)
    }

    fn height(&self, centre: ScenePlanPoint) -> Option<SupportElevation> {
        let hit = self
            .terrain
            .surface_below(SupportQuery::unbounded(centre))?;
        (hit.normal.y >= MINIMUM_GRASS_SLOPE_NORMAL_Y).then_some(hit.elevation)
    }

    fn community(&mut self, centre: ScenePlanPoint) -> GrassCommunity {
        self.communities.at(centre, self.profile)
    }
}

pub(in crate::presentation) fn prepare_scene_tufts(
    terrain: &SceneTerrain,
    ground: &SceneGround,
    environment: &SceneEnvironment,
    grass: &crate::presentation::config::GrassConfig,
    fault_scarp: Option<&adventuresim_tactical_core::prelude::TerrainLandformRecipe>,
) -> GeometryResult<TierSpeciesBatches> {
    if !grass.enabled {
        return Ok(Default::default());
    }
    let masked_ground = fault_scarp.map(|recipe| {
        super::scene_mask::scatter_ground_without_patch(ground, recipe.transition_collar())
    });
    let ground = masked_ground.as_ref().unwrap_or(ground);
    let base_seed = stable_text_seed(&environment.scene_digest).xor_word(0x6772_6173_735f_6c6f);
    let mut placement = ScenePlacement {
        terrain,
        ground,
        mask: CoverageMask::new(ground, stable_text_seed(&environment.scene_digest))?,
        profile: GrassCommunityProfile::from_environment(environment),
        communities: GrassCommunityField::new(base_seed),
    };
    let mut batches = TierSpeciesBatches::default();
    for lod in [GrassMeshLod::Near, GrassMeshLod::Far] {
        scatter_cell_tufts(
            &mut batches[lod.tier_index()],
            &mut placement,
            base_seed,
            lod,
            grass.placement.playable_patch_spacing_m,
            grass,
        );
    }
    // Reuse near placements so the near-edge crossfade does not move tufts.
    for species in GrassSpecies::ALL {
        batches[GrassMeshLod::NearEdge.tier_index()][species.index()] =
            batches[GrassMeshLod::Near.tier_index()][species.index()].clone();
    }
    scatter_cell_tufts(
        &mut batches[GrassMeshLod::Vista.tier_index()],
        &mut placement,
        base_seed.xor_word(0x7669_7374_615f_6c6f),
        GrassMeshLod::Vista,
        grass.placement.vista_patch_spacing_m,
        grass,
    );
    Ok(batches)
}

/// The geometric reach of ground scatter around its root: `footprint`
/// metres sideways, plus the blade height margins.
pub(super) fn ground_scatter_reach(footprint: f32) -> InstanceReach {
    InstanceReach {
        horizontal: footprint,
        above: TUFT_HEIGHT_MARGIN_METRES,
        below: TUFT_DEPTH_MARGIN_METRES,
    }
}

/// Walks the jittered placement cells and fills per-species instance vectors
/// with tuft placements.
pub(in crate::presentation) fn scatter_cell_tufts(
    species_batches: &mut [Vec<ChunkInstance>; GrassSpecies::ALL.len()],
    placement: &mut impl TuftPlacement,
    base_seed: Seed,
    lod: GrassMeshLod,
    cell_spacing: f32,
    grass: &crate::presentation::config::GrassConfig,
) -> u32 {
    let (minimum, maximum) = placement.lattice_bounds(cell_spacing);
    let side = match lod {
        GrassMeshLod::Near => grass.lod.near.native_tufts_per_cell_side,
        GrassMeshLod::NearEdge => grass.lod.near_edge.native_tufts_per_cell_side,
        GrassMeshLod::Far => grass.lod.far.native_tufts_per_cell_side,
        GrassMeshLod::Vista => grass.lod.vista.native_tufts_per_cell_side,
    } as i32;
    let footprint = configured_tuft_footprint_metres(lod, grass);
    let mut emitted = 0_u32;
    for z in minimum.y..=maximum.y {
        for x in minimum.x..=maximum.x {
            let cell_hash = streams::CELL.seed(base_seed, &[x as u32 as u64, z as u32 as u64]);
            if !placement.cell_allows(
                cell_hash,
                IVec2::new(x, z),
                cell_spacing,
                grass.placement.jitter_fraction,
            ) {
                continue;
            }
            let cell_origin = Vec2::new(x as f32, z as f32) * cell_spacing
                - Vec2::splat((side - 1) as f32 * 0.5 * footprint);
            for tuft_z in 0..side {
                for tuft_x in 0..side {
                    let variation = variation::TuftVariation::new(
                        streams::TUFT.seed(cell_hash, &[tuft_x as u64, tuft_z as u64]),
                    );
                    let jitter = variation.jitter * footprint * 0.35;
                    let centre =
                        cell_origin + Vec2::new(tuft_x as f32, tuft_z as f32) * footprint + jitter;
                    let Some(centre) = ScenePlanPoint::from_metres(centre) else {
                        continue;
                    };
                    let coverage = placement.coverage(centre);
                    if coverage == 0 {
                        continue;
                    }
                    let Some(height) = placement.height(centre) else {
                        continue;
                    };
                    let community = placement.community(centre);
                    let species = grass_species(community, variation.species);
                    species_batches[species.index()].push(ChunkInstance {
                        position: Vec3::new(centre.metres().x, height.metres(), centre.metres().y),
                        scale: 1.0,
                        rotation: variation.rotation,
                        seed: u32::from(coverage) | (variation.shader_seed << 8),
                    });
                    emitted += 1;
                }
            }
        }
    }
    emitted
}

/// Instanced counterpart of the grass portion of `present_ground_scatter`.
/// Builds the playable scene's sward once per scene, alongside the vista rings
/// that `presentation::vista` spawns from the same lattice and batching path.
fn present_instanced_grass(
    scenes: super::scene_mask::InstancedGrassSceneQuery,
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<TacticalGrassInstancedMaterial>>,
    settings: Res<crate::presentation::TacticalGraphicsSettings>,
) {
    for (entity, _scene_id, terrain, ground, environment, fault_scarp) in &scenes {
        if !settings.config.grass.enabled {
            commands.entity(entity).insert(InstancedGrassPresented);
            continue;
        }
        let started = web_time::Instant::now();
        let (grass_color, grass_dryness) = grass_pigment(environment);
        let grass_density = grass_scatter_density(
            bps(environment.canopy_bps),
            bps(environment.water_bps),
            bps(environment.cultivation_bps),
            bps(environment.weather.snow_cover_bps),
        ) * settings.config.grass.density_scale;
        let wind_scale = 0.16 + bps(environment.weather.wind_speed_bps) * 0.36;
        let grass = &settings.config.grass;
        let base_seed = stable_text_seed(&environment.scene_digest).xor_word(0x6772_6173_735f_6c6f);
        let mut batches =
            match prepare_scene_tufts(terrain, ground, environment, grass, fault_scarp) {
                Ok(batches) => batches,
                Err(error) => {
                    warn!(%error, ?entity, "Invalid instanced grass ground mask");
                    continue;
                }
            };
        spawn_tuft_batches(
            GrassWorld {
                commands: &mut commands,
                meshes: &mut meshes,
                materials: &mut materials,
            },
            &mut batches,
            "Instanced grass",
            (),
            base_seed,
            TuftPigment {
                color: grass_color,
                density: grass_density,
                dryness: grass_dryness,
                wind_scale,
            },
            grass,
        );
        tracing::info!(
            elapsed_ms = started.elapsed().as_millis(),
            "Generated instanced tactical grass"
        );
        commands.entity(entity).insert(InstancedGrassPresented);
    }
}

fn update_instanced_grass_interaction(
    time: Res<Time>,
    interactors: Query<&GlobalTransform, With<GrassInteractor>>,
    mut state: ResMut<InstancedGrassInteractionState>,
    mut materials: ResMut<Assets<TacticalGrassInstancedMaterial>>,
    settings: Res<crate::presentation::TacticalGraphicsSettings>,
) {
    let Some(position) = interactors.iter().next().map(GlobalTransform::translation) else {
        if state.written.take().is_some() {
            for (_, material) in materials.iter_mut() {
                material.interaction = Vec4::ZERO;
                material.interaction_motion = Vec4::ZERO;
            }
        }
        state.previous_position = None;
        state.smoothed_velocity = Vec3::ZERO;
        return;
    };
    let delta_seconds = time.delta_secs().max(1.0 / 240.0);
    let velocity = state
        .previous_position
        .map(|previous| ((position - previous) / delta_seconds).clamp_length_max(8.0))
        .unwrap_or_default();
    let response = 1.0 - (-delta_seconds * 10.0).exp();
    state.smoothed_velocity = state.smoothed_velocity.lerp(velocity, response);
    state.previous_position = Some(position);

    // Idle interactors converge to constants; stop dirtying material assets
    // once the written values are close enough that no motion is visible.
    if state
        .written
        .is_some_and(|(written_position, written_velocity)| {
            written_position.distance_squared(position) < 1e-6
                && written_velocity.distance_squared(state.smoothed_velocity) < 1e-6
        })
    {
        return;
    }

    let speed = state.smoothed_velocity.length();
    for (_, material) in materials.iter_mut() {
        let interaction = &settings.config.grass.interaction;
        material.interaction = position.extend(interaction.radius_m);
        material.interaction_motion = Vec4::new(
            state.smoothed_velocity.x,
            state.smoothed_velocity.y,
            state.smoothed_velocity.z,
            (interaction.minimum_push + speed * 0.11)
                .clamp(interaction.minimum_push, interaction.maximum_push),
        );
    }
    state.written = Some((position, state.smoothed_velocity));
}

/// Number of tuft columns/rows that subdivide one placement cell, per tier.
fn tufts_per_cell_side(lod: GrassMeshLod) -> i32 {
    match lod {
        GrassMeshLod::Near | GrassMeshLod::NearEdge => 12,
        GrassMeshLod::Far => 4,
        GrassMeshLod::Vista => 2,
    }
}

/// Legacy fade bands per tier: `xy` fade-in, `zw` fade-out, mirroring the
/// legacy `grass_lod_visibility` crossfade margins. The near tier's epsilon
/// fade-in keeps the dither-level math well-defined at zero distance.
///
/// `range_scale` contracts every band edge uniformly, so tier hand-offs stay
/// contiguous while the geometric sward trades reach for vertex throughput.
/// Near-tier cost scales with the square of its radius, making this the
/// single most effective grass performance lever.
fn tier_visibility_range(lod: GrassMeshLod, range_scale: f32) -> Vec4 {
    let scale = range_scale.clamp(0.35, 1.0);
    (match lod {
        // #560's legacy near band (0..14 m) splits into a full-detail field and
        // a slimmer edge ring; the ring covers most of the band's area, so most
        // near verts move to the nine-vertex 6x6 mesh. The instanced tiers
        // reproduce the legacy `grass_lod_visibility` bands so the native and
        // wasm swards fade out at the same distances (~50 m terminal).
        GrassMeshLod::Near => Vec4::new(0.0, 0.001, 4.0, 6.0),
        GrassMeshLod::NearEdge => Vec4::new(4.0, 6.0, 7.0, 14.0),
        GrassMeshLod::Far => Vec4::new(7.0, 14.0, 36.0, 44.0),
        // The vista fade-in shares the far tier's fade-out endpoints so the
        // complementary crossfade partition hands off exactly.
        GrassMeshLod::Vista => Vec4::new(34.0, 42.0, 42.0, 50.0),
    }) * scale
}

fn configured_tier_band(
    lod: GrassMeshLod,
    grass: &crate::presentation::config::GrassConfig,
) -> FadeBand {
    let tier = match lod {
        GrassMeshLod::Near => &grass.lod.near,
        GrassMeshLod::NearEdge => &grass.lod.near_edge,
        GrassMeshLod::Far => &grass.lod.far,
        GrassMeshLod::Vista => &grass.lod.vista,
    };
    FadeBand::new(
        tier.fade_in_m[0]..tier.fade_in_m[1],
        tier.fade_out_m[0]..tier.fade_out_m[1],
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::presentation::ground_scatter::grass::{grass_lod_visibility, tuft_blade_side};

    #[test]
    fn instanced_tiers_reproduce_legacy_per_cell_shoot_totals() {
        // Legacy: 96x96 near shoots, 40x40 far shoots, 24x24 vista shoots
        // per placement cell. The near-edge ring deliberately thins the
        // legacy near total to 6x6 blades per tuft past ~9 m.
        for (lod, legacy_total) in [
            (GrassMeshLod::Near, 96 * 96),
            (GrassMeshLod::NearEdge, 12 * 12 * 36),
            (GrassMeshLod::Far, 1_600),
            (GrassMeshLod::Vista, 576),
        ] {
            let side = tufts_per_cell_side(lod) as usize;
            let blades = tuft_blade_side(lod) * tuft_blade_side(lod);
            assert_eq!(side * side * blades, legacy_total, "{lod:?}");
        }
    }

    #[test]
    fn instanced_fade_bands_match_the_legacy_visibility_ranges() {
        // The legacy near band's 18..26 fade-out is owned by the near-edge
        // sub-tier; the near field hands off to the edge ring at 8..10.
        for lod in [
            GrassMeshLod::NearEdge,
            GrassMeshLod::Far,
            GrassMeshLod::Vista,
        ] {
            let range = tier_visibility_range(lod, 1.0);
            let legacy = grass_lod_visibility(lod);
            assert_eq!(range.x, legacy.start_margin.start, "{lod:?}");
            assert_eq!(range.y, legacy.start_margin.end, "{lod:?}");
            assert_eq!(range.z, legacy.end_margin.start, "{lod:?}");
            assert_eq!(range.w, legacy.end_margin.end, "{lod:?}");
        }
        let near = tier_visibility_range(GrassMeshLod::Near, 1.0);
        let edge = tier_visibility_range(GrassMeshLod::NearEdge, 1.0);
        assert_eq!(near.z, edge.x);
        assert_eq!(near.w, edge.y);
        for lod in TIERS {
            let range = tier_visibility_range(lod, 1.0);
            assert!(range.x <= range.y && range.y <= range.z && range.z < range.w);
        }
    }

    #[test]
    fn contracted_fade_bands_stay_contiguous_across_tiers() {
        for scale in [0.35, 0.6, 0.75, 1.0] {
            let near = tier_visibility_range(GrassMeshLod::Near, scale);
            let edge = tier_visibility_range(GrassMeshLod::NearEdge, scale);
            let far = tier_visibility_range(GrassMeshLod::Far, scale);
            let vista = tier_visibility_range(GrassMeshLod::Vista, scale);
            assert_eq!(near.z, edge.x);
            assert_eq!(near.w, edge.y);
            assert_eq!(edge.z, far.x);
            assert_eq!(edge.w, far.y);
            assert!(far.z >= vista.x && far.w >= vista.y);
            for range in [near, edge, far, vista] {
                assert!(range.x <= range.y && range.y <= range.z && range.z < range.w);
            }
        }
        // Out-of-range requests clamp instead of collapsing the sward.
        assert_eq!(
            tier_visibility_range(GrassMeshLod::Near, 0.0),
            tier_visibility_range(GrassMeshLod::Near, 0.35)
        );
    }

    #[test]
    fn instance_seed_low_byte_carries_placement_coverage() {
        let coverage = 173_u8;
        let seed = u32::from(coverage) | (0xdead_beef_u32 << 8);
        assert_eq!((seed & 0xff) as u8, coverage);
    }
}
