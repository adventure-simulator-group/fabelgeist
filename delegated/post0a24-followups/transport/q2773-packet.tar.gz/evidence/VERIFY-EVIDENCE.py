#!/usr/bin/env python3
"""Verify q2773 bounded source evidence only; no product execution or closure inference."""
import argparse,datetime,gzip,hashlib,json,os,pathlib,subprocess
P=pathlib.Path(__file__).resolve().parent
REV='95e63628f9d70b8dd6e6fede64334696c6995009'
OLD='e2755a732c84e67296b5e3441a4259a84f461b2f'
FROZEN='6533e444fa37552927070cc8d8190907fd3b413e'
LEDGER='31e130bfa8f8914f759c7d5cddc3db92962704c7'
LEDGER_SHA='b10132337fad5f1cf91fbd23c01a3ed4330793e79aac65ec4921aece591d1c50'
def j(n):return json.loads((P/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def union(spans):
 out=[]
 for lo,hi in sorted(spans):
  if out and lo<=out[-1][1]+1:out[-1][1]=max(out[-1][1],hi)
  else:out.append([lo,hi])
 return out
def check_manifest():
 m=j('MANIFEST.json');items=list(P.iterdir());assert all(x.is_file() and not x.is_symlink() for x in items)
 assert {x.name for x in items if x.name!='MANIFEST.json'}==set(m['files'])
 for n,v in m['files'].items():
  assert pathlib.Path(n).name==n;b=(P/n).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']
def refs(v,out):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str) and len(v['sha256'])==64:out.add((v['path'],v['sha256']))
  for x in v.values():refs(x,out)
 elif isinstance(v,list):
  for x in v:refs(x,out)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--git-repo',type=pathlib.Path);ap.add_argument('--transport-manifest',type=pathlib.Path);ap.add_argument('--live-ledger',type=pathlib.Path);a=ap.parse_args();check_manifest()
 assert sha((P/'FOCUSED-SKILL.md').read_bytes())=='964ebea7b08a545b5abcabf605c22b92ac0dbb09ed79e6f79651ea2f141a3500'
 caps=[]
 for f in sorted(P.glob('SOURCE-CAPTURES*.json')):caps.extend(json.loads(f.read_text()))
 assert len(caps)==20 and len({x['path'] for x in caps})==20;bypath={x['path']:x for x in caps};bycap={x['capture']:x for x in caps}
 for x in caps:
  b=(P/x['capture']).read_bytes();assert x['revision']==REV and sha(b)==x['sha256'] and blob(b)==x['blob'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof']
  if x['capture']=='SOURCE-000.dat':assert x['eof']==272 and x['all_three_same'] and set(x['versions'])=={REV,OLD,FROZEN} and all(z['sha256']==x['sha256'] and z['blob']==x['blob'] for z in x['versions'].values())
 assert sorted(x['capture'] for x in caps if x.get('e275_same_bytes') is False)==['SOURCE-002.dat','SOURCE-010.dat','SOURCE-013.dat','SOURCE-017.dat']
 regs={f.name:json.loads(f.read_text()) for f in P.glob('SOURCE*REGISTRATION.json')};receipt=j('SOURCE-READ-RECEIPT.json');assert len(receipt['displays'])==31;spans={x['path']:[] for x in caps}
 for x in receipt['displays']:
  lo,hi=x['range'];r=regs[x['registration']];c=bypath[x['path']];assert r['revision']==x['revision']==REV and x['registered_before_display']
  assert any(z['path']==x['path'] and z['range']==x['registered_range'] and z['range'][0]<=lo<=hi<=z['range'][1] for z in r['sources'])
  assert r['registered_utc']==x['registration_time_utc'] and datetime.datetime.fromisoformat(x['registration_time_utc'])<=datetime.datetime.fromisoformat(x['display_file_mtime_utc'])
  lines=(P/c['capture']).read_text().splitlines();assert 1<=lo<=hi<=len(lines);b=''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
  assert b==(P/x['display']).read_bytes() and sha(b)==x['sha256'];spans[x['path']].append((lo,hi))
 assert {x['path'] for x in receipt['coverage']}==set(bypath)
 for x in receipt['coverage']:
  merged=union(spans[x['path']]);assert x['personally_displayed_union']==merged and x['personal_displayed_lines']==sum(b-a+1 for a,b in merged) and x['eof']==bypath[x['path']]['eof'] and x['unread_lines']==x['eof']-x['personal_displayed_lines']
 assert union(spans[bycap['SOURCE-000.dat']['path']])==[[1,272]] and sum(x['personal_displayed_lines'] for x in receipt['coverage'])==2780 and sum(x['unread_lines'] for x in receipt['coverage'])==1615
 missing=[]
 for n,r in regs.items():
  for z in r['sources']:
   lo,hi=z['range']
   if hi==1000000:continue
   present={i for a,b in spans[z['path']] for i in range(a,b+1)};m=union([(i,i) for i in range(lo,hi+1) if i not in present])
   if m:missing.append({'registration':n,'path':z['path'],'registered_range':[lo,hi],'unread_subranges':m})
 assert not missing and receipt['precise_windows_with_unread_subranges']==missing
 ids=j('HISTORY-IDENTITIES.json');assert len(ids)==2
 for x in ids:
  b=(P/x['capture']).read_bytes();assert len(b)==x['entry_bytes'] and sha(b)==x['entry_sha256']
 b=(P/'Q2773-ORIGINAL-EXACT.json').read_bytes();assert b==(P/'Q2773-RECONSTRUCTED-EXACT.json').read_bytes();q=json.loads(b);direct=set();refs(q,direct)
 assert q['contract_id']=='OBLIGATION-ROOT-L3-EXT-0006-LENS-09' and q['lens']==9 and q['status']=='own-lens-proof-qualification-or-read-pending' and q['body_or_population_credit']==0 and not q['implementation_gate_complete']
 x=q['exact_source_identities_and_assessed_ranges'][0];assert x['revision']==FROZEN and x['source_sha256']==bycap['SOURCE-000.dat']['sha256'] and x['actual_EOF']==272 and x['required_ranges']==[[1,272]] and x['assessed_ranges']==[] and x['foreign_body_credit']==0
 x=q['exact_current_revision_revisit_requirements'][0];assert x['target_revision']==OLD and x['required_ranges']==[[1,272]] and x['body_credit']==0 and x['own_lens_evidence_still_required']
 recovery=j('RECOVERY-RESULT.json');assert len(recovery)==3 and direct=={(x['reference'],x['expected_sha256']) for x in recovery}
 nested=j('NESTED-RESULT.json');seg=j('SEGOVB-RESULT.json');assert len(nested)==2 and len(seg)==2
 for x in recovery+nested+seg:
  b=(P/x['capture']).read_bytes();h=x.get('expected_sha256') or x.get('actual_sha256');assert sha(b)==h and len(b)==x['bytes']
 assert nested[0]['expected_sha256']=='0cf8f380e9c3e6e8e8d275c256de20ed2642579c2a529e09ae229640baf5267e' and nested[1]['expected_sha256'] is None and j('TRANSPORT-RESULT.json')['matched']==j('TRANSPORT-RESULT.json')['total']==7
 assert j('HISTORICAL-001-FOCUS.json')['lens']==3 and j('HISTORICAL-001-FOCUS.json')['row']['fresh_personal_ranges']==[[1,272]] and j('NESTED-FOCUS.json')['receipt_metadata']['lens']==11 and j('SEGOVB-FOCUS.json')['record0_meta']['lens']==12
 related=j('RELATED-HISTORY-IDENTITIES.json')+j('RELATED-EXT-IDENTITIES.json');assert len(related)==16
 for x in related:assert sha((P/x['capture']).read_bytes())==x['sha256']
 for n in (67,1293,1295,1297,1299,2356,2359,2703):assert (P/f'RELATED-Q{n}-ORIGINAL.json').read_bytes()==(P/f'RELATED-Q{n}-RECONSTRUCTED.json').read_bytes()
 hist=j('HIST-LEDGER-IDENTITIES.json');assert len(hist)==2 and j('HIST-LEDGER-ORIGINAL.json')==j('HIST-LEDGER-RECONSTRUCTED.json')
 indices={228:'Q-L12-fe5aeac1436aeecbda1a',229:'ADLER-L11-CITY-GPU-PREPARATION-OUTCOME',230:'ADLER-L11-CITY-SURFACE-MATERIAL-CONTRACT',231:'ADLER-L11-CITY-STREAMING-FAILURE-OWNERSHIP',232:'REVIEW-STRATEGIC-CITY-FAILURE-READINESS-001',239:'REVIEW-REGIONAL-CITY-FINISH-GRAPHICS-IDENTITY-001'}
 for i,k in indices.items():assert j(f'LEDGER-{i}.json')['id']==k
 for n in ('DELTA-IDENTITY.json','REGIONAL-DELTA-IDENTITY.json'):
  x=j(n);b=(P/x['capture']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 print('PASS manifest, skill, 20 source identities, 31 displays, q2773, related historical slices/records, six 31e rows and captured diffs.')
 def ledger_check(b):
  assert len(b)==1457605 and sha(b)==LEDGER_SHA;rows=json.loads(b)['newly_assessed_ledger']['entries'];assert len(rows)==1072
  for i in indices:assert rows[i]==j(f'LEDGER-{i}.json')
  r=j('SHAPE-LEDGER-LOCATOR-REGISTRATION.json');assert [{'term':t,'total':len(hits:=[{'index':i,'id':x.get('id')} for i,x in enumerate(rows) if t.lower() in json.dumps(x).lower()]),'retained':hits,'omitted':0} for t in r['terms']]==j('SHAPE-LEDGER-LOCATOR-RESULT.json')
 if a.git_repo:
  env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
  def git(*args):return subprocess.check_output(['git','-C',str(a.git_repo),'--no-replace-objects',*args],env=env)
  for x in caps:
   b=git('show',f'{REV}:{x["path"]}');ob=git('show',f'{OLD}:{x["path"]}');assert b==(P/x['capture']).read_bytes()
   if x['capture']=='SOURCE-000.dat':assert ob==b and git('show',f'{FROZEN}:{x["path"]}')==b
   else:assert sha(ob)==x['e275_sha256'] and (ob==b)==x['e275_same_bytes']
  for n in ('DELTA-IDENTITY.json','REGIONAL-DELTA-IDENTITY.json'):
   x=j(n);assert git('diff','--no-ext-diff','--no-textconv',OLD,REV,'--',*x['paths'])==(P/x['capture']).read_bytes()
  streams={}
  for x in ids:
   key=(x['revision'],x['path']);b=git('show',f'{key[0]}:{key[1]}');streams[key]=b
   assert len(b)==x['stream_bytes'] and sha(b)==x['stream_sha256'] and blob(b)==x['git_blob'] and b[x['start']:x['end']]==(P/x['capture']).read_bytes() and json.loads(b)['entries'][2773]==q
  for x in related:
   b=streams[(x['revision'],'baseline-059/queue.json')];assert b[x['start']:x['end']]==(P/x['capture']).read_bytes() and json.loads(b)['entries'][int(x['selector'].split('/')[-1])]==j(x['capture'])
  for x in hist:
   b=git('show',f'{x["revision"]}:{x["path"]}');assert len(b)==x['stream_bytes'] and sha(b)==x['stream_sha256'] and json.loads(b)['discovery_findings_and_dependencies'][x['key']]==j(x['capture'])
  ledger_check(git('show',f'{LEDGER}:BASELINE-95E-20261110.json'))
  for stem in ('LOCATOR','LOCATOR-EXT','STATE-LOCATOR','WIRE-LOCATOR'):
   reg=j(stem+'-REGISTRATION.json');stored=j(stem+'-RESULT.json')
   for x in stored:
    args=['grep','-n','-F',x['pattern'],REV,'--']+([':!*.lock'] if stem=='WIRE-LOCATOR' else [reg['scope']]);r=subprocess.run(['git','-C',str(a.git_repo),'--no-replace-objects',*args],env=env,capture_output=True,text=True);assert r.returncode in (0,1);lines=r.stdout.splitlines();assert lines==x['retained'] and len(lines)==x['total'] and x['omitted']==0
  print('PASS Git object store: 95e/e275 source and diffs, frozen scope, both 059 queue/ledger streams, 31e ledger and source locators.')
 else:print('NOT REPEATED: Git membership and source locators (supply --git-repo).')
 if a.transport_manifest:
  d=json.load(gzip.open(a.transport_manifest,'rt'));assert d['transport_only'] and not d['source_read_credit']
  for x in recovery+nested+seg:
   b=(P/x['capture']).read_bytes();h=x.get('expected_sha256') or x.get('actual_sha256');suffix=x['reference'].removeprefix('target/726-audit-adler-20261027/');assert any(e['path'].endswith(suffix) and e['sha256']==h and e['bytes']==len(b) for e in d['entries'])
  print('PASS seven same-machine transport matches; one is newly measured from a name-only citation, not independently authenticated custody.')
 else:print('NOT REPEATED: transport correspondence (supply --transport-manifest).')
 if a.live_ledger:ledger_check(a.live_ledger.read_bytes());print('PASS supplied exact 31e ledger and six selected objects.')
 else:print('NOT REPEATED: supplied ledger anchor (supply --live-ledger).')
 print('LIMITS: hashes, timestamps and source text do not prove comprehension, all writers, policy, native behavior, global aliases, product validation or independent custody.')
if __name__=='__main__':main()
