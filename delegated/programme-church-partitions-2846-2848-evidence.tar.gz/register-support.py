from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';root='crates/adventuresim-building-generator/src/'
plans=[('orchestration','generator/orchestration.rs',[[1,20]]),('urban-church','generator/urban_church.rs',[[1,20]]),('church-assembly','generator/church_assembly.rs',[[1,50],[380,410]]),('wall-assemblies','generator/wall_assemblies.rs',[[1,85],[285,330],[620,660],[1080,1140]]),('building-program','model/building_program.rs',[[1,66]]),('generator-core','generator/core.rs',[[190,230],[280,311]])]
entries=[];pending=[]
for name,p,ranges in plans:
 path=root+p; raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':loc});pending.append((loc,raw))
(b/'support-registration.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective current support only; no historic source-role transfer. Original own earlier orchestration 1–115 and building-program 1–66 support reads are separately attributed in prior 2840–2842 packet; this new registration precedes fresh displays.','entries':entries},indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
