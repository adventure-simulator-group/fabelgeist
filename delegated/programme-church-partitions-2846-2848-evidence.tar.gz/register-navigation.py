from pathlib import Path
from datetime import datetime,timezone
import json
b=Path(__file__).resolve().parent
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','purpose':'Prospective match-only navigation for connected programme, wall span call sites and admission; outputs do not constitute full body reads or ordered-role credit.','searches':[{'patterns':['resolved_wall_vertical_span','TIMBER_UPPER_FLOOR_SURFACE_OFFSET_METRES','TIMBER_CEILING_JOIST_ZONE_METRES'],'path':'crates/adventuresim-building-generator/src'},{'patterns':['storey_height_metres','validate_church_program'],'path':'crates/adventuresim-building-generator/src/generator'},{'patterns':['nave_bays','resolve_church_assembly'],'path':'crates/adventuresim-building-generator/src/generator/church_assembly.rs crates/adventuresim-building-generator/src/generator/urban_church.rs'}]}
(b/'navigation-registration.json').write_text(json.dumps(x,indent=2)+'\n')
