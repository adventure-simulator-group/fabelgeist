from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';root='crates/adventuresim-building-generator/src/'
plans=[('opening-heights','generator/wall_assemblies.rs',[[590,630],[950,1009]]),('opening-profile','generator/wall_derivation.rs',[[169,230]]),('opening-model','model/walls.rs',[[156,245],[320,345]])]
entries=[];pending=[]
for name,p,ranges in plans:
 path=root+p; raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';eof=len(raw.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':eof,'ranges':ranges,'local':loc});pending.append((loc,raw))
(b/'support-registration-opening.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective current producer/consumer support only. Separate opening-profile consumer support; no original-role credit.','entries':entries},indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
