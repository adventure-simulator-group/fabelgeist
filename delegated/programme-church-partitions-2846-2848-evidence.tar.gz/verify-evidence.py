'''Offline source/evidence integrity checks only; no product or fixture execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,re,tarfile
b=Path(__file__).resolve().parent
h=lambda x:hashlib.sha256(x).hexdigest()
oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
L=lambda n:json.loads((b/n).read_bytes())
reg=L('registration.json');rec=L('read-receipt.json');hist=L('historical-manifest.json');sel=L('historical-selections-reconstructed.json');proof=L('git-proofs.json');report=L('REPORT.json');ids=[2846,2847,2848];expected={2846:[[216,243]],2847:[[24,43]],2848:[[7,28]]}
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
arch=L('recovered/MANIFEST.json');rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256']==arch['registry_sha256'];assert h((b/'recovered/registry.json.gz').read_bytes())==arch['registry_gzip_sha256'];assert h((b/'recovered/objects.tar.gz').read_bytes())==arch['objects_archive_sha256'];r=json.loads(rbytes);original=r['files'];assert all(original[i]==sel['registry_rows'][str(i)] for i in ids);assert sel['snapshot_rows']==[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')]
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];cv=L('prior/COVERAGE-L01-ROLES.json');assert h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes())==sel['prior_coverage_sha256'];assert all(next(x for x in cv['roles'] if x['original_index']==i)==sel['prior_coverage_roles'][str(i)] for i in ids)
snap=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=L('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['live_comparison']['status_counts']['??']==7
catalog=L('recovered/catalog-774.json')['rows']
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];raw=(b/old['local']).read_bytes();assert t.extractfile(old['sha256']).read()==raw and h(raw)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256'];assert original[i]['material_ranges']==row['original_material_ranges']==expected[i];assert catalog[i]['origin']=='git:6533e444fa37552927070cc8d8190907fd3b413e:'+row['path'];assert (b/cur['local']).read_bytes()==raw and cur['equals_historical_object']
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==raw and c['equals_historical_object'] and not c['display_planned']
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(x['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(rr):return [i for a,z in rr for i in range(a,z+1)]
def part(n,rr,extra=[]):
 v=nums(rr)+extra;return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  x=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/x['local']).read_bytes();assert h(raw)==v['sha256']==x['sha256'] and len(raw.splitlines())==v['eof']==x['eof'];assert set(nums(x['actual_display_chunks']))==set(nums(expected[row['original_index']]));assert part(v['eof'],x['actual_display_chunks']+x['unread_complement'],x['navigation_only_lines_at_assigned_scope']);assert x['original_material_ranges']==(expected[row['original_index']] if not j else [])
planfiles=['support-registration.json','support-registration-extra.json','support-registration-opening.json'];plans={x['name']:x for n in planfiles for x in L(n)['entries']};assert len(plans)==len(rec['support'])
for x in rec['support']:
 p=plans[x['name']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==p['sha256'] and len(raw.splitlines())==x['eof'] and x['ordered_role_credit']==0;registered=set(nums(p['ranges']));actual=set(nums(x['full_line_body_displays']));assert actual=={i for i in registered if i<=x['eof']};outside=sorted(i for i in registered if i>x['eof']);assert outside==nums(x['registration_out_of_file_range']);assert part(x['eof'],x['full_line_body_displays']+x['prior_assigned_displays_of_same_pinned_path']+x['unread_complement'],x['navigation_only_lines'])
nav={}
for x in rec['navigation_output_receipts']:
 raw=(b/x['output']).read_bytes();lines=raw.decode().splitlines();assert h(raw)==x['sha256'] and len(lines)==x['saved_output_lines'];displayed=nums(x['personally_displayed_output_lines']);unread=nums(x['unread_saved_output_lines']);assert set(displayed+unread)==set(range(1,len(lines)+1)) and len(displayed)+len(unread)==len(lines)
 for j in displayed:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):(.*)$',lines[j-1]);assert m;path,num,body=m.group(1),int(m.group(2)),m.group(3);nav.setdefault(path,set()).add(num)
  for p in rec['support']:
   if p['path']==path:assert (b/p['local']).read_text().splitlines()[num-1]==body
assert {k:sorted(v) for k,v in nav.items()}==rec['navigation_actual_source_lines']
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
raw=(b/'historical/774/native-source-range-registration.jsonl').read_bytes();parts=raw.splitlines(keepends=True);native=readjsonl('historical/774/native-source-range-registration.jsonl');qual=L('registry-file-qualification.json');seg=L('historical/059/segovb/READ-L11-462.json');nativequals=readjsonl('historical/774/native-source-qualifications.jsonl');assert h(raw)=='0bb2e7a6198efc2e3db19800dd507c9a5ec91dc47c9fa388e612162d133f5bed' and len(parts)==qual['file_line_count']
for i,sid in [(2846,1767),(2847,1768),(2848,1769)]:
 ob=original[i]['scope_registration'][0];assert native[ob['row_1based']-1]==ob['original_record'];x=next(x for x in seg['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected[i]==x['assessed_ranges'] and h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{sid}.json').read_bytes())==x['registration_sha256'];root=L('historical/774/root-new-parallel-admission-'+('234' if i in [2846,2847] else '238')+'.json');rootrow=next(x for x in root['source_roles'] if x.get('registration_id')==ob['id']);assert rootrow['actual_compared_ranges']==expected[i];z=next(x for x in qual['roles'] if x['role']==i);wanted='ebc722367865e4a469f6905355ac0588906e3f3e586f24a29120cfe2f719b5e5' if i in [2846,2847] else '3a2f8040cdb9e7da7622562c0019473f69ce130f54d3dd5bfdf013ebe9e4093e';assert z['recorded_earlier_file_sha256']==ob['sha256']==wanted and z['f82_file_sha256']==h(raw) and z['parsed_row_equals_original_registry_record'] and z['complete_line_prefix_matches']==[j for j in range(1,len(parts)+1) if h(b''.join(parts[:j]))==wanted]==[]
q={x.get('id'):x for x in nativequals};assert q['NATIVE-INITIAL05-QUAL091']['qualified_material_ranges']==[[24,42]] and q['NATIVE-INITIAL05-QUAL091']['context_ranges']==[[43,43]];assert q['NATIVE-INITIAL05-QUAL093']['qualified_material_ranges']==[[7,8],[10,28]] and q['NATIVE-INITIAL05-QUAL093']['context_ranges']==[[9,9]];assert 'before registration' in q['NATIVE-INITIAL05-QUAL090']['premature_display'];assert 'unregistered' in q['NATIVE-INITIAL05-QUAL092']['premature_display']
assert L('historical/774/native-contract-groups-296.json')['new_unique_findings']==[] and L('historical/774/native-contract-groups-300.json')['new_unique_findings']==[];assert any(x.get('id')=='CAMERA-INITIAL07-F046' for x in readjsonl('historical/774/camera-findings.jsonl')) and any(x.get('id')=='CAMERA-INITIAL07-CONTRACT-239' for x in readjsonl('historical/774/camera-contracts.jsonl')) and any(x.get('id')=='CAMERA-INITIAL07-QUAL191' for x in readjsonl('historical/774/camera-qualifications.jsonl'))
p=report['prior_personal_support'];assert h((b/p['source']).read_bytes())==p['receipt_sha256'] and h((b/'prior/spiral-2840-2842/REPORT.json').read_bytes())==p['report_sha256'] and h((b/'prior/spiral-2840-2842/MANIFEST.json').read_bytes())==p['manifest_sha256'];prior=L(p['source'])['support'];assert next(x for x in prior if x['name']=='orchestration')['full_line_body_displays']==[[1,115]] and next(x for x in prior if x['name']=='building-program')['full_line_body_displays']==[[1,66]];assert all(x['ordered_role_credit']==0 for x in prior)
assert L('prior/ASSESSMENT-L01-CHURCH-SAFEGUARDS-95E.json')['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009';assert len(proof['proofs'])==35 and len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and report['separate_support_personal_displays']==rec['support']
for x in report['related_evidence']:assert h((b/x['path']).read_bytes())==x['sha256']
if (b/'MANIFEST.json').exists():
 seen=set()
 for x in L('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert h(raw)==x['sha256'] and len(raw)==x['bytes'],x['path'];seen.add(x['path'])
 assert seen=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p!=b/'MANIFEST.json'}
print('PASS: roles 2846–2848; separate old/current displays, registered support, original historical attribution and premature-read qualifications, 35 Git proofs and 13 bounded lenses. Evidence integrity only; no product execution.')
