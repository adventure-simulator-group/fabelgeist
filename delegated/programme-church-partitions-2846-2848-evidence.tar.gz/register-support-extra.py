from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';root='crates/adventuresim-building-generator/src/'
plans=[('small-church','generator/small_church.rs',[[50,78]]),('wall-assembly-tail','generator/wall_assemblies.rs',[[1133,1185]]),('closed-wall','generator/internal_partitions.rs',[[363,430]]),('wall-material','generator/wall_material.rs',[[1,90]]),('wall-solid','generator/wall_derivation.rs',[[260,330]])]
entries=[];pending=[]
for name,p,ranges in plans:
 path=root+p; raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';eof=len(raw.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':eof,'ranges':ranges,'local':loc});pending.append((loc,raw))
(b/'support-registration-extra.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective current producer/consumer support only. internal_partitions 363–430 is historical-role exclusion and not original role credit.','entries':entries},indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
