# Bounded programme and wall-span evidence: roles 2846–2848

`REPORT.json` records `/root/hair_ops`'s static source inspection of three
historical `pr-working` roles and pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. `registration.json` and
`read-receipt.json` distinguish prospective registrations, actual displays,
match-only navigation, historical material and current-only support. The
archived old, 6533 and current files are equal per role, but the historical
and current source windows were separately displayed and 6533 copies were only
compared. The recorded pr-working snapshot has unrelated modifications.

The native historical reviewers' qualifications are integral to the record:
prior premature navigation at programme line 233 and partition constants 1–8
was uncredited; later registered reads and independent root receipts have
their own attributions. Native material excludes `church_programme.rs:43`
context and `internal_partitions.rs:9` blank context. f82 registration rows
match their embedded earlier records, but the earlier whole-file registration
hashes differ from the retained f82 file and all complete-line prefixes.
Equality of parsed rows is not whole-file restoration or proof of absence.

The current bounded evidence connects to historical Camera F046 without a new
finding count. It does not show a supported final plan that triggers the
conditional split, or that a complete audit accepts it. Existing historical
records are not promoted to checkpoint 3821. No product, tests, fixtures,
geometry, builds, probes or repairs were executed.

`git-proofs.json` and `git-objects/` retain offline commit/tree/blob chains.
The historical manifest lists exact originals and explicitly labeled
reconstructed selections. `MANIFEST.json` inventories every packet file except
itself, including nested manifests. The evidence-only verifier is:

```sh
python3 verify-evidence.py
```

It verifies hashes, source identity, registry rows, reader qualifications,
coverage partitions and manifest. It cannot independently prove personal
source display; that is the reviewer's recorded receipt.
