from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path.cwd();pub=Path('<LOCAL_PATH_0>');orig=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');workspace=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/'recovered'/n,'recovered/'+n,'Archive/registry/059 where labelled; reconstructed catalog and later matching tracked patch retain independent qualifications.')
for n in ['AGENTS.md','crates/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Applicable source rules; source-only prohibition prevails.')
for n in ['COVERAGE-L01-ROLES.json','ASSESSMENT-L01-CHURCH-SAFEGUARDS-95E.json','ASSESSMENT-L01-HISTORICAL-610-615.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Prior published bounded assessment; no automatic alias or inherited reading.')
for n in ['REPORT.json','MANIFEST.json','support-registration.json','read-receipt.json']:
 copy(prev/n,'prior/spiral-2840-2842/'+n,'Earlier /root/hair_ops support read, no historical role credit.')
for n in ['segovb/READ-L11-462.json','segovb/STATE-L11-462.json','segovb/VERIFY-L11-462.json','segovb/REGISTRATION-SEGOVB-1767.json','segovb/REGISTRATION-SEGOVB-1768.json','segovb/REGISTRATION-SEGOVB-1769.json',]:
 copy(orig/n,'historical/059/'+n,'Exact original 059 historical receipt/registration, no reader or lens transfer.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';paths=[('native','initial05-aggregate-states',n) for n in ['source-range-registration.jsonl','source-qualifications.jsonl','contract-groups-296.json','contract-groups-300.json','findings.jsonl']]+[('root','admission03',f'new-parallel-admission-{n}.json') for n in [234,238]]+[('root','',f'parallel-scope-qualification-{n}.json') for n in [233,237]]
for owner,folder,n in paths:
 gp='/'.join(x for x in ['handoff/774/adler-original/audit/continuation',owner,folder,n] if x);raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,'historical/774/'+owner+'-'+n,'git:'+rev+':'+gp,'Original 774 record via f82 transport; earlier registration-file hash separately qualified.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw);qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());cv=json.loads((b/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=[2846,2847,2848];s={'kind':'Newly reconstructed selected rows, not original historical record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in ids},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')],'queue_uncompressed_sha256':h(qraw),'prior_coverage_sha256':h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes()),'prior_coverage_roles':{str(i):next(x for x in cv['roles'] if x['original_index']==i) for i in ids},'qualification':'PR based on 6533 with unrelated recorded modifications, not a clean snapshot; P16 distinct, no 3821 promotion.'};(b/'historical-selections-reconstructed.json').write_text(json.dumps(s,indent=2)+'\n');(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'All old reviewers/sources/ranges retained; f82 is evidence transport only.'},indent=2)+'\n');print('recovered',len(records),'manifest',h((b/'historical-manifest.json').read_bytes()))
