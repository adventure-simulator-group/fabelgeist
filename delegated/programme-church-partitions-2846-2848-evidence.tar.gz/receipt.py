from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path.cwd();h=lambda x:hashlib.sha256(x).hexdigest();L=lambda n:json.loads((b/n).read_bytes());reg=L('registration.json');nav={};navigation=[]
navfiles={'navigation-spans.txt':'navigation-registration.json','navigation-storeys.txt':'navigation-registration.json','navigation-church.txt':'navigation-registration.json','navigation-materials.txt':'navigation-registration-extra.json'}
for name,rn in navfiles.items():
 raw=(b/name).read_bytes();lines=raw.decode().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m,(name,line);nav.setdefault(m.group(1),set()).add(int(m.group(2)))
 navigation.append({'output':name,'sha256':h(raw),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'registration':rn,'ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2846:[[216,243]],2847:[[24,43]],2848:[[7,28]]};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];used=nums(d);extra=sorted(nav.get(row['path'],set())-used) if j else [];assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'local':v['local'],'sha256':v['sha256'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':extra,'unread_complement':comp(v['eof'],used|set(extra)),'qualification':'Old and current bodies separately read post-registration; 6533 copy mechanically compared. Original material windows are distinct from separately registered support; no tests executed.'})
support=[]
files=['support-registration.json','support-registration-extra.json','support-registration-opening.json']
for rn in files:
 for x in L(rn)['entries']:
  d=x['ranges'];used=nums(d);prior=[]
  for row in reg['rows']:
   if row['path']==x['path']:prior=chunks[row['original_index']]
  priornums=nums(prior);navonly=sorted(nav.get(x['path'],set())-used-priornums)
  support.append({'name':x['name'],'registration':rn,'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement':comp(x['eof'],used|priornums|set(navonly)),'registration_out_of_file_range':[],'qualification':'Overlapping support windows on the same path remain separate; internal_partitions 363–430 is current support and excluded from historical role.','ordered_role_credit':0})
names=['registration.json',*files,*dict.fromkeys(navfiles.values())];d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Reconstructed personal source displays and match-line-only navigation after prospective registration.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':L(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{k:sorted(v) for k,v in sorted(nav.items())},'prior_personal_support':'prior/spiral-2840-2842/read-receipt.json records current orchestration 1–115 and building-program 1–66 as support only; new displays here were separately registered, no historical role credit.','limits':'Source/evidence only; no product, geometry, fixtures, tests, build, runtime probe, repair or publication edit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt sha256',h((b/'read-receipt.json').read_bytes()))
