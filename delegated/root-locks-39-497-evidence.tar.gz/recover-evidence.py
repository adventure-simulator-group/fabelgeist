from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,datetime
r=Path(__file__).resolve().parent;recovered=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest()
(r/'recovered').mkdir();(r/'historical').mkdir();(r/'prior').mkdir();(r/'recovered/physical-p16-patch-recovery').mkdir()
for name in ['MANIFEST.json','registry.json.gz','objects.tar.gz','catalog-774.json','original-059-queue.json.gz']:
 shutil.copyfile(recovered/name,r/'recovered'/name)
for name in ['tracked.patch','live-comparison-redacted.json']:
 shutil.copyfile(recovered/'physical-p16-patch-recovery'/name,r/'recovered/physical-p16-patch-recovery'/name)
for name in ['LOCKFILE-DELTA.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','COVERAGE-L01-ROLES.json']:
 p=Path(repo)/name
 if not p.exists(): p=Path('<LOCAL_PATH_2>')/name
 shutil.copyfile(p,r/'prior'/name)
reg=json.load(gzip.open(r/'recovered/registry.json.gz','rt'));q=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'))
selections={'kind':'Reconstructed selections copied without edits to entries; original full compressed registry/queue preserved separately','original_registry_rows':{str(i):reg['files'][i] for i in (39,497)},'snapshot_rows':[x for x in reg['snapshots'] if x['id'] in ('physical-p16','pr-working')],'original_059_queue_rows':{str(i):q['entries'][i] for i in (72,124,1303,1791)}}
(r/'historical/selections-reconstructed.json').write_text(json.dumps(selections,indent=2,ensure_ascii=False)+'\n')
raw_records={'774-native-registrations.jsonl':'handoff/774/adler-original/audit/continuation/native/admission03/source-range-registration.jsonl','774-native-final-qualifications.jsonl':'handoff/774/adler-original/audit/continuation/native/admission03/source-qualifications-final-current.jsonl','774-root-owner-coverage.jsonl':'handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/audit-existing-type-owners/root/coverage.jsonl','774-camera-owner-additional.jsonl':'handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/audit-existing-type-owners/camera/additional-sources.jsonl'}
for out,path in raw_records.items():
 data=subprocess.check_output(['git','-C',repo,'show','f82adcabd9d89c4fa2dd7f99253a45297a0681ee:'+path]);(r/'historical'/out).write_bytes(data)
prior=[('saphyr-errors','<LOCAL_PATH_3>',['REPORT.json','MANIFEST.json','read-receipt.json','historical/059/adler/READ-L11-217.json']),('tiny-skia','<LOCAL_PATH_4>',['REPORT.json','MANIFEST.json','read-receipt.json','historical/059/adler/READ-L11-328.json']),('saphyr-options','<LOCAL_PATH_5>',['REPORT.json','MANIFEST.json','read-receipt.json','historical/774-findings.jsonl'])]
previous=[]
for label,old,files in prior:
 dest=r/'prior'/label; dest.mkdir();old=Path(old);m=json.loads((old/'MANIFEST.json').read_bytes());entries={x['path']:x for x in m['files']}
 for f in files:
  src=old/f;destfile=dest/f;destfile.parent.mkdir(parents=True,exist_ok=True);b=src.read_bytes()
  if f!='MANIFEST.json':assert f in entries and sha(b)==entries[f]['sha256'],(label,f)
  destfile.write_bytes(b)
 previous.append({'label':label,'original_packet':str(old),'manifest_sha256':sha((old/'MANIFEST.json').read_bytes()),'copied_members':files})
(r/'historical/recovery-and-prior-index.json').write_text(json.dumps({'qualification':'Exact copied member bytes checked against their own earlier frozen manifest; no earlier verifier invoked. Reconstructed selections are separate; f82 is evidence transport, not source revision.','prior_packets':previous,'raw_774_records':raw_records},indent=2)+'\n')
print('Recovered historical originals and prior selected receipts. Prior manifests:',[(x['label'],x['manifest_sha256']) for x in previous])
