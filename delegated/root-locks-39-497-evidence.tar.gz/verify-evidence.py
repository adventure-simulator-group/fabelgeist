from pathlib import Path
import gzip,hashlib,json,tarfile,tomllib,io,sys
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def fail_if(x,msg):
 if x: raise AssertionError(msg)
manifest=json.loads((r/'recovered/MANIFEST.json').read_bytes());regbytes=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());orig=json.loads(regbytes)
assert h(regbytes)==manifest['registry_sha256'];assert h((r/'recovered/registry.json.gz').read_bytes())==manifest['registry_gzip_sha256'];assert h((r/'recovered/objects.tar.gz').read_bytes())==manifest['objects_archive_sha256']
registration=json.loads((r/'registration.json').read_bytes());receipt=json.loads((r/'read-receipt.json').read_bytes());assert receipt['registration_sha256']==h((r/'registration.json').read_bytes())
with tarfile.open(r/'recovered/objects.tar.gz') as tar:
 for e in registration['objects'][:2]:
  assert e['registry_row']==orig['files'][e['role']];raw=tar.extractfile(e['sha256']).read();assert h(raw)==e['sha256'];assert raw==(r/e['path']).read_bytes()
for e in registration['objects']:
 assert h((r/e['path']).read_bytes())==e['sha256']
for e in receipt['reads']:
 x=next(x for x in registration['objects'] if x['path']==e['path']);assert x['sha256']==e['sha256'];assert len((r/e['path']).read_bytes().splitlines())==e['eof'];rs=[y['range'] for y in x.get('registered_display_windows',[])] or x.get('registered_display_ranges');assert rs==e['personal_display_chunks_in_order']
 expected=set();displayed=set()
 for a,b in rs:expected.update(range(a,b+1))
 for a,b in e['union']:displayed.update(range(a,b+1))
 assert expected==displayed
 cells=[0]*(e['eof']+1)
 for a,b in e['union']:
  for i in range(a,b+1):cells[i]+=1
 for a,b in e['unread_complement']:
  for i in range(a,b+1):cells[i]+=1
 assert all(x==1 for x in cells[1:]);assert sum(b-a+1 for a,b in e['union'])==e['displayed_lines']
ps=json.loads((r/'git-proofs.json').read_bytes());objects={}
for k,v in ps['objects'].items():
 b=gzip.decompress((r/v['preserved']).read_bytes());assert len(b)==v['bytes'];assert h(b)==v['sha256'];assert oid(v['type'],b)==k;objects[k]=b
def lookup(raw,name):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,n=raw[i:z].split(b' ',1);k=raw[z+1:z+21].hex();i=z+21
  if n.decode()==name:return mode.decode(),k
 raise AssertionError(name)
for p in ps['proofs']:
 raw=objects[p['revision']];root=raw.splitlines()[0].split()[1].decode();assert root==p['root_tree'];tree=root
 for component in p['chain']:
  assert component['tree']==tree;mode,child=lookup(objects[tree],component['name']);assert mode==component['mode'] and child==component['object'];tree=child
 assert p['path'].split('/')==[c['name'] for c in p['chain']];assert tree==p['blob'];b=(r/p['local']).read_bytes();b=gzip.decompress(b) if p.get('local_encoding')=='gzip' else b;assert h(b)==p['sha256'] and oid('blob',b)==tree
locks=[tomllib.loads((r/p).read_text())['package'] for p in ['source/role-39-Cargo.lock','source/role-497-Cargo.lock','source/95e-Cargo.lock']]
for e in registration['objects']:
 if e.get('category')!='native archive':continue
 version=e['identity'].rsplit(' ',1)[-1];name=e['identity'].split(' ',1)[-1].rsplit(' ',1)[0]
 for lock in locks:
  hits=[x for x in lock if x['name']==name and x['version']==version and x.get('checksum')==e['sha256'] and x.get('source')=='registry+https://github.com/rust-lang/crates.io-index'];assert len(hits)==1,(name,version)
for e in registration['objects']:
 if e.get('category')!='native package manifest support':continue
 archive=next(x for x in registration['objects'] if x.get('category')=='native archive' and x['sha256']==e['archive_sha256'])
 with tarfile.open(fileobj=io.BytesIO((r/archive['path']).read_bytes()),mode='r:gz') as t:assert t.extractfile(e['identity']).read()==(r/e['path']).read_bytes()
patch=(r/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert len(patch)==524542 and h(patch)==next(x['patch_sha256'] for x in orig['snapshots'] if x['id']=='physical-p16')
comparison=json.loads((r/'mechanical-comparison.json').read_bytes());d=lambda p:{(x['name'],x['version'],x.get('source','')):x for x in p};a,b=map(d,locks[:2]);assert [len(x) for x in locks]==comparison['package_counts'];assert len(a.keys()-b.keys())==comparison['p16_vs_pr_added_keys'];assert len(b.keys()-a.keys())==comparison['p16_vs_pr_removed_keys'];assert sum(a[k]!=b[k] for k in a.keys()&b.keys())==len(comparison['p16_vs_pr_modified_records'])==1
selection=json.loads((r/'historical/selections-reconstructed.json').read_bytes());queue=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'))
for i in (39,497):assert selection['original_registry_rows'][str(i)]==orig['files'][i]
for i in (72,124,1303,1791):assert selection['original_059_queue_rows'][str(i)]==queue['entries'][i]
for sel in [('saphyr-errors','historical/059/adler/READ-L11-217.json',72),('tiny-skia','historical/059/adler/READ-L11-328.json',124)]:
 label,p,i=sel;receipts=queue['entries'][i]['exact_source_identities_and_assessed_ranges'];assert h((r/'prior'/label/p).read_bytes()) in {x['receipt']['sha256'] for x in receipts}
idx=json.loads((r/'historical/recovery-and-prior-index.json').read_bytes())
for entry in idx['prior_packets']:
 base=r/'prior'/entry['label'];assert h((base/'MANIFEST.json').read_bytes())==entry['manifest_sha256'];old=json.loads((base/'MANIFEST.json').read_bytes());by={x['path']:x for x in old['files']}
 for f in entry['copied_members']:
  if f!='MANIFEST.json':assert h((base/f).read_bytes())==by[f]['sha256']
disclosure=json.loads((r/'navigation-disclosure.json').read_bytes());assert disclosure['pre_registration_rg_lines']==[15,29,45,100];assert disclosure['identity'].endswith(h((r/'support/native-serde-saphyr-Cargo.toml').read_bytes()))
report=json.loads((r/'REPORT.json').read_bytes());assert len(report['lens_perspectives'])==13
m=r/'MANIFEST.json'
if m.exists():
 records=json.loads(m.read_bytes())['files'];listed={e['path']:e for e in records};actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p!=m};assert set(listed)==actual
 for path,e in listed.items():b=(r/path).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],path
print('PASS: registry/archive and exact lock objects; f82 and project Git membership; actual receipt partitions; four native archive checksums across three lockfiles; historical records; prior frozen manifest members; P16 tracked-patch hash; mechanical comparison; thirteen bounded perspectives'+('; complete top manifest' if m.exists() else '; no top manifest yet'))
print('Evidence verification only. Feature resolution, builds, tests, product execution and validation remain open and unperformed.')
