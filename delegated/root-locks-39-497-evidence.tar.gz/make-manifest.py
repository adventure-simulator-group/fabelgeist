from pathlib import Path
import hashlib,json,datetime
r=Path(__file__).resolve().parent;out=r/'MANIFEST.json';files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p!=out:
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
obj={'schema':'726-bounded-locks-39-497-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'qualification':'Every packet file including nested MANIFEST.json is included; only this top-level manifest is excluded. Evidence archive presence is not personal source read credit.'}
out.write_text(json.dumps(obj,indent=2)+'\n');print('manifest',hashlib.sha256(out.read_bytes()).hexdigest(),'files',len(files),'total bytes',sum(x['bytes'] for x in files))
