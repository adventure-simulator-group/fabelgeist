import gzip,hashlib,json,pathlib,subprocess,tarfile,tomllib,datetime
D=pathlib.Path('<LOCAL_PATH_0>'); R=pathlib.Path('<LOCAL_PATH_1>'); repo='<LOCAL_PATH_2>'; rev='95e63628f9d70b8dd6e6fede64334696c6995009'; f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'; old=json.load(gzip.open(R/'registry.json.gz','rt')); (D/'source').mkdir(); (D/'native').mkdir(); (D/'support').mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def git(revision,path):return subprocess.check_output(['git','-C',repo,'show',revision+':'+path])
def stage(path,b): (D/path).write_bytes(b)
files=[]
names={'adventuresim-core','adventuresim-stdb-module','adventuresim-weapon-model','bytemuck','png','serde-saphyr','spacetimedb','spacetimedb-bindings-macro','spacetimedb-lib','spacetimedb-sats','tiny-skia','tiny-skia-path'}
with tarfile.open(R/'objects.tar.gz') as t:
 for i in (39,497):
  row=old['files'][i]; b=t.extractfile(row['sha256']).read(); assert sha(b)==row['sha256']; assert b==git(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256']); out='source/role-%d-Cargo.lock'%i;stage(out,b)
  files.append({'role':i,'identity':row['source_id'],'path':out,'sha256':sha(b),'lines':len(b.splitlines()),'registry_row':row,'revision_qualification': 'dirty snapshot based at a120; f82 is recovered-object transport' if i==39 else 'pr-working snapshot based on 6533, with unrelated dirty changes; f82 is recovered-object transport'})
b=git(rev,'Cargo.lock');stage('source/95e-Cargo.lock',b);files.append({'identity':'current 95e Cargo.lock','path':'source/95e-Cargo.lock','sha256':sha(b),'lines':len(b.splitlines()),'revision':rev})
for r in files:
 lines=(D/r['path']).read_text().splitlines(); starts=[i for i,l in enumerate(lines) if l=='[[package]]']+[len(lines)]; windows=[]
 for i,j in zip(starts,starts[1:]):
  package=tomllib.loads('\n'.join(lines[i:j]))['package'][0]
  if package['name'] in names: windows.append({'package':package['name'],'version':package['version'],'range':[i+1,j]})
 r['registered_display_windows']=windows
 r['unread_complement']='all lines outside registered windows, to be concretely calculated in personal receipt';
for name,path,ranges in [('workspace','Cargo.toml',[[125,165]]),('core','crates/adventuresim-core/Cargo.toml',[[1,45]]),('weapon','crates/adventuresim-weapon-model/Cargo.toml',[[1,19]])]:
 b=git(rev,path);out='support/95e-'+name+'-Cargo.toml';stage(out,b);files.append({'identity':'current project manifest '+path,'path':out,'sha256':sha(b),'lines':len(b.splitlines()),'revision':rev,'registered_display_ranges':ranges,'category':'support'})
archives=[('<LOCAL_PATH_3>','serde-saphyr',[[45,99]]),('<LOCAL_PATH_4>','tiny-skia',[[40,66]]),('<LOCAL_PATH_5>','bytemuck',[]),('<LOCAL_PATH_6>','tiny-skia-path',[])]
for path,name,ranges in archives:
 p=pathlib.Path(path);b=p.read_bytes();stage('native/'+p.name,b)
 pkg=tomllib.loads((D/'source/95e-Cargo.lock').read_text())['package']; match=[x for x in pkg if x['name']==name and x.get('checksum')==sha(b)]; assert len(match)==1
 ent={'identity':'crates.io '+name+' '+match[0]['version'],'path':'native/'+p.name,'sha256':sha(b),'prior_location':path,'checksum_matches_current_lock':True,'archive_only_no_personal_source_read':True,'category':'native archive'}
 files.append(ent)
 if ranges:
  with tarfile.open(fileobj=__import__('io').BytesIO(b),mode='r:gz') as t:
   n=next(x.name for x in t.getmembers() if x.name.endswith('/Cargo.toml') and x.name.count('/')==1); manifest=t.extractfile(n).read()
  out='support/native-'+name+'-Cargo.toml';stage(out,manifest);files.append({'identity':n,'path':out,'sha256':sha(manifest),'lines':len(manifest.splitlines()),'registered_display_ranges':ranges,'archive_sha256':sha(b),'category':'native package manifest support'})
reg={'schema':'726-prospective-lock-window-registration-v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','purpose':'Bounded independent source inspection only; no whole lock coverage or feature activation inferred','pinned_current':rev,'objects':files,'earlier_navigation_disclosure':'Before this registration, metadata TOML parsing counted package names, versions, line ranges and stanza hashes; rg output displayed current project workspace serde-saphyr line 140 and tiny-skia line 159, weapon manifest line 13, plus current lock matching name/dependency lines 187,339,373,417,488,9276,9372,10476,10487,10491 in previously preserved prior packet copies. These were navigation output, not prospective fresh ordered-role credit. Earlier own lock displays and other readers are separately preserved in REPORT and prior receipts.','exclusion':'All unregistered lines remain unread for this new packet. Historical owner metadata full-file read is not a personal semantic read or later lens completion.'}
(D/'registration.json').write_text(json.dumps(reg,indent=2,ensure_ascii=False)+'\n')
print('Registration',sha((D/'registration.json').read_bytes()));print('objects',[(x['identity'],x['sha256'],x.get('lines'),len(x.get('registered_display_windows',x.get('registered_display_ranges',[])))) for x in files])
