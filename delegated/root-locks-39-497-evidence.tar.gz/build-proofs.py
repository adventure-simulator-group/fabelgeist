from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objects={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind,encoding=None):
 raw=(r/local).read_bytes();raw=gzip.decompress(raw) if encoding=='gzip' else raw;root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw),(rev,path,local);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw),'local_encoding':encoding})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';proof('eb407672813424d64ec31f208193969f5a62620c','handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json','recovered/original-059-queue.json.gz','Exact recovered 059 historical queue, gzip preserves the original uncompressed bytes; no 3821 credit','gzip');rev='95e63628f9d70b8dd6e6fede64334696c6995009';reg=json.loads((r/'registration.json').read_bytes())
for e in reg['objects'][:2]:proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+e['sha256'],e['path'],'Original registry object in f82 evidence transport')
proof('a120390947c89b703dc74c4255a13c035d054c50','Cargo.lock','source/role-497-Cargo.lock','clean P16 base bytes equal historical pr-working object; not dirty P16 object')
proof('6533e444fa37552927070cc8d8190907fd3b413e','Cargo.lock','source/role-497-Cargo.lock','pr-working file byte equality only; snapshot has other modifications')
proof(rev,'Cargo.lock','source/95e-Cargo.lock','pinned current project source')
for path,local in [('Cargo.toml','support/95e-workspace-Cargo.toml'),('crates/adventuresim-core/Cargo.toml','support/95e-core-Cargo.toml'),('crates/adventuresim-weapon-model/Cargo.toml','support/95e-weapon-Cargo.toml')]:proof(rev,path,local,'registered current source support')
idx=json.loads((r/'historical/recovery-and-prior-index.json').read_bytes())
for name,path in idx['raw_774_records'].items():proof(f82,path,'historical/'+name,'raw original 774 supplier record preserved via f82 transport')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-bounded-lock-git-proof-v1','objects':objects,'proofs':proofs,'qualification':'Git establishes content membership of individual files only; f82 is evidence transport and matching bytes do not establish full-tree cleanliness, feature resolution, semantics, or checkpoint3821.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'sha256',h((r/'git-proofs.json').read_bytes()))
