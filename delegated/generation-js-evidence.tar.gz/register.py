import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';revisions=['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']
names=['strategic-generation-cache.js','strategic-generation-pool.js','strategic-generation-worker.js','strategic-generation-write-queue.js','strategic-generation.js'];rows=[]
for index,name in enumerate(names,2423):
 path='crates/strategic-web/static/'+name;versions=[]
 for rev in revisions:
  x=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True)
  if x.returncode:versions.append({'revision':rev,'present':False});continue
  b=x.stdout;(out/'source'/(rev[:4]+'-'+name)).write_bytes(b)
  versions.append({'revision':rev,'present':True,'lines':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 rows.append({'original_index':index,'path':path,'versions':versions})
o={'schema':'delegated-audit-prospective-source-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Register exact historical and current generation cache, pool, worker, write queue and coordinator bodies before full display.','qualification':'Display each distinct body separately; an identical source object may be displayed once after independent Git byte verification. All prior source credit remains with its original author and revision.','constraint':'Source inspection and evidence integrity only; no product edits, implementation, JS or worker execution, builds, tests, browser or runtime probes.','ordered_roles':rows}
f=out/'registration.json';f.write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(rows,indent=1))
