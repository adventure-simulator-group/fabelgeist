import gzip,hashlib,json,pathlib
src=pathlib.Path('<LOCAL_PATH_0>');pub=pathlib.Path('<LOCAL_PATH_1>');out=pathlib.Path('<LOCAL_PATH_2>');old=pathlib.Path('<LOCAL_PATH_3>');handoff=pathlib.Path('<LOCAL_PATH_4>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f:entries={e['path']:e for e in json.load(f)['entries']}
paths=[]
for i in (815,816):paths += [f'segovb/READ-L12-{i}.json',f'segovb/REGISTRATION-SEGOVB-L12-{i}.json',f'segovb/VERIFY-L12-{i}.json',f'parallel-l12-20261029/PROPOSAL-L12-{i}.json']
paths += [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json' for i in (432,433,434,435,436)]
rows=[];missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file():missing.append(path);continue
 b=(src/path).read_bytes();e=entries[path];h=hashlib.sha256(b).hexdigest();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),path
 dst=out/'historical'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);rows.append({'original_transport_path':path,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+path})
o={'schema':'delegated-recovered-historical-evidence-v1','qualification':'Exact original 059 extraction copies verified against original transport SHA-256, byte size and Git blob. Preserve author/revision/qualifications; never promote to checkpoint3821.','records':rows,'unavailable':missing}
f=out/'historical-manifest.json';f.write_text(json.dumps(o,indent=2)+'\n');print('059 verified',len(rows),'unavailable',missing,'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
ref=out/'reference';ref.mkdir(exist_ok=True)
refs=[('<LOCAL_PATH_5>','registry.json.gz','exact original registry'),('<LOCAL_PATH_6>','original-transport-manifest.json.gz','exact original transport manifest'),('<LOCAL_PATH_7>','queue-059.json.gz','losslessly compressed 059 queue; not checkpoint3821'),('<LOCAL_PATH_8>','strategic-web-AGENTS-95e.md','governing web source rules'),(str(old/'ledger.json'),'older-774-ledger.json','older 774 local ledger, 13fc revision and incomplete status')]
old_manifest=(handoff/'MANIFEST.json').read_bytes();(ref/'older-774-handoff-manifest.json.gz').write_bytes(gzip.compress(old_manifest,mtime=0));manifest=json.loads(old_manifest);indexed={e['path']:e for e in manifest['files']}
oldpaths=['redundant-authority/contract-560.json','redundant-authority/contract-561.json','operations/contract-groups-581.json'];older=[]
for n in oldpaths:
 a=old/'reconcile-adler-20261023/audit-continuation'/n; m='audit/reconcile-adler-20261023/audit-continuation/'+n;b=(handoff/m).read_bytes();e=indexed[m];assert b==a.read_bytes() and (len(b),hashlib.sha256(b).hexdigest())==(e['bytes'],e['sha256'])
 name='older-774-'+n.replace('/','__');(ref/name).write_bytes(b);older.append({'manifest_path':m,'merged_copy':str(a),'bytes':len(b),'sha256':e['sha256'],'copy':'reference/'+name,'qualification':'Exact bytes match both local 774 collections and the earlier 774 handoff manifest; preserve each record original git revision, author and source scopes.'})
f=ref/'older-774-selection.json';f.write_text(json.dumps({'manifest_compressed':'reference/older-774-handoff-manifest.json.gz','manifest_uncompressed_sha256':hashlib.sha256(old_manifest).hexdigest(),'records':older},indent=2)+'\n');print('774 verified',len(older),'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
assess=['ASSESSMENT-GENERATION-IDENTITY-95E.json','ASSESSMENT-STRATEGIC-REPLACEMENT-ERROR-95E.json','ASSESSMENT-GENERATION-WORKER-TRUST-95E.json','ASSESSMENT-CITY-GROUND-WIRE-ADMISSION-95E.json']
for i,n in enumerate(assess):
 path=pub/n;o=json.loads(path.read_text());refs.append((str(path),f'prior-assessment-{i}.json','prior current assessment, preserve author, revision and bounded ranges'))
 for j,x in enumerate(o.get('current_supporting_sources',[])):
  if 'strategic-generation' in x.get('path','') and x.get('preserved_bytes'):
   refs.append((str(pub/x['preserved_bytes']),f'prior-source-{i}-{j}.gz','exact preserved earlier role object; ranges and revision in prior assessment'))
rs=[];unavailable=[]
for source,name,cl in refs:
 s=pathlib.Path(source)
 if not s.is_file():unavailable.append(source);continue
 b=s.read_bytes();(ref/name).write_bytes(b);rs.append({'source':source,'copy':'reference/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'classification':cl})
f=ref/'manifest.json';f.write_text(json.dumps({'records':rs,'unavailable':unavailable,'older_manifest_sha256':hashlib.sha256((ref/'older-774-selection.json').read_bytes()).hexdigest()},indent=2)+'\n');print('references',len(rs),'unavailable',unavailable,'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
