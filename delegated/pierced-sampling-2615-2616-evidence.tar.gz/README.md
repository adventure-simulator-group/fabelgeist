# Bounded checkpoint 17 reconciliation proposal

This additive packet concerns original roles 2615 and 2616 and current revision
95e63628f9d70b8dd6e6fede64334696c6995009. Start with `report.json` for source
relationships, safeguards, open questions and proposed ledger connections.
This is source-only evidence, with no repair, product validation or lens closure.

`registration.json` predates the independently displayed source windows and
`read-receipt.json` records their actual scopes and unread complements. Full
saved source bytes are not personal-read credit. In particular this follow-up
read historical sampling 1–45 and current 1–49, leaving old 46–71 and current
50–75 unread. The byte-level reconstructed diff establishes a current constant
addition; it does not transfer review credit for unread text. `git-proofs.json`
and compressed Git objects prove per-file membership. f82 is transport, and the
recorded 6533 pr-working HEAD has unrelated modifications.

`reference/` preserves exact baseline materials plus compressed earlier
reconstructed 059 queue and ledger. `059-selection-reconstructed.json` and
`registry-selection-reconstructed.json` are new exact selections, not original
historical receipts. `history-059/` is checked against the original transport
manifest, and `history-774/` contains tree-proved f82 records. The historical
index preserves two rig registration-prefix digest mismatches and matching
qualification pins without assigning a cause. The 774 registration reason and
additional contract differ about Serde for sampling; both are retained.

`prior/` is a hash-checked selection of `/root/hair_ops` frozen evidence.
`public-prior-members.json` distinguishes its original member bytes from the
redacted checkpoint 17 copy. All earlier readers retain their own scopes; no
historical material is promoted to checkpoint 3821. The separately linked P16
patch recovery is background and does not change these pr-working identities.

`verification.json` records this packet's evidence-only verifier. The root
manifest hashes every packet file except itself, including nested manifests.
No old verifier or product code was executed.
