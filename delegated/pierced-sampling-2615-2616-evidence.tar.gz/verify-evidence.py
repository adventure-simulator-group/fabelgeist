import datetime,difflib,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes())
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(v==reg['files'][int(k)] for k,v in sel['roles'].items());assert all(reg['files'][i]['snapshot']=='pr-working' for i in (2615,2616))
for name in ('reference-index.json','rules.json','rules-local.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256']
r=load('registration.json');t=load('read-receipt.json');assert t['registration_sha256']==sha((p/'registration.json').read_bytes()) and len(r['entries'])==len(t['entries'])==12 and datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(r['registered_utc'])
def nums(rs):return {i for lo,hi in rs for i in range(lo,hi+1)}
for e,v in zip(r['entries'],t['entries']):
 b=(p/e['archive']).read_bytes();assert e['tag']==v['tag'] and sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'];seen=nums(v['displayed_chunks']);unseen=nums(v['unread_complement']);assert nums(e['registered_ranges'])==seen and seen|unseen==set(range(1,e['EOF']+1)) and not seen&unseen
 if e['kind']=='historical-pr-working':assert e['sha256']==reg['files'][e['role']]['sha256']
assert (p/'source/pr-working-2615.rs').read_bytes()==(p/'source/current-2615.rs').read_bytes();assert (p/'source/pr-working-2616.rs').read_bytes()!=(p/'source/current-2616.rs').read_bytes();assert next(z for z in t['entries'] if z['tag']=='pr-working-2616')['unread_complement']==[[46,71]] and next(z for z in t['entries'] if z['tag']=='current-2616')['unread_complement']==[[50,75]]
old=(p/'source/pr-working-2616.rs').read_text().splitlines(keepends=True);cur=(p/'source/current-2616.rs').read_text().splitlines(keepends=True);assert ''.join(difflib.unified_diff(old,cur,fromfile='pr-working',tofile='95e'))==(p/'2616-diff-reconstructed.txt').read_text()
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());lraw=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());q=json.loads(qraw);l=json.loads(lraw);x=load('059-selection-reconstructed.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for path,v in x['journal_entries'].items():
 z=l
 for part in path.strip('/').split('/'):z=z[int(part)] if isinstance(z,list) else z[part]
 assert z==v
for i in (609,1813):assert not q['entries'][i]['exact_source_identities_and_assessed_ranges'] and not q['entries'][i]['source_receipt_contexts']
assert q['entries'][3141]['exact_source_identities_and_assessed_ranges']
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for suffix in ('L11-427','L12-893','L12-894'):
 v=load('history-059/segovb/VERIFY-'+suffix+'.json');assert v['receipt_sha256']==sha((p/('history-059/segovb/READ-'+suffix+'.json')).read_bytes()) and v['state_sha256']==sha((p/('history-059/segovb/STATE-'+suffix+'.json')).read_bytes())
read=load('history-059/segovb/READ-L11-427.json');l11=[]
for e in read['sources']:
 if e['original_index'] not in (2615,2616):continue
 rel=e['registration'].split('target/726-audit-adler-20261027/',1)[1];assert e['registration_sha256']==sha((p/'history-059'/rel).read_bytes()) and e['sha256']==reg['files'][e['original_index']]['sha256'];l11.append(e)
assert len(l11)==3 and [e['fresh_personal_body_reads'] for e in l11]==[[[1,188]],[[1,43]],[[44,45]]]
for n,role,ran in [(893,2615,[[1,188]]),(894,2616,[[1,43]])]:
 read=load(f'history-059/segovb/READ-L12-{n}.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes());e=next(z for z in read['rows'] if z['original_index']==role);assert e['fresh_personal_body_reads']==ran and e['source_sha256']==reg['files'][role]['sha256'] and e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes())
refs=[]
def walk(o,path=''):
 if isinstance(o,dict):
  if isinstance(o.get('path'),str) and o['path'] in idx and isinstance(o.get('sha256'),str):
   actual=sha((p/'history-059'/o['path']).read_bytes());refs.append({'pointer':path,'path':o['path'],'recorded_sha256':o['sha256'],'actual_sha256':actual,'match':o['sha256']==actual})
  for k,v in o.items():walk(v,path+'/'+k)
 elif isinstance(o,list):
  for i,v in enumerate(o):walk(v,path+'/'+str(i))
walk(q['entries'][3141],'/entries/3141');assert all(e['match'] for e in refs),[e for e in refs if not e['match']]
prior=load('prior-index.json');m=(p/'prior/MANIFEST.json').read_bytes();assert sha(m)==prior['original_manifest_sha256']=='5e98f9550e19a46e5d41fd05d5807920d99a23820a0c2684e256e50c5dce07bf';idxprior={e['path']:e for e in json.loads(m)['files']}
for e in prior['selected_files']:
 b=(p/'prior'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(idxprior[e['path']]['bytes'],idxprior[e['path']]['sha256'])
entry=next(z for z in load('reference/DELEGATED-EVIDENCE-CHECKPOINT-17.json')['bundles'] if z['bundle_id']=='armor-pierced-sampling-hair-ops');assert entry['archive_sha256']==prior['published_archive_sha256'];members=load('public-prior-members.json');assert members['archive_sha256']==entry['archive_sha256']
for v in members['members']:
 z=next(z for z in entry['members'] if z['path']==v['path']);assert (v['original_sha256'],v['published_sha256'],v['changed'])==(z['original_sha256'],z['published_sha256'],z['changed']) and v['original_sha256']==sha((p/'prior'/v['path']).read_bytes()) and v['published_sha256']==sha((p/v['file']).read_bytes())
assert next(v for v in members['members'] if v['path']=='historical-manifest.json')['changed'] and not next(v for v in members['members'] if v['path']=='REPORT.json')['changed'] and sha((p/'reference/published-prior-report.json').read_bytes())==sha((p/'prior/REPORT.json').read_bytes())
pin=hist['rig_registration_pin_qualification'];a=json.loads(gzip.decompress((p/'history-774/continuation/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));b=json.loads(gzip.decompress((p/'history-774/continuation/root/admission03-scope-reconciliation-050.json.gz').read_bytes()));rr=gzip.decompress((p/'history-774/continuation/rig/admission03/source-range-registration.jsonl.gz').read_bytes());rq=gzip.decompress((p/'history-774/continuation/rig/admission03/source-qualifications.jsonl.gz').read_bytes());assert a['input_pins'][3]==pin['root046_registration_pin'] and b['input_pins'][2]==pin['root050_registration_pin'];assert a['input_pins'][3]['sha256']!=sha(b''.join(rr.splitlines(keepends=True)[:35]))==pin['later_registration_first35_sha256'];assert b['input_pins'][2]['sha256']!=sha(b''.join(rr.splitlines(keepends=True)[:139]))==pin['later_registration_first139_sha256'];assert a['input_pins'][4]['sha256']==sha(b''.join(rq.splitlines(keepends=True)[:31])) and b['input_pins'][3]['sha256']==sha(b''.join(rq.splitlines(keepends=True)[:45]))
for role,n in ((2615,62),(2616,63)):
 row=json.loads(rr.splitlines()[n-1]);obs=reg['files'][role]['admission03_scope_observations'][0];assert row==obs['original_record']==pin['row'+str(n)] and datetime.datetime.fromisoformat(a['at'])<datetime.datetime.fromisoformat(row['at'])<datetime.datetime.fromisoformat(b['at'])
adds=gzip.decompress((p/'history-774/continuation/rig/admission03/additional-contracts.jsonl.gz').read_bytes()).splitlines();d62=json.loads(adds[47]);d63=json.loads(adds[48]);assert d62['id']=='RIG-ADMISSION03-ADDITIONAL-062' and d62['actual_source_ranges']==[[1,188]] and d63['id']=='RIG-ADMISSION03-ADDITIONAL-063' and d63['actual_source_ranges']==[[1,43]] and 'noSerde' in d63['admission_comparison'] and 'Serde' in pin['row63']['reason']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 bts=gzip.decompress((p/e['archive']).read_bytes());assert len(bts)==e['bytes'] and sha(bts)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(bts)).encode()+b'\0'+bts).hexdigest()==oid;objs[oid]=(e['type'],bts)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,body=objs[tree];assert typ=='tree';mode,tree=entries(body)[name];assert mode==link['mode'] and tree==link['object']
 body=(p/x['archive']).read_bytes();body=gzip.decompress(body) if x.get('encoding')=='gzip' else body;assert sha(body)==x['sha256'] and blob(body)==x['blob']==tree
report=load('report.json');baseline=load('reference/BASELINE-95E-20261110.json');assert len(proof['proofs'])==19 and len(report['lens_perspectives'])==13 and [z['index'] for z in report['historical_relations']['selected_059_queue']]==[609,1813,3141];assert baseline['newly_assessed_ledger']['entries'][471]['id']=='REVIEW-L3-HELMET-CARRIER-TOPOLOGY-ADMISSION' and baseline['newly_assessed_ledger']['entries'][472]['id']=='REVIEW-BUFFE-BREATH-COURSE-CONTEXT-95E'
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_source_entries':len(r['entries']),'git_membership_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(hist['records']),'selected_queue_entries':3,'qualified_queue_reference_hashes':len(refs),'lens_perspectives':13,'rig_registration_mismatches_retained':2,'public_historical_manifest_redacted':True,'qualification':'Evidence integrity only: independent historical/current source reads, explicit sampling unread complements, 059/774 chronology and discrepancy, original/public member identities, revision diff and membership proofs. No product, geometry, triangulation, fixture, test, build or probe execution.'},indent=2))
