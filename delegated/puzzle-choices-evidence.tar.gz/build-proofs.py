import gzip, hashlib, json, pathlib, subprocess
p = pathlib.Path(__file__).parent
repo = '<LOCAL_PATH_0>'
f82 = 'f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
reg = json.loads((p/'registration.json').read_bytes())
records = []
for x in reg['roles']:
 for j,o in enumerate(x['revision_objects']):
  label = 'historical' if j == 0 else 'current'
  records.append({'kind':'project-role','revision':o['revision'],'path':o['git_path'],'archive':f"source/{x['original_index']}-{label}.rs",'sha256':o['sha256'],'git_blob':o['git_blob']})
 o=x['revision_objects'][0]
 records.append({'kind':'f82-evidence-object','revision':f82,'path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+o['sha256'],'archive':f"source/{x['original_index']}-historical.rs",'sha256':o['sha256'],'git_blob':o['git_blob']})
for x in json.loads((p/'support-registration.json').read_bytes())['rows']:
 records.append({'kind':'current-support','revision':x['revision'],'path':x['path'],'archive':x['support_file'],'sha256':x['sha256'],'git_blob':x['git_blob']})
for x in json.loads((p/'historical-index.json').read_bytes())['records']:
 if x['kind']=='historical-774':records.append({'kind':'historical-774-record','revision':f82,'path':x['transport_path'],'archive':x['file'],'sha256':x['sha256'],'git_blob':x['git_blob'],'encoding':'gzip'})
(p/'git-objects').mkdir();objs={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]); assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objs:
  dest=p/'git-objects'/(oid+'.'+t+'.gz');dest.write_bytes(gzip.compress(b,mtime=0));objs[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dest.relative_to(p))}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in records:
 c=obj('commit',x['revision']);tree=c.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b
 blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert (hashlib.sha256(b).hexdigest(),blob,tree)==(x['sha256'],x['git_blob'],x['git_blob'])
 proofs.append(dict(x,commit_tree=root,chain=chain))
(p/'git-proofs.json').write_text(json.dumps({'objects':objs,'proofs':proofs,'qualification':'Project 6533/95e paths distinct from f82 historical source-object/record transport. Per-file equality does not make recorded pr-working snapshot globally clean.'},indent=2)+'\n')
print('proofs',len(proofs),'raw commit/tree objects',len(objs))
