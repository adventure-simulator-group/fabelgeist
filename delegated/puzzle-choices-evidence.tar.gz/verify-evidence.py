#!/usr/bin/env python3
"""Read-only source and evidence identity verifier. Does not execute product code."""
import gzip, hashlib, json, pathlib, sys, tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]); sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
reg=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes());assert reg['registered_utc']<receipt['recorded_utc'];assert len(receipt['rows'])==4
for x in receipt['rows']:
 b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['lines'];assert x['actual_display_ranges']==[[1,x['lines']]] and not x['unread_ranges']
for x in reg['roles']:
 a,b=x['revision_objects'];assert a['sha256']==b['sha256']==x['registry_entry']['sha256'] and a['git_blob']==b['git_blob']
checks.append('prospective full historical/current registration and four actual role read receipts; per-file identity')
support=load('support-read-receipt.json');registrations={x['file']:load(x['file']) for x in support['registrations']}
for x in support['registrations']:assert sha((p/x['file']).read_bytes())==x['sha256'] and registrations[x['file']]['registered_utc']<support['recorded_utc']
for x in support['actual_reads']:
 b=(p/x['support_file']).read_bytes();assert sha(b)==x['sha256']
 assert any(r['path']==x['path'] and r['sha256']==x['sha256'] and r['prospective_ranges']==x['actual_display_ranges'] for d in registrations.values() for r in d['rows'])
 assert all(1<=a<=z<=len(b.splitlines()) for a,z in x['actual_display_ranges'])
checks.append('all actual support scopes match independently prior registrations and archived bytes')
idx=load('historical-index.json');arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 tr=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in tr['entries']};orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==reg['original_registry_decompressed_sha256'];r=json.loads(orig)
 for x in reg['roles']:assert x['registry_entry']==r['files'][x['original_index']]
for x in idx['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b
 assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('original registry entries and 11 exact 059 records match published original transport manifest; four 774 records exact')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def tree_entries(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==16
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for v in x['chain']:
  assert v['tree']==tree and tree_entries(data(tree))[v['name']]==(v['mode'],v['object']);tree=v['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b
 assert (sha(b),blob(b),tree)==(x['sha256'],x['git_blob'],x['git_blob'])
checks.append('16 independent raw Git commit/tree/blob chains including separate 6533, 95e and f82 paths')
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['local_sha256']
r=load('report.json');assert {x['number'] for x in r['lenses']}==set(range(1,14));assert len(r['roles'])==2
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());assert queue['entries'][2697]['contract_id']=='REVIEW-L3-ORDERED-CLUE-POSITION-ADMISSION'
rec=json.loads((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes());patch=pub/rec['recovered_patch']['path'];assert sha(patch.read_bytes())==rec['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
checks.append('13 bounded lens views, original queue ID and later tracked-P16 patch identity; no scope or credit transfer')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence verification only. No source execution, product validation, build, test, runtime probe, repair, lens completion, 3821 promotion or source/publication change.'},indent=2))
