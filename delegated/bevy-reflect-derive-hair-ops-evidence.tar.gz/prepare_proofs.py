import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());reg=load('registration.json');srnames=['support-registration.json','support-registration-02.json'];supports=[s for n in srnames for s in load(n)['sources']];hist=load('historical-manifest.json');(p/'git-objects').mkdir(exist_ok=True);objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
m=[]
for role in reg['roles']:
 b=(p/role['local_source']).read_bytes();m.append({'revision':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+role['sha256'],'local':role['local_source'],'sha256':role['sha256'],'git_blob':blob(b),'qualification':'f82 exact evidence transport, not package source Git revision.'})
for rev,v in reg['lock_provenance'].items():m.append({'revision':rev,'path':'Cargo.lock','local':v['path'],'sha256':v['sha256'],'git_blob':v['git_blob']})
for x in supports:
 if x['kind']=='project':m.append(x)
for x in hist['records']:
 if x['scope'] in ('original-native-f82','earlier-current-publication'):
  b=(p/x['copy']).read_bytes();m.append({'revision':x['revision'],'path':x['origin'],'local':x['copy'],'sha256':x['sha256'],'git_blob':blob(b),'qualification':x['qualification']})
for s in m:
 rev=s['revision'];tree=obj('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==blob(b);proofs.append({'revision':rev,'path':s['path'],'archive':s['local'],'commit_tree':root,'chain':chain,'blob':tree,'qualification':s.get('qualification')})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Git membership for source objects in f82 transport, two locks, current project support and selected historical records; external package bytes retain native archive/registry identity, not project Git identity.','objects':objects,'proofs':proofs},indent=2)+'\n')
def complement(eof,w):
 covered={i for lo,hi in w for i in range(lo,hi+1)};out=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in covered and start is None:start=i
  if start is not None and (i==eof+1 or i in covered):out.append([start,i-1]);start=None
 return out
rolew={2563:[[1,100],[101,200],[201,300],[301,400],[401,500],[501,600],[601,700],[701,800],[801,907]],2564:[[1,100],[101,200],[201,275],[276,353]]};reads=[]
for r in reg['roles']:
 w=rolew[r['original_index']];reads.append({'original_index':r['original_index'],'source_id':r['source_id'],'package':r['package'],'version':r['version'],'sha256':r['sha256'],'archive':r['local_source'],'eof':r['registered_range'][1],'actual_display_ranges':w,'unread_complement':complement(r['registered_range'][1],w),'original_material_ranges':[[60,117]] if r['original_index']==2563 else [[25,56]],'fresh_outside_original_material':[[1,59],[118,907]] if r['original_index']==2563 else [[1,24],[57,353]]})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration_sha256':sha((p/'registration.json').read_bytes()),'reads':reads,'qualification':'Separate native package body displays; original rig attribution and materially narrowed ranges remain distinct; no macro execution.'},indent=2)+'\n')
windows={'support/project-2':[[1,75],[76,131]],'support/native-0':[[1,75],[76,131]],'support/native-1':[[1,75],[76,150],[151,212]]};reads=[]
for s in supports:
 w=windows.get(s['local'],s['prospective_ranges']);reads.append({'kind':s['kind'],'path':s['path'],'revision':s.get('revision'),'package':s.get('package'),'version':s.get('version'),'archive':s['local'],'sha256':s['sha256'],'eof':s['eof'],'actual_display_windows':w,'unread_complement':complement(s['eof'],w)})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in srnames],'reads':reads,'qualification':'Bounded project/native support only; archived complement not read. No ordered-role credit.'},indent=2)+'\n')
lr=load('lock-registration.json');reads=[]
for s in lr['sources']:
 w=s['prospective_ranges'];reads.append({'revision':s['revision'],'path':s['path'],'archive':s['local'],'sha256':s['sha256'],'eof':s['eof'],'actual_display_windows':w,'unread_complement':complement(s['eof'],w)})
(p/'lock-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration_sha256':sha((p/'lock-registration.json').read_bytes()),'reads':reads,'qualification':'Bounded lock clauses only; locked dependency identity does not prove feature activation or execution.'},indent=2)+'\n');print('Git membership proofs',len(proofs),'objects',len(objects),'support',len(supports))
