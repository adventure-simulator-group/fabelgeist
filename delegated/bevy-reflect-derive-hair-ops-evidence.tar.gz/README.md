# Bevy reflection derive: bounded native source assessment

`/root/hair_ops` reviewed original roles 2563–2564 and bounded project and
native supports. `report.json` distinguishes the native opaque typed-clone
route, project checked-owner examples, a conditional defaultable-struct
reconstruction question, and an opt-in static-registration question. None is
claimed as a new demonstrated product defect. Existing 059 and 774 records
retain their original authorship and open status.

`bevy_reflect_derive` 0.19.1 is an external registry package, not a project Git
revision. The full cached crate archive, its SHA-256, original registry
objects, per-member bytes and both 6533 and 95e Cargo.lock bindings are
preserved. Lock selection alone does not show feature activation, macro
expansion or runtime use. f82 carries recovered evidence objects; it is not a
package source revision. Original rig material was lib.rs 60–117 and
from_reflect.rs 25–56 after narrowing the latter registration from 25–59; all
additional personally displayed lines are fresh extensions. Prior L11 and L12
personal reads and e275 inherited line 118 remain separately attributed.

`read-receipt.json`, `support-read-receipt.json` and `lock-read-receipt.json`
list exact displayed windows and unread complements. Registered source bytes,
package archive and commit-tree membership proofs are included. The original
059 and 774 manifest archives and original queue are hash-linked from
`historical-manifest.json`; exact relevant historical records and reconstructed
queue rows are included. Central publication must preserve those linked
archives or relink them to byte-identical published evidence.

`python3 verify_manifest.py` checks the frozen packet. `verify_evidence.py`
checks package, source, read-partition, Git and historical evidence and writes
its result; it does not run the package or project. No macro, build, test,
product, simulated fixture, runtime probe, repair or product validation ran.
