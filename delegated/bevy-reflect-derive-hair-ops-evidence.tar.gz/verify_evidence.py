'''Evidence-only verification. Does not run macros, project source, tests or builds.'''
import datetime,gzip,hashlib,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());reg=load('registration.json');rr=load('read-receipt.json');sr=load('support-read-receipt.json');lr=load('lock-read-receipt.json');proof=load('git-proofs.json');hist=load('historical-manifest.json');report=load('report.json');registry=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()));inventory_bytes=gzip.decompress((p/'reference/059-source-inventory.json.gz').read_bytes());inventory=json.loads(inventory_bytes);reads={}
def partition(eof,windows,unread):
 a={i for lo,hi in windows for i in range(lo,hi+1)};b={i for lo,hi in unread for i in range(lo,hi+1)};assert all(1<=lo<=hi<=eof for lo,hi in windows+unread);assert not a&b and a|b==set(range(1,eof+1));return a
def ts(x):return datetime.datetime.fromisoformat(x)
assert rr['prospective_registration_sha256']==sha((p/'registration.json').read_bytes()) and ts(reg['registered_utc'])<ts(rr['recorded_utc']);assert len(reg['roles'])==2
proofkeys={(x['revision'],x['path'],x['archive']) for x in proof['proofs']}
for role,r in zip(reg['roles'],rr['reads']):
 idx=role['original_index'];assert idx==r['original_index'] and idx in (2563,2564);b=(p/role['local_source']).read_bytes();assert len(b)==role['bytes'] and sha(b)==role['sha256']==registry['files'][idx]['sha256']==catalog['rows'][idx]['expected_sha256']==inventory['rows'][idx]['expected_sha256'];assert role['source_id']==registry['files'][idx]['source_id']==inventory['rows'][idx]['source_id'];ab=(p/role['archive']).read_bytes();assert len(ab)==role['archive_bytes'] and sha(ab)==role['archive_sha256'];
 with tarfile.open(p/role['archive'],'r:gz') as t:
  assert t.extractfile(role['member']).read()==b;cargo=t.extractfile('bevy_reflect_derive-0.19.1/Cargo.toml').read();assert cargo==(p/role['archive_cargo_toml']).read_bytes() and sha(cargo)==role['archive_cargo_toml_sha256'];pkg=tomllib.loads(cargo.decode())['package'];assert pkg['name']==role['package'] and pkg['version']==role['version']
 rrset=partition(r['eof'],r['actual_display_ranges'],r['unread_complement']);assert rrset==set(range(1,r['eof']+1));reads[(role['package'],role['version'],role['member'].split('/',1)[1])]=rrset
 orig='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+role['sha256'];assert ('f82adcabd9d89c4fa2dd7f99253a45297a0681ee',orig,role['local_source']) in proofkeys
 for rev in role['pinned_lock_revisions']:
  lock=reg['lock_provenance'][rev];lb=(p/lock['path']).read_bytes();assert sha(lb)==lock['sha256'] and blob(lb)==lock['git_blob'];pkg=next(x for x in tomllib.loads(lb.decode())['package'] if x['name']==role['package'] and x['version']==role['version']);assert pkg['checksum']==role['archive_sha256'] and pkg['source']=='registry+https://github.com/rust-lang/crates.io-index';assert (rev,'Cargo.lock',lock['path']) in proofkeys
supports=[]
for q in sr['prospective_registrations']:
 s=load(q['path']);assert sha((p/q['path']).read_bytes())==q['sha256'] and ts(s['registered_utc'])<ts(sr['recorded_utc']);supports.extend(s['sources'])
assert len(supports)==len(sr['reads'])
for s,r in zip(supports,sr['reads']):
 b=(p/s['local']).read_bytes();assert s['path']==r['path'] and s['sha256']==r['sha256']==sha(b) and len(b)==s['bytes'] and len(b.splitlines())==s['eof'];actual=partition(r['eof'],r['actual_display_windows'],r['unread_complement']);registered={i for lo,hi in s['prospective_ranges'] for i in range(lo,hi+1)};assert actual<=registered
 if s['kind']=='project':
  assert blob(b)==s['git_blob'] and (s['revision'],s['path'],s['local']) in proofkeys;k=(s['revision'],s['path'])
 else:
  with tarfile.open(p/'archives/bevy_reflect_derive-0.19.1.crate','r:gz') as t:assert t.extractfile(s['member']).read()==b
  k=(s['package'],s['version'],s['path'])
 reads.setdefault(k,set()).update(actual)
ls=load('lock-registration.json');assert lr['prospective_registration_sha256']==sha((p/'lock-registration.json').read_bytes()) and ts(ls['registered_utc'])<ts(lr['recorded_utc'])
for s,r in zip(ls['sources'],lr['reads']):
 b=(p/s['local']).read_bytes();assert s['sha256']==r['sha256']==sha(b);actual=partition(r['eof'],r['actual_display_windows'],r['unread_complement']);registered={i for lo,hi in s['prospective_ranges'] for i in range(lo,hi+1)};assert actual<=registered;reads.setdefault((s['revision'],s['path']),set()).update(actual)
objects={}
for oid,o in proof['objects'].items():
 b=gzip.decompress((p/o['archive']).read_bytes());assert len(b)==o['bytes'] and sha(b)==o['sha256'] and hashlib.sha1(o['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def tree_entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
for q in proof['proofs']:
 assert objects[q['revision']].splitlines()[0].split()[1].decode()==q['commit_tree'];tree=q['commit_tree'];assert len(q['path'].split('/'))==len(q['chain'])
 for name,c in zip(q['path'].split('/'),q['chain']):
  assert c['tree']==tree and c['name']==name;mode,tree=tree_entries(objects[tree])[name];assert mode==c['mode'] and tree==c['object']
 assert tree==q['blob']==blob((p/q['archive']).read_bytes())
linked={}
for kind in ('manifest_reference_059','manifest_reference_774'):
 link=hist[kind];f=pathlib.Path(link['path']);linked[kind]=f.is_file()
 if f.is_file():
  z=f.read_bytes();assert sha(z)==link['sha256'];d=json.loads(gzip.decompress(z));key='entries' if kind.endswith('059') else 'files';scope='059' if kind.endswith('059') else '774'
  for e in [x for x in hist['records'] if x['scope']==scope]:assert next(x for x in d[key] if x['path']==e['origin'])==e['manifest_entry']
  if scope=='059':
   inv=next(x for x in d[key] if x['path']=='evidence/audit08/predecessor/source-inventory.json');assert inv['sha256']==sha(inventory_bytes) and inv['bytes']==len(inventory_bytes)
for e in hist['records']:
 b=(p/e['copy']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
 if e['scope'] in ('059','774'):assert e['manifest_entry']['path']==e['origin'] and e['manifest_entry']['sha256']==e['sha256']
 else:assert (e['revision'],e['origin'],e['copy']) in proofkeys
queue=load(hist['reconstructed_queue']);q=pathlib.Path(queue['original_compressed_path']);linked['original_059_queue']=q.is_file()
if q.is_file():
 z=q.read_bytes();assert sha(z)==queue['original_compressed_sha256'];d=json.loads(gzip.decompress(z));assert all(d['entries'][e['index']]==e['record'] for e in queue['rows'])
assert [(e['index'],e['record']['status']) for e in queue['rows']]==[(1445,'open-evidence-or-disposition'),(2332,'open-source-reconciliation'),(3445,'open-source-reconciliation')]
assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
refs=[]
def visit(x):
 if isinstance(x,dict):
  if 'lines' in x and 'path' in x and ('revision' in x or ('package' in x and 'version' in x)):refs.append(x)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
for r in refs:
 k=(r['revision'],r['path']) if 'revision' in r else (r['package'],r['version'],r['path']);assert k in reads,k
 for lo,hi in r['lines']:assert all(i in reads[k] for i in range(lo,hi+1)),(k,lo,hi)
result={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'package_roles_archive_lock_registry_and_transport':len(reg['roles']),'git_membership_proofs':len(proof['proofs']),'support_read_partitions':len(supports),'lock_read_partitions':len(lr['reads']),'historical_and_current_records':len(hist['records']),'report_references_within_actual_personal_reads':len(refs),'partial_lens_perspectives':len(report['lenses']),'historical_queue_statuses_preserved':True},'hash_linked_prior_evidence_available':linked,'qualification':'Evidence integrity only. No macro expansion/execution, package execution, product tests, builds, probes, simulations, repairs or validation.'};(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
