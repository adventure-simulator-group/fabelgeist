from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path.cwd();repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();items=[('spiral-owner','crates/adventuresim-building-generator/src/spiral_stairs.rs',[[1,110]]),('spiral-flight','crates/adventuresim-building-generator/src/spiral_stairs/flight.rs',[[1,197]]),('portal-consumer','crates/adventuresim-building-generator/src/interior/navigation/portals.rs',[[80,130]]),('keep-core','crates/adventuresim-building-generator/src/spiral_stairs/keep_core.rs',[[1,36]])];entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert all(1<=a<=z<=len(raw.splitlines()) for a,z in ranges);local='support/'+name+'.rs';entries.append({'name':name,'path':path,'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':local});pending.append((local,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective current bounded source support; no ordered-role credit for any support or neighboring original role.','entries':entries};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print('support registration',h((b/'support-registration.json').read_bytes()))
