from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path.cwd();h=lambda x:hashlib.sha256(x).hexdigest();L=lambda n:json.loads((b/n).read_bytes());reg=L('registration.json');nav={};raw=(b/'navigation-plan.txt').read_bytes();lines=raw.decode().splitlines()
for line in lines:
 m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m;nav.setdefault(m.group(1),set()).add(int(m.group(2)))
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=row['original_material_ranges'];assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'local':v['local'],'sha256':v['sha256'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':d if j==0 else [],'unread_complement':comp(v['eof'],nums(d)),'qualification':'Old and current copies displayed separately after registration; 6533 copy mechanically compared only.'})
support=[]
for regname in ['support-registration.json','support-registration-extra.json']:
 for x in L(regname)['entries']:
  d=[[1,100],[101,197]] if x['name']=='spiral-flight' else x['ranges'];used=nums(d);navonly=sorted(nav.get(x['path'],set())-used)
  support.append({'name':x['name'],'registration':regname,'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'navigation_only_lines':navonly,'unread_complement':comp(x['eof'],used|set(navonly)),'ordered_role_credit':0,'qualification':'Support only; keep-core role2840 is separately owned and not credited here.'})
names=['registration.json','support-registration.json','support-registration-extra.json','navigation-registration.json'];d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Reconstructed actual personal display receipt after prospective registration, no historical reader transfer.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':L(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':[{'output':'navigation-plan.txt','sha256':h(raw),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]],'unread_saved_output_lines':[],'registration':'navigation-registration.json','ordered_role_credit':0}],'navigation_actual_source_lines':{k:sorted(v) for k,v in sorted(nav.items())},'limits':'No product, geometry, tests, fixtures, build, runtime probe, repair or publication edit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt sha256',h((b/'read-receipt.json').read_bytes()))
