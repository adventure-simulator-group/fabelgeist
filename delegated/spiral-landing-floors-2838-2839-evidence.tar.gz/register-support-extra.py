from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path.cwd();repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();entries=[];pending=[]
for name,path,ranges in [('plan-fields','crates/adventuresim-building-generator/src/model/plan.rs',[[1,45]]),('resolved-fields','crates/adventuresim-building-generator/src/model/resolved_networks.rs',[[355,390]])]:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';entries.append({'name':name,'path':path,'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':loc});pending.append((loc,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective current public aggregate shape support; not original role credit.','entries':entries};(b/'support-registration-extra.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:(b/n).write_bytes(raw)
print('registration sha256',h((b/'support-registration-extra.json').read_bytes()))
