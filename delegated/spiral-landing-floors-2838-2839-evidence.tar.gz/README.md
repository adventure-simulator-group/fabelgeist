# Spiral landing and floor helper evidence

Roles 2838–2839 are the pr-working landing policy and occupied-floor helpers.
Their historical and pinned 95e bodies were prospectively registered and
separately displayed in full. Each matches its 6533 per-file object; the recorded
pr-working snapshot has unrelated modifications and is not claimed clean.

`REPORT.json` records 13 bounded lens perspectives and reconnects the original
Camera F047 source-level landing identity/pose question. Selected initial
resolution uses the same occupied-cell predicate, while a later portal query
recompiles the mutable recipe after only an owner-level landing check. No
supported one-sided mutation, physical incident or navigation acceptance is
claimed. The auxiliary crown landing is a distinct deliberate destination.

`read-receipt.json` identifies actual registered bodies, bounded current support
and match-only navigation. The neighboring keep-core role was support only.
The 059 Segovb fresh reads, separately delegated PL13-066 reads and Root's
zero-reread adoption remain separately attributed. `historical/` retains the
original records and qualifications; `historical-selections-reconstructed.json`
is a new selection, not an original receipt. Historical registration file SHA
86c5… differs from the f82 whole-file SHA 0468… despite equal parsed rows 41–42;
no earlier whole-file recovery or global absence is inferred.

`git-proofs.json` and `git-objects/` preserve 20 offline membership proofs.
The unrelated P16 tracked patch is a later matching-digest recovery with its own
command, custody and seven untracked-object qualifications. `MANIFEST.json`
covers every packet file except itself, including nested manifests. Running
`python3 verify-evidence.py` checks evidence integrity only; it does not execute
product code, geometry, fixtures, or tests.
