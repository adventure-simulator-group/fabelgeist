import datetime,hashlib,json,subprocess
from pathlib import Path
r=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda b:hashlib.sha256(b).hexdigest();paths=['crates/adventuresim-core/src/item_catalog_validation.rs','crates/adventuresim-core/src/item_catalog_validation_surface.rs','crates/adventuresim-core/src/item_catalog_schema.rs','crates/adventuresim-core/src/item_catalog.rs','crates/adventuresim-core/build.rs','crates/adventuresim-character-creator/src/armor_metal.rs'];rows=[];bs=[]
for i,path in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);oid=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();rows.append({'path':path,'revision':rev,'git_blob':oid,'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'saved':'support/'+str(i)+'.rs','prospective_ranges':[[1,len(b.splitlines())]],'scope':'current support only, never other agent role credit'});bs.append(b)
d={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','sources':rows,'qualification':'Full range registered for targeted navigation and display; only explicit displayed material credited in subsequent receipt.'}
with (r/'support-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for x,b in zip(rows,bs):(r/x['saved']).write_bytes(b)
print(d['registered_utc']);print([(x['saved'],x['path'],x['lines']) for x in rows])
