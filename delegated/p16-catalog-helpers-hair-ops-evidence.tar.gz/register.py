import datetime,gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
r=Path('<LOCAL_PATH_0>');pub=Path('<LOCAL_PATH_1>');arc=pub/'recovered/original-registry-source-archive';cur='95e63628f9d70b8dd6e6fede64334696c6995009';base='a120390947c89b703dc74c4255a13c035d054c50';tr='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';live=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest(); raw=gzip.decompress((arc/'registry.json.gz').read_bytes());assert h(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw)['files'];m=json.loads((arc/'MANIFEST.json').read_text());assert h((arc/'objects.tar.gz').read_bytes())==m['objects_archive_sha256'];rows=[];copies={}
with tarfile.open(arc/'objects.tar.gz','r:gz') as t:
 for i in [2583,2584]:
  e=reg[i];sha=e['sha256'];name=e['source_id'].split(':',1)[1];old=t.extractfile(sha).read();assert sha==h(old) and len(old)==e['bytes'];gp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+sha;assert subprocess.check_output(['git','-C',str(pub),'show',tr+':'+gp])==old
  versions=[];cb=None
  for rev in [base,cur]:
   b=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+name]);oid=subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+name],text=True).strip();versions.append({'revision':rev,'git_blob':oid,'sha256':h(b),'bytes':len(b),'eof':len(b.splitlines()),'equal_p16_object':b==old})
   if rev==cur:cb=b
  lb=(live/name).read_bytes();rows.append({'role':i,'original_registry_record':e,'path':name,'p16_sha256':sha,'p16_bytes':len(old),'p16_eof':len(old.splitlines()),'f82_transport_object':gp,'base_and_current':versions,'live_p16_file_sha256':h(lb),'live_p16_equal':lb==old,'prospective_reads':{'historical_p16':[[1,len(old.splitlines())]],'current_95e':[[1,len(cb.splitlines())]]},'qualification':'Original P16 dirty source object; clean base and current are separately verified per-file identities. Later live P16 recovery is not prior source-read attribution.'});copies[i]=(old,cb)
d={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','source_revision':cur,'p16_base':base,'p16_transport':tr,'registry_sha256':h(raw),'registry_source_archive_sha256':m['objects_archive_sha256'],'prior_reproduced_p16_patch_comparison':'<LOCAL_PATH_3>','prior_p16_comparison_sha256':h(Path('<LOCAL_PATH_3>').read_bytes()),'rows':rows,'rule':'Registration before separate personal displays of exact P16 and current bodies; equality is not separate historical credit and whole snapshot remains dirty.'}
with (r/'registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for sub in ['source','historical','support']:(r/sub).mkdir()
for i,(old,now) in copies.items():(r/'source'/('p16-'+str(i)+'.rs')).write_bytes(old);(r/'source'/('95e-'+str(i)+'.rs')).write_bytes(now)
print('registered',d['registered_utc']);print([(x['role'],x['p16_sha256'],[(v['revision'][:7],v['sha256'],v['equal_p16_object']) for v in x['base_and_current']],x['live_p16_equal']) for x in rows])
