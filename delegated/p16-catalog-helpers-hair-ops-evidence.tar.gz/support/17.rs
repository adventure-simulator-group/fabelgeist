[package]
name = "adventuresim-core"
version.workspace = true
edition.workspace = true
repository.workspace = true
license.workspace = true
build = "build.rs"

[features]
default = []
spacetimedb = ["dep:spacetimedb", "adventuresim-world-schema/spacetimedb", "fabelgeist-determinism/spacetimedb"]

[dependencies]
fabelgeist-geometry.workspace = true
fabelgeist-math.workspace = true
thiserror.workspace = true
enum-assoc = "1.3.0"
blanket = "0.4.0"
ambassador = "0.5.0"
enumflags2 = "0.7.12"
serde.workspace = true
serde_json.workspace = true
serde-saphyr.workspace = true
sha2.workspace = true
adventuresim-world-schema.workspace = true
adventuresim-dialogue.workspace = true
adventuresim-puzzles.workspace = true
adventuresim-weapon-model.workspace = true
fabelgeist-determinism.workspace = true
spacetimedb = { workspace = true, optional = true }

[build-dependencies]
fabelgeist-math.workspace = true
thiserror.workspace = true
serde = { workspace = true, features = ["derive"] }
serde_json.workspace = true
serde-saphyr.workspace = true
sha2.workspace = true
adventuresim-world-schema.workspace = true

[dev-dependencies]
spacetimedb-sats.workspace = true

[lints]
workspace = true
