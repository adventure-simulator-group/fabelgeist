[package]
name = "adventuresim-weapon-model"
version.workspace = true
edition.workspace = true
repository.workspace = true
license.workspace = true

[dependencies]
serde.workspace = true
serde_json = { workspace = true, features = ["float_roundtrip"] }
sha2.workspace = true
thiserror.workspace = true
tiny-skia.workspace = true
glam = "0.32.1"



[lints]
workspace = true
