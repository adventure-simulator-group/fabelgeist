import datetime,hashlib,json,subprocess,tarfile
from pathlib import Path
r=Path('<LOCAL_PATH_0>');pub=Path('<LOCAL_PATH_1>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda b:hashlib.sha256(b).hexdigest();paths=['crates/adventuresim-tactical-core/src/inventory.rs','crates/adventuresim-tactical-server/src/equipment.rs','crates/adventuresim-tactical-client/src/equipment/placeholder_visual.rs','crates/adventuresim-tactical-client/src/equipment/grab_world.rs','Cargo.lock'];rows=[];bs=[]
for i,path in enumerate(paths,6):
 b=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path]);oid=subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+path],text=True).strip();rows.append({'path':path,'revision':rev,'git_blob':oid,'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'saved':'support/'+str(i)+'.rs','prospective_ranges':[[1,len(b.splitlines())]],'scope':'current support only'});bs.append(b)
native=[];nbs=[]
for i,(package,member) in enumerate([('serde_json-1.0.151','serde_json-1.0.151/src/value/de.rs'),('serde_json-1.0.151','serde_json-1.0.151/src/number.rs'),('serde_json-1.0.151','serde_json-1.0.151/src/de.rs'),('serde_core-1.0.229','serde_core-1.0.229/src/de/impls.rs')],11):
 archive=pub/'native-evidence'/package/(package+'.crate');
 with tarfile.open(archive,'r:gz') as t:b=t.extractfile(member).read()
 native.append({'name':member,'archive':str(archive),'archive_sha256':h(archive.read_bytes()),'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'saved':'support/'+str(i)+'.native','prospective_ranges':[[1,len(b.splitlines())]],'scope':'native package source support only'});nbs.append(b)
d={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','sources':rows,'native':native,'qualification':'Full ranges registered for navigation and bounded display. Exact displayed scopes are recorded separately; package source is not project Git or execution.'}
with (r/'support-registration-2.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for x,b in zip(rows,bs):(r/x['saved']).write_bytes(b)
for x,b in zip(native,nbs):(r/x['saved']).write_bytes(b)
print(d['registered_utc']);print([(x['saved'],x['path'],x['lines']) for x in rows]);print([(x['saved'],x['name'],x['lines']) for x in native])
