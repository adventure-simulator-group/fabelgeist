# Bounded P16 catalog numeric and material helper audit

`REPORT.json` covers original roles 2583–2584. Their historical P16 and 95e
bodies were separately displayed, while a120 and 6533 file identities were
verified without claiming extra source reads. The original P16 snapshot remains
dirty; the later recovered tracked patch, separately retained untracked objects,
and all original rig/camera/059 review attributions remain qualified.

The existing positive-dimension narrowing finding is supported, and a connected
finite-f64 to f32 overflow candidate is recorded with distinct, feature-dependent
preflight and runtime outcomes. No input or runtime result has been demonstrated.
The material-name check agrees with the current typed enum. Exact source scopes,
Git proofs, historical records, safeguards and open questions are in the JSON.
Prior evidence, native package archives and the parallel rig agent's separate
packet are hash-linked; central publication must preserve or relink exact bytes.

`python3 verify-evidence.py` checks evidence integrity and read partitions only.
No product, decoder, build, test, fixture, renderer or runtime probe ran.
