import gzip,hashlib,json,subprocess,datetime
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());s1=json.loads((p/'support-registration.json').read_bytes());s2=json.loads((p/'support-registration-2.json').read_bytes());s3=json.loads((p/'support-registration-3.json').read_bytes());hist=json.loads((p/'historical-manifest.json').read_bytes());pr=json.loads((p/'pr-file-comparison.json').read_bytes());objects={};proofs=[];(p/'git-objects').mkdir()
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for x in reg['rows']:
 n=x['role'];members.extend([{'revision':reg['p16_transport'],'path':x['f82_transport_object'],'local':f'source/p16-{n}.rs','qualification':'P16 recovered evidence object; not whole clean snapshot.'},{'revision':reg['p16_base'],'path':x['path'],'local':f'source/p16-{n}.rs','qualification':'P16 clean-base per-file match.'},{'revision':reg['source_revision'],'path':x['path'],'local':f'source/95e-{n}.rs','qualification':'Current role personally displayed.'}])
for x in pr['rows']:members.append({'revision':x['revision'],'path':x['path'],'local':f"source/p16-{x['role']}.rs",'qualification':'Historic 6533 per-file hash check only, not new body display.'})
for x in s1['sources']+s2['sources']+s3['sources']:members.append({'revision':x['revision'],'path':x['path'],'local':x['saved'],'qualification':'95e bounded support only.'})
for x in hist['exact_original_files']:
 if x.get('transport_revision'):members.append({'revision':x['transport_revision'],'path':x['git_path'],'local':x['local'],'qualification':'Original 774 document; no transferred credit.'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();top=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert tree==blob(b);proofs.append({**s,'commit_tree':top,'chain':chain,'blob':tree,'sha256':sha(b)})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Per-file f82 source/receipt and a120,6533,95e Git memberships; original P16 dirty snapshot not clean.','objects':objects,'proofs':proofs},indent=2)+'\n')
windows={'support/0.rs':[[110,290],[390,410],[500,532],[637,735]],'support/1.rs':[[1,145]],'support/2.rs':[[1,90],[115,160]],'support/3.rs':[[1,75]],'support/4.rs':[[222,285]],'support/5.rs':[[1,90]],'support/6.rs':[[156,215]],'support/7.rs':[[200,230],[504,575]],'support/8.rs':[[1,63]],'support/9.rs':[[1,80]],'support/10.rs':[[9395,9404],[9417,9430]],'support/11.native':[[169,193],[282,314]],'support/12.native':[[535,546],[582,599]],'support/13.native':[[109,128],[319,354],[623,671],[1500,1515]],'support/14.native':[[129,151],[222,242],[450,456]],'support/15.rs':[[775,835],[885,915]],'support/16.rs':[[1,19]],'support/17.rs':[[1,45]]}
def complement(n,ranges):
 used=set()
 for a,b in ranges:used.update(range(a,b+1))
 arr=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):arr.append([start,i-1]);start=None
 return arr
reads=[]
for x in s1['sources']+s2['sources']+s2['native']+s3['sources']:
 w=windows[x['saved']];reads.append({'path':x.get('path',x.get('name')),'revision':x.get('revision','external package'),'saved':x['saved'],'sha256':x['sha256'],'eof':x['lines'],'actual_display_ranges':w,'unread_complement':complement(x['lines'],w),'qualification':'Support only; no other ordered-role attribution or product execution.'})
rr={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in ['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json']],'assigned_roles':[{'index':x['role'],'historical_p16_source':f"source/p16-{x['role']}.rs",'current_95e_source':f"source/95e-{x['role']}.rs",'historical_and_current_separate_display_ranges':[[1,x['p16_eof']]],'historical_unread':[],'current_unread':[],'prior_774_rig_material':x['original_registry_record']['material_ranges'],'original_snapshot_field':x['original_registry_record']['snapshot'],'source_id':x['original_registry_record']['source_id'],'qualification':'Both exact P16 and 95e copies were personally displayed separately; a120 and 6533 versions were hash/Git verified only.'} for x in reg['rows']],'support_reads':reads,'navigation':'Search navigation, some truncated, is not included as assessed body outside explicit windows.','qualification':'Original and current source displays occurred after registration. Other agent roles remain support-only; no product, package, build, test, probe or runtime execution.'}
(p/'read-receipt.json').write_text(json.dumps(rr,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'support',len(reads))
