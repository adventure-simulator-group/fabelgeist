'''Evidence integrity verification only; no product, build, package, test, fixture or runtime execution.'''
import gzip,hashlib,json,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());rec=json.loads((p/'read-receipt.json').read_bytes());hist=json.loads((p/'historical-manifest.json').read_bytes());pr=json.loads((p/'git-proofs.json').read_bytes());supp=json.loads((p/'support-registration-2.json').read_bytes());
for x in hist['hash_links']:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
for x in hist['exact_original_files']:
 b=(p/x['local']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
for x in rec['prospective_registrations']:assert sha((p/x['path']).read_bytes())==x['sha256']
archive=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/objects.tar.gz')));assert sha(archive.read_bytes())==reg['registry_source_archive_sha256']
with tarfile.open(archive,'r:gz') as tar:
 for x in reg['rows']:
  old=(p/f"source/p16-{x['role']}.rs").read_bytes();new=(p/f"source/95e-{x['role']}.rs").read_bytes();assert sha(old)==x['p16_sha256'] and old==new==tar.extractfile(x['p16_sha256']).read() and len(old.splitlines())==x['p16_eof'] and all(v['equal_p16_object'] for v in x['base_and_current'])
for x in supp['native']:
 a=Path(x['archive']);assert sha(a.read_bytes())==x['archive_sha256'];b=(p/x['saved']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 with tarfile.open(a,'r:gz') as t:assert t.extractfile(x['name']).read()==b
for x in rec['support_reads']:
 b=(p/x['saved']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof'];used=[]
 for a,z in x['actual_display_ranges']+x['unread_complement']:assert 1<=a<=z<=x['eof'];used.extend(range(a,z+1))
 assert len(used)==x['eof'] and set(used)==set(range(1,x['eof']+1))
objects={}
for oid,x in pr['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 raise ValueError(name)
for x in pr['proofs']:
 current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for st in x['chain']:
  assert current==st['tree'];mode,child=lookup(objects[current],st['name']);assert mode==st['mode'] and child==st['object'];current=child
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and sha(b)==x['sha256']
rr=[json.loads(l) for l in (p/'historical/774-rig--admission03--source-range-registration.jsonl').read_text().splitlines()];qq=[json.loads(l) for l in (p/'historical/774-rig--admission03--source-qualifications.jsonl').read_text().splitlines()]
for x in reg['rows']:
 for ob in x['original_registry_record']['admission03_scope_observations']:assert rr[ob['row_1based']-1]==ob['original_record'] and all(q in qq for q in ob['local_qualifications'])
sel=json.loads((p/'historical/774-contract-selection-reconstructed.json').read_text());b=Path(sel['source_path']).read_bytes();assert len(b)==sel['source_bytes'] and sha(b)==sel['source_sha256'];lines=b.splitlines(keepends=True)
for x in sel['rows']:assert lines[x['row_1based']-1]==x['raw_utf8'].encode() and sha(lines[x['row_1based']-1])==x['sha256']
sel=json.loads((p/hist['prior_ledger_selection']).read_text());b=Path(sel['source_path']).read_bytes();assert sha(b)==sel['source_sha256'];j=json.loads(b);assert j['segovb_continuation']['lens13']['delegated_connected_contracts_pending_alias'][281]==sel['value']
if (p/'MANIFEST.json').exists():
 for x in json.loads((p/'MANIFEST.json').read_bytes())['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
print('Evidence checks passed: two P16/current role identities, 27 Git membership chains, 774 registrations and exact selected records, reconstructed 059 ledger selection, 18 support read partitions, four locked native archive members and prior evidence hash links. No product execution or validation.')
