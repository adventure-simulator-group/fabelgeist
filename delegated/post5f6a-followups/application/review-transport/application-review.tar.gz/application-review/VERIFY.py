#!/usr/bin/env python3
import pathlib,hashlib,json,stat,sys
p=pathlib.Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('optimization prohibited')
def req(x,s):
 if not x:raise ValueError(s)
def j(n):return json.loads((p/n).read_bytes())
def h(b):return hashlib.sha256(b).hexdigest()
m=j('MANIFEST.json');rows={}
for f in sorted(p.rglob('*')):
 rel=f.relative_to(p).as_posix();req(not f.is_symlink(),'symlink')
 if f.is_file() and rel!='MANIFEST.json':
  b=f.read_bytes();rows[rel]={'sha256':h(b),'bytes':len(b),'mode':stat.S_IMODE(f.stat().st_mode)}
req(rows==m['files'],'manifest inventory')
a=j('STRUCTURE-CHECK.json');b=j('V4-CHECK.json');r=j('REPORT.json');req(a['result']==b['result']=='pass' and a['ledger_before']==1103 and a['ledger_after']==1106 and a['queue_before']=={'partial':1364,'unassessed':2349} and a['queue_after']=={'partial':1370,'unassessed':2343},'recorded result');req(r['draft_sha256']==h((p/'captured-v4/DRAFT.json').read_bytes()) and r['transform_sha256']==h((p/'captured-v4/TRANSFORM.py').read_bytes()) and r['correction_sha256']==h((p/'captured-v4/CORRECTION.json').read_bytes()),'v4 identity')
print(json.dumps({'result':'pass','files':len(rows),'qualification':'Public receipt integrity and recorded evidence results; full source/queue comparison requires restricted capture.'},sort_keys=True))
