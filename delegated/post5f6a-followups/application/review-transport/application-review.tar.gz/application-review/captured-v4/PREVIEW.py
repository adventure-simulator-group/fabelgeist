#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess
import sys
if sys.flags.optimize:raise RuntimeError('Evidence assertions require an unoptimized interpreter')
from TRANSFORM import NAMES,QNAME,RNAME,transform
p=Path(__file__).resolve().parent;repo=p.parent.parent/'publication';before={n:(p/'before'/n).read_bytes() for n in NAMES};report=json.loads((p/'DRAFT.json').read_bytes());obs=json.loads((p/'MAIN-RECHECK-20261113-0536.json').read_bytes());proposals={n:subprocess.check_output(['git','show',report['parent_checkpoint']+':'+n],cwd=repo) for n in [QNAME,RNAME]};after=transform(before,report,obs,proposals);out=p/'preview-after';out.mkdir(mode=0o700);rows=[]
for n,b in after.items():
 with (out/n).open('xb') as f:f.write(b)
 rows.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
q=json.loads(after['RECONCILIATION-059.json'])['entries'];ids=[10,13,3447,3448,3450,3451]
for i in ids:
 for f in q[i]['further_current_evidence'][1:]:assert (repo/f).is_file(),f
r={'schema':'726-post5f6a-application-preview-v1','status':'private preview only; not an adopted application','draft_sha256':hashlib.sha256((p/'DRAFT.json').read_bytes()).hexdigest(),'after':rows,'counts':report['counts'],'qualification':'Evidence-only pure transform. No publication file changed; exact predecessor and review identities remain separately bound. A separate independent application review is required before adoption.'}
with (p/'PREVIEW.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps({'files':len(rows),'partial_after':1370,'unassessed_after':2343,'ledger_after':1106}))
