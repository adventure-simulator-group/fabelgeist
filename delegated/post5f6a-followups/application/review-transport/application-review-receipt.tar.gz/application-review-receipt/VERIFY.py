#!/usr/bin/env python3
import pathlib,json,hashlib,stat,sys,argparse
p=pathlib.Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('optimization prohibited')
def req(x,s):
 if not x:raise ValueError(s)
def j(n):return json.loads((p/n).read_bytes())
def h(b):return hashlib.sha256(b).hexdigest()
m=j('MANIFEST.json');rows={}
for f in sorted(p.rglob('*')):
 rel=f.relative_to(p).as_posix();req(not f.is_symlink(),'symlink')
 if f.is_file() and rel!='MANIFEST.json':
  b=f.read_bytes();rows[rel]={'sha256':h(b),'bytes':len(b),'mode':stat.S_IMODE(f.stat().st_mode)}
req(rows==m['files'],'manifest');x=j('SCAN-RESULT.json');req(all(v==0 for v in x['exit_codes'].values()) and x['gpu_forbidden_matches']==x['q2332_matches']==x['059_matches']==x['exceptions']==0 and not x['gpu_other_candidates'],'scan');req(j('PUBLIC-REPLAY.json')['result']=='pass','public replay')
a=argparse.ArgumentParser();a.add_argument('--public',type=pathlib.Path);z=a.parse_args()
if z.public:req(h((z.public/'MANIFEST.json').read_bytes())==j('REPORT.json')['public_manifest_sha256'],'public binding')
print(json.dumps({'result':'pass','files':len(rows),'public_bound':bool(z.public),'qualification':'Receipt identity and bounded scan outcomes only.'},sort_keys=True))
