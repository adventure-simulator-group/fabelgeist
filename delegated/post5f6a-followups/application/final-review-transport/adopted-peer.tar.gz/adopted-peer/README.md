# Independent adopted-report candidate check

This is a bounded structural review. Exact staged targets, application archive,
Git objects, peer evidence and prior-guard output are separately held under
restricted manifest SHA-256
a8d4028b1fb948765bd1e00f95219ff42df0deb34183fc0cc58ea9e29d5eeebe.

Run VERIFY.py for public identity checks; add --restricted with the separately
held private directory for full captured object, transform, target and review
checks. Public files alone cannot reconstruct the restricted originals. The
optional predecessor guards also need their exact clean checkout and keys.
Local observations are time-bound; privacy scanning is finite. No product
validation, independent custody or semantic closure is claimed.
