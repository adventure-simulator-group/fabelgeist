#!/usr/bin/env python3
import pathlib,json,hashlib,argparse,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((P/n).read_bytes());a=argparse.ArgumentParser();a.add_argument('--restricted');o=a.parse_args();m=J('MANIFEST.json');expect={r['path']:r for r in m['files']};actual={f.relative_to(P).as_posix():f for f in P.rglob('*') if f.is_file() and f!=P/'MANIFEST.json'};assert set(expect)==set(actual)
for n,f in actual.items():
 b=f.read_bytes();r=expect[n];assert H(b)==r['sha256'] and len(b)==r['bytes'] and oct(f.stat().st_mode&0o777)==r['mode']
assert {f.relative_to(P).as_posix():oct(f.stat().st_mode&0o777) for f in P.rglob('*') if f.is_dir()}==m['dirs']
s=J('RESULT-SUMMARY.json');assert [s[k] for k in ['application_members','git_bound_parent_paths','staged_targets','after_images','application_review_members','review_receipt_members']]==[17,6,5,4,15,8] and [s[k] for k in ['semantic_closures','unique_defect_increment','lenses_completed']]==[0,0,0]
c=J('CANDIDATE.json');assert c['status']=='candidate only; not installed or published' and len(c['targets'])==5 and len(c['after'])==4;assert J('PRELIMINARY.json')['only_expected_fields']
assert H((P/'APPLICATION-REVIEW-MANIFEST.json').read_bytes())=='3fecc064492e45fa2a39c91eca43856988465877b405c946611160c9fff85c69'
if o.restricted:
 r=pathlib.Path(o.restricted);assert H((r/'MANIFEST.json').read_bytes())=='a8d4028b1fb948765bd1e00f95219ff42df0deb34183fc0cc58ea9e29d5eeebe';aliases={'CANDIDATE.json':'inputs/candidate/CANDIDATE.json','APPLICATION-RECORD.json':'inputs/application/RECORD.json','APPLICATION-REVIEW-MANIFEST.json':'inputs/application-review/MANIFEST.json'}
 for n,f in actual.items():
  if n not in {'README.md','VERIFY.py'}:assert f.read_bytes()==(r/aliases.get(n,n)).read_bytes()
 z=subprocess.run([sys.executable,'-B',str(r/'VERIFY.py')],capture_output=True,text=True);assert z.returncode==0,z.stderr
 print('Separately held restricted object, transform, target and review-archive checks passed.')
else:print('Public manifest and bounded summary identities passed; original objects, targets and replay require restricted custody.')
print('Optional predecessor guards need a separately held clean checkout and keys; product behavior, independent custody and semantic closure are not certified.')
