# Clarification of predecessor replay and keys

The earlier peer report and public checker overstate that keys are needed to
repeat the optional predecessor guards. The recorded guard-only replay passed
on a clean same-machine predecessor checkout while its output expressly says
that encrypted-payload decryption, plaintext-archive checks and original
restoration were not repeated. The replay did not establish keys as necessary
for those guard-only checks.

The exact clean predecessor checkout and its Git objects are needed to repeat
the optional checkout-bound guards. Separately held keys remain dependencies
for full encrypted recovery, including decryption and original restoration.
Neither the guard replay nor this clarification establishes independent custody,
product behavior, semantic closure or checkpoint 3821 recovery. The earlier
sealed packet remains unchanged; its structural findings and replay result are
not altered.
