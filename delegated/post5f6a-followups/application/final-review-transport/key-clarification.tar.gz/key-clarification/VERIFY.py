#!/usr/bin/env python3
import pathlib,json,hashlib,argparse,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((P/n).read_bytes());a=argparse.ArgumentParser();a.add_argument('--restricted');o=a.parse_args();m=J('MANIFEST.json');fs={f.name:f for f in P.iterdir() if f.is_file() and f.name!='MANIFEST.json'};assert set(fs)=={r['path'] for r in m['files']}
for r in m['files']:
 b=fs[r['path']].read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes'] and oct(fs[r['path']].stat().st_mode&0o777)==r['mode']
x=J('BINDINGS.json');assert x['earlier_public_manifest_sha256']=='d1c2bb96bf5fc1e70135dad29ae0f42c5a60d4086e3f786b7ff3f19362796638'
if o.restricted:
 r=pathlib.Path(o.restricted);assert H((r/'MANIFEST.json').read_bytes())==x['clarification_restricted_manifest_sha256'] and (P/'NOTE.md').read_bytes()==(r/'NOTE.md').read_bytes();z=subprocess.run([sys.executable,'-B',str(r/'VERIFY.py')],capture_output=True,text=True);assert z.returncode==0,z.stderr
print('Clarification identity checked; no decryption, product behavior or independent custody asserted.')
