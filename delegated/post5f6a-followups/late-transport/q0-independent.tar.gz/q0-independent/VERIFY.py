#!/usr/bin/env python3
import pathlib,json,hashlib,argparse,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((P/n).read_bytes());a=argparse.ArgumentParser();a.add_argument('--restricted');o=a.parse_args();m=J('MANIFEST.json');expect={r['path']:r for r in m['files']};actual={f.relative_to(P).as_posix():f for f in P.rglob('*') if f.is_file() and f!=P/'MANIFEST.json'};assert set(expect)==set(actual)
for n,f in actual.items():
 b=f.read_bytes();r=expect[n];assert H(b)==r['sha256'] and len(b)==r['bytes'] and oct(f.stat().st_mode&0o777)==r['mode']
assert {f.relative_to(P).as_posix():oct(f.stat().st_mode&0o777) for f in P.rglob('*') if f.is_dir()}==m['dirs']
for n in ['SOURCE-CAPTURE.json','SOURCE-CAPTURE-006.json','SOURCE-CAPTURE-007.json','SOURCE-CAPTURE-008.json']:
 for r in J(n):assert H((P/'source'/r['window']).read_bytes())==r['sha256']
h=J('HISTORY-SUMMARY.json');assert h['lens']==8 and h['f2ec_status']=='unassessed' and h['q61_lens']==11 and h['f2ec_ledger_row']==217 and h['before_revision']=='unknown'
x=J('STATIC-CHECK.json');assert x['placeholder_three_way_equal'] and x['old_current_selection_equal']
if o.restricted:
 r=pathlib.Path(o.restricted);assert H((r/'MANIFEST.json').read_bytes())=='06fd89716f3d6f311d7ba47d405990466d7125c8313fab3b7b458cfd592b304a';assert (P/'delegate-manifest.json').read_bytes()==(r/'delegate/public-v2/MANIFEST.json').read_bytes()
 for f in actual.values():
  n=f.relative_to(P)
  if n.as_posix() not in {'README.md','VERIFY.py','delegate-manifest.json','CORRECTION-SUMMARY.json'}:assert f.read_bytes()==(r/n).read_bytes()
 c=J('CORRECTION-SUMMARY.json');assert c['prior_manifest_sha256']==H((r/'delegate/public-v1/MANIFEST.json').read_bytes()) and c['successor_manifest_sha256']==H((r/'delegate/public-v2/MANIFEST.json').read_bytes()) and c['prior_report_sha256']==H((r/'delegate/public-v1/REPORT.md').read_bytes()) and c['successor_report_sha256']==H((r/'delegate/public-v2/REPORT.md').read_bytes())
 z=subprocess.run([sys.executable,'-B',str(r/'VERIFY.py')],capture_output=True,text=True);assert z.returncode==0,z.stderr
 print('Separately held restricted evidence, exact delegate packet, source objects, history and predecessor correction passed.')
else:print('Public manifest and selected source-window identities passed; original sources, before-byte and history proofs need restricted custody.')
print('Display is attested; before Git revisions, runtime behavior, supported reach and closure remain open.')
