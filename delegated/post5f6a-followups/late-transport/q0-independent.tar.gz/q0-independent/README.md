# Independent q0 packet check

This bounded peer review includes fresh source windows and a public-manifest
identity for the original reviewer. Exact delegate versions, Git objects,
recovered before sources and histories are separately held under restricted
manifest SHA-256
06fd89716f3d6f311d7ba47d405990466d7125c8313fab3b7b458cfd592b304a.

Run VERIFY.py for public checks; add --restricted with the separately held
private directory for object, diff, history and predecessor replay. Public
evidence alone cannot recreate the originals. Source display is an attestation
and privacy scans are finite. Before Git revisions, runtime behavior, supported
reach and closure remain open.
