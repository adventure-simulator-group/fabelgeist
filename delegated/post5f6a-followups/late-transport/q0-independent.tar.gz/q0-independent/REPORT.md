# Independent peer review of q0 retained fit

The original q0 source packet was authored by a different reviewer. This
independent bounded Lens 8 check supports its central old/new distinction and
its conditional reach and outcome limits. It does not establish an ordinary
gameplay mutation, authorize the change, assign an alias or count, close a
queue or validate product behavior.

In the recovered before generation body, `generation.rs:24–73` retains a
previous unworn fit's shape, placement and layers but sets the key's item to
the current presentation ID. In the 6533 and pinned 95e generation bodies,
`:23–95` returns the previous typed selection when not fitted to the owner and
a previous selection exists. Current `layers.rs:13–37` ties that selection
to its catalog item/placement pair. Thus an unworn presentation B with a
retained fit A has an old key containing current item B and newer selection
A. Whether the old B/previous-placement combination was valid, or which
policy should govern a changing item, remains undecided. The 6533/95e
selection-function slices are byte-identical; their whole generation files
are not, and the complete captured 55-line diff concerns other changes.

The full `spawn_item_placeholders` body is byte-identical across the
recovered before equipment body `:1071–1158`, the 36c overlay `:818–905`,
and pinned 95e `:428–515`. Under its displayed valid-physical and change
conditions it despawns old placeholders and removes attachment sockets but
does not remove the item-owned `LastFit`. Current `runtime_equipment.rs:
127–142` copies `ItemProperties.id` into the presentation; the public `id`
field is in tactical-core `inventory.rs:101–106`. Current `generation.rs:
314–348` queries the presentation's item and prefers item LastFit over the
presentation's current key, while fitting to owner requires no scene marker,
no holding side and an owner. Scheduling, admission and other execution
conditions remain necessary. Public mutability establishes a representable
state, not a supported same-entity transition.

The retained selection reaches the generation request at `generation.rs:
163–213`; successful results use its item for sockets and generated parts at
`:217–258`, and a successful cache entry attaches the model at `:411–428`.
The attachment's Bevy name uses the current presentation ID (`:263–290`),
which is not evidence of a player-visible name. Errors, failed generation,
cache readiness, rendering and actual consumer effects remain open.

The selected server projection reserves new tactical item entities
(`player_projection.rs:777–810`), and the selected strategic wardrobe path
despawns/recreates equipment when its view changes (`strategic_scene/
equipment.rs:14–49`). Neither establishes a supported A-to-B mutation on
the same entity, nor is either a global absence proof. The historical arming
doublet/linen tunic illustration has authored entries and worn placements
and a doublet recipe; the clothing-classification path is visible in source.
Normal catalog, recipe and native admission and actual execution remain
unvalidated.

Original 059 q61 and f2ec ledger217 instead start from owned fit/preparation
failure context and readiness under Lens 11, with their own original reviewer
and partial scope. They share the equipment family but are not proven aliases
of q0's retained-selection first operation. Historical M07 and M06 labels
remain recorded relationships, not accepted aliases or unique counts.

The before equipment and before generation bodies are recovered by their
recorded hashes, but their original before Git revisions are unknown. The
checked historical equipment head is the qualified 36c overlay; generation
head is 6533; f82 is a normalized recovered transport, not proof of missing
pre-export originals. Exact diff application binds the before bytes to those
heads, not to an independently established before revision. Earlier q0
continuation evidence is qualified same-lens adoption, not a fresh personal
read. The selected authoritative current source is 95e; per-file matches do
not establish equality of entire revisions.

The successor correction matches its predecessor: the report adds the
recorded earlier equipment WIP/95e per-file distinction and changes “20
source paths” to 20 revision/path selections. Its evidence checker adds the
listed receipt, source-pin and currentness bindings. The predecessor remains
separately preserved. This comparison does not certify every underlying
historical claim or any product behavior.

The initial ordinary-worktree object lookup and guessed f82 before-path
lookup failed; their captured outputs and later recovery are separate. The
guessed lookup's tool-visible assertion traceback was not retained byte for
byte. The checked 6533 parent did not match either before file; source-pin
metadata and behavior-010 were located by name and relationship, without
proven membership in the three specifically searched Git trees. This
review's initial source-identity metadata display was explicitly sliced;
full bytes remain restricted, and only the displayed metadata is credited.
Personal source-display events are attestations, not proof of attention.
The normalized 774 transport, missing pre-export originals, SOURCE004, 73
nontext/no-positive-EOF obligations and missing checkpoint 3821 remain open.
All custody is same-machine; finite privacy scanning is not a guarantee. No
product code, fixture, test, build, repair or runtime probe was run.
