#!/usr/bin/env python3
"""Offline evidence verification only; never executes product or crate code."""
import argparse,hashlib,io,json,os,stat,subprocess,sys,tarfile,tomllib,zlib
from pathlib import Path
if not __debug__:raise SystemExit('optimization prohibited')
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_bytes())
def check(root,name,expected=None):
 b=(root/name).read_bytes();assert expected is None or sha(b)==expected;m=json.loads(b);fs={};ds={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_dir():ds[n]=format(stat.S_IMODE(f.stat().st_mode),'04o')
  elif f.is_file() and n!=name:
   d=f.read_bytes();fs[n]={'sha256':sha(d),'bytes':len(d),'mode':format(stat.S_IMODE(f.stat().st_mode),'04o')}
  else:assert n==name
 assert fs==m['files'];assert 'directories' not in m or ds==m['directories']
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();key=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if key==name:return mode,oid
 raise AssertionError('missing tree member')
def historical_proof(r):
 info=j(r/'HISTORICAL-GIT-PROOF.json');objs={}
 for oid,m in info['objects'].items():
  b=(r/'historical-git-objects'/(oid+'.zlib')).read_bytes();assert sha(b)==m['stored_sha256'];raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid;head,body=raw.split(b'\0',1);kind,n=head.decode().split(' ');assert kind==m['type'] and len(body)==int(n)==m['size'] and sha(body)==m['sha256'];objs[oid]=(kind,body)
 out={}
 for p in info['proofs']:
  c=objs[p['revision']];assert c[0]=='commit';first=c[1].split(b'\n',1)[0];assert first.startswith(b'tree ');tree=first[5:].decode();trees=[];parts=p['path'].split('/')
  for i,n in enumerate(parts):
   trees.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],n)
   if i<len(parts)-1:assert int(mode,8)==int('40000',8);tree=oid
   else:assert int(mode,8) in (int('100644',8),int('100755',8));assert oid==p['blob'] and objs[oid][0]=='blob';body=objs[oid][1]
  assert [z['tree'] for z in p['chain']]==trees and p['chain'][-1]['child']==oid;assert sha(body)==p['sha256'] and len(body)==p['bytes'];out[(p['revision'],p['path'])]=body
 assert len(out)==4;return out
def exact_selection(raw,index):
 text=raw.decode();needle='"entries": [';pos=text.index(needle)+len(needle);decoder=json.JSONDecoder()
 for i in range(index+1):
  while text[pos] in ' \t\r\n,':pos+=1
  start=pos;_,pos=decoder.raw_decode(text,pos)
 return text[start:pos].encode()
def view(body,path,lo,hi):
 lines=body.decode().splitlines();assert 1<=lo<=hi<=len(lines);v=''.join(f'{i:5} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert path.read_bytes()==v

def anchorcheck(a,ref):
 raw=(a/'ANCHOR-MANIFEST.json').read_bytes();assert sha(raw)=='e3262991171c1b8279952062621c01b95803d573fbb4a20cd05cb8b2cc794a2d' and raw==ref.read_bytes();m=json.loads(raw);want={x['file'] for x in m['anchors']}|set(m['support'])|{'ANCHOR-MANIFEST.json'};assert {x.name for x in a.iterdir()}==want and stat.S_IMODE(a.stat().st_mode)==0o700
 for x in m['anchors']:
  f=a/x['file'];assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['source_mode_octal']==x['preserved_mode_octal']
 for n,x in m['support'].items():
  f=a/n;b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['mode_octal']
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);a=ap.parse_args();p=Path(__file__).resolve().parent;check(p,'MANIFEST.json');print('public manifest: PASS')
 if not a.private:assert not a.anchors;print('restricted replay not requested');return
 r=a.private.resolve();check(r,'MANIFEST-PRIVATE.json','c42adeb4d2eeb7651e35c84d032b35fe00492bf3700e0f9d9760c6adbba13e57');d=r/'delegate-private';pub=r/'delegate-public-v2';assert sha((d/'MANIFEST.json').read_bytes())=='2e5c46b420a88f8d0a91ba6a6b044b664d008d468aa6d6236c3b19e6940e3774';assert sha((pub/'MANIFEST.json').read_bytes())=='a488190391a1bfc8c3abbfc3e7608e5f4c80f6e21733a1eaa23b3e3e0893f67a'
 cmd=[sys.executable,'-B',str(pub/'VERIFY-PUBLIC.py'),'--private',str(d)]
 if a.anchors:anchorcheck(a.anchors,r/'history/ANCHOR-MANIFEST.json');cmd+=['--anchors',str(a.anchors)]
 run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});assert run.returncode==0,run.stderr.decode(errors='replace')
 src=j(r/'SOURCE-CAPTURE.json');reg=j(r/'REGISTRATION-002.json');assert reg['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009';paths={'crates/adventuresim-core/src/organization.rs':'current/organization.source'}
 for n in ('SUPPORT-004-CAPTURE.json','SUPPORT-007-CAPTURE.json'):
  v=j(d/n)
  for x in v.get('sources',v.get('product_sources',[])):paths[x['path']]=x['file']
 count=0
 for item in src['product']:
  body=(r/'sources'/f"{item['id']}.source").read_bytes();assert body==(d/paths[item['path']]).read_bytes() and sha(body)==item['sha256'];assert [[x['lo'],x['hi']] for x in item['views']]==reg['product_windows'][item['path']]
  for x in item['views']:
   f=r/x['file'];assert sha(f.read_bytes())==x['sha256'];view(body,f,x['lo'],x['hi']);count+=1
 lock=(r/'sources/Cargo.lock').read_bytes();assert lock==(d/'dependency/Cargo.lock').read_bytes() and sha(lock)==src['lock_sha256'];pkgs=tomllib.loads(lock.decode())['package']
 for name,item in src['archives'].items():
  b=(r/'archives'/f'{name}.crate').read_bytes();assert item in pkgs and sha(b)==item['checksum'] and b==(d/'dependency/crates'/f"{name}-{item['version']}.crate").read_bytes()
 for item in src['members']:
  raw=(r/'archives'/f"{item['package']}.crate").read_bytes()
  with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
   t=tar.getmember(item['member']);assert t.isfile();body=tar.extractfile(t).read()
  assert body==(r/'members'/f"{item['id']}.source").read_bytes() and sha(body)==item['sha256'];assert [[x['lo'],x['hi']] for x in item['views']]==reg['native_archive_members'][item['member']]
  for x in item['views']:
   f=r/x['file'];assert sha(f.read_bytes())==x['sha256'];view(body,f,x['lo'],x['hi']);count+=1
 assert count==30;h=historical_proof(r);o='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';n='dac7d0055716053f245139971eb67ddfd87fa462';q='baseline-059/queue.json';assert sha(h[(o,q)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(h[(n,q)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 for rev,name in ((o,'original'),(n,'reconstructed')):
  selected=exact_selection(h[(rev,q)],2497);assert selected==(r/'history'/f'q2497-{name}.json').read_bytes()==(d/f'q2497-{name}.json').read_bytes()
 q19=j(r/'history/q2497-original.json');assert q19['contract_id']=='EXTENSION-L3-ROOT-L2-EXT-0055' and q19['lens']==3 and q19['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,498]]
 rec=j(d/'history/f2ec/RECONCILIATION-059.json')['entries'][2497];assert rec['current_reconciliation']=='unassessed' and rec['historical_lens']==3;f=d/'history/receipts/QUALIFIED-INHERITED-L2-EXT-055-058-060-061-001.json';assert sha(f.read_bytes())=='bd94d9ee48850460d399a43ad162a05de0601918d3f4431e50417b63d4e408d6';e=j(f);row=e['rows'][0];assert row['supplier']=='root' and row['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and row['metadata_revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' and row['qualified_selected_same_lens_ranges']==[[1,498]] and e['fresh_personal_read_credit']==e['body_original_or_current_credit_from_metadata']==0
 l3=j(d/'history/receipts/READ-ROOT-L3-EXT-057-061.json')['rows'][0];e3=j(d/'history/receipts/READ-ROOT-L3-CURRENT-007.json')['rows'][0];assert l3['fresh_personal_ranges']==[[1,633]] and e3['fresh_personal_ranges']==[] and e3['qualified_reuse_ranges']==[[1,633]] and e3['frozen_source_adoption_pending']
 v1=r/'delegate-public-v1';v2=pub;a1=j(v1/'RECONSTRUCTION-CROSSWALK.json');a2=j(v2/'RECONSTRUCTION-CROSSWALK.json');cor=j(v2/'PUBLIC-CORRECTION.json');assert sha((v1/'RECONSTRUCTION-CROSSWALK.json').read_bytes())==cor['predecessor_crosswalk_sha256'] and sha((v2/'RECONSTRUCTION-CROSSWALK.json').read_bytes())==cor['successor_crosswalk_sha256'];assert len(a1['files'])==115 and len(a2['files'])==114 and sum(x not in a2['files'] for x in a1['files'])==1 and all(x in a1['files'] for x in a2['files']);assert (v1/'dependency/root.tree').read_bytes()==(v2/'current/trees/1eec97de340d9b7debbb30ca0c0fb2240a73b93f.tree').read_bytes();assert j(r/'delegate-public-v1-prescan/SCAN.json')['counts']=={'private-value':2} and not j(r/'delegate-v2-scan/SCAN.json')['counts']
 assert all(x['exit_code']==0 for x in j(r/'replay/RESULT.json'));assert j(d/'SOURCE-002-CAPTURE.json')['status']=='failed' and j(d/'SUPPORT-011-FAILURE.json')['actual_eof']==42
 print('delegate full evidence replay, historic queue proofs, attributed receipts and privacy correction: PASS')
 print('30 independently registered source/dependency windows and five locked archives: PASS')
 print('q2812 collection checked now: '+str(bool(a.anchors)))
 print('Source/evidence identity only; no product execution, runtime outcome, global closure or independent custody.')
if __name__=='__main__':main()
