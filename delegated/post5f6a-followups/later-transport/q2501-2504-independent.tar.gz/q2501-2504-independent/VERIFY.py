#!/usr/bin/env python3
"""Evidence-only replay; does not import or execute product source."""
import argparse,hashlib,io,json,os,stat,subprocess,sys,tarfile,zlib
from pathlib import Path
if not __debug__:raise SystemExit('optimization prohibited')
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_bytes())
def check(root,name,expected=None):
 b=(root/name).read_bytes();assert expected is None or sha(b)==expected;m=json.loads(b);fs={};ds={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_dir():ds[n]=format(stat.S_IMODE(f.stat().st_mode),'04o')
  elif f.is_file() and n!=name:
   b=f.read_bytes();fs[n]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(f.stat().st_mode),'04o')}
  else:assert n==name
 assert fs==m['files'];assert 'directories' not in m or ds==m['directories']
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();key=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if key==name:return mode,oid
 raise AssertionError('missing tree member')
def history(r):
 info=j(r/'HISTORICAL-GIT-PROOF.json');objs={}
 for oid,m in info['objects'].items():
  b=(r/'historical-git-objects'/(oid+'.zlib')).read_bytes();assert sha(b)==m['stored_sha256'];raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid;head,body=raw.split(b'\0',1);kind,n=head.decode().split(' ');assert kind==m['type'] and len(body)==int(n)==m['size'] and sha(body)==m['sha256'];objs[oid]=(kind,body)
 out={}
 for p in info['proofs']:
  c=objs[p['revision']];assert c[0]=='commit';first=c[1].split(b'\n',1)[0];assert first.startswith(b'tree ');tree=first[5:].decode();trees=[];parts=p['path'].split('/')
  for i,n in enumerate(parts):
   trees.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],n)
   if i<len(parts)-1:assert int(mode,8)==int('40000',8);tree=oid
   else:assert int(mode,8) in (int('100644',8),int('100755',8)) and oid==p['blob'] and objs[oid][0]=='blob';body=objs[oid][1]
  assert [x['tree'] for x in p['chain']]==trees and p['chain'][-1]['child']==oid and sha(body)==p['sha256'] and len(body)==p['bytes'];out[(p['revision'],p['path'])]=body
 assert len(out)==4;return out
def selections(raw,ids):
 t=raw.decode();needle='"entries": [';pos=t.index(needle)+len(needle);dec=json.JSONDecoder();out={}
 for i in range(max(ids)+1):
  while t[pos] in ' \t\r\n,':pos+=1
  start=pos;value,pos=dec.raw_decode(t,pos)
  if i in ids:out[i]=(value,t[start:pos].encode())
 return out
def view(raw,p,lo,hi):
 lines=raw.decode().splitlines();assert 1<=lo<=hi<=len(lines);s=''.join(f'{i:5} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert s==p.read_bytes()
def anchors(a,ref):
 raw=(a/'ANCHOR-MANIFEST.json').read_bytes();assert sha(raw)=='e3262991171c1b8279952062621c01b95803d573fbb4a20cd05cb8b2cc794a2d' and raw==ref.read_bytes();m=json.loads(raw);want={x['file'] for x in m['anchors']}|set(m['support'])|{'ANCHOR-MANIFEST.json'};assert {f.name for f in a.iterdir()}==want and stat.S_IMODE(a.stat().st_mode)==0o700
 for x in m['anchors']:
  f=a/x['file'];assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['source_mode_octal']==x['preserved_mode_octal']
 for n,x in m['support'].items():
  f=a/n;b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['mode_octal']
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);a=ap.parse_args();pub=Path(__file__).resolve().parent;check(pub,'MANIFEST.json');print('public manifest: PASS')
 if not a.private:assert not a.anchors;print('restricted replay not requested');return
 r=a.private.resolve();check(r,'MANIFEST-PRIVATE.json','209d415ac0e89aa8c34685a531ccbfb117d2e22ddd8b05753532ff10660916c7');dp=r/'delegate-private';p=r/'delegate-public-mode-correct';assert sha((p/'MANIFEST.json').read_bytes())=='d12a7be9479fa4a8ffff9bf45574917350b9e5fbf8e707801cc891b1ad0837a0' and sha((dp/'MANIFEST.json').read_bytes())=='bfa4c2ac4f6e357cf6790cd1869fdda9a8d2c5e68b855b8c2ab483422bf61441'
 raw=(r/'q2501-2504.tar.gz').read_bytes();assert sha(raw)=='948e3a673b321c6ac47c9739e259c2fa3d7e15a9fcf9a088a25a0903c6d63a92';seen=set()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  for x in t:
   path=Path(x.name);assert not path.is_absolute() and '..' not in path.parts and x.isfile() and x.name not in seen;seen.add(x.name);f=p/path;assert f.is_file() and not f.is_symlink() and t.extractfile(x).read()==f.read_bytes() and stat.S_IMODE(f.stat().st_mode)==x.mode
 assert seen=={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file()}
 cmd=[sys.executable,'-B',str(p/'verify.py'),'--private',str(dp),'--peer0057',str(r/'peer0057'),'--own0060',str(r/'own0060')]
 if a.anchors:anchors(a.anchors,r/'ANCHOR-MANIFEST.json');cmd+=['--anchors',str(a.anchors)]
 proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});assert proc.returncode==0,proc.stderr.decode(errors='replace')
 cap=j(r/'SOURCE-CAPTURE.json');reg=j(r/'REGISTRATION-002.json');assert reg['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009';mapping={reg['product_windows'] and 'crates/adventuresim-core/src/organization.rs':'source/95e.rs'}
 for name in ('SUPPORT-010','SUPPORT-017','SUPPORT-023'):
  for x in j(p/(name+'-CAPTURE-RESULT.json')):mapping[x['path']]=x['file']
 count=0
 for item in cap['items']:
  b=(r/'sources'/f"{item['id']}.source").read_bytes();assert b==(p/mapping[item['path']]).read_bytes() and sha(b)==item['sha256'];assert [[x['lo'],x['hi']] for x in item['views']]==reg['product_windows'][item['path']]
  for x in item['views']:
   f=r/x['file'];assert sha(f.read_bytes())==x['sha256'];view(b,f,x['lo'],x['hi']);count+=1
 assert count==20
 h=history(r);old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';new='dac7d0055716053f245139971eb67ddfd87fa462';q='baseline-059/queue.json';assert sha(h[(old,q)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(h[(new,q)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173';ids=[540,2493,2501,2503,2504,3300,3446,3450,3452,3454,3455]
 for rev,label in ((old,'original'),(new,'reconstructed')):
  got=selections(h[(rev,q)],ids)
  for i in ids:
   folder='queue' if i in [2501,2503,2504] else 'relations';assert got[i][1]==(dp/f'{folder}/q{i}-{label}.json').read_bytes()
 hist=j(r/'HISTORICAL-SELECTION.json');rec=j(dp/'committed/reconciliation.stdout')['entries']
 for i,lens in [(2501,7),(2503,9),(2504,10)]:
  q0=j(dp/f'queue/q{i}-original.json');q1=j(dp/f'queue/q{i}-reconstructed.json');s=q0['exact_source_identities_and_assessed_ranges'][0];assert q0==q1 and q0['lens']==lens and s['required_ranges']==[[1,498]] and 'git_path' not in s and s['lens2_proof_navigation_only']['git_path']=='crates/adventuresim-core/src/organization.rs';assert rec[i]['historical_lens']==lens and rec[i]['current_reconciliation']=='unassessed' and hist['queue'][str(i)]['raw_equal']
 assert rec[3450]['current_reconciliation']=='unassessed';qual=j(dp/'historical/QUALIFIED-INHERITED-L2-EXT-055-058-060-061-001.json');row=qual['rows'][0];assert row['supplier']=='root' and row['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and row['metadata_revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' and row['qualified_selected_same_lens_ranges']==[[1,498]] and qual['fresh_personal_read_credit']==qual['body_original_or_current_credit_from_metadata']==0
 assert hist['ledger']['842']['id']=='SEGOVB-L12-PROFESSION-PREVIEW-REWARD-ENUM-STRING';assert j(r/'replay/initial-RESULT.json')['exit']!=0 and (r/'replay/initial-stderr').stat().st_size>0 and j(r/'replay/corrected-RESULT.json')['exit']==0 and all(x['exit']==0 for x in j(r/'replay/FULL-RESULT.json'))
 assert not j(r/'delegate-privacy/PUBLIC-AND-DELIVERY.json')['counts'] and not j(r/'delegate-privacy/RECEIPT-SCAN.json')['counts']
 print('archive, delegate full replay, historic queues, f2ec and attribution: PASS')
 print('20 independently registered source windows under three separate lens analyses: PASS')
 print('q2812 anchor collection checked now: '+str(bool(a.anchors)))
 print('Source evidence only; no product behavior, unique count, global closure or independent custody.')
if __name__=='__main__':main()
