#!/usr/bin/env python3
import pathlib,json,hashlib,argparse,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((P/n).read_bytes());a=argparse.ArgumentParser();a.add_argument('--restricted');o=a.parse_args();m=J('MANIFEST.json');expect={r['path']:r for r in m['files']};actual={f.relative_to(P).as_posix():f for f in P.rglob('*') if f.is_file() and f!=P/'MANIFEST.json'};assert set(expect)==set(actual)
for n,f in actual.items():
 b=f.read_bytes();r=expect[n];assert H(b)==r['sha256'] and len(b)==r['bytes'] and oct(f.stat().st_mode&0o777)==r['mode']
assert {f.relative_to(P).as_posix():oct(f.stat().st_mode&0o777) for f in P.rglob('*') if f.is_dir()}==m['dirs']
for n in ['SOURCE-CAPTURE.json','SOURCE-CAPTURE-005.json']:
 for r in J(n):assert H((P/'source'/r['window']).read_bytes())==r['sha256']
h=J('HISTORY-SUMMARY.json');assert h['lens']==4 and h['a422_status']=='unassessed' and h['q541_lens']==12 and h['a422_ledger_row']==843 and h['old_supplier']=='Rig'
if o.restricted:
 r=pathlib.Path(o.restricted);assert H((r/'MANIFEST.json').read_bytes())=='b9d976bd7dd00436bc905f94aab5f966593c59d9143f1265dc64786389e91dc3';assert (P/'delegate-manifest.json').read_bytes()==(r/'delegate/public/MANIFEST.json').read_bytes()
 for f in actual.values():
  n=f.relative_to(P)
  if n.as_posix() not in {'README.md','VERIFY.py','delegate-manifest.json'}:assert f.read_bytes()==(r/n).read_bytes()
 z=subprocess.run([sys.executable,'-B',str(r/'VERIFY.py')],capture_output=True,text=True);assert z.returncode==0,z.stderr
 print('Separately held restricted capture, selected history, source objects and delegate proof passed.')
else:print('Public manifest and source-window identity checks passed; original history and object proofs require restricted custody.')
print('Source display is an attestation; supported reach, product behavior, policy and closure remain open.')
