#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,stat,sys
p=pathlib.Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('optimization prohibited')
def req(v,s):
 if not v:raise ValueError(s)
def j(n):return json.loads((p/n).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
m=j('MANIFEST.json');items={}
for f in sorted(p.rglob('*')):
 req(not f.is_symlink(),'symlink')
 if f.is_file() and f.relative_to(p).as_posix()!='MANIFEST.json':
  b=f.read_bytes();items[f.relative_to(p).as_posix()]={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(f.stat().st_mode)}
req(items==m['files'],'receipt manifest')
r=j('REPORT.json');g=j('GPU-PRIVACY.json');a=j('Q2332-PRIVACY.json');b=j('059-PRIVACY.json');v=j('SOURCE-REPLAY.json')
req(g['forbidden_digest_total']==0 and not g['exceptions'] and a['matching_occurrences']==0 and not a['exceptions'] and b['matching_occurrences']==0 and not b['exceptions'] and v['result']=='pass','recorded results')
arg=argparse.ArgumentParser();arg.add_argument('--public',type=pathlib.Path);args=arg.parse_args()
if args.public:req(sha((args.public/'MANIFEST.json').read_bytes())==r['public_manifest_sha256'],'bound public manifest')
print(json.dumps({'result':'pass','files':len(items),'public_checked':bool(args.public),'qualification':'Receipt integrity and recorded bounded scan results only.'},sort_keys=True))
