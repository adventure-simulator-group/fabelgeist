#!/usr/bin/env python3
"""Evidence-only offline verifier; does not load or execute product code."""
import argparse, hashlib, io, json, os, stat, tarfile, tomllib, zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not use Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def readj(p): return json.loads(p.read_bytes())
def inv(root, exclude):
 files={}; dirs={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink(); n=f.relative_to(root).as_posix()
  if f.is_dir(): dirs[n]=format(stat.S_IMODE(f.stat().st_mode),'04o')
  elif f.is_file() and n!=exclude:
   b=f.read_bytes(); files[n]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(f.stat().st_mode),'04o')}
  else: assert n==exclude
 return files,dirs
def check_manifest(root,name,expected=None):
 b=(root/name).read_bytes()
 if expected: assert sha(b)==expected
 m=json.loads(b); files,dirs=inv(root,name); assert files==m['files']
 if 'directories' in m: assert dirs==m['directories']
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i); nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();key=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if key==name:return mode,oid
 raise AssertionError('missing tree entry')
def compressed_proofs(root,index,objdir):
 info=readj(root/index);objects={}
 for oid,meta in info['objects'].items():
  packed=(root/objdir/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
  head,body=raw.split(b'\0',1);kind,n=head.decode().split(' ');assert kind==meta['type'] and len(body)==int(n)==meta['size'] and sha(body)==meta['sha256'];objects[oid]=(kind,body)
 results={}
 for p in info['proofs']:
  commit=objects[p['revision']];assert commit[0]=='commit';tree=commit[1].split(b'\n',1)[0].removeprefix(b'tree ').decode()
  if p['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009':assert tree=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
  chain=[]
  for j,n in enumerate(p['path'].split('/')):
   chain.append(tree);assert objects[tree][0]=='tree';mode,oid=child(objects[tree][1],n)
   if j<len(p['path'].split('/'))-1:assert int(mode,8)==int('40000',8);tree=oid
   else:assert int(mode,8) in (int('100644',8),int('100755',8));assert oid==p['blob'];assert objects[oid][0]=='blob';body=objects[oid][1]
  assert [x['tree'] for x in p['chain']]==chain and p['chain'][-1]['child']==oid
  assert sha(body)==p['sha256'] and len(body)==p['bytes'];results[(p['revision'],p['path'])]=body
 return results
def raw_proofs(root):
 base=root/'delegate-git-proof';idx=readj(base/'INDEX.json')['objects'];pr=readj(base/'PROOFS.json');assert pr==readj(root/'delegate-public/GIT-PROOFS.json')
 data={}
 for oid,m in idx.items():
  b=(base/'objects'/oid).read_bytes();assert len(b)==m['size'] and sha(b)==m['sha256'];raw=(m['type']+' '+str(len(b))+'\0').encode()+b;assert hashlib.sha1(raw).hexdigest()==oid;data[oid]=(m['type'],b)
 out={}
 for p in pr['proofs']:
  assert data[p['revision']][0]=='commit';first=data[p['revision']][1].split(b'\n',1)[0];assert first==('tree '+p['root_tree']).encode();tree=p['root_tree'];names=[]
  for step in p['steps']:
   assert tree==step['tree'] and data[tree][0]=='tree';mode,oid=child(data[tree][1],step['name']);assert int(mode,8)==int(step['mode'],8) and oid==step['oid'] and data[oid][0]==step['type'];tree=oid;names.append(step['name'])
  assert '/'.join(names)==p['path'] and tree==p['git_blob'] and data[tree][0]=='blob' and sha(data[tree][1])==p['sha256'];out[(p['revision'],p['path'])]=data[tree][1]
 assert len(out)==37;return out
def own_view(body,v,lo,hi):
 lines=body.decode().splitlines();assert 1<=lo<=hi<=len(lines);render=''.join(f'{i:5} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert v.read_bytes()==render
def check_delegate_folder(path,expected):
 assert sha((path/'MANIFEST.json').read_bytes())==expected;m=readj(path/'MANIFEST.json');actual={}
 for f in sorted(path.rglob('*')):
  assert not f.is_symlink()
  if f.is_file() and f!=path/'MANIFEST.json':
   b=f.read_bytes();actual[f.relative_to(path).as_posix()]={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(f.stat().st_mode)}
 assert actual==m['files']
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);a=ap.parse_args();pub=Path(__file__).resolve().parent;check_manifest(pub,'MANIFEST.json');print('public manifest: PASS')
 if not a.private:print('restricted replay not requested');return
 r=a.private.resolve();check_manifest(r,'MANIFEST-PRIVATE.json','9f1e288f31b39a0e41734cc2013078e79870e6d29d5e1f0b5a942fecc82a854b')
 check_delegate_folder(r/'delegate-public','cf258d0e87765f9067bad736a647b8923ea245c3682a849539f6a69d233b1a1f');check_delegate_folder(r/'delegate-receipt','f79478de25170941ac507f0c9308afc4bcd18dcb8a9ca505ade3e18b99d0c4f2')
 cur=raw_proofs(r);hist=compressed_proofs(r,'HISTORICAL-GIT-PROOF.json','historical-git-objects');fam=compressed_proofs(r,'FAMILY-GIT-PROOF.json','family-git-objects');assert len(hist)==4 and len(fam)==1
 rev='95e63628f9d70b8dd6e6fede64334696c6995009';cap=readj(r/'SOURCE-CAPTURE.json');reg=readj(r/'REGISTRATION-002.json');assert reg['product_revision']==rev and len(cap['sources'])==13;count=0
 for s in cap['sources']:
  b=(r/'sources'/f"{s['id']:02}").read_bytes();assert b==cur[(rev,s['path'])] and sha(b)==s['sha256'] and len(b)==s['size'];assert reg['windows'][s['path']]==s['ranges']
  for ran,v in zip(s['ranges'],s['views']):
   assert sha((r/v['path']).read_bytes())==v['sha256'];own_view(b,r/v['path'],*ran);count+=1
 family=readj(r/'FAMILY-CAPTURE.json');body=(r/'sources/family').read_bytes();assert body==fam[(rev,family['path'])] and sha(body)==family['sha256'];own_view(body,r/'views/family-1-52.txt',1,52);count+=1
 cargo=tomllib.loads(cur[(rev,'Cargo.toml')].decode());mod=tomllib.loads(cur[(rev,'crates/adventuresim-stdb-module/Cargo.toml')].decode());lock=tomllib.loads(cur[(rev,'Cargo.lock')].decode());assert cargo['workspace']['dependencies']['spacetimedb']=='=2.6.1' and mod['dependencies']['spacetimedb']['workspace'] is True
 pkg=[x for x in lock['package'] if x['name']=='spacetimedb' and x['version']=='2.6.1'];assert len(pkg)==1
 archive=(r/'sources/native.crate').read_bytes();assert sha(archive)==pkg[0]['checksum']=='b6eff5017248ff2e35e03564df947fdf3e963f7198be6ae1d9e894c2efb2ea15'
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
  f=t.getmember(reg['native_member']);assert f.isfile();member=t.extractfile(f).read()
 assert member==(r/'sources/native-lib.rs').read_bytes() and sha(member)==cap['native']['member_sha256'];own_view(member,r/'views/native-450-555.txt',450,555);count+=1
 original='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';reconstructed='dac7d0055716053f245139971eb67ddfd87fa462';qpath='baseline-059/queue.json';lpath='baseline-059/ledger.json';q0=readj_bytes(hist[(original,qpath)]);q1=readj_bytes(hist[(reconstructed,qpath)]);l0=readj_bytes(hist[(original,lpath)]);l1=readj_bytes(hist[(reconstructed,lpath)]);sel=readj(r/'selected/059-SELECTION.json')
 assert sha(hist[(original,qpath)])!=sha(hist[(reconstructed,qpath)]) and sha(hist[(original,lpath)])!=sha(hist[(reconstructed,lpath)])
 for n in (19,221,225):
  k=str(n);o=q0['entries'][n];rec=q1['entries'][n];ident=o['contract_id'];assert o==rec==sel[k]['original']==sel[k]['reconstructed'];old=l0['discovery_findings_and_dependencies'][ident];new=l1['discovery_findings_and_dependencies'][ident];assert isinstance(old,dict) and old==new==sel[k]['original_ledger']==sel[k]['reconstructed_ledger']
 assert q0['entries'][19]['lens']==11 and q0['entries'][221]['lens']==q0['entries'][225]['lens']==12
 assert l0['discovery_findings_and_dependencies'][q0['entries'][221]['contract_id']]['source_receipt'].endswith('READ-L12-268.json')
 assert l0['discovery_findings_and_dependencies'][q0['entries'][225]['contract_id']]['source_receipt'].endswith('READ-L12-276.json')
 cp='a4223bf23487b5872bc5efe5b272d40f859456f2';base=cur[(cp,'BASELINE-95E-20261110.json')];queue=cur[(cp,'RECONCILIATION-059.json')];assert base==(r/'selected/a422-0.json').read_bytes() and queue==(r/'selected/a422-1.json').read_bytes();bb=readj_bytes(base);qq=readj_bytes(queue);s=readj(r/'selected/a422-ROW9-QUEUE19.json');row=bb['newly_assessed_ledger']['entries'][9];assert row==s['ledger9'] and qq['entries'][19]==s['queue19'] and qq['entries'][19]['current_reconciliation']=='unassessed' and row['id']=='REVIEW-WEDDING-CAPACITY-POSTWRITE-001'
 assert cur[(cp,'ASSESSMENT-L01-WEDDING-CAPACITY-95E.json')]==(r/'delegate-public/PRIOR-CURRENT-ASSESSMENT.json').read_bytes()
 alias=readj(r/'delegate-public/historical/2.json');assert sha((r/'delegate-public/historical/2.json').read_bytes())=='7c1f8549da96256451b506c27ef48c130e9e42713d75a40b943b70f3fa8815d7';assert q0['entries'][225]['contract_id'] in alias['same_exact_capacity_contract_aliases'] and q0['entries'][221]['contract_id'] in alias['distinct_excluded']
 pc=readj(r/'delegate-receipt/PROCESS-CORRECTION.json');assert pc['predecessor_receipt_manifest_sha256']=='b26c4d41baf0d9be9e952ad9aaa968274e7dd70f2b99c9b8a2955f1a684e10cc';cor=readj(r/'delegate-receipt-correction/RESULT.json');assert cor['exit_codes']=={'v1-clean':0,'v2-clean':0,'v1-extra':0,'v2-extra':1}
 failed=readj(r/'selected/initial-failed-RESULT.json');assert failed['exit_code']==1 and failed['candidate_manifest_sha256']=='667caeae4c650afa40e482e76d31d2e4cd3bdebdce1ca5cbcaf71f358b67f9c0';assert (r/'selected/initial-failed-stderr').stat().st_size>0
 for v in readj(r/'replay/RESULT.json'):assert v['exit_code']==0 and not (r/'replay'/v['stderr_file']).read_bytes()
 correction=readj(r/'selected/HISTORY-CORRECTION-v2.json');assert sha((r/'selected/HISTORY-CORRECTION.json').read_bytes())==correction['predecessor_sha256'] and all(v['ledger_present'] and v['ledger_equal'] for v in correction['confirmed'].values())
 print('37 inherited and 5 fresh Git path proofs, historic selections, a422 row9 and delegate correction: PASS')
 print(str(count)+' independently registered source, manifest and SDK windows: PASS')
 print('Evidence identity and selected source displays only; no product execution, runtime outcome, independent custody, or global closure.')
def readj_bytes(b):return json.loads(b)
if __name__=='__main__':main()
