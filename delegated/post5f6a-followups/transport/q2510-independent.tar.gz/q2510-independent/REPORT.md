# Independent check of q2510 invariant-operations packet

The sealed q2510 packet's central axis-code claim is supported within its
stated conditions. The packet was authored by a different reviewer; this
check personally read only the source windows listed in SOURCE-CAPTURE.json
and SOURCE-CAPTURE-006.json. It does not adopt a queue entry, assign a unique
defect count, establish a supported gameplay failure, or validate product
behavior.

At pinned 95e, `crates/adventuresim-core/src/social.rs:276–282` defines
three or four legal axis-local codes, and :203–253 maps invalid codes to no
label. `diagnosed_axis` at :999–1040 accepts an `i8` truth and checks its
membership only with `debug_assert!`. With assertions disabled, the
representable call using Nerve, truth -1, and zero finite insight, deception
and roll takes the correct branch and returns -1, despite the documented legal
result. This is a direct-API counterexample, not evidence that the displayed
gameplay producer supplies an illegal truth. With assertions enabled that
invalid input instead encounters the assertion. For legal truth and finite
inputs the displayed legal sets leave at least two alternatives; chance is
clamped away from both endpoints and the final alternative index is capped.
No floating-point execution was performed.

The selected `adventuresim-stdb-module/src/social.rs:2327–2411` producer
exhaustively maps each shown typed variant to one of its axis's legal codes;
:2857–2875 uses that producer for the shown diagnosis call. At :2481–2513,
`put_belief` returns before a write for an illegal perceived code, and the
backend view :1352–1364 filters illegal axis/code pairs. The selected web
consumer at `crates/strategic-web/src/templates/settlement/social.rs:118–124`
uses an uncertain fallback for an unlabelled code. Other callers, database
state, build configuration and supported reach remain unproved.

A nonfinite confidence has a more specific conditional boundary than code
legality: the existing-row branch in `put_belief` invokes the replacement
helper, which requires the new confidence to be finite
(`adventuresim-core/src/social.rs:369–371`; module :2493–2498). For a legal
code with no existing row, the shown first-insert branch :2500–2512 has no
local confidence-finiteness check. The selected caller obtains mental checks
and a random draw at module :2664–2679. Whether a nonfinite value can reach
this function, pass native storage, or have a product effect is not established;
its intended admission policy also remains open. This observation does not
contradict the delegate's explicit nonfinite/reach qualification.

Original 059 q541 and f2ec ledger row 843 instead identify the distinct typed
axis → slug → string-matched hint operation. The personally read current web
window :157–187 supports that operation distinction. Original and
reconstructed selected q541 records compare equal as parsed objects; their
whole historical streams differ. Their original author and earlier Lens 12
reading are retained; no same-finding alias or unique-count conclusion follows.
The delegate's bounded search is not a repository-wide alias proof.

The delegate packet's q2510 historic record identifies 6533 social.rs:1–329
of 1,909, with no prior credited Lens 4 ranges, and f2ec records it unassessed.
The complete social.rs bytes match for 6533, e275 and 95e; that is per-file
identity, not historical tree equality. The delegate separately read its
registered historical/current ranges; this review's narrower fresh windows
are separate. The old qualified Lens 2 selection and its supplier's reported
read do not confer Lens 4 credit. The supplier file was a same-machine
hash-matching recovery after its named Git pathname failed, not a proved
recovered Git-tree location. The normalized 774 transport, missing pre-export
originals, SOURCE004, 73 nontext/no-positive-EOF obligations and missing
checkpoint 3821 remain qualified and open.

The delegate's initial related-record display was truncated and its original
emitted tool transcript was not separately saved; four object searches and
the supplier Git lookup failed before the registered successful alternatives.
This review initially emitted one bounded navigation search without saving its
exact tool output; a newly registered repeat was captured. A history-detail
display was explicitly sliced; only the shown bounded fields are credited.
The exact selected records and complete delegate packets are preserved in
restricted custody. Source display is an attestation, not independently
verified human attention. The evidence-only checker reproduced the delegate
proof from copied same-machine custody. Finite privacy scans cannot guarantee
the absence of all sensitive material. No product code, fixture, build, test,
repair or runtime probe was run.
