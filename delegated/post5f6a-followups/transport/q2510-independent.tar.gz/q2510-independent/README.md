# Independent q2510 packet check

This is a bounded independently attributed review of a Lens 4 packet. It
contains selected source windows, the delegate public-manifest identity and a
path-safe report projection. Exact originals, the delegate packets and source
objects are separately held under restricted manifest SHA-256
f7a580dc7a456b86266052d788858867945de851a88e27e1b729a6a76a146a63.

Run VERIFY.py for public identity checks; add --restricted with the separately
held private directory to replay original reconstruction, object proofs and
source-window binding. Public evidence alone cannot recreate private originals.
The scan is finite, source display is an attestation, and no product execution,
validation, repair, queue closure or independent custody is claimed.
