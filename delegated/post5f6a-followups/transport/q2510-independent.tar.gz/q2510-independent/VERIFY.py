#!/usr/bin/env python3
import pathlib,json,hashlib,subprocess,sys,argparse
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((P/n).read_bytes())
a=argparse.ArgumentParser();a.add_argument('--restricted');o=a.parse_args();m=J('MANIFEST.json');expect={x['path']:x for x in m['files']};actual={x.relative_to(P).as_posix():x for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};assert set(expect)==set(actual)
for n,f in actual.items():
 b=f.read_bytes();r=expect[n];assert len(b)==r['bytes'] and H(b)==r['sha256'] and oct(f.stat().st_mode&0o777)==r['mode']
assert {x.relative_to(P).as_posix():oct(x.stat().st_mode&0o777) for x in P.rglob('*') if x.is_dir()}==m['dirs']
for r in J('SOURCE-CAPTURE.json'):assert H((P/'source'/r['window']).read_bytes())==r['sha256']
for r in J('SOURCE-CAPTURE-006.json'):assert H((P/'source'/r['name']).read_bytes())==r['sha256']
h=J('HISTORY-SUMMARY.json');assert h['historical_lens']==4 and h['f2ec_status']=='unassessed' and h['q541_lens']==12 and h['f2ec_ledger_index']==843
c=J('RECONSTRUCTION.json');assert H((P/'REPORT.md').read_bytes())==c['public_sha256']
if o.restricted:
 r=pathlib.Path(o.restricted);assert H((r/'MANIFEST.json').read_bytes())=='f7a580dc7a456b86266052d788858867945de851a88e27e1b729a6a76a146a63'
 original=(r/'REPORT.md').read_bytes();assert H(original)==c['original_sha256'];e=c['edit'];offset=e['byte_offset'];reconstructed=original[:offset]+e['replacement'].encode()+original[offset+e['removed_length']:];assert reconstructed==(P/'REPORT.md').read_bytes()
 assert (P/'delegate-manifest.json').read_bytes()==(r/'delegate/public/MANIFEST.json').read_bytes()
 for f in actual.values():
  n=f.relative_to(P)
  if n.as_posix() not in {'README.md','VERIFY.py','RECONSTRUCTION.json','REPORT.md','delegate-manifest.json'}:assert f.read_bytes()==(r/n).read_bytes()
 z=subprocess.run([sys.executable,'-B',str(r/'VERIFY.py')],capture_output=True,text=True);assert z.returncode==0,z.stderr
 print('Separately held restricted capture, exact original reconstruction, source objects, history and delegate proof passed.')
else:print('Public manifest and selected source-window identities passed. Exact original, object and history checks require restricted custody.')
print('No product execution, semantic closure, supported reach, or independent trusted custody is certified.')
