#!/usr/bin/env python3
"""Evidence-only scan-note identity check; no product execution."""
import argparse,hashlib,json,stat
from pathlib import Path
if not __debug__:raise SystemExit('optimization prohibited')
def sha(b):return hashlib.sha256(b).hexdigest()
def check(root,name,expect=None):
 b=(root/name).read_bytes();assert expect is None or sha(b)==expect;m=json.loads(b);files={};dirs={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_dir():dirs[n]=format(stat.S_IMODE(f.stat().st_mode),'04o')
  elif f.is_file() and n!=name:
   data=f.read_bytes();files[n]={'sha256':sha(data),'bytes':len(data),'mode':format(stat.S_IMODE(f.stat().st_mode),'04o')}
  else:assert n==name
 assert files==m['files']
 if 'directories' in m:assert dirs==m['directories']
p=Path(__file__).resolve().parent;check(p,'MANIFEST.json');a=argparse.ArgumentParser();a.add_argument('--review-public',type=Path);a.add_argument('--scan-private',type=Path);v=a.parse_args()
if v.review_public:check(v.review_public,'MANIFEST.json','01bf67398cc19a8a7fb42e7dc8c13543cb5c27933001e3bb0a4e875eaf54dbb4')
if v.scan_private:
 s=v.scan_private;check(s,'MANIFEST.json','73b35ffee6bfdb582de2b56c6522dfdb5c37de26b0c2c0103ac18adee4bdd327');r=json.loads((s/'RESULT.json').read_bytes());assert all(x['exit_code']==0 for x in r['commands'])
 gpu=json.loads((s/'0-stdout').read_bytes());assert gpu['forbidden_digest_total']==0 and not gpu['other_candidate_counts'] and not gpu['exceptions']
 for n in ('q2332.json','059.json'):
  d=json.loads((s/n).read_bytes());assert d['matching_occurrences']==0 and not d['exceptions']
print('scan-note integrity: PASS; evidence-only, same-machine, no product validation')
