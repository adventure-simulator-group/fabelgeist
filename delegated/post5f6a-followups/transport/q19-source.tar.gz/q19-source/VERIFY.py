#!/usr/bin/env python3
"""Evidence-only verification; no product code or network. Raw Git proof objects
are restricted; --restricted enables standalone provenance, --repo adds a
separate local Git object-store check. This is not product validation."""
import argparse,hashlib,json,os,pathlib,stat,subprocess,sys,tarfile
P=pathlib.Path(__file__).resolve().parent
if sys.flags.optimize: raise SystemExit('Python optimization disables integrity checks')
def require(x,msg):
 if not x: raise ValueError(msg)
def j(p): return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def gitid(typ,b):return hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()
def inv(root,exclude):
 result={}
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root).as_posix()
  require(not p.is_symlink(),'symlink '+rel)
  if p.is_file() and rel not in exclude:
   b=p.read_bytes();result[rel]={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(p.stat().st_mode)}
  elif not p.is_file():require(p.is_dir(),'non-file '+rel)
 return result
m=j(P/'MANIFEST.json'); require(inv(P,{'MANIFEST.json'})==m['files'],'public manifest')
s=j(P/'SOURCE-OBJECTS.json'); members=j(P/'NATIVE-MEMBER-CAPTURE.json');allrows=s['objects']+s['cargo_metadata']
for r in allrows:
 b=(P/r['object']).read_bytes();require(sha(b)==r['sha256'] and len(b)==r['bytes'] and gitid('blob',b)==r['git_blob'] and len(b.decode().splitlines())==r['eof'],'source object')
archive=(P/'native/spacetimedb-2.6.1.crate').read_bytes();require(sha(archive)=='b6eff5017248ff2e35e03564df947fdf3e963f7198be6ae1d9e894c2efb2ea15','crate checksum')
with tarfile.open(P/'native/spacetimedb-2.6.1.crate','r:gz') as t:
 for r in members:
  f=t.extractfile(r['member']);require(f is not None,'native member');b=f.read(); require(b==(P/'native'/str(r['id'])).read_bytes() and sha(b)==r['sha256'] and len(b)==r['bytes'] and len(b.decode().splitlines())==r['eof'],'native member bytes')
read=j(P/'READ-RECEIPT.json');require(len(read['views'])==41,'view count')
for v in read['views']:
 reg=j(P/v['registration']);matches=[x for x in reg['views'] if all(v.get(k)==value for k,value in x.items())];require(len(matches)==1,'prospective view registration')
 if v['group']=='source': r=next(x for x in s['objects'] if x['id']==v['id']);b=(P/r['object']).read_bytes()
 elif v['group']=='cargo':r=next(x for x in s['cargo_metadata'] if x['id']==v['id']);b=(P/r['object']).read_bytes()
 elif v['group']=='native':r=next(x for x in members if x['id']==v['id']);b=(P/'native'/str(r['id'])).read_bytes()
 else: raise ValueError('view group')
 require(sha(b)==v['sha256'] and len(b.decode().splitlines())==v['eof'],'view source')
 lo,hi=v['lines'];lines=b.decode().splitlines();require(1<=lo<=hi<=len(lines),'view bounds')
 expected=''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode(); actual=(P/v['view_file']).read_bytes();require(actual==expected and sha(actual)==v['view_sha256'],'exact display')
h=j(P/'HISTORY-REDISPLAY-REGISTRATION.json');b=(P/'Q19-ORIGINAL-SELECTED.json').read_bytes();require(sha(b)==h['source_sha256'],'history source');lines=b.decode().splitlines();require(len(lines)==h['eof']==500,'history EOF')
for lo,hi in h['ranges']:
 actual=(P/f'history-views/{lo}-{hi}.txt').read_bytes();require(actual==''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode(),'history redisplay')
for r in j(P/'RECEIPT-CAPTURE.json'):
 b=(P/'historical'/f"{r['id']}.json").read_bytes();require(sha(b)==r['sha256'] and len(b)==r['bytes'],'historical receipt')
for r in j(P/'RECEIPT2-CAPTURE.json'):
 b=(P/'historical'/f"additional-{r['id']}").read_bytes();require(sha(b)==r['sha256']==r['expected_sha256'] and len(b)==r['bytes'],'additional receipt')
require(j(P/'Q19-ORIGINAL-SELECTED.json')['contract_id']=='CONT-WEDDING-CAPACITY-POSTWRITE-ERROR','historical record')
proofs=j(P/'GIT-PROOFS.json')['proofs']; require(len(proofs)==37,'proof count')
ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repo',type=pathlib.Path);args=ap.parse_args()
def tree_entries(b):
 out={};i=0
 while i<len(b):
  space=b.index(b' ',i);zero=b.index(b'\0',space);mode=b[i:space].decode();name=b[space+1:zero].decode();oid=b[zero+1:zero+21].hex();require(len(oid)==40 and name not in out,'raw tree parse');out[name]=(mode,oid);i=zero+21
 return out
if args.restricted:
 q=args.restricted; idx=j(q/'git-proof/INDEX.json')['objects']; expected=j(q/'git-proof/PROOFS.json');require(expected==j(P/'GIT-PROOFS.json'),'proof copy')
 for oid,r in idx.items():
  b=(q/'git-proof/objects'/oid).read_bytes();require(sha(b)==r['sha256'] and len(b)==r['size'] and gitid(r['type'],b)==oid,'restricted Git object')
 for pr in proofs:
  commit=(q/'git-proof/objects'/pr['revision']).read_bytes();require(commit.split(b'\n',1)[0]==('tree '+pr['root_tree']).encode(),'commit root')
  tree=pr['root_tree']; names=[]
  for st in pr['steps']:
   require(st['tree']==tree,'tree chain');entries=tree_entries((q/'git-proof/objects'/tree).read_bytes());require(int(entries[st['name']][0],8)==int(st['mode'],8) and entries[st['name']][1]==st['oid'],'tree member');require(idx[st['oid']]['type']==st['type'],'tree child type');names.append(st['name']);tree=st['oid']
  require('/'.join(names)==pr['path'] and tree==pr['git_blob'] and sha((q/'git-proof/objects'/tree).read_bytes())==pr['sha256'],'leaf chain')
 hist=j(P/'HISTORY-SUMMARY.json')
 for name,key in [('QUEUE-ORIGINAL.json','original_queue_sha256'),('QUEUE-RECONSTRUCTED.json','reconstructed_queue_sha256'),('LEDGER-ORIGINAL.json','original_ledger_sha256'),('LEDGER-RECONSTRUCTED.json','reconstructed_ledger_sha256')]:require(sha((q/name).read_bytes())==hist[key],'whole historical stream')
 old=j(q/'QUEUE-ORIGINAL.json')['entries'][19];new=j(q/'QUEUE-RECONSTRUCTED.json')['entries'][19];require(old==new==j(P/'Q19-ORIGINAL-SELECTED.json'),'queue selected equality')
 oldl=j(q/'LEDGER-ORIGINAL.json')['discovery_findings_and_dependencies'][old['contract_id']];newl=j(q/'LEDGER-RECONSTRUCTED.json')['discovery_findings_and_dependencies'][old['contract_id']];require(oldl==newl==j(P/'Q19-LEDGER-SELECTED.json'),'ledger selected equality')
 require(j(q/'PARENT-1.json')['entries'][19]['current_reconciliation']=='unassessed','committed current queue status')
if args.repo:
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 for pr in proofs:
  r=subprocess.run(['git','-C',str(args.repo),'rev-parse',pr['revision']+':'+pr['path']],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env).stdout.decode().strip();require(r==pr['git_blob'],'local Git proof')
print(json.dumps({'result':'pass','public_files':len(m['files']),'views':len(read['views']),'git_proofs':len(proofs),'restricted_offline_proofs':bool(args.restricted),'local_git_crosscheck':bool(args.repo),'qualification':'Evidence identities and selected source displays only; no product execution or semantic closure.'},sort_keys=True))
