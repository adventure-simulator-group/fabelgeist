# q19: wedding capacity and error granularity

The independently registered Lens 11 review corroborates the existing current
ledger row 9. Wedding settlement can write a paid dowry and household prefix
before a later occupancy admission checks finite property capacity. The global
dispatcher catches the returned string error and attempts to cancel it as
`ResidenceUnavailable`. This is the same conditional source family already
recorded, not a new defect count.

If a valid processable wedding reaches that capacity failure, cancellation and
all later scheduler work succeed, and the pinned native transaction contract
applies, the earlier write prefix can be retained. If escrow was paid and
deleted first, the shown cancellation refund branch has no escrow row to
refund. No supported populated state, actual database commit or user outcome
was observed. The individual personal-time caller propagates the helper error;
its higher callers remain unassessed.

The 95e module declares the workspace `spacetimedb =2.6.1` dependency; the
locally recovered crate matches its lockfile checksum. Its source documentation
states that reducer calls share their caller’s transaction and failed reducers
roll back. This is documented native behavior, not a runtime probe.

Existing event and state types distinguish meaningful wedding, birth, clock,
residence and money roles. The shared `Result<(), String>` currently gives the
global catch no typed distinction between expected rejection and unexpected
commit failure. A prepared plan and distinct error outcomes are repair
directions for later reconciliation, not implementation.

The original 059 record, original Lens 11 receipt/adoption, separate historical
Lens 12/13 qualifications and the prior current Lens 1 assessment retain their
source revisions and reviewers. Original and reconstructed whole streams
differ; selected q19 values agree. Two truncated historical metadata displays
were recorded, with the full selected q19 object later redisplayed in bounded
chunks. No prior evidence is promoted into checkpoint 3821.
