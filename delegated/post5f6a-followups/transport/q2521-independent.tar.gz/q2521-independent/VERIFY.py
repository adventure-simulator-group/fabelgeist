#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' or (v['mode']=='0664' and k.startswith(('delegate-public/','delegate-receipts/'))) for k,v in m['files'].items())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');previous=public/'predecessor';assert sha((previous/'MANIFEST.json').read_bytes())=='b5a5c21ab8be4946d06081c7d6ac07b7bdf18d4e64ae15f31cef09141c62e2c9';verify_manifest(previous,'MANIFEST.json');print('public and predecessor manifests: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='23c516991440d188f078a57768a9ad8e462cebcf0546345a4fb5619987963543';verify_manifest(root,'MANIFEST-PRIVATE.json')
 src=proof(root,'SOURCE-GIT-PROOF.json','source-git-objects',True);hist=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert len(src)==15 and len(hist)==3
 rev='95e63628f9d70b8dd6e6fede64334696c6995009';path='crates/adventuresim-stdb-module/src/strategic/dialogue_schema.rs';old='6533e444fa37552927070cc8d8190907fd3b413e';e275='e2755a732c84e67296b5e3441a4259a84f461b2f';assert src[(rev,path)]==src[(old,path)]==src[(e275,path)] and sha(src[(rev,path)])=='aad9a8d85274246ec4a34ceaf33f869f44d80b116f75b304767d290aa15fe576'
 objects=json.loads((root/'SOURCE-GIT-PROOF.json').read_bytes())['objects'];kind,commit=decode_object(root/'source-git-objects',rev,objects[rev]);assert kind=='commit' and commit.split(b'\n',1)[0]==b'tree 1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
 r1='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';r2='dac7d0055716053f245139971eb67ddfd87fa462';hp='baseline-059/queue.json';assert sha(hist[(r1,hp)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(hist[(r2,hp)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 a1=exact_selections(hist[(r1,hp)],[232,2521]);a2=exact_selections(hist[(r2,hp)],[232,2521]);sel=json.loads((root/'HISTORICAL-RELATED-015.json').read_bytes());assert all(a1[i][0]==a2[i][0]==sel['original'][str(i)]==sel['reconstructed'][str(i)] for i in (232,2521));q=a1[2521][0];assert q['contract_id']=='EXTENSION-L3-ROOT-L2-EXT-0057' and q['lens']==3 and q['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,703]]
 cp='a4223bf23487b5872bc5efe5b272d40f859456f2';base=json.loads(src[(cp,'BASELINE-95E-20261110.json')]);rq=json.loads(src[(cp,'RECONCILIATION-059.json')]);assert rq['entries'][2521]['current_reconciliation']=='unassessed';rows=base['newly_assessed_ledger']['entries'];assert rows[131]==sel['a422_ledger']['131'] and rows[131]['id']=='SEGOVB-L12-COND-SESSION-NPC-REUSE-BINDING' and rows[773]==sel['a422_ledger']['773']
 dp=root/'delegate-public';dr=root/'delegate-receipts';assert sha((dp/'MANIFEST.json').read_bytes())=='a98701418526c2e291afdb74fb86be585db889f491d431069e699a5ccc5ac164';assert sha((dr/'MANIFEST.json').read_bytes())=='bf292370b0e6f52c7e9bbcb9c0103732cc336f83c116bb4c1d77063e3ce43d85'
 for folder in (dp,dr):
  m=json.loads((folder/'MANIFEST.json').read_bytes());assert {x.relative_to(folder).as_posix() for x in folder.rglob('*') if x.is_file() and x!=folder/'MANIFEST.json'}==set(m['files'])
  for n,v in m['files'].items():
   f=folder/n;b=f.read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256'] and (f.stat().st_mode&0o777)==v['mode']
 assert json.loads((dp/'selected-queue-original.json').read_bytes())==q;rel=json.loads((dp/'RELATED-RECORDS.json').read_bytes());assert all(a1[232][0].get(k)==v for k,v in rel['queue']['232'].items()) and rel['ledger']['131']==rows[131] and rel['ledger']['773']==rows[773]
 receipt=json.loads((dp/'READ-RECEIPT.json').read_bytes());assert receipt['reviewer']=='/root/mhr_character' and len(receipt['views'])==34 and receipt['assigned_unread_complement']==[[704,781]]
 pm=root/'delegate-restricted-subset';assert sha((pm/'PRIVATE-MANIFEST.json').read_bytes())=='fe813ad8264a86c259fa02f703be5c8eeba798f39ab05cecbe0abd8fbe721d6f';m=json.loads((pm/'PRIVATE-MANIFEST.json').read_bytes())
 for n in ['CUSTODY-INVENTORY.json','UNPUBLISHED-CITATION-CORRECTION.json','SCAN-LOCATION.json','SCAN-RETRY-LOCATION.json','prior-unpublished-candidate/REPORT.json','public-transport/REPORT.json']:
  b=(pm/n).read_bytes();assert sha(b)==m['files'][n]['sha256'] and len(b)==m['files'][n]['bytes']
 correction=json.loads((pm/'UNPUBLISHED-CITATION-CORRECTION.json').read_bytes());assert sha((pm/'prior-unpublished-candidate/REPORT.json').read_bytes())==correction['initial_report_sha256'] and sha((pm/'public-transport/REPORT.json').read_bytes())==correction['corrected_report_sha256'];assert json.loads((pm/'SCAN-RETRY-LOCATION.json').read_bytes())['retry_exit']==0
 n=0
 for f in ['SOURCE-IDENTITIES-002.json','SUPPORT-IDENTITIES-004.json','ADDITIONAL-IDENTITIES-007.json','NPC-SUPPORT-IDENTITIES-009.json']:
  for item in json.loads((root/f).read_bytes()):
   assert item['revision']==rev and src[(rev,item['path'])]==(root/item['capture']).read_bytes()
   for w in item['views']:window(root,item['capture'],w['capture'],w['lo'],w['hi']);n+=1
 for f in ['ROUTER-IDENTITY-013.json','PATTERNS-IDENTITY-014.json','RESIDENT-TYPE-IDENTITY-017.json']:
  item=json.loads((root/f).read_bytes());assert src[(rev,item['path'])]==(root/item['capture']).read_bytes()
  for w in item['views']:window(root,item['capture'],w['capture'],w['lo'],w['hi']);n+=1
 for raw,out,lo,hi in [('source-0.raw','npc-producer-0750-0835.txt',750,835),('source-0.raw','npc-route-header-0710-0750.txt',710,750)]:window(root,raw,out,lo,hi);n+=1
 assert n==22;router=json.loads((root/'ROUTER-IDENTITY-013.json').read_bytes());assert router['lines']==34 and router['views'][0]['requested_hi']==60 and router['views'][0]['hi']==34
 import html
 raw=(root/'rust-u64.html').read_text()
 for label,tag in [('from-str-radix','id="method.from_str_radix"'),('display','id="impl-Display-for-u64"'),('fromstr','id="impl-FromStr-for-u64"')]:
  i=raw.index(tag);j=raw.find('</details>',i);assert j>i;s=' '.join(html.unescape(re.sub(r'<[^>]+>',' ',raw[i:j])).split())+'\n';assert s==(root/f'rust-u64-{label}.txt').read_text()
 s=(root/'rust-fmt-num.html').read_text();pat=re.compile(r'<a href=#(\d+) id=\1 data-nosnippet>\1</a>');matches=list(pat.finditer(s));lines={int(a.group(1)):html.unescape(re.sub(r'<[^>]*>','',s[a.end():(matches[i+1].start() if i+1<len(matches) else len(s))])).rstrip() for i,a in enumerate(matches)};render=''.join(''.join(f'{i:4} {lines[i]}\n' for i in range(lo,hi+1)) for lo,hi in [(133,153),(180,248),(595,600)]);assert render==(root/'rust-fmt-source-selected.txt').read_text()
 assert all(x['status']==0 for x in json.loads((root/'DELEGATE-REPLAY.json').read_bytes()));assert all(x['exit']==0 for x in json.loads((root/'COPIED-DELEGATE-REPLAY.json').read_bytes()))
 print('q2521 historical/current Git bindings, q232/a422 ledger, delegate public and selected custody evidence: PASS')
 print('22 registered source windows and installed Rust-document extracts: PASS')
 print('Scope: evidence identities only. Full delegate restricted replay needs its separate packet and Git store; no product execution, reachability, closure, independent custody or checkpoint3821 claim.')
if __name__=='__main__':main()
