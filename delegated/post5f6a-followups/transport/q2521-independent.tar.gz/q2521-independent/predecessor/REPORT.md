# q2521: independent admission-trace review

The peer review supports the packet's conditional NPC-spelling mismatch. It
adds a reach qualification: the selected ordinary NPC-list and browser path
supplies canonical decimal IDs when its server response and client are
unmodified. An alternate or modified request path and the required coexisting
state remain unproved. This is a bounded review, not a queue or lens closure,
product validation, or a new unique finding.

The reviewed delegate public manifest has SHA-256
`a98701418526c2e291afdb74fb86be585db889f491d431069e699a5ccc5ac164`.
The delegate is `/root/mhr_character`; this reviewer independently registered
and displayed only the selected current windows below, not the delegate's full
assigned range. The source is pinned to
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`.

## Spelling and reach

`strategic-web/src/routes/dialogue.rs:1505–1509, 1524–1545, 1560–1616`
receives the NPC ID as a string, parses it as `u64` for a resident lookup,
and forwards the original string to `start_dialogue`. The reducer parses it
again (`dialogue_sessions.rs:27–32`); for a new session it writes each bound
NPC participant's numeric ID with `to_string()` (`:175–205`). After a matching
rumor delivery and successful referral authority, it searches participant
`actor_id` using the original input string (`:277–302`).

The installed Rust integer parsing documentation admits decimal digits with
leading zeroes. Thus, under the stated path and prerequisites, `0007` parses
as the same numeric ID as `7`, but the participant written by this path has
`7`, so the raw-string comparison cannot find that NPC by `0007`. The
selected generated resident row declares its ID as `u64`; the installed
formatting source supports the decimal rendering. These are source and language
documentation observations, not an executed request or a claim about the
exact deployed toolchain.

The existing-session branch returns at `dialogue_sessions.rs:118–127`, before
new participant creation and the later delivery comparison. The conditional
case also needs successful gateway, catalog, party, place, resident, authority,
co-presence and session checks; a matching delivery; and exactly one of its
local-problem receipt or public-threat disclosure. The authority helper rejects
missing and conflicting sources (`dialogue_provenance.rs:10–43`,
`threat_escalation.rs:47–64`). Selected `local_problem.rs:1470–1577,
1679–1788` can create a delivery after further guards, but the review does
not establish a concrete state satisfying all guards together. The reducer
writes session and participant rows before the comparison; persistence or
rollback on a later error is not established.

The selected NPC-list handler formats `npc.character_id.to_string()` as
`NpcView.id` (`routes/dialogue.rs:743–828`). Its route is wired by
`routes/dialogue/router.rs:10–22` and the location path by
`location_urls/patterns.rs:21–22`. `strategic-scene.js:11–23` loads the JSON;
`dialogue-client.js:717–724, 734–740, 770–804` carries `npc.id` into the
start request. This source path does not add leading zeroes to the server's
canonical ID. The fetch hook, modified data or client, other gateways and
hand-built requests were not exhaustively assessed. Whether noncanonical
spellings should be accepted or rejected is a policy question.

## History and evidence limits

Original 059 q232 and a422 ledger row 131 address an existing-session request
for a different NPC while retaining the old participant binding. Their first
operation is the earlier reuse branch; it is related to, but not automatically
an alias of, the later fresh-session spelling comparison. Original 059 q2521
requires `dialogue_schema.rs:1–703` at 6533 and was unassessed at a422. Its
original and reconstructed selected objects compare as parsed, while their
full queue streams differ. The 6533, e275 and 95e bytes match for that single
schema file, not for their whole trees. Historical Camera Lens 2 supplier
coverage and Root reinspection retain their own attribution and confer no
Lens 3 credit.

The delegate's unpublished first report had a corrected citation; both exact
reports and the additive correction remain available in restricted evidence.
Its first GPU privacy scan stopped at a scratch-directory mode assertion
before scanning and was followed by a separately recorded retry; the public
receipt verifies recorded outcomes and is not a fresh corpus scan. The
delegate and this reviewer each read the nested core and strategic-web agent
guides after earlier support displays; those guides govern changes and no
changes were made. The guide hash comparison to the workspace was tool-visible,
not independently captured as a separate transcript.

Two initial source-window displays and one broad Rust-document locator were
truncated by the tool. The affected source windows were saved before display
and redisplayed separately without reported truncation; the initial emitted
transcripts were not separately captured byte-for-byte. A router request through
line 60 reached EOF 34, with no credit for nonexistent lines. The missing
rust-src locator and later installed documentation are separately qualified.

The recovered 774 catalog is normalized and its pre-export originals remain
missing; SOURCE004, 73 nontext/no-positive-EOF, and the missing checkpoint 3821
remain open. No earlier evidence is promoted into that checkpoint. This packet
contains exact delegate public and receipt copies plus selected private
records, but replay of the delegate's complete restricted verifier needs its
separately preserved 390-file packet and pinned Git store. These are same-machine
copies, not independent custody or public-only recovery. The bounded public
privacy scan is not proof that all sensitive values are absent.
