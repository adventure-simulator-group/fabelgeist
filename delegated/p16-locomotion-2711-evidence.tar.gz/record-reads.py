from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda x:hashlib.sha256(x).hexdigest();groups=['registration.json','support-registration.json'];actual={'p16-role-2711':[[88,92]],'current-locomotion-support':[[80,100]],'rate':[[1,45],[46,86]],'runtime':[[1,50],[51,98]],'config':[[1,65]],'frame-clock':[[1,58]],'scenario':[[780,825],[826,875]],'html':[[70,86]]}
def complement(eof,ranges):
 s={i for a,z in ranges for i in range(a,z+1)};out=[];begin=None
 for i in range(1,eof+2):
  if i<=eof and i not in s and begin is None:begin=i
  if (i>eof or i in s) and begin is not None:out.append([begin,i-1]);begin=None
 return out
rows=[]
for name in groups:
 r=json.loads((b/name).read_bytes())
 for e in r['entries']:
  ranges=actual[e['id']];rows.append({'id':e['id'],'registration':name,'registration_sha256':sha((b/name).read_bytes()),'archive':e['archive'],'revision':e.get('revision','physical-p16 dirty snapshot transported at f82adcabd9d89c4fa2dd7f99253a45297a0681ee'),'sha256':e['sha256'],'actual_personal_display_chunks':ranges,'unread_complement':complement(e['eof'],ranges),'actual_read_qualification':'Prior grep match lines are navigation only. Current support is distinct from original material role; tests, where text appeared, were not run.'})
out={'schema':'726-personal-read-receipt-v1','author':'/root/rig_identity','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows,'navigation':'Before support registration, git grep printed individual matches (one multi-file output truncated); treated only as locator context, not full-function or role coverage.','source_only':'No product, animation, test, fixture, build or runtime action.'};(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
