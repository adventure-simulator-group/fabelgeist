# Bounded locomotion evidence: original role 2711

This packet records a source-only review by `/root/rig_identity` of the
physical-p16 locomotion sample-rate function at lines 88–92 and separately
registered support at current project revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. `REPORT.json` gives the findings,
conditions, 13 bounded perspectives, limitations, and reviewer relationships.
It does not establish completion of any full audit lens.

`registration.json` and `support-registration.json` precede direct body
inspection; `personal-read-receipt.json` records actual displayed chunks and
unread complements. Source files retained in full are not automatically full
reads. Older 774 Native and 059 Adler/Segovb scopes belong to those reviewers;
`registry-selection-reconstructed.json` and
`queue-selection-reconstructed.json` are selected reconstructions, and the
complete 059 registry, transport manifest, queue and ledger are separately
retained under `history/`.

`git-proofs.json` and its compressed raw commit/tree objects independently bind
each file to its stated tree. The f82 commit is evidence transport. The a120
commit is the P16 base; the snapshot also has a dirty delta. The reproduced P16
tracked patch is retained with its later recovery report and matches the
original digest. Seven untracked files are outside that patch. The original
invocation, uninterrupted custody, and current historical worktree cleanliness
are not established. Earlier packet records with an unrecovered-patch status
retain that true historical observation; the later recovery supersedes only
that status. The original 059 transport payload Git path was not found in the
inspected object stores, so exact selected 059 bytes are checked against the
recovered original manifest rather than as a recovered Git path.

Two earlier exact local packet archives under `history/` retain prior author,
source scopes and limitations, and may contain nonessential local paths. Review
and appropriately redact any public copy while retaining original hashes and
bytes separately; do not claim a redacted copy is byte-identical. Neither old
records nor these source assessments restore or become checkpoint 3821.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` for evidence
integrity only. These checks do not invoke product code, builds, tests, viewers,
animations, fixtures, probes or other product validation.
