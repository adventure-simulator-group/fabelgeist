from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json');receipt=load('personal-read-receipt.json');groups={n:load(n) for n in ('registration.json','support-registration.json')};allregs={(name,e['archive']):e for name,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[1767,2711]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
p16=next(x for x in registry['snapshots'] if x['id']=='physical-p16');pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert p16['base']==p16['head']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(p16['status_porcelain'])==159;assert sha((b/'history/p16-tracked.patch').read_bytes())==p16['patch_sha256'];assert pr['base']=='3a50b708381ad00c116445c2c999a49c3943088b' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
assert sha((b/'sources/pr-base-3a50-not-read.rs').read_bytes())==registry['files'][1767]['base_sha256'];assert registry['files'][1767]['state']=='modified'
for r in groups.values():
 for x in r['entries']:
  d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
old,cur=groups['registration.json']['entries'];assert old['sha256']==registry['files'][2711]['sha256']==registry['files'][1767]['sha256'] and old['prospective_personal_read_ranges']==registry['files'][2711]['material_ranges']==[[88,92]];assert old['sha256']!=cur['sha256'];a=(b/old['archive']).read_bytes().splitlines();c=(b/cur['archive']).read_bytes().splitlines();assert a[87:92]==c[87:92]
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in sel['entries']]==[97,1245]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[97]['contract_id']=='ADLER-L11-LOCOMOTION-PROFILE-ADMISSION' and q[1245]['contract_id']=='Q-L12-96bf280e7b1c15aac5ae'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
e=next(x for x in load('history/059/segovb/READ-L11-442.json')['sources'] if x['original_index']==2711);assert e['fresh_personal_body_reads']==e['assessed_ranges']==[[88,92]]
e=next(x for x in load('history/059/adler/READ-L11-259.json')['sources'] if x['original_index']==1767);assert e['fresh_reads']==[[1,200],[201,267]]
e=next(x for x in load('history/059/segovb/READ-L12-571.json')['rows'] if x['original_index']==1767);assert e['fresh_personal_body_reads']==[[1,267]] and e['same_lens_reuse']==[]
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
regs=[json.loads(z) for z in gun('history/774/native/admission03/source-range-registration.jsonl.gz').splitlines()];quals={x['registration_id']:x for x in map(json.loads,gun('history/774/native/admission03/source-qualifications-final-current.jsonl.gz').splitlines())};r=registry['files'][2711]['admission03_scope_observations'][0];assert regs[r['row_1based']-1]==r['original_record'] and r['effective_material_ranges']==[[88,92]] and quals[r['registration_id']]==r['local_qualifications'][0];assert quals['NATIVE-ADMISSION03-REG-059']['qualified_material_ranges']==[[1,86]]
for x in history['prior_packets']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
  members={m.name for m in t.getmembers() if m.isfile()};mraw=t.extractfile(x['manifest_name']).read();assert sha(mraw)==x['manifest_sha256'];m=json.loads(mraw);assert members=={f['path'] for f in m['files']}|{x['manifest_name']}
  for f in m['files']:
   raw=t.extractfile(f['path']).read();assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
  assert sha(t.extractfile(x['report_name']).read())==x['report_sha256']
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==19
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
assert len(receipt['entries'])==len(allregs)==8;cover={}
for e in receipt['entries']:
 source=allregs[(e['registration'],e['archive'])];rr=groups[e['registration']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']) and e['registration_sha256']==sha((b/e['registration']).read_bytes()) and e['sha256']==source['sha256']
 actual={i for a,z in e['actual_personal_display_chunks'] for i in range(a,z+1)};planned={i for a,z in source['prospective_personal_read_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert actual<=planned and actual.isdisjoint(unread) and actual|unread==set(range(1,source['eof']+1));cover[(e['archive'],e['revision'])]=actual
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   possible=[e for e in allregs.values() if e['archive']==x['archive']];assert possible and x['sha256']==possible[0]['sha256'] and x['git_path']==possible[0].get('git_path',possible[0].get('source_path'));assert all(set(range(a,z+1))<=cover[(x['archive'],x['revision'])] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','role2711_original_material':[[88,92]],'current_role_file_personal_support':[[80,100]],'registered_personal_scopes':len(receipt['entries']),'historical_059_manifest_matched':len(history['records_059']),'historical_774_git_path_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'prior_full_packets_verified':len(history['prior_packets']),'bounded_lenses':len(report['thirteen_lens_dispositions']),'p16_reproduced_tracked_patch_digest_verified':True,'historical_059_payload_git_path_proof':'not available in inspected object stores; selected exact records match recovered original transport manifest','product_build_test_execution_probe_validation':'not performed'},indent=2))
