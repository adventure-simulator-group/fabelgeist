from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';base='a120390947c89b703dc74c4255a13c035d054c50';old='6533e444fa37552927070cc8d8190907fd3b413e';origin='039329518e264f19206cf5b0b98d177433f40c17';cur='95e63628f9d70b8dd6e6fede64334696c6995009';path='crates/adventuresim-tactical-core/src/animation/locomotion.rs';expected='6aef5ced10b1d430e513c990cd005b5e6ff4bdf8c98505b3dccd48d17cb6ac62'
proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+expected,'sources/p16-2711.rs','f82 transport of dirty P16 object; not project revision')
for r,k in [(base,'P16 recorded base individual file'),(old,'pr-working recorded head individual file; unrelated snapshot changes'),(origin,'059 catalog_origin individual file; not P16 revision')]:proof(r,path,'sources/p16-2711.rs',k)
proof('3a50b708381ad00c116445c2c999a49c3943088b',path,'sources/pr-base-3a50-not-read.rs','recorded pr-working base; full bytes retained for Git/hash proof, not personally displayed')
proof(cur,path,'sources/95e-locomotion.rs','pinned 95e current body; support only')
for x in json.loads((b/'support-registration.json').read_bytes())['entries']:proof(cur,x['git_path'],x['archive'],'personally displayed current support with scope in receipt')
proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/744e4868234738f05d7030c0cbae4c057fcbad21d41987b955e6895f3f9d5093','support/rate.rs','same exact 774 P16 rate object as 95e rate bytes; 774 Native separately read historic 1–86, no transferred credit')
proof(base,'crates/adventuresim-tactical-core/src/animation/sample_rate.rs','support/rate.rs','P16 base rate file equality only; whole snapshot remains dirty')
proof(cur,'crates/adventuresim-tactical-core/AGENTS.md','core-AGENTS.md','applicable repository rule')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(x['revision'],x['transport_path'],x['preserved'],'exact 774 historical reviewer record at f82')
out={'schema':'726-locomotion-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Git tree chains prove per-file identities only; f82 is audit transport and a120 is the P16 base, not its dirty commit. 039 is a 059 catalog_origin, not a P16 snapshot revision. 774 Native and 059 reviewers retain own scopes.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('git paths',len(proofs),'objects',len(objects))
