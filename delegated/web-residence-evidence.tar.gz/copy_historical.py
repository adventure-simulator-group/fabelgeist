import gzip,hashlib,json,pathlib
src=pathlib.Path('<LOCAL_PATH_0>');pub=pathlib.Path('<LOCAL_PATH_1>');out=pathlib.Path('<LOCAL_PATH_2>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f:entries={e['path']:e for e in json.load(f)['entries']}
paths=['adler/READ-L11-385.json','adler/STATE-L11-385.json','adler/VERIFY-L11-385.json','adler/READ-L11-386.json','adler/STATE-L11-386.json','adler/VERIFY-L11-386.json','adler/REGISTRATION-ADLER-1247.json','adler/REGISTRATION-ADLER-1248.json','adler/REGISTRATION-ADLER-1250.json']
for i in [790,791,792]:paths += [f'segovb/READ-L12-{i}.json',f'segovb/REGISTRATION-SEGOVB-L12-{i}.json',f'segovb/VERIFY-L12-{i}.json',f'parallel-l12-20261029/PROPOSAL-L12-{i}.json']
paths += ['segovb/READ-L12-CONNECTED-TEAM-007.json','segovb/READ-L12-CONNECTED-TEAM-008.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-CONNECTED-TEAM007.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-CONNECTED-TEAM008.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-787-CAMP-APPEARANCE-OWNERS.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-790-LOCATION-LOOKUP.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-792-REST-SUMMARY.json','parallel-l12-20261029/REGISTRATION-PAR-L12-363-CONNECTED-CAMP-OWNER.json','parallel-l12-20261029/REGISTRATION-PAR-L12-368.json','parallel-l12-20261029/REGISTRATION-PAR-L12-369-CONNECTED-LOCATION-LOOKUP.json','parallel-l12-20261029/REGISTRATION-PAR-L12-370.json','parallel-l12-20261029/REGISTRATION-PAR-L12-371.json','parallel-l12-20261029/REGISTRATION-PAR-L12-372-CONNECTED-REST-SUMMARY.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-368-LOCATOR-EOF-ORIGINAL2378.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-371-WINDOWS-ORIGINAL2380.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-792-ORIGINAL2380-FUTURE-SUPPORT.json']
rows=[];missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file():missing.append(path);continue
 b=(src/path).read_bytes();e=entries[path];h=hashlib.sha256(b).hexdigest();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),path
 dst=out/'historical'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);rows.append({'original_transport_path':path,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+path})
o={'schema':'delegated-recovered-historical-evidence-v1','qualification':'Exact copies from read-only original extraction checked against original transport SHA-256, length and Git blob. Preserve original reviewer, revision, scopes and open statuses; never promote to checkpoint3821 or current personal reads.','records':rows,'unavailable':missing}
f=out/'historical-manifest.json';f.write_text(json.dumps(o,indent=2)+'\n');print('verified',len(rows),'missing',missing,'manifest',hashlib.sha256(f.read_bytes()).hexdigest())
ref=out/'reference';ref.mkdir(exist_ok=True)
refs=[('<LOCAL_PATH_3>','registry.json.gz','exact original registry reference'),('<LOCAL_PATH_4>','original-transport-manifest.json.gz','exact original transport manifest reference'),('<LOCAL_PATH_5>','queue-059.json.gz','losslessly compressed 059 queue, not checkpoint3821'),('<LOCAL_PATH_6>','strategic-web-AGENTS-95e.md','current governing rules, no ordered credit'),('<LOCAL_PATH_7>','prior-web-equipment-report.json','same agent prior role and rest support attribution'),('<LOCAL_PATH_8>','prior-web-equipment-support-registration-01.json','same agent prior rest support registration'),(str(pub/'ASSESSMENT-L01-RESIDENCE-CLOCK-95E.json'),'prior-assessment-residence-clock-95e.json','prior current related billing-clock assessment, not 059')]
rs=[]
for source,name,cl in refs:
 s=pathlib.Path(source)
 if not s.is_file():print('unavailable reference',source);continue
 b=s.read_bytes();(ref/name).write_bytes(b);rs.append({'source':source,'copy':'reference/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'classification':cl})
f=ref/'manifest.json';f.write_text(json.dumps({'records':rs},indent=2)+'\n');print('references',len(rs),'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
