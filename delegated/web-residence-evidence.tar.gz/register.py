import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');revisions=['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']
roles=[(2378,'crates/strategic-web/src/routes/settlements/party/location_personal.rs'),(2379,'crates/strategic-web/src/routes/settlements/residences.rs'),(2380,'crates/strategic-web/src/routes/settlements/rest.rs')];rows=[];bodies=[]
for idx,path in roles:
 versions=[]
 for rev in revisions:
  x=subprocess.run(['git','show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if x.returncode:versions.append({'revision':rev,'present':False});continue
  b=x.stdout;versions.append({'revision':rev,'present':True,'lines':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()});bodies.append((rev,path,b))
 rows.append({'original_index':idx,'path':path,'versions':versions})
o={'schema':'delegated-audit-prospective-source-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Full assigned bodies at frozen historical and pinned current revisions; actual personally displayed ranges recorded separately, no other lens or checkpoint transfer.','prior_personal_support':'Same agent earlier read rest.rs 370–388 as support in <LOCAL_PATH_1> after support-registration-01.json; old support remains separately credited, not reused as fresh ordered read.','qualification':'Identical objects may be displayed once for both only after independent byte verification; differing versions need separately displayed ranges. Prior reviewer attribution remains separate.','constraint':'No product edits, repairs, builds, tests, browsers, runtime probes or simulations.','ordered_roles':rows}
f=p/'registration.json';f.write_text(json.dumps(o,indent=2)+'\n');print('registered',o['registered_utc'],hashlib.sha256(f.read_bytes()).hexdigest())
for row in rows:print(row['original_index'],row['path'],[(v['revision'][:4],v.get('lines'),v.get('sha256')) for v in row['versions']])
for rev,path,b in bodies:(p/'source'/(rev[:4]+'-'+pathlib.Path(path).name)).write_bytes(b)
