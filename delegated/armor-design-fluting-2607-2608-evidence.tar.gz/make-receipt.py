from pathlib import Path
import json,hashlib,datetime
r=Path(__file__).resolve().parent;b=(r/'registration.json').read_bytes();o=json.loads(b);reads=[]
for e in o['entries']:
 for v in e['versions']:
  got=set(n for a,z in v['registered_windows'] for n in range(a,z+1));un=[];start=None
  for n in range(1,v['eof']+1):
   if n not in got and start is None:start=n
   if n in got and start is not None:un.append([start,n-1]);start=None
  if start is not None:un.append([start,v['eof']])
  reads.append({'local':v['local'],'project_path':e['project_path'],'original_index':e.get('original_index'),'identity':v['identity'],'revision':v.get('revision'),'sha256':v['sha256'],'displayed_ranges':v['registered_windows'],'unread_complement':un})
receipt={'schema':'726-roles2607-2608-reconciliation-read-receipt-v1','reader':'/root/hair_ops','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(b).hexdigest(),'registration_clarification_sha256':hashlib.sha256((r/'registration-clarification.json').read_bytes()).hexdigest(),'actual_displays':reads,'qualification':'All listed historical/current source windows were separately displayed in untruncated tool output after registration and its correction. Supports only, not new historic ordered-role credit. The EOF complements remain unread in this packet even where other packets independently credit a fuller read. The original registry’s material excludes 2608 lines101 and132–146; the initial registration wording is explicitly corrected in the pre-display clarification.'}
out=(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n').encode();(r/'read-receipt.json').write_bytes(out);print('receipt',hashlib.sha256(out).hexdigest(),'views',len(reads))
