from pathlib import Path
import gzip,hashlib,json
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
m=json.loads((r/'recovered/MANIFEST.json').read_bytes());rb=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());registry=json.loads(rb);assert h(rb)==m['registry_sha256']=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';assert h((r/'recovered/registry.json.gz').read_bytes())==m['registry_gzip_sha256']
registration=json.loads((r/'registration.json').read_bytes());clar=json.loads((r/'registration-clarification.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());assert clar['registration_sha256']==rec['registration_sha256']==h((r/'registration.json').read_bytes());assert rec['registration_clarification_sha256']==h((r/'registration-clarification.json').read_bytes());assert len(rec['actual_displays'])==10
for e in registration['entries']:
 if 'original_index' in e:
  row=registry['files'][e['original_index']];assert row==e['original_registry_row'];b=(r/e['versions'][0]['local']).read_bytes();assert h(b)==row['sha256']
 for v in e['versions']:
  b=(r/v['local']).read_bytes();assert h(b)==v['sha256'] and len(b.splitlines())==v['eof'];p=next(x for x in rec['actual_displays'] if x['local']==v['local']);assert p['displayed_ranges']==v['registered_windows'] and p['sha256']==v['sha256'];observed=set();unread=set()
  for a,z in p['displayed_ranges']:observed.update(range(a,z+1))
  for a,z in p['unread_complement']:unread.update(range(a,z+1))
  assert not observed.intersection(unread) and observed.union(unread)==set(range(1,v['eof']+1))
proof=json.loads((r/'git-proofs.json').read_bytes());objs={}
for k,v in proof['objects'].items():
 b=gzip.decompress((r/v['local']).read_bytes());assert len(b)==v['size'] and h(b)==v['sha256'] and oid(v['type'],b)==k;objs[k]=b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),k
 raise AssertionError(n)
assert len(proof['proofs'])==18
for p in proof['proofs']:
 tree=objs[p['revision']].splitlines()[0].split()[1].decode();assert tree==p['root_tree']
 for c in p['chain']:
  assert tree==c['tree'];mode,k=lookup(objs[tree],c['name']);assert mode==c['mode'] and k==c['object'];tree=k
 assert p['path'].split('/')==[c['name'] for c in p['chain']];b=(r/p['local']).read_bytes();b=gzip.decompress(b) if p.get('encoding')=='gzip' else b;assert h(b)==p['sha256'] and oid('blob',b)==tree==p['blob']
queue=json.loads(gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes()));ledger=json.loads(gzip.decompress((r/'recovered/original-059-ledger.json.gz').read_bytes()));sel=json.loads((r/'historical/selections-reconstructed.json').read_bytes());idx=json.loads((r/'historical/evidence-index.json').read_bytes());expected=[608,641,1814,1815,1818,2689,3141];assert set(sel['queue_rows'])==set(map(str,expected))
for i in expected:
 row=queue['entries'][i];assert sel['queue_rows'][str(i)]==row
 if row['contract_id'] in sel['ledger_findings']:assert sel['ledger_findings'][row['contract_id']]==ledger['discovery_findings_and_dependencies'][row['contract_id']]
refs={}
def walk(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str) and len(x['sha256'])==64:refs[x['path']]=x['sha256']
  if isinstance(x.get('verification'),str) and isinstance(x.get('verification_sha256'),str):refs[x['verification']]=x['verification_sha256']
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for y in x:walk(y)
for i in expected:walk(queue['entries'][i])
assert refs==idx['original_059_receipts_from_queue_hashes'] and len(refs)==9
for p,digest in refs.items():assert h((r/'historical'/p).read_bytes())==digest
for x in idx['prior_frozen_packets']:
 base=r/'prior'/x['label'];b=(base/'MANIFEST.json').read_bytes();assert h(b)==x['manifest_sha256'];known={y['path']:y['sha256'] for y in json.loads(b)['files']}
 for p in x['members']:assert h((base/p).read_bytes())==known[p]
for x in idx['central_working_snapshots']:
 b=gzip.decompress((r/x['local']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256']
patch=(r/'recovered/p16/tracked.patch').read_bytes();assert len(patch)==524542 and h(patch)==next(x['patch_sha256'] for x in registry['snapshots'] if x['id']=='physical-p16')
report=json.loads((r/'REPORT.json').read_bytes());assert report['registration']['sha256']==h((r/'registration.json').read_bytes()) and report['registration']['clarification_sha256']==h((r/'registration-clarification.json').read_bytes()) and report['read_receipt']['sha256']==h((r/'read-receipt.json').read_bytes()) and report['git_proofs']['sha256']==h((r/'git-proofs.json').read_bytes());assert len(report['bounded_lens_perspectives'])==13 and report['new_ledger_rows']==[] and report['accepted_unique_count_change']==0
rows=json.loads(gzip.decompress((r/'central/RECONCILIATION-059.json.gz').read_bytes()))['entries'];assert all(report['captured_central_reconciliation']['rows'][str(i)]==rows[i] for i in expected)
manifest=r/'MANIFEST.json'
if manifest.exists():
 entries={e['path']:e for e in json.loads(manifest.read_bytes())['files']};actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p!=manifest};assert set(entries)==actual
 for n,e in entries.items():b=(r/n).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],n
print('PASS: original registry and P16 patch; 18 offline Git proofs including 774 originals; 10 personal read partitions and pre-display correction; exact 059 queue, ledger and referenced receipts; prior manifest members and central snapshots; 13 bounded perspectives'+('; full packet manifest' if manifest.exists() else '; pre-manifest'))
print('Evidence identity verification only. No product parser, GPU, geometry, test, build, probe, repair or runtime validation was performed.')
