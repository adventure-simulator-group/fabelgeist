from pathlib import Path
import hashlib,json,datetime
r=Path(__file__).resolve().parent;out=r/'MANIFEST.json';files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p!=out:
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
o={'schema':'726-checkpoint17-armor-reconciliation-packet-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'qualification':'Only the top-level MANIFEST.json itself is excluded; nested manifest bytes are included. Offline source and evidence integrity, not product validation.'};out.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n');print('files',len(files),'manifest sha256',hashlib.sha256(out.read_bytes()).hexdigest())
