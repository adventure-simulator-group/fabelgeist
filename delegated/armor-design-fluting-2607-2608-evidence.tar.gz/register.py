from pathlib import Path
import gzip,hashlib,json,tarfile,subprocess,datetime
r=Path(__file__).resolve().parent
prior=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';base='6533e444fa37552927070cc8d8190907fd3b413e';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';h=lambda b:hashlib.sha256(b).hexdigest()
reg=json.load(gzip.open(prior/'registry.json.gz','rt'));(r/'source').mkdir();entries=[]
with tarfile.open(prior/'objects.tar.gz') as archive:
 for index,windows in [(2607,[[6,50],[84,121]]),(2608,[[1,26],[43,98],[102,131],[147,150]])]:
  row=reg['files'][index];path=row['source_id'].split(':',1)[1];b=archive.extractfile(row['sha256']).read();assert h(b)==row['sha256'];transport='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];assert b==subprocess.check_output(['git','-C',repo,'show',f82+':'+transport]);assert b==subprocess.check_output(['git','-C',repo,'show',base+':'+path]);versions=[]
  for label,identity,payload in [('historical','dirty pr-working snapshot object; 6533 is recorded base and f82 transports the object',b),('current','pinned current project 95e',subprocess.check_output(['git','-C',repo,'show',rev+':'+path]))]:
   loc=f'source/{index}-{label}.rs';(r/loc).write_bytes(payload);assert max(z for a,z in windows)<=len(payload.splitlines());versions.append({'identity':identity,'local':loc,'sha256':h(payload),'eof':len(payload.splitlines()),'registered_windows':windows,**({'revision':rev} if label=='current' else {})})
  entries.append({'original_index':index,'purpose':'bounded reconciliation support, no new historical read or role credit','project_path':path,'original_registry_row':row,'historical_transport_revision':f82,'historical_transport_path':transport,'versions':versions})
project=[('armor-validation','crates/fabelgeist-armor/src/lib.rs',[[178,220]]),('anime','crates/fabelgeist-armor/src/anime_design.rs',[[12,56]]),('units-bracer','crates/fabelgeist-armor/src/design.rs',[[1,22],[45,100]]),('loader','crates/adventuresim-character-creator/src/design_input.rs',[[1,30]]),('device-bracer','crates/fabelgeist-armor/src/gpu/bracer.rs',[[165,205],[285,315]]),('chart','crates/fabelgeist-armor/src/gpu/chart.rs',[[80,110],[175,205]])]
for name,path,windows in project:
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);loc=f'source/{name}.rs';(r/loc).write_bytes(b);assert max(z for a,z in windows)<=len(b.splitlines());entries.append({'purpose':'current bounded support; no original role credit','project_path':path,'versions':[{'identity':'pinned current project 95e','revision':rev,'local':loc,'sha256':h(b),'eof':len(b.splitlines()),'registered_windows':windows}]})
o={'schema':'726-roles2607-2608-bounded-reconciliation-registration-v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','entries':entries,'qualification':'All listed windows to be displayed per revision after registration. Original rig and 059 reader credit remains distinct. Historical pr-working snapshot has unrelated modifications; matching selected file bytes do not establish a clean tree. Role2608 excludes line101 and 132–146 within original material, and new displays of support never transfer role2725/2726 P16 or prior /root/mhr_character full-read credit. Metadata-only git grep for catalog_id output just paths and lines, before this registration. No execution or validation.'}
b=(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode();(r/'registration.json').write_bytes(b)
print('registered',h(b),'entries',len(entries),'versions',sum(len(e['versions']) for e in entries))
for e in entries:
 for v in e['versions']:print(v['local'],v['sha256'],v['eof'],v['registered_windows'])
