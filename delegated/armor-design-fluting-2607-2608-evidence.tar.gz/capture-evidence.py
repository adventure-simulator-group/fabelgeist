from pathlib import Path
import gzip,json,hashlib,shutil,datetime
r=Path(__file__).resolve().parent;prev=Path('<LOCAL_PATH_0>');user=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest()
for d in ['recovered','historical','prior','central']:(r/d).mkdir()
for n in ['MANIFEST.json','registry.json.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:shutil.copyfile(prev/'recovered'/n,r/'recovered'/n)
(r/'recovered/p16').mkdir()
for n in ['tracked.patch','RECOVERY.json']:shutil.copyfile(prev/'recovered/p16'/n,r/'recovered/p16'/n)
q=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'));ledger=json.load(gzip.open(r/'recovered/original-059-ledger.json.gz','rt'));inds=[608,641,1814,1815,1818,2689,3141];rows={str(i):q['entries'][i] for i in inds};findings={e['contract_id']:ledger['discovery_findings_and_dependencies'][e['contract_id']] for e in rows.values() if e['contract_id'] in ledger['discovery_findings_and_dependencies']}
(r/'historical/selections-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed selected rows of exact recovered 059 queue and ledger bytes, neither independent original records nor checkpoint3821. q641 is pending, not an accepted unique finding.','queue_rows':rows,'ledger_findings':findings},indent=2,ensure_ascii=False)+'\n')
refs={}
def walk(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str) and len(x['sha256'])==64:refs[x['path']]=x['sha256']
  if isinstance(x.get('verification'),str) and isinstance(x.get('verification_sha256'),str):refs[x['verification']]=x['verification_sha256']
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for y in x:walk(y)
for row in rows.values():walk(row)
for p,d in refs.items():
 b=(user/p).read_bytes();assert h(b)==d,p;out=r/'historical'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
packets=[('design-fluting','<LOCAL_PATH_3>','660f71c1993ef53a5e47db2fb18ccb924f6fb20873d4daa7379b5105bdfa45c8',['report.json','registration.json','read-receipt.json','support-registration.json','support-read-receipt.json','history-059/READ-L11-427.json','history-059/READ-L11-445.json','history-059/READ-L12-889.json','history-059/READ-L12-890.json','history-059/QUALIFICATION-PAR-L12-674-ORIGINAL2607.json','history-059/QUALIFICATION-PAR-L12-675-ORIGINAL2608.json','history-774/findings.jsonl.gz','history-774/source-range-registration.jsonl.gz','history-774/additional-contracts.jsonl.gz']),('p16-admission','<LOCAL_PATH_4>','47db455e0586a2d9e60678cd36adfccc19984221569410045fd983ef6c47357d',['REPORT.json','registration.json','read-receipt.json','historical/774/native-p16-armor-admission.json']),('p16-primitives','<LOCAL_PATH_5>','6ef76a8c1b376d96910be3173f17e422cd491c88e2b1966096f8c0d05c9b4962',['REPORT.json','registration.json','read-receipt.json','historical-manifest.json'])]
pktinfo=[]
for label,old,expected,files in packets:
 p=Path(old);mb=(p/'MANIFEST.json').read_bytes();assert h(mb)==expected;mapping={v['path']:v['sha256'] for v in json.loads(mb)['files']};dest=r/'prior'/label;dest.mkdir();(dest/'MANIFEST.json').write_bytes(mb)
 for f in files:
  b=(p/f).read_bytes();assert h(b)==mapping[f],(label,f);out=dest/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 pktinfo.append({'label':label,'previous_directory':old,'manifest_sha256':expected,'members':files})
central=['RECONCILIATION-059.json','BASELINE-95E-20261110.json','DELEGATED-EVIDENCE-CHECKPOINT-17.json','ASSESSMENT-LIMB-METAL-95E.json','ASSESSMENT-HELMET-FOOTWEAR-95E.json','ASSESSMENT-PAULDRON-PART-95E.json']
centralmeta=[]
for n in central:
 b=(pub/n).read_bytes();out='central/'+n+'.gz';(r/out).write_bytes(gzip.compress(b,mtime=0));centralmeta.append({'path':n,'local':out,'sha256':h(b),'bytes':len(b)})
o={'schema':'726-roles2607-2608-evidence-index-v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_059_receipts_from_queue_hashes':refs,'prior_frozen_packets':pktinfo,'central_working_snapshots':centralmeta,'qualification':'Exact 059 linked receipts match their 059 reference hashes; additional original receipts and 774 records are copied unchanged as manifest-verified prior packet members. Central files are captured working snapshots, potentially staged/uncommitted, not asserted as a published commit. No prior verifiers invoked and no reader, dirty-P16 or checkpoint3821 credit transferred. Full source object archive is not duplicated; selected historical file objects have f82 Git proofs and original registry hash bindings.'}
(r/'historical/evidence-index.json').write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n');print('059 queue linked receipts',len(refs),'prior packet selections',len(pktinfo),'central snapshots',len(centralmeta))
