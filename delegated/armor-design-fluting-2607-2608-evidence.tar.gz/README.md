# Checkpoint 17: breastplate design and plate-fluting reconciliation

This additive packet proposes bounded links to existing 059 gauge, fluting,
helmet and catalog records. It assigns no new accepted finding or role credit,
and does not claim a whole lens complete. `registration.json` and the separate
pre-display correction record the prospective source windows; `read-receipt.json`
contains the actual separate pr-working and 95e displays and unread complements.

The original 059 queue and ledger are preserved byte-for-byte in gzip containers.
Selected rows are explicitly reconstructed. Historical 774 rig and native
records, 059 receipts and prior delegate reports are exact manifest-verified
copies; the named readers and historical revisions remain separate. Central
files are timestamped working snapshots that may have been staged or
uncommitted at capture and are not asserted to be the final published state.

For roles 2607–2608, f82 transports the historical pr-working source objects,
which individually equal 6533 and 95e. This does not establish a clean
pr-working snapshot or equate it with the separately dirty physical-P16
snapshot. A later P16 tracked patch matches the recorded hash but excludes
seven untracked files. No material is promoted to missing checkpoint 3821.

Run `python3 verify-evidence.py` from any directory for a read-only offline
check of source, historic and packet identities. This is evidence verification,
not a product test, build, runtime probe, repair or behavioral validation.
