from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile
b=Path(__file__).parent; arc=b/'packages/bevy_ecs-0.19.1.crate';check='a350b2e4c2e47f7903d688affb8a723b31bca63af9789f1da88703f1ba04e354';assert hashlib.sha256(arc.read_bytes()).hexdigest()==check
spec=[('observer-runner','bevy_ecs-0.19.1/src/observer/runner.rs',[[1,150]]),('function-system','bevy_ecs-0.19.1/src/system/function_system.rs',[[570,630]])]; rows=[]
with tarfile.open(arc) as tar:
 for ident,member,ranges in spec:
  d=tar.extractfile(member).read(); path='support/'+ident+'.rs';(b/path).write_bytes(d);rows.append({'id':ident,'repo_kind':'crate-archive','package':'bevy_ecs','version':'0.19.1','package_archive':'packages/bevy_ecs-0.19.1.crate','package_checksum':check,'member_path':member,'archive':path,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'eof':len(d.splitlines()),'prospective_read_ranges':ranges,'qualification':'Native supporting context only, no reassignment of separate original roles 11/12 or transferred reader attribution.'})
(b/'native-support-registration.json').write_text(json.dumps({'schema':'726-bevy-native-support-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
