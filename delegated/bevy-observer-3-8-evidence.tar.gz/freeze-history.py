from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).parent;pub=Path('<LOCAL_PATH_0>');rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';prev=Path('<LOCAL_PATH_1>');locks=Path('<LOCAL_PATH_2>');ex=Path('<LOCAL_PATH_3>');sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d);return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[];wm=json.loads((prev/'MANIFEST.json').read_bytes());wi={x['path']:x for x in wm['files']}
for f in ['history/original-registry.json.gz','history/original-transport-manifest.json.gz','history/baseline-059-queue.json.gz','history/baseline-059-ledger.json.gz']:
 d=(prev/f).read_bytes();assert sha(d)==wi[f]['sha256'];refs.append({'kind':'exact previously preserved original registry/transport or compressed historical 059 summary, not checkpoint3821','from_verified_packet':str(prev),'original_packet_path':f,'original_uncompressed_sha256':sha(gzip.decompress(d)),**save(d,f)})
r=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes())); roles=[3,4,5,6,7,8,1692];(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanical selected rows retaining original scopes and source identities, not a fresh read receipt or checkpoint3821. Role 1692 is independently bounded support, not assigned role credit.','rows':[{'original_index':i,**r['files'][i]} for i in roles],'snapshots':[x for x in r['snapshots'] if x['id']=='pr-working']},indent=2)+'\n')
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries'];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-059-queue-reconstruction-v1','qualification':'Mechanical selection of original 059 historical summary, no new historical count or checkpoint3821 credit.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in [91,92]]},indent=2)+'\n')
for n,expected in [('READ-L11-244.json','5fb5a7ba00f88d568e03a1f4c12b7bf041a85a1b764a8617ea67f545e8f6d0b0'),('REGISTRATION-ADLER-526.json','873d67df6816df50b8d34c734487bfea1a7af0362cc4402bfef9dd6817a4e4a4'),('REGISTRATION-ADLER-530.json','5b369038543d80a9c9e655c48f9970e98ee7ab89aa2124c023d182c302721de2')]:
 d=(ex/n).read_bytes();assert sha(d)==expected;refs.append({'kind':'original extracted 059 Adler lens11 receipt/registration; attribution and original line ranges unchanged','original_locator':'adler/'+n,**save(d,'history/059/'+n)})
d=(pub/'ASSESSMENT-STRATEGIC-STATUS-CENSUS-95E.json').read_bytes();refs.append({'kind':'prior separately authored central 95e assessment, no transferred source-read credit','original':'ASSESSMENT-STRATEGIC-STATUS-CENSUS-95E.json',**save(d,'history/prior-status-assessment-95e.json')})
paths=[]
for who in ['native','rig']:
 for fam,lab in [('adler-original/audit/records','redacted'),('historical-family-execution','original-paths')]:
  paths.append((f'handoff/774/{fam}/final-acceptance-20261021/wave-01/audit-existing-type-owners/{who}/additional-sources.jsonl',f'{who}-owner-{lab}.jsonl'))
for who in ['native','rig']:
 for fn in ['contracts.jsonl','findings.jsonl']:
  paths.append((f'handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/audit-existing-type-owners/{who}/{fn}',f'{who}-owner-{fn}'))
for fn in ['native-framework-port.json','additional-range-coverage.jsonl']:
 paths.append(('handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/audit-existing-type-owners/native/'+fn,'native-'+fn))
paths += [('handoff/774/adler-original/audit/continuation/rig/admission03/contract-groups.jsonl','rig-admission-contracts.jsonl'),('handoff/774/adler-original/audit/continuation/camera/initial07-redundant-authority/contracts.jsonl','camera-contracts.jsonl')]
for n in ['020','064','065']: paths.append((f'handoff/774/adler-original/audit/continuation/native/initial05-aggregate-states/contract-groups-{n}.json',f'native-aggregate-{n}.json'))
old=[]
for p,n in paths:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+p]);old.append({'revision':rev,'transport_path':p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+n+'.gz')})
comparisons=[]
for who,indices in [('native',[3,6,7,8]),('rig',[4,5])]:
 a=[json.loads(z) for z in gzip.decompress((b/f'history/774/{who}-owner-redacted.jsonl.gz').read_bytes()).splitlines()];z=[json.loads(z) for z in gzip.decompress((b/f'history/774/{who}-owner-original-paths.jsonl.gz').read_bytes()).splitlines()]
 for i in indices:
  e=r['files'][i];p=e['owner_contract_proofs'][0];j=p['row'];x=a[j];y=z[j];assert x['source_id']==y['source_id']==e['source_id'] and x['observed_sha256']==y['observed_sha256']==e['sha256'] and x['read_ranges']==y['read_ranges']==p['read_ranges']; diffs=[k for k in sorted(set(x)|set(y)) if x.get(k)!=y.get(k)]; comparisons.append({'role':i,'supplier':who,'registry_row_zero_based':j,'physical_line_1based':j+1,'different_top_level_keys':diffs,'redacted_path':x.get('path'),'original_path':y.get('path'),'registry_read_status':p.get('read_status')})
lm=json.loads((locks/'MANIFEST.json').read_bytes());li={x['path']:x for x in lm['files']};copied=[]
for path in ['lock-registration.json','lock-inventory.json']+[x['archive'] for x in json.loads((locks/'lock-registration.json').read_bytes())['entries']]:
 raw=(locks/path).read_bytes();e=li[path];assert sha(raw)==e['sha256'] and len(raw)==e['bytes'];copied.append({'original_packet':str(locks),'original_path':path,**save(raw,path)})
prior={'author':'/root/rig_identity','original_directory':str(locks),'qualification':'Prior exact lock inventory, not current feature resolution or freshly displayed whole lock body.'}
for n in ['REPORT.json','MANIFEST.json']:prior[n]=save((locks/n).read_bytes(),'history/prior/eidolon-2790-2793/'+n)
out={'schema':'726-bevy-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_774':old,'selected_supplier_variant_comparisons':comparisons,'prior_lock_packet_report_manifest':prior,'copied_prior_lock_evidence':copied,'qualification':'Selected 774 supplier rows are compared individually across redacted/original-path files; original 059 receipt and registrations are exact extracted records. Original native additional-sources read_status is null for roles3,6–8; separate native framework-port and range-coverage explicitly record limited material reads, all remain historically attributed. Rig originally registered 1–159 for role4 but actual EOF129; separately 774 admission/native aggregate and original 059 exact reinspection preserved. No historical record is checkpoint3821.'};(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('refs',len(refs),'774',len(old),'locks',len(copied),'comparisons',json.dumps(comparisons,indent=2))
