from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tomllib,tarfile
b=Path(__file__).parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');report=load('REPORT.json')
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'];
 if 'original_uncompressed_sha256' in x:assert sha(gzip.decompress(d))==x['original_uncompressed_sha256']
registry=json.loads(gun('history/original-registry.json.gz'));assert sha(gun('history/original-registry.json.gz'))=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';assert sha(gun('history/original-transport-manifest.json.gz'))=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858'
roles=[3,4,5,6,7,8];sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==roles+[1692]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
checks={'bevy_app':'5fd2aa472d43b4d081ef41d26300d17bd22cba6d68df2a223eb358782fa40bc6','bevy_asset':'1624eddbf2293441b2158506aba75e523432b898d9da26eb6ed3e20af4c7fd38','bevy_ecs':'a350b2e4c2e47f7903d688affb8a723b31bca63af9789f1da88703f1ba04e354'}
for n,h in checks.items():assert sha((b/f'packages/{n}-0.19.1.crate').read_bytes())==h
names=['registration.json','support-registration.json','native-support-registration.json'];groups={n:load(n) for n in names};regs={(n,str(e['id'])):e for n,r in groups.items() for e in r['entries']}
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
 if name in ['registration.json','native-support-registration.json']:
  assert x['package_checksum']==checks[x['package']]
  with tarfile.open(b/x['package_archive']) as tar:assert tar.extractfile(x['member_path']).read()==d
for i in roles:
 x=regs[('registration.json',str(i))];r=registry['files'][i];assert x['original_source_id']==r['source_id'] and x['sha256']==r['sha256'] and x['original_registered_ranges']==r['owner_contract_proofs'][0]['read_ranges']
assert regs[('registration.json','4')]['eof']==129 and regs[('registration.json','4')]['nonexistent_original_tail']==[[130,159]]
assert regs[('support-registration.json','dirty-past')]['sha256']==registry['files'][1692]['sha256'] and registry['files'][1692]['state']=='modified'
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];selection=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in selection['entries']]==[91,92]
for x in selection['entries']:assert x['entry']==q[x['original_index_zero_based']]
rec=load('history/059/READ-L11-244.json');assert sha((b/'history/059/READ-L11-244.json').read_bytes())=='5fb5a7ba00f88d568e03a1f4c12b7bf041a85a1b764a8617ea67f545e8f6d0b0'
z=next(x for x in rec['connected_reinspection'] if x['original_index']==4);assert z['fresh_reads']==[[1,129]] and z['additional_original_frontier_credit']==0 and z['inherited_scope_extent_qualification']['excluded_nonexistent_ranges']==[[130,159]]
for idx,n in [(1692,'526'),(4,'530')]:
 a=load(f'history/059/REGISTRATION-ADLER-{n}.json'); assert a['original_index']==idx and a['prospective'];refs=rec['sources'] if idx==1692 else rec['connected_reinspection'];e=next(x for x in refs if x['original_index']==idx);assert sha((b/f'history/059/REGISTRATION-ADLER-{n}.json').read_bytes())==e['registration_sha256']
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
for who in ['native','rig']:
 a=[json.loads(z) for z in gun(f'history/774/{who}-owner-redacted.jsonl.gz').splitlines()];c=[json.loads(z) for z in gun(f'history/774/{who}-owner-original-paths.jsonl.gz').splitlines()];assert sha(gun(f'history/774/{who}-owner-redacted.jsonl.gz'))!=sha(gun(f'history/774/{who}-owner-original-paths.jsonl.gz'))
 for x in [v for v in hist['selected_supplier_variant_comparisons'] if v['supplier']==who]:
  r=registry['files'][x['role']];proof=r['owner_contract_proofs'][0];j=proof['row'];u,v=a[j],c[j];assert j==x['registry_row_zero_based'] and j+1==x['physical_line_1based'];assert u['source_id']==v['source_id']==r['source_id'] and u['observed_sha256']==v['observed_sha256']==r['sha256'] and u['read_ranges']==v['read_ranges']==proof['read_ranges'] and u.get('read_status')==v.get('read_status')==proof.get('read_status');diff=[k for k in sorted(set(u)|set(v)) if u.get(k)!=v.get(k)];assert diff==x['different_top_level_keys']==(['native_source_path','path'] if who=='native' else ['path']) and u['path']==x['redacted_path'] and v['path']==x['original_path']
port=json.loads(gun('history/774/native-native-framework-port.json.gz'));assert port['trace_id']=='NATIVE-OWNER-OBSERVER-001'
for i in [3,6,7,8]:
 r=registry['files'][i];assert r['owner_contract_proofs'][0]['read_status'] is None
 x=next(x for x in port['resolved_read_files'] if x['source_id']==r['source_id']);assert x['observed_sha256']==r['sha256'] and x['read_ranges']==r['owner_contract_proofs'][0]['read_ranges']
for who,id in [('native','NATIVE-OWNER-F009'),('rig','RIG-OWNER-F006')]:assert any(json.loads(z).get('id')==id for z in gun(f'history/774/{who}-owner-findings.jsonl.gz').splitlines())
adm=[json.loads(z) for z in gun('history/774/rig-admission-contracts.jsonl.gz').splitlines()]
for role,no in [(4,13),(5,14)]:
 x=next(x for x in adm if x.get('id')==f'RIG-ADMISSION03-CONTRACT-{no:03d}');assert x['source_id']==registry['files'][role]['source_id'] and x['sha256']==registry['files'][role]['sha256'] and x['actual_read_ranges']==regs[('registration.json',str(role))]['prospective_personal_read_ranges']
cam=[json.loads(z) for z in gun('history/774/camera-contracts.jsonl.gz').splitlines()]
for role in roles:
 x=next(x for x in cam if x['id']==('CAMERA-INITIAL07-CONTRACT-006' if role in [4,5] else 'CAMERA-INITIAL07-CONTRACT-005'));m=next(m for m in x['members'] if m.get('scope014_index')==role);assert m['material_ranges']==regs[('registration.json',str(role))]['prospective_personal_read_ranges']
for no,role in [('020',3),('020',6),('020',8),('064',4),('065',7)]:
 x=json.loads(gun(f'history/774/native-aggregate-{no}.json.gz'));m=next(m for m in x['source_members'] if m['source_id']==registry['files'][role]['source_id']);assert m['scoped_ranges_compared']==regs[('registration.json',str(role))]['prospective_personal_read_ranges']
prior=hist['prior_lock_packet_report_manifest'];manifest=json.loads((b/prior['MANIFEST.json']['preserved']).read_bytes());e=next(x for x in manifest['files'] if x['path']=='REPORT.json');assert e['sha256']==prior['REPORT.json']['sha256']
for n in ['REPORT.json','MANIFEST.json']:
 x=prior[n];raw=(b/x['preserved']).read_bytes();assert sha(raw)==x['sha256'] and len(raw)==x['bytes']
for x in hist['copied_prior_lock_evidence']:
 raw=(b/x['preserved']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
lreg=load('bevy-lock-registration.json');inv=load('bevy-lock-inventory.json');assert lreg['prior_registration_sha256']==sha((b/'lock-registration.json').read_bytes()) and inv['registration_sha256']==sha((b/'bevy-lock-registration.json').read_bytes()) and datetime.fromisoformat(lreg['at_utc'])<datetime.fromisoformat(inv['at_utc']) and len(lreg['entries'])==len(inv['entries'])==8
for x,y in zip(lreg['entries'],inv['entries']):
 raw=(b/x['archive']).read_bytes();assert x['id']==y['id'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']==y['sha256'];packages=tomllib.loads(raw.decode())['package'];matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in packages if p['name'] in checks and p['version']=='0.19.1'];assert len(packages)==y['package_count'] and matches==y['matches'];expected=3 if x['git_path'] in ['Cargo.lock','crates/adventuresim-character-creator/Cargo.lock'] else 0;assert len(matches)==expected
 for p in matches:assert p['checksum']==checks[p['name']] and p['source']=='registry+https://github.com/rust-lang/crates.io-index'
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
assert len(proof['paths'])==33 and not proof['absent_paths']
coverage={}
for receipt in ['read-receipt.json','support-read-receipt.json','native-support-read-receipt.json']:
 r=load(receipt);name=r['registration'];assert r['registration_sha256']==sha((b/name).read_bytes()) and datetime.fromisoformat(groups[name]['at_utc'])<datetime.fromisoformat(r['recorded_at_utc'])
 for e in r['entries']:
  id=str(e.get('id',e.get('role')));x=regs[(name,id)];assert e['sha256']==x['sha256'];actual={i for a,z in e['actual_display_chunks'] for i in range(a,z+1)};planned={i for a,z in x.get('prospective_personal_read_ranges',x.get('prospective_read_ranges',[])) for i in range(a,z+1)};remaining={i for a,z in e['unread_existing_lines'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage[id]=actual
assert len(regs)==len(coverage)==10
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(str(e['id'])==str(x['id']) and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[str(x['id'])] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','native_roles':roles,'personal_registered_scopes':len(regs),'774_records_git_proved':len(hist['records_774']),'supplier_variants':'native rows differ path and native_source_path; rig rows differ path','059_receipt_and_registration':'exact prior recorded bytes; no borrowed scope credit','role4':'actual EOF129; original 130–159 nonexistent','git_paths_proved':len(proof['paths']),'lockfiles_structurally_verified':8,'package_archives_and_members_verified':3,'bounded_lenses':13,'feature_resolution':'not inferred','build_test_fixture_product_execution_probe_validation':'not performed'},indent=2))
