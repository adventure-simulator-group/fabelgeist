# Bounded Bevy 0.19.1 native source review: roles 3–8

`REPORT.json` is the review. `registration.json` and `read-receipt.json`
record prospectively registered and actually displayed assigned ranges; the
support registrations and receipts separately record independent supporting
reads. Complete raw archive members are preserved for recovery but their unread
complements are not credited. The report relates, without deduplicating, the
original 774 native and rig findings and the 059 Adler receipt and queue.

The original role 4 request extends past EOF. The exact package member has 129
lines. Original lines 130–159 do not exist. This qualification was already
recorded by earlier 774 and 059 reinspection; its rediscovery is corroboration,
not a new finding.

`packages/` contains checksum-matched crates.io archives; `locks/` contains exact
6533 and 95e committed lockfile bytes from the prior packet. Git proof objects
bind project lockfiles, the pinned current first-party support, exact 774
records, and f82 recovered source objects to their transporting commits. Package
source identity is its package/version/checksum/member, not a project Git
revision. The recorded pr-working historical state has modifications; f82
transports the preserved modified status source and is not its product revision.
Both 774 supplier variants are retained as exact bytes and are not identical.
The original-path variant includes local filesystem paths; review and redact
public copies while retaining original bytes and recording separate hashes.

`history/original-registry.json.gz` is recovered 059 source metadata. The
`*-selection-reconstructed.json` files are mechanical selections from that
metadata and the 059 historical queue, not original standalone artifacts or
checkpoint 3821. `history/059` contains the exact extracted receipt and
registrations. The separate prior 95e assessment retains its original attribution.

Run the evidence-only checks from any directory:

```sh
python3 <LOCAL_PATH_0>
python3 <LOCAL_PATH_1>
```

These checks hash, parse and compare saved evidence only. No source repair,
product builds, tests, fixtures, observers, GPU operations, runtime probes or
product validation were performed. Read scopes and open questions do not imply
completion of the thirteen whole lenses.
