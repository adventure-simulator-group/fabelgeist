from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tomllib
b=Path(__file__).resolve().parent;reg=json.loads((b/'bevy-lock-registration.json').read_bytes());out=[]
for x in reg['entries']:
 raw=(b/x['archive']).read_bytes();assert hashlib.sha256(raw).hexdigest()==x['sha256'];pkgs=tomllib.loads(raw.decode())['package'];matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in pkgs if p['name'] in ['bevy_app','bevy_asset','bevy_ecs'] and p['version']=='0.19.1'];out.append({'id':x['id'],'sha256':x['sha256'],'package_count':len(pkgs),'matches':matches,'qualification':'Exact selected version only, structural parsing, no target/feature or execution claim.'})
(b/'bevy-lock-inventory.json').write_text(json.dumps({'schema':'726-bevy-lock-inventory-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256((b/'bevy-lock-registration.json').read_bytes()).hexdigest(),'entries':out},indent=2)+'\n')
