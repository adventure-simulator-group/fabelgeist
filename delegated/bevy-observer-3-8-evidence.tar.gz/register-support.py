from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
b=Path(__file__).parent;pub='<LOCAL_PATH_0>';p='crates/adventuresim-tactical-client/src/strategic_scene/status.rs';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';cur='95e63628f9d70b8dd6e6fede64334696c6995009';orig='1ac60dfc9e48db2d8717ff144d5b340d9f5cf2f9a158a8a7dcb1c966f17afdb4'
rows=[]
for id,rev,path in [('dirty-past',f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+orig),('current',cur,p)]:
 d=subprocess.check_output(['git','-C',pub,'show',rev+':'+path]);sha=hashlib.sha256(d).hexdigest();eof=len(d.splitlines()); fn='support/'+id+'-status.rs';(b/fn).parent.mkdir(exist_ok=True);(b/fn).write_bytes(d);chunks=[[1,120],[180,min(226,eof)]]
 rows.append({'id':id,'revision':rev,'git_path':path,'logical_project_path':p,'archive':fn,'sha256':sha,'bytes':len(d),'eof':eof,'prospective_read_ranges':chunks,'qualification':'Bounded independent support; f82 is transport for dirty pr-working original object, not project revision. Current is pinned project commit; no product execution.'})
out={'schema':'726-bevy-observer-support-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
