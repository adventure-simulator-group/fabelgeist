from pathlib import Path
import hashlib,json,tarfile
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();out=[]
for name,local,files,suffixes in [('p16-catalog-occupancy-surface','<LOCAL_PATH_1>',['MANIFEST.json','git-proofs.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774-compressed/additional-contracts.jsonl.gz'],['/source-range-registration.jsonl','/additional-contracts.jsonl']),('serde-tree-growth','<LOCAL_PATH_2>',['MANIFEST.json','git-proofs.json','historical-774/rig-findings.jsonl.gz'],['/findings.jsonl'])]:
 base=Path(local);p=pub/(name+'-evidence.tar.gz');blob=p.read_bytes();gp=json.load(open(base/'git-proofs.json'));oids=set()
 for suffix in suffixes:
  matches=[x for x in gp['paths'] if x['path'].endswith(suffix)];assert len(matches)==1;x=matches[0];oids.add(x['revision']);oids.update(y['tree'] for y in x['path_chain'])
 files+=sorted(gp['objects'][x]['preserved_bytes'] for x in oids);members=[]
 with tarfile.open(p,'r:gz') as t:
  for f in files:
   raw=t.extractfile(f).read();assert raw==(base/f).read_bytes();members.append({'member':f,'sha256':sha(raw),'bytes':len(raw)})
 out.append({'published_archive':str(p),'sha256':sha(blob),'bytes':len(blob),'local_original_bundle':local,'byte_identical_members':members,'qualification':'Only listed members checked. Other members may be public reconstructions; do not claim entire published archive matches original packet.'})
(b/'published-prior-packet-links.json').write_text(json.dumps({'schema':'726-gpu-reflection-published-prior-packets-v1','archives':out},indent=2)+'\n');print([(x['published_archive'],len(x['byte_identical_members'])) for x in out])
