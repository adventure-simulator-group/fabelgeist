from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',repo,*args])
objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();raw=gzip.decompress(raw) if body.endswith('.gz') else raw;cur=root(rev);chain=[]
 for segment in path.split('/'):
  mode,child=entries(save('tree',cur))[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
r=json.load(open(b/'registration.json'))
for x in r['roles']:
 if x['label']=='historical-f82':
  proof(x['revision'],x['transport_path'],x['archive'],'Original source transport, f82 is not historical project revision')
  if x['matches_6533_per_file']:proof('6533e444fa37552927070cc8d8190907fd3b413e',x['path'],x['archive'],'Per-file equality to recorded pr-working Git head; whole snapshot had unrelated modifications')
 else:proof(x['revision'],x['path'],x['archive'],'Pinned current project source')
for filename in ['support-registration.json','native-registration.json']:
 for x in json.load(open(b/filename))['entries']:
  if x['kind']!='pinned package support':proof(x['revision'],x['path'],x['archive'],'Separately read current support, no ordered credit')
for label,rev in [('historical','6533e444fa37552927070cc8d8190907fd3b413e'),('current','95e63628f9d70b8dd6e6fede64334696c6995009')]:proof(rev,'Cargo.lock',f'metadata/{label}-Cargo.lock.gz','Structured package selection only, no personal line-by-line read')
out={'schema':'726-gpu-reflection-git-proof-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Exact raw Git commit/tree memberships; historical source was transported by f82; original pr-working snapshot had unrelated modifications.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects))
