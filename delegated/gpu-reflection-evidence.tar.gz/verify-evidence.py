from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,sys,tarfile,tomllib
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads(Path(p).read_bytes());gun=lambda p:gzip.decompress(Path(p).read_bytes())
for x in load(b/'evidence-links.json')['links']:
 d=Path(x['path']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes'],x['path']
orig=json.loads(gun(pub/'recovered/original-registry-source-archive/registry.json.gz'));assert sha(gun(pub/'recovered/original-registry-source-archive/registry.json.gz'))=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';sel=load(b/'registry-selection-reconstructed.json')
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==orig['files'][x['original_index']]
for x in sel['snapshots']:assert x in orig['snapshots']
pr=next(x for x in orig['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
p16=next(x for x in orig['snapshots'] if x['id']=='physical-p16');assert p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256'] and recovery['recovered_patch']['bytes']==524542 and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7}
reg=load(b/'registration.json');su=load(b/'support-registration.json');nt=load(b/'native-registration.json');rec=load(b/'personal-read-receipt.json');report=load(b/'REPORT.json')
for x in reg['roles']:
 d=(b/x['archive']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes'] and len(d.splitlines())==x['eof']
 if x['label']=='historical-f82':
  z=orig['files'][x['role']];assert x['sha256']==z['sha256'] and x['original_material_ranges']==z['material_ranges'] and x['matches_6533_per_file'] and not x['recorded_pr_status_for_file'];assert not any(t[3:]==x['path'] for t in pr['status_porcelain'])
for i in [2632,2636]:assert (b/f'sources/{i}-historical-f82.rs').read_bytes()==(b/f'sources/{i}-current-95e.rs').read_bytes()
assert (b/'sources/2635-historical-f82.rs').read_bytes()!=(b/'sources/2635-current-95e.rs').read_bytes()
for x in su['entries']+nt['entries']:
 d=(b/x['archive']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes'] and len(d.splitlines())==x['eof']
 if x['kind']=='pinned package support':
  z=Path(x['package_archive']).read_bytes();assert sha(z)==x['package_sha256'];
  with tarfile.open(fileobj=io.BytesIO(z),mode='r:gz') as t:assert t.extractfile(x['member']).read()==d
for x in nt['structured_lock_metadata']:
 d=gun(b/f"metadata/{x['label']}-Cargo.lock.gz");assert sha(d)==x['lock_sha256'];pkgs=[p for p in tomllib.loads(d.decode())['package'] if p['name']=='wgpu-types'];assert pkgs==x['matching_packages'] and any(p['version']=='29.0.4' and p['checksum']==nt['entries'][1]['package_sha256'] for p in pkgs)
q=load(pub/'baseline-059/queue.json')['entries']
for x in load(b/'queue-selection-reconstructed.json')['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[370]['contract_id']=='SEGOVB-L12-GPU-REFLECTION-SPARSE-GROUP-LAYOUT-POSITION'
mi=json.loads(gun(pub/'recovered/original-transport-manifest.json.gz'));idx={x['path']:x for x in mi['entries']};at=load(b/'historical-attribution.json');assert len(at['missing'])==1 and not at['missing'][0]['exists'] and not at['missing'][0]['in_transport_manifest'] and 'Exploratory guessed' in at['missing'][0]['qualification']
for x in at['records_059']:
 d=(b/x['preserved_bytes']).read_bytes();m=idx[x['original_path']];assert sha(d)==x['sha256']==m['sha256'] and len(d)==x['bytes']==m['bytes'] and oid('blob',d)==x['git_blob']==m['git_blob']
for i,n in [(2632,430),(2635,431),(2636,431)]:
 l11=load(b/f'historical-059/segovb/READ-L11-{n}.json');x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==orig['files'][i]['material_ranges']
l12=load(b/'historical-059/segovb/READ-L12-905.json');x=next(x for x in l12['rows'] if x['original_index']==2632);assert x['fresh_personal_body_reads']==[[1,135]] and '/root/lens12_frontier' in x['attribution'] and l12['root_personal_rereads']==[]
conn=load(b/'historical-059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-749-SHADER-REFLECTION.json');later=load(b/'historical-059/segovb/READ-L12-907.json')
for i in (2635,2636):
 a=next(x for x in conn['rows'] if x['original_index']==i);z=next(x for x in later['rows'] if x['original_index']==i);assert a['fresh_personal_body_reads']==orig['files'][i]['material_ranges'] and z['fresh_personal_body_reads']==[] and '/root/lens12_frontier' in a['attribution'] and z['qualified_same_lens_reuse_ranges_and_exact_proofs']
assert later['root_personal_rereads']==[]
old=Path('<LOCAL_PATH_1>');lines=[json.loads(x) for x in (old/'historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl').read_bytes().splitlines()]
for i in [2632,2635,2636]:
 for x in orig['files'][i]['admission03_scope_observations']:assert lines[x['row_1based']-1]==x['original_record']
add=[json.loads(x) for x in gun(old/'historical-774-compressed/additional-contracts.jsonl.gz').splitlines()];assert {'RIG-ADMISSION03-ADDITIONAL-087','RIG-ADMISSION03-ADDITIONAL-090','RIG-ADMISSION03-ADDITIONAL-091'}<={x['id'] for x in add}
find=[json.loads(x) for x in gun('<LOCAL_PATH_2>').splitlines()];assert {'RIG-ADMISSION03-F057','RIG-ADMISSION03-F058'}<={x['id'] for x in find}
proof=load(b/'git-proofs.json');objs={}
for k,x in proof['objects'].items():
 d=gun(b/x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objs[k]=d
for rev,x in proof['commits'].items():assert objs[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
def check_paths(proof,objects,base,paths):
 for x in paths:
  cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
  for name,s in zip(parts,x['path_chain']):
   assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
  p=base/x['preserved_bytes'];d=gun(p) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
check_paths(proof,objs,b,proof['paths'])
# Prior frozen packets preserve raw f82 commit/tree objects for 774 record membership.
for base,suffixes in [(old,['/source-range-registration.jsonl','/additional-contracts.jsonl']),(Path('<LOCAL_PATH_3>'),['/findings.jsonl'])]:
 gp=load(base/'git-proofs.json');prev={}
 for k,x in gp['objects'].items():
  d=gun(base/x['preserved_bytes']);assert sha(d)==x['sha256'] and len(d)==x['bytes'] and oid(x['type'],d)==k;prev[k]=d
 wanted=[]
 for suffix in suffixes:
  choices=[p for p in gp['paths'] if p['path'].endswith(suffix)];assert len(choices)==1 and choices[0]['revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';wanted+=choices
 for rev,x in gp['commits'].items():assert prev[rev].splitlines()[0].split()[1].decode()==x['root_tree']
 check_paths(gp,prev,base,wanted)
# Exact selected prior records and raw f82 path-proof objects are recoverable from published packet members.
for packet in load(b/'published-prior-packet-links.json')['archives']:
 d=Path(packet['published_archive']).read_bytes();assert sha(d)==packet['sha256'] and len(d)==packet['bytes']
 with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
  for member in packet['byte_identical_members']:
   raw=t.extractfile(member['member']).read();assert sha(raw)==member['sha256'] and len(raw)==member['bytes'] and raw==(Path(packet['local_original_bundle'])/member['member']).read_bytes()
for x in rec['registrations']:
 d=(b/x['path']).read_bytes();assert sha(d)==x['sha256'] and datetime.fromisoformat(json.loads(d)['registered_utc'])<datetime.fromisoformat(rec['recorded_utc'])
scopes={}
for x in rec['reads']:
 data=(b/x['archive']).read_bytes();assert sha(data)==x['sha256'] and len(data.splitlines())==x['eof'];r=load(b/x['registration']);entries1=r.get('roles',r.get('entries'));hits=[v for v in entries1 if v['archive']==x['archive']];assert len(hits)==1 and hits[0]['sha256']==x['sha256'] and hits[0]['registered_ranges']==x['actual_display_ranges'];seen={i for a,z in x['actual_display_ranges'] for i in range(a,z+1)};chunks={i for a,z in x['actual_display_chunks'] for i in range(a,z+1)};other={i for a,z in x['unread_complement'] for i in range(a,z+1)};assert seen==chunks and not seen&other and seen|other==set(range(1,x['eof']+1));scopes.setdefault((x['archive'],x['sha256']),set()).update(seen)
assert len(rec['reads'])==14 and len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
def visit(x):
 if isinstance(x,dict):
  if all(k in x for k in ('archive','lines','sha256')):
   a,z=x['lines'];assert set(range(a,z+1))<=scopes[(x['archive'],x['sha256'])],x
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','counts':{'original_roles':3,'personal_read_entries':14,'raw_git_path_proofs':len(proof['paths']),'original_059_records':len(at['records_059']),'bounded_lens_perspectives':13},'checks':['Original registry, queue reconstructions, 059 receipts, historical supplier attribution, and exact f82 Git proofs','Independent 6533 and 95e per-file membership/differences and separately recovered P16 qualifications','Registered actual read partitions and source citations; Cargo-locked native source archive membership and project support','Evidence/source verification only; no product, GPU, shader, simulation, fixture, tests, build or runtime validation.']};raw=(json.dumps(result,indent=2)+'\n').encode()
if '--record' in sys.argv:(b/'evidence-verification.json').write_bytes(raw)
print('PASS',sha(raw),result['counts'])
