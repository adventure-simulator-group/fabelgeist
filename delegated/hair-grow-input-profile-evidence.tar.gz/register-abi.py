from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');g=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);sha=lambda d:hashlib.sha256(d).hexdigest();rev='95e63628f9d70b8dd6e6fede64334696c6995009'
def add(path,ranges,name):
 raw=g('show',rev+':'+path);eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in ranges),(path,eof,ranges);archive='support/'+name
 if (b/archive).exists():assert (b/archive).read_bytes()==raw
 else:(b/archive).write_bytes(raw)
 return {'kind':'current ABI/source support, no original credit','revision':rev,'path':path,'archive':archive,'git_blob':g('rev-parse',rev+':'+path).decode().strip(),'sha256':sha(raw),'bytes':len(raw),'eof':eof,'registered_ranges':ranges,'planned_chunks':[[x,min(x+69,z)] for a,z in ranges for x in range(a,z+1,70)]}
rows=[add('crates/fabelgeist-hair/src/gpu/grow.rs',[[1,35]],'grow.rs'),add('crates/fabelgeist-hair/src/gpu/guides.rs',[[1,80],[322,355]],'guides.rs'),add('crates/fabelgeist-gpu/src/data/gpu/parameters/mod.rs',[[1,42]],'parameters.rs'),add('crates/fabelgeist-gpu/src/data/gpu/parameters/parameter.rs',[[1,45],[105,129]],'parameter.rs'),add('crates/fabelgeist-compute/src/kernel/fast.rs',[[270,375]],'fast.rs'),add('crates/fabelgeist-compute/src/kernel/mod.rs',[[275,330]],'kernel.rs')]
x={'schema':'726-hair-grow-abi-support-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'Separate source-only trace of parameter construction and dispatch; helper, source and consumer support, no macro expansion or execution.'};(b/'abi-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('sha',sha((b/'abi-registration.json').read_bytes()));print(json.dumps(rows,indent=2))
