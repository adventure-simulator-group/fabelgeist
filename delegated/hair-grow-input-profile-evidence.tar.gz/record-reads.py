from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda x:hashlib.sha256(x).hexdigest();load=lambda p:json.loads((b/p).read_text());reads=[]
def complement(eof,rs):
 s={i for a,z in rs for i in range(a,z+1)};out=[]
 for i in sorted(set(range(1,eof+1))-s):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for fn,key in [('registration.json','roles'),('support-registration.json','entries'),('more-registration.json','entries'),('abi-registration.json','entries')]:
 for x in load(fn)[key]:
  rs=x['registered_ranges'];chunks=x.get('planned_chunks',rs)
  if x['archive']=='support/guides.rs':chunks=[[1,80],[322,355]]
  reads.append({'kind':x.get('kind','assigned historical/current source'),'role':x.get('role'),'archive':x['archive'],'sha256':x['sha256'],'revision':x['revision'],'eof':x['eof'],'registration':fn,'actual_display_ranges':rs,'actual_display_chunks':chunks,'unread_complement':complement(x['eof'],rs),'historical_original_material_ranges':x.get('original_material_ranges'),'qualification':'Displayed after registration without tool truncation. Full archived bytes beyond displayed ranges are not read credit; all support and other reviewers remain separate.'})
regs=[]
for f in ['registration.json','support-registration.json','more-registration.json','abi-registration.json']:
 d=(b/f).read_bytes();regs.append({'path':f,'sha256':sha(d),'registered_utc':json.loads(d)['registered_utc']})
out={'schema':'726-hair-grow-personal-reads-v1','author':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registrations':regs,'reads':reads};(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('entries',len(reads),'sha',sha((b/'personal-read-receipt.json').read_bytes()))
