from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');g=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);sha=lambda x:hashlib.sha256(x).hexdigest();rev='95e63628f9d70b8dd6e6fede64334696c6995009';out=[]
for path,rs,name in [('crates/fabelgeist-hair/src/rng.rs',[[112,155]],'rng.rs'),('crates/fabelgeist-hair/src/gpu/wgsl/common.rs',[[1,35]],'wgsl-common.rs')]:
 d=g('show',rev+':'+path);eof=len(d.splitlines());assert all(1<=a<=z<=eof for a,z in rs);archive='support/'+name;(b/archive).write_bytes(d);out.append({'kind':'separate random encoding support, source only','revision':rev,'path':path,'archive':archive,'git_blob':g('rev-parse',rev+':'+path).decode().strip(),'sha256':sha(d),'bytes':len(d),'eof':eof,'registered_ranges':rs,'planned_chunks':rs})
x={'schema':'726-hair-profile-random-support-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out,'qualification':'Source text only; no RNG or shader execution, no statistical or platform equivalence claim.'};(b/'rng-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(sha((b/'rng-registration.json').read_bytes()))
