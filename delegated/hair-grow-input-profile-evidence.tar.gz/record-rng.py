from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();raw=(b/'personal-read-receipt-initial.json').read_bytes();out=json.loads(raw);z=(b/'rng-registration.json').read_bytes();reg=json.loads(z);out['initial_receipt']={'path':'personal-read-receipt-initial.json','sha256':sha(raw)};out['recorded_utc']=datetime.now(timezone.utc).isoformat();out['registrations'].append({'path':'rng-registration.json','sha256':sha(z),'registered_utc':reg['registered_utc']})
for x in reg['entries']:
 a,last=x['registered_ranges'][0];complement=([[1,a-1]] if a>1 else [])+([[last+1,x['eof']]] if last<x['eof'] else []);out['reads'].append({'kind':x['kind'],'role':None,'archive':x['archive'],'sha256':x['sha256'],'revision':x['revision'],'eof':x['eof'],'registration':'rng-registration.json','actual_display_ranges':x['registered_ranges'],'actual_display_chunks':x['planned_chunks'],'unread_complement':complement,'historical_original_material_ranges':None,'qualification':'Prospectively registered independent current source support; no RNG, test, shader, or product execution. rng.rs 149–155 are test source only.'})
(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('entries',len(out['reads']),'sha',sha((b/'personal-read-receipt.json').read_bytes()))
