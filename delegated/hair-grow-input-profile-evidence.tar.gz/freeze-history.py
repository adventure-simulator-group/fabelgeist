from pathlib import Path
import gzip,hashlib,json
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');ex=Path('<LOCAL_PATH_1>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));mi=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in mi['entries']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-registry-reconstruction-v1','qualification':'Selected original registry rows and snapshot records, reconstructed; not a historical standalone record or checkpoint3821.','rows':[{'original_index':i,**r['files'][i]} for i in (2641,2642)],'snapshots':[x for x in r['snapshots'] if x['id'] in ('pr-working','physical-p16')]},indent=2)+'\n')
q=json.load(open(pub/'baseline-059/queue.json'))['entries'];ids=[160,163,373,1837,2331,3135];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-queue-reconstruction-v1','qualification':'Selected 059 queue rows reconstructed, keeping original revision, status and attribution. Related does not prove aliases or new counts.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in ids]},indent=2)+'\n')
paths=[f'segovb/{k}-L11-432.json' for k in ('READ','VERIFY','STATE')]+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in (1557,1558)]+[f'segovb/{k}-L12-911.json' for k in ('READ','VERIFY','STATE')]+['parallel-l12-20261029/PROPOSAL-L12-911.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-908-916.json']+[f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json' for i in (706,707)]+[f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{j}-ORIGINAL{i}.json' for i,j in [(2641,706),(2642,707)]]+[f'parallel-l12-20261029/PARTIAL-PAR-L12-911-00{i}.json' for i in (1,2)]
records=[];missing=[]
for path in paths:
 f=ex/path
 if not f.exists() or path not in idx:missing.append({'path':path,'exists':f.exists(),'in_transport_manifest':path in idx});continue
 raw=f.read_bytes();m=idx[path];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];dest=b/'historical-059'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);records.append({'original_path':path,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dest.relative_to(b))})
assert not missing,missing
links=[]
def link(p,origin,note):
 raw=p.read_bytes();links.append({'path':str(p),'sha256':sha(raw),'bytes':len(raw),'origin':origin,'qualification':note})
for p in ['recovered/original-registry-source-archive/registry.json.gz','recovered/original-transport-manifest.json.gz','baseline-059/queue.json','baseline-059/ledger.json','ASSESSMENT-HAIR-GPU-GROW-95E.json','ASSESSMENT-HAIR-GUIDES-95E.json','ASSESSMENT-HAIR-GPU-MODULE-95E.json','ASSESSMENT-HAIRDO-GROOM-95E.json','ASSESSMENT-GPU-BIND-BUFFER-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','recovered/physical-p16-patch-recovery/tracked.patch']:
 link(pub/p,'published recovered/current evidence','Own revision and prior source-read attribution preserved; no 3821 or read credit transfer.')
old=Path('<LOCAL_PATH_2>')
for p in ['MANIFEST.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774-compressed/additional-contracts.jsonl.gz','historical-774-compressed-attribution.json','git-proofs.json']:
 link(old/p,'prior frozen evidence packet','Original rig 774 records and f82 Git proof; preserve supplier and original ranges.')
old=Path('<LOCAL_PATH_3>')
for p in ['MANIFEST.json','historical-774/rig-findings.jsonl.gz','git-proofs.json']:
 link(old/p,'prior frozen evidence packet','Original F058 exact 774 finding and transport proof, not an automatic duplicate.')
(b/'historical-attribution.json').write_text(json.dumps({'schema':'726-hair-grow-historical-attribution-v1','records_059':records,'missing':missing,'qualification':'Original 774 supplier rig REGISTER097/098 and ADD097/098; 059 READ-L11-432 contains fresh personal ranges but no individual author name. /root/lens12_frontier personally read both ranges in READ-L12-911, root adoption no personal rereads. F058 is a separately attributed fast uniform writer finding. f82 is source transport; whole pr-working snapshot had unrelated modifications; P16/3821 are not promoted.'},indent=2)+'\n');(b/'evidence-links.json').write_text(json.dumps({'schema':'726-hair-grow-evidence-hash-links-v1','links':links},indent=2)+'\n');print('059 records',len(records),'missing',missing,'links',len(links))
