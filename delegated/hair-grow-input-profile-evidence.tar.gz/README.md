# Bounded hair GPU grow input and profile evidence

This packet records `/root/rig_identity`'s independent source-only review of
original roles 2641 and 2642 against their historical identities and pinned
project revision 95e. `REPORT.json` contains thirteen bounded perspectives,
source-level observations and nonfindings, connections to historical/current
contracts, and remaining policy and reachability questions. It does not grant a
whole-lens verdict or product validation.

`registration.json` preceded the separately displayed historical and current
bodies. Other registrations cover bounded independent caller, parameter,
reflection, buffer and shader-source support; `personal-read-receipt.json`
records exact displayed ranges and complements. Full archived source beyond
those ranges is not read credit. Earlier attribution and revisions remain
separate. The recorded pr-working snapshot had unrelated modifications; f82
is original source transport, not a product revision.

`historical-059/` contains exact original bytes checked against the published
transport manifest; registry and queue selections are reconstructed and labeled.
Original 774 records and Git transport proofs are hash-linked to prior packets;
`published-prior-packet-links.json` confirms byte-identical selected members and
raw proof objects in earlier published bundles. Other published members may be
reconstructed and are not claimed exact. The dirty P16 snapshot and its later
patch recovery do not establish checkpoint 3821.

Run `python3 verify-evidence.py` then `python3 verify-manifest.py` for evidence
checks only. The former requires the hash-linked earlier packets and published
baseline at recorded absolute paths; retain or rebase those dependencies for
archival recovery. No GPU, shader, RNG, simulation, fixture, build, product,
test or runtime probe is run by either verifier.
