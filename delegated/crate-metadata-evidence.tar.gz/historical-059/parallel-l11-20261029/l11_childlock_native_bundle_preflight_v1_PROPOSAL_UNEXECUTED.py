"""Read-only exact child-crate-lock native bundle adapter; zero authority writes."""
import argparse,hashlib,json,pathlib,subprocess,runpy,tarfile,tomllib
R=pathlib.Path('target/726-audit-adler-20261027');O=R/'parallel-l11-20261029';REV='e2755a732c84e67296b5e3441a4259a84f461b2f';D=O/'native-childlock-rawzip-192-20261030'
LIB=O/'l11_firstparty_bundle_preflight_v1_PROPOSAL_UNEXECUTED.py';assert hashlib.sha256(LIB.read_bytes()).hexdigest()=='20577da89668140032aeac03763b86ed16bf7214f1f421d30a6bb302e15ec40c';lib=runpy.run_path(str(LIB),run_name='l11_firstparty_proof_library');sha=lib['sha'];packed=lib['packed'];ref=lib['ref'];ptr=lib['ptr'];valid=lib['valid'];inc=lib['inc'];holes=lib['holes']
EXPECTED={172:('db276e2f05b52ed5743d4d10003425a12db3961ca2848d2ffbd1817806e096b3','772520ce479a391541e3dd6ce9ff50407abaa34c4190665ca93a6f27570d90d0'),173:('05bcf8ddeee92125aa0d937c79efab3d1be36f69f3ce375fb94a8db9ef711013','67fc032ba1daaf62c3e84c3d1d7aa6d36af99cfdf3d1520bea82109ff718c0a7'),174:('59ccea27c797a6aacd77516b8ee5e7153e3911601b762d7242497d291f9642e7','2d0b75aa7c6398bf7a5fa4f710645c74a010f942c55577a7f66905f5434d6df9'),175:('2c494c528e902dc40937cd364d4ba5c0272df5f91cf19ed191259312fdc6b596','4a7dc27ae4c773efed4d374f689cc229bca059579c7b7f2fdbe3bf10ec7864bb'),176:('e804b4bcdc3c56e93e54cc608dc1f5554281fdc5fa99b82e54153fe598b46a34','bf5882cef0bfad717633544e05e9d25ca7cd25bc1ba75e71473d75df02a5923b')}
PLANS={192:'7403fb94a95705179bc0c790ea76fce67a228a27c60b67bfb2aa03fb2fdb1799',193:'c2f71ed0a54c4f6c6390d27574d6330aa22a2b97923b32d2f4083ce9373f0795',194:'09d3a9a82427cb20add5becf570e20f97514dab7621272f291e2445a820ffbd6'}
LOCKPATH='crates/fabelgeist-numpy-storage/Cargo.lock';CRATESHA='ac9999039f74cd73c03158cddfe4362991703c74efe5ce5c8073026f80a5e48c'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preflight',required=True,action='store_true');ap.add_argument('--bundle',required=True);ap.add_argument('--expected-sha256',required=True);a=ap.parse_args();bp=pathlib.Path(a.bundle);assert bp.is_relative_to(O) and sha(bp)==a.expected_sha256;b=json.loads(bp.read_text());pj=json.loads(ref(b['protocol']).read_text());assert b['protocol']['sha256']=='8fa2ba016a32b9e4b9624cdd0c1ae02d61a956f7dda4948f30fd89d8387b34ed' and all(k in b for k in pj['required_bundle_fields']);assert b['lens']==11 and b['schema']=='726-proposal-bundle-v1' and not b['product_execution'] and not b['implementation_gate_complete'] and ref(b['validation_ruleset']).resolve()==pathlib.Path(__file__).resolve()
 snap=b['base_authority_snapshot'];lp=pathlib.Path(snap['ledger']['path']);cp=pathlib.Path(snap['selector']['path']);lb,cb=lp.read_bytes(),cp.read_bytes();current=json.loads(cb);assert current['ledger_sha256']==hashlib.sha256(lb).hexdigest() and current['current_main_pin']==REV and not current['implementation_gate_complete']
 if sha(lp)==snap['ledger']['sha256']:base=json.loads(lb);assert sha(cp)==snap['selector']['sha256']
 else:
  hist=json.loads((R/'checkpoint-history'/(snap['ledger']['sha256']+'.json')).read_text());base=hist['ledger'];bc=hist['current'];assert hashlib.sha256(packed(base)).hexdigest()==snap['ledger']['sha256']==bc['ledger_sha256'] and hashlib.sha256(packed(bc)).hexdigest()==snap['selector']['sha256']
 queue=json.loads(ref(snap['closure_queue']).read_text());assert len(b['immutable_proposals'])==8 and all(v==0 for v in b['population_deltas_separate'].values()) and b['ordered_frontier_before']==b['ordered_frontier_after'];assert b['current_delta_updates']==[]
 adoptions={}
 for ar in base['segovb_continuation']['parallel_l11_adoptions']:
  rp=R/ar['path'];assert sha(rp)==ar['sha256'];aj=json.loads(rp.read_text());adoptions[(aj['proposal'],aj['proposal_sha256'])]=(ar,aj)
 regs={}
 for n,digest in PLANS.items():
  pp=O/f'PLAN-{n:03}.json';assert sha(pp)==digest;p=json.loads(pp.read_text());assert p['lens']==11 and p['revision']==REV
  for i,g in enumerate(p['rows']):assert g['registration'] not in regs;regs[g['registration']]=(pp,i,g)
 assert {(z['path'],z['sha256']) for z in b['new_prospective_registration_proofs']}=={(str(O/f'PLAN-{n:03}.json'),v) for n,v in PLANS.items()}
 assert [pathlib.Path(z['receipt']['path']).name for z in b['source_receipt_adoption_order']]==[f'READ-{n:03}.json' for n in EXPECTED]
 newrows={};readjs={}
 for pair in b['source_receipt_adoption_order']:
  rp=ref(pair['receipt']);vp=ref(pair['verify']);n=int(rp.stem.split('-')[1]);assert (sha(rp),sha(vp))==EXPECTED[n];j=json.loads(rp.read_text());v=json.loads(vp.read_text());assert v['receipt']==pair['receipt'] and j['lens']==11 and j['revision']==REV and not j['implementation_gate_complete'] and all(x==0 for x in j['population_credit'].values());readjs[n]=j;done=set()
  for z in j['rows']:
   pp,i,g=regs[z['registration']];assert all(g[k]==z[k] for k in g) and z['assessed_ranges']==z['fresh_personal_body_ranges']==g['prospective_ranges'];assert z['registration'] not in newrows;newrows[z['registration']]=z;done.add(z['registration'])
  for pr in j.get('exact_prior_completed_scopes',[]):
   prior=ref(pr);pn=int(prior.stem.split('-')[1]);assert pn<n and pn in readjs
   for z in readjs[pn]['rows']:
    if any(z['registration']==g['registration'] for g in json.loads(ref(j['plans'][0]).read_text())['rows']):done.add(z['registration'])
  expected_unread=[{'registration':g['registration'],'source_id':g['source_id'],'revision':g['revision'],'path':g['path'],'sha256':g['sha256'],'actual_EOF':g['actual_EOF'],'registered_unread_ranges':g['prospective_ranges']} for g in json.loads(ref(j['plans'][0]).read_text())['rows'] if g['registration'] not in done];assert j['registered_unread_sources_at_packet']==expected_unread
 assert len(newrows)==11 and set(newrows)==set(regs) and readjs[175]['registered_unread_sources_at_packet']==readjs[176]['registered_unread_sources_at_packet']==[]
 locks=subprocess.check_output(['git','show',REV+':'+LOCKPATH]);pkg=next(x for x in tomllib.loads(locks.decode())['package'] if x['name']=='rawzip' and x['version']=='0.5.2');assert pkg['checksum']==CRATESHA and pkg['source']=='registry+https://github.com/rust-lang/crates.io-index';arc=D/'rawzip-0.5.2.crate';assert sha(arc)==CRATESHA;provenance=D/'MATERIAL-PROVENANCE.json';assert sha(provenance)=='9ac61e4662557982f20674838b8a70fc9c09b40c98f60476ece10d94583ffc9d';prov=json.loads(provenance.read_text());assert prov['own_lock_path']==LOCKPATH and prov['own_lock_revision']==REV and prov['own_lock_sha256']==hashlib.sha256(locks).hexdigest() and prov['archive_sha256']==CRATESHA and prov['new_source_body_credit']==0 and prov['product_execution'] is False
 source_rows={};allplanrefs=set()
 for sr in b['exact_source_read_rows']:
  assert all(k in sr for k in pj['source_row_required_fields']);rp=ref(sr['body_receipt']);j=json.loads(rp.read_text());n=int(rp.stem.split('-')[1]);z=ptr(j,sr['receipt_pointer']);assert z==sr['preserved_exact_source_row'] and j['lens']==11 and j['revision']==REV and z['lens']==11;pr=sr['registration_ref_and_sha256'];pp=ref(pr);g=ptr(json.loads(pp.read_text()),pr['json_pointer']);assert all(z[k]==g[k] for k in g) and any(x['path']==str(pp) and x['sha256']==sha(pp) for x in j['plans']);allplanrefs.add((str(pp),sha(pp)));valid(z['assessed_ranges'],z['actual_EOF']);assert z['assessed_ranges']==z['fresh_personal_body_ranges']==z['prospective_ranges']
  if z.get('kind')=='native-exact-child-crate-lock-restored-member':
   assert n in EXPECTED and z['current_product_lock_path']==LOCKPATH and z['current_product_lock_revision']==REV and z['lock_sha256']==hashlib.sha256(locks).hexdigest() and z['revision']=='crates.io rawzip0.5.2 pinned current e275 fabelgeist-numpy-storage/Cargo.lock'
   lr=regs[z['lock_registration']][2];assert lr['path']==LOCKPATH and lr['revision']==REV and lr['sha256']==z['lock_sha256'];assert inc(lr['prospective_ranges'],[[4304,4308]])
   rel=z['archive_member'].removeprefix('rawzip-0.5.2/');assert rel in ['src/locator.rs','src/archive.rs','src/headers.rs','src/errors.rs','src/extra_fields.rs'];local=D/'rawzip-0.5.2'/rel;assert z['path']==z['local_path']==str(local) and z['archive']==str(arc) and z['archive_sha256']==z['locked_package_checksum']==CRATESHA and z['exact_archive_member_matches_local'] is True and ref(z['restoration_provenance'])==provenance;data=local.read_bytes()
   with tarfile.open(arc,'r:gz') as tf:assert tf.extractfile(z['archive_member']).read()==data
  else:assert z['revision']==REV and not pathlib.Path(z['path']).is_absolute();data=subprocess.check_output(['git','show',REV+':'+z['path']])
  assert hashlib.sha256(data).hexdigest()==z['sha256'] and len(data.splitlines())==z['actual_EOF']
  if n in EXPECTED:assert sr['root_adoption_pending'] is True and newrows[z['registration']]==z and sr['qualified_same_lens_reuse_ranges_and_exact_proofs']=={'ranges':[],'proofs':[]}
  else:
   assert n in [11,170,171];ar,aj=adoptions[(str(rp.relative_to(R)),sha(rp))];assert sr['root_adoption']==ar and sr['root_adoption_pending'] is False and aj['actual_current_target']==REV;az=next(x for x in aj['rows'] if x['registration']==z['registration']);assert all(az[k]==z[k] for k in ['source_id','path','revision','sha256','actual_EOF','assessed_ranges']);assert sr['qualified_same_lens_reuse_ranges_and_exact_proofs']=={'ranges':z['assessed_ranges'],'proofs':[{'body_receipt':sr['body_receipt'],'receipt_pointer':sr['receipt_pointer'],'root_adoption':ar}]}
  assert sr['source_id']==z['source_id'] and sr['revision_or_explicit_transport_qualification']==z['revision'] and sr['source_sha256']==z['sha256'] and sr['actual_EOF_or_visual_contract']==z['actual_EOF'] and sr['requested_ranges']==z['prospective_ranges'] and sr['assessed_ranges']==z['assessed_ranges'] and sr['fresh_personal_ranges']==(z['fresh_personal_body_ranges'] if n in EXPECTED else []) and sr['read_attribution']==z['attribution'];assert sr['unread_ranges']==holes(z['assessed_ranges'],z['actual_EOF']) and sr['complete_relevant_functions_and_dependencies'] and sr['body_output_truncation_status']['all_contributing_body_outputs_untruncated'] is True;assert sr['source_row_key'] not in source_rows;source_rows[sr['source_row_key']]=sr
 assert {(z['path'],z['sha256']) for z in b['prospective_registration_proofs']}==allplanrefs
 updates=[]
 for rf in b['immutable_proposals']:
  p=json.loads(ref(rf).read_text());assert all(k in p for k in pj['contract_update_required_fields']) and p['lens']==11 and not p['authority_mutation'] and not p['implementation_gate_complete'] and p['closure_is_not_repair_or_runtime'] is True and p['existing_contract_revisit_identity_proof_if_any'] is None and p['contract_id_or_proposed_new_id'].startswith('REVIEW-L11-')
  for e in p['exact_source_identities_and_assessed_ranges']:
   sr=source_rows[e['source_row_key']];assert all(e[k]==sr[k] for k in ['source_id','revision_or_explicit_transport_qualification','source_sha256','assessed_ranges','receipt_pointer','read_attribution']);valid(e['contract_relevant_ranges'],sr['actual_EOF_or_visual_contract']);assert inc(sr['assessed_ranges'],e['contract_relevant_ranges'])
  assert p['closure_condition'] and p['dependencies'];updates.append(p)
 assert b['contract_updates']==updates and len({p['contract_id_or_proposed_new_id'] for p in updates})==8
 assert lp.read_bytes()==lb and cp.read_bytes()==cb
 print(json.dumps({'bundle':str(bp),'sha256':sha(bp),'new_source_receipts':5,'new_source_views':11,'source_rows_total':len(source_rows),'contracts':8,'own_child_lock':LOCKPATH,'archive_sha256':CRATESHA,'authority_mutation':False,'product_execution':False,'implementation_gate_complete':False,'current_ledger_sha256':hashlib.sha256(lb).hexdigest(),'current_selector_sha256':hashlib.sha256(cb).hexdigest()}))
if __name__=='__main__':main()
