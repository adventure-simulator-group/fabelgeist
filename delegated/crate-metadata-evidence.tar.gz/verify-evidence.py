import gzip,hashlib,json,pathlib,tarfile
b=pathlib.Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda kind,d:hashlib.sha1(kind.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();report=json.loads((b/'REPORT.json').read_bytes());h=json.loads((b/'history-manifest.json').read_bytes());tm=(b/'original-transport-manifest.json.gz').read_bytes();m=json.loads(gzip.decompress(tm));idx={e['path']:e for e in m['entries']};assert sha(tm)==h['original_transport_manifest_sha256']
for e in h['original_059_records']:
 d=(b/e['preserved_bytes']).read_bytes();want=idx[e['original_path']];assert len(d)==e['bytes']==want['bytes'] and sha(d)==e['sha256']==want['sha256'] and oid('blob',d)==e['git_blob']==want['git_blob'],e['original_path']
for e in h['older_774_receipts']:
 d=(b/e['preserved_bytes']).read_bytes();assert len(d)==e['bytes'] and sha(d)==e['sha256'] and oid('blob',d)==e['git_blob']
for name in ['registration.json','support-registration.json','support-registration-2.json','historical-support-registration.json','historical-support-6533-registration.json']:
 raw=(b/name).read_bytes();assert sha(raw)==report['registrations'][name]['sha256'];reg=json.loads(raw)
 for e in reg['entries']:
  if name=='registration.json':p=b/'sources'/e['revision'][:4]/e['path']
  elif name=='historical-support-registration.json':p=b/'historical-support'/e['path']
  elif name=='historical-support-6533-registration.json':p=b/'historical-support-6533'/e['path']
  else:p=b/'support'/e['path']
  d=p.read_bytes();assert len(d)==e['bytes'] and sha(d)==e['sha256'] and oid('blob',d)==e['git_blob'],e['path']
for e in report['original_roles']:
 a=(b/e['current_source']).read_bytes();c=(b/e['historical_source']).read_bytes();assert sha(a)==e['current_sha256'] and sha(c)==e['historical_sha256'] and (a==c)==e['byte_identical']
expected={'queue':'2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08','ledger':'3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac'}
for name,digest in expected.items():assert sha(gzip.decompress((b/('original-059-'+name+'.json.gz')).read_bytes()))==digest
selection=json.loads((b/'registry-selection-reconstructed.json').read_bytes());regzip=(b/selection['exact_registry_gzip']).read_bytes();assert sha(regzip)==selection['exact_registry_gzip_sha256'];registry=json.loads(gzip.decompress(regzip))
for i,row in zip([2326,2330,2331,2339,2347,2348],selection['rows']):assert row['original_index']==i and {k:v for k,v in row.items() if k!='original_index'}==registry['files'][i]
proof=json.loads((b/'git-proofs.json').read_bytes());objects={}
for k,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==k;objects[k]=raw
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
older={e['transport_path']:e for e in h['older_774_receipts']}
for e in proof['paths']:
 c=proof['commits'][e['revision']];assert objects[c['commit_object']].splitlines()[0]==b'tree '+c['root_tree'].encode();current=c['root_tree']
 for link in e['path_chain']:
  assert link['tree']==current;mode,child=entries(objects[current])[link['name']];assert mode==link['mode'] and child==link['object'];current=child
 assert current==e['git_blob'] and '/'.join(link['name'] for link in e['path_chain'])==e['path']
 kind=e['kind'];p=e['path']
 if kind=='original role':d=(b/'sources'/e['revision'][:4]/p).read_bytes()
 elif kind=='bounded current support':d=(b/'support'/p).read_bytes()
 elif kind=='bounded historical support':d=(b/('historical-support' if e['revision'].startswith('e275') else 'historical-support-6533')/p).read_bytes()
 elif kind=='older historical 774 transport record':d=(b/older[p]['preserved_bytes']).read_bytes()
 else:raise AssertionError(kind)
 assert len(d)==e['bytes'] and sha(d)==e['sha256'] and oid('blob',d)==e['git_blob']
base=b/'historical-059/parallel-l11-20261029/native-childlock-rawzip-192-20261030';archive=base/'rawzip-0.5.2.crate';assert sha(archive.read_bytes())=='ac9999039f74cd73c03158cddfe4362991703c74efe5ce5c8073026f80a5e48c'
with tarfile.open(archive,'r:gz') as tf:
 for n in ['locator.rs','archive.rs','headers.rs','errors.rs','extra_fields.rs']:
  m=tf.extractfile('rawzip-0.5.2/src/'+n);assert m and m.read()==(base/'rawzip-0.5.2/src'/n).read_bytes()
assert (b/'historical-support/crates/fabelgeist-numpy-storage/Cargo.lock').read_bytes()==(b/'support/crates/fabelgeist-numpy-storage/Cargo.lock').read_bytes()
assert not h['unavailable_original_records'] and len(report['thirteen_lens_dispositions'])==13
print('Evidence integrity passed:',len(h['original_059_records']),'exact original 059 records including archive/member bytes,',len(h['older_774_receipts']),'earlier 774 originals/variants,',len(proof['paths']),'Git paths and',len(proof['objects']),'raw commit/tree objects; registered source revisions, child-lock relation, registry selection and 059 queue/ledger verified. No product tests or probes.')
