from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
b=Path(__file__).resolve().parent
chunks={'sources/2710-pr_head.rs':[[1,50]],'sources/2710-current.rs':[[1,50]],'support/disease.source':[[125,148],[172,185],[210,242],[1695,1740],[2050,2100],[2140,2200],[2201,2265],[2396,2405],[2474,2498],[2614,2626]],'support/physiology.source':[[1,50],[51,100],[470,500],[648,685],[686,716]],'support/identifiers.source':[[1,25]],'support/adapter.source':[[1,27]],'support/calendar.source':[[89,122],[123,155]],'support/web-medical.source':[[85,123],[203,220]],'support/calendar-head.source':[[1,22]],'support/bootstrap.source':[[300,335],[395,430]],'support/medical-active.source':[[1,28]],'support/disease-stop.source':[[475,525],[2266,2305]],'support/medical-route.source':[[707,740],[741,773]],'support/physiology-tail.source':[[717,730]]};rows=[]
for reg in ('registration.json','support-registration.json','extra-registration.json','stop-registration.json'):
 r=json.loads((b/reg).read_bytes())
 for e in r['entries']:
  c=chunks[e['archive']];actual={i for a,z in c for i in range(a,z+1)};planned={i for a,z in e['prospective_personal_read_ranges'] for i in range(a,z+1)};assert actual==planned;unread=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in actual and start is None:start=i
   if start is not None and (i>e['eof'] or i in actual):unread.append([start,i-1]);start=None
  rows.append({'registration':reg,'registration_sha256':hashlib.sha256((b/reg).read_bytes()).hexdigest(),'registration_at_utc':r['at_utc'],'archive':e['archive'],'revision':e['revision'],'git_path':e['git_path'],'sha256':e['sha256'],'eof':e['eof'],'actual_personal_display_chunks':c,'unread_complement':unread,'reader':'/root/rig_identity','qualification':'source text displayed after prospective registration, separate from other reviewers and fixture/database execution'})
out={'schema':'726-personal-source-read-receipt-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'recording time not per-display timestamp; assigned old/current bodies read separately; no parsing, construction, validation or execution of fixture/database code'};(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('read scopes',len(rows))
