from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json');receipt=load('personal-read-receipt.json')
names=('registration.json','support-registration.json','extra-registration.json','stop-registration.json');groups={n:load(n) for n in names};allregs={(name,e['archive']):e for name,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('historical/registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('historical/transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[1093,1094,2710]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4 and pr['patch_sha256']=='dba7a85bb2105ccdf0587c4713fdc2a33b374600457f5c05e9c5f29d087193b1'
for r in groups.values():
 for x in r['entries']:
  d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
old,cur=groups['registration.json']['entries'];assert old['sha256']==cur['sha256']==registry['files'][2710]['sha256'] and old['eof']==cur['eof']==50 and old['prospective_personal_read_ranges']==registry['files'][2710]['material_ranges']==[[1,50]] and (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes()
queue=json.loads(gun('historical/baseline-059-queue.json.gz'))['entries'];q=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in q['entries']]==[179,193,198,459,890,915,970,1863,1873,1887]
for x in q['entries']:assert x['entry']==queue[x['original_index_zero_based']]
assert queue[459]['contract_id']=='SEGOVB-L12-CONNECTED-MEDICAL-BACKEND-DOSE-ADMISSION' and queue[915]['contract_id']=='Q-L12-930d3b253c48e556a206'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
ordered=load('historical/059/segovb/READ-L11-442.json');e=next(x for x in ordered['sources'] if x['original_index']==2710);assert e['fresh_personal_body_reads']==[[1,50]] and e['assessed_ranges']==[[1,50]]
shared=load('historical/059/segovb/READ-L11-520.json');e=next(x for x in shared['rows'] if x.get('shared_index')==158);assert e['fresh_personal_body_reads']==[[1,50]] and e['same_lens_reuse']==[]
later=load('historical/059/segovb/READ-L11-580.json');e=next(x for x in later['rows'] if x.get('path','').endswith('disease/fixture_administrations.rs'));assert e['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and e['fresh_personal_body_ranges']==[] and e['inherited_lens11_body_reuse'] is True
l12=load('historical/059/segovb/READ-L12-235.json');assert l12['inherited_disease1093_read_qualification_unchanged'] is True and next(x for x in l12['rows'] if x['original_index']==1094)['fresh_personal_body_reads']==[[1,27]]
handoff=load('historical/059/CURRENT-ADLER.json');q12=next(x for x in handoff['frontiers'] if x['lens']==12)['qualification'];assert all(z in q12 for z in ('1..1200','1201..1800','1801..2950','not separately transported'))
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
regs=[json.loads(z) for z in gun('historical/774/rig/admission03/source-range-registration.jsonl.gz').splitlines()];norms={x['registration_id']:x for x in map(json.loads,gun('historical/774/rig/admission03/source-qualifications-final-current.jsonl.gz').splitlines())}
for x in registry['files'][2710]['admission03_scope_observations']:
 assert regs[x['row_1based']-1]==x['original_record']
 for y in x['local_qualifications']:assert norms[y['registration_id']]==y
clinical=json.loads(gun('historical/774/rig/admission03/native20-support/clinical-admission-001.json.gz'));assert clinical['id']=='RIG-NATIVE20-ADM03-CLINICAL-001' and clinical['exact_join']['additional_actual_source']['actual_read_ranges']==[[1,50]]
findings=[json.loads(z) for z in gun('historical/774/root/admission03/camera-support-extra40/findings.jsonl.gz').splitlines()];assert any(x['id']=='ROOT-CAMERA-EXTRA40-ADM03-F005' for x in findings)
x=history['prior_web_medical'];d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
 names={e.name for e in t.getmembers() if e.isfile()};raw=t.extractfile(x['manifest_name']).read();assert sha(raw)==x['manifest_sha256'];manifest=json.loads(raw);assert names=={e['path'] for e in manifest['files']}|{x['manifest_name']}
 for e in manifest['files']:
  raw=t.extractfile(e['path']).read();assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
 assert sha(t.extractfile(x['report_name']).read())==x['report_sha256']
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==25
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
assert len(receipt['entries'])==len(allregs)==14;cover={}
for e in receipt['entries']:
 source=allregs[(e['registration'],e['archive'])];rr=groups[e['registration']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']) and e['registration_sha256']==sha((b/e['registration']).read_bytes()) and e['sha256']==source['sha256']
 actual={i for a,z in e['actual_personal_display_chunks'] for i in range(a,z+1)};planned={i for a,z in source['prospective_personal_read_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(unread) and actual|unread==set(range(1,source['eof']+1));cover[(e['archive'],e['revision'])]=actual
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   possible=[e for e in allregs.values() if e['archive']==x['archive'] and e['revision']==x['revision']];assert possible and x['sha256']==possible[0]['sha256'] and x['git_path']==possible[0]['git_path'];assert all(set(range(a,z+1))<=cover[(x['archive'],x['revision'])] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','registered_personal_read_scopes':len(receipt['entries']),'historical_059_records_manifest_matched':len(history['records_059']),'historical_774_records_git_path_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'prior_full_medical_packet_verified':True,'bounded_lenses':len(report['thirteen_lens_dispositions']),'historic_059_payload_git_path_proof':'not available in inspected publication and project object databases; selected exact records match original recovered transport manifest','fixture_or_product_validation':'not performed'},indent=2))
