from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
for x in json.loads((b/'registration.json').read_bytes())['entries']:
 proof(x['revision'],x['git_path'],x['archive'],x['qualification'])
 if x['kind']=='pr_head':proof(x['transport_revision'],x['transport_path'],x['archive'],'f82 transports exact historic object; pr-working snapshot recorded unrelated modifications')
proof('e2755a732c84e67296b5e3441a4259a84f461b2f','crates/adventuresim-stdb-module/src/disease/fixture_administrations.rs','sources/2710-pr_head.rs','prior e275 L11 same-lens reuse equality proof; no personal e275 source read or current verdict transfer')
for f in ('support-registration.json','extra-registration.json','stop-registration.json'):
 for x in json.loads((b/f).read_bytes())['entries']:proof(x['revision'],x['git_path'],x['archive'],x['qualification'])
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(x['revision'],x['transport_path'],x['preserved'],'exact original 774 record transported at f82, original reviewer retained')
out={'schema':'726-disease-fixture-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Commit/tree paths prove file identity only. f82 transports historical records; pr-working remains dirty. e275 identity relates prior inherited proof, not fresh personal read.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('git paths',len(proofs),'objects',len(objects))
