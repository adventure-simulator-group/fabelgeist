from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';items=[('disease-stop','crates/adventuresim-stdb-module/src/disease.rs',[[475,525],[2266,2305]]),('medical-route','crates/strategic-web/src/routes/settlements/party/inventory_medical.rs',[[707,773]]),('physiology-tail','crates/adventuresim-core/src/physiology.rs',[[717,730]])];rows=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);n=len(raw.splitlines());assert all(1<=a<=z<=n for a,z in ranges),(name,n);dest=f'support/{name}.source';(b/dest).write_bytes(raw);rows.append({'name':name,'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'eof':n,'prospective_personal_read_ranges':ranges,'qualification':'additional independent bounded current source text, no fixture execution or prior reviewer credit'})
out={'schema':'726-prospective-support-registration-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows};(b/'stop-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
