# Role 2710: disease administration fixture source

This packet is a bounded source-text audit. `REPORT.json` records the assigned
historical/current source identities, thirteen scoped perspectives, existing
clinical findings, conditional chronology questions and outstanding evidence.
It does not validate fixture content or product behavior.

The role's historical source object and the 95e source are byte-identical;
the whole recorded pr-working snapshot had unrelated modifications. The
historical body matches both the 6533 per-file object and the original f82
transport object. `git-proofs.json` contains the project and transport path
proofs, and `personal-read-receipt.json` records source displays made after
prospective registration. The 50-line historical and current bodies were
displayed separately.

The original 774 Rig and 059 SEGOVB Lens 11 records retain their read scopes;
the later e275 same-lens reuse is not a fresh e275 read. The historical Lens 12
disease1093 qualification remains precise: inherited 1–1200, checkpoint
attestation 1201–1800 whose raw predecessor outputs were not separately
transported, and new personal 1801–2950. Earlier evidence is not promoted to
checkpoint 3821. Reconstructed registry and queue selections are labeled.

The prior complete medical-route packet is preserved with its manifest and
original author and peer scopes. Full original 059 registry/transport manifest
and selected exact 059 records are also retained. The 059 payload Git commit
was absent from the inspected publication and project object databases, so
the selected receipt bytes are checked against the recovered manifest rather
than independently Git-path-proved.

Run evidence-only verification from this directory:

```
python3 verify-evidence.py
python3 verify-manifest.py
```

The checks verify preserved evidence bytes, metadata, Git paths, read scopes
and report citations. No fixture or database code was constructed, parsed,
validated, invoked or executed. No repairs, product builds, tests, browser,
runtime probes or product validation occurred. Central owns the baseline,
alias reconciliation, connected repair ledger and checkpoint publication.
