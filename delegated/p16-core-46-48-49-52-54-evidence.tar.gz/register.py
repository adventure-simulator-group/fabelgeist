import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent
pub=pathlib.Path('<LOCAL_PATH_0>')
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
git=lambda *a:subprocess.run(['git','-C',str(pub),*a],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
reg=json.loads(gzip.decompress((pub/'recovered/original-registry-source-archive/registry.json.gz').read_bytes()))
base='a120390947c89b703dc74c4255a13c035d054c50';cur='95e63628f9d70b8dd6e6fede64334696c6995009';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
out=[];comparisons=[];rows=[]
for i in (46,48,49,52,54):
 row=reg['files'][i];rows.append({'original_index':i,'row':row});path=row['source_id'].split(':',1)[1];tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];q=git('show',f82+':'+tp);assert q.returncode==0;old=q.stdout;assert sha(old)==row['sha256'];assert row.get('bytes',len(old))==len(old);assert row.get('actual_line_count',len(old.splitlines()))==len(old.splitlines())
 versions={}; currents=None
 for label,rev in [('base',base),('current',cur)]:
  q=git('show',rev+':'+path)
  versions[label]={'revision':rev,'present':q.returncode==0,'git_status':q.returncode,'git_stderr':q.stderr.decode().strip() if q.returncode else None}
  if q.returncode==0:
   b=q.stdout;versions[label].update({'sha256':sha(b),'git_blob':blob(b),'equals_archived':b==old,'lines':len(b.splitlines())});
   if label=='current': currents=b
 comparisons.append({'original_index':i,'versions':versions,'qualification':'Original physical-p16 bytes are a dirty working snapshot. Base equality is per file only; tracked patch excludes separately archived untracked files. f82 is evidence transport.'})
 for label,rev,b in [('historical',None,old),('current',cur,currents)]:
  if b is None:continue
  f=f'source/{i}-{label}.rs';(p/f).write_bytes(b);n=len(b.splitlines());out.append({'original_index':i,'source_id':row['source_id'],'snapshot':row['snapshot'],'label':label,'revision':rev,'path':path,'archive':f,'sha256':sha(b),'git_blob':blob(b),'bytes':len(b),'EOF':n,'registered_ranges':[[1,n]],'transport_path':tp if label=='historical' else None})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':out,'comparisons':comparisons,'qualification':'Prospective personally displayed full-body registrations, independently for old and current. A registered range is not a read until an actual displayed receipt. Original physical-p16 is dirty; original tracked patch excludes seven untracked paths; f82 is transport and no reader credit transfers. Test files and build script are source text only.'}
(p/'registration.json').write_text(json.dumps(x,indent=2)+'\n');(p/'registry-selection-reconstructed.json').write_text(json.dumps({'derivation':'Exact selected rows copied from decompressed original registry; list index is original role index. This is reconstructed selection, not original standalone registry.','registry_sha256':sha(gzip.decompress((pub/'recovered/original-registry-source-archive/registry.json.gz').read_bytes())),'rows':rows},indent=2)+'\n');print('registration_sha256',sha((p/'registration.json').read_bytes()));print(json.dumps(comparisons,indent=2))
