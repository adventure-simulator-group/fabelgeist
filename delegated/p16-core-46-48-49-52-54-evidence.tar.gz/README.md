# Bounded historical P16 core source packet

`report.json` contains the independent source assessment and conditional
finding, exact historical relationships, thirteen bounded perspectives, and
open questions. `registration.json` and `personal-read-receipt.json` preserve
separate full old and current body displays for original roles 46, 48, 49, 52,
and 54. `support*-registration.json` and matching receipts preserve bounded
current support, including exact unread complements.

`source/` holds independently captured historical and current bytes. `support/`
holds complete supporting source bytes, but its receipts are the only personal
read scope. `git-proofs.json` and `git-objects/` independently verify the
historical f82 transport, per-file recorded a120 base, related 6533 and pinned
95e Git membership. The selected P16 files individually match a120; the P16
snapshot remains dirty and its tracked patch omits seven untracked files.

`reference/` includes the original registry, original 059 transport manifest,
recovered tracked P16 patch, 059 queue and separate current/historical autopsy
assessments. `history-059/` contains exact manifest-matched records and
`history-774/` contains exact f82 tree-bound records. Registry and queue
selections are reconstructed subsets; `history-reconciliation.json` records
four mojibake text discrepancies without changing either original.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` to verify
packet integrity, not product behavior. No product code, build script, test,
fixture, macro, renderer, generation or runtime was executed. Central review
owns adoption, duplicate decisions, publication, and the repair ledger; no
checkpoint 3821 source or record is inferred.
