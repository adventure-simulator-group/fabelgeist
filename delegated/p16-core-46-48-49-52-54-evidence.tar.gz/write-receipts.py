import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
for reg,dst in [('registration.json','personal-read-receipt.json'),('support-registration.json','support-read-receipt.json'),('support2-registration.json','support2-read-receipt.json')]:
 x=json.loads((p/reg).read_bytes());out=[]
 for e in x['entries']:
  if reg=='registration.json':
   i=e['original_index'];n=e['EOF'];chunks=([[1,90],[91,180],[181,270],[271,360],[361,440],[441,n]] if i==46 else [[1,90],[91,180],[181,270],[271,360],[361,450],[451,540],[541,n]] if i==49 else [[1,n]])
  else:chunks=e['registered_ranges']
  out.append({'source':e['archive'],'sha256':e['sha256'],'revision':e['revision'],'displayed_chunks':chunks,'displayed_union':e['registered_ranges'],'unread_complement':[] if reg=='registration.json' else 'All lines outside displayed registered ranges; no full support-file claim.'})
 y={'author':'/root/mhr_character','receipt_utc':at,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':out,'qualification':'Personally displayed via numbered untruncated source views after prospective registration. Tests and build scripts were read as source text only. No reads by other reviewers were transferred.'};(p/dst).write_text(json.dumps(y,indent=2)+'\n');print(dst,sha((p/dst).read_bytes()))
