import gzip,json,pathlib
p=pathlib.Path(__file__).parent;reg=json.load(open(p/'registry-selection-reconstructed.json'))['rows'];idx=json.load(open(p/'historical-index.json'))['records'];out=[]
for r in reg:
 row=r['row']
 for x in row.get('owner_contract_proofs',[]):
  z=next(y for y in idx if y['transport_path'].endswith(x['record']));rr=json.loads(gzip.decompress((p/z['file']).read_bytes()).splitlines()[x['row']]);assert rr['source_id']==row['source_id'] and rr['read_ranges']==x['read_ranges'];out.append({'role':r['original_index'],'kind':'owner','registry_row_index_zero_based':x['row'],'transport_line_one_based':x['row']+1,'transport_file':z['file'],'source_id':rr['source_id'],'range_match':True,'recorded_ranges':rr['read_ranges'],'recorded_read_status':rr['read_status']})
 for x in row.get('producer_reached_contract_observations',[]):
  z=next(y for y in idx if y['transport_path'].endswith(x['record']));ls=gzip.decompress((p/z['file']).read_bytes()).splitlines();matches=[(i,json.loads(l)) for i,l in enumerate(ls,1) if (json.loads(l).get('id')==x['receipt'] or json.loads(l).get('trace_id')==x['receipt'])];assert len(matches)==1;li,v=matches[0]
  for key in x['json_pointer'].strip('/').split('/'):v=v[int(key)] if isinstance(v,list) else v[key.replace('~1','/').replace('~0','~')]
  old=x['source_context'];diff={k:{'original_registry':old.get(k),'f82_record':v.get(k)} for k in set(old)|set(v) if old.get(k)!=v.get(k)}
  assert v['sha256']==row['sha256'] and v['read_ranges']==x['read_ranges_as_recorded'];out.append({'role':r['original_index'],'kind':'producer','receipt':x['receipt'],'transport_file':z['file'],'transport_line_one_based':li,'pointer':x['json_pointer'],'source_hash_and_ranges_match':True,'differences':diff})
(p/'history-reconciliation.json').write_text(json.dumps({'entries':out,'qualification':'Registry and f82 trace source hashes and range arrays agree for checked pointers. Four source-context text fields differ: registry contains mojibake in place of f82 en dashes; both exact originals remain preserved. Do not normalize or infer the cause; no read credit is transferred. Owner record row fields are zero-based; line numbers are one-based.'},indent=2,ensure_ascii=False)+'\n');print('reconciled',len(out),'text differences',sum(bool(e.get('differences')) for e in out))
