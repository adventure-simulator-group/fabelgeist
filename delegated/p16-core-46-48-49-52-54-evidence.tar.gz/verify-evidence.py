import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);selection=load('registry-selection-reconstructed.json');assert selection['registry_sha256']==sha(raw) and all(reg['files'][e['original_index']]==e['row'] for e in selection['rows']);assert [e['original_index'] for e in selection['rows']]==[46,48,49,52,54]
t=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(t)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';m={e['path']:e for e in json.loads(gzip.decompress(t))['entries']};q=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(q)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(q);assert all(queue['entries'][int(k)]==v for k,v in load('queue-selection-reconstructed.json')['entries'].items())
for n in ('reference-index.json','rules.json','skills.json'):
 for e in load(n)['records']:assert sha((p/e['file']).read_bytes())==e['sha256'],e['file']
snap=next(z for z in reg['snapshots'] if z['id']=='physical-p16');patch=(p/'reference/p16-tracked.patch').read_bytes();a=load('p16-per-file-qualification.json');assert sha(patch)==snap['patch_sha256']==a['patch_observed_sha256']==a['patch_recorded_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';assert a['base_head']==snap['head'] and a['status_rows']==len(snap['status_porcelain'])==159
for e in a['files']:
 path=e['path'];assert e['snapshot_status_matches']==[z for z in snap['status_porcelain'] if z[3:]==path];assert e['tracked_patch_contains_diff_header']==(f'diff --git a/{path} b/{path}\n'.encode() in patch)
groups=[('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('support2','support2-registration.json','support2-read-receipt.json'),('support3','support3-registration.json','support3-read-receipt.json')]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert (sha(body),blob(body),len(body.splitlines()))==(a['sha256'],a['git_blob'],a['EOF']);assert a['sha256']==b['sha256'] and a['archive']==b['source'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and seen|missing==set(range(1,a['EOF']+1)) and not seen&missing
 counts[name]=len(r['entries'])
r=load('registration.json');assert len(r['entries'])==10
for e in r['entries']:
 row=reg['files'][e['original_index']];assert e['source_id']==row['source_id'] and e['snapshot']==row['snapshot']=='physical-p16'
 if e['label']=='historical':assert e['sha256']==row['sha256'] and e['revision'] is None and (row.get('actual_line_count',e['EOF'])==e['EOF'])
for c in r['comparisons']:
 assert c['versions']['base']['equals_archived'];assert c['versions']['current']['equals_archived']==(c['original_index']!=46)
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  k=m[e['transport_path']];assert (k['bytes'],k['sha256'],k['git_blob'])==(len(b),sha(b),blob(b))
h=p/'history-059/parallel-l12-20261029';one=json.loads((h/'PARTIAL-CONNECTED-PAR-L12-878-CATALOG-COMPILER-001.json').read_bytes());two=json.loads((h/'PARTIAL-CONNECTED-PAR-L12-878-CATALOG-COMPILER-002.json').read_bytes());assert one['rows'][1]['fresh_personal_body_reads']==[[1,135]] and one['rows'][1]['unread_registered_ranges']==[[220,341]];assert two['rows'][0]['fresh_personal_body_reads']==[[220,341]] and not two['rows'][0]['unread_registered_ranges'];assert two['predecessor_partial']['sha256']==sha((h/'PARTIAL-CONNECTED-PAR-L12-878-CATALOG-COMPILER-001.json').read_bytes());assert two['rows'][0]['registration_sha256']==sha((h/'REGISTRATION-PAR-L12-645.json').read_bytes());ad=load('history-059/segovb/READ-L12-CONNECTED-TEAM-021.json')['exact_source_rows'][9];assert ad['original_index']==46 and ad['unread_ranges']==[[136,219],[342,509]]
old=load('history-059/parallel-l13-20261029/READ-PL13-131.json');assert old['rows'][0]['source_id']=='pr-working:crates/adventuresim-core/src/autopsy.rs' and old['rows'][0]['fresh_personal_assessed_ranges']==[[1,648]];assert old['registration']['sha256']==sha((p/'history-059/parallel-l13-20261029/REGISTRATION-PL13-131.json').read_bytes())
rec=load('history-reconciliation.json');assert len(rec['entries'])==14 and sum(bool(e.get('differences')) for e in rec['entries'])==4
for e in rec['entries']:
 b=gzip.decompress((p/e['transport_file']).read_bytes());lines=b.splitlines();record=json.loads(lines[e['transport_line_one_based']-1]);row=reg['files'][e['role']]
 if e['kind']=='owner':assert record['source_id']==row['source_id'] and record['read_ranges']==e['recorded_ranges']
 else:
  assert record.get('id',record.get('trace_id'))==e['receipt'];v=record
  for k in e['pointer'].strip('/').split('/'):v=v[int(k)] if isinstance(v,list) else v[k.replace('~1','/').replace('~0','~')]
  assert v['sha256']==row['sha256'];old=next(z for z in row['producer_reached_contract_observations'] if z['receipt']==e['receipt'])['source_context'];diff={k:{'original_registry':old.get(k),'f82_record':v.get(k)} for k in set(old)|set(v) if old.get(k)!=v.get(k)};assert diff==e['differences']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==37;report=load('report.json');assert len(report['lens_perspectives'])==13 and len({e['lens'] for e in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','scope':'Offline source identity, dirty P16 patch/registry, 059 transport records and exact prior ranges, 774 record reconciliations, prospective registration and exact displayed/unread range partition, plus raw Git commit/tree proofs; no product validation.','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'registry_context_text_differences':4,'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
