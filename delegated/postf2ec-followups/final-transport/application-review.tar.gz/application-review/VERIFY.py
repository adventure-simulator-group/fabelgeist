#!/usr/bin/env python3
"""Read-only replay of bounded evidence identities and application relationships."""
import argparse,collections,hashlib,io,json,os,pathlib,subprocess,sys,tarfile
if sys.flags.optimize: raise RuntimeError('Assertions required: do not use Python -O')
P=pathlib.Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--publication',type=pathlib.Path,required=True);ap.add_argument('--clarification',type=pathlib.Path);ap.add_argument('--snapshot-tree',type=pathlib.Path);ap.add_argument('--initial-index',type=pathlib.Path);ap.add_argument('--check-index',action='store_true');args=ap.parse_args()
r=args.publication.resolve();stage=r/'delegated/postf2ec-followups';app=stage/'application';h=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_bytes());report=J(P/'REPORT.json');manifest=J(P/'MANIFEST.json');capture=J(P/'FROZEN-CAPTURE.json')
assert h((P/'FROZEN-CAPTURE.json').read_bytes())==report['frozen_capture_sha256']
actual={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x.name!='MANIFEST.json'};assert actual==set(manifest['files']) and not any(x.is_symlink() for x in P.rglob('*'))
for name,row in manifest['files'].items():
 b=(P/name).read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256']
assert len(capture['rows'])==173
for row in capture['rows']:
 p=r/row['path'];b=p.read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'];assert ('100755' if p.stat().st_mode&0o111 else '100644')==row['mode']
 if args.snapshot_tree:
  p=args.snapshot_tree/row['path'];b=p.read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'];assert ('100755' if p.stat().st_mode&0o111 else '100644')==row['mode']
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
if args.check_index:
 out=subprocess.check_output(['git','-C',str(r),'ls-files','--stage','-z'],env=env);idx={}
 for e in out.split(b'\0'):
  if e:
   meta,path=e.split(b'\t',1);mode,blob,num=meta.decode().split(' ');idx[os.fsdecode(path)]=(mode,blob,num)
 for row in capture['rows']:assert idx[row['path']]==(row['mode'],row['git_blob'],'0')
rec=J(app/'RECORD.json');assert h((app/'RECORD.json').read_bytes())==report['application_record_sha256']
for n,want in rec['scripts'].items():assert h((app/n).read_bytes())==want
raw=(app/rec['archive']).read_bytes();assert (len(raw),h(raw))==(rec['archive_bytes'],rec['archive_sha256']) and h(raw)==report['archive_sha256'];wanted={x['path']:x for x in rec['members']};data={}
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
 for m in tar:
  n=pathlib.PurePosixPath(m.name);assert not n.is_absolute() and '..' not in n.parts and m.isfile() and m.name in wanted and m.name not in data
  b=tar.extractfile(m).read();x=wanted[m.name];assert (len(b),h(b),oct(m.mode))==(x['bytes'],x['sha256'],x['mode']);data[m.name]=b
assert set(data)==set(wanted)
names=['BASELINE-95E-20261110.json','CONTINUATION-PROGRESS-95E.json','RECONCILIATION-059.json','CONTINUATION.md']
for n in names:
 assert data['after/'+n]==(r/n).read_bytes()
 old=subprocess.check_output(['git','-C',str(r),'show',report['parent_checkpoint']+':'+n],env=env);assert data['before/'+n]==old
for old,new in [('verify_postd7a5_application.py','PREDECESSOR-D7.py'),('verify_postede12_application.py','PREDECESSOR-EDE.py')]:assert subprocess.check_output(['git','-C',str(r),'show',report['parent_checkpoint']+':'+old],env=env)==(app/new).read_bytes()
for n,path in [('draft-v4.json',stage/'central/DRAFT-v4.json'),('report.json',r/'ASSESSMENT-CENTRAL-FOLLOWUPS-19-95E.json'),('pending.json',stage/'PENDING-DELEGATES.json'),('previous-pending.json',r/'delegated/postede12-followups/PENDING-DELEGATES.json'),('main-observation.json',r/'MAIN-RECHECK-20261113-0314.json')]:assert data['inputs/'+n]==path.read_bytes()
assert data['inputs/previous-pending.json']==subprocess.check_output(['git','-C',str(r),'show',report['parent_checkpoint']+':delegated/postede12-followups/PENDING-DELEGATES.json'],env=env)
rev=json.loads(data['inputs/review-adoption.json']);draft=json.loads(data['inputs/draft-v4.json']);adopt=json.loads(data['inputs/report.json']);assert h(data['inputs/draft-v4.json'])==report['draft_v4_sha256']==rev['reviewed_draft_sha256']==adopt['adopted_from_draft_sha256'];assert h(data['inputs/report.json'])==report['report_sha256']
assert all(adopt[k]==v for k,v in draft.items() if k!='status');assert h((r/rev['public_transport']).read_bytes())==report['review_archive_sha256']==rev['public_transport_sha256']
with tarfile.open(r/rev['public_transport'],'r:gz') as t:assert h(t.extractfile('color-owner-review/MANIFEST.json').read())==report['review_manifest_sha256']==rev['public_review_manifest_sha256']
before=json.loads(data['before/RECONCILIATION-059.json'])['entries'];after=json.loads(data['after/RECONCILIATION-059.json'])['entries'];assert len(before)==len(after)==3713
changed=[]
for i,(a,b) in enumerate(zip(before,after)):
 if a!=b:
  assert {k for k in set(a)|set(b) if a.get(k)!=b.get(k)}=={'current_reconciliation','further_current_evidence'}
  assert a['current_reconciliation']=='unassessed' and b['current_reconciliation'].startswith('partial') and 'no semantic queue or lens closure' in b['current_reconciliation'];changed.append([i,b['historical_lens']])
assert sorted(changed)==sorted(report['selected_queue_lenses'])
count=lambda xs:dict(collections.Counter('partial' if x['current_reconciliation'].startswith('partial') else x['current_reconciliation'] for x in xs));assert count(after)=={'partial':1364,'unassessed':2349}
old=json.loads(data['inputs/previous-pending.json'])['packets'];pending=json.loads(data['inputs/pending.json'])['packets'];post=J(stage/'POSTFREEZE-PENDING.json')['packets'];states=lambda xs:dict(collections.Counter('partial' if after[x['queue_index']]['current_reconciliation'].startswith('partial') else after[x['queue_index']]['current_reconciliation'] for x in xs));ids=lambda xs:{x['queue_index'] for x in xs}
assert len(old)==28 and states(old)=={'partial':8,'unassessed':20} and len(pending)==28 and states(pending)=={'unassessed':28} and len(post)==16 and states(post)=={'unassessed':16};assert not(ids(pending)&ids(post) or ids(pending)&{x[0] for x in changed} or ids(post)&{x[0] for x in changed})
freeze=J(stage/'FREEZE.json');assert set(freeze['central_proposed'])=={x[0] for x in changed} and {n for group in freeze['sealed_pending_groups'] for n in group['queue_indices']}==ids(pending)
a=json.loads(data['before/BASELINE-95E-20261110.json'])['newly_assessed_ledger']['entries'];b=json.loads(data['after/BASELINE-95E-20261110.json'])['newly_assessed_ledger']['entries'];assert len(a)==1101 and len(b)==1103 and b[:1101]==a and [x['id'] for x in b[1101:]]==report['added_relationship_ids']
for cr,x,y in [('INDEX-POSTFREEZE-CORRECTION.json','INDEX-v2.md','INDEX-v3.md'),('INDEX-RESTORATION-CORRECTION.json','INDEX-v3.md','INDEX-v4.md'),('INDEX-REVIEW-CORRECTION.json','INDEX-v4.md','INDEX.md')]:
 z=J(stage/cr);assert h((stage/x).read_bytes())==z['predecessor_sha256'] and h((stage/y).read_bytes())==z['successor_sha256']
z=J(stage/'INDEX-WRAP-CORRECTION.json');assert h((stage/'INDEX-v2.md').read_bytes())==z['successor_sha256'] and z['initial_sha256']==report['restricted_index_initial_sha256']
if args.initial_index:assert h(args.initial_index.read_bytes())==z['initial_sha256']
if args.clarification:
 c=args.clarification;v2=J(c/'REPORT-v2.json');v3=J(c/'REPORT-v3.json');c2=J(c/'CORRECTION.json');c3=J(c/'CORRECTION-v3.json');assert h((c/'REPORT-v2.json').read_bytes())==report['clarification_v2_sha256']==c2['successor_sha256']==c3['predecessor_sha256'];assert c2['predecessor_sha256']==report['report_sha256'];assert h((c/'REPORT-v3.json').read_bytes())==report['clarification_v3_sha256']==c3['successor_sha256'];assert {k for k in set(v2)|set(v3) if v2.get(k)!=v3.get(k)}=={'review_qualification','predecessor_clarification_sha256','wording_qualification'};assert v2['review_qualification'].replace('; At the owners-v2','; at the owners-v2')==v3['review_qualification'];assert {k for k in set(adopt)|set(v2) if adopt.get(k)!=v2.get(k)}=={'review_qualification','process_qualification','predecessor_report_sha256','clarification_qualification'}
print(json.dumps({'result':'pass','frozen_paths':173,'queue_after':count(after),'ledger_entries':len(b),'partial_assessments':8,'semantic_closures':0,'postfreeze_unassessed':16,'clarification_checked':bool(args.clarification),'snapshot_tree_checked':bool(args.snapshot_tree),'restricted_initial_index_checked':bool(args.initial_index),'index_checked':args.check_index,'qualification':'Evidence identity and selected structural relationships only. No product behavior, personal display event, independent custody, full predecessor replay or global closure established.'}))
