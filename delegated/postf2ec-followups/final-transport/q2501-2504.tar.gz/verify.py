#!/usr/bin/env python3
# Source evidence replay; no product code is imported or executed.
import argparse,hashlib,json,pathlib,stat,subprocess,sys
if sys.flags.optimize:raise SystemExit('Optimized execution unsupported.')
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
def load(n):return json.loads((P/n).read_bytes())
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def safe(d,n):
 q=pathlib.PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts;return d.joinpath(*q.parts)
def tree(b):
 o={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);assert z+21<=len(b);n=b[a+1:z].decode();assert n not in o;o[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return o
def prove(root,path,data):
 for part in path.split('/'):
  t=(P/'trees'/(root+'.tree')).read_bytes();assert oid('tree',t)==root;mode,root=tree(t)[part]
 assert mode=='100644' and oid('blob',data)==root
def manifest():
 m=load('MANIFEST.json');fs={q.relative_to(P).as_posix() for q in P.rglob('*') if q.is_file() and q!=P/'MANIFEST.json'};ds={q.relative_to(P).as_posix() for q in P.rglob('*') if q.is_dir()};assert fs==set(m['files']) and ds==set(m['directories']) and not any(q.is_symlink() for q in P.rglob('*'))
 for n,x in m['files'].items():
  q=safe(P,n);b=q.read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256'] and stat.S_IMODE(q.stat().st_mode)==x['mode']
 for n,mode in m['directories'].items():assert stat.S_IMODE(safe(P,n).stat().st_mode)==mode
ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);ap.add_argument('--peer0057',type=pathlib.Path);ap.add_argument('--own0060',type=pathlib.Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if not a.private and (a.anchors or a.peer0057 or a.own0060):raise SystemExit('other anchors require --private')
if a.skip_manifest:print('NOT CHECKED: public manifest (--skip-manifest).')
else:manifest();print('public exact inventory, modes and hashes: pass')
source=(P/'source/95e.rs').read_bytes();assert H(source)=='cb410372fbb5a1f8b61fad2bf447bcd93512725560fb69338ec024ed3135b0e1' and len(source.splitlines())==1251
primary=load('SOURCE-006-CAPTURE-RESULT.json');assert len(primary)==3
for x in primary:assert x['sha256']==H(source) and x['EOF']==1251;prove(x['root'],x['path'],source)
root='1eec97de340d9b7debbb30ca0c0fb2240a73b93f';rows={primary[-1]['path']:{'file':'source/95e.rs'}}
for name in ['SUPPORT-010','SUPPORT-017','SUPPORT-023']:
 for x in load(name+'-CAPTURE-RESULT.json'):
  assert x['root']==root;b=safe(P,x['file']).read_bytes();assert H(b)==x['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['EOF'];prove(root,x['path'],b);rows[x['path']]=x
print('primary source blob-to-declared-tree proofs and pinned support: pass')
print('NOT CHECKED from public data alone: commit-to-root links or original private queue membership.')
reg=load('SOURCE-008-DISPLAY-REG.json');assert reg['queues']==[2501,2503,2504] and reg['lenses']==[7,9,10] and reg['EOF']==1251 and reg['planned_ranges']==[[1,100],[101,200],[201,300],[301,400],[401,498]]
for lens,q in [(7,2501),(9,2503),(10,2504)]:
 x=load(f'LENS-{lens:02}-SOURCE-REG.json');assert x['queue']==q and x['lens']==lens and x['prospective_ranges']==[[1,498]]
ls=source.decode().splitlines(keepends=True);views=load('SOURCE-008-DISPLAY-RESULT.json');assert [x['range'] for x in views]==reg['planned_ranges']
for x in views:
 lo,hi=x['range'];b=safe(P,x['file']).read_bytes();assert H(b)==x['sha256'] and b.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
for name in ['SUPPORT-012','SUPPORT-014','SUPPORT-018','SUPPORT-024']:
 reg=load(name+'-DISPLAY-REG.json');out=load(name+'-DISPLAY-RESULT.json');assert [(x['path'],x['range']) for x in out]==[(v['path'],r) for v in reg['views'] for r in v['ranges']]
 for x in out:
  ls=safe(P,rows[x['path']]['file']).read_text().splitlines(keepends=True);lo,hi=x['range'];actual=safe(P,x['file']).read_bytes();assert H(actual)==x['sha256'] and actual.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
 assert (P/(name+'-READ.json')).is_file()
for skill in load('SKILLS-001-CAPTURE.json'):
 b=(P/'skills'/('lens-'+str(skill['lens'])+'.md')).read_bytes();assert H(b)==skill['sha256'] and len(b.splitlines())==skill['lines']
print('three focused skills, separate registrations, primary and support windows: pass; display is attested')
cross=load('RECONSTRUCTION-CROSSWALK.json')
for x in cross['files']:
 b=safe(P,x['public_file']).read_bytes();assert H(b)==x['public_whole_sha256'] and len(b)==x['public_bytes']
 if a.private:
  original=safe(a.private,x['restricted_file']).read_bytes();assert H(original)==x['restricted_whole_sha256'] and len(original)==x['restricted_bytes'];out=bytearray();pos=0
  for v in x['spans']:
   off=v['offset'];assert off>=pos and off+v['length']<=len(original);out+=original[pos:off];out+=v['replacement'].encode();pos=off+v['length']
  out+=original[pos:];assert bytes(out)==b
if a.private:
 assert H((a.private/'MANIFEST.json').read_bytes())==cross['restricted_manifest_sha256']=='bfa4c2ac4f6e357cf6790cd1869fdda9a8d2c5e68b855b8c2ab483422bf61441'
 cmd=[sys.executable,'-B',str(a.private/'verify-evidence.py')]
 for opt,val in [('--anchors',a.anchors),('--peer0057',a.peer0057),('--own0060',a.own0060)]:
  if val:cmd += [opt,str(val)]
 assert subprocess.run(cmd,check=False).returncode==0
 h=load('PUBLIC-HISTORY.json');rec=json.loads((a.private/'committed'/'reconciliation.stdout').read_bytes())['entries'];assert h['queues']=={'2501':7,'2503':9,'2504':10} and h['fresh_personal_ranges']==[[1,498]]
 for k,l in h['queues'].items():assert rec[int(k)]['historical_lens']==l and rec[int(k)]['current_reconciliation']=='unassessed'
 assert rec[3450]['current_reconciliation']=='unassessed'
 for parts,key in [(('historical','INHERITED-L2-root-coverage.jsonl'),'supplier_metadata_sha256'),(('historical','READ-ROOT-L2-EXT-055-066.json'),'historical_l2_receipt_sha256')]:assert H(a.private.joinpath(*parts).read_bytes())==h[key]
 assert H((a.private/'prior'/'peer0057'/'MANIFEST.json').read_bytes())==h['prior_peer_manifest_sha256'] and H((a.private/'prior'/'own0060'/'MANIFEST.json').read_bytes())==h['prior_own_manifest_sha256']
 print('public crosswalk and bounded history projection against separately held originals: pass')
else:print('NOT CHECKED: original crosswalk and history projection (supply --private).')
print('No product behavior, unique count, checkpoint3821 recovery or overall audit closure is established.')
