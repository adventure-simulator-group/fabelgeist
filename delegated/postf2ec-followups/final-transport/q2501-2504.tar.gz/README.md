# q2501/q2503/q2504 source-only successor

The three reports assess lenses 7, 9 and 10 independently against pinned 95e. Full source objects and their Git trees are present for identity proofs, but personally displayed coverage is only organization.rs lines1–498 of EOF1251. Historical display records are reviewer attestations. Earlier peer role0057 and own role0060 reports are included in path-safe form and retain separate attribution; their sealed complete packets are independently held.

`python3 -B verify.py` checks the public manifest, blob-to-declared-tree proofs, registrations, displayed windows and skills. Public-only replay cannot prove the commit-to-tree links, original historical queue membership or exact removed bytes. Supply `--private PRIVATE_DIR` to verify the crosswalk and restricted packet; add `--anchors ANCHOR_DIR`, `--peer0057 PEER_DIR` and `--own0060 OWN_DIR` for all full queue and prior packet anchors. These checks do not execute product code.

Raw queue records, Git commit payloads and sensitive paths are omitted. The full original bytes cannot be reconstructed without the separately held restricted packet. Finite privacy scanning and archive comparison are separate receipts, not proof of exhaustive privacy. No product build, test, runtime probe, repair, global closure or unique count is claimed.
