#!/usr/bin/env python3
"""Read-only evidence/registered display replay; never executes product code."""
import argparse,hashlib,gzip,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
def J(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(x,m):
 if not x:raise ValueError(m)
def safe(r,n):
 q=pathlib.PurePosixPath(n);need(not q.is_absolute() and '..' not in q.parts,'unsafe path');return r.joinpath(*q.parts)
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'tree bounds');n=b[a+1:z].decode();need(n not in out,'duplicate entry');out[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repository');a=ap.parse_args();m=J(P/'MANIFEST.json');fs={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(fs==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest set')
 for n,v in m['files'].items():
  f=safe(P,n);b=f.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode'],'file '+n)
 for x in J(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(x['name']+'.md')).read_bytes();need(sh(b)==x['sha256'] and len(b.splitlines())==x['lines'],'skill identity')
 reg=J(P/'SOURCE-REGISTRATION.json');expected=[(3401,1),(3402,2),(3404,5),(3405,6)];need([(x['queue'],x['lens']) for x in reg['lenses']]==expected and [(x['queue'],x['lens']) for x in J(P/'ASSESSMENTS.json')['assessments']]==expected,'lenses');rr=J(P/'SOURCE-READ-RECEIPT.json');need(rr['sources']==reg['sources'] and rr['actual_display_ranges']==[[1,1573]] and rr['unread_complement']==[],'assigned read prereg');bodies=[]
 for x in reg['sources']:
  b=(P/'sources'/(x['label']+'.rs')).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(b.decode().splitlines())==x['EOF']==1573,'source identity');bodies.append(b)
 need(len(bodies)==3 and len(set(bodies))==1,'shared view exact bytes');ls=bodies[0].decode().splitlines();seen=set()
 for v in rr['views']:
  lo,hi=v['range'];b=safe(P,v['file']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i}: {ls[i-1]}' for i in range(lo,hi+1)] and v['registration_mtime_ns']<=v['view_created_mtime_ns'],'assigned view');need(not seen.intersection(range(lo,hi+1)),'overlap');seen.update(range(lo,hi+1))
 need(len(rr['views'])==16 and seen==set(range(1,1574)),'full assigned view')
 supports=[]
 for name in ('SUPPORT-READ-RECEIPT.json','SUPPORT-READ-RECEIPT-4.json','SUPPORT-READ-RECEIPT-5.json'):supports+=J(P/name)['rows']
 need(len(supports)==13,'support scope count');chunks=0
 for r in supports:
  b=safe(P,r['source_file']).read_bytes();lines=b.decode().splitlines();need(sh(b)==r['sha256'] and oid(b'blob',b)==r['git_blob'] and len(lines)==r['EOF'],'support identity');d=J(P/r['registration']);x=next(t for t in d['rows'] if t['label']==r['label']);need(x['revision']==r['revision'] and x['path']==r['path'] and x['registered_ranges']==r['actual_ranges'],'support prereg');actual=set()
  for v in r['views']:
   lo,hi=v['range'];b=safe(P,v['file']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(lo,hi+1)] and r['registration_mtime_ns']<=v['view_created_mtime_ns'],'support display');actual.update(range(lo,hi+1));chunks+=1
  need(actual=={i for lo,hi in r['actual_ranges'] for i in range(lo,hi+1)},'support range')
 proofs=J(P/'TREE-PROOFS.json')['proofs']+J(P/'TREE-PROOFS-ADDENDUM.json')['proofs'];need(len(proofs)==17,'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree path length')
  for part,step in zip(parts,x['tree_chain']):
   need(cur==step['tree'] and part==step['entry'],'tree step');b=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',b)==cur,'tree hash');mode,cur=tree(b)[part];need(mode==step['mode'] and cur==step['object'],'tree entry')
  need(cur==x['blob'],'tree blob');
  if x['role'] in ('source','older-identity-only'):need(oid(b'blob',safe(P,x['source_file']).read_bytes())==cur,'source blob')
  elif a.restricted:
   b=safe(a.restricted,x['source_file']).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==cur,'restricted blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository binding')
 cat=J(P/'CATALOG-RESULT.json')['matches'];need([(x['index'],x['lens']) for x in cat]==expected and all(x['selected_equal'] for x in cat),'queue scope')
 history=False
 if a.restricted:
  h=a.restricted/'historical';raw=(h/'previous-private-manifest.json').read_bytes();need(sh(raw)=='1cd8f03c3312bb99d1905666c8c9e5f98f74d33ab5b06480ca9a9cd20a0e446f','previous manifest');old=json.loads(raw)['files'];qs=[]
  for n in ('queue-original.json','queue-reconstructed.json'):
   b=(h/n).read_bytes();need(sh(b)==old['historical/'+n]['sha256'],'original queue anchor');qs.append(json.loads(b))
  b=(h/'queue-published.json').read_bytes();need(sh(b)==J(P/'CATALOG-RESULT.json')['published_queue_sha256'],'published queue');qs.append(json.loads(b));need((h/'queue-original.json').read_bytes()!=(h/'queue-reconstructed.json').read_bytes(),'queue stream distinction')
  for x in cat:
   e=[q['entries'][x['index']] for q in qs];need(e[0]==e[1]==e[2] and e[0]['lens']==x['lens'] and e[0]['contract_id']==x['id'],'queue selection')
  for i in (541,542,2458,2459,3302,3303,227,182):need(qs[0]['entries'][i]==qs[1]['entries'][i]==qs[2]['entries'][i] and J(h/f'q{i}-original.json')==qs[0]['entries'][i],'related 059 record')
  hm=J(h/'prior-historical-manifest.json');records={r['original_transport_path']:r for r in hm['records']}
  for r in J(P/'HISTORICAL-INPUT-CAPTURE.json')['records']:
   b=(h/f"prior-receipt-{r['index']:02d}.json").read_bytes();need(sh(b)==r['sha256']==records[r['historical_path']]['sha256'] and oid(b'blob',b)==r['git_blob'],'historical receipt')
  b=(h/'registry-original.json.gz').read_bytes();need(sh(b)=='a90f280f820e17643933b87aee4587c0ba47f8feec35bd9db61611653bc14063','stored registry');u=gzip.decompress(b);need(sh(u)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f','decoded registry');q=json.loads(u);need(J(h/'registry-role2408.json')==q['files'][2408] and q['files'][2408]['snapshot']=='pr-working' and q['files'][2408]['sha256']==reg['sources'][0]['sha256'],'registry role')
  b=(h/'older-774-ledger.json').read_bytes();need(sh(b)=='74f8fe4d07b187636dc8568ba5f129f02157d43d67b6d67c618c7259a808be48' and J(h/'older-774-finding79.json')==json.loads(b)['findings'][79] and json.loads(b)['findings'][79]['id']=='M56','older M56');need((h/'archived-original-object.rs').read_bytes()==bodies[0],'original source object')
  l2=J(h/'prior-receipt-06.json')['rows'][1];l2e=J(h/'prior-receipt-08.json')['rows'][1];l3=J(h/'prior-receipt-09.json')['rows'][8];l3e=J(h/'prior-receipt-11.json')['rows'][9];need(l2['fresh_personal_ranges']==l3['fresh_personal_ranges']==[[1,1573]] and l2e['fresh_personal_ranges']==l3e['fresh_personal_ranges']==[] and l2e['qualified_same_lens_reuse_ranges']==l3e['qualified_reuse_ranges']==[[1,1573]],'historical full read vs e275 reuse')
  c=(h/'baseline-committed.json').read_bytes();w=(h/'baseline-observed.json').read_bytes();need(sh(c)=='a402d49eb6dab3cd9182e16db92d2ea91896c761d02c87b2fcdad9d50efa7276' and sh(w)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041' and c!=w,'distinct ledger streams');l=json.loads(c)['newly_assessed_ledger']['entries'];need(l[843]['id']=='SEGOVB-L12-SOCIAL-PERSONALITY-AXIS-SLUG-ROUNDTRIP' and l[844]['id']=='SEGOVB-L12-SOCIAL-FAITH-DISPLAY-NONE-CONDITION','ledger references')
  roots={}
  for x in J(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(oid(b'commit',b)==x['revision'] and sh(b)==x['payload_sha256'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit identity');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit tree binding');history=True
 print(json.dumps({'result':'pass','public_files':len(fs),'assigned_shared_display_chunks':len(rr['views']),'support_display_chunks':chunks,'git_tree_path_proofs':len(proofs),'restricted_history_checked':history,'repository_binding_checked':bool(a.repository),'qualification':'Evidence and recorded read-scope integrity only; runtime behavior, alias, count and closure not decided.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
