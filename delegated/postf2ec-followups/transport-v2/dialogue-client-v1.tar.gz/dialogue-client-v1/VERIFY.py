#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None: print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();verify_manifest(root,'MANIFEST-PRIVATE.json')
 source=proof(root,'SOURCE-GIT-PROOF.json','git-objects',True);checkpoint=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);history=proof(root,'historical-git-proof-reference.json','historical-git-objects',False)
 revs=['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','95e63628f9d70b8dd6e6fede64334696c6995009'];path='crates/strategic-web/static/dialogue-client.js';expected='dd5524466d59c0e52e3a527e31b8cc005ebf64f581b89a08801e2195943fcf19'
 assert len(source)==10 and len(checkpoint)==2 and len(history)==3
 assert all(sha(source[(r,path)])==expected and source[(r,path)]==source[(revs[0],path)] for r in revs);assert len(source[(revs[0],path)].decode().splitlines())==825
 old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';rec='dac7d0055716053f245139971eb67ddfd87fa462';hpath='baseline-059/queue.json'
 assert sha(history[(old,hpath)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert sha(history[(rec,hpath)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 indices=[203,2460,3413,3414,3416,3417];oldsel=exact_selections(history[(old,hpath)],indices);newsel=exact_selections(history[(rec,hpath)],indices)
 for i in indices:
  assert oldsel[i][0]==newsel[i][0]
  for label,sel in [('original',oldsel),('reconstructed',newsel)]:
   b=(root/f'{label}-q{i}.json').read_bytes()
   if i==203:assert json.loads(b)==sel[i][0]
   else:assert b==sel[i][1]
  if i!=203:assert oldsel[i][1]==newsel[i][1]
 assert oldsel[203][0]['contract_id']=='SEGOVB-L11-STALE-RESIDENT-SELECTION';assert oldsel[2460][0]['contract_id']=='L2-DIALOGUE-JS-NATIVE-INPUT-NORMALIZATION'
 for i,lens in [(3413,1),(3414,2),(3416,5),(3417,6)]:
  v=oldsel[i][0];assert v['lens']==lens and v['body_or_population_credit']==0 and v['status']=='own-lens-proof-qualification-or-read-pending';assert v['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,825]]
 ede='ede12d3f9f19d284abbc669b5ae38b814a585f77';base=checkpoint[(ede,'BASELINE-95E-20261110.json')];recbytes=checkpoint[(ede,'RECONCILIATION-059.json')];assert sha(base)=='a402d49eb6dab3cd9182e16db92d2ea91896c761d02c87b2fcdad9d50efa7276';assert sha(recbytes)=='be6acb889cb51b645d03e861715895c9efcf0f47e970cc8fa12f1d03404a9f94';q=json.loads(recbytes)['entries'];assert len(q)==3713
 for i in [3413,3414,3416,3417]:assert q[i]['current_reconciliation']=='unassessed' and q[i]['contract_id']==oldsel[i][0]['contract_id']
 rows=json.loads(base)['newly_assessed_ledger']['entries'];assert len(rows)==1099
 for i,id in [(14,'REVIEW-DIALOGUE-ACTION-RECEIPT-001'),(123,'SEGOVB-L12-SOCIAL-ACTION-PRIVATE-READMISSION'),(751,'ADLER-L11-NPC-CHAT-RETRY-SCOPE'),(841,'SEGOVB-L11-STALE-RESIDENT-SELECTION'),(1085,'relationship-dialogue-multi-ballot-order-95e'),(1086,'relationship-dialogue-claim-occurrence-identity-95e')]:assert rows[i]['id']==id
 for n,h in [('l2-read.json','607d08cf25b6b0fb20154f64f0221e4f58044f376973d5c947d4b388c64df467'),('l2-current-read.json','8d7f814a71196f3f7f4cd65431dedab06b8dcc5d49c232ade34d5d9e2618fa5f'),('l3-read.json','32d8a9c8a5c59c9b023cf3a1fc7bb1a7d27f35ff9ddc4ba2e5e0e1af0f959440'),('l3-current-read.json','9ece5d4f9868e490e6f19fcb0a3be2612bebda985c6b2ee3fe1b2d4dfed1da09')]:assert sha((root/n).read_bytes())==h
 l2=json.loads((root/'l2-read.json').read_bytes())['rows'][2];l2cur=json.loads((root/'l2-current-read.json').read_bytes())['rows'][2];assert l2['fresh_personal_ranges']==[[1,825]] and l2cur['fresh_personal_ranges']==[] and l2cur['qualified_same_lens_reuse_ranges']==[[1,825]]
 l3=json.loads((root/'l3-read.json').read_bytes())['rows'][9];l3cur=json.loads((root/'l3-current-read.json').read_bytes())['rows'][10];assert l3['fresh_personal_ranges']==[[1,825]] and l3cur['fresh_personal_ranges']==[] and l3cur['qualified_reuse_ranges']==[[1,825]]
 windows=[('source-95e.raw','display-001-140.txt',1,140),('source-95e.raw','display-141-280.txt',141,280),('source-95e.raw','display-281-420.txt',281,420),('source-95e.raw','display-421-560.txt',421,560),('source-95e.raw','display-561-700.txt',561,700),('source-95e.raw','display-701-825.txt',701,825),('social-owner.raw','social-display-0135-0175.txt',135,175),('social-owner.raw','social-display-0205-0250.txt',205,250),('social-owner.raw','social-display-1070-1105.txt',1070,1105),('social-owner.raw','social-route-1230-1345.txt',1230,1345),('scene-owner.raw','scene-display-001-035.txt',1,35),('scene-owner.raw','scene-display-330-371.txt',330,371),('context-web-routes.raw','context-web-routes-display.txt',75,130),('context-session-schema.raw','context-session-schema-display.txt',105,145),('context-session-prompts.raw','context-session-prompts-display.txt',175,225),('social-native.raw','social-native-display-0465-0520.txt',465,520),('social-native.raw','social-native-display-0585-0615.txt',585,615),('social-native.raw','social-native-display-0630-0755.txt',630,755)]
 for x in windows:window(root,*x)
 for raw,name,ranges in [('social-native.raw','social-native-display-0750-0770.txt',[(750,770)]),('context-session-init.raw','context-session-init.raw.more-display.txt',[(110,147)]),('context-session-prompts.raw','context-session-prompts.raw.more-display.txt',[(120,145),(414,437)])]:
  lines=(root/raw).read_text().splitlines();s=''.join(f'{i}: {lines[i-1]}\n' for lo,hi in ranges for i in range(lo,hi+1));assert s.encode()==(root/name).read_bytes()
 print('restricted manifest, ten source/revision bindings, checkpoint, queue proofs, six selections, attribution and 21 display files: PASS')
 print('Scope: evidence bytes and registered displays only; no product execution, semantic closure, runtime validation, independent custody, or checkpoint 3821 claim.')
if __name__=='__main__':main()
