#!/usr/bin/env python3
"""Read-only source and custody verification for interface-help review."""
import argparse,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
def J(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(x,msg):
 if not x:raise ValueError(msg)
def safe(root,n):
 p=pathlib.PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return root.joinpath(*p.parts)
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'truncated tree');n=b[a+1:z].decode();need(n not in out,'duplicate tree entry');out[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def runs(s):
 out=[]
 for i in sorted(s):
  if out and out[-1][1]+1==i:out[-1][1]=i
  else:out.append([i,i])
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repository');a=ap.parse_args();m=J(P/'MANIFEST.json');files={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(files==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest file set')
 for n,v in m['files'].items():
  x=safe(P,n);b=x.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (x.stat().st_mode&0o777)==v['mode'],'manifest file '+n)
 for e in J(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(e['name']+'.md')).read_bytes();need(sh(b)==e['sha256'] and len(b.splitlines())==e['lines'],'skill identity')
 need([(x['queue'],x['lens']) for x in J(P/'SOURCE-REGISTRATION.json')['assigned_own_lenses']]==[(3341,1),(3342,2),(3344,5),(3345,6)],'assigned lenses')
 rr=J(P/'READ-RECEIPT.json');unions={};views=0
 for r in rr['rows']:
  b=safe(P,r['source_file']).read_bytes();lines=b.decode().splitlines();need(sh(b)==r['source_sha256'] and oid(b'blob',b)==r['git_blob'] and len(lines)==r['EOF'],'source identity '+r['label']);d=J(P/r['registration'])
  if r['role']=='assigned':
   e=next(x for x in d['sources'] if x['label']==r['label']);need(e['revision']==r['revision'] and e['path']==r['path'] and e['sha256']==r['source_sha256'] and e['planned_ranges']==r['registered_ranges'],'assigned prereg')
  elif 'rows' in d:
   e=next(x for x in d['rows'] if 'support-'+x['label']==r['label']);need(e['revision']==r['revision'] and e['path']==r['path'] and e['sha256']==r['source_sha256'] and e['registered_ranges']==r['registered_ranges'],'support prereg')
  else:need(d['revision']==r['revision'] and d['path']==r['path'] and d.get('registered_ranges',d.get('ranges'))==r['registered_ranges'],'single support prereg')
  allowed=set();seen=set()
  for lo,hi in r['registered_ranges']:allowed.update(range(lo,hi+1))
  for v in r['views']:
   lo,hi=v['range'];need(1<=lo<=hi<=len(lines),'view bounds');b=safe(P,v['file']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(lo,hi+1)],'view bytes');seen.update(range(lo,hi+1));views+=1
  need(allowed==seen,'display and registered range');u=unions.setdefault((r['revision'],r['path']),{'eof':len(lines),'seen':set()});u['seen'].update(seen)
 for c in rr['coverage']:
  u=unions[(c['revision'],c['path'])];need(runs(u['seen'])==c['displayed_union'] and runs(set(range(1,u['eof']+1))-u['seen'])==c['unread_complement'],'coverage')
 need(len(unions)==len(rr['coverage'])==18 and all(c['displayed_union']==[[1,119]] and not c['unread_complement'] for c in rr['coverage'][:3]),'assigned full scopes');need(all(x['registration_mtime_ns']<=x['view_mtime_ns'] for x in J(P/'READ-CHRONOLOGY.json')['rows']),'view chronological metadata')
 proofs=J(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==20,'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree length')
  for part,step in zip(parts,x['tree_chain']):
   need(step['tree']==cur and step['entry']==part,'tree order');raw=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',raw)==cur,'tree id');mode,cur=tree(raw)[part];need(mode==step['mode'] and cur==step['object'],'tree node')
  need(cur==x['blob'],'tree blob')
  if x['role']=='source':need(oid(b'blob',safe(P,x['source_file']).read_bytes())==cur,'source blob')
  elif a.restricted:
   b=safe(a.restricted,x['source_file']).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==cur,'restricted blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository binding')
 selections=J(P/'QUEUE-SELECTION.json')['rows'];need([(x['index'],x['lens']) for x in selections]==[(3341,1),(3342,2),(3344,5),(3345,6)],'queue scope');need(all(x['parsed_equal_original_reconstructed_published'] for x in selections),'selected queue equality')
 fix=J(P/'QUEUE-SELECTION-CORRECTION.json');need([x['index'] for x in fix['rows']]==[3341,3342,3344,3345] and all(x['exact_current_revision_revisit_requirements'][0]['target_revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' for x in fix['rows']),'additive extraction correction');need([(x['queue'],x['lens']) for x in J(P/'ASSESSMENTS.json')['assessments']]==[(3341,1),(3342,2),(3344,5),(3345,6)],'assessment mapping')
 restricted=False
 if a.restricted:
  h=a.restricted/'historical';pm=(h/'prior-private-manifest.json').read_bytes();need(sh(pm)=='f40f0b76064f10a5c9de2d1ccb3d42a31f449cf058c1638c1f1c2c13d7075628','prior manifest identity');old=json.loads(pm)['files'];qs=[]
  for n in ('queue-original-56f.json','queue-reconstructed-dac7d.json'):
   b=(h/n).read_bytes();need(sh(b)==old['historical/'+n]['sha256'],'full queue anchor');qs.append(json.loads(b))
  published=(h/'queue-published-ede12.json').read_bytes();need(sh(published)=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173','published queue identity');qs.append(json.loads(published));need((h/'queue-original-56f.json').read_bytes()!=(h/'queue-reconstructed-dac7d.json').read_bytes(),'whole queue distinction')
  for x in selections:
   entries=[q['entries'][x['index']] for q in qs];need(entries[0]==entries[1]==entries[2] and entries[0]['lens']==x['lens'] and entries[0]['contract_id']==x['id'],'queue parsed entries');b=(json.dumps(entries[0],indent=2,ensure_ascii=False)+'\n').encode();need(sh(b)==x['selected_normalized_sha256'],'normalized selected identity');expect=next(k for k in fix['rows'] if k['index']==x['index']);need(entries[0]['exact_current_revision_revisit_requirements']==expect['exact_current_revision_revisit_requirements'],'corrected revisit')
  for i in (2453,3298):need(qs[0]['entries'][i]==qs[1]['entries'][i] and J(h/f'related-q{i}-original-56f.json')==qs[0]['entries'][i],'related 059 records')
  need(J(h/'related-059-197.json')==qs[0]['entries'][197],'q197')
  for r in J(P/'RECEIPT-CAPTURE.json')['records']:
   b=(h/('receipt-'+r['name'])).read_bytes();need(sh(b)==r['sha256']==old['historical/receipt-'+r['name']]['sha256'],'prior original receipt')
  l3=J(h/'receipt-READ-ROOT-L3-EXT-046-055.json')['rows'][3];c3=J(h/'receipt-READ-ROOT-L3-CURRENT-006.json')['rows'][4];l2=J(h/'receipt-READ-ROOT-L2-EXT-045-051.json')['rows'][4];c2=J(h/'receipt-READ-ROOT-L2-CURRENT-010.json')['rows'][4];need(l3['fresh_personal_ranges']==l2['fresh_personal_ranges']==[[1,119]] and c3['fresh_personal_ranges']==c2['fresh_personal_ranges']==[] and c3['qualified_reuse_ranges']==c2['qualified_same_lens_reuse_ranges']==[[1,119]],'prior read versus adoption')
  need((h/'recovered-original-role0049.object').read_bytes()==(P/'sources/old-6533.rs').read_bytes(),'original source object');need(sh((h/'early-READ-L11-390.json').read_bytes())=='3676cb690ba13d84292c5814a6fd3af6312963c98b5d91c386396e179e449e07','early 059 receipt')
  x=(h/'baseline-committed.json').read_bytes();y=(h/'baseline-working-observed.json').read_bytes();need(x==y and sh(x)==J(P/'OVERLAP-METADATA.json')['committed_sha256'],'captured ledger streams');ledger=json.loads(x)['newly_assessed_ledger']['entries'];need(ledger[785]['id']=='ADLER-L11-LIMB-HEALTH-AVAILABILITY' and ledger[857]['id']=='REVIEW-HEALTH-INJURY-OBSERVATION-AVAILABILITY-95E','related ledger rows')
  roots={}
  for x in J(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(oid(b'commit',b)==x['revision'] and sh(b)==x['payload_sha256'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit identity');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit tree link');restricted=True
 print(json.dumps({'result':'pass','public_files':len(files),'registered_display_chunks':views,'source_revision_pairs':len(unions),'git_tree_path_proofs':len(proofs),'restricted_history_and_commit_proofs_checked':restricted,'repository_binding_checked':bool(a.repository),'qualification':'Integrity and actual read scopes only; no product behavior, alias, count, or lens closure.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
