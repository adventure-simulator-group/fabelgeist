# Strategic interface help: four bounded source-lens assessments

Reviewer `/root/mhr_character` independently selected q3341, q3342, q3344
and q3345 from the published 059 catalog for historical lenses 1, 2, 5 and 6.
The two immediately preceding source roles were reserved to other reviewers.
The exact-ID, q-number and file-path search in the captured current ledger
found no matches; searches exclude compressed or unindexed material and do not
prove absence of a semantically equivalent record.

The assigned `crates/strategic-web/src/templates/interface_help.rs` source is
119 lines and has SHA-256
`c78ba1ba7989dbb10ddda4b92fd1118f802fa26bb36d5e5623449ffb567af9c9` and Git
blob `a7039e20b4b2e2fcc8805658a59cbe8847271080` at historical 6533, e275 and
pinned 95e. The recovered original object agrees. This is per-file identity,
not a clean historical or current tree assertion. One fresh preregistered
complete source display per revision was used for the four explicitly named
lenses; it does not transfer any earlier reviewer's credit.

## Lens 1: producer propagation

The selected `regional_reading` takes a typed `BodyRegion`, a textual reading,
a raw `sound` scalar and a `Markup` bar (`interface_help.rs:76–93`). Its
selected caller computes `okay` once and passes that same value to the reading,
its meter, and the helper (`character_health.rs:1395–1437`). The existing
`BodyRegion` is reexported from core physiology (`spacetimedb/types.rs:8–21`,
`spacetimedb/mod.rs:11,37`; `physiology.rs:188–248`). Earlier in that path,
the attribute rail passes region ordinals 6, 4, 5, 0, 1, 2, 3 alongside
names, slugs and health (`character_health.rs:1192–1235,1236–1248`). The
`region: usize` travels through helpers (`:1260–1267,1291–1297,1321–1327`),
is classified by `BodyRegion::ALL[region]` (`:1360–1373`), and addresses
regional arrays (`:1387–1395`) before the typed region reaches the assigned
view. The shown constants agree with `ALL`; no current mismatch or actual
failed execution has been demonstrated. The owner-preserving future direction
is to carry the region role through this producer chain and convert only for
actual indexed access, preserving all seven mappings. Its relation to other
ledger entries and any unique count are centrally unresolved.

The inventory key receives the same quantity/equipment flags used by the
selected table's matching columns (`inventory_browser.rs:35–38,71–97`), so
the shown path establishes no legend-versus-column mismatch. String labels,
CSS class names, icon names and `Markup` are presentation/native boundaries in
the displayed operations; that does not settle every unseen consumer.

## Lens 2: existing owners

`BodyRegion` already owns the semantic variants and `index()`/`slug()`
(`physiology.rs:188–248`); the health path above reconstructs it after raw
ordinal propagation. `UnitInterval` is a possible finite [0,1] numeric leaf
(`unit_interval.rs:9–35`), but it rejects nonfinite values and out-of-range
inputs, whereas the displayed health presentation clamps raw database values
(`character_health.rs:1334,1368`; generated `character_limbs_type.rs:9–18`).
Whether and where this leaf fits depends on the intended clamp, nonfinite and
unavailable-value policy. A simple replacement is not established as
behavior-preserving. Historical q2453 is a separate prior Lens 2 review.

## Lens 5: aggregate and lifecycle states

`regional_reading` accepts region, reading, numeric soundness and prebuilt
bar as separate values. The selected caller coordinates the reading and meter
using `okay`; independently mismatched arguments are representable internally,
but no actual caller producing one was found in the bounded source search.
The raw region, displayed name/slug and health are independently passed in
the related producer chain; the shown seven tuples match the enum order,
so a mismatch is a representable maintenance risk rather than observed data.
The existing missing-limb-projection and missing-injury-observation records
remain distinct availability questions.

There is also a conditional control-lifecycle relationship. The applicant
statistics panel contains both attribute and skill label controls
(`character_details.rs:39–66`; `character_health.rs:1216`;
`character_skills.rs:1023–1025`). Applicant markup places the panel in a
template (`recruitment.rs:352–363`) and the click handler later clones it
into the left sidebar (`party-recruitment.js:81–93`). `stats-panels.js:4–17,
20–22` installs listeners on controls present at initial mount or a later
`strategic-page-mounted` event. The shown clone callback does not itself send
that event. If no later mount or separate binding occurs, those inserted
controls have no listener from this module. If both controls are subsequently
mounted within the same `aside`, they choose the same panel and independently
set one `data-stat-labels-visible` attribute while using distinct saved keys;
the later update governs the shared CSS target (`stats.css:13–14,21–24,33–39`).
This is conditional source reasoning, not a browser observation: host markup,
lifecycle events, actual effect, and potential pre-existing aliases remain
open.

## Lens 6: type ownership

The assigned helper defines no competing bespoke region type. The selected
imports trace to core `BodyRegion`, and the solver-style numeric-leaf analogy
is not assumed: `UnitInterval` only supplies a reusable invariant if the
health presentation's distinct role and admission policy fit. No duplicate
or misplaced type owner is established across the displayed ranges.

## Historical evidence and limits

Original q2453 records Root's independent 6533 Lens 2 read of lines 1–119;
e275 is a qualified reuse of identical bytes, with no fresh current read.
Q3298 separately records Root's independent Lens 3 6533 read and e275 reuse.
Original role 2394 has a Lens 11 60–94 read and same-lens connected
1–59/95–119 read in `READ-L11-390`; none transfers to another lens. The
original and reconstructed whole 059 streams differ despite equality of the
selected parsed records, and no historical record is promoted to checkpoint
3821. The captured committed and observed-working ledger snapshots happened
to match; later working state is not asserted.

The source spans, support windows, original queues and receipts, offline Git
proofs, and qualifications are recoverable in the accompanying restricted
and public evidence. No source, shader, macro, browser, fixture, test or
product execution occurred. This is not a global lens closure, alias decision,
unique defect count, implementation or product validation.
