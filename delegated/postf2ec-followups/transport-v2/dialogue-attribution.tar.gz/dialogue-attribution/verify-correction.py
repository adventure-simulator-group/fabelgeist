#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def manifest(d):
 m=json.loads((d/'MANIFEST.json').read_bytes());assert {str(f.relative_to(d)) for f in d.rglob('*') if f.is_file() and f.name!='MANIFEST.json'}==set(m['files'])
 for n,v in m['files'].items():
  f=d/n;b=f.read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode']
a=argparse.ArgumentParser();a.add_argument('--predecessor',type=Path);a.add_argument('--private',type=Path);a.add_argument('--followup',type=Path);a=a.parse_args();manifest(p);print('correction manifest: pass')
c=json.loads((p/'CORRECTION.json').read_bytes());assert H((p/'HISTORIC-AUTHORITY.json').read_bytes())=='76c75c561d1eae5eafa1cb4d9246bc21164f7a7f2ab629c401ca091b61bad35a';print('exact registration authority bytes: pass')
if a.predecessor:
 assert H((a.predecessor/'MANIFEST.json').read_bytes())==c['predecessor_public_manifest_sha256'];manifest(a.predecessor);assert c['changes'][0]['old_exact'] in (a.predecessor/'REVIEW-L6.md').read_text();assert c['changes'][1]['old_exact']==json.loads((a.predecessor/'HISTORICAL-ATTRIBUTION.json').read_bytes())['historical_sources']['Lens6'];print('predecessor manifest and original wording: pass')
else:print('NOT CHECKED: predecessor manifest and original wording')
if a.private:
 assert H((a.private/'MANIFEST.json').read_bytes())=='d10d86ab4e8988a917dc00d8eaf149c1ca24872ae61be53ef2b2a1910df01292';manifest(a.private);b=(a.private/'historical/evidence__audit05__overlay-contracts-014.json').read_bytes();assert H(b)=='7a766d76282c6a996289bd7eb5a915796e451fe57366acfab97403a2dd363071';x=json.loads(b);r=x['members'][3];s=json.loads((p/'OVERLAY-SUMMARY.json').read_bytes());assert x['authority']=='raw-overlay-authority-proof-001.json' and r['registration']['id']==s['registration_id'] and r['registration']['audit_owner']==s['registration_audit_owner'] and r['registration']['material_ranges']==s['registered_ranges'] and r['personally_read_registered_ranges']==s['enclosing_personally_read_ranges'];print('restricted predecessor and overlay member: pass')
else:print('NOT CHECKED: restricted predecessor and exact overlay member')
if a.followup:
 assert H((a.followup/'MANIFEST.json').read_bytes())==c['restricted_followup_manifest_sha256'];manifest(a.followup);assert (a.followup/'PRIVATE-AUTHORITY.json').read_bytes()==(p/'HISTORIC-AUTHORITY.json').read_bytes();print('restricted follow-up authority copy: pass')
else:print('NOT CHECKED: restricted follow-up authority copy')
print('Evidence identity only; no product validation or checkpoint3821 recovery.')
