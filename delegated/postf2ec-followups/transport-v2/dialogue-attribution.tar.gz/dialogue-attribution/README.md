# Attribution correction for dialogue route lens six

This successor corrects the separately sealed predecessor without changing it. Camera is identified as the registration audit owner; the surrounding personally-read field is separate and its reader is not identified by the inspected member and registration-provenance authority. Exact original and follow-up evidence remain separately held.

Run `python3 verify-correction.py` for local manifest and authority bytes. `--predecessor DIRECTORY` checks the predecessor report and historical wording; `--private DIRECTORY` checks the exact restricted overlay member; `--followup DIRECTORY` checks the separate restricted authority receipt. Without those optional inputs those checks are not performed. This verifies evidence identity, not semantic conclusions or product behavior.
