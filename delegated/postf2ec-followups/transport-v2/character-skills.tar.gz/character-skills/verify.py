#!/usr/bin/env python3
"""Read-only evidence/recorded scope replay; no product execution."""
import argparse,hashlib,gzip,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
def J(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(kind,b):return hashlib.sha1(kind+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(x,m):
 if not x:raise ValueError(m)
def safe(root,n):
 q=pathlib.PurePosixPath(n);need(not q.is_absolute() and '..' not in q.parts,'path');return root.joinpath(*q.parts)
def tree(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'tree bounds');n=b[a+1:z].decode();need(n not in d,'duplicate name');d[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repository');a=ap.parse_args();m=J(P/'MANIFEST.json');files={f.relative_to(P).as_posix() for f in P.rglob('*') if f.is_file() and f!=P/'MANIFEST.json'};need(files==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'public file set')
 for n,v in m['files'].items():
  f=safe(P,n);b=f.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode'],'file '+n)
 for x in J(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(x['name']+'.md')).read_bytes();need(sh(b)==x['sha256'] and len(b.splitlines())==x['lines'],'skill identity')
 assigned=J(P/'SOURCE-REGISTRATION.json');expected=[(3377,1),(3378,2),(3380,5),(3381,6)];need([(r['queue'],r['lens']) for r in assigned['lenses']]==expected,'lenses');need([(r['queue'],r['lens']) for r in J(P/'ASSESSMENTS.json')['assessments']]==expected,'per-lens assessments');receipt=J(P/'SOURCE-READ-RECEIPT.json');need(receipt['actual_display_ranges']==[[1,2355]] and receipt['unread_complement']==[[2356,3812]],'assigned scope');need(receipt['sources']==assigned['sources'],'assigned prereg')
 bodies=[]
 for x in assigned['sources']:
  b=(P/'sources'/(x['label']+'.rs')).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(b.decode().splitlines())==x['EOF']==3812,'assigned identity');bodies.append(b)
 need(len(bodies)==3 and len(set(bodies))==1,'one shared physical body justified');lines=bodies[0].decode().splitlines();seen=set()
 for x in receipt['views']:
  lo,hi=x['range'];v=safe(P,x['file']).read_bytes();need(sh(v)==x['sha256'] and v.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(lo,hi+1)] and x['registration_mtime_ns']<=x['view_created_mtime_ns'],'assigned view');need(not seen.intersection(range(lo,hi+1)),'view overlap');seen.update(range(lo,hi+1))
 need(len(receipt['views'])==24 and seen==set(range(1,2356)),'actual shared view coverage')
 sr=J(P/'SUPPORT-READ-RECEIPT.json');need(len(sr['rows'])==6,'support count');sv=0
 for r in sr['rows']:
  b=(P/'sources'/('support-'+r['label']+'.rs')).read_bytes();ls=b.decode().splitlines();need(sh(b)==r['sha256'] and oid(b'blob',b)==r['git_blob'] and len(ls)==r['EOF'],'support identity');reg=J(P/r['registration']);x=next(x for x in reg['rows'] if x['label']==r['label']);need(x['registered_ranges']==r['actual_ranges'] and x['revision']==r['revision'] and x['path']==r['path'],'support prereg');read=set()
  for v in r['views']:
   lo,hi=v['range'];raw=safe(P,v['path']).read_bytes();need(sh(raw)==v['sha256'] and raw.decode().splitlines()==[f'{i}: {ls[i-1]}' for i in range(lo,hi+1)] and r['registration_mtime_ns']<=v['view_created_mtime_ns'],'support view');read.update(range(lo,hi+1));sv+=1
  need(read=={i for lo,hi in r['actual_ranges'] for i in range(lo,hi+1)},'support read coverage')
 proofs=J(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==10,'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'path depth')
  for part,step in zip(parts,x['tree_chain']):
   need(cur==step['tree'] and part==step['entry'],'tree step');b=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',b)==cur,'tree hash');mode,cur=tree(b)[part];need(mode==step['mode'] and cur==step['object'],'tree entry')
  need(cur==x['blob'],'tree blob');
  if x['role']=='source':need(oid(b'blob',safe(P,x['source_file']).read_bytes())==cur,'source blob')
  elif a.restricted:
   b=safe(a.restricted,x['source_file']).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==cur,'restricted evidence blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository tree')
 catalog=J(P/'CATALOG-RESULT.json')['role52_matches'];need([(x['index'],x['lens']) for x in catalog]==expected and all(x['equality_selected'] for x in catalog),'catalog selection')
 hist=False
 if a.restricted:
  h=a.restricted/'historical';b=(h/'previous-private-manifest.json').read_bytes();need(sh(b)=='f39120ab10781981d16f42ddecdae143871d3178b15d9f95ad531ed76ca45e27','previous manifest');old=json.loads(b)['files'];queues=[]
  for n,prior in [('queue-original.json','historical/queue-original-56f.json'),('queue-reconstructed.json','historical/queue-reconstructed-dac7d.json')]:
   b=(h/n).read_bytes();need(sh(b)==old[prior]['sha256'],'historical queue original/reconstruction');queues.append(json.loads(b))
  b=(h/'queue-published.json').read_bytes();need(sh(b)==J(P/'CATALOG-RESULT.json')['published_queue_sha256'],'published queue');queues.append(json.loads(b));need((h/'queue-original.json').read_bytes()!=(h/'queue-reconstructed.json').read_bytes(),'original/reconstructed distinct')
  for x in catalog:
   e=[q['entries'][x['index']] for q in queues];need(e[0]==e[1]==e[2] and e[0]['lens']==x['lens'] and e[0]['contract_id']==x['id'],'selected record')
  for idx in (199,200,540,543,2455,2491,3300):need(queues[0]['entries'][idx]==queues[1]['entries'][idx]==queues[2]['entries'][idx] and J(h/f'q{idx}-original.json')==queues[0]['entries'][idx],'history selected row')
  histm=J(h/'prior-historical-manifest.json');records={x['original_transport_path']:x for x in histm['records']}
  for x in J(P/'HISTORICAL-INPUT-CAPTURE.json')['historical_records']:
   b=(h/f"prior-receipt-{x['index']:02d}.json").read_bytes();need(sh(b)==x['sha256']==records[x['historical_path']]['sha256'] and oid(b'blob',b)==x['git_blob'],'historical receipt')
  b=(h/'registry-original.json.gz').read_bytes();need(sh(b)=='a90f280f820e17643933b87aee4587c0ba47f8feec35bd9db61611653bc14063','stored registry');raw=gzip.decompress(b);need(sh(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f','decoded registry');reg=json.loads(raw)
  for i in (465,2402):need(J(h/f'registry-role{i}.json')==reg['files'][i] and reg['files'][i]['sha256']==assigned['sources'][0]['sha256'],'registry role source')
  need(reg['files'][465]['snapshot']=='physical-p16' and reg['files'][2402]['snapshot']=='pr-working','registry snapshot difference');need((h/'archived-original-object.rs').read_bytes()==bodies[0],'archived original object')
  l2=J(h/'prior-receipt-04.json')['rows'][6];l2now=J(h/'prior-receipt-07.json')['rows'][6];l3=J(h/'prior-receipt-08.json')['rows'][6];l3now=J(h/'prior-receipt-10.json')['rows'][7];need(l2['fresh_personal_ranges']==[[1,1529],[1559,2355]] and l2['qualified_inherited_same_lens_ranges']==[[1530,1558]] and l2now['fresh_personal_ranges']==[] and l2now['qualified_same_lens_reuse_ranges']==[[1,2355]],'historical L2 attribution');need(l3['fresh_personal_ranges']==[[1,2355]] and l3now['fresh_personal_ranges']==[] and l3now['qualified_reuse_ranges']==[[1,2355]],'historical L3 attribution')
  c=(h/'baseline-committed.json').read_bytes();w=(h/'baseline-observed.json').read_bytes();need(sh(c)=='a402d49eb6dab3cd9182e16db92d2ea91896c761d02c87b2fcdad9d50efa7276' and sh(w)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041' and c!=w,'distinct baseline');need(J(h/'ledger30-committed.json')['id']=='REVIEW-TERRAIN-FAMILY-HOURS-CARDINALITY-001' and J(h/'ledger842-committed.json')['id']=='SEGOVB-L12-PROFESSION-PREVIEW-REWARD-ENUM-STRING','ledger pointers')
  prev=(h/'prior-self-public-manifest.json').read_bytes();need(sh(prev)=='5de58041eeb586e806718791f313a880c7e9f97f692a81a41345af62a4c08b6a' and sh((h/'prior-self-read-receipt.json').read_bytes())==json.loads(prev)['files']['READ-RECEIPT.json']['sha256'],'prior independent support')
  roots={}
  for x in J(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(oid(b'commit',b)==x['revision'] and sh(b)==x['payload_sha256'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit proof');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit tree binding');hist=True
 print(json.dumps({'result':'pass','public_files':len(files),'assigned_shared_display_chunks':len(receipt['views']),'support_display_chunks':sv,'source_revision_path_proofs':len(proofs),'restricted_history_checked':hist,'repository_binding_checked':bool(a.repository),'qualification':'Read-scope and evidence integrity only; source meaning, runtime behavior, global aliases and closure remain separately assessed.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
