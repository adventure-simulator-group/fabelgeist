#!/usr/bin/env python3
"""Evidence-only replay; never executes product code, builds, tests or probes."""
import argparse,hashlib,json,pathlib,subprocess,sys
if sys.flags.optimize:raise SystemExit('Optimized execution is unsupported.')
P=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def safe(root,n):
 q=pathlib.PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts;return root.joinpath(*q.parts)
def check_manifest(root,expected=None):
 mb=(root/'MANIFEST.json').read_bytes()
 if expected:assert H(mb)==expected
 m=json.loads(mb);fs={x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_file() and x!=root/'MANIFEST.json'}
 assert fs==set(m['files']) and not any(x.is_symlink() for x in root.rglob('*'))
 for n,x in m['files'].items():
  f=safe(root,n);b=f.read_bytes();assert H(b)==x['sha256'] and len(b)==x['bytes'] and (f.stat().st_mode&0o777)==x['mode']
 return m
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);assert z+21<=len(b);n=b[a+1:z].decode();assert n not in out;out[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def prove(root,path,data):
 for part in path.split('/'):
  tb=(P/'trees'/(root+'.tree')).read_bytes();assert oid('tree',tb)==root;mode,root=tree(tb)[part]
 assert mode=='100644' and oid('blob',data)==root
try:
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);a=ap.parse_args();assert not a.anchors or a.private
 check_manifest(P);print('public file set, modes, lengths and hashes: pass')
 reg=json.loads((P/'SOURCE-004-REG.json').read_bytes());rows={x['path']:x for x in json.loads((P/'SOURCE-004-RESULT.json').read_bytes())};root=json.loads((P/'SCOPE.json').read_bytes())['pinned_source_root_tree']
 assert root=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f' and reg['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009'
 for r in reg['views']:
  row=rows[r['path']];b=safe(P,row['file']).read_bytes();assert H(b)==row['sha256'] and len(b.splitlines())==row['EOF'];prove(root,r['path'],b);ls=b.decode().splitlines(keepends=True)
  for lo,hi in r['ranges']:
   name=r['path'].replace('/','__')+f'-{lo}-{hi}.txt';assert (P/'source-displays'/name).read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
 r=json.loads((P/'SOURCE-005-SUPPLEMENT-REG.json').read_bytes());ls=safe(P,rows[r['path']]['file']).read_text().splitlines(keepends=True)
 for lo,hi in r['ranges']:assert (P/'source-displays'/(r['path'].replace('/','__')+f'-{lo}-{hi}.txt')).read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
 print('source root-tree/blob proofs and independently registered display files: pass')
 c=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes());assert c['restricted_manifest_sha256']=='4877e6a5e16541cc5228eeedf3809e64315c765762d642cfbbc7025f56a1080d'
 originals={}
 for x in c['files']:
  b=safe(P,x['public_file']).read_bytes();assert H(b)==x['public_whole_file_sha256'] and len(b)==x['public_bytes'];origins=0
  for span in x['replacements']:
   assert span['offset']>=origins and span['length']>0 and span['offset']+span['length']<=x['original_bytes'];origins=span['offset']+span['length']
  originals[x['public_file']]=x['original_whole_file_sha256']
 j2=json.loads((P/'draft/DRAFT-v2.json').read_bytes());j3=json.loads((P/'draft/DRAFT-v3.json').read_bytes());c2=json.loads((P/'draft/DRAFT-v2-CORRECTION.json').read_bytes());c3=json.loads((P/'draft/DRAFT-v3-CORRECTION.json').read_bytes());assert j2['predecessor_draft_sha256']==c2['predecessor_sha256']==originals['draft/DRAFT-v1.json'] and c2['successor_sha256']==j3['predecessor_draft_sha256']==c3['predecessor_sha256']==originals['draft/DRAFT-v2.json'] and c3['successor_sha256']==originals['draft/DRAFT-v3.json']
 print('reconstructed output identities, replacement bounds and original draft hash chain: pass')
 if a.private:
  check_manifest(a.private,c['restricted_manifest_sha256'])
  for x in c['files']:
   orig=safe(a.private,x['restricted_source']).read_bytes();assert H(orig)==x['original_whole_file_sha256'] and len(orig)==x['original_bytes'];parts=[];pos=0
   for span in x['replacements']:
    lo=span['offset'];parts.extend([orig[pos:lo],span['replacement'].encode()]);pos=lo+span['length']
   parts.append(orig[pos:]);assert b''.join(parts)==safe(P,x['public_file']).read_bytes()
  cmd=[sys.executable,str(a.private/'verify-review-v2.py')]
  if a.anchors:cmd.extend(['--anchors',str(a.anchors)])
  run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert run.returncode==0
  print('separately held restricted manifest, exact reconstructions and nested evidence replay: pass')
  if not a.anchors:print('NOT CHECKED: full queue stream membership (supply separately held --anchors).')
 else:print('NOT CHECKED: private original bytes, original revision commit binding, historical selections and exact reconstructions (supply --private and --anchors).')
 print('No product behavior, reachability, repairs, global closure or missing checkpoint recovery is asserted.')
except Exception as e:
 print('evidence verification failed:',type(e).__name__,file=sys.stderr);sys.exit(1)
