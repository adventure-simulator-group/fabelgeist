# Independent review of the later color draft

Reviewer: [independent reviewer]. The separately delegated four-lens reviews were
performed by [delegate]; the central drafts and selected 95e displays
were prepared by [coordinator]. This review addresses only the cited claims and their
provenance, not disposition of an entire lens, queue or defect count. The working
authority is pinned commit 95e63628f9d70b8dd6e6fede64334696c6995009.

## Conclusions and changes

I checked the v1 registrations and exact source windows against the copied
95e sources and independently registered my own source windows. q3243 and
q3255 are Lens 1, and q3246 and q3258 are Lens 5. At the ede12 committed
checkpoint the reconstructed 059 reconciliation marks all four unassessed; the
central record is a proposal outside that freeze. The separate delegate's
recorded registered full-file views and historical Lens 3 evidence remain
separately attributed. Matching file identity is not clean-worktree proof.

For a symbolic 3x3 NV12 image with a 13-byte YUV buffer and sufficiently large
RGBA buffer, the wrapper divides it into 9 Y bytes and 4 UV bytes; the decoder
reaches UV index 4 at y=2,x=0 after earlier assignments. The encoder writes Y,
then UV index 3, before attempting index 4. Width-byte row stride makes row 0
last V and row 1 first U both UV offset 3. See yuv.rs:54-94,147-168,251-327;
conversion.rs:166-246. This is a source-level conditional calculation, not a
shown reachable panic or a runtime result. The wrapper admits larger YUV
buffers too; supported odd dimensions and actual callers remain open. q3145
and ledger 495 separately concern YUV chroma extent, including I420 floor/ceil;
q147/ledger 493 concerns early same-format success. No alias or count follows.

The v1 encoder citation omitted the function header. V2 adds separately
registered yuv.rs:245-263 and cites 251-327. For custom primaries all x=y=0.25,
the basis columns coincide and are finite; inversion at space.rs:145-228 and
231-310 returns None. to_xyz_matrix substitutes identity for the inverse of
the basis, not necessarily for the final product. from_xyz_matrix has another
fallback. V2 narrows v1's overbroad finite/nonzero-y statement accordingly.
The prior Adler q148/ledger 494 remains a historical family, not a new count.
Allowed custom inputs and effects remain open; ACES blue has negative y, so a
blanket positivity rule is not established.

The composition Bt709 -> LinearSrgb -> Srgb in space.rs:72-95, paired with
different transfer functions in transfer.rs:120-164 and conversion.rs:107-149,
loses the original encoded-space identity if reversible composition is desired.
Whether callers expect canonicalization or reversibility remains open. Ledger
496 names missing linear variants for DCI-P3 and AdobeRGB; relationship is
context, not a demonstrated alias or common defect count.

V3 changes the buffer sentence to say a buffer of exactly 13 bytes is accepted,
with sufficiently large RGBA, without asserting larger ones are rejected. It
also expressly retains the original q148 space row's null recorded revision,
Git path and attribution; the separately captured Adler READ-L11-356 /sources/1
records a fresh 1-356 read. Matching later source bytes do not supply those null
fields. Both v2 changes remain. My bounded v3 spot-check found no remaining
contradiction in these corrected statements; this is not adoption or full
validation of the draft.

## Provenance and limits

The original 059 and reconstructed queue streams have different whole-file
identities; the separately selected parsed entries match and the selected exact
raw array slices were replayed against separately held streams. Root's 6533
Lens 3 personal reads and e275 qualified reuse are not new personal reads in
another lens. q148 remains Adler-attributed as recorded above. Neither later
work nor earlier recovered records become checkpoint 3821, whose original
export remains missing. Reconstructed records, recovered originals, historical
summaries, and newly assessed work remain distinct. All 73 nontext or
no-positive-EOF obligations remain open; no global completion is inferred.

The coordinator reports that its registered line-numbered windows were printed
without truncation. Their stored bytes and prospective registrations were
independently verified; there is no separately signed or independent receipt of
the coordinator display event. The delegate's recorded personal displays are
attestations, not automatically inferred from file existence.

The first full q148 display was truncated; a separately registered bounded
redisplay addressed the fields used here. A later display of portions of the two
already copied delegate proof files lacked its own prospective registration and
was truncated; it is retained uncredited, followed by a separately registered
bounded metadata display. See HISTORY-008-TRUNCATION.json and
TREE-012-UNREGISTERED-TRUNCATION.json. Both delegates' inspected private
custody verifiers subsequently passed, including their restricted streams,
commit/tree proofs and earlier evidence identities. A small separately sealed
copy of shared d7a5 committed evidence is included; complete delegate originals
and full queue streams remain external anchors. Source execution, repairs,
product tests, builds and probes were not performed.
