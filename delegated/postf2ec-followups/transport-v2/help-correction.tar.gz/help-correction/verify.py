#!/usr/bin/env python3
"""Read-only check of the wording correction and prior registered views."""
import argparse,json,hashlib,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def need(x,msg):
 if not x:raise ValueError(msg)
def main():
 a=argparse.ArgumentParser();a.add_argument('--prior',required=True,type=pathlib.Path);a=a.parse_args();m=json.loads((P/'MANIFEST.json').read_bytes());files={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(files==set(m['files']),'manifest set')
 for n,v in m['files'].items():
  b=(P/n).read_bytes();need(sha(b)==v['sha256'] and len(b)==v['bytes'],'file identity '+n)
 r=json.loads((P/'REGISTRATION.json').read_bytes());prior=(a.prior/'MANIFEST.json').read_bytes();need(sha(prior)==r['prior_public_manifest_sha256'],'prior manifest');pm=json.loads(prior)['files'];ss=json.loads((P/'SELECTED-VIEWS.json').read_bytes())['views'];need(len(ss)==3,'selected views')
 for row in ss:
  b=(a.prior/row['path']).read_bytes();need(sha(b)==row['view_sha256']==pm[row['path']]['sha256'],'prior view');selected=[]
  for line in b.decode().splitlines():
   n=int(line.split(':',1)[0])
   if any(lo<=n<=hi for lo,hi in row['ranges']):selected.append(line)
  need(selected==row['selected_lines'],'selected lines')
 h='\n'.join(ss[0]['selected_lines']);s='\n'.join(ss[1]['selected_lines']);need('let Some(attributes) = attributes else' in h and 'return html! {};' in h and '@if let Some(skills) = skills' in s and 'interface_help::skill_key()' in s,'presence conditions')
 print(json.dumps({'result':'pass','prior_manifest_bound':True,'selected_existing_view_count':len(ss),'qualification':'Evidence only; no new source read, runtime conclusion, alias or lens closure.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('correction verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
