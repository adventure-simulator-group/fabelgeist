#!/usr/bin/env python3
"""Read-only evidence integrity and scoped display replay; never runs product code."""
import argparse,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
def J(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(x,m):
 if not x:raise ValueError(m)
def safe(r,n):
 p=pathlib.PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return r.joinpath(*p.parts)
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'tree bounds');name=b[a+1:z].decode();need(name not in out,'duplicate tree entry');out[name]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def runs(s):
 out=[]
 for i in sorted(s):
  if out and out[-1][1]+1==i:out[-1][1]=i
  else:out.append([i,i])
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repository');a=ap.parse_args();m=J(P/'MANIFEST.json');files={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(files==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest set')
 for n,v in m['files'].items():
  f=safe(P,n);b=f.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode'],'manifest '+n)
 for x in J(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(x['name']+'.md')).read_bytes();need(sh(b)==x['sha256'] and len(b.splitlines())==x['lines'],'skill identity')
 expected=[(3365,1),(3366,2),(3368,5),(3369,6)];need([(r['queue'],r['lens']) for r in J(P/'SOURCE-REGISTRATION.json')['assigned_own_lenses']]==expected,'lens assignment');need([(r['queue'],r['lens']) for r in J(P/'ASSESSMENTS.json')['assessments']]==expected,'lens assessments')
 rr=J(P/'READ-RECEIPT.json');union={};views=0
 for r in rr['rows']:
  b=safe(P,r['source_file']).read_bytes();lines=b.decode().splitlines();need(sh(b)==r['source_sha256'] and oid(b'blob',b)==r['git_blob'] and len(lines)==r['EOF'],'source object');d=J(P/r['registration'])
  if r['role']=='assigned':
   e=next(x for x in d['sources'] if x['label']==r['label']);need(e['revision']==r['revision'] and e['path']==r['path'] and e['sha256']==r['source_sha256'] and e['planned_ranges']==r['registered_ranges'],'assigned prereg')
  elif 'rows' in d:
   e=next(x for x in d['rows'] if 'support-'+x['label']==r['label']);need(e['revision']==r['revision'] and e['path']==r['path'] and e['sha256']==r['source_sha256'] and e['registered_ranges']==r['registered_ranges'],'support prereg')
  else:need(d['revision']==r['revision'] and d['path']==r['path'] and d.get('registered_ranges',d.get('ranges'))==r['registered_ranges'],'single prereg')
  allowed={i for lo,hi in r['registered_ranges'] for i in range(lo,hi+1)};seen=set()
  for w in r['views']:
   lo,hi=w['range'];need(1<=lo<=hi<=len(lines),'view bounds');v=safe(P,w['file']).read_bytes();need(sh(v)==w['sha256'] and v.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(lo,hi+1)],'view bytes');seen.update(range(lo,hi+1));views+=1
  need(allowed==seen,'registered versus displayed range');u=union.setdefault((r['revision'],r['path']),{'eof':len(lines),'seen':set()});u['seen'].update(seen)
 for c in rr['coverage']:
  u=union[(c['revision'],c['path'])];need(runs(u['seen'])==c['displayed_union'] and runs(set(range(1,u['eof']+1))-u['seen'])==c['unread_complement'],'coverage union')
 need(len(union)==len(rr['coverage'])==16,'coverage count');assigned=[r for r in rr['rows'] if r['role']=='assigned'];need(len(assigned)==3 and all(r['EOF']==1065 and runs({i for v in r['views'] for i in range(v['range'][0],v['range'][1]+1)})==[[1,1065]] for r in assigned),'full assigned scopes');need(all(x['registration_mtime_ns']<=x['view_mtime_ns'] for x in J(P/'READ-CHRONOLOGY.json')['rows']),'chronology metadata')
 proofs=J(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==18,'proof count')
 for p in proofs:
  cur=p['root_tree'];parts=p['path'].split('/');need(len(parts)==len(p['tree_chain']),'tree path depth')
  for part,step in zip(parts,p['tree_chain']):
   need(step['tree']==cur and step['entry']==part,'tree path');raw=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',raw)==cur,'tree hash');mode,cur=tree(raw)[part];need(mode==step['mode'] and cur==step['object'],'tree entry')
  need(cur==p['blob'],'tree blob')
  if p['role']=='source':need(oid(b'blob',safe(P,p['source_file']).read_bytes())==cur,'source blob')
  elif a.restricted:
   b=safe(a.restricted,p['source_file']).read_bytes();need(sh(b)==p['sha256'] and oid(b'blob',b)==cur,'historical evidence blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',p['revision']+'^{tree}'],text=True).strip()==p['root_tree'],'repository tree binding')
 selections=J(P/'QUEUE-SELECTION.json')['rows'];need([(x['index'],x['lens']) for x in selections]==expected and all(x['parsed_equal_original_reconstructed_published'] for x in selections),'queue selection')
 checked=False
 if a.restricted:
  h=a.restricted/'historical';pm=(h/'prior-private-manifest.json').read_bytes();need(sh(pm)=='d08d5a727218db10361759f24e5c40e74a368806bc81928170dfcfd7bcb85548','prior private manifest');old=json.loads(pm)['files'];qs=[]
  for n in ('queue-original-56f.json','queue-reconstructed-dac7d.json'):
   b=(h/n).read_bytes();need(sh(b)==old['historical/'+n]['sha256'],'original or reconstructed whole queue anchor');qs.append(json.loads(b))
  b=(h/'queue-published.json').read_bytes();need(sh(b)=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173','published queue identity');qs.append(json.loads(b));need((h/'queue-original-56f.json').read_bytes()!=(h/'queue-reconstructed-dac7d.json').read_bytes(),'whole queue distinction')
  for x in selections:
   e=[q['entries'][x['index']] for q in qs];need(e[0]==e[1]==e[2] and e[0]['lens']==x['lens'] and e[0]['contract_id']==x['id'],'selected queue entry');need(sh((json.dumps(e[0],indent=2,ensure_ascii=False)+'\n').encode())==x['selected_normalized_sha256'],'selected normalized hash')
  for idx in (192,201,542,2454,3299):need(qs[0]['entries'][idx]==qs[1]['entries'][idx],'historical related queue selection')
  names=['REGISTRATION-ROOT-L3-EXT-046-055.json','READ-ROOT-L3-EXT-046-055.json','REGISTRATION-ROOT-L3-CURRENT-006.json','READ-ROOT-L3-CURRENT-006.json','REGISTRATION-ROOT-L2-EXT-045-051.json','READ-ROOT-L2-EXT-045-051.json','READ-ROOT-L2-CURRENT-010.json']
  for n in names:
   b=(h/('role0051-receipt-'+n)).read_bytes();need(sh(b)==old['historical/receipt-'+n]['sha256'],'prior source receipt')
  l3=J(h/'role0051-receipt-READ-ROOT-L3-EXT-046-055.json')['rows'][5];c3=J(h/'role0051-receipt-READ-ROOT-L3-CURRENT-006.json')['rows'][6];l2=J(h/'role0051-receipt-READ-ROOT-L2-EXT-045-051.json')['rows'][5];c2=J(h/'role0051-receipt-READ-ROOT-L2-CURRENT-010.json')['rows'][5]
  need(l3['fresh_personal_ranges']==l2['fresh_personal_ranges']==[[1,1065]] and c3['fresh_personal_ranges']==c2['fresh_personal_ranges']==[] and c3['qualified_reuse_ranges']==c2['qualified_same_lens_reuse_ranges']==[[1,1065]],'historical fresh versus reuse')
  need((h/'recovered-original-role0051.object').read_bytes()==(P/'sources/old-6533.rs').read_bytes(),'archived original object');need(sh((h/'early-READ-L11-385.json').read_bytes())=='051770b7513c96ff3e0f8146360e3bf4a68d79485d6d2355e1d3b7712aa4985d','Adler batch385');need(sh((h/'early-READ-L11-391.json').read_bytes())=='0398fa3d0606b40421fea5819ebeea540f55962635af8657b464de028a845582','Adler batch391')
  need(sh((h/'prior-BUNDLE-MANIFEST.json').read_bytes())=='a4cf65a38dd29c8c3cd1e7449f575e8b01ba741b9e77e36e6102646534ddbdac','prior own source bundle');prior=J(h/'prior-BUNDLE-MANIFEST.json');need(any(x['sha256']==sh((h/'prior-read-receipt.json').read_bytes()) for x in prior['files']),'prior own receipt');need(sh((h/'prior-q0049-public-manifest.json').read_bytes())=='793af46b057c42b9c117cc3de19cd82ef89ac6f740023051da928dd0e34715ea','prior role0049 manifest');p4=J(h/'prior-q0049-public-manifest.json');need(sh((h/'prior-q0049-read-receipt.json').read_bytes())==p4['files']['READ-RECEIPT.json']['sha256'],'prior 0049 receipt')
  x=(h/'baseline-committed.json').read_bytes();y=(h/'baseline-observed-working.json').read_bytes();need(x==y and sh(x)=='a402d49eb6dab3cd9182e16db92d2ea91896c761d02c87b2fcdad9d50efa7276','captured ledger streams');ledger=json.loads(x)['newly_assessed_ledger']['entries'];need(ledger[781]['id']=='ADLER-L11-STRATEGIC-CLOCK-PROJECTION-ADMISSION' and ledger[836]['id']=='REVIEW-CHARACTER-STATS-ORGANIZATION-ABSENCE-95E','ledger relationships')
  roots={}
  for x in J(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(oid(b'commit',b)==x['revision'] and sh(b)==x['payload_sha256'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit identity');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit tree link');checked=True
 print(json.dumps({'result':'pass','public_files':len(files),'registered_display_chunks':views,'source_revision_pairs':len(union),'git_tree_path_proofs':len(proofs),'restricted_history_and_commit_proofs_checked':checked,'repository_binding_checked':bool(a.repository),'qualification':'Integrity and recorded display scopes only; not product validation, queue closure, alias or unique count.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
