#!/usr/bin/env python3
"""Read-only binding of the scan receipt to the public manifest."""
import argparse,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
def need(x,msg):
 if not x:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument("--public",required=True,type=pathlib.Path);a=a.parse_args();m=json.loads((P/"MANIFEST.json").read_bytes());files={p.relative_to(P).as_posix() for p in P.rglob("*") if p.is_file() and p!=P/"MANIFEST.json"};need(files==set(m["files"]),"receipt file set")
 for n,v in m["files"].items():
  b=(P/n).read_bytes();need(sha(b)==v["sha256"] and len(b)==v["bytes"],"receipt file identity")
 r=json.loads((P/"REPORT.json").read_bytes());need(sha((a.public/"MANIFEST.json").read_bytes())==r["public_manifest_sha256"],"public manifest binding");need(r["scan"]["gpu"]["forbidden_matches"]==r["scan"]["q2332"]["matches"]==r["scan"]["059"]["matches"]==0,"recorded scan findings");c=subprocess.run([sys.executable,str(a.public/"verify.py")],capture_output=True,text=True);need(c.returncode==0,"public evidence verification");print(json.dumps({"result":"pass","public_manifest_bound":True,"public_verify":json.loads(c.stdout),"qualification":"Scan results are receipts; this checker does not recompute private corpora."},sort_keys=True))
if __name__=="__main__":
 try:main()
 except Exception as e:print("receipt verification failed:",type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
