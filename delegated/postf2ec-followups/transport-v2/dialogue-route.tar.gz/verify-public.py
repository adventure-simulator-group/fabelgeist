#!/usr/bin/env python3
"""Evidence-only replay; never runs product, tests, fixtures, browsers, builds or macros."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);d[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return d
def prove(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/f'{t}.tree').read_bytes();assert oid('tree',b)==t;mode,t=tree(b)[part]
 assert mode=='100644' and oid('blob',data)==t
def manifest(d):
 m=json.loads((d/'MANIFEST.json').read_bytes());found={str(f.relative_to(d)) for f in d.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};assert found==set(m['files'])
 for n,v in m['files'].items():
  f=d/n;b=f.read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode']
def windows(reg,by,default):
 for row in reg['windows']:
  ls=(P/by[row['path']]['file']).read_text().splitlines(keepends=True);folder=row.get('output_dir',default)
  for lo,hi in row['ranges']:
   n=f"{row['path'].replace('/','__')}-{lo}-{hi}.txt";assert (P/folder/n).read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: public packet manifest (--skip-manifest)')
else:manifest(P);print('public file set, sizes, modes and hashes: pass')
roots={'6533':'849ec1e8faca2236c7021893cda7a3f7cb5c72e8','e275':'7737c903f98397669c12da05475f759aa7fcfe73','95e':'1eec97de340d9b7debbb30ca0c0fb2240a73b93f'};allb=[]
for row in json.loads((P/'SOURCE-003-RESULT.json').read_bytes())['rows']:
 label=row['label'];assert row['chain'][0]['tree']==roots[label];b=(P/'source'/f'{label}.rs').read_bytes();assert H(b)=='c3dde45589069173a7b9c0b94f377424e3164e25dbdde70df99cc9d9870d3a56' and len(b.splitlines())==1897 and b.endswith(b'\n');prove(roots[label],'crates/strategic-web/src/routes/dialogue.rs',b);allb.append(b)
assert len(allb)==3 and allb[0]==allb[1]==allb[2];ls=allb[2].decode().splitlines(keepends=True);ranges=json.loads((P/'SOURCE-005-DISPLAY-REG.json').read_bytes())['ranges'];assert ranges[0][0]==1 and ranges[-1][1]==1897 and all(ranges[i][1]+1==ranges[i+1][0] for i in range(len(ranges)-1))
for lo,hi in ranges:assert (P/'displays'/f'shared-{lo}-{hi}.txt').read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
by={}
for name in ['ADJ-013-CAPTURE-RESULT.json','CATALOG-019-CAPTURE-RESULT.json','CLIENT-024-CAPTURE-RESULT.json']:
 for row in json.loads((P/name).read_bytes()):
  b=(P/row['file']).read_bytes();assert H(b)==row['sha256'] and oid('blob',b)==row['blob'] and len(b.splitlines())==row['EOF'];prove(roots['95e'],row['path'],b);by[row['path']]=row
for n,d in [('ADJ-014-DISPLAY-REG.json','adj-displays'),('ADJ-016-REG.json','adj-displays'),('ADJ-017-REG.json','adj-displays'),('CATALOG-020-DISPLAY-REG.json','catalog-displays'),('CATALOG-021-REG.json','catalog-displays'),('CLIENT-025-DISPLAY-REG.json','client-displays'),('CLIENT-026-REG.json','client-displays'),('SOCIAL-028-REG.json',None)]:windows(json.loads((P/n).read_bytes()),by,d)
names={1:'producer-propagation',2:'existing-type-owners',5:'aggregate-states',6:'type-ownership'}
for r in json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows']:assert r['name']==names[r['number']] and H((P/f"SKILL-L{r['number']}.md").read_bytes())==r['skill']['sha256']
assert H((P/'HISTORICAL-GROUP-242.json').read_bytes())=='997b99c50766b5d37faf27538f7a6587da8b2c9eeab6b31a1dfdc053a0c3fb6f'
print('selected root-tree/blob proofs, complete target and adjacent transcripts, four skill hashes and exact historic group: pass')
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if not a.private:print('NOT CHECKED: commit-to-root binding, original handoff map, full queue membership, remaining historical receipts, private reconstruction and committed reconciliation/ledger membership; separately held restricted packet required')
else:
 assert H((a.private/'MANIFEST.json').read_bytes())=='d10d86ab4e8988a917dc00d8eaf149c1ca24872ae61be53ef2b2a1910df01292';manifest(a.private)
 for item in json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes())['files']:
  old=(a.private/item['original_file']).read_bytes();assert H(old)==item['original_whole_file_sha256'];out=bytearray();last=0
  for r in item['replacements']:
   i=r['original_byte_offset'];n=r['original_byte_length'];assert i>=last;out+=old[last:i]+r['replacement'].encode();last=i+n
  out+=old[last:];assert bytes(out)==(P/item['successor']).read_bytes() and H(out)==item['successor_whole_file_sha256']
 m=json.loads((a.private/'PRIVATE-HANDOFF-LENS-MAP.json').read_bytes());assert json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows']==[m['lenses'][i-1] for i in [1,2,5,6]]
 h=json.loads((P/'HISTORY-SUMMARY.json').read_bytes())
 for row in h['obligations']+h['relationships']:
  b=(a.private/f"PRIVATE-Q{row['index']}-original.json").read_bytes();q=json.loads(b);assert H(b)==row['selected_record_sha256'] and q['contract_id']==row['contract_id'] and q['lens']==row['lens'] and q.get('status')==row['status']
 ledger=json.loads((a.private/'PRIVATE-ede12-BASELINE-95E-20261110.json').read_bytes())['newly_assessed_ledger']['entries'];rec=json.loads((a.private/'PRIVATE-ede12-RECONCILIATION-059.json').read_bytes())['entries']
 for row in h['ledger_relationships']:assert ledger[row['index']]['id']==row['id']
 for row in h['obligations']:assert rec[row['index']]['current_reconciliation']=='unassessed'
 assert (P/'HISTORICAL-GROUP-242.json').read_bytes()==(a.private/'historical/evidence__audit05__contract-groups-242.json').read_bytes()
 print('restricted manifest, reconstruction crosswalk, selected map/queue/status and historic group: pass')
 cmd=[sys.executable,str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,end='')
 if r.returncode:print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
print('Integrity replay does not establish semantic conclusions, recover 3821 or validate product behavior.')
