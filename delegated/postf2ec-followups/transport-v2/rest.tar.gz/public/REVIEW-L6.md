# q3393 — Lens 6: type ownership

Reader: [independent reviewer]. The entire registered source was independently
read for this lens; history and supporting windows are separately attributed.

The within-day wake position has an existing core owner
`StrategicMinuteOfDay` (`strategic_time.rs:34-63`) and a current producer from
an absolute strategic time (`camp.rs:328-337`). Its application path currently
uses `u16`/`Option<u16>` through the camp and rest templates until native
HTML/JS. The owner is already in a dependency used by the web crate and camp
route; this is related to historical q2457, with valid `None` for quest and a
separate elapsed duration. No duplicate clock owner or all-callers proof is
claimed.

The local rest-service enum, physical venue and public action-service owner
have different scopes. `SettlementVenueKind::action_service` and
`RestServiceKind::public_service` each map the relevant physical/public
relationship, while residence intentionally has no public service
(`strategic_place.rs:121-179`; template `rest.rs:13-54`; `economy.rs:32-39`).
Existing mapping policy can be reviewed without erasing the private-residence
case; q2456 already records the named-scope fit. No currently inconsistent
mapping or unique duplication defect is established.

`days_to_full_health` hand-calculates a 0.05/day, round-up-to-days estimate
(`rest.rs:372-395`). Core offers linear `healed_health` and exact-minute
`convalescence_minutes` (`strategic_time.rs:31-32,426-473`), but the native
settlement operation uses a different surgery and physiology-sensitive
convalescence, restorative allocation and disease clipping
(`time/settlement_rest.rs:1-5,312-340`). The display suggestion subsequently
adds repair time and rounds/clamps whole days. Owner, intended rounding,
interaction with real recovery and valid input policy are open; do not call
the linear helper authoritative or substitute it without resolving those
contracts. Similarly camp fatigue clearance is a different path from the
settlement suggestion; no equality of rates or outcomes is inferred.
