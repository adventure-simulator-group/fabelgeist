# q3389 — Lens 1: producer propagation

Reader: [independent reviewer]. The full 594-line registered source was read under
this lens at identical source bytes in 6533, e275 and pinned 95e. Source hash,
commit/tree/blob proofs, registered windows and receipt are in this packet.

`camp.rs:328-337,433-445` derives a planned wake position from the party's
saturating absolute strategic time; `travel.rs:827-839,883-890` carries that
position as `u16`, and `rest.rs:66-74,299-318` carries `Option<u16>` to a data
attribute. `StrategicMinuteOfDay::from_absolute/get` owns the same within-day
coordinate (`strategic_time.rs:34-63`); the current producer's
`minute_of_day()` yields a valid within-day position. The present typed
boundary is lost across application template signatures before conversion to
browser attribute text. `rest-duration.js:11-26,86-90,101-110,140-149,210-225`
normalizes and uses that value; the HTTP duration is instead elapsed minutes,
and `routes/settlements/rest.rs:93-157` separately parses and bounds it. A
quest caller intentionally passes no wake suggestion (`quest.rs:453-464`).
The relationship is to historical q2457, not a proven alias or new defect
count. Other producers and supported API exposure remain open.

`rest_default_minutes` and `RestSummary.minutes` transport elapsed quantities
as `u64`, but an exact generic elapsed owner with matching zero, saturation and
presentation semantics is not established. Dividing soap use counts for a
formatted tooltip is a native rendering conversion, not by itself an unfinished
bespoke migration (`rest_preview.rs:1-14,182-231`; template `rest.rs:105-144`).
Follow any proposed wake-owner propagation through both typed callers and
retain `None`, the distinct elapsed duration and browser boundary. Source-only;
no implementation, parser or product execution occurred.
