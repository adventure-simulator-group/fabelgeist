#!/usr/bin/env python3
"""Read-only evidence replay; no product execution or validation."""
import argparse,hashlib,json,pathlib,stat,subprocess,sys
if sys.flags.optimize:raise SystemExit('Optimized execution unsupported')
P=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def load(root,n):return json.loads((root/n).read_bytes())
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def safe(root,n):
 q=pathlib.PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts;return root.joinpath(*q.parts)
def check_manifest(root,expected=None):
 raw=(root/'MANIFEST.json').read_bytes()
 if expected:assert H(raw)==expected
 m=json.loads(raw);fs={x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_file() and x!=root/'MANIFEST.json'};assert fs==set(m['files']) and not any(x.is_symlink() for x in root.rglob('*'))
 for n,v in m['files'].items():
  q=safe(root,n);b=q.read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'] and stat.S_IMODE(q.stat().st_mode)==v['mode']
 return m
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);assert z+21<=len(b);n=b[a+1:z].decode();assert n not in out;out[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def prove(root,path,b):
 for part in path.split('/'):
  x=(P/'trees'/(root+'.tree')).read_bytes();assert oid('tree',x)==root;mode,root=tree(x)[part]
 assert mode=='100644' and oid('blob',b)==root
try:
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);a=ap.parse_args();assert not a.anchors or a.private
 check_manifest(P);print('public file set, modes, lengths and hashes: pass')
 primary=load(P,'SOURCE-006-CAPTURE-RESULT.json');body=(P/'source/95e.rs').read_bytes();assert len(primary)==3
 for x in primary:
  assert H(body)==x['sha256']=='63dcebbc01df68859b94ad46c77ca3a6d20ca1727213d550f050ce39caa4e947' and len(body.splitlines())==x['EOF']==594;prove(x['root'],x['path'],body)
 rows={primary[-1]['path']:{'file':'source/95e.rs'}}
 for n in ['ADJ-009-CAPTURE-RESULT.json','SUPPORT-013-CAPTURE-RESULT.json','SUPPORT-016-CAPTURE-RESULT.json','SUPPORT-020-CAPTURE-RESULT.json','SUPPORT-026-CAPTURE-RESULT.json']:
  for x in load(P,n):
   assert 'error' not in x;b=safe(P,x['file']).read_bytes();assert H(b)==x['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['EOF'];prove(x['root'],x['path'],b);rows[x['path']]=x
 reg=load(P,'SOURCE-007-DISPLAY-REG.json');views=load(P,'SOURCE-007-DISPLAY-RESULT.json');assert reg['queues']==[3389,3390,3392,3393] and [x['range'] for x in views]==reg['planned_ranges'];ls=body.decode().splitlines(keepends=True)
 for x in views:
  lo,hi=x['range'];out=safe(P,x['file']).read_bytes();assert H(out)==x['sha256'] and out.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
 for prefix in ['ADJ-010','SUPPORT-014','SUPPORT-017','SUPPORT-021','SUPPORT-024','SUPPORT-027']:
  reg=load(P,prefix+'-DISPLAY-REG.json');out=load(P,prefix+'-DISPLAY-RESULT.json');assert [(x['path'],x['range']) for x in out]==[(v['path'],r) for v in reg['views'] for r in v['ranges']]
  for x in out:
   b=safe(P,rows[x['path']]['file']).read_bytes();ls=b.decode().splitlines(keepends=True);lo,hi=x['range'];data=safe(P,x['file']).read_bytes();assert H(data)==x['sha256'] and data.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
 for x in load(P,'SKILLS-005-CAPTURE.json'):
  b=(P/'skills'/('lens-'+str(x['lens'])+'.md')).read_bytes();assert H(b)==x['sha256'] and len(b.splitlines())==x['lines']
 assert load(P,'SOURCE-006-CAPTURE-REG.json')['assigned_lenses']==[1,2,5,6]
 print('three source-tree path proofs, pinned support objects, four skills and registered display bytes: pass')
 c=load(P,'RECONSTRUCTION-CROSSWALK.json');assert c['restricted_manifest_sha256']=='4ce55db5b92accd1b8b3123679c65a4cfa142035c2977301cfb5ea5b2ecf022f'
 for x in c['files']:
  b=safe(P,x['public_file']).read_bytes();assert H(b)==x['public_whole_file_sha256'] and len(b)==x['public_bytes'];last=0
  for s in x['replacements']:assert s['offset']>=last and s['length']>0 and s['offset']+s['length']<=x['original_bytes'];last=s['offset']+s['length']
 print('public reconstructed file identities and replacement bounds: pass')
 if a.private:
  check_manifest(a.private,c['restricted_manifest_sha256'])
  for x in c['files']:
   b=safe(a.private,x['restricted_source']).read_bytes();assert H(b)==x['original_whole_file_sha256'] and len(b)==x['original_bytes'];parts=[];pos=0
   for s in x['replacements']:lo=s['offset'];parts.extend([b[pos:lo],s['replacement'].encode()]);pos=lo+s['length']
   parts.append(b[pos:]);assert b''.join(parts)==safe(P,x['public_file']).read_bytes()
  cmd=[sys.executable,str(a.private/'verify-evidence-v3.py')]
  if a.anchors:cmd.extend(['--anchors',str(a.anchors)])
  x=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert x.returncode==0
  print('restricted original inventory, exact reconstruction, and nested source/history replay: pass')
  if not a.anchors:print('NOT CHECKED: full 059 queue membership (supply separately held --anchors).')
 else:print('NOT CHECKED: revision commit binding, full queue history or exact original reconstruction (supply --private and --anchors).')
 print('No runtime behavior, repair, reachability, global closure or missing checkpoint recovery is asserted.')
except Exception as e:
 print('evidence verification failed:',type(e).__name__,file=sys.stderr);sys.exit(1)
