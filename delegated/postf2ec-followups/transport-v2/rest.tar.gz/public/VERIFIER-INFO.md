Use `verify-v2.py` for public and optional anchored replay. The initial unrun `verify.py` is preserved with its narrower check documented in PUBLIC-VERIFIER-CORRECTION.json.
