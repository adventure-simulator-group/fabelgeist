# q3392 — Lens 5: aggregate relationships

Reader: [independent reviewer]. The complete registered template was read for this
lens; bounded producer/consumer source windows are listed in the receipts.

`rest_default_minutes` returns `None` whenever all of limbs, stats and
condition are absent, even when independently supplied repair or smith-wait
minutes are positive (`rest.rs:387-405`). Inn rendering fetches the three
health records separately from the equipment estimate (`rendering.rs:115-145`);
`query_single` maps both an error and no row to `None`
(`routes/settlements/rest.rs:378-383`). If all three observations are absent
and the independently obtained relevant equipment recommendation exceeds a
day, `rest_service_menu` uses its one-day initial default instead
(`rest.rs:234-237,282-292`). This is a source-level conditional relationship;
actual independent query outcomes, >one-day supported order/repair states,
recommendation policy and player impact were not established. Trace and retain
observation completeness and equipment wait independently if this contract is
adopted; do not silently treat error as a real empty record. This is related in
shape to ledger813's missing-outcome observation issue, but first operation,
inputs and presentation differ; no alias or count is inferred.

`SoapRestPreview` exposes total, personal, shared, availability and alcohol
fields separately (`rest.rs:105-113`); its selected producer forms total using
saturating personal+shared and computes availability/drink flags separately
(`rest_preview.rs:17-71,85-180,182-232`). Missing reads default to empty and
missing personality is treated as non-temperate by the shown predicate. The
consumer can present absence or a will-consume statement (`rest.rs:115-163`).
This is the separately attributed Adler q202/ledger786 availability/forecast
family; preserve its unknown inputs, actual duration/evening rules, caller and
native policy questions instead of making a new count. Independent public
fields also admit contradictory states; no actual reachable contradictory
producer is asserted.

The rest summary receives independently optional before/after observations and
renders zero/empty projections as actual outcomes (`routes/rest.rs:317-334,
378-383,402-470`; template `rest.rs:245-273`). Ledger813 already records that
family, while ledger812 separately concerns requested versus elapsed inn
charges and ledger814 action path versus actual location. They remain distinct
pending central alias adjudication; no new count.
