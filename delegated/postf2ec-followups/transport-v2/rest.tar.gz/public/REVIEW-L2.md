# q3390 — Lens 2: existing owners

Reader: [independent reviewer]. The full registered source was independently read
for this lens at the three named source identities. Historic Root Lens2 has a
separate 6533 fresh 1-594 personal read and a qualified e275 1-594 same-lens
reuse with zero fresh current read; neither is transferred as my credit.

`StrategicMinuteOfDay` accepts exactly positions less than a day and supports
normalization from an absolute strategic time (`strategic_time.rs:34-63`). The
selected camp producer computes a day position (`camp.rs:328-337`), then retains
it as `u16` through `camp_page`, `party_rest_menu` and the wake control before
native HTML/JS conversion (`travel.rs:827-839,883-890`; `rest.rs:66-74,
299-318`). This is a concrete match to the wake role, extending q2457's open
producer/adapter question. Quest supplies `None`. The browser uses a number,
and the HTTP form parses a separate elapsed duration; no identity between
those roles is established (`rest-duration.js:11-26,86-90,101-110,140-149`;
`routes/settlements/rest.rs:93-157`). Other call sites and exact aliases remain
open.

`RestServiceKind` has Inn, Temple and Residence; the existing
`SettlementVenueKind` represents physical venues, while `SettlementActionService`
represents only public Inn/Temple actions. The venue's checked
`action_service` maps Inn/Church to those actions and other venues to None
(`strategic_place.rs:121-179,189-204`; `economy.rs:32-39`; template
`rest.rs:13-54`). Residence's None carries useful meaning. This corroborates
q2456's named-scope classification, not global closure or a new uniqueness
count.

The zero-valid recommendation and absolute clock position differ. The core
linear `convalescence_minutes` helper (`strategic_time.rs:426-473`) and web
whole-day heuristic (`rest.rs:372-405`) also differ in rounding and contract;
the native settlement path calls surgery's physiology-sensitive owner and
accounts for restorative time and disease (`time/settlement_rest.rs:1-5,
312-340`). A direct replacement or shared-owner policy is not established.
