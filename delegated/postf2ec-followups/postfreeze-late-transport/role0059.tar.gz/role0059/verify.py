#!/usr/bin/env python3
"""Read-only evidence replay; does not execute product code."""
import argparse,gzip,hashlib,io,json,pathlib,subprocess,sys,tarfile
P=pathlib.Path(__file__).resolve().parent
def j(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(x,m):
 if not x:raise ValueError(m)
def safe(root,name):
 p=pathlib.PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return root.joinpath(*p.parts)
def tree(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'tree bounds');k=b[a+1:z].decode();need(k not in d,'duplicate tree name');d[k]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
def archive(f,prefix,manifestsha):
 with tarfile.open(f,'r:gz') as t:
  fs={x.name[len(prefix):]:x for x in t.getmembers() if x.isfile() and x.name.startswith(prefix)};raw=t.extractfile(prefix+'MANIFEST.json').read();need(sh(raw)==manifestsha,'prior manifest');m=json.loads(raw);need(set(fs)==set(m['files'])|{'MANIFEST.json'},'prior file set')
  for n,v in m['files'].items():
   b=t.extractfile(fs[n]).read();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and fs[n].mode==v['mode'],'prior member')
  return {n:t.extractfile(x).read() for n,x in fs.items()}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repository');a=ap.parse_args();m=j(P/'MANIFEST.json');files={f.relative_to(P).as_posix() for f in P.rglob('*') if f.is_file() and f!=P/'MANIFEST.json'};need(files==set(m['files']) and not any(f.is_symlink() for f in P.rglob('*')),'manifest set')
 for n,v in m['files'].items():
  f=safe(P,n);b=f.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode'],'file '+n)
 for x in j(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(x['name']+'.md')).read_bytes();need(sh(b)==x['sha256'] and len(b.splitlines())==x['lines'],'skill identity')
 for x in j(P/'RULES-READ-RECEIPT.json')['files']:need(sh(safe(P,x['captured_file']).read_bytes())==x['sha256'],'rule capture')
 reg=j(P/'SOURCE-REGISTRATION.json');rr=j(P/'SOURCE-READ-RECEIPT.json');expected=[(3471,1),(3472,2),(3474,5),(3475,6)];need([(x['queue'],x['lens']) for x in reg['lenses']]==expected and [(x['queue'],x['lens']) for x in j(P/'ASSESSMENTS.json')['assessments']]==expected,'lenses');need(rr['sources']==reg['sources'] and rr['actual_display_ranges']==[[1,148]] and rr['unread_complement']==[],'source scope');bodies=[]
 for x in reg['sources']:
  b=(P/'sources'/(x['label']+'.rs')).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(b.decode().splitlines())==x['EOF']==148,'source object');bodies.append(b)
 need(len(bodies)==3 and len(set(bodies))==1,'source shared view');lines=bodies[0].decode().splitlines();seen=set()
 for v in rr['views']:
  lo,hi=v['range'];b=safe(P,v['file']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(lo,hi+1)] and v['registration_mtime_ns']<=v['view_created_mtime_ns'],'source view');need(not seen.intersection(range(lo,hi+1)),'overlap');seen.update(range(lo,hi+1))
 need(len(rr['views'])==2 and seen==set(range(1,149)),'source coverage');chunks=0
 for suffix in ('','2','3','4'):
  fn='SUPPORT'+suffix+'-REGISTRATION.json';d=j(P/fn);q=j(P/('SUPPORT'+suffix+'-READ-RECEIPT.json'));need(sh((P/fn).read_bytes())==q['registration_sha256'],'support registration')
  for x in d['rows']:
   b=(P/'support'/(x['label']+'.rs')).read_bytes();ls=b.decode().splitlines();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(ls)==x['EOF'],'support blob');vs=[v for v in q['views'] if v['label']==x['label']];need([v['range'] for v in vs]==x['registered_ranges'],'support windows')
   for v in vs:
    lo,hi=v['range'];b=safe(P,v['view']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i:5}  {ls[i-1]}' for i in range(lo,hi+1)] and v['registration_mtime_ns']<=v['view_created_mtime_ns'],'support display');chunks+=1
 need(chunks==21,'support chunks')
 for v in j(P/'HISTORICAL-READ-RECEIPT.json')['views']:need(sh(safe(P,v['view']).read_bytes())==v['sha256'],'historical view')
 prior=archive(P/'prior/url-four-lens-v2.tar.gz','','8b498ad2945bdc1ca251a69830f0360b204e7906c83d795764f3535e62367782');err=archive(P/'prior/url-erratum.tar.gz','url-erratum/','dd799ac25689b8fb8579976f225e5e45346f4a9530c7bb96d90f35265ba32f53')
 for v in j(P/'PRIOR-0047-READ-RECEIPT.json')['views']:
  n=v['member'];ref=err[n[len('ERRATUM-'):]] if n.startswith('ERRATUM-') else prior[n];b=(P/'historical/prior-0047-selected'/n).read_bytes();need(sh(b)==v['sha256'] and b==ref,'prior read identity')
 proofs=j(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==21,'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree length')
  for part,step in zip(parts,x['tree_chain']):
   need(cur==step['tree'] and part==step['entry'],'tree path');b=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',b)==cur,'tree object');mode,cur=tree(b)[part];need(mode==step['mode'] and cur==step['object'],'tree member')
  need(cur==x['blob'],'tree target')
  if x['role']=='source':need(oid(b'blob',safe(P,x['source_file']).read_bytes())==cur,'source blob')
  elif a.restricted:
   b=safe(a.restricted,x['source_file']).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==cur,'restricted blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository root')
 cats=j(P/'CATALOG-RESULT.json')['matches'];need([(x['index'],x['lens']) for x in cats]==expected and all(not x['status_present'] for x in cats),'catalog selections');checked=False
 if a.restricted:
  h=a.restricted/'historical';raw=(h/'previous-private-manifest.json').read_bytes();need(sh(raw)=='6ad792769add0d2e7052f329761fe0d265af341fadc53d221a979e5f422ca030','previous private manifest');old=json.loads(raw)['files'];qs=[]
  for n in ('queue-original.json','queue-reconstructed.json'):
   b=(h/n).read_bytes();need(sh(b)==old['historical/'+n]['sha256'],'previous queue identity');qs.append(json.loads(b))
  b=(h/'queue-published.json').read_bytes();need(sh(b)==j(P/'CATALOG-RESULT.json')['published_queue_sha256'],'published queue identity');qs.append(json.loads(b));need((h/'queue-original.json').read_bytes()!=(h/'queue-reconstructed.json').read_bytes(),'whole queue distinction')
  for x in cats:
   es=[q['entries'][x['index']] for q in qs];need(es[0]==es[1]==es[2] and es[0]['lens']==x['lens'] and es[0]['contract_id']==x['id'],'selected queue')
  for i in (178,184,213,217,2450,3297):
   es=[q['entries'][i] for q in qs];need(es[0]==es[1]==es[2] and j(h/f'q{i}-original.json')==es[0],'historical record')
   v=j(P/f'historical/selected-views/q{i}-core.json');need(all(es[0].get(k)==v[k] for k in v),'history projection')
  b=(h/'registry-original.json.gz').read_bytes();need(sh(b)=='a90f280f820e17643933b87aee4587c0ba47f8feec35bd9db61611653bc14063','stored registry');d=gzip.decompress(b);need(sh(d)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f','decoded registry');files0=json.loads(d)['files'];need(not any('location_urls/patterns.rs' in json.dumps(x) for x in files0) and j(h/'registry-matches.json')==[],'registry absence');need((h/'archived-original-object.rs').read_bytes()==bodies[0],'archived source')
  ids=j(h/'HISTORICAL-FILE-IDENTITIES.json')
  for n,v in ids.items():need(sh((h/n).read_bytes())==v['sha256'],'historical receipt')
  oldrow=j(h/'READ-ROOT-L3-EXT-057-061.json')['rows'][2];erow=j(h/'READ-ROOT-L3-CURRENT-007.json')['rows'][2];need(oldrow['fresh_personal_ranges']==[[1,148]] and erow['fresh_personal_ranges']==[] and erow['qualified_reuse_ranges']==[[1,148]],'historical read attribution')
  c=(h/'baseline-committed.json').read_bytes();w=(h/'baseline-observed.json').read_bytes();need(c==w and sh(c)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041' and len(json.loads(c)['newly_assessed_ledger']['entries'])==1101,'captured baseline')
  roots={}
  for x in j(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(oid(b'commit',b)==x['revision'] and sh(b)==x['payload_sha256'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit anchor');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit tree binding');checked=True
 print(json.dumps({'result':'pass','public_files':len(files),'assigned_shared_display_chunks':len(rr['views']),'support_display_chunks':chunks,'git_tree_path_proofs':len(proofs),'prior_archive_member_checks':len(prior)+len(err)-2,'restricted_history_checked':checked,'repository_binding_checked':bool(a.repository),'qualification':'Evidence and declared read scopes only; runtime, alias, count and global closure remain open.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
