#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def reconstruct(old,diff):
 source=old.splitlines(keepends=True);lines=diff.splitlines(keepends=True);out=[];pos=0;hunks=0;i=0
 pattern=re.compile(rb'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@')
 while i<len(lines):
  m=pattern.match(lines[i])
  if not m:i+=1;continue
  before,blen,after,alen=[int(v) if v is not None else 1 for v in m.groups()];start=before-1 if before else 0;assert start>=pos
  out.extend(source[pos:start]);pos=start;assert len(out)==(after-1 if after else 0)
  consumed=added=0;i+=1
  while i<len(lines) and not lines[i].startswith((b'@@ ',b'diff --git ')):
   line=lines[i];assert line and line[:1] in (b' ',b'+',b'-');mark=line[:1];payload=line[1:]
   if mark in (b' ',b'-'):assert pos<len(source) and source[pos]==payload;pos+=1;consumed+=1
   if mark in (b' ',b'+'):out.append(payload);added+=1
   i+=1
  assert consumed==blen and added==alen;hunks+=1
 out.extend(source[pos:]);assert hunks>0;return b''.join(out),hunks
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None: print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='d37fe7d66c66aeb932d29f0bb1c278f6bdf6dbf58ec5377c2c41ccf378ba70df';verify_manifest(root,'MANIFEST-PRIVATE.json')
 source=proof(root,'SOURCE-GIT-PROOF.json','source-git-objects',True);supplement=proof(root,'SOURCE-SUPPLEMENT-GIT-PROOF.json','supplement-git-objects',True);checkpoint=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);history=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert len(source)==18 and len(supplement)==2 and len(checkpoint)==2 and len(history)==3
 hist='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';recon='dac7d0055716053f245139971eb67ddfd87fa462';hp='baseline-059/queue.json';assert sha(history[(hist,hp)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(history[(recon,hp)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173';o=exact_selections(history[(hist,hp)],[0,61]);r=exact_selections(history[(recon,hp)],[0,61]);assert all(o[i][0]==r[i][0] for i in [0,61]);q=o[0][0];assert q['contract_id']=='ADLER-CONT08-CANDIDATE-001' and q['lens']==8 and q['status']=='open-reconciliation' and q['body_or_population_credit']==0
 for label,s in [('original',o),('reconstructed',r)]:assert (root/f'{label}-q0-exact.json').read_bytes()==s[0][1] and json.loads((root/f'{label}-q0-pretty.json').read_bytes())==s[0][0]
 f2ec='f2ec8cbad7becbcc9a8e9da22ba512f52975768f';base=checkpoint[(f2ec,'BASELINE-95E-20261110.json')];rq=checkpoint[(f2ec,'RECONCILIATION-059.json')];assert sha(base)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041' and sha(rq)=='73bc3864944276b88944163257e3cfc67dde6141b2dc3f82588af66621003945';rqrows=json.loads(rq)['entries'];rows=json.loads(base)['newly_assessed_ledger']['entries'];assert len(rqrows)==3713 and len(rows)==1101 and rqrows[0]==json.loads((root/'f2ec-q0.json').read_bytes()) and rqrows[0]['historical_status']=='open-reconciliation' and rqrows[0]['current_reconciliation']=='unassessed'
 related=json.loads((root/'HISTORICAL-SEARCH-009.json').read_bytes());assert [x['index'] for x in related]==[0,61] and related[1]['row']==o[61][0];ledger=json.loads((root/'LEDGER-SEARCH-009.json').read_bytes());assert all(rows[x['index']]==x['row'] for x in ledger);assert rows[217]['id']=='ADLER-L11-RUNTIME-EQUIPMENT-FAILURE-OWNERSHIP'
 for n,h in [('receipt-behavior-011.json','9dc19ff8b3c863bdc17e00e319f8a79c3f895087b4a58ae501c9e10e2860b21c'),('receipt-behavior-016-partial.json','86aaa2fbd2f2a80769118a4b2711b55b605cc53fabc50bbb66f33b29baa11b3e'),('receipt-batch-002-equipment-policy-accounting.json','2ad84b8b5f1083cd2c6a70091445cecb1bb306073adab42810c50700c86ea2f3'),('receipt-QUALIFICATION-L8-CONTRACT-ORIGIN-001.json','15c0f48e2b7ef64da0fdb5a22ba32a5f5e2ba00340e68deaac040ac3c8cf0699')]:assert sha((root/n).read_bytes())==h
 b11=json.loads((root/'receipt-behavior-011.json').read_bytes());b16=json.loads((root/'receipt-behavior-016-partial.json').read_bytes());batch=json.loads((root/'receipt-batch-002-equipment-policy-accounting.json').read_bytes());assert batch['lens']==8 and batch['candidate']['id']==q['contract_id'];ident=q['exact_source_identities_and_assessed_ranges'];assert b11['1474_read_status']==ident[0]['raw_attestation_value'] and b16['source_reads']['1484_head']==ident[1]['raw_attestation_value'];assert q['origin_metadata_qualifications'][0]['proof']['exact_contract_identity_receipt']['sha256']==sha((root/'receipt-batch-002-equipment-policy-accounting.json').read_bytes())
 assert sha((root/'skill-audit-behavior-preservation.md').read_bytes())=='7413ca56a7a637a20cb56f6a35c7623253934e806415e26131af076050fa685c' if (root/'skill-audit-behavior-preservation.md').exists() else sha((root/'SKILL-behavior-preservation.md').read_bytes())=='7413ca56a7a637a20cb56f6a35c7623253934e806415e26131af076050fa685c'
 def data(n):return (root/n).read_bytes()
 assert sha(data('base-equipment-recovered.raw'))=='7e814de4d7c4a949912538a6d63f5fad3fc23ff23c367634f3034f7cca17cbf9';assert sha(data('transport-generation-base.raw'))=='92e54d6897e8c25fa216aacba88771dbd55b17f9f9968e180cf5b92ee48340a1';assert sha(data('overlay-equipment.raw'))=='c7869ebb6e2c2a67a4c47e9504c0ced6da6566f95fba9320181d49b1142a54fd' and data('overlay-equipment.raw')==data('transport-equipment.raw');assert sha(data('old-generation.raw'))=='ea41899e503a9d300af874feb8f230532b8e8c1b9f6994c4c89b690746dfaf29' and data('old-generation.raw')==data('transport-generation.raw');assert sha(data('current-generation.raw'))=='8fd8eb2ebae7206be3aa38b846ff7258857b16f4508ac77e1979d0d9aa32c93d' and data('current-generation.raw')!=data('old-generation.raw')
 assert data('parent-equipment.raw')!=data('base-equipment-recovered.raw') and data('parent-generation.raw')!=data('transport-generation-base.raw');assert data('old-presentation.raw')==data('current-presentation.raw')
 for n,h in [('connected-pr1474.diff','83032eed8a0ca430f1865f96c9bfcc41825c6bd47df2685fb212b216a0dc5512'),('connected-pr1484.diff','3637a3d1711abd173d9e58cd9ed5737801b638feb7506172bb1066786ddd6a90')]:assert sha(data(n))==h
 for pair in json.loads(data('REGISTRATION-022.json'))['pairs']:
  out,count=reconstruct(data(pair['before']),data(pair['diff']));assert out==data(pair['after']) and count>0
 import difflib
 diff=''.join(difflib.unified_diff(data('old-generation.raw').decode().splitlines(keepends=True),data('current-generation.raw').decode().splitlines(keepends=True),fromfile='6533-generation',tofile='95e-generation')).encode();assert diff==data('DIFF-6533-95e-generation.txt') and len(diff.splitlines())==55
 def block(n,lo,hi):return b'\n'.join(data(n).splitlines()[lo-1:hi])+b'\n'
 comparison=json.loads(data('REGISTRATION-030.json'))['slices'];blocks=[block(n,*r) for n,r in comparison.items()];assert blocks[0]==blocks[1]==blocks[2] and sha(blocks[0])==json.loads(data('COMPARISON-030.json'))['sha256']
 windows=[]
 for name in ['REGISTRATION-008.json','REGISTRATION-012.json']:
  reg=json.loads(data(name))
  for w in reg['windows']:
   for lo,hi in w['ranges']:windows.append((w['file'],f"{w['file']}-{lo}-{hi}.txt",lo,hi))
 for name in ['REGISTRATION-013.json','REGISTRATION-029.json']:
  reg=json.loads(data(name))
  for w in reg['windows']:
   lo,hi=w['range'];windows.append((w['file'],f"{w['file']}-{lo}-{hi}.txt",lo,hi))
 reg=json.loads(data('REGISTRATION-014.json'))
 for w in reg['sources']:
  for lo,hi in w.get('ranges',[w.get('range')]):
   raw=w['label']+'.raw';windows.append((raw,f'{raw}-{lo}-{hi}.txt',lo,hi))
 for name,key in [('REGISTRATION-019.json','window'),('REGISTRATION-024.json','existing_window'),('REGISTRATION-025.json','window'),('REGISTRATION-026.json','existing_window')]:
  w=json.loads(data(name))[key];lo,hi=w['range'];windows.append((w['file'],f"{w['file']}-{lo}-{hi}.txt",lo,hi))
 w=json.loads(data('REGISTRATION-027.json'));lo,hi=w['range'];windows.append((w['file'],f"{w['file']}-{lo}-{hi}.txt",lo,hi));assert len(windows)==35
 for x in windows:window(root,*x)
 print('restricted manifest, 20 Git-bound source selections, f2ec, queue, receipts, two exact historical diff reconstructions, current diff and 35 captured windows: PASS')
 print('Evidence only; no product execution, semantic closure, runtime validation, independent custody or checkpoint 3821 claim.')
if __name__=='__main__':main()
