#!/usr/bin/env python3
"""Bounded privacy candidate scan; prints counts, not matched values."""
import json,re,sys
from pathlib import Path
root=Path(__file__).resolve().parent
patterns={'email':re.compile(rb'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'),'unix_local_path':re.compile(rb'/(?:home|tmp|Users|mnt)/[^\s\"\x27<>]+'),'windows_local_path':re.compile(rb'\b[A-Za-z]:'+re.escape(bytes([92]))+rb'[^\s\"\x27<>]+'),'private_key_header':re.compile(rb'-{5}BEGIN [A-Z ]*PRIVATE KEY-{5}'),'access_key':re.compile(rb'AKIA[0-9A-Z]{16}')}
assert patterns['windows_local_path'].search(b'Q:'+bytes([92])+b'Example'+bytes([92])+b'file')
assert patterns['unix_local_path'].search(b'/'+b'home'+b'/example')
counts={k:0 for k in patterns};n=0
for p in sorted(root.rglob('*')):
 if p.is_symlink():raise SystemExit('symlink')
 if p.is_file():
  n+=1;b=p.read_bytes()
  for k,r in patterns.items():counts[k]+=len(r.findall(b))
print(json.dumps({'files_scanned':n,'candidate_counts':counts,'qualification':'bounded pattern scan, not proof of absence of all sensitive data'},sort_keys=True));sys.exit(1 if any(counts.values()) else 0)
