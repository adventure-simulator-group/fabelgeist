# q0: retained fit and current equipment identity

This is a bounded, fresh Lens 8 behavior-preservation review by
`verifier_scope`, after the current checkpoint cutoff. It corroborates a
conditional source-level old/new difference already described by the
historical q0 candidate. It does not establish that the triggering mutation is
supported or occurs in ordinary play, that a model was rendered, that the
change is unauthorized, an exact alias, a unique finding count, or closure.
The coordinator owns the connected ledger and disposition.

## Historical scope and revision

Original 059 `/entries/0` is `ADLER-CONT08-CANDIDATE-001`, historically
`open-reconciliation`; the separate f2ec reconciliation marks it
`unassessed`. The original and reconstructed 059 full streams have different
whole-file hashes, although their parsed q0 entries agree. q0 records historical
Lens 8 personal attestations for the 1,745-line equipment source and the
467-line generation source. The later continuation accounting receipt
expressly says it adopted qualified same-lens evidence without a new personal
body read. Neither its attribution nor the earlier personal attestation
transfers to this reviewer or another lens.

The historical equipment head is the expressly qualified 36c overlay,
`36c97923da8ee84d0ab8994e7cfedf6a0cdea641`, SHA-256
`c7869ebb6e2c2a67a4c47e9504c0ced6da6566f95fba9320181d49b1142a54fd`;
its exact content also appears as an f82 normalized 774 transport object.
The prior attempted 6533 equipment hash query had been rejected before
historical display. The generation head is 6533,
`6533e444fa37552927070cc8d8190907fd3b413e`, SHA-256
`ea41899e503a9d300af874feb8f230532b8e8c1b9f6994c4c89b690746dfaf29`,
also present as an f82 source object. Do not conflate the overlay, transport,
original historical source, or authoritative current revision.

The historical before equipment body was recovered by its recorded SHA-256
`7e814de4d7c4a949912538a6d63f5fad3fc23ff23c367634f3034f7cca17cbf9`
from an older local collection. The before generation body, SHA-256
`92e54d6897e8c25fa216aacba88771dbd55b17f9f9968e180cf5b92ee48340a1`,
is in the f82 transport. The underlying original before Git revisions remain
unknown. Evidence-only reconstruction confirms that the two recorded
diffs transform those exact before bytes into the 36c equipment and 6533
generation heads, respectively. This proves the byte relationships, not an
independent historical read of every undisplayed line.

The authoritative current revision is
`95e63628f9d70b8dd6e6fede64334696c6995009`. Its generation source has
SHA-256 `8fd8eb2ebae7206be3aa38b846ff7258857b16f4508ac77e1979d0d9aa32c93d`.
It differs from 6533; the complete 55-line textual comparison is captured and
was displayed. The selection function in the registered windows is unchanged.
Current equipment differs at whole-file level from the 36c overlay. This
review independently displayed only the registered old/current selections and
connected windows, not either full equipment family.

## Conditional behavioral difference

In the recovered before generation source, `FitKey::for_presentation`
(lines 24–73) takes the current presentation's item ID even when an unworn
item retains a prior fit's shape, placement and layers. At 6533 and 95e,
`generation.rs:23–95` instead returns the entire previous typed selection
when `!fitted_to_owner` and a previous fit exists. Thus, for a presentation
whose current item is B and whose prior selection is A, the old key carries B
with the prior placement, while the newer key carries the prior A selection.
Whether reusing that earlier placement with B was itself valid is a separate
contract; the comparison alone does not declare either policy correct.

The complete `spawn_item_placeholders` function is byte-identical at the
recovered before equipment source, 36c overlay, and 95e. Under its displayed
conditions it responds to `Changed<ItemProperties>`, replaces the placeholder
and removes attachment sockets without removing item-owned `LastFit`. The
current presentation constructor copies `ItemProperties.id` into its item
ID; the generation path prefers item `LastFit` over its current key and uses
`!scene && no holding side && owner present` to decide whether fitting is to
an owner. The source therefore supports the comparison for a conditional
changed-ID, unworn, retained-fit state; schedule, admission, availability and
other route conditions remain necessary.

The historical receipt illustrates an arming doublet followed by a linen
tunic. Pinned source names both authored items, a `worn` placement for each,
the doublet recipe and the fitted-clothing classification route. Their
classification still depends on normal catalog/recipe admission; no decoder,
fixture or product validation was run. A selected current server projection
creates new tactical item entities and the inspected strategic scene rebuilds
entities on wardrobe changes. Neither selected producer establishes an
ordinary same-entity ID mutation, and these windows are not a global proof
that no such producer exists. `ItemProperties.id` is a public field, which
establishes representability rather than supported policy.

At current `generation.rs:163–213,217–259,263–290,344–386,444–467`, the
selection reaches the generation request and, on a successful result or cache
hit, the item used for generated parts and sockets. Attachment uses the
current presentation ID in a Bevy `Name`; that source text is not proof of a
player-visible label or successful rendering. The possible identity mismatch
therefore remains conditional on the relevant execution, success and consumer
paths. Same-item hold/drop retention and the old placement/layer semantics
must be considered when deciding the intended behavior; they were not
validated at runtime here.

## Relationships and remaining work

Original q0's continuation receipt links an earlier M07 presentation/fit
policy and a separate M06 error-context question. Those historical labels
are reported as recorded, not accepted aliases or finding counts. Original
059 q61 and f2ec ledger row 217,
`ADLER-L11-RUNTIME-EQUIPMENT-FAILURE-OWNERSHIP`, concern owned fit/preparation
failure context and readiness under Lens 11. They are related to the same
family but have a distinct first question and retain their original reviewer
and lens attribution. Bounded literal and equipment-family searches do not
establish global alias absence.

The remaining decisions include the supported lifetime and mutation contract
for a tactical item ID, any actual producer and scheduling path, correct
ownership of current item versus previous fit, previous-fit preservation for
unchanged items, connected cache/socket/material consumers, historical M07
and M06 reconciliation, and exact current aliases. Full source complements
and native behavior remain unassessed. No repair or acceptance claim is made.

## Recovery, replay and limitations

The evidence-only verifier checks the two queue streams and f2ec snapshot,
selected historical receipts and exact candidate, 20 selected Git-bound source
paths, 35 captured source windows, complete historical diff reconstruction,
the old/current generation diff and the placeholder function equality. It
does not prove source-reader attention, product behavior, complete old source
coverage, privacy beyond the bounded scan, or independent custody. Strongest
replay requires the separate restricted collection containing raw Git objects,
source and path-bearing receipts; current custody is same-machine only. No
individual removed local-path digest is published.

The first lookup for 95e in the ordinary worktree object store failed; the
separate evidence checkout supplied it and the captured Git proof. A guessed
f82 path for the old 1474 base was absent, with empty stdout and Git stderr
preserved; the tool-visible assertion traceback was not separately captured
byte-for-byte. The hash-matching base was subsequently found in older local
collections. A checked 6533 parent candidate did not match either historical
before file. The recovered behavior-010 and source-pin metadata were located
by filename and internal relationships, not independently authenticated as
paths in the three specifically searched Git trees; their bytes and exact
diff relationships are preserved. The historical erratum and later
correction to the unrelated icon comparison remain distinct records.

Preserve normalized recovered 774 separately from missing pre-export
originals, the SOURCE004 and 73 nontext/no-positive-EOF qualifications, and
the absent checkpoint 3821. Older evidence is not promoted into 3821. No
protected extraction, product source, publication or central ledger was
modified.
