#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def walkdiff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return sum(([path+'/'+k] if k not in a or k not in b else walkdiff(a[k],b[k],path+'/'+k) for k in sorted(set(a)|set(b))),[])
 if isinstance(a,list):return [path+'/length'] if len(a)!=len(b) else sum((walkdiff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='d17e1f33e588d120f10537100d6b9cdb9afe1a9358018580601c1e40fc522b2c';verify_manifest(root,'MANIFEST-PRIVATE.json')
 source=proof(root,'SOURCE-GIT-PROOF.json','git-objects',True);cp=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);hist=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert len(source)==12 and len(cp)==4 and len(hist)==3
 old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';rec='dac7d0055716053f245139971eb67ddfd87fa462';qp='baseline-059/queue.json';assert sha(hist[(old,qp)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(hist[(rec,qp)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 ids=[147,148,3143,3145,3243,3244,3246,3247,3255,3256,3258,3259];a=exact_selections(hist[(old,qp)],ids);b=exact_selections(hist[(rec,qp)],ids);selected={x['index']:x for x in json.loads((root/'HISTORICAL-SELECTED.json').read_bytes())}
 for i in ids:assert a[i][0]==b[i][0]==selected[i]['original']==selected[i]['reconstructed']
 q148=a[148][0];match=[x for x in q148['exact_source_identities_and_assessed_ranges'] if x['source_id'].endswith('/space.rs')];assert len(match)==1 and all(match[0][x] is None for x in ['revision_as_recorded','git_path_as_recorded','attribution_as_recorded']);adler=(root/'ADLER-READ-L11-356.json').read_bytes();assert sha(adler)=='f1b81a13b5eb0ad1e9a72de680aa75412c0d01dea8c4040d09875c9aca0b529c' and json.loads(adler)['sources'][1]['fresh_reads']==[[1,356]]
 ede='ede12d3f9f19d284abbc669b5ae38b814a585f77';f2='f2ec8cbad7becbcc9a8e9da22ba512f52975768f';base0=json.loads(cp[(ede,'BASELINE-95E-20261110.json')]);base1=json.loads(cp[(f2,'BASELINE-95E-20261110.json')]);q0=json.loads(cp[(ede,'RECONCILIATION-059.json')])['entries'];q1=json.loads(cp[(f2,'RECONCILIATION-059.json')])['entries'];r0=base0['newly_assessed_ledger']['entries'];r1=base1['newly_assessed_ledger']['entries'];assert len(r0)==1099 and len(r1)==1101 and r1[:1099]==r0;assert all(q0[i]==q1[i] for i in ids)
 assigned=[3243,3244,3246,3247,3255,3256,3258,3259];assert all(q1[i]['current_reconciliation']=='unassessed' and q1[i]['contract_id']==a[i][0]['contract_id'] for i in assigned);assert all(a[i][0]['body_or_population_credit']==0 for i in assigned)
 for i,id in [(493,'ADLER-L11-PIXEL-BUFFER-IDENTITY-ADMISSION'),(494,'ADLER-L11-COLOR-PRIMARY-INVERSION-ADMISSION')]:assert r1[i]['id']==id
 for id in ['relationship-yuv-odd-plane-row-stride-95e','relationship-color-encoded-origin-95e']:assert id not in [x.get('id') for x in r1]
 rootdraft=root/'draft-inputs';o=rootdraft/'postf2ec-color-owners-wgsh2rwc';c=rootdraft/'postfreeze-color-central-sk8a2kea';z=rootdraft/'postf2ec-central-combined-x5e99vf6';owner=json.loads((o/'DRAFT-OWNERS-v2.json').read_bytes());color=json.loads((c/'DRAFT-v3.json').read_bytes());v1=json.loads((z/'DRAFT.json').read_bytes());v2=json.loads((z/'DRAFT-v2.json').read_bytes());v3=json.loads((root/'combined-v3/DRAFT-v3.json').read_bytes());v4=json.loads((root/'combined-v4/DRAFT-v4.json').read_bytes())
 assert sha((root/'combined-v4/DRAFT-v4.json').read_bytes())=='8e02160bd01b6a143333e1a843d7506f5352c85edfbd2769d96b29488b4570bb';expected={(g,x['queue_index']):x for g,y in [('color-v3',color),('owners-v2',owner)] for x in y['partial_queue_assessments']};actual={(x['source_group'],x['record']['queue_index']):x['record'] for x in v2['partial_queue_assessments']};assert expected==actual and len(actual)==8;assert [x['record'] for x in v2['ledger_relationships']]==color['ledger_relationships'] and v2['partial_queue_assessments']==v1['partial_queue_assessments'] and v2['ledger_relationships']==v1['ledger_relationships']
 assert '/status' in walkdiff(v1,v2);assert set(walkdiff(v2,v3))=={'/partial_queue_assessments/2/record/summary','/partial_queue_assessments/6/record/history','/partial_queue_assessments/6/record/source_refs/2','/partial_queue_assessments/6/record/summary','/predecessor_draft_sha256','/process_qualification','/review_qualification','/sanitization_qualification'};assert set(walkdiff(v3,v4))=={'/chronology_qualification','/predecessor_draft_sha256','/process_qualification','/successor_created_utc'};assert v4['partial_queue_assessments']==v3['partial_queue_assessments'] and v4['ledger_relationships']==v3['ledger_relationships'] and v4['counts']==v3['counts']
 for oldfile,newfile,corfile in [(o/'DRAFT-OWNERS.json',o/'DRAFT-OWNERS-v2.json',o/'DRAFT-OWNERS-v2-CORRECTION.json'),(c/'DRAFT.json',c/'DRAFT-v2.json',c/'DRAFT-v2-CORRECTION.json'),(c/'DRAFT-v2.json',c/'DRAFT-v3.json',c/'DRAFT-v3-CORRECTION.json'),(z/'DRAFT.json',z/'DRAFT-v2.json',z/'DRAFT-v2-CORRECTION.json'),(z/'DRAFT-v2.json',root/'combined-v3/DRAFT-v3.json',root/'combined-v3/CORRECTION-v3.json'),(root/'combined-v3/DRAFT-v3.json',root/'combined-v4/DRAFT-v4.json',root/'combined-v4/CORRECTION-v4.json')]:
  cor=json.loads(corfile.read_bytes());assert cor['predecessor_sha256']==sha(oldfile.read_bytes()) and cor['successor_sha256']==sha(newfile.read_bytes())
 assert v4['counts']=={'new_partial_queue_assessments':8,'semantic_queue_closures':0,'new_planning_relationships':2,'accepted_unique_defect_increment':0,'lens_completions':0};assert v4['repair']=='not started' and v4['product_validation']=='not performed'
 revs=['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','95e63628f9d70b8dd6e6fede64334696c6995009'];paths={'delegate-yuv':('yuv.raw','crates/fabelgeist-color/src/yuv.rs',503),'delegate-space':('space.raw','crates/fabelgeist-color/src/space.rs',356)}
 for label,(raw,path,eof) in paths.items():
  d=root/label;m=json.loads((d/'MANIFEST.json').read_bytes());rr=json.loads((d/'READ-RECEIPT.json').read_bytes());reg=json.loads((d/'SOURCE-REGISTRATION.json').read_bytes());assert reg['reviewer']=='/root/mhr_character'
  for file in d.rglob('*'):
   if file.is_file() and file.name!='MANIFEST.json':
    rel=file.relative_to(d).as_posix();assert rel in m['files'] and sha(file.read_bytes())==m['files'][rel]['sha256']
  for k,row in enumerate(rr['rows'][:3]):
   assert row['revision']==revs[k] and row['path']==path and row['eof']==eof;body=(d/row['source_file']).read_bytes();assert body==source[(revs[k],path)]==(root/raw).read_bytes();lines=body.decode().splitlines();covered=[]
   for view in row['views']:
    lo,hi=view['range'];covered+=list(range(lo,hi+1));captured=(d/view['file']).read_bytes();expectedview=''.join(f'{i}: {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert captured==expectedview and sha(captured)==view['sha256']
   assert covered==list(range(1,eof+1))
 for name,h in [('prior-l3-read.json','3c8a1b3c13e7c0f2be5190fba6c799be1861add624e5191b059f7a57123900b8'),('prior-l3-current-read.json','0243b780d725d732b5daa508005afd5d72eb332d739318c298cb623e27d81718')]:assert sha((root/name).read_bytes())==h
 prior=json.loads((root/'prior-l3-read.json').read_bytes())['rows'];current=json.loads((root/'prior-l3-current-read.json').read_bytes())['rows'];assert prior[0]['fresh_personal_ranges']==[[1,503]] and prior[1]['fresh_personal_ranges']==[[1,356]] and current[9]['fresh_personal_ranges']==[] and current[10]['fresh_personal_ranges']==[] and current[9]['qualified_reuse_ranges']==[[1,503]] and current[10]['qualified_reuse_ranges']==[[1,356]]
 reg=json.loads((root/'REGISTRATION-005.json').read_bytes())
 for s in reg['specifications']:
  body=(root/(s['label']+'.raw')).read_bytes();assert body==source[(revs[2],s['path'])]
  for lo,hi in s['ranges']:window(root,s['label']+'.raw',f"{s['label']}-view-{lo}-{hi}.txt",lo,hi)
 window(root,'cargo.raw','cargo-view-1-25.txt',1,25)
 def render(label,body,ranges):
  lines=body.decode().splitlines();return ''.join('\n--- '+label+' '+str(lo)+'-'+str(hi)+' ---\n'+''.join(str(i)+': '+lines[i-1]+'\n' for i in range(lo,hi+1)) for lo,hi in ranges).encode()
 for directory,draftname in [(o,'DRAFT-OWNERS-v2.json'),(c,'DRAFT-v3.json')]:
  rr=json.loads((directory/'REGISTRATION.json').read_bytes());dd=json.loads((directory/draftname).read_bytes());index={x['label']:x for x in dd['registered_source_views']}
  for view in rr['views']:
   label=view['label'];src=(directory/'sources'/(label+'.source')).read_bytes();out=(directory/(label+'-DISPLAY.txt')).read_bytes();assert sha(src)==view['sha256'] and out==render(label,src,view['planned_display']) and sha(out)==index[label]['display_sha256']
 wrapper=json.loads((o/'OWNER-WRAPPER-REGISTRATION.json').read_bytes());wrapout=(o/'OWNER-WRAPPER-DISPLAY.txt').read_bytes();assert wrapper['lenses']==[2,6] and wrapout==render('conversion',(root/'conversion.raw').read_bytes(),wrapper['planned_display']) and owner['wrapper_registration_sha256']==sha((o/'OWNER-WRAPPER-REGISTRATION.json').read_bytes()) and owner['wrapper_display_sha256']==sha(wrapout)
 sig=json.loads((c/'ENCODER-SIGNATURE-REGISTRATION.json').read_bytes());lo,hi=sig['planned_display'];lines=(root/'yuv.raw').read_text().splitlines();assert (c/'ENCODER-SIGNATURE-DISPLAY.txt').read_bytes()==''.join(f'{i}: {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 print('restricted proofs, selected queues and ledger, six correction links, delegate windows, historical attribution and current display captures: PASS')
 print('Evidence-only verification; display events, semantic closure, product behavior, global privacy, independent custody and checkpoint3821 are not established.')
if __name__=='__main__':main()
