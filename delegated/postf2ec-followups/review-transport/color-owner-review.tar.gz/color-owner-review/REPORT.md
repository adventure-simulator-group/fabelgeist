# Independent review of color owner and combined drafts

The bounded source and evidence review found no remaining blocking discrepancy
in combined draft v4. It proposes eight partial assessments and two planning
relationships; the eight f2ec queue entries remain unassessed in the frozen
checkpoint. No semantic closure, accepted unique-defect increment, lens
completion, repair or product validation is asserted.

The successor is bound to SHA-256
`8e02160bd01b6a143333e1a843d7506f5352c85edfbd2769d96b29488b4570bb`.
Relative to v3 it changes only the chronology qualification, predecessor hash,
process qualification and separate successor timestamp. Its eight assessment
and two relationship values are unchanged. Earlier v1, v2 and v3 drafts and
corrections remain restricted originals. V2's claim that only custody locators
changed was incomplete: its status also clarified that independent review of
the combined successor was pending. V3 records that distinction and preserves
the earlier correction. V3 also clarifies two source statements:

* `Bt709.to_linear_space().to_gamma_space()` returns `Srgb`; a direct
  `Bt709.to_gamma_space()` returns `Bt709` (`space.rs:294-310`). Whether an
  encoded-origin round trip is required remains a caller policy question.
* My separately registered full read of `fabelgeist-color/Cargo.toml:1-25`
  found no direct `fabelgeist-math` dependency. The coordinator's original
  manifest display was only lines 8–12; transitive dependencies remain open.

V4 discloses that owner v2 and central color v2/v3 inherited their original
`created_utc` fields, which precede their separately registered supplemental
reads. Those inherited fields are not successor-creation times or proof of
an earlier read. The new v4 successor timestamp is distinct. The owner v1
wrapper claim had originally relied on Lens 1/5 scope; its v2 adds the
separately registered Lens 2/6 wrapper windows and retains the correction.
The supplemental registration and captured text match pinned source, but the
coordinator's act of displaying it remains coordinator-reported.

## Source and history checks

I independently displayed registered 95e windows under the existing-owner
and type-ownership lenses. `YuvStandard`, `YuvRange`, chroma subsampling,
pixel format and channel layout retain distinct roles; shared BT.709 names
and the existing RGBA `Color` do not establish an interchangeable YCbCr or
validated-plane owner (`yuv.rs:4-140`; `pixel.rs:4-105,215-231,288-292`;
`color.rs:4-54`). The selected wrapper fixes BT.709/full range
(`conversion.rs:184-212,215-245,377-403`). The selected `Chromaticity`,
`ColorPrimaries`, `WhitePoint`, `ColorSpace`, `Ratio` and `ColorTransform`
sources support the draft's bounded distinctions (`space.rs:6-17,31-95,
145-150,231-291`; `units.rs:1-20,62-69`; `conversion.rs:107-149`). ACES
blue has a negative listed y coordinate, so a universal [0,1] rule would
exclude that listed standard. Broader owner searches and native policy remain
open.

On paper, for 3×3 NV12 the wrapper accepts a YUV buffer of exactly 13 bytes
with sufficient RGBA storage: nine luma bytes and four chroma bytes. The
shown decoder reaches chroma index 4 after earlier assignments, and the
encoder writes index 3 before attempting index 4 (`conversion.rs:175-212,
377-403`; `yuv.rs:147-168,183-191,251-327`). Width-byte row stride also
makes the first row's final V and second row's first U share offset 3. The
supported odd-dimension/stride policy, actual callers, native outcome and
partial-write policy remain open. This refines q3145 and ledger row 495 and
is not automatically an alias of q147/row 493 or a new accepted count.

For symbolic custom primaries red = green = blue = (0.25, 0.25), the shown
basis has identical finite columns. The inverse returns `None` and the
basis-inverse fallback substitutes identity; the subsequently calculated
final matrix is not asserted to be identity (`space.rs:145-203,207-228`).
Supported custom inputs and finite, invertibility and near-singular policy
remain open. This is related to q148 and ledger row 494, not a new count.
No conversion or calculation code was executed.

The owner registration and seven captured displays, the central registration
and five captured displays, and the separately registered wrapper and encoder
signature windows match their exact source slices and stated hashes. This
proves captured bytes and bindings, not the act of viewing. The same delegate
separately recorded one complete personal display per historical/current
revision for each assigned source, each applied to four named lenses. The
36 retained primary view chunks match those manifest-bound receipts and their
source slices; the delegate, coordinator and this reviewer have separate read
credit. Full delegate packets remain separate custody items.

Original 059 and reconstructed records agree as parsed values for the twelve
selected history indices. The full queue streams remain distinct. At f2ec,
q3243/3244/3246/3247 and q3255/3256/3258/3259 are unassessed. The ede ledger
has 1,099 rows and is a parsed prefix of f2ec's 1,101 rows; the two proposed
relationship IDs are absent by exact ID only. These facts do not prove global
semantic alias absence. The original q148 space row has null recorded revision,
Git path and attribution; the separately hash-verified Adler receipt records a
fresh 1–356 read. Matching source bytes do not fill those null fields. Earlier
Root Lens 3 6533 fresh reads and e275 same-lens reuse remain separately
attributed and do not grant Lens 2/6 credit.

The evidence preserves recovered originals, reconstructed records, historical
summaries and newly assessed work separately. The normalized 774 catalog is
not a substitute for missing pre-export originals. SOURCE004, the 73
nontext/no-positive-EOF obligations and missing checkpoint 3821 retain their
qualifications. One initial batched output was tool-truncated and two metadata
summaries were sliced; full captured inputs and subsequent targeted checks are
retained. Restricted objects and path-bearing originals are in same-machine
custody, not independent public recovery. The verifier checks selected bytes,
registrations, history, correction chain and bindings; it does not prove
semantic correctness, global privacy, product behavior or full audit closure.
