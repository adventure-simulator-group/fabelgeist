#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None: print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='479e858a42532ec66616821a7cad4eae0d7225a5a36e5d19393db4a2ba6e6596';verify_manifest(root,'MANIFEST-PRIVATE.json')
 source=proof(root,'SOURCE-GIT-PROOF.json','git-objects',True);checkpoint=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);history=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert len(source)==14 and len(checkpoint)==2 and len(history)==3
 revs=['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','95e63628f9d70b8dd6e6fede64334696c6995009'];path='crates/strategic-web/src/templates/settlement/character_skills.rs';expected='38f67a86433b56274d2b29fcf8a12e129f973f07b9744fe8117b603674f25314'
 assert all(sha(source[(r,path)])==expected and source[(r,path)]==source[(revs[0],path)] for r in revs);assert len(source[(revs[0],path)].decode().splitlines())==3812
 old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';rec='dac7d0055716053f245139971eb67ddfd87fa462';hpath='baseline-059/queue.json';assert sha(history[(old,hpath)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert sha(history[(rec,hpath)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 assigned=[3425,3426,3428,3429];related=[199,200,628,2454,2455,2491,2494,2495,3300,3301,3444];indices=assigned+related;oldsel=exact_selections(history[(old,hpath)],indices);newsel=exact_selections(history[(rec,hpath)],indices)
 for i in indices:assert oldsel[i][0]==newsel[i][0]
 for i,lens in [(3425,1),(3426,2),(3428,5),(3429,6)]:
  q=oldsel[i][0];assert q['lens']==lens and q['body_or_population_credit']==0 and q['status']=='own-lens-proof-qualification-or-read-pending' and q['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[2356,2494]]
  for label in ['original','reconstructed']:assert json.loads((root/f'{label}-q{i}-projection.json').read_bytes())==q
 selected=json.loads((root/'historical-related-selected.json').read_bytes());selected+=json.loads((root/'additional-related-selected.json').read_bytes());selected={x['index']:x['row'] for x in selected if x.get('family','historical')=='historical'}
 for i in related:assert selected[i]==oldsel[i][0]
 f2ec='f2ec8cbad7becbcc9a8e9da22ba512f52975768f';base=checkpoint[(f2ec,'BASELINE-95E-20261110.json')];rq=checkpoint[(f2ec,'RECONCILIATION-059.json')];assert sha(base)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041';assert sha(rq)=='73bc3864944276b88944163257e3cfc67dde6141b2dc3f82588af66621003945';q=json.loads(rq)['entries'];assert len(q)==3713
 for i in assigned:assert q[i]['current_reconciliation']=='unassessed' and q[i]['contract_id']==oldsel[i][0]['contract_id']
 rows=json.loads(base)['newly_assessed_ledger']['entries'];assert len(rows)==1101
 for i,id in [(18,'REVIEW-IMMEDIATE-ACTIVITY-AMBIENT-LANGUAGE-001'),(89,'REVIEW-SCHEDULE-PARALLEL-ALLOCATION-001'),(817,'REVIEW-APPRENTICESHIP-PRESENCE-GATE-95E')]:assert rows[i]['id']==id
 for n,h in [('l2-read.json','b7fe7d69310e522f8ae05bdbeded0b382a244466b8b203a3e467f55f10ee418a'),('l2-current.json','8d7f814a71196f3f7f4cd65431dedab06b8dcc5d49c232ade34d5d9e2618fa5f'),('l3-read.json','aa82e492538046b554bf8a923e1193c33e92d1dd00c6fa81fc09ca7d5bcdc5b1'),('l3-current.json','9ece5d4f9868e490e6f19fcb0a3be2612bebda985c6b2ee3fe1b2d4dfed1da09')]:assert sha((root/n).read_bytes())==h
 l2=json.loads((root/'l2-read.json').read_bytes())['rows'];l2c=json.loads((root/'l2-current.json').read_bytes())['rows'];assert l2[8]['fresh_personal_ranges']==[[2356,2488]] and l2[9]['fresh_personal_ranges']==[[2489,2494]] and l2c[10]['fresh_personal_ranges']==[] and l2c[11]['fresh_personal_ranges']==[];assert l2c[10]['qualified_same_lens_reuse_ranges']==[[2356,2488]] and l2c[11]['qualified_same_lens_reuse_ranges']==[[2489,2494]]
 l3=json.loads((root/'l3-read.json').read_bytes())['rows'][0];l3c=json.loads((root/'l3-current.json').read_bytes())['rows'][11];assert l3['fresh_personal_ranges']==[[2356,2494]] and l3c['fresh_personal_ranges']==[] and l3c['qualified_reuse_ranges']==[[2356,2494]]
 peer=json.loads((root/'peer-0052-MANIFEST.json').read_bytes());assert sha((root/'peer-0052-MANIFEST.json').read_bytes())=='e06a2e0da3a01730788572b6e53ffc75dee3a02ed8760e9d635e5a7335101d05'
 for n in ['SOURCE-REGISTRATION.json','SOURCE-READ-RECEIPT.json','REPORT.md']:
  b=(root/('peer-0052-'+n)).read_bytes();assert sha(b)==peer['files'][n]['sha256'] and len(b)==peer['files'][n]['bytes']
 peerread=json.loads((root/'peer-0052-SOURCE-READ-RECEIPT.json').read_bytes());assert peerread['actual_display_ranges']==[[1,2355]] and peerread['unread_complement']==[[2356,3812]]
 windows=[('source-95e.raw','display-2356-2425.txt',2356,2425),('source-95e.raw','display-2426-2494.txt',2426,2494)]
 for a,b in [(1000,1055),(1195,1255),(2250,2355),(1065,1105),(795,855)]:windows.append(('source-95e.raw',f'context-{a}-{b}.txt',a,b))
 for label,ranges in [('immediate-js',[(1,80),(81,157)]),('training-js',[(1,80),(220,300),(480,528),(300,430),(431,479)]),('web-activity',[(85,210),(1,85)]),('native-activity',[(165,270),(271,335)]),('core-schedule',[(1,80),(155,245),(80,155),(285,364)]),('web-schedule',[(1,99)]),('native-model',[(35,98)]),('character-details',[(135,170),(225,305)]),('location-personal',[(160,220),(219,250)]),('schedule-preview',[(1,45)]),('router',[(335,355)]),('source-95e',[(856,885)])]:
  for lo,hi in ranges:windows.append((label+'.raw',f'{label}-{lo}-{hi}.txt',lo,hi))
 assert len(windows)==31
 for x in windows:window(root,*x)
 print('restricted manifest, 14 source/revision bindings, f2ec, queue proofs, prior/peer receipts and 31 source displays: PASS')
 print('Scope: evidence bytes and registered displays only; no product execution, semantic closure, runtime validation, independent custody or checkpoint 3821 claim.')
if __name__=='__main__':main()
