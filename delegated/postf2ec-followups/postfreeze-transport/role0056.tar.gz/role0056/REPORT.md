# Role 0056: schedule and immediate-activity presentation

This source-only assessment by `verifier_scope` follows published f2ec. The
original 059 obligations q3425, q3426, q3428 and q3429 map respectively to
Lens 1 producer propagation, Lens 2 existing owners, Lens 5 aggregate states
and Lens 6 type ownership. The immutable f2ec reconciliation marks all four
unassessed. Central reconciliation owns their disposition and connected ledger;
this report claims neither lens completion nor a new unique count.

The assigned `crates/strategic-web/src/templates/settlement/character_skills.rs`
range is 2356–2494 of a 3,812-line file. Historical 6533 and e275 and
current authoritative 95e have the same Git blob
`112b3aac2da0828be2b60c23e7989ecac422dd81` and SHA-256
`38f67a86433b56274d2b29fcf8a12e129f973f07b9744fe8117b603674f25314`.
I personally displayed the assigned range once in two registered chunks and
applied the four lenses to that shared body. Selected connected source windows
were separately registered and displayed; file capture does not grant a read
of undisplayed lines. No product code, test, fixture, build or probe was run.

## Conditional source relationships

* **Socializing immediate action.** With skills, a schedule, an action URL and
  settlement activity context, the view renders a Socializing row with an
  actionable immediate button (`character_skills.rs:1023-1043,1084-1089,
  1231-1234,2287-2350,2398-2415`). The dialog contains the activity form
  (`:2433-2448`); its browser handler removes `_minutes` from the row's
  `socializing_minutes` name and assigns `socializing` to the hidden activity
  field (`immediate-activity.js:16,102-121`). Once the route's prior session,
  active character and location checks pass, its mapping has no socializing
  case and returns `BAD_REQUEST` (`training_activity.rs:117-179`). The native
  `ImmediateActivity` enum also has no Socializing variant (`time/model.rs:
  58-72`), and its dispatcher covers only the existing variants
  (`time/activities.rs:179-201`). The active character view supplies the
  schedule path and activity location (`character_details.rs:241,271-298`;
  `location_personal.rs:219-226`). These are source conditions and ordinary
  event/data flow, not an observed interaction, successful authorization or
  runtime outcome. A connected policy decision must determine whether that
  immediate control should exist and what behavior is intended before any
  UI, web-dispatch or native change. Historical q2495 records a broader scoped
  native-presentation disposition; f2ec row 18 concerns a different
  immediate-activity ambient-language first operation. Neither is an automatic
  alias or count for this trace.
* **Zero-minute organization selection.** The preview map can contain known
  roles for active, dues-current, chapter-valid memberships when attributes
  are available (`character_skills.rs:806-838,856-870`). For such a nonempty
  map the view falls back to its first training organization, and similarly
  to the first eligible practice organization, independently of that activity's
  saved minutes (`:1235-1245`). The assigned helper emits each selected ID in
  a named, enabled select without a blank option (`:2356-2371`). If the selected
  ID is nonempty and the associated minutes are zero, ordinary form
  serialization supplies both values (`training-schedule.js:373-383`); the
  web form converts them unchanged and validation rejects the zero/nonempty
  combination (`training_activity.rs:1-35,70-87`; `schedule.rs:11-39`;
  `strategic_schedule/allocation.rs:39-57,113-131`). The read-only preview
  applies the same conversion (`schedule_preview.rs:10-32`). This conclusion
  is conditional on the stated membership, rendered form and request path;
  actual player state, browser activity and a production failure were not
  observed. A connected resolution must preserve legitimate zero-minute
  schedules and reconcile selection display, form transport and authoritative
  admission. Historical q2494 retains the broader admission and optional-mode
  question. Historical q628 concerns direct public `Scheduled` admission;
  q3444 concerns organization identity ownership. Their first operations and
  reviewer credits remain distinct. F2ec ledger row 817 concerns representative
  presence, another distinct dependency. No global alias is inferred.

## Lens dispositions and unresolved scope

The raw IDs, activity names and minute scalars cross an HTML/form boundary.
The inspected core already has `ActivityMinutes`, `OrganizationAllocation`
and `ValidatedSchedule` (`allocation.rs:7-57,177-196`); web conversion
constructs the validated schedule before effective preview (`schedule.rs:
11-62`). Their existence alone does not prove that native browser strings or
hidden scalar inputs need another Rust owner. The two conditions above concern
agreement across producers, retained form state and consumers; the exact owner
and dependency direction of any later change remain open.

`format_schedule_hours` widens a `u16`, adds seven and rounds to a 15-minute
multiple for display (`character_skills.rs:2482-2492`); the allocation input
retains the supplied minute value (`:2383-2393`). The inspected validated
schedule requires quarter-hour increments and a daily total limit
(`allocation.rs:28-36,181-196`). This bounded comparison does not establish a
supported invalid stored allocation or a display defect. Initialization also
snaps hidden fields to quarter hours (`training-schedule.js:242-246`); its
complete save/error policy and all possible writers remain outside this
review. Other source ranges and native consumers are not exhausted.

Original q2455 explicitly left 2356–3812 unassessed in its earlier selected
scope. Original q2494 and q2495 preserve Root's fresh Lens 2 6533 reads of
2356–2488 and 2489–2494; their e275 receipts record same-lens reuse with zero
fresh current reread. The separate historical Lens 3 receipt records Root's
fresh 6533 read of 2356–2494 and e275 same-lens reuse, and grants no other-lens
credit. The earlier role 0052 reviewer independently displayed 1–2355 and
marked 2356–3812 unread in that packet; this assessment's adjacent reads have
separate attribution. A peer's initial range shorthand was corrected; a
reconstructed process note and the exact manifest-bound peer registration and
receipt are retained.

The original 059 queue is bound to evidence commit 56f; the separately
identified dac7d queue is reconstructed. The selected historical records
agree as parsed JSON, not as a claim that the full streams agree. The 774
catalog is normalized recovery material and pre-export originals are missing;
SOURCE004 and the 73 nontext/no-positive-EOF obligations keep their limits.
No earlier evidence is promoted to missing checkpoint 3821. Historical
summaries, recovered originals, reconstructed projections and this new read
remain distinct.

The restricted collection retains a truncated filename-only peer locator, a
clipped historical metadata print and its complete selected records, plus
registered compact successor selections. A few registered source windows
include test-module text; these were read as source and no tests were executed.
Compressed Git commits and local-path provenance stay restricted. The replay
binds source/object paths, selected history, peer receipts, f2ec state and
registered displays; it does not establish semantic accuracy, runtime
behavior, global privacy, independent custody or checkpoint 3821 recovery.
