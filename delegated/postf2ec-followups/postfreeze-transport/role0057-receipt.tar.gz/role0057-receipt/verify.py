#!/usr/bin/env python3
"""Read-only identity and recorded-scan verification; not a privacy proof."""
import pathlib,json,hashlib,argparse,sys
P=pathlib.Path(__file__).resolve().parent
def sh(b):return hashlib.sha256(b).hexdigest()
def J(x):return json.loads(x.read_bytes())
def main():
 a=argparse.ArgumentParser();a.add_argument('--public',required=True,type=pathlib.Path);a=a.parse_args();m=J(P/'MANIFEST.json');actual={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'}
 if actual!=set(m['files']):raise ValueError('file set')
 for n,v in m['files'].items():
  f=P/n;b=f.read_bytes()
  if sh(b)!=v['sha256'] or len(b)!=v['bytes'] or (f.stat().st_mode&0o777)!=v['mode']:raise ValueError('receipt file identity')
 r=J(P/'REPORT.json');raw=J(P/'raw-scan.json');g=J(P/'gpu-scan.json');q=J(P/'q2332-scan.json');z=J(P/'059-scan.json')
 if sh((a.public/'MANIFEST.json').read_bytes())!=r['public_manifest_sha256'] or raw['public_manifest_sha256']!=r['public_manifest_sha256']:raise ValueError('public manifest binding')
 if any(raw['matches'].values()) or g['forbidden_digest_total'] or g['exceptions'] or q['matching_occurrences'] or q['exceptions'] or z['matching_occurrences'] or z['exceptions']:raise ValueError('recorded finding')
 print(json.dumps({'result':'pass','public_manifest_sha256':r['public_manifest_sha256'],'qualification':'Identity and recorded outcomes only; private corpora required for independent scan replay.'}))
if __name__=='__main__':
 try:main()
 except Exception as e:print('receipt verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
