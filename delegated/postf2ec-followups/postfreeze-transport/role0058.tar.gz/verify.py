#!/usr/bin/env python3
# Evidence-only replay: does not import or execute product code.
import argparse,hashlib,json,pathlib,stat,subprocess,sys
if sys.flags.optimize:raise SystemExit('Optimized execution unsupported.')
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
def load(n):return json.loads((P/n).read_bytes())
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def safe(d,n):
 q=pathlib.PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts;return d.joinpath(*q.parts)
def tree(b):
 o={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);assert z+21<=len(b);n=b[a+1:z].decode();assert n not in o;o[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return o
def prove(root,path,data):
 for part in path.split('/'):
  t=(P/'trees'/(root+'.tree')).read_bytes();assert oid('tree',t)==root;mode,root=tree(t)[part]
 assert mode=='100644' and oid('blob',data)==root
def manifest():
 m=load('MANIFEST.json');fs={q.relative_to(P).as_posix() for q in P.rglob('*') if q.is_file() and q!=P/'MANIFEST.json'};ds={q.relative_to(P).as_posix() for q in P.rglob('*') if q.is_dir()};assert fs==set(m['files']) and ds==set(m['directories']) and not any(q.is_symlink() for q in P.rglob('*'))
 for n,x in m['files'].items():
  q=safe(P,n);b=q.read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256'] and stat.S_IMODE(q.stat().st_mode)==x['mode']
 for n,mode in m['directories'].items():assert stat.S_IMODE(safe(P,n).stat().st_mode)==mode
ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if a.skip_manifest:print('NOT CHECKED: public manifest (--skip-manifest).')
else:manifest();print('public exact inventory, modes and hashes: pass')
source=(P/'source/95e.rs').read_bytes();assert H(source)=='87bb6b40cc4c57605e3b8c0601b6db29818a0a548aa8d3d4c3b136f55411f001' and len(source.splitlines())==99
primary=load('SOURCE-005-CAPTURE-RESULT.json');assert len(primary)==3
for x in primary:assert x['sha256']==H(source) and x['EOF']==99;prove(x['root'],x['path'],source)
root='1eec97de340d9b7debbb30ca0c0fb2240a73b93f';rows={primary[-1]['path']:{'file':'source/95e.rs'}}
for name in ['SUPPORT-009','SUPPORT-011','SUPPORT-012','SUPPORT-015','SUPPORT-016','SUPPORT-022','SUPPORT-025']:
 for x in load(name+'-CAPTURE-RESULT.json'):
  assert x['root']==root;b=safe(P,x['file']).read_bytes();assert H(b)==x['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['EOF'];prove(root,x['path'],b);rows[x['path']]=x
print('historical/current source blob-to-declared-root proofs and pinned support: pass')
print('NOT CHECKED from public data alone: commit-to-root links or original private queue membership.')
reg=load('SOURCE-006-DISPLAY-REG.json');assert reg['queues']==[3459,3460,3462,3463] and reg['lenses']==[1,2,5,6] and reg['planned_ranges']==[[1,99]]
ls=source.decode().splitlines(keepends=True);x=load('SOURCE-006-DISPLAY-RESULT.json');b=safe(P,x['file']).read_bytes();assert H(b)==x['sha256'] and b.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(1,100))
for name in ['SUPPORT-010','SUPPORT-012','SUPPORT-013','SUPPORT-016','SUPPORT-020','SUPPORT-023','SUPPORT-026','SUPPORT-027','SUPPORT-029']:
 reg=load(name+'-DISPLAY-REG.json');out=load(name+'-DISPLAY-RESULT.json');assert [(x['path'],x['range']) for x in out]==[(v['path'],r) for v in reg['views'] for r in v['ranges']]
 for x in out:
  ls=safe(P,rows[x['path']]['file']).read_text().splitlines(keepends=True);lo,hi=x['range'];actual=safe(P,x['file']).read_bytes();assert H(actual)==x['sha256'] and actual.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
 assert (P/(name+'-READ.json')).is_file()
for skill in load('SKILLS-005-CAPTURE.json'):
 b=(P/'skills'/('lens-'+str(skill['lens'])+'.md')).read_bytes();assert H(b)==skill['sha256'] and len(b.splitlines())==skill['lines']
print('preregistered source windows and four focused skills: pass; displays are reviewer attestations')
cross=load('RECONSTRUCTION-CROSSWALK.json')
for x in cross['files']:
 b=safe(P,x['public_file']).read_bytes();assert H(b)==x['public_whole_sha256'] and len(b)==x['public_bytes']
 if a.private:
  original=safe(a.private,x['restricted_file']).read_bytes();assert H(original)==x['restricted_whole_sha256'] and len(original)==x['restricted_bytes'];out=bytearray();pos=0
  for v in x['spans']:
   off=v['offset'];assert off>=pos and off+v['length']<=len(original);out+=original[pos:off];out+=v['replacement'].encode();pos=off+v['length']
  out+=original[pos:];assert bytes(out)==b
if a.private:
 assert H((a.private/'MANIFEST.json').read_bytes())==cross['restricted_manifest_sha256']=='95c798ccf51e961dd7508b15b7ef5d9253524da6512144dbfee830e8eca693b3'
 cmd=[sys.executable,'-B',str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 assert subprocess.run(cmd,check=False).returncode==0
 print('public crosswalk against separately held originals: pass')
else:print('NOT CHECKED: public crosswalk against independently held originals; provide --private.')
print('No product behavior, unique count, checkpoint3821 recovery or overall audit closure is established.')
