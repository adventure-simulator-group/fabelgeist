#!/usr/bin/env python3
# Check selected reconstructed history against separately held original packet.
import argparse,json,pathlib,hashlib
P=pathlib.Path(__file__).resolve().parent
a=argparse.ArgumentParser();a.add_argument('--private',required=True,type=pathlib.Path);v=a.parse_args();R=v.private
h=lambda b:hashlib.sha256(b).hexdigest()
assert h((R/'MANIFEST.json').read_bytes())=='95c798ccf51e961dd7508b15b7ef5d9253524da6512144dbfee830e8eca693b3'
j=json.loads((P/'PUBLIC-HISTORY.json').read_bytes());rec=json.loads((R/'committed/reconciliation.stdout').read_bytes())['entries']
assert j['queues']=={'3459':1,'3460':2,'3462':5,'3463':6}
for k,l in j['queues'].items():
 x=rec[int(k)];assert x['historical_lens']==l and x['current_reconciliation']=='unassessed'
for name,key in [('root-l2/READ-ROOT-L2-EXT-055-066.json','historic_l2_read_sha256'),('root-l2/READ-ROOT-L2-CURRENT-011.json','historic_l2_current_sha256'),('READ-ROOT-L3-EXT-057-061.json','historic_l3_read_sha256'),('READ-ROOT-L3-CURRENT-007.json','historic_l3_current_sha256')]:assert h((R/'historical'/name).read_bytes())==j[key]
a=json.loads((R/'historical'/'root-l2/READ-ROOT-L2-EXT-055-066.json').read_bytes())['rows'][4];b=json.loads((R/'historical'/'root-l2/READ-ROOT-L2-CURRENT-011.json').read_bytes())['rows'][7];c=json.loads((R/'historical/READ-ROOT-L3-EXT-057-061.json').read_bytes())['rows'][1];d=json.loads((R/'historical/READ-ROOT-L3-CURRENT-007.json').read_bytes())['rows'][1]
assert a['fresh_personal_ranges']==c['fresh_personal_ranges']==[[1,99]] and b['fresh_personal_ranges']==d['fresh_personal_ranges']==[] and b['qualified_same_lens_reuse_ranges']==d['qualified_reuse_ranges']==[[1,99]] and d['frozen_source_adoption_pending'] is True
print('bounded history projection checks: pass; run verify.py --private for full restricted manifest and object checks')
