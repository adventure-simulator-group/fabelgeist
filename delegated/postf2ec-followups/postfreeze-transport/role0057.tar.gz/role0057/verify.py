#!/usr/bin/env python3
"""Read-only evidence replay. Does not execute product code."""
import argparse,gzip,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
def j(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(x,m):
 if not x:raise ValueError(m)
def safe(root,name):
 p=pathlib.PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return root.joinpath(*p.parts)
def tree(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'tree bounds');key=b[a+1:z].decode();need(key not in d,'duplicate tree entry');d[key]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repository');a=ap.parse_args();m=j(P/'MANIFEST.json');fs={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(fs==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest set')
 for n,v in m['files'].items():
  f=safe(P,n);b=f.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode'],'file '+n)
 for x in j(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(x['name']+'.md')).read_bytes();need(sh(b)==x['sha256'] and len(b.splitlines())==x['lines'],'skill')
 reg=j(P/'SOURCE-REGISTRATION.json');rr=j(P/'SOURCE-READ-RECEIPT.json');expected=[(3447,1),(3448,2),(3450,5),(3451,6)];need([(x['queue'],x['lens']) for x in reg['lenses']]==expected and [(x['queue'],x['lens']) for x in j(P/'ASSESSMENTS.json')['assessments']]==expected,'lenses');need(rr['sources']==reg['sources'] and rr['actual_display_ranges']==[[1,633]] and rr['unread_complement']==[[634,1251]],'assigned scope')
 bodies=[]
 for x in reg['sources']:
  b=(P/'sources'/(x['label']+'.rs')).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(b.decode().splitlines())==x['EOF']==1251,'source identity');bodies.append(b)
 need(len(bodies)==3 and len(set(bodies))==1,'shared source bytes');lines=bodies[0].decode().splitlines();seen=set()
 for v in rr['views']:
  lo,hi=v['range'];b=safe(P,v['file']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(lo,hi+1)] and v['registration_mtime_ns']<=v['view_created_mtime_ns'],'assigned view');need(not seen.intersection(range(lo,hi+1)),'view overlap');seen.update(range(lo,hi+1))
 need(len(rr['views'])==7 and seen==set(range(1,634)),'assigned coverage')
 sr=j(P/'SUPPORT-REGISTRATION.json');receipt=j(P/'SUPPORT-READ-RECEIPT.json');need(sh((P/'SUPPORT-REGISTRATION.json').read_bytes())==receipt['registration_sha256'],'support registration identity');n=0
 for x in sr['rows']:
  b=(P/'support'/(x['label']+'.rs')).read_bytes();ls=b.decode().splitlines();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(ls)==x['EOF'],'support object')
  vs=[v for v in receipt['views'] if v['label']==x['label']];need([v['range'] for v in vs]==x['registered_ranges'],'support windows')
  for v in vs:
   lo,hi=v['range'];b=safe(P,v['view']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i:5}  {ls[i-1]}' for i in range(lo,hi+1)],'support view');n+=1
 s2=j(P/'SUPPORT2-REGISTRATION.json');r2=j(P/'SUPPORT2-READ-RECEIPT.json');need(sh((P/'SUPPORT2-REGISTRATION.json').read_bytes())==r2['registration_sha256'],'support2 registration');x=s2['row'];ls=(P/'support/validation.rs').read_text().splitlines();need(x['sha256']==next(t['sha256'] for t in sr['rows'] if t['label']=='validation') and [v['range'] for v in r2['views']]==x['registered_ranges'],'support2 scope')
 for v in r2['views']:
  lo,hi=v['range'];b=safe(P,v['view']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i:5}  {ls[i-1]}' for i in range(lo,hi+1)],'support2 view');n+=1
 hist=j(P/'HISTORICAL-READ-RECEIPT.json');need(sh((P/'HISTORICAL-REGISTRATION.json').read_bytes())==hist['registration_sha256'],'history registration')
 for v in hist['views']:need(sh(safe(P,v['view']).read_bytes())==v['sha256'],'historical selected view')
 proofs=j(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==10,'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree chain length')
  for part,step in zip(parts,x['tree_chain']):
   need(cur==step['tree'] and part==step['entry'],'tree path');b=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',b)==cur,'tree object');mode,cur=tree(b)[part];need(mode==step['mode'] and cur==step['object'],'tree member')
  need(cur==x['blob'],'tree target')
  if x['role']=='source':need(oid(b'blob',safe(P,x['source_file']).read_bytes())==cur,'source blob')
  elif a.restricted:
   b=safe(a.restricted,x['source_file']).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==cur,'restricted blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository tree anchor')
 cats=j(P/'CATALOG-RESULT.json')['matches'];need([(x['index'],x['lens']) for x in cats]==expected and all(x['selected_equal'] and x['status'] is None for x in cats),'selected catalog metadata')
 checked=False
 if a.restricted:
  h=a.restricted/'historical';oldraw=(h/'previous-private-manifest.json').read_bytes();need(sh(oldraw)=='14ea6ae3856b91e862fee0c102beed45c14f4f6e7a23f560edf3a058de820036','prior private manifest');old=json.loads(oldraw)['files'];qs=[]
  for name in ('queue-original.json','queue-reconstructed.json'):
   b=(h/name).read_bytes();need(sh(b)==old['historical/'+name]['sha256'],'previous queue identity');qs.append(json.loads(b))
  b=(h/'queue-published.json').read_bytes();need(sh(b)==j(P/'CATALOG-RESULT.json')['published_queue_sha256'],'published queue identity');qs.append(json.loads(b));need((h/'queue-original.json').read_bytes()!=(h/'queue-reconstructed.json').read_bytes(),'whole queue distinction')
  for x in cats:
   es=[q['entries'][x['index']] for q in qs];need(es[0]==es[1]==es[2] and es[0]['contract_id']==x['id'] and es[0]['lens']==x['lens'],'queue selected equality')
  for i in (542,2491,3300,3446):
   es=[q['entries'][i] for q in qs];need(es[0]==es[1]==es[2] and j(h/f'q{i}-original.json')==es[0],'related history identity')
  for i in (2491,3300,3446):
   v=j(P/f'historical/selected-views/q{i}-selected.json');e=qs[0]['entries'][i];need(all(e.get(k)==v.get(k) for k in ('contract_id','kind','lens','canonical_owner','first_failed_contract_or_unresolved_question')),'related selected projection')
  v=j(P/'historical/selected-views/q542-core.json');e=qs[0]['entries'][542];need(all(e.get(k)==v.get(k) for k in v),'q542 projection')
  raw=(h/'registry-original.json.gz').read_bytes();need(sh(raw)=='a90f280f820e17643933b87aee4587c0ba47f8feec35bd9db61611653bc14063','stored registry');dec=gzip.decompress(raw);need(sh(dec)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f','decoded registry');role=json.loads(dec)['files'][960];need(role['source_id']=='pr-working:crates/adventuresim-core/src/organization.rs' and role['sha256']==reg['sources'][0]['sha256'] and j(h/'registry-matched-organization.json')==[{'index':960,'row':role}],'registry source role')
  need((h/'archived-original-object.rs').read_bytes()==bodies[0],'original archived object')
  ids=j(h/'HISTORICAL-FILE-IDENTITIES.json')
  for name,d in ids.items():
   if name.startswith('root-l'):
    need(sh((h/pathlib.PurePosixPath(name).name).read_bytes())==d['sha256'],'original receipt identity')
  oldrow=j(h/'READ-ROOT-L3-EXT-057-061.json')['rows'][0];currentrow=j(h/'READ-ROOT-L3-CURRENT-007.json')['rows'][0];l2=j(h/'READ-ROOT-L2-EXT-055-066.json')['rows'][0];need(oldrow['fresh_personal_ranges']==[[1,633]] and currentrow['fresh_personal_ranges']==[] and currentrow['qualified_reuse_ranges']==[[1,633]] and l2['fresh_personal_ranges']==[] and l2['qualified_inherited_same_lens_ranges']==[[1,498]],'historical attribution')
  old774=(h/'older-774-ledger.json').read_bytes();need(sh(old774)=='74f8fe4d07b187636dc8568ba5f129f02157d43d67b6d67c618c7259a808be48' and json.loads(old774)['findings'][79]['id']=='M56','older identity')
  c=(h/'baseline-committed.json').read_bytes();w=(h/'baseline-observed.json').read_bytes();need(c==w and sh(c)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041','at-capture baseline equality');need(len(json.loads(c)['newly_assessed_ledger']['entries'])==1101,'ledger count')
  roots={}
  for x in j(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(oid(b'commit',b)==x['revision'] and sh(b)==x['payload_sha256'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit object');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit root binding');checked=True
 print(json.dumps({'result':'pass','public_files':len(fs),'assigned_shared_display_chunks':len(rr['views']),'support_display_chunks':n,'git_tree_path_proofs':len(proofs),'restricted_history_checked':checked,'repository_binding_checked':bool(a.repository),'qualification':'Evidence identities and declared read scopes only; no product behavior, global alias, unique count or closure determined.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
