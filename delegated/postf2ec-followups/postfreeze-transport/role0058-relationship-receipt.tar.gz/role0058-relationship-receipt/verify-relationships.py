#!/usr/bin/env python3
# Verify selected historical relationships using the sealed restricted original.
import argparse,hashlib,json,pathlib
p=argparse.ArgumentParser();p.add_argument('--private',required=True,type=pathlib.Path);R=p.parse_args().private
h=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 o={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);o[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return o
assert h((R/'MANIFEST.json').read_bytes())=='95c798ccf51e961dd7508b15b7ef5d9253524da6512144dbfee830e8eca693b3'
c=(R/'committed/commit.stdout').read_bytes();rt=(R/'committed'/'root.stdout').read_bytes();assert oid('commit',c)=='f2ec8cbad7becbcc9a8e9da22ba512f52975768f' and c.splitlines()[0]==b'tree '+oid('tree',rt).encode()
a=(R/'HIST-014-ASSESSMENT.stdout').read_bytes();assert h(a)=='69df0143c35c003e807f4a7f9e23747f639f16c5dc7111eeb2364d1c60b69251';assert tree(rt)['ASSESSMENT-L05-SCHEDULE-AGGREGATE-95E.json']==('100644',oid('blob',a))
row=json.loads((R/'relations/ledger-89.json').read_bytes());assert row['record']=='ASSESSMENT-L05-SCHEDULE-AGGREGATE-95E.json' and row['historical_related_records']==['baseline-059/ledger.json#/segovb_continuation/lens13/discovery_receipts/207']
q=json.loads((R/'relations/q2494-original.json').read_bytes());assert q['contract_id']=='L2-SAVED-SCHEDULE-NATIVE-ADMISSION-QUESTION' and q['status']=='open-connected-owner-current-alias-qualification'
for i,l in [(2544,1),(2547,5),(2548,6)]:
 q=json.loads((R/f'relations/q{i}-original.json').read_bytes());assert q['lens']==l and q['status']=='pending-independent-lens-qualification'
print('f2ec commit-to-root-to-assessment blob and bounded ledger89/q2494/q2544/q2547/q2548 relationships: pass')
print('Run private verify-evidence.py first for the full packet inventory and both optional original 059 anchors. This check does not execute product code or establish alias/closure.')
