#!/usr/bin/env python3
# Source-evidence replay; never imports or runs product code.
import argparse,hashlib,json,pathlib,stat,subprocess,sys
if sys.flags.optimize:raise SystemExit('Optimized execution unsupported.')
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
def load(n):return json.loads((P/n).read_bytes())
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def safe(d,n):
 q=pathlib.PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts;return d.joinpath(*q.parts)
def tree(b):
 o={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);assert z+21<=len(b);n=b[a+1:z].decode();assert n not in o;o[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return o
def prove(root,path,data):
 for part in path.split('/'):
  t=(P/'trees'/(root+'.tree')).read_bytes();assert oid('tree',t)==root;mode,root=tree(t)[part]
 assert mode=='100644' and oid('blob',data)==root
def manifest():
 m=load('MANIFEST.json');fs={q.relative_to(P).as_posix() for q in P.rglob('*') if q.is_file() and q!=P/'MANIFEST.json'};ds={q.relative_to(P).as_posix() for q in P.rglob('*') if q.is_dir()};assert fs==set(m['files']) and ds==set(m['directories']) and not any(q.is_symlink() for q in P.rglob('*'))
 for n,x in m['files'].items():
  q=safe(P,n);b=q.read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256'] and stat.S_IMODE(q.stat().st_mode)==x['mode']
 for n,mode in m['directories'].items():assert stat.S_IMODE(safe(P,n).stat().st_mode)==mode
ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if a.skip_manifest:print('NOT CHECKED: public manifest (--skip-manifest).')
else:manifest();print('public exact inventory, modes and hashes: pass')
source=(P/'source/95e.rs').read_bytes();assert H(source)=='45b87fa13f86c8805f2b4f974fd1f629f5da068a07b3b7c4af17115aaa339846' and len(source.splitlines())==986
primary=load('SOURCE-005-CAPTURE-RESULT.json');assert len(primary)==3
for x in primary:assert x['sha256']==H(source) and x['EOF']==986;prove(x['root'],x['path'],source)
root='1eec97de340d9b7debbb30ca0c0fb2240a73b93f';rows={primary[-1]['path']:{'file':'source/95e.rs'}}
for name in ['SUPPORT-010','SUPPORT-015']:
 for x in load(name+'-CAPTURE-RESULT.json'):
  assert x['root']==root;b=safe(P,x['file']).read_bytes();assert H(b)==x['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['EOF'];prove(root,x['path'],b);rows[x['path']]=x
print('primary source blob-to-declared-tree proofs and pinned support: pass')
print('NOT CHECKED from public data alone: commit-to-root links or original private queue membership.')
reg=load('SOURCE-006-DISPLAY-REG.json');assert reg['queues']==[3483,3484,3486,3487] and reg['lenses']==[1,2,5,6] and reg['EOF']==986 and reg['planned_ranges']==[[1,100],[101,200],[201,300],[301,400],[401,500],[501,600],[601,700],[701,722]]
ls=source.decode().splitlines(keepends=True);views=load('SOURCE-006-DISPLAY-RESULT.json');assert [x['range'] for x in views]==reg['planned_ranges']
for x in views:
 lo,hi=x['range'];b=safe(P,x['file']).read_bytes();assert H(b)==x['sha256'] and b.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
for name in ['SUPPORT-011','SUPPORT-016','SUPPORT-018']:
 reg=load(name+'-DISPLAY-REG.json');out=load(name+'-DISPLAY-RESULT.json');assert [(x['path'],x['range']) for x in out]==[(v['path'],r) for v in reg['views'] for r in v['ranges']]
 for x in out:
  ls=safe(P,rows[x['path']]['file']).read_text().splitlines(keepends=True);lo,hi=x['range'];actual=safe(P,x['file']).read_bytes();assert H(actual)==x['sha256'] and actual.decode()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
 assert (P/(name+'-READ.json')).is_file()
for skill in load('SKILLS-003-CAPTURE.json'):
 b=(P/'skills'/('lens-'+str(skill['lens'])+'.md')).read_bytes();assert H(b)==skill['sha256'] and len(b.splitlines())==skill['lines']
print('four focused skills, preregistered 1–722 primary and support windows: pass; display is attested')
cross=load('RECONSTRUCTION-CROSSWALK.json')
for x in cross['files']:
 b=safe(P,x['public_file']).read_bytes();assert H(b)==x['public_whole_sha256'] and len(b)==x['public_bytes']
 if a.private:
  original=safe(a.private,x['restricted_file']).read_bytes();assert H(original)==x['restricted_whole_sha256'] and len(original)==x['restricted_bytes'];out=bytearray();pos=0
  for v in x['spans']:
   off=v['offset'];assert off>=pos and off+v['length']<=len(original);out+=original[pos:off];out+=v['replacement'].encode();pos=off+v['length']
  out+=original[pos:];assert bytes(out)==b
if a.private:
 assert H((a.private/'MANIFEST.json').read_bytes())==cross['restricted_manifest_sha256']=='bef7b67510e709f3a78d25f037e2892253fd9d1c44909eb8845f0bb5ab1d4d74'
 cmd=[sys.executable,'-B',str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 assert subprocess.run(cmd,check=False).returncode==0
 h=load('PUBLIC-HISTORY.json');rec=json.loads((a.private/'committed'/'reconciliation.stdout').read_bytes())['entries'];assert h['queues']=={'3483':1,'3484':2,'3486':5,'3487':6} and h['reviewer_personal_ranges']==[[1,722]]
 for k,l in h['queues'].items():assert rec[int(k)]['historical_lens']==l and rec[int(k)]['current_reconciliation']=='unassessed'
 for path,key in [(('historical','READ-ROOT-L3-EXT-057-061.json'),'l3_prior_receipt_sha256'),(('historical','READ-ROOT-L3-CURRENT-007.json'),'l3_current_receipt_sha256'),(('historical','root-l2','READ-ROOT-L2-CURRENT-013.json'),'l2_current_receipt_sha256')]:assert H(a.private.joinpath(*path).read_bytes())==h[key]
 print('public crosswalk and bounded projected history against separately held originals: pass')
else:print('NOT CHECKED: original crosswalk and projected history (supply --private).')
print('No product behavior, unique count, checkpoint3821 recovery or global audit closure is established.')
