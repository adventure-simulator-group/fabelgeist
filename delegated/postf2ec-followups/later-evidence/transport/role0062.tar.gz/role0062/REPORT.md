# Role 0062: catalog source ownership and propagation

This is a source-only, bounded independent read by `verifier_scope` under
historical lenses 1 (producer propagation), 2 (type ownership), 5 (aggregate
states), and 6 (existing type owners). It proposes a conditional source-map
question; it does not close an obligation, decide an alias, establish an
independent finding count, execute product code, or establish product behavior.
The coordinator owns reconciliation and the connected repair ledger.

## Scope and chronology

Original 059 entries `/entries/3507`, `/entries/3508`, `/entries/3510`, and
`/entries/3511` specify `crates/adventuresim-core/build.rs` at
`6533e444fa37552927070cc8d8190907fd3b413e`, SHA-256
`fc42ea1f2234144e94d6bfac86f254cd059799b9f9e5ae6de7f77e3125f19b7c`,
509 lines, required lines 1–136. Their recorded assessed ranges are empty,
body credit is zero, and the original rows have no `status` field or current
revision revisit requirement field. In the separate published f2ec
reconciliation those entries have `historical_status: null` and current
status `unassessed`; neither value should be inserted into the original.

After prospective registration, this reviewer displayed historical 1–136 and
pinned authoritative `95e63628f9d70b8dd6e6fede64334696c6995009` lines 1–138
as a shared body, applying the four lenses separately. Current helper lines
300–388 and specified supporting source windows were separately registered.
The pinned 95e file equals the e275 file byte-for-byte, SHA-256
`58cfca52333fe7faa7e685d953532cf8aa58b171efc63443ee929b1a32f94dc6`,
511 lines. It differs from the 6533 file by the two-line `unit_interval`
module declaration. This comparison concerns this one file; it does not prove
other files or trees equal, a fresh personal e275 read, or credit for unread
complements.

Separate original 059 current-builder obligations `/entries/3699`,
`/entries/3700`, `/entries/3702`, and `/entries/3703` require e275 lines
1–138 **and** 389–511 under the respective lenses; f2ec still marks them
unassessed. This packet covers their first current range only, with a separate
helper selection. A peer's separately assigned 0061 review of the latter
range does not automatically combine reader or lens credit. Do not infer that
the historical 0062 rows contained this later requirement.

The original full 059 and reconstructed full queue streams have different
whole-file identities; the selected parsed rows are equal. A recovered Root
Segovb Lens 1 receipt records a separate personal, untruncated e275 full-file
read; the distinct Root Lens 3 receipt records e275 ranges 1–138 and 389–511.
The historical 6533 Lens 3 registration is preserved, but this packet did not
find a separate corresponding historical read receipt. These records retain
their original lens, reviewer, revision and scope; they grant no other-lens
credit or automatic f2ec closure.

## Source observations and conditional relationship

`build.rs:74–137` sorts the immediate quest files, reads their raw text,
updates a digest from each normalized relative path and text, parses strict
JSON, collects dialogue-variant source positions before adding each document,
validates the parallel documents and source paths, and writes the generated
catalog values. The validator checks the parallel lengths; a broken aggregate
is not inferred merely from those vectors. The source read neither generates
nor validates a product catalog.

At `build.rs:348–385`, the helper serializes each parsed template string and
searches the raw source from a cursor for the next identical serialized token;
it then labels the found location with the variant template's structural
path. On paper, if an earlier token has exactly that serialized form, the
recorded line and column can refer to it instead. For example, a first
variant whose earlier ID token and later template token are both `hello`
could meet the displayed individual ID and nonempty-template shape checks
(`quest_catalog_validation.rs:186–211,258–268,1183–1196`). Whether a complete
catalog with that arrangement passes every relevant constraint and is
supported is unverified. The checked-in investigation content was inspected
for context and is not evidence of such a duplicate. A lexically different but
semantically equivalent escaped string is a separate unproved locator question.

If such a catalog is admitted and that source reference is selected, the
registered trace passes through `quest_catalog.rs:343–375,700–728`, the
conditional LocalProblem referral path in `dialogue_provenance.rs:59–123`,
`dialogue_sessions.rs:287–333`, web source projection at
`routes/dialogue.rs:357–368,1375–1416`, and edit URL formation at
`adventuresim-dialogue/src/lib.rs:455–462,940–973`. A wrong edit line further
requires a duplicate on another line, the relevant branch and variant to be
selected, an authorized session and projection. No actual catalog acceptance,
build, referral, displayed edit link or native outcome was demonstrated.

This supports a bounded aggregate question about the relationship between
structural path, value and raw coordinates, and a producer-propagation
question about where that relationship is established and retained. Existing
`SourceRef` use is relevant to type ownership and reuse, but does not by itself
establish that every string is a misplaced type or resolve the correct owner.
The digest includes sorted raw content and paths; generator/schema code is not
explicitly included at the displayed site. Whether content-only revision is
intended, or has a consequence for a consumer, remains a policy question; no
hash collision is asserted.

## Related records and open work

Original q690 (`Q-L1-55012137ee5a868cf978`) already raises source-map
locator, authoring and validator questions and identifies the separate prior
Lens 1 receipt. Original q2434 and q2439 raise diagnostic-path and runtime
source-identity owner questions under Lens 12; q2391 is another diagnostic
path protocol record. Their relationships, first operations and exact aliases
remain to be reconciled, without transferring authorship or credit.

At immutable f2ec, ledger row 759 concerns malformed event source-reference
JSON losing its cause. Row 773 concerns the PublicThreat branch's receipt
string at a structured source-reference boundary. The present conditional
trace is the LocalProblem branch and a possible coordinate/path mismatch, so
it is a related question with a different first operation, not an automatic
alias or a new unique count. No comprehensive alias-absence search is claimed.

Resolve complete admitted-catalog constraints and authoring policy, the raw
locator's structural identity and escape policy, source/path ownership and
consumer expectations, plus the separate uninspected current-builder range.
Any later runtime or acceptance work requires a later authorized stage; none
was performed here.

## Recovery and verification limits

The portable verifier checks inventoried file bytes/modes, Git commit/tree/blob
bindings for original and reconstructed queue streams, pinned source and f2ec
snapshots, selected parsed entries and prior receipt identities, the specific
one-file delta, and captured line windows. It does not prove semantic findings,
source-display attention, product behavior, privacy outside its bounded scan,
or independent custody. The strongest replay needs the separately held
restricted collection containing path-bearing originals and Git objects. It
is presently same-machine custody, not independent public recoverability; no
individual removed local-path digest is published. The protected extraction
was not overwritten.

An initial status lookup raised `KeyError` after the row projections were
captured; the source row has no such field. A planned 275–355 connected
window exceeded EOF 351 and raised `IndexError` before display; the registered
275–351 successor was displayed. Both tracebacks were tool-visible but not
separately captured byte-for-byte. A broad historical ID display was truncated
and a q690 selection was printed as a slice; the full machine-readable search
and selection remain restricted, and exact selected records were subsequently
inspected. Some support windows contain adjacent test source text; no test was
run. Preserve normalized recovered 774 separately from missing pre-export
originals, the SOURCE004 qualification, the 73 nontext/no-positive-EOF
qualification, and the absence of checkpoint 3821. Older records are not
promoted into 3821.
