#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None: print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='9c86f563b3fb40de9cbbef6da8900caa5ccae8318c7f0ce94cd0f536cb6f8472';verify_manifest(root,'MANIFEST-PRIVATE.json')
 source=proof(root,'SOURCE-GIT-PROOF.json','git-objects',True);checkpoint=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);history=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert len(source)==12 and len(checkpoint)==2 and len(history)==3
 revs=['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','95e63628f9d70b8dd6e6fede64334696c6995009'];path='crates/adventuresim-core/build.rs'
 a,b,c=(source[(r,path)] for r in revs);assert sha(a)=='fc42ea1f2234144e94d6bfac86f254cd059799b9f9e5ae6de7f77e3125f19b7c' and sha(b)=='58cfca52333fe7faa7e685d953532cf8aa58b171efc63443ee929b1a32f94dc6';assert a!=b and b==c and len(a.decode().splitlines())==509 and len(b.decode().splitlines())==511
 import difflib
 delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),c.decode().splitlines(keepends=True),fromfile='historical-6533',tofile='authoritative-95e')).encode();assert delta==(root/'SOURCE-DELTA.diff').read_bytes()
 old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';rec='dac7d0055716053f245139971eb67ddfd87fa462';hpath='baseline-059/queue.json';assert sha(history[(old,hpath)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert sha(history[(rec,hpath)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 assigned=[3507,3508,3510,3511];related=[216,686,687,688,689,690,691,2391,2433,2434,2439,3699,3700,3702,3703];indices=assigned+related;oldsel=exact_selections(history[(old,hpath)],indices);newsel=exact_selections(history[(rec,hpath)],indices)
 for i in indices:assert oldsel[i][0]==newsel[i][0]
 for i,lens in [(3507,1),(3508,2),(3510,5),(3511,6)]:
  q=oldsel[i][0];s=q['exact_source_identities_and_assessed_ranges'][0];assert q['lens']==lens and q['body_or_population_credit']==0 and 'status' not in q and 'exact_current_revision_revisit_requirements' not in q and s['revision']==revs[0] and s['required_ranges']==[[1,136]] and s['assessed_ranges']==[] and s['actual_EOF']==509
  for label in ['original','reconstructed']:assert json.loads((root/f'{label}-q{i}-projection.json').read_bytes())==q
 selected={x['index']:x for x in json.loads((root/'related-selected.json').read_bytes())}
 for i in related:assert selected[i]['original']==oldsel[i][0] and selected[i]['reconstructed']==newsel[i][0]
 for i,lens in [(3699,1),(3700,2),(3702,5),(3703,6)]:
  q=oldsel[i][0];s=q['exact_source_identities_and_assessed_ranges'][0];assert q['lens']==lens and s['revision']==revs[1] and s['required_ranges']==[[1,138],[389,511]] and s['assessed_ranges']==[]
 f2ec='f2ec8cbad7becbcc9a8e9da22ba512f52975768f';base=checkpoint[(f2ec,'BASELINE-95E-20261110.json')];rq=checkpoint[(f2ec,'RECONCILIATION-059.json')];assert sha(base)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041';assert sha(rq)=='73bc3864944276b88944163257e3cfc67dde6141b2dc3f82588af66621003945';q=json.loads(rq)['entries'];assert len(q)==3713
 for i in assigned+[3699,3700,3702,3703]:assert q[i]['current_reconciliation']=='unassessed' and q[i]['historical_status'] is None and q[i]['contract_id']==oldsel[i][0]['contract_id']
 rows=json.loads(base)['newly_assessed_ledger']['entries'];assert len(rows)==1101
 selectedrows={x['index']:x['row'] for x in json.loads((root/'f2ec-ledger-selected.json').read_bytes())}
 for i,id in [(759,'SEGOVB-L12-DIALOGUE-EVENT-SOURCE-REFS-JSON-CAUSE-ERASURE'),(773,'REVIEW-DIALOGUE-REFERRAL-SOURCE-SHAPE-95E')]:assert rows[i]['id']==id and rows[i]==selectedrows[i]
 for n,h in [('current-l1-read.json','59a549a8805d1a703f95560b7c143812a61ccb400123c7f45fc7102d96c80e70'),('current-l3-read.json','104e2e5faad0592a8de2ccb739ef3b29a7a644928e0d93d22063a601da7ae10d'),('historical-l3-registration.json','cf9c1e2a887297facab1d74b9a7b576925d675a8b2e92b8f997699d7073725d8'),('current-l3-registration.json','ce2d43189713d28dc3e0c7a4fa87b409b2a81da310fc23e77e8571be2ce47e16')]:assert sha((root/n).read_bytes())==h
 l1=json.loads((root/'current-l1-read.json').read_bytes())['rows'][3];l3=json.loads((root/'current-l3-read.json').read_bytes())['rows'][0];assert l1['assessed_ranges']==[[1,511]] and l1['body_output_truncated'] is False and l3['fresh_personal_ranges']==[[1,138],[389,511]] and l3['body_output_truncated'] is False
 windows=[('source-6533.raw','display-6533-1-136.txt',1,136),('source-95e.raw','display-95e-1-138.txt',1,138),('source-95e.raw','context-source-map-300-388.txt',300,388)]
 for label,ranges in [('item-validate',[(120,145)]),('quest-validate',[(410,485),(1,55),(1170,1260),(170,240),(250,275)]),('quest-catalog',[(320,385),(830,880),(1,95),(380,415),(700,735)]),('quest-gen',[(1,40)]),('provenance',[(90,150),(1,90)]),('dialogue',[(440,470),(940,985)]),('web-dialogue',[(345,380),(1430,1455),(1370,1415),(1414,1430)]),('authored-quest',[(13,20)]),('dialogue-sessions',[(275,351)])]:
  for lo,hi in ranges:windows.append((label+'.raw',f'{label}-{lo}-{hi}.txt',lo,hi))
 assert len(windows)==25
 for x in windows:window(root,*x)
 print('restricted manifest, 12 Git-bound source selections, f2ec, exact original/reconstructed queue projections, prior receipts, one-file delta and 25 captured windows: PASS')
 print('Scope: evidence bytes and registered displays only; no product execution, semantic closure, runtime validation, independent custody or checkpoint 3821 claim.')
if __name__=='__main__':main()
