#!/usr/bin/env python3
"""Read-only evidence replay; no product code, build script, parser or macro execution."""
import argparse,gzip,hashlib,json,pathlib,subprocess,sys,tarfile
P=pathlib.Path(__file__).resolve().parent
def j(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(x,m):
 if not x:raise ValueError(m)
def safe(root,name):
 p=pathlib.PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return root.joinpath(*p.parts)
def tree(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'tree bounds');k=b[a+1:z].decode();need(k not in d,'duplicate tree entry');d[k]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);ap.add_argument('--repository');a=ap.parse_args();m=j(P/'MANIFEST.json');files={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(files==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest set')
 for n,v in m['files'].items():
  f=safe(P,n);b=f.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode'],'file '+n)
 for x in j(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(x['name']+'.md')).read_bytes();need(sh(b)==x['sha256'] and len(b.splitlines())==x['lines'],'skill')
 need(sh((P/'rules/crates-AGENTS.md').read_bytes())==j(P/'RULES-REUSE.json')['sha256'],'working guide identity')
 reg=j(P/'SOURCE-REGISTRATION.json');rr=j(P/'SOURCE-READ-RECEIPT.json');expected=[(3495,1),(3496,2),(3498,5),(3499,6)];need([(x['queue'],x['lens']) for x in reg['lenses']]==expected and [(x['queue'],x['lens']) for x in j(P/'ASSESSMENTS.json')['assessments']]==expected,'lenses');need(rr['sources']==reg['sources'],'source receipt');bodies={}
 for x in reg['sources']:
  b=(P/'sources'/(x['label']+'.rs')).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(b.decode().splitlines())==x['EOF'],'source object');bodies[x['label']]=b
 need(bodies['historical-e275']==bodies['current-95e'] and bodies['historical-6533']!=bodies['current-95e'],'revision distinction');old=bodies['historical-6533'].decode().splitlines();cur=bodies['current-95e'].decode().splitlines();need(old[386:509]==cur[388:511] and j(P/'DELTA-METADATA-RESULT.json')['same_named_function_equal'],'equal function slice');seen={'old':set(),'current':set()}
 for v in rr['views']:
  lo,hi=v['range'];ls=old if v['group']=='old' else cur;b=safe(P,v['file']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i}: {ls[i-1]}' for i in range(lo,hi+1)] and v['registration_mtime_ns']<=v['view_created_mtime_ns'],'source view');need(not seen[v['group']].intersection(range(lo,hi+1)),'source overlap');seen[v['group']].update(range(lo,hi+1))
 need(len(rr['views'])==4 and seen['old']==set(range(387,510)) and seen['current']==set(range(387,512)),'assigned ranges');chunks=0
 for suffix in ('','2'):
  fn='SUPPORT'+suffix+'-REGISTRATION.json';d=j(P/fn);q=j(P/('SUPPORT'+suffix+'-READ-RECEIPT.json'));need(sh((P/fn).read_bytes())==q['registration_sha256'],'support registration')
  for x in d['rows']:
   ext='lock' if x['label']=='workspace-lock' else ('yaml' if 'content' in x['label'] else 'rs');b=(P/'support'/(x['label']+'.'+ext)).read_bytes();ls=b.decode().splitlines();need(sh(b)==x['sha256'] and oid(b'blob',b)==x['git_blob'] and len(ls)==x['EOF'],'support object');vs=[v for v in q['views'] if v['label']==x['label']];need([v['range'] for v in vs]==x['registered_ranges'],'support ranges')
   for v in vs:
    lo,hi=v['range'];b=safe(P,v['view']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i:5}  {ls[i-1]}' for i in range(lo,hi+1)] and v['registration_mtime_ns']<=v['view_created_mtime_ns'],'support display');chunks+=1
 need(chunks==15,'support chunks');nativechunks=0
 for prefix in ('NATIVE','NATIVE2','JSON-NATIVE'):
  fn=prefix+'-REGISTRATION.json';d=j(P/fn);q=j(P/(prefix+'-READ-RECEIPT.json'));need(sh((P/fn).read_bytes())==q['registration_sha256'],'native registration');archive=None
  if a.restricted:
   archive=a.restricted/'native'/(d['package']+'-'+d['version']+'.crate');need(sh(archive.read_bytes())==d['archive_sha256'],'native archive checksum')
  for x in d['rows']:
   b=(P/'native'/(x['label']+'.rs')).read_bytes();ls=b.decode().splitlines();need(sh(b)==x['sha256'] and len(ls)==x['EOF'],'native source identity')
   if archive:
    with tarfile.open(archive,'r:gz') as t:need(t.extractfile(x['package_member']).read()==b,'native archive member')
   vs=[v for v in q['views'] if v['label']==x['label']];need([v['range'] for v in vs]==x['registered_ranges'],'native ranges')
   for v in vs:
    lo,hi=v['range'];b=safe(P,v['view']).read_bytes();need(sh(b)==v['sha256'] and b.decode().splitlines()==[f'{i:5}  {ls[i-1]}' for i in range(lo,hi+1)] and v['registration_mtime_ns']<=v['view_created_mtime_ns'],'native display');nativechunks+=1
 need(nativechunks==12,'native chunks')
 for v in j(P/'HISTORICAL-READ-RECEIPT.json')['views']:need(sh(safe(P,v['view']).read_bytes())==v['sha256'],'historical view')
 d=P/'historical/prior-0057-selected';b=(d/'MANIFEST.json').read_bytes();need(sh(b)=='0ea197ca6305f78b494ba8767d98b48263c8ea5e8836e2e42e498526011846fc','prior manifest');old=json.loads(b)['files']
 for n in ('REPORT.md','SUPPORT-REGISTRATION.json','SUPPORT-READ-RECEIPT.json'):need(sh((d/n).read_bytes())==old[n]['sha256'],'prior selected file')
 proofs=j(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==12,'tree proof count')
 for x in proofs:
  curtree=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree chain length')
  for part,step in zip(parts,x['tree_chain']):
   need(curtree==step['tree'] and part==step['entry'],'tree step');b=(P/'trees'/(curtree+'.bin')).read_bytes();need(oid(b'tree',b)==curtree,'tree object');mode,curtree=tree(b)[part];need(mode==step['mode'] and curtree==step['object'],'tree member')
  need(curtree==x['blob'],'tree target')
  if x['role']=='source':need(oid(b'blob',safe(P,x['source_file']).read_bytes())==curtree,'source blob')
  elif a.restricted:
   b=safe(a.restricted,x['source_file']).read_bytes();need(sh(b)==x['sha256'] and oid(b'blob',b)==curtree,'restricted blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository binding')
 cats=j(P/'CATALOG-RESULT.json')['matches'];need([(x['index'],x['lens']) for x in cats]==expected and all(not x['status_present'] for x in cats),'catalog selection');checked=False
 if a.restricted:
  h=a.restricted/'historical';raw=(h/'previous-private-manifest.json').read_bytes();need(sh(raw)=='815dd963d446df9d98647a31a527ff74dc8bb74b8e65406d17402659bf25f00d','previous manifest');prior=json.loads(raw)['files'];qs=[]
  for n in ('queue-original.json','queue-reconstructed.json'):
   b=(h/n).read_bytes();need(sh(b)==prior['historical/'+n]['sha256'],'queue anchor');qs.append(json.loads(b))
  b=(h/'queue-published.json').read_bytes();need(sh(b)==j(P/'CATALOG-RESULT.json')['published_queue_sha256'],'published queue');qs.append(json.loads(b));need((h/'queue-original.json').read_bytes()!=(h/'queue-reconstructed.json').read_bytes(),'queue stream distinction')
  for x in cats:
   es=[q['entries'][x['index']] for q in qs];need(es[0]==es[1]==es[2] and es[0]['lens']==x['lens'] and es[0]['contract_id']==x['id'],'queue selection')
  for i in (2493,3300,3446,3699,3700,3702,3703):
   es=[q['entries'][i] for q in qs];need(es[0]==es[1]==es[2] and j(h/f'q{i}-original.json')==es[0],'related record');v=j(P/f'historical/selected-views/q{i}-core.json');need(all(es[0].get(k)==v[k] for k in v),'record projection')
  raw=(h/'registry-original.json.gz').read_bytes();need(sh(raw)=='a90f280f820e17643933b87aee4587c0ba47f8feec35bd9db61611653bc14063','stored registry');dec=gzip.decompress(raw);need(sh(dec)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f','decoded registry');role=json.loads(dec)['files'][850];need(role['source_id']=='pr-working:crates/adventuresim-core/build.rs' and role['sha256']==reg['sources'][0]['sha256'] and j(h/'registry-matches.json')==[{'index':850,'row':role}],'registry role')
  need((h/'archived-old.rs').read_bytes()==bodies['historical-6533'] and (h/'archived-e275.rs').read_bytes()==bodies['historical-e275'],'original archived objects')
  for n,v in j(h/'HISTORICAL-FILE-IDENTITIES.json').items():need(sh((h/n).read_bytes())==v['sha256'],'historical receipt identity')
  o=j(h/'READ-ROOT-L3-EXT-057-061.json')['rows'][4];c=j(h/'READ-ROOT-L3-CURRENT-008.json')['rows'][0];need(o['fresh_personal_ranges']==[[387,509]] and c['fresh_personal_ranges']==[[1,138],[389,511]] and c['qualified_reuse_ranges']==[],'historical attribution')
  committed=(h/'baseline-committed.json').read_bytes();work=(h/'baseline-observed.json').read_bytes();need(committed==work and sh(committed)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041' and len(json.loads(committed)['newly_assessed_ledger']['entries'])==1101,'baseline capture')
  roots={}
  for x in j(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(oid(b'commit',b)==x['revision'] and sh(b)==x['payload_sha256'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit-tree binding');checked=True
 print(json.dumps({'result':'pass','public_files':len(files),'assigned_display_chunks':len(rr['views']),'support_chunks':chunks,'native_chunks':nativechunks,'native_archive_binding_checked':bool(a.restricted),'git_tree_path_proofs':len(proofs),'restricted_history_checked':checked,'repository_binding_checked':bool(a.repository),'qualification':'Evidence integrity and declared read scopes only; exact native archive binding needs restricted inputs; no product behavior, alias, count, feature resolution or closure inferred.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
