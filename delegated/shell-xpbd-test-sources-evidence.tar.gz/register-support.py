from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda d:hashlib.sha256(d).hexdigest()
plans=[('crates/fabelgeist-shell/src/surface_contact/solve.rs','support/solve.rs',[[1,34],[238,309]]),('crates/fabelgeist-xpbd/src/constraint.rs','support/constraint.rs',[[50,115],[119,222],[229,292]]),('crates/fabelgeist-xpbd/src/incidence.rs','support/incidence.rs',[[1,107]]),('crates/fabelgeist-shell/src/native_vector_fixture.rs','support/native-vector.rs',[[1,21]]),('crates/fabelgeist-xpbd/tests/fixtures/constraint-native.json','support/constraint-native.json',[[1,47]]),('crates/fabelgeist-shell/tests/fixtures/contact_masses.json','support/contact-masses.json',[[1,60],[4330,4396]])]
rows=[]
for path,dest,ranges in plans:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in ranges)
 chunks=[[start,min(start+59,z)] for a,z in ranges for start in range(a,z+1,60)];(b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(raw);rows.append({'kind':'connected current support; test and fixture text only','revision':rev,'path':path,'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path]).decode().strip(),'sha256':sha(raw),'bytes':len(raw),'eof':eof,'archive':dest,'registered_ranges':ranges,'planned_chunks':chunks})
r={'schema':'726-shell-xpbd-test-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'Prospective bounded current support only, including fixture text; no ordered role, other reviewer credit, fixture invocation or product execution.'};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((b/'support-registration.json').read_bytes()));print(json.dumps(rows,indent=2))
