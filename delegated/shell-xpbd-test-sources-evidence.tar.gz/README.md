# Bounded shell and XPBD test-source evidence

This packet records `/root/rig_identity`'s independent source-only review of
original registry roles 2661 (`fabelgeist-shell/src/surface_contact/solve/tests.rs`)
and 2662 (`fabelgeist-xpbd/src/constraint/tests.rs`). It supplies thirteen
bounded perspectives; it does not establish whole-lens completion, a passing
test, product validation, or unique ledger counts.

The recorded `pr-working` snapshot has head
`6533e444fa37552927070cc8d8190907fd3b413e` and four unrelated status entries.
Each test object individually equals its file at that head and pinned current
revision `95e63628f9d70b8dd6e6fede64334696c6995009`. Revision
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports recovered evidence; it
is not the project revision. Raw Git commit, tree and blob membership proofs
are in `git-proofs.json` and `git-objects/`.

Both historical and current test bodies were displayed in full after
registration: lines 1–45 and 1–111 respectively. Current solve, constraint,
incidence, test-helper and fixture text were registered separately as support.
The large contact fixture was personally displayed only at 1–60, 1711–1832 and
4330–4396; lines 61–1710 and 1833–4329 are unread by this reviewer. The small
constraint fixture was displayed at 1–47 as support. The full source files are
archived for recoverability, but archived bytes and the historical/current Git
matches confer neither full current body-read credit nor historical personal
read credit. `personal-read-receipt.json` records actual chunks and unread
complements.

The original 774 rig reviewer separately read the full historical test files
and both fixture files. The 059 Lens11 receipts preserve their full windows and
partial receipt links without naming an individual. `/root/lens12_frontier`
read the test bodies in 920; its note that the large fixture had not yet been
read applies at that point. Subsequent 921 and 922 receipts record separate
full historical fixture reads, with no root rereads. These fixture roles are
context in this packet, not newly credited ordered roles.

One displayed authored case has four maximum finite inverse-mass words,
`resolved: 1`, and corrected position words identical to predicted words. It is
connected context for the earlier finite-response overflow question; this
packet does not establish the cause or a product result. The constraint fixture
also contains `u32::MAX` as a native particle word, but the displayed test
records a lambda clear rather than a constraint solve with that index. Existing
membership, attachment-shape and four distinct diagnostic questions retain
their own attribution. Exact historic expected words and prose are not a
compatibility mandate.

`registry-selection-reconstructed.json` and
`queue-selection-reconstructed.json` are selected reconstructed records, not
original standalone files. The 059 records in `historical-059/` are exact bytes
checked against the recovered transport manifest. Historical 774 records and
earlier assessments are hash-linked in `evidence-links.json`.
`published-prior-packet-links.json` verifies only listed selected archive
members, not every member. Published bundles and exact earlier packets are
dependencies of full verification.

The separate P16 dirty snapshot is based on
`a120390947c89b703dc74c4255a13c035d054c50`; that base is not the dirty
snapshot's commit. Its later recovered tracked patch matches the recorded hash,
with seven untracked files separate; matching bytes do not establish the
original diff invocation or uninterrupted custody. This packet does not
recover or promote the checkpoint 3821 ledger or queue.

Run `python3 verify-evidence.py` for evidence integrity, provenance, source
ranges and a structural comparison of the displayed fixture case. Run
`python3 verify-manifest.py` to check frozen packet files. These are
evidence-only checks. No test, fixture invocation, product, GPU, shader,
simulation, build or runtime probe was executed.
