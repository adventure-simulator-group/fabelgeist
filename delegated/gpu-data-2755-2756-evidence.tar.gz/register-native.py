import datetime,hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;pub=pathlib.Path('<LOCAL_PATH_0>');sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();d=p/'native';d.mkdir(exist_ok=True)
packages={'wgpu-29.0.4':'76e8840e1ba2881d4cbb18d2147627a56af426ff064c0401eb0c8410c6325d07','wgpu-types-29.0.4':'84bf84cd9ca8ca45e2b223a3868f1adf9bfc0c66aeac212e76ee7e40fdadf8f5'};packs=[]
for name,expected in packages.items():
 src=pub/'native-evidence'/name;raw=(src/(name+'.crate')).read_bytes();assert sha(raw)==expected;(d/(name+'.crate')).write_bytes(raw);(d/(name+'-MANIFEST.json')).write_bytes((src/'MANIFEST.json').read_bytes());packs.append({'package':name,'archive':'native/'+name+'.crate','archive_sha256':sha(raw),'bytes':len(raw),'prior_manifest':'native/'+name+'-MANIFEST.json','prior_manifest_sha256':sha((d/(name+'-MANIFEST.json')).read_bytes())})
specs=[('wgpu-29.0.4','src/api/buffer.rs',[[200,220]]),('wgpu-29.0.4','src/lib.rs',[[125,140]]),('wgpu-types-29.0.4','src/buffer.rs',[[1,80]]),('wgpu-types-29.0.4','src/lib.rs',[[430,455]])];out=[]
for name,path,ranges in specs:
 member=name+'/'+path
 with tarfile.open(d/(name+'.crate'),'r:gz') as t:b=t.extractfile(member).read()
 fn='native/'+name+'-'+path.replace('/','_');(p/fn).write_bytes(b);out.append({'package':name,'package_member':member,'archive':fn,'sha256':sha(b),'git_blob_for_content':blob(b),'bytes':len(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packages':packs,'entries':out,'qualification':'Package archives bound to current Cargo.lock checksum, source text only. Current feature selection/unification, native validation and execution not inferred.'};(p/'native-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('registration sha256',sha((p/'native-registration.json').read_bytes()));print([(e['package_member'],e['EOF'],e['registered_ranges']) for e in out])
