import datetime,gzip,hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);assert [registry['files'][i]['snapshot'] for i in [2755,2756]]==['pr-working','pr-working'];assert [registry['files'][i]['material_ranges'] for i in [2755,2756]]==[[[1,28]],[[7,13]]];trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue);sel=load('queue-selection-reconstructed.json');assert all(q['entries'][int(k)]==v for k,v in sel['entries'].items());sel=load('registry-selection-reconstructed.json');assert all(registry['files'][int(k)]==v for k,v in sel['roles'].items());assert sel['snapshot']==[x for x in registry['snapshots'] if x['id']=='pr-working']
for n in ['reference-index.json','rules.json','skills.json']:
 for e in load(n)['records']:
  b=(p/e['file']).read_bytes();assert sha(b)==e['sha256'],e['file']
groups=[('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('native','native-registration.json','native-read-receipt.json'),('native2','native2-registration.json','native2-read-receipt.json'),('native3','native3-registration.json','native3-read-receipt.json'),('native4','native4-registration.json','native4-read-receipt.json'),('bridge','bridge-registration.json','bridge-read-receipt.json')]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'];assert blob(body)==a.get('git_blob',a.get('git_blob_for_content'));assert len(body.splitlines())==a['EOF'] and a['archive']==b['archive'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[name]=len(r['entries'])
r=load('registration.json')
for e in r['entries']:
 row=registry['files'][e['original_index']];assert (e['source_id'],e['snapshot'],e['sha256'],e['EOF'],e['original_material_ranges'])==(row['source_id'],row['snapshot'],row['sha256'],row['actual_line_count'],row['material_ranges'])
assert all(v['equals_archived'] for c in r['comparisons'] for v in c['versions'].values())
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
hist=p/'history-059/segovb';receipt=json.loads((hist/'READ-L11-451.json').read_bytes());state=json.loads((hist/'STATE-L11-451.json').read_bytes());verification=json.loads((hist/'VERIFY-L11-451.json').read_bytes());assert receipt['current_reconciled'] is False and receipt['accepted_unique_count_change']==0 and state['accepted_unique_count_change']==0 and verification['gate'] is False;assert state['receipt_sha256']==sha((hist/'READ-L11-451.json').read_bytes())==verification['receipt_sha256'];assert verification['state_sha256']==sha((hist/'STATE-L11-451.json').read_bytes())
for role,num,scope in [(2755,1674,[[1,28]]),(2756,1675,[[7,13]])]:
 f=hist/f'REGISTRATION-SEGOVB-{num}.json';x=json.loads(f.read_bytes());src=[s for s in receipt['sources'] if s['original_index']==role];assert len(src)==1 and src[0]['registration_sha256']==sha(f.read_bytes()) and src[0]['assessed_ranges']==src[0]['fresh_personal_body_reads']==x['ranges']==scope and x['sha256']==registry['files'][role]['sha256'] and x['prospective']
rp=p/'history-774/rig/initial06-type-ownership';rows=[json.loads(l) for l in gzip.decompress((rp/'source-range-registration.jsonl.gz').read_bytes()).splitlines()];coverage=[json.loads(l) for l in gzip.decompress((rp/'coverage.jsonl.gz').read_bytes()).splitlines()];contracts=json.loads(gzip.decompress((rp/'contracts-010.json.gz').read_bytes()))['additional_definition_proofs']
for role,n,scope in [(2755,3,[[1,28]]),(2756,4,[[7,13]])]:
 key=f'RIG-INITIAL06-REG-{n:03d}';row=rows[n-1];assert row['id']==key and row==registry['files'][role]['parallel_reached_registration']['original_record'];assert contracts[key]['fresh_ranges']==scope;v=[x for x in coverage if x.get('id')==f'RIG-INITIAL06-SOURCE-{role}'];assert len(v)==1 and v[0]['actual_fresh_read_ranges']==scope
native=load('native-registration.json');archives={}
for e in native['packages']:
 b=(p/e['archive']).read_bytes();assert sha(b)==e['archive_sha256'] and len(b)==e['bytes'];m=load(e['prior_manifest']);assert sha((p/e['prior_manifest']).read_bytes())==e['prior_manifest_sha256'] and m['sha256']==sha(b) and m['bytes']==len(b);archives[e['package']]=p/e['archive']
for rf in ['native-registration.json','native2-registration.json','native3-registration.json','native4-registration.json','bridge-registration.json']:
 for e in load(rf)['entries']:
  if e.get('package_member'):
   pkg=e['package_member'].split('/')[0]
   with tarfile.open(archives[pkg],'r:gz') as t:assert t.extractfile(e['package_member']).read()==(p/e['archive']).read_bytes()
ls=(p/'support/lock.lock').read_text().splitlines();assert ls[11520]=='name = "wgpu"' and ls[11521]=='version = "29.0.4"' and native['packages'][0]['archive_sha256'] in ls[11523];assert ls[11673]=='name = "wgpu-types"' and ls[11674]=='version = "29.0.4"' and native['packages'][1]['archive_sha256'] in ls[11676];assert ls[11545].strip()=='"wgpu-types",'
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==18
report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13;assert load('reference/gpu-reflection-report.json')['author']=='/root/rig_identity';assert len(load('read-scope-summary.json')['scopes'])==len(groups)
print(json.dumps({'status':'pass','scope':'Offline 059/774 records and registry, prospective read receipts and unread complements, 6533/95e/f82 raw Git proofs, pinned native archives/lock, package members and earlier evidence hashes; no product validation','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
