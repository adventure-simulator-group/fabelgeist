import datetime,hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();specs=[('src/api/buffer.rs',[[835,852]]),('src/api/mod.rs',[[78,90]])];out=[]
for path,ranges in specs:
 member='wgpu-29.0.4/'+path
 with tarfile.open(p/'native/wgpu-29.0.4.crate','r:gz') as t:b=t.extractfile(member).read()
 f='native/wgpu-29.0.4-'+path.replace('/','_');existing=p/f
 if existing.exists():assert existing.read_bytes()==b
 else:existing.write_bytes(b)
 out.append({'package':'wgpu-29.0.4','package_member':member,'archive':f,'sha256':sha(b),'git_blob_for_content':blob(b),'bytes':len(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':out,'qualification':'Supplemental wgpu descriptor and Label type definitions after separate native source registration; previous contextual windows unchanged.'};(p/'native2-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(sha((p/'native2-registration.json').read_bytes()))
