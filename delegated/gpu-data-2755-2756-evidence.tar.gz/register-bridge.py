import datetime,hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();out=[]
for name,archive,ranges,member in [('project lock','support/lock.lock',[[11538,11550]],None),('wgpu package manifest','native/wgpu-29.0.4-Cargo.toml',[[190,200]],'wgpu-29.0.4/Cargo.toml')]:
 if member:
  with tarfile.open(p/'native/wgpu-29.0.4.crate') as t:b=t.extractfile(member).read()
  (p/archive).write_bytes(b)
 else:b=(p/archive).read_bytes()
 out.append({'name':name,'archive':archive,'package_member':member,'sha256':sha(b),'git_blob_for_content':blob(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':out,'qualification':'Supplemental declaration and lock dependency-identity windows only; no Cargo resolution or feature inference.'};(p/'bridge-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('registered',sha((p/'bridge-registration.json').read_bytes()))
