# Bounded GPU data evidence: roles 2755–2756

This packet records an independent static assessment by `/root/mhr_character`
against pinned project revision `95e63628f9d70b8dd6e6fede64334696c6995009`.
`report.json` contains the bounded thirteen-lens perspectives, source
references, connected existing findings and open questions. It does not
establish completion of any whole lens or the connected audit.

The original registry records both roles in the dirty `pr-working` snapshot,
whose recorded HEAD is `6533e444fa37552927070cc8d8190907fd3b413e`. Their
recovered object bytes individually match both recorded HEAD and the pinned
current file; no inference of a clean historical tree follows. The `f82...`
commit transports archived evidence and is not the project source revision.
`git-proofs.json` and the compressed raw commit/tree objects establish each
recorded path-to-blob chain offline.

`history-774/` preserves original rig registration, scope and comparison
records. `history-059/` preserves the original segovb prospective
registrations, receipt and state. Original role 2755 material was lines 1–28;
role 2756 was lines 7–13 only. The current review independently registered and
displayed historical and current 2755 lines 1–28 and 2756 lines 1–13; its
additional lines 1–6 do not retroactively expand either historic review.
Personal and support read scopes, original byte hashes, and every unread
complement are recorded by the registration/receipt files and
`read-scope-summary.json`. Source bytes outside the displayed ranges are
archival evidence, not claimed read coverage.

`native/` preserves the pinned `wgpu` and `wgpu-types` 29.0.4 registry
archives and selected source members. Their checksums match the 95e Cargo.lock;
this establishes package identity, not selected Cargo features or native
backend behavior. Prior `/root/rig_identity` and published GPU assessments are
preserved as separate references; they grant no transferred reader credit and
are not counted again. The original checkpoint 3821 queue and ledger are not
established by these records.

`python3 verify-evidence.py` checks saved Git objects, source members,
historical transport records, personal read receipts, package identity and
selected original registry/queue records. `python3 verify-manifest.py` checks
all packet files against the frozen root manifest, including nested manifests.
These are evidence integrity checks, not product validation. No product,
renderer, shader, macro, fixture, build, test or runtime probe was executed.

A preliminary search for `PassParameter::Unsigned` used the workspace Git
object store, which could not parse the pinned commit. It returned no source;
the search is not evidence of absence. The packet uses the pinned publication
object store for all project source and Git path proofs.
