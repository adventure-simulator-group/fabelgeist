import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();specs=[('wgpu-29.0.4','src/lib.rs',[[90,106]]),('wgpu-types-29.0.4','src/lib.rs',[[25,35],[52,60]])];out=[]
for pkg,path,ranges in specs:
 f='native/'+pkg+'-'+path.replace('/','_');b=(p/f).read_bytes();out.append({'package':pkg,'package_member':pkg+'/'+path,'archive':f,'sha256':sha(b),'git_blob_for_content':blob(b),'bytes':len(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':out,'qualification':'Supplemental package alias and exported descriptor linkage, selected windows only.'};(p/'native3-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('registered',sha((p/'native3-registration.json').read_bytes()))
