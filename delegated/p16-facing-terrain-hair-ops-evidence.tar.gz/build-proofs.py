import gzip,hashlib,json,subprocess,datetime
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());support=json.loads((p/'support-registration.json').read_bytes())['sources']+json.loads((p/'support-registration-2.json').read_bytes())['sources'];coord=json.loads((p/'coordinates-registration.json').read_bytes());hist=json.loads((p/'historical-manifest.json').read_bytes());objects={};proofs=[];(p/'git-objects').mkdir()
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for x in reg['rows']:
 n=x['role'];members.extend([{'revision':reg['p16_transport'],'path':x['f82_transport_object'],'local':f'source/p16-{n}.rs','qualification':'P16 recovered native source evidence object, not a clean full snapshot.'},{'revision':reg['p16_base'],'path':x['path'],'local':f'source/p16-{n}.rs','qualification':'Per-file clean-base equality only, not whole P16 tree.'},{'revision':reg['source_revision'],'path':x['path'],'local':f'source/95e-{n}.rs','qualification':'Current role independently displayed.'}])
for x in support:members.append({'revision':x['revision'],'path':x['path'],'local':x['saved'],'qualification':'95e current source support only.'})
members.append({'revision':coord['revision'],'path':coord['path'],'local':'support/10.rs','qualification':'95e coordinate owner support only.'})
for x in hist['exact_historical_files']:
 if x.get('transport_revision'):members.append({'revision':x['transport_revision'],'path':x['git_path'],'local':x['local'],'qualification':'Exact historical 774 camera document; attribution remains original.'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();top=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert tree==blob(b);proofs.append({**s,'commit_tree':top,'chain':chain,'blob':tree,'sha256':sha(b)})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Per-file f82 evidence-object membership and a120/95e project Git source membership; old P16 snapshot is dirty and source equality does not transfer reviewer credit.','objects':objects,'proofs':proofs},indent=2)+'\n')
windows={'support/0.rs':[[120,225]],'support/1.rs':[[1,80],[110,170]],'support/2.rs':[[1,156]],'support/3.rs':[[240,310],[316,410],[930,1000]],'support/4.rs':[[1,43]],'support/5.rs':[[1,36]],'support/6.rs':[[1760,1810]],'support/7.rs':[[1,57]],'support/8.rs':[[1,121]],'support/9.rs':[[1,100],[220,305]],'support/10.rs':[[1,145]]}
def complement(n,ranges):
 used=set();
 for a,b in ranges:used.update(range(a,b+1))
 arr=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):arr.append([start,i-1]);start=None
 return arr
reads=[]
for x in support+[{'path':coord['path'],'revision':coord['revision'],'saved':'support/10.rs','sha256':coord['sha256'],'lines':coord['eof']}]:
 w=windows[x['saved']];reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['lines'],'actual_display_ranges':w,'unread_complement':complement(x['lines'],w),'qualification':'Current source support only; test source in displayed ranges is text, not run.'})
rr={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in ['registration.json','support-registration.json','support-registration-2.json','coordinates-registration.json']],'assigned_roles':[{'index':x['role'],'historical_p16_source':f"source/p16-{x['role']}.rs",'current_95e_source':f"source/95e-{x['role']}.rs",'historical_and_current_separate_display_ranges':[[1,x['p16_eof']]],'historical_unread':[],'current_unread':[],'prior_774_camera_material':x['original_registry_record']['material_ranges'],'original_snapshot_field':x['original_registry_record']['snapshot'],'source_id':x['original_registry_record']['source_id'],'qualification':'P16 and current bytes each personally displayed separately after registration; separate clean-base object only verified equal. Earlier camera authorship, roles and source_coverage_awarded:false are retained.'} for x in reg['rows']],'support_reads':reads,'navigation':'Filename and symbol navigation lines outside these material windows are not claimed as assessed body coverage.','qualification':'Original P16 data and current 95e separately displayed; byte equality does not credit another agent or lens. No product execution, tests, builds, fixture simulation or validation.'}
(p/'read-receipt.json').write_text(json.dumps(rr,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'support scopes',len(reads))
