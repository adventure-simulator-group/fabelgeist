from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
r=load('registration.json');assigned=[]
for x in r['rows']:
 for v in x['versions']:
  assigned.append({'original_index':x['original_index'],'source_id':x['source_id'],'identity':v.get('identity','pinned current'),'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'displayed':[[1,v['eof']]],'unread_complement':[],'qualification':'Full separately displayed archived object and current body; contiguous union recorded, not a claim of separate reading of equal 6533 copy.'})
windows={
'crates/adventuresim-tactical-core/src/scene_coordinates/polygon.rs':[[1,191]],
'crates/adventuresim-tactical-core/src/city_layout/grounding/surface.rs':[[1,177]],
'crates/adventuresim-tactical-core/src/city_layout/compiled/grounded/projection.rs':[[1,334]],
'crates/adventuresim-tactical-core/src/scene_input/validation.rs':[[1,64]],
'crates/adventuresim-tactical-core/src/scene_input/generation/geographic.rs':[[1,96]],
'crates/adventuresim-tactical-core/src/city_layout/grounding/surface/floor.rs':[[1,270]],
'crates/adventuresim-tactical-core/src/city_layout/grounding/surface/validation.rs':[[1,159]],
'crates/adventuresim-tactical-core/src/scene_input.rs':[[1,180]],
'crates/adventuresim-tactical-core/src/city_layout/compiled/grounded.rs':[[1,199]],
'crates/adventuresim-tactical-core/src/city_layout/compiled.rs':[[1,130],[190,230]],
'crates/adventuresim-tactical-core/src/city_layout/compiled/assembly.rs':[[1,95]],
'crates/adventuresim-tactical-core/src/city_layout/compiled/single_support.rs':[[1,89]],
'crates/adventuresim-tactical-core/src/scene_input/descriptor.rs':[[1,103]],
'crates/adventuresim-tactical-core/src/scene_input/properties.rs':[[1,148]],
'crates/adventuresim-tactical-server-dispatcher/src/scene_input.rs':[[1,200],[440,470]]}
regs=[];supports=[]
for n in ['registration.json','support-registration.json','integrity-registration.json','stages-registration.json','layout-registration.json','descriptor-registration.json','callers-registration.json']:
 d=load(n);regs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':d['created_utc']})
 if n!='registration.json':
  for e in d['entries']:
   rs=windows[e['path']];supports.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'local':e['local'],'eof':e['eof'],'displayed':rs,'unread_complement':complement(e['eof'],rs),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','basis':'Assigned archive and 95e copies personally displayed separately after prospective registrations, with these contiguous unions of actual displayed lines; support reads after separate registrations. Tests displayed are source only, never executed.','assigned':assigned,'support':supports,'registrations':regs,'comparison_copies':'The matching 6533 direct Git copies archived for object identity were not personally displayed separately; their equality does not create an independent personal read at that revision.','navigation':'Before support registrations only Git filenames were returned; later rg navigation lines are included in the actual displayed unions. Prior authors retain their personal scopes; no 3821 promotion.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
