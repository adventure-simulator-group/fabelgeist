from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-tactical-core/src/scene_coordinates/polygon.rs','crates/adventuresim-tactical-core/src/city_layout/grounding/surface.rs','crates/adventuresim-tactical-core/src/city_layout/compiled/grounded/projection.rs','crates/adventuresim-tactical-core/src/scene_input/validation.rs','crates/adventuresim-tactical-core/src/scene_input/generation/geographic.rs'];entries=[];pending=[]
for path in paths:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;local='support/'+path;entries.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,len(raw.splitlines())]],'local':local});pending.append((local,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective bounded current polygon, terrain, scene validation and projection support. Initial discovery used filename-only searches. Earlier authors keep their source read credit; exact new windows and unread complements follow.','entries':entries};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('registration_sha256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
