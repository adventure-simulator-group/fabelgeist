# Grounding floor region and generation roles 2697–2698

This source-only packet is authored by `/root/hair_ops` for the central audit.
Start with `REPORT.json`, then `read-receipt.json`, `registration.json`, the
support registrations, and `historical-manifest.json`. The old and current
assigned source bodies were displayed separately. Direct 6533 copies prove
per-file identity and were not separately displayed. Support receipts record
actual ranges and unread complements. The original pr-working snapshot had
unrelated changes; byte identity of these files does not establish a clean tree.

The `recovered/` copies preserve the exact registry archive and 059 ledger and
queue previously recovered elsewhere. `historical/` contains earlier reviewer
records or the later unadopted 937 proposal, without changing their authorship
or claiming checkpoint 3821. `historical-selections-reconstructed.json` is a
new selection, not a historical original. `prior/` contains separate central
assessments. `git-proofs.json` and `git-objects/` provide offline Git
commit/tree/blob membership, while `MANIFEST.json` hashes every packet file
except itself, including the nested recovered manifest.

Run `python3 verify-evidence.py` solely to verify source and evidence integrity.
This verifier executes no product code. The packet contains partial, bounded
perspectives on all thirteen lenses, not whole-lens clearance. No build, tests,
product/fixture execution, runtime probe, simulation, implementation, source
edit or publication action was performed.
