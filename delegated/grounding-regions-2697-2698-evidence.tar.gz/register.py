from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';base=Path(repo)/'recovered/original-registry-source-archive';registry=json.load(gzip.open(base/'registry.json.gz','rt'));oldrev='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda x:hashlib.sha256(x).hexdigest();rows=[];pending=[]
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 for i in [2697,2698]:
  x=registry['files'][i];path=x['source_id'].split(':',1)[1];old=t.extractfile(x['sha256']).read();assert sha(old)==x['sha256'] and len(old)==x['bytes'] and len(old.splitlines())==x['actual_line_count'];local=f'source/{i}-pr-working.rs';pending.append((local,old));versions=[{'identity':'original pr-working exact archived object','revision_qualification':'Recorded snapshot has HEAD 6533 plus unrelated working changes; per-file equality independently checked','sha256':sha(old),'bytes':len(old),'eof':len(old.splitlines()),'local':local,'planned_display_ranges':[[1,len(old.splitlines())]]}]
  matches=[]
  for rev in [oldrev,cur]:
   raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;local=f'source/{i}-{rev[:4]}.rs';pending.append((local,raw));obj={'revision':rev,'sha256':sha(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':local,'equals_pr_working_object':raw==old}
   if rev==cur:obj['planned_display_ranges']=[[1,len(raw.splitlines())]];versions.append(obj)
   else:obj['display_planned']=False;matches.append(obj)
  rows.append({'original_index':i,'source_id':x['source_id'],'path':path,'original_material_ranges':x['material_ranges'],'versions':versions,'historical_6533_per_file':matches[0]})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective full original registry-object and pinned current source display, separately and in bounded chunks. No fresh 6533 Git-body read claimed unless separately displayed.','original_registry_uncompressed_sha256':sha(gzip.decompress((base/'registry.json.gz').read_bytes())),'snapshot_qualification':'pr-working snapshot is 6533 head plus recorded unrelated modifications. Per-file identity must not be promoted to whole-snapshot cleanliness or checkpoint3821.','rows':rows,'limits':'Source and evidence integrity only; no product execution, builds, tests, probes, fixtures, repairs or publication edits.'};(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('registration_sha256',sha((b/'registration.json').read_bytes()))
