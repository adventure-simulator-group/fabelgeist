'''Offline evidence-integrity verification only; no product or test execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['original_registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files'];assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id']=='pr-working']
for i in [2697,2698]:assert original[i]==sel['registry_rows'][str(i)]
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows']
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for x in reg['rows']:
  old=x['versions'][0];body=(b/old['local']).read_bytes();assert t.extractfile(old['sha256']).read()==body and h(body)==old['sha256']==original[x['original_index']]['sha256'];c=catalog[x['original_index']];assert c['expected_sha256']==old['sha256'] and c['origin']=='git:6533e444fa37552927070cc8d8190907fd3b413e:'+x['path']
  comp=x['historical_6533_per_file'];raw=(b/comp['local']).read_bytes();assert h(raw)==comp['sha256'] and raw==body and comp['equals_pr_working_object'] and comp['display_planned']==False;assert (b/x['versions'][1]['local']).read_bytes()==body
for x in rec['registrations']:
 assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def partition(n,ranges):
 nums=[i for a,z in ranges for i in range(a,z+1)];return len(nums)==n and set(nums)==set(range(1,n+1))
for r in reg['rows']:
 for v in r['versions']:
  p=next(x for x in rec['assigned'] if x['original_index']==r['original_index'] and x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'];assert partition(v['eof'],p['displayed']+p['unread_complement']) and p['unread_complement']==[]
planned={}
for n in ['support-registration.json','integrity-registration.json','stages-registration.json','layout-registration.json','descriptor-registration.json','callers-registration.json']:
 for x in load(n)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];assert partition(x['eof'],x['displayed']+x['unread_complement']);assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
r774=[json.loads(s) for s in (b/'historical/774/source-range-registration.jsonl').read_text().splitlines()];q774=[json.loads(s) for s in (b/'historical/774/source-qualifications-final-current.jsonl').read_text().splitlines()]
for i in [2697,2698]:
 for ob in original[i]['admission03_scope_observations']:
  j=ob['row_1based']-1;assert r774[j]==ob['original_record'] and q774[j]==ob['local_qualifications'][0]
assert original[2697]['material_ranges']==[[1,78]] and original[2698]['material_ranges']==[[1,75]]
l11=load('historical/059/segovb/READ-L11-440.json')
for i,ranges in {2697:[[1,78]],2698:[[1,75]]}.items():
 x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==ranges;name=Path(x['registration']).name;assert h((b/'historical/059/segovb'/name).read_bytes())==x['registration_sha256']
connected=load('historical/059/segovb/READ-CONNECTED-L12-672-POPULATIONS.json');x=next(x for x in connected['rows'] if x.get('population_index')==2698 and x.get('population')=='original');assert x['fresh_personal_body_reads']==[[1,78]] and x['new_ordered_population_credit']==0;assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-937.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False
for i,ranges in {2697:[[1,78]],2698:[[1,78]]}.items():
 x=next(x for x in p['rows'] if x['original_index']==i);assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256'];q=x['identity_specific_windows_qualification'];assert h((b/'historical/059'/q['path']).read_bytes())==q['sha256']
for x in p['partial_read_receipts']:assert h((b/'historical/059'/x['path']).read_bytes())==x['sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: 2 original pr-working objects and 95e separately displayed, per-file 6533 comparisons, exact 774/059/937 attribution, %d offline Git proofs, %d bounded supports, thirteen partial perspectives, and complete manifest if present. Evidence integrity only; no product, builds, tests, fixtures, probes or simulation.'%(len(proof['proofs']),len(rec['support'])))
