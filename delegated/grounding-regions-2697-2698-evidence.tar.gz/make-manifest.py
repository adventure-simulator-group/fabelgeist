from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;files=[]
for p in sorted(x for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'):
 raw=p.read_bytes();files.append({'path':str(p.relative_to(b)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
d={'schema':'726-grounding-2697-2698-evidence-manifest-v1','created_utc':datetime.now(timezone.utc).isoformat(),'qualification':'Every file except root MANIFEST.json; nested recovered/MANIFEST.json included. Evidence integrity only.','files':files};(b/'MANIFEST.json').write_text(json.dumps(d,indent=2)+'\n');print('files',len(files),'manifest_sha256',hashlib.sha256((b/'MANIFEST.json').read_bytes()).hexdigest())
