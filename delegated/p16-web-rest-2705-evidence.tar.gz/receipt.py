from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
r=load('registration.json');assigned=[]
for x in r['rows']:
 for v in x['versions']:
  rs=[[1,150],[151,300],[301,450],[451,580]];assigned.append({'original_index':2705,'source_id':x['source_id'],'identity':v.get('identity','pinned current'),'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'displayed':rs,'unread_complement':complement(v['eof'],rs),'qualification':'Archive and current copies separately and prospectively displayed in bounded chunks. Original exclusion windows are newly read context only, not retroactive original 774/059 credit.'})
windows={'crates/adventuresim-stdb-module/src/time/settlement_rest.rs':[[1,150],[175,490],[520,612]],'crates/adventuresim-core/src/strategic_economy.rs':[[1,45]],'crates/adventuresim-core/src/strategic_time.rs':[[1,22]],'crates/strategic-web/src/templates/settlement/rest.rs':[[1,70],[170,285],[425,490],[515,527]],'crates/strategic-web/src/templates/settlement/chrome.rs':[[1,20],[270,282],[680,685]],'crates/strategic-web/src/routes/settlements/rest_preview.rs':[],'crates/strategic-web/src/routes/settlements/camp.rs':[[850,915]],'crates/strategic-web/src/routes/quests.rs':[[1,30],[850,920]]};regs=[];supports=[]
for n in ['registration.json','support-registration.json','historical-comparisons-registration.json']:
 d=load(n);regs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':d['created_utc']})
 if n=='support-registration.json':
  for e in d['entries']:
   rs=windows[e['path']];supports.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'local':e['local'],'eof':e['eof'],'displayed':rs,'unread_complement':complement(e['eof'],rs),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','basis':'Original physical-p16 and pinned current assigned bodies each personally displayed1–580 after prospective registration, in listed chunks; tests displayed as source only. Each support range was separately registered before navigation/display.','assigned':assigned,'support':supports,'registrations':regs,'comparison_copies':'Direct a120, 6533, 039 and e275 comparison copies were archived for per-file Git identity, not separately displayed. Equal bytes do not imply a clean P16 or pr-working snapshot, nor a personal read at those revisions.','prior_same_agent':'<LOCAL_PATH_0> role2380 previously recorded one full-body personal display1–840 of byte-identical copies but does not specify which 6533/95e copy was displayed; never infer two reads. Prior equipment support370–388 and separate current support receipts retain previous attribution.','navigation':'Source discovery before registrations listed filenames only; later rg output is bounded within shown support windows, except rest_preview has no body display. Historical authors keep original scope; no checkpoint3821 credit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
