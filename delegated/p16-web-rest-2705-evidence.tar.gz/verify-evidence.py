'''Offline evidence-integrity verification only; no product or test execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['original_registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files'];assert all(original[i]==sel['registry_rows'][str(i)] for i in [2380,2705]);assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id'] in ['physical-p16','pr-working']]
snapshot=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['recovered_patch']['bytes']==len(patch) and recovery['live_comparison']['status_counts']['??']==7
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows'];x=reg['rows'][0];old=x['versions'][0];body=(b/old['local']).read_bytes()
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:assert t.extractfile(old['sha256']).read()==body
assert h(body)==old['sha256']==original[2705]['sha256']==original[2380]['sha256']==catalog[2705]['expected_sha256']==catalog[2380]['expected_sha256'];assert catalog[2705]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+x['path'];assert catalog[2380]['origin']=='git:6533e444fa37552927070cc8d8190907fd3b413e:'+x['path']
for c in x['comparison_git_paths']+load('historical-comparisons-registration.json')['entries']:
 assert (b/c['local']).read_bytes()==body and c['display_planned']==False
assert (b/x['versions'][1]['local']).read_bytes()==body
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def partition(n,ranges):
 nums=[i for a,z in ranges for i in range(a,z+1)];return len(nums)==n and set(nums)==set(range(1,n+1))
for r in reg['rows']:
 for v in r['versions']:
  p=next(x for x in rec['assigned'] if x['original_index']==r['original_index'] and x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'];assert partition(v['eof'],p['displayed']+p['unread_complement']) and p['unread_complement']==[[581,840]]
planned={x['local']:x for x in load('support-registration.json')['entries']}
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];assert partition(x['eof'],x['displayed']+x['unread_complement']);assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
r774=[json.loads(s) for s in (b/'historical/774/root-source-range-registration.jsonl').read_text().splitlines()];q774=[json.loads(s) for s in (b/'historical/774/root-source-qualifications-final.jsonl').read_text().splitlines()]
for ob in original[2705]['admission03_scope_observations']:
 j=ob['row_1based']-1;assert r774[j]==ob['original_record'] and q774[j]==ob['local_qualifications'][0]
assert original[2705]['material_ranges']==[[1,21],[32,91],[104,158]]
rig=[json.loads(s) for s in (b/'historical/774/rig-source-range-registration.jsonl').read_text().splitlines()];ob=original[2380]['admission03_increment050_role_observations'][0];assert rig[ob['row_1based']-1]==ob['original_record'];traces=[json.loads(s) for s in (b/'historical/774/rig-producer-traces.jsonl').read_text().splitlines()];trace=next(t for t in traces if t.get('id')=='RIG-PPS-038');assert trace['additional_actual_source_proofs'][9]==original[2380]['producer_reached_contract_observations'][0]['source_context']
l11=load('historical/059/segovb/READ-L11-441.json');x=next(x for x in l11['sources'] if x['original_index']==2705);assert x['fresh_personal_body_reads']==[[1,21],[32,91],[104,158]];assert h((b/'historical/059/segovb'/Path(x['registration']).name).read_bytes())==x['registration_sha256']
a=load('historical/059/adler/READ-L11-386.json');x=next(x for x in a['sources'] if x['original_index']==2380);assert x['fresh_reads']==[[1,377]];assert h((b/'historical/059/adler/REGISTRATION-ADLER-1250.json').read_bytes())==x['registration_sha256']
l11=load('historical/059/segovb/READ-L11-464.json');x=next(x for x in l11['sources'] if x['original_index']==2380);assert x['fresh_personal_body_reads']==[[378,840]];assert h((b/'historical/059/segovb/REGISTRATION-SEGOVB-1776.json').read_bytes())==x['registration_sha256']
p=load('historical/059/segovb/READ-L11-569.json');x=next(x for x in p['rows'] if x.get('registration')=='PL11-0290');assert x['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and x['fresh_personal_body_ranges']==[] and x['qualified_same_lens_reuse_ranges']==[[378,840]]
p=load('historical/059/segovb/READ-L12-792.json');x=next(x for x in p['rows'] if x['original_index']==2380);assert x['fresh_personal_body_reads']==[[1,377]] and '/root/lens12_frontier' in x['attribution'] and p['root_personal_rereads']==[];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
for file,ranges in [('READ-CONNECTED-PAR-L12-787-CAMP-APPEARANCE-OWNERS.json',[[378,395]]),('READ-CONNECTED-PAR-L12-792-REST-SUMMARY.json',[[396,580]])]:
 p=load('historical/059/parallel-l12-20261029/'+file);x=next(x for x in p['rows'] if x['original_index']==2380);assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution'] and x['new_original_credit']==0;assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-940.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False;x=next(x for x in p['rows'] if x['original_index']==2705);assert x['fresh_personal_body_reads']==[[1,159]] and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256'];q=x['identity_specific_windows_qualification'];assert h((b/'historical/059'/q['path']).read_bytes())==q['sha256']
for x in p['partial_read_receipts']:assert h((b/'historical/059'/x['path']).read_bytes())==x['sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: dirty-P16 role2705 and 95e separately displayed1–580, unread581–840; distinct role2380 and exact 774/059 per-lens scopes; unadopted proposal940; later matching tracked patch with untracked qualification; %d Git proofs and %d registered supports. Thirteen partial perspectives; evidence integrity only, no product/build/test/fixture/probe.'%(len(proof['proofs']),len(rec['support'])))
