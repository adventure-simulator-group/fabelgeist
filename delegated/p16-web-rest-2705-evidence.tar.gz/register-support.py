from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-stdb-module/src/time/settlement_rest.rs','crates/adventuresim-core/src/strategic_economy.rs','crates/adventuresim-core/src/strategic_time.rs','crates/strategic-web/src/templates/settlement/rest.rs','crates/strategic-web/src/templates/settlement/chrome.rs','crates/strategic-web/src/routes/settlements/rest_preview.rs','crates/strategic-web/src/routes/settlements/camp.rs','crates/strategic-web/src/routes/quests.rs'];entries=[];pending=[]
for path in paths:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;n=len(raw.splitlines());local='support/'+path;entries.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':n,'local':local,'planned_display_ranges':[[1,n]]});pending.append((local,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective bounded current authority, duration, UI and travel/field-rest consumers. Filename-only navigation preceded registration. Prior same-agent and other-agent reads retain attribution; actual new windows and complements recorded separately.','entries':entries};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('sha256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
