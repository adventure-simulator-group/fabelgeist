from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';path='crates/strategic-web/src/routes/settlements/rest.rs';h=lambda x:hashlib.sha256(x).hexdigest();entries=[];pending=[]
for rev in ['039329518e264f19206cf5b0b98d177433f40c17','e2755a732c84e67296b5e3441a4259a84f461b2f']:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;local='source/2705-'+rev[:4]+'.rs';entries.append({'revision':rev,'path':path,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':local,'equals_registry_object':raw==(b/'source/2705-physical-p16.rs').read_bytes(),'display_planned':False});pending.append((local,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Comparison only: 039 older reconstructed catalogue provenance and e275 historic current Lens11 receipt; no separate personal display or transferred body credit.','entries':entries};(b/'historical-comparisons-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for local,raw in pending:(b/local).write_bytes(raw)
print(json.dumps(d,indent=2));print('sha256',h((b/'historical-comparisons-registration.json').read_bytes()))
