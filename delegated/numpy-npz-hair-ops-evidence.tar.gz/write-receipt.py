'''Retain actual displayed source scopes; archived bytes alone do not count.'''
import json,hashlib,datetime
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((p/n).read_bytes())
regs=['registration.json','support-registration.json'];all_sources=[]
for n in regs[1:]:
 for s in load(n)['sources']:
  if not any(x['saved']==s['saved'] for x in all_sources): all_sources.append(s)
displays={'support/00.rs':[[1,68]],'support/01.rs':[[1,100],[101,184]],'support/02.rs':[[1,44]],'support/03.rs':[[1,80]],'support/04.rs':[[1,130]]}
def complement(n,rs):
 covered={i for a,z in rs for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in covered:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
support=[{'path':s['path'],'revision':s['revision'],'saved':s['saved'],'sha256':s['sha256'],'eof':s['eof'],'displayed':displays[s['saved']],'unread_complement':complement(s['eof'],displays[s['saved']]),'qualification':'Fresh prospective current support only, no ordered role or earlier reviewer credit; source text only.'} for s in all_sources]
a=[{'role':2656,'pr_working_actual_display':[[1,100],[101,186]],'current_95e_actual_display':[[1,110],[111,221]],'unread_old_and_current':[],'qualification':'Old and current copies personally displayed separately after prospective registration. 6533 and e275 per-file identity verified, not separate personal body displays.'}]
o={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in regs],'assigned':a,'support':support,'limits':'Personal display scope only; independent prior reviewers are not transferred. Test source not executed. A broad preliminary git grep incidentally printed truncated fixture-text matches before support registration; those lines are not assessed and receive no read credit; no fixture was processed or executed.'};(p/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n')
