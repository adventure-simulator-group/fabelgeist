# Bounded NPZ source evidence

`REPORT.json` records the `/root/hair_ops` source-only review of original role
2656 and its bounded support, with historical relationships and thirteen
partial perspectives. This packet is not whole-audit completion, a repair,
product validation, or a substitute for the unrecovered checkpoint 3821.

`registration.json` prospectively registered the historical pr-working and
current 95e bodies; `support-registration.json` separately registered current
support. `read-receipt.json` records actual displays and unread complements.
Full archived source bytes do not alone confer read credit. Historical
pr-working matches the 6533 file, while 95e differs; `additional-revision.json`
verifies that the independently reviewed e275 file equals 95e. These are
per-file comparisons, not whole-tree claims. The recorded pr-working snapshot
has unrelated modifications.

`git-proofs.json` and `git-objects/` bind each revision and source to its Git
objects. `historical/` preserves selected exact original 059 records and an
explicitly reconstructed selection of 059 queue rows. `historical-manifest.json`
hashes the original registry, 774 records and earlier evidence dependencies;
linked published files are necessary for the full verification. `MANIFEST.json`
fixes this packet's own bytes.

Run `python3 verify-evidence.py` for evidence-integrity verification only. It
checks source identity and read partitions, Git membership chains, exact prior
records and evidence dependencies; it does not execute the product, tests,
archive decoder, fixtures, simulation, or repair code.
