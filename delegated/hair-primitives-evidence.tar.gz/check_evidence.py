import hashlib,json,pathlib,tarfile,tomllib
p=pathlib.Path('<LOCAL_PATH_0>')
def digest(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
reg=json.loads((p/'registration.json').read_text())
for x in reg['ordered_roles']:
 b=(p/'source'/pathlib.Path(x['path']).name).read_bytes()
 assert (digest(b),blob(b),len(b),b.count(b'\n'))==(x['sha256'],x['git_blob'],x['bytes'],x['lines'][1]),x['path']
support=0
for i in range(1,5):
 data=json.loads((p/('support-registration-%02d.json'%i)).read_text())
 for x in data['registered_sources']:
  file='support-'+x['path'].replace('/','__')
  b=(p/'source'/file).read_bytes()
  assert (digest(b),blob(b),len(b),b.count(b'\n'))==(x['sha256'],x['blob'],x['bytes'],x['range'][1]),x['path']
  support+=1
native=json.loads((p/'native-registration-rayon.json').read_text()); archive=(p/native['archive']).read_bytes(); src=(p/'source/rayon-slice-mod.rs').read_bytes()
assert (len(archive),digest(archive))==(native['archive_bytes'],native['archive_sha256'])
assert (len(src),digest(src),src.count(b'\n'))==(native['source_member_bytes'],native['source_member_sha256'],native['registered_ranges'][0][1])
with tarfile.open(p/native['archive'],'r:gz') as t:assert t.extractfile(native['source_member']).read()==src
lock=tomllib.loads((p/'source/support-Cargo.lock').read_text()); rayon=[x for x in lock['package'] if x['name']=='rayon' and x['version']=='1.12.0']; assert len(rayon)==1 and rayon[0]['checksum']==digest(archive)
history=json.loads((p/'historical-manifest.json').read_text())
for x in history['records']:
 b=(p/x['copy_path']).read_bytes();assert (len(b),digest(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob']),x['copy_path']
report=json.loads((p/'report.json').read_text())
assert report['registration']['sha256']==digest((p/'registration.json').read_bytes())
assert report['historical_manifest']['sha256']==digest((p/'historical-manifest.json').read_bytes())
for x in report['support']:assert x['sha256']==digest((p/x['registration']).read_bytes())
for x in report['prior_current_copies']:assert x['sha256']==digest((p/x['path']).read_bytes())
print('Evidence integrity passed:',len(reg['ordered_roles']),'ordered source objects,',support,'support source objects, native Rayon archive/member and lock checksum,',len(history['records']),'historical copies, 4 prior current records and all registration hashes. No product build, test, algorithm, fixture or runtime probe ran.')
