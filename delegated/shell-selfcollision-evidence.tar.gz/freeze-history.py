from pathlib import Path
import gzip,hashlib,json
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');ex=Path('<LOCAL_PATH_1>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));mi=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in mi['entries']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-registry-reconstruction-v1','qualification':'Selected original registry row and snapshots reconstructed, not original standalone record or checkpoint3821.','rows':[{'original_index':2659,**r['files'][2659]}],'snapshots':[x for x in r['snapshots'] if x['id'] in ('pr-working','physical-p16')]},indent=2)+'\n')
q=json.load(open(pub/'baseline-059/queue.json'))['entries'];ids=[622,1858,3439];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-queue-reconstruction-v1','qualification':'Selected 059 queue rows retain original status, revision and attribution; no automatic aliases or new counts.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in ids]},indent=2)+'\n')
paths=[f'segovb/{k}-L11-434.json' for k in ('READ','VERIFY','STATE')]+['segovb/REGISTRATION-SEGOVB-1576.json']+[f'segovb/{k}-L12-919.json' for k in ('READ','VERIFY','STATE')]+['parallel-l12-20261029/PROPOSAL-L12-919.json','parallel-l12-20261029/REGISTRATION-PAR-L12-724.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-724-ORIGINAL2659.json']
records=[];missing=[]
for path in paths:
 f=ex/path
 if not f.exists() or path not in idx:missing.append({'path':path,'exists':f.exists(),'in_transport_manifest':path in idx});continue
 raw=f.read_bytes();m=idx[path];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];dest=b/'historical-059'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);records.append({'original_path':path,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dest.relative_to(b))})
assert not missing,missing
links=[]
def link(p,origin,note):
 raw=p.read_bytes();links.append({'path':str(p),'sha256':sha(raw),'bytes':len(raw),'origin':origin,'qualification':note})
for p in ['recovered/original-registry-source-archive/registry.json.gz','recovered/original-transport-manifest.json.gz','baseline-059/queue.json','baseline-059/ledger.json','ASSESSMENT-DELEGATED-RECONCILIATION-4-95E.json','delegated/shell-solver-report.json','delegated/shell-contact-report.json','delegated/shell-mesh-material-report.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','recovered/physical-p16-patch-recovery/tracked.patch']:
 link(pub/p,'published original and earlier current evidence','Retain own revision, source and reviewer scopes; no 3821 or borrowed role credit.')
old=Path('<LOCAL_PATH_2>')
for p in ['MANIFEST.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774-compressed/additional-contracts.jsonl.gz','git-proofs.json']:
 link(old/p,'prior frozen evidence packet','Original rig 774 registration and additional-contract records with f82 Git proof.')
old=Path('<LOCAL_PATH_3>')
for p in ['MANIFEST.json','historical-774/rig-findings.jsonl.gz','git-proofs.json']:
 link(old/p,'prior frozen evidence packet','Original rig F089 and F073-SUPPLEMENT-002 and raw Git proof; no automatic aliases.')
for name,files in [('shell-solver',['support-read-receipt.json','support-0.rs']),('shell-contact',['support-read-receipt.json','support-2.rs']),('shell-mesh-material',['personal-read-receipt.json','REPORT.json'])]:
 for f in files:link(Path('<LOCAL_PATH_4>'+name)/f,'prior independent 95e review','Retain original author, revision and actual registered support ranges; no role credit transfer.')
(b/'historical-attribution.json').write_text(json.dumps({'schema':'726-shell-selfcollision-historical-attribution-v1','records_059':records,'missing':missing,'qualification':'774 rig REG122 and ADD122 full 1–283, F089 radius/spacing and F073 supplement count; source only. 059 READ-L11-434 records fresh body without naming reader; /root/lens12_frontier personally read 1–283 at historical 6533 in L12-919, root adoption zero rereads. L12 already calls built-before-dispatch conditional and identifies ordinary true rebuild. /root/mhr_character separately read the full 95e body as support in shell-contact and shell-solver; /root/rig_identity prior mesh-material packet read partial support ranges. No borrowed ordered credit; f82 transport not project revision; P16 and 3821 not promoted.'},indent=2)+'\n');(b/'evidence-links.json').write_text(json.dumps({'schema':'726-shell-selfcollision-hash-links-v1','links':links},indent=2)+'\n');print('059 records',len(records),'links',len(links),'missing',missing)
