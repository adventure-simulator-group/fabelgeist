from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda d:hashlib.sha256(d).hexdigest()
plans=[('crates/fabelgeist-shell/src/shell.rs','support/shell.rs',[[33,52],[75,89],[135,145],[190,205],[210,247],[270,290],[380,408]]),('crates/fabelgeist-shell/src/mesh.rs','support/mesh.rs',[[85,115],[131,139]]),('crates/fabelgeist-shell/src/lib.rs','support/lib.rs',[[18,48]]),('crates/fabelgeist-shell/src/wgsl.rs','support/wgsl.rs',[[95,135],[140,166],[210,320]]),('crates/fabelgeist-compute/src/kernel/mod.rs','support/kernel.rs',[[210,315],[345,365]]),('crates/fabelgeist-xpbd/src/particles.rs','support/particles.rs',[[1,88]])]
rows=[]
for path,dest,ranges in plans:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in ranges)
 chunks=[[start,min(start+59,z)] for a,z in ranges for start in range(a,z+1,60)]
 (b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(raw);rows.append({'kind':'connected current support; WGSL text only','revision':rev,'path':path,'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path]).decode().strip(),'sha256':sha(raw),'bytes':len(raw),'eof':eof,'archive':dest,'registered_ranges':ranges,'planned_chunks':chunks})
r={'schema':'726-shell-selfcollision-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'Prospective bounded current support only; no ordered role, other reviewer credit, shader or product execution.'};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((b/'support-registration.json').read_bytes()));print(json.dumps(rows,indent=2))
