# Bounded self-collision source evidence

This packet records `/root/rig_identity`'s independent source-only review of
original registry role 2659 (`fabelgeist-shell/src/selfcollision.rs`) and
separately registered support. It supplies thirteen bounded perspectives; it
does not establish whole-lens completion, product validation, or unique ledger
counts.

The recorded `pr-working` snapshot has head
`6533e444fa37552927070cc8d8190907fd3b413e` and four unrelated status entries.
The selected file object independently equals its file at that head and pinned
current revision `95e63628f9d70b8dd6e6fede64334696c6995009`. Revision
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports recovered evidence; it
is not the project revision. Raw Git commit, tree and blob membership proofs
are in `git-proofs.json` and `git-objects/`.

The old and current role bodies were independently displayed in full, lines
1–283, after prospective registration. Current shell, mesh, material/export,
WGSL text, command-batch and particle support are separately registered.
`personal-read-receipt.json` records actual display chunks and unread
complements. Original 774 rig source reads and the 059 Lens12 read by
`/root/lens12_frontier` remain attributed to their historical revision and
scope. The 059 Lens11 receipt does not name an individual reader. Earlier
`/root/mhr_character` self-collision 1–283 support reads and the partial
`/root/rig_identity` support reads retain their own current revision and
attribution; they do not transfer ordered-role credit.

The report identifies one conditional direct-input question: an asymmetric
adjacency list can cause direction-dependent exclusion in the shown shader
text, if the caller intended an undirected mesh-edge relationship. The normal
validated mesh path constructs both directions. Actual callers, policy, native
results and unique-count treatment remain open. The historical 059 q3439
already flagged the cached `built` state before dispatch. The current batch
source additionally shows recording and submission are separate; cross-batch
failure or ordering remains conditional, while same-batch ordered recording
can be valid. Earlier radius/spacing, native-count, tiny-thickness, endpoint
indexing and fixed-point observations keep their individual authors and
conditions.

`registry-selection-reconstructed.json` and
`queue-selection-reconstructed.json` are selected reconstructed records, not
original standalone files. The original 059 records in `historical-059/` are
exact bytes checked against the recovered transport manifest. Historical 774
records and earlier assessments are hash-linked in `evidence-links.json`.
`published-prior-packet-links.json` checks only listed selected members against
published archives; it does not assert every archive member is an exact
original. Those published bundles and exact earlier packets are dependencies of
full verification.

The separate P16 dirty snapshot is based on
`a120390947c89b703dc74c4255a13c035d054c50`; that base is not the dirty
snapshot's commit. Its later recovered tracked patch matches the recorded hash,
with seven untracked files separate; matching bytes do not establish the
original diff invocation or uninterrupted custody. This packet does not
recover or promote the checkpoint 3821 ledger or queue.

Run `python3 verify-evidence.py` to check evidence integrity, provenance and
source ranges; run `python3 verify-manifest.py` to check frozen packet files.
These are evidence-only checks. No product, GPU, shader, simulation, fixture,
build, test or runtime probe was executed.
