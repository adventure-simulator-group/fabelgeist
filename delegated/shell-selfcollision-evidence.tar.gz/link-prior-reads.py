from pathlib import Path
import hashlib,json,tarfile
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda d:hashlib.sha256(d).hexdigest();p=b/'published-prior-packet-links.json';x=json.loads(p.read_bytes())
for name,files in [('shell-solver',['support-read-receipt.json','support-0.rs']),('shell-contact',['support-read-receipt.json','support-2.rs']),('shell-mesh-material',['personal-read-receipt.json','REPORT.json'])]:
 local=Path('<LOCAL_PATH_1>'+name);archive=pub/(name+'-evidence.tar.gz');raw=archive.read_bytes();members=[]
 with tarfile.open(archive,'r:gz') as t:
  for f in files:
   d=t.extractfile(f).read();assert d==(local/f).read_bytes();members.append({'member':f,'sha256':sha(d),'bytes':len(d)})
 x['archives'].append({'published_archive':str(archive),'sha256':sha(raw),'bytes':len(raw),'local_original_bundle':str(local),'byte_identical_members':members,'qualification':'Only selected source and read/assessment member bytes verified; other members may be reconstructed.'})
p.write_text(json.dumps(x,indent=2)+'\n');print('published linked archives',len(x['archives']))
