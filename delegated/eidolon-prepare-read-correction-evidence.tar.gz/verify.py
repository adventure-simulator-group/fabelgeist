import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());c=load('correction.json')
for owner in ['own','rig']:
 e=c['files'][owner];m=(p/e['manifest']).read_bytes();assert sha(m)==e['manifest_sha256'];index={x['path']:x for x in json.loads(m)['files']}
 for name in e['files']:
  b=(p/owner/name).read_bytes();assert (len(b),sha(b))==(index[name]['bytes'],index[name]['sha256'])
rig=p/'rig';receipt=json.loads((rig/'support-read-receipt.json').read_bytes());assert receipt['author']=='/root/rig_identity';entries={x['id']:x for x in receipt['entries']};plans=[];seen=[]
for fn,ident,wanted in [('support-registration-2.json','native-prepare',[[1,105],[227,340]]),('support-registration-3.json','native-inputs',[[106,226]])]:
 b=(rig/fn).read_bytes();reg=json.loads(b);ref=next(x for x in receipt['registrations'] if x['path']==fn);assert sha(b)==ref['sha256'];assert datetime.datetime.fromisoformat(ref['at_utc'])<datetime.datetime.fromisoformat(receipt['at_utc']);a=next(x for x in reg['entries'] if x['id']==ident);v=entries[ident];assert a['revision']=='1a5aff8d4809287e5f5713fb4cf72181b2285fff' and a['git_path']=='src/render/prepare/mod.rs' and a['prospective_personal_read_ranges']==wanted;body=(rig/a['archive']).read_bytes();assert sha(body)==a['sha256']==v['sha256']=='7b8be56d6f6ea9285176e55efb88de7bcb8a15df4cdca7619d3038a92de56092' and blob(body)==a['git_blob']=='073b691cfb1f6f64c2a62f7726a044cae08897c8';planned={i for lo,hi in wanted for i in range(lo,hi+1)};actual={i for lo,hi in v['actual_display_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in v['unread_complement'] for i in range(lo,hi+1)};assert planned==actual and missing==set(range(1,341))-actual;plans.append(planned);seen.append(actual)
assert not seen[0].intersection(seen[1]) and seen[0]|seen[1]==set(range(1,341));body=(rig/'support/native-prepare.source').read_bytes();assert body==(rig/'support/native-inputs.source').read_bytes()==(p/'own/support/prepare.rs').read_bytes()
proof=load('own/git-proofs.json');x=next(v for v in proof['proofs'] if v['revision']=='1a5aff8d4809287e5f5713fb4cf72181b2285fff' and v['path']=='src/render/prepare/mod.rs');objs={}
for oid in {x['revision']}|{a['tree'] for a in x['chain']}:
 e=proof['objects'][oid];b=gzip.decompress((p/'own'/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
typ,commit=objs[x['revision']];assert typ=='commit';tree=commit.splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
for name,link in zip(x['path'].split('/'),x['chain']):
 assert tree==link['tree'] and name==link['name'];typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
assert blob(body)==tree==x['blob'];own=load('own/report.json');assert '106–226 unread' in own['historical_relationships']['prior_delegate'];assert '106–226 unread' in (p/'own/README.md').read_text()
print(json.dumps({'status':'pass','scope':'Frozen packet manifests, separately registered prior reader receipts and same-source identity, raw Git path membership and exact read union; evidence only','native_prepare_chunks':[[1,105],[227,340]],'native_inputs_chunks':[[106,226]],'combined_union':[[1,340]],'ordered_role_credit':'none','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
