from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent
chunks={'native-manifest':[[1,31],[32,62],[63,93]],'native-runner':[[1,40],[41,80],[81,118]],'native-updater':[[1,33],[34,66],[67,99],[100,130]],'native-id-allocator':[[1,33],[34,66],[67,99],[100,130]],'native-writable-macro':[[228,230]],'old-lock':[[1,8],[303,325],[1898,1920]],'old-manifest':[[118,132],[195,207]],'old-client-manifest':[[45,65]],'old-cull-adapter':[[1,28],[29,55],[110,138],[139,167]],'old-shader':[[1,37]],'current-lock':[[1,8]],'current-manifest':[[118,132],[185,205]],'current-client-manifest':[[45,65]],'current-grass':[[1,34],[35,67],[68,100]],'native-utils':[[1,47]],'native-backend':[[1,35],[36,71]],'native-paged':[[1,38],[39,76],[77,114],[115,152],[153,190],[191,225]],'native-prepare':[[1,35],[36,70],[71,105],[227,260],[261,300],[301,340]],'native-prepare-core':[[1,47]],'native-inputs':[[106,135],[136,165],[166,195],[196,226]],'native-instance-type':[[35,75]],'native-cull-wgsl':[[1,28],[29,55]],'native-updater-tail':[[131,152]],'native-cull-types':[[1,37]],'native-cull-bindings':[[1,12]],'old-grass-batches':[[1,43],[44,86]]}
out={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':[],'entries':[]}
for fname in ['support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json']:
 raw=(b/fname).read_bytes();reg=json.loads(raw);out['registrations'].append({'path':fname,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for e in reg['entries']:
  ch=chunks[e['id']];covers={i for a,z in ch for i in range(a,z+1)};missing=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covers and start is None:start=i
   elif (i>e['eof'] or i in covers) and start is not None:missing.append([start,i-1]);start=None
  out['entries'].append({'registration':fname,'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':missing,'qualification':'Personally displayed bounded support at the revision on registration; no historic role transfer. Test, WGSL and macro invocation text read only, not executed.'})
(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('recorded',len(out['entries']),'support reads')
