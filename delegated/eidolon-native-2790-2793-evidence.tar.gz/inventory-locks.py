from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tomllib
b=Path(__file__).resolve().parent;raw=(b/'lock-registration.json').read_bytes();reg=json.loads(raw);out=[]
for e in reg['entries']:
 d=(b/e['archive']).read_bytes();doc=tomllib.loads(d.decode());matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in doc.get('package',[]) if p['name']=='bevy_eidolon'];consumers=[p['name'] for p in doc.get('package',[]) if any(x.split(' ',1)[0]=='bevy_eidolon' for x in p.get('dependencies',[]))];out.append({'id':e['id'],'sha256':e['sha256'],'package_count':len(doc.get('package',[])),'matches':matches,'consumer_names':consumers,'mode':'whole-file stdlib TOML structural inventory, not personal body display or Cargo feature/target resolution'})
r={'schema':'726-lock-inventory-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(raw).hexdigest(),'entries':out};(b/'lock-inventory.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(out,indent=2))
