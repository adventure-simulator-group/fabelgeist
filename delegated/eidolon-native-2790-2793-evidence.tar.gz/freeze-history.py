from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
ex=Path('<LOCAL_PATH_1>')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d);return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[]
for src,dest,kind in [('recovered/original-registry-source-archive/registry.json.gz','history/original-registry.json.gz','original 059 recovered registry'),('recovered/original-transport-manifest.json.gz','history/original-transport-manifest.json.gz','original 059 extraction transport manifest'),('recovered/l13-root-719/bevy-eidolon-native.bundle','history/bevy-eidolon-native.bundle','recovered native 1a5 Git bundle'),('ASSESSMENT-GRASS-CHUNK-AND-CONFIG-95E.json','history/assessment-grass-chunk-95e.json','earlier separately attributed current and historical grass assessment'),('ASSESSMENT-L01-HISTORICAL-1554-1561.json','history/assessment-l01-grass-1554-1561.json','earlier historical grass assessment')]:
 refs.append({'kind':kind,'original':src,**save((pub/src).read_bytes(),dest)})
for src,dest in [('baseline-059/queue.json','history/baseline-059-queue.json.gz'),('baseline-059/ledger.json','history/baseline-059-ledger.json.gz')]:
 raw=(pub/src).read_bytes();refs.append({'kind':'059 historical summary mechanically compressed; not checkpoint 3821','original':src,'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(gzip.compress(raw,mtime=0),dest)})
registry=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()))
idx={v['path']:v for v in json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()))['entries']}
inds=[2790,2791,2792,2793]
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanically selected rows from retained original registry; native commit is not project Git; original metadata is not reading credit or checkpoint 3821.','rows':[{'original_index':i,**registry['files'][i]} for i in inds],'snapshots':[x for x in registry['snapshots'] if x['id']=='pr-working']},indent=2)+'\n')
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries'];qi=[1313,1314,1315]
(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-059-queue-reconstruction-v1','qualification':'Related historical grass/native questions; neither alias nor closure nor count assumed.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in qi]},indent=2)+'\n')
paths=['segovb/READ-L11-455.json','segovb/STATE-L11-455.json','segovb/VERIFY-L11-455.json']+[f'segovb/REGISTRATION-SEGOVB-{n}.json' for n in range(1710,1714)]+['segovb/READ-L11-483.json','segovb/STATE-L11-483.json','segovb/VERIFY-L11-483.json','segovb/REGISTRATION-SEGOVB-1815.json']
records=[]
for p in paths:
 raw=(ex/p).read_bytes();m=idx[p];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];records.append({'original_path':p,'git_blob':m['git_blob'],**save(raw,'history/059/'+p)})
old=[];prefix='handoff/774/adler-original/audit/continuation/'
for p in ['native/initial05-aggregate-states/source-range-registration.jsonl','native/initial05-aggregate-states/source-qualifications.jsonl','native/initial05-aggregate-states/coverage.jsonl','native/initial05-aggregate-states/contract-groups-071.json','native/initial05-aggregate-states/findings.jsonl','root/initial04-invariant-operations/findings.jsonl']:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+prefix+p]);old.append({'revision':rev,'transport_path':prefix+p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+p+'.gz')})
a=json.loads(gzip.decompress((b/'history/774/native/initial05-aggregate-states/source-range-registration.jsonl.gz').read_bytes()).decode().splitlines()[0])
rows=[json.loads(line) for line in gzip.decompress((b/'history/774/native/initial05-aggregate-states/source-range-registration.jsonl.gz').read_bytes()).splitlines()]
for i in inds:
 item=registry['files'][i]['scope_registration'][0];assert rows[item['row_1based']-1]==item['original_record']
mismatch={'recorded_registry_registration_sha256':'be4de13c0087526fb48f225e3113291ff752609a986f4ae768660f8d617a16e2','f82_registration_sha256':sha(gzip.decompress((b/'history/774/native/initial05-aggregate-states/source-range-registration.jsonl.gz').read_bytes())),'qualification':'All four selected f82 parsed registration rows equal embedded original records. Whole-file hashes differ; recorded variant not located in inspected collections, cause unknown. Do not claim whole-file byte identity.'}
assert mismatch['f82_registration_sha256']=='0bb2e7a6198efc2e3db19800dd507c9a5ec91dc47c9fa388e612162d133f5bed'
out={'schema':'726-eidolon-native-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_059':records,'records_774':old,'registration_file_hash_mismatch':mismatch,'qualification':'Selected 059 extracted records match transport manifest size, SHA and Git blob; original payload Git path not found in inspected stores. Original native reviewers and Segovb scopes retain independent attribution. f82 transports records only; native 1a5 is not project Git. Historical 6533 working snapshot had unrelated modifications, not clean. No evidence is promoted to missing checkpoint 3821.'}
(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('references',len(refs),'059',len(records),'774',len(old))
