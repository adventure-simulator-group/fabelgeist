from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;raw=(b/'registration.json').read_bytes();reg=json.loads(raw);chunks={'2790':[[1,40],[41,80],[81,120],[121,160],[161,182]],'2791':[[1,28],[29,56],[84,112]],'2792':[[1,38],[39,76],[77,114],[115,152],[153,190],[191,226]],'2793':[[1,40],[41,80],[81,118]]};out=[]
for e in reg['entries']:
 ch=chunks[e['id']];have={i for a,z in ch for i in range(a,z+1)};miss=[];start=None
 for i in range(1,e['eof']+2):
  if i<=e['eof'] and i not in have and start is None:start=i
  elif (i>e['eof'] or i in have) and start is not None:miss.append([start,i-1]);start=None
 out.append({'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':miss,'qualification':'Exact pinned-native source personal display only; stored unread bytes confer no source credit.'})
(b/'read-receipt.json').write_text(json.dumps({'schema':'726-native-personal-read-receipt-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(raw).hexdigest(),'entries':out},indent=2)+'\n');print('recorded',len(out))
