# Native bevy_eidolon allocator roles 2790–2793

`REPORT.json` records the bounded thirteen perspectives, independent source
references, conditional observations, prior reviewer links and unresolved
questions. This packet is source/evidence only. It contains no implementation,
product validation, execution, build, test, simulation, rendering or probe.

Original assigned identity is bevy_eidolon 0.5.0 native Git commit
`1a5aff8d4809287e5f5713fb4cf72181b2285fff`, not a project Git revision. The
historical 6533 root lock identifies that commit. The pinned current project
revision is `95e63628f9d70b8dd6e6fede64334696c6995009`; the four enumerated
tracked lockfiles do not contain this package, without establishing feature,
target or runtime resolution. `f82adcabd9d89c4fa2dd7f99253a45297a0681ee`
transports exact historical bytes and is not the native source revision. The
original pr-working snapshot recorded unrelated changes. P16 and missing 3821
are not reconstructed or promoted by this packet.

`registration.json` prospectively declares assigned old native reads;
`read-receipt.json` records exact displayed chunks and unread complements.
`support-registration*.json` and `support-read-receipt.json` separate all
current, historical, native, shader-text and macro-text support from assigned
role credit. Full archived source bytes do not imply a full personal read.
`lock-registration.json` and `lock-inventory.json` record structural TOML
inventory separately from displayed source. `reset-navigation.json` records a
bounded literal search with its call-graph limitations.

`history/` retains the exact native Git bundle, original recovered registry and
transport manifest, selected 059 reviewer records, historical queue/ledger
summaries (losslessly compressed), selected exact 774 reviewer records and prior
central assessments. Files named `*-reconstructed.json` are mechanical
selections from retained originals, not original artifacts. Four selected 774
registration rows match their embedded original records, while the original
registry's recorded whole-file registration hash differs from the f82 file;
the cause is unknown and no byte-identity claim is made. Historical attributions
remain with their original readers, revisions, ranges and qualifications.

`git-proofs.json` and `git-objects/` retain raw compressed Git commit and tree
objects proving individual native, project and transport file identities plus
one exact current-tree path absence. Source bodies are retained separately.
`evidence-verification.json` records the evidence-only verifier result.
Run `python3 verify-evidence.py` and `python3 verify-manifest.py` from this
folder to recheck integrity; these scripts do not run product code.
