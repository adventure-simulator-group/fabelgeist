from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,subprocess,tomllib
b=Path(__file__).resolve().parent
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest()
load=lambda p:json.loads((b/p).read_bytes())
gun=lambda p:gzip.decompress((b/p).read_bytes())
history=load('historical-attribution.json');report=load('REPORT.json')
names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json']
groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
assert sha((b/'history/bevy-eidolon-native.bundle').read_bytes())=='904158b24f571f43447cf6991b0822dd5a82e5f5a5b453323c451ecd02125a2a'
heads=subprocess.check_output(['git','bundle','list-heads',str(b/'history/bevy-eidolon-native.bundle')]).decode();assert heads==(b/'history/native-bundle-heads.txt').read_text() and '1a5aff8d4809287e5f5713fb4cf72181b2285fff refs/heads/master' in heads
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2790,2791,2792,2793]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
for role,ranges in [(2790,[[1,182]]),(2791,[[1,56],[84,112]]),(2792,[[1,226]]),(2793,[[1,118]])]:
 x=regs[('registration.json',str(role))];assert x['sha256']==registry['files'][role]['sha256'] and x['prospective_personal_read_ranges']==registry['files'][role]['material_ranges']==ranges
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in sel['entries']]==[1313,1314,1315]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert [q[i]['contract_id'] for i in [1313,1314,1315]]==['Q-L12-20a23a4159ced0cd2f9e','Q-L12-e9e53f9be5de36951195','Q-L12-7b32c40b78bac228fc8a']
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
r=load('history/059/segovb/READ-L11-455.json')
for role,ranges in [(2790,[[1,182]]),(2791,[[1,56],[84,112]]),(2792,[[1,226]]),(2793,[[1,118]])]:
 e=next(x for x in r['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==ranges and e['sha256']==registry['files'][role]['sha256']
r=load('history/059/segovb/READ-L11-483.json');e=next(x for x in r['rows'] if x['overlay_index']==225);assert e['fresh_personal_body_reads']==[[228,230]] and e['reused_ranges']==[[1,226]] and e['source_id']==registry['files'][2792]['source_id']
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
path='history/774/native/initial05-aggregate-states/source-range-registration.jsonl.gz';raw=gun(path);rows=[json.loads(z) for z in raw.splitlines()]
assert sha(raw)==history['registration_file_hash_mismatch']['f82_registration_sha256'] and sha(raw)!=history['registration_file_hash_mismatch']['recorded_registry_registration_sha256']
for role in [2790,2791,2792,2793]:
 e=registry['files'][role]['scope_registration'][0];assert rows[e['row_1based']-1]==e['original_record']
quals=[json.loads(z) for z in gun('history/774/native/initial05-aggregate-states/source-qualifications.jsonl.gz').splitlines()];assert all(any(x.get('id')==i for x in quals) for i in ['NATIVE-INITIAL05-QUAL019','NATIVE-INITIAL05-QUAL020'])
group=json.loads(gun('history/774/native/initial05-aggregate-states/contract-groups-071.json.gz'));assert group['id']=='NATIVE-INITIAL05-GROUP-071'
assert any(json.loads(z).get('id')=='ROOT-INITIAL04-F053' for z in gun('history/774/root/initial04-invariant-operations/findings.jsonl.gz').splitlines())
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
assert proof['commits']['1a5aff8d4809287e5f5713fb4cf72181b2285fff']['namespace']=='native package Git' and proof['commits']['95e63628f9d70b8dd6e6fede64334696c6995009']['namespace']=='project Git'
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
for x in proof['absent_paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');chain=x['path_chain_to_parent']
 for name,s in zip(parts,chain):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 assert x['parent_tree']==cur and parts[len(chain)]==x['missing_segment'] and x['missing_segment'] not in entries(objects[cur])
assert len(proof['paths'])==50 and len(proof['absent_paths'])==1
coverage={}
def record(regname,id,chunks,unread,when,recorded_sha):
 x=regs[(regname,id)];assert datetime.fromisoformat(groups[regname]['at_utc'])<datetime.fromisoformat(when) and recorded_sha==x['sha256']
 actual={i for a,z in chunks for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in unread for i in range(a,z+1)}
 assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage.setdefault(id,set()).update(actual)
a=load('read-receipt.json');assert a['registration_sha256']==sha((b/'registration.json').read_bytes())
for e in a['entries']:record('registration.json',e['id'],e['actual_display_chunks'],e['unread_complement'],a['at_utc'],e['sha256'])
s=load('support-read-receipt.json')
for x in s['registrations']:assert x['sha256']==sha((b/x['path']).read_bytes())
for e in s['entries']:record(e['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
assert len(regs)==len(coverage)==30
assert coverage['2791'].isdisjoint(set(range(57,84))) and coverage['2792'].isdisjoint(set(range(227,263))) and coverage['native-writable-macro']=={228,229,230}
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(e['id']==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
lreg=load('lock-registration.json');linv=load('lock-inventory.json');assert linv['registration_sha256']==sha((b/'lock-registration.json').read_bytes()) and datetime.fromisoformat(lreg['at_utc'])<datetime.fromisoformat(linv['at_utc']);assert len(lreg['entries'])==len(linv['entries'])==8
for x,y in zip(lreg['entries'],linv['entries']):
 raw=(b/x['archive']).read_bytes();assert x['id']==y['id'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']==y['sha256'] and oid('blob',raw)==x['git_blob']
 doc=tomllib.loads(raw.decode());packages=doc.get('package',[]);matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in packages if p['name']=='bevy_eidolon'];consumers=[p['name'] for p in packages if any(a.split(' ',1)[0]=='bevy_eidolon' for a in p.get('dependencies',[]))];assert len(packages)==y['package_count'] and matches==y['matches'] and consumers==y['consumer_names']
 if x['revision'].startswith('95e'):assert matches==[]
old=next(x for x in linv['entries'] if x['id']=='6533e44:Cargo.lock');assert old['matches']==[{'name':'bevy_eidolon','version':'0.5.0','source':'git+https://github.com/barsoosayque/bevy_eidolon?branch=fablegeist-0.19#1a5aff8d4809287e5f5713fb4cf72181b2285fff','checksum':None}] and 'adventuresim-tactical-client' in old['consumer_names']
print(json.dumps({'status':'PASS','registered_personal_scopes':len(regs),'assigned_native_roles':[2790,2791,2792,2793],'native_unread_role_complements':{'2791':[[57,83]],'2792':[[227,262]]},'separately_read_support_only':{'2792':[[228,230]]},'historical_059_records_manifest_matched':len(history['records_059']),'historical_774_records_git_proved':len(history['records_774']),'registration_whole_file_mismatch':'preserved; four selected rows match','git_path_proofs':len(proof['paths']),'git_tree_absence_proofs':len(proof['absent_paths']),'native_git_bundle_head_verified':True,'locks_structurally_inventoried':len(lreg['entries']),'bounded_lenses':13,'feature_resolution':'not inferred','product_build_test_fixture_shader_execution_probe_validation':'not performed'},indent=2))
