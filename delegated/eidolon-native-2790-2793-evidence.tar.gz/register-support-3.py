from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;project='<LOCAL_PATH_0>';native='<LOCAL_PATH_1>';n='1a5aff8d4809287e5f5713fb4cf72181b2285fff';old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();(b/'support').mkdir(exist_ok=True)
spec=[('native-inputs','native',n,'src/render/prepare/mod.rs',[[106,226]]),('native-instance-type','native',n,'src/components.rs',[[35,75]]),('native-cull-wgsl','native',n,'src/cull/compute.wgsl',[[1,70]]),('native-updater-tail','native',n,'src/render/prepare/instance_buffer_updater.rs',[[131,152]])];rows=[]
for id,kind,rev,path,ranges in spec:
 repo=native if kind=='native' else project;r=subprocess.run(['git','-C',repo,'show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if r.returncode:print('UNAVAILABLE',id,path);continue
 d=r.stdout;eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/'+id+'.source';(b/dest).write_bytes(d);rows.append({'id':id,'kind':kind,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Separate support: native package, pr-working 6533 or current 95e as explicitly labeled; lock structural parse does not imply full body reading or resolved feature/runtime selection. WGSL/macro text only, never execute.'})
out={'schema':'726-eidolon-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'support-registration-3.json').write_text(json.dumps(out,indent=2)+'\n');print('registered',len(rows),'at',out['at_utc']);print([(x['id'],x['eof'],x['prospective_personal_read_ranges']) for x in rows])
