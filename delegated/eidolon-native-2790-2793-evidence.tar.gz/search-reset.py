from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
args=['git','-C',repo,'grep','-n','-E',r'(source_allocator|backend|batcher)[[:space:]]*\.reset\(','1a5aff8d4809287e5f5713fb4cf72181b2285fff','--','src']
r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==1 and r.stdout==b'' and r.stderr==b''
out={'schema':'726-literal-navigation-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','repository_kind':'native package, 1a5 commit, not project Git','arguments':args,'returncode':r.returncode,'stdout_utf8':r.stdout.decode(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_utf8':r.stderr.decode(),'qualification':'Literal same-line names only; cannot exclude aliases, other variable names, multiline expressions, external callers, generated or dynamic invocation. Search is navigation, not source body reading credit or resolved call graph.'}
(b/'reset-navigation.json').write_text(json.dumps(out,indent=2)+'\n')
