from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();rows=[]
for rev in ['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']:
 paths=subprocess.check_output(['git','-C',repo,'ls-tree','-r','--name-only',rev]).decode().splitlines();paths=[p for p in paths if p=='Cargo.lock' or p.endswith('/Cargo.lock')]
 for path in paths:
  d=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);dest='locks/'+rev[:7]+'/'+path;(b/dest).parent.mkdir(parents=True,exist_ok=True);(b/dest).write_bytes(d);rows.append({'id':rev[:7]+':'+path,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':len(d.splitlines()),'planned_structural_parse':True,'qualification':'Whole lockfile structural inventory only, no personal body-read credit, cargo resolution, target or feature proof.'})
r={'schema':'726-prospective-lock-inventory-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'lock-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registered',len(rows),'at',r['at_utc'])
