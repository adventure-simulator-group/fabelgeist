#!/usr/bin/env python3
"""Verify preserved evidence, Git identities and read scopes only; no product execution."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');rc=load('personal-read-receipt.json');assert rc['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<rc['recorded_utc'] and len(rc['actual_displays'])==len(r['entries'])==4
for e,x in zip(r['entries'],rc['actual_displays']):
 d=(p/e['source_archive']).read_bytes();assert (sha(d),blob(d),len(d),len(d.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['source_archive']==e['source_archive'] and x['chunks']==e['planned_chunks'] and not x['unread_complement']
for role,rr in [(2702,[[1,132]]),(2703,[[1,173]])]:
 old,cur=[e for e in r['entries'] if e['original_index']==role];cmp=next(x for x in r['comparisons'] if x['original_index']==role);base=(p/cmp['base_archive']).read_bytes();assert old['original_material_ranges']==rr and old['sha256']==cur['sha256']==cmp['base_sha256']==sha(base) and old['git_blob']==cur['git_blob']==cmp['base_blob']==blob(base) and cmp['historical_equals_base'] and cmp['current_equals_historical'] and not cmp['status_porcelain']
checks.append('Four separate P16/current full assigned displays; original shorter material ranges and personally unread base copies retained')
scopes={}
for stem in ['support','gate','view-policy','fixture','review-views','pass']:
 sr=load(stem+'-registration.json');rc=load(stem+'-read-receipt.json');assert rc['registration_sha256']==sha((p/(stem+'-registration.json')).read_bytes()) and sr['registered_utc']<rc['recorded_utc'] and len(sr['entries'])==len(rc['actual_displays'])
 for e,x in zip(sr['entries'],rc['actual_displays']):
  d=(p/e['source_archive']).read_bytes();assert (sha(d),blob(d),len(d),len(d.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['displayed_chunks']==e['planned_chunks'] and x['source_archive']==e['source_archive'];scope=scopes.setdefault(e['source_archive'],set())
  for lo,hi in e['registered_ranges']:scope.update(range(lo,hi+1))
for file,e in load('read-scope-summary.json')['support'].items():
 actual={i for lo,hi in e['displayed_ranges'] for i in range(lo,hi+1)};unread={i for lo,hi in e['unread_complement'] for i in range(lo,hi+1)};assert actual==scopes[file] and not actual&unread and actual|unread==set(range(1,e['EOF']+1))
assert len(scopes)==6 and 'preceding' in load('registration-chronology-note.json')['qualification'];checks.append('Independently registered current support windows, exact unread complements and earlier separate read chronology')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['original_registry_sha256_uncompressed']==sha(raw)
for x in sel['rows']:assert x['entry']==reg['files'][x['original_index']]
snap=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert sel['physical_p16_snapshot']==snap and snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and sha((p/'reference/p16-tracked.patch').read_bytes())==snap['patch_sha256'] and len(snap['status_porcelain'])==159
assert sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));entries={x['path']:x for x in manifest['entries']};history=load('historical-index.json');assert sum(x['kind']=='original-059' for x in history['records'])==17 and sum(x['kind']=='historical-774' for x in history['records'])==4
for x in history['records']:
 d=(p/x['file']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (len(d),sha(d),blob(d))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
assert not any('segovb/'+t+'-L12-939.json' in entries for t in ['READ','VERIFY','STATE']) and len(load('recovery-search.json')['roots'])==2
checks.append('Original dirty P16 registry, later tracked patch, 059/774 identities and bounded 939 adoption search')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];d=gzip.decompress((p/x['archive']).read_bytes());assert (len(d),sha(d),hashlib.sha1(x['type'].encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest())==(x['bytes'],x['sha256'],oid);return d
def trees(d):
 out={};i=0
 while i<len(d):
  s=d.index(b' ',i);z=d.index(b'\0',s);out[d[s+1:z].decode()]=(d[i:s].decode(),d[z+1:z+21].hex());i=z+21
 return out
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==25
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 d=(p/x['archive']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (sha(d),blob(d),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Twenty-five raw Git tree proofs covering f82, P16 base, 039 catalog, 6533, 95e and prior support')
reg774=gzip.decompress((p/'history-774/root/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines();assert json.loads(reg774[42])['id']=='ROOT-ADMISSION03-REG-043' and json.loads(reg774[43])['id']=='ROOT-ADMISSION03-REG-044';rig=json.loads(gzip.decompress((p/'history-774/rig/admission03/dependency-reconciliation-113.json.gz').read_bytes()));assert next(x for x in rig['rows'] if x['dependency_id']=='capture_view_indices')['disposition']=='still_exact_unread_producer_obligation';groups=gzip.decompress((p/'history-774/rig/admission03/contract-groups.jsonl.gz').read_bytes()).splitlines();assert json.loads(groups[796])['id']=='RIG-ADMISSION03-CONTRACT-797'
l11=load('history-059/segovb/READ-L11-441.json')
for role,rr in [(2702,[[1,132]]),(2703,[[1,173]])]:assert next(x for x in l11['sources'] if x['original_index']==role)['fresh_personal_body_reads']==rr
adler=load('history-059/adler/READ-L11-247.json');assert next(x for x in adler['sources'] if x['original_index']==1704)['fresh_reads']==[[1,200],[201,373]];s12=load('history-059/segovb/READ-L12-545.json');assert next(x for x in s12['rows'] if x['original_index']==1704)['fresh_personal_body_reads']==[[1,373]]
for role,num,rr in [(2702,1,[[1,132]]),(2703,2,[[1,173]])]:
 pp=load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-939-{num:03d}.json');row=next(x for x in pp['rows'] if x['original_index']==role);assert row['fresh_personal_body_reads']==rr and '/root/lens12_frontier' in row['attribution']
assert 'root adoption required' in load('history-059/parallel-l12-20261029/PROPOSAL-L12-939.json')['kind'];checks.append('774 prospective registrations and Rig unread dependency; distinct 059 fresh/reused-role scopes and 939 proposal')
prior=load('prior-readiness-index.json');m=(p/'prior-readiness/BUNDLE-MANIFEST.json').read_bytes();assert sha(m)==prior['manifest_sha256']=='95ed71a5988513740f514a84a612af4b6f057ec22f1cac3def9524cf7be06e5a';idx={x['path']:x for x in json.loads(m)['files']}
for x in prior['selected_records']:
 d=(p/x['file']).read_bytes();e=idx[x['prior_member']];assert (sha(d),len(d))==(x['sha256'],x['bytes'])==(e['sha256'],e['bytes'])
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert queue['entries'][int(n)]==e
for x in load('prior-evidence-index.json')['records']:
 d=(p/x['preserved_bytes']).read_bytes();assert (sha(d),len(d))==(x['sha256'],x['bytes'])
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
assert {x['number'] for x in load('report.json')['lenses']}==set(range(1,14));checks.append('Prior readiness manifest-selected evidence, reconstructed queue, prior assessments, rules and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and read accounting only; no product validation, viewer, fixture, test, runtime probe, execution, implementation, checkpoint3821 promotion or inferred 939 adoption.'},indent=2))
