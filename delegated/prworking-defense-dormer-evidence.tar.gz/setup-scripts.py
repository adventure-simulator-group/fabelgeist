import pathlib
p=pathlib.Path('<LOCAL_PATH_0>');old=pathlib.Path('<LOCAL_PATH_1>')
s=(old/'build-proof.py').read_text().replace(str(old),str(p));s=s.replace("names=['support-registration.json','support-registration-02.json']","names=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json']");a=s.index('arch=[]');b=s.index(';d=p/\'git-objects\'',a);s=s[:a]+"arch=[]\nrecords=reg['sources']+support+arch"+s[b:];s=s.replace('f82 is transport, a120 recorded base, current 95e authoritative; equality holds individually and never identifies the whole dirty P16 snapshot with clean a120.', '6533 is the recorded pr-working HEAD and 95e is current; per-file equality does not identify the entire historical modified working snapshot with clean HEAD.').replace('historical/current body displays are new source assessment, never claim historical reviewer credit or checkpoint3821.', 'historical/current body displays are new source assessment, never claim historical reviewer credit or checkpoint3821.')
a=s.index('ranges={');b=s.index('\ndef complement(',a)
s=s[:a]+'''ranges={0:[[1,80],[175,215]],1:[[1,163]],2:[[410,470]],3:[[1,78]],4:[[1,140]],5:[[140,210]],6:[[140,180],[200,290]],7:[[65,100],[260,305]],8:[[1,100]],9:[[1,140]],10:[[1,100]],11:[[1,265]],12:[[1,66]],13:[[140,220]],14:[[1,68]],15:[[1,46]]}
# The registered rg displayed matching navigation lines; include their exact singleton exposures.
import re
pattern=r'DormerLayout::new|walk_junction_centre\\(|projected_solid\\(|seam_depth\\(|roof_surface_height_at\\(|struct RoofDormer|struct RoofAssembly|fn audit_plan'
nav={}
for i in range(9):
 lines=(p/f'source/support-{i:02}.source').read_text().splitlines();matches=[n for n,line in enumerate(lines,1) if re.search(pattern,line)];nav[str(i)]=matches
 spans=sorted(ranges[i]+[[n,n] for n in matches]);merged=[]
 for a,b in spans:
  if merged and a<=merged[-1][1]+1:merged[-1][1]=max(b,merged[-1][1])
  else:merged.append([a,b])
 ranges[i]=merged
(p/'navigation-exposures.json').write_text(json.dumps({'qualification':'Actual post-registration rg matching lines, included in read scopes but not full-body/function credit.','lines_by_support_index':nav},indent=2)+'\\n')
''' +s[b:];(p/'build-proof.py').write_text(s)
s=(old/'copy-evidence.py').read_text().replace(str(old),str(p));a=s.index('names=[');b=s.index('\nrows=[]',a);names=['segovb/READ-L11-419.json','segovb/REGISTRATION-SEGOVB-1440.json','segovb/REGISTRATION-SEGOVB-1441.json','segovb/READ-L12-860.json','parallel-l12-20261029/PROPOSAL-L12-860.json','parallel-l12-20261029/REGISTRATION-PAR-L12-565.json','parallel-l12-20261029/REGISTRATION-PAR-L12-566.json'];s=s[:a]+'names='+repr(names)+s[b:];s=s.replace('inds=[49,65,563,588,1300,1399,1936,1939,1940,2107,2244,2251,2252,2303,2359,2705]','inds=[582,583,592,639,1931,2107,2258,2259]').replace('[2519,2520]','[2534,2535]').replace("cpaths=['rig/owner-reached-producer-followup/findings.jsonl','rig/initial06-type-ownership/coverage.jsonl','owner-range-extensions.jsonl']","cpaths=['native/root-roof-producer-followup/findings.jsonl','owner-range-extensions.jsonl']").replace('Standalone rig producer registration and qualification files','Standalone native roof producer registration and qualification files');(p/'copy-evidence.py').write_text(s)
s=(old/'check-evidence.py').read_text().replace(str(old),str(p)).replace("ns=['support-registration.json','support-registration-02.json']","ns=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json']").replace('[2519,2520]','[2534,2535]');a=s.index("r=json.load(gzip.open(p/'reference/original-registry.json.gz'");b=s.index('\nold=json.loads',a);s=s[:a]+'''r=json.load(gzip.open(p/'reference/original-registry.json.gz','rt'));assert r['snapshots'][0]==reg['historical_snapshot'];assert r['snapshots'][0]['head']=='6533e444fa37552927070cc8d8190907fd3b413e';assert r['snapshots'][0]['status_porcelain']
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']: assert x['entry']==r['files'][x['index']]
for i in [2534,2535]:
 a=[z for z in reg['sources'] if z['original_role']==i];assert len(a)==2 and a[0]['sha256']==a[1]['sha256']==r['files'][i]['sha256'] and a[0]['head_path_bytes_equal'];assert (p/a[0]['archive']).read_bytes()==(p/a[1]['archive']).read_bytes()
''' +s[b:];s=s.replace("Registry-recorded patch hash not verified against patch bytes; no product validation or execution.","Per-file equality to recorded 6533 does not prove the historical working snapshot clean; no product validation or execution.");(p/'check-evidence.py').write_text(s)
