import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());names=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json'];support=[x for n in names for x in json.loads((p/n).read_text())['sources']];arch=[]
records=reg['sources']+support+arch;d=p/'git-objects';d.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=d/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();assert tree==x['git_blob_sha1'];assert hashlib.sha256(b).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'kind':x['kind'],'revision':rev,'path':x['path'],'archive':x['archive'],'commit_tree':root,'chain':chain,'blob':tree})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw Git commit/tree objects and archived exact bytes prove path membership only: 6533 is the recorded pr-working HEAD and 95e is current; per-file equality does not identify the entire historical modified working snapshot with clean HEAD.','objects':objects,'proofs':proof},indent=2)+'\n')
rows=[]
for x in reg['sources']:
 rows.append({'role':x['original_role'],'kind':x['kind'],'revision':x['revision'],'path':x['path'],'archive':x['archive'],'actual_display_ranges':x['planned_display_chunks'],'actual_display_union':[[1,x['lines']]],'unread_ranges':[],'full_body_displayed':True,'planned_deviation':'none'})
(p/'read-receipt.json').write_text(json.dumps({'schema':'726-assigned-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest(),'reads':rows,'qualification':'Full listed assigned historical/current body displays are new source assessment, never claim historical reviewer credit or checkpoint3821.'},indent=2)+'\n')
ranges={0:[[1,80],[175,215]],1:[[1,163]],2:[[410,470]],3:[[1,78]],4:[[1,140]],5:[[140,210]],6:[[140,180],[200,290]],7:[[65,100],[260,305]],8:[[1,100]],9:[[1,140]],10:[[1,100]],11:[[1,265]],12:[[1,66]],13:[[140,220]],14:[[1,68]],15:[[1,46]]}
# The registered rg displayed matching navigation lines; include their exact singleton exposures.
import re
pattern=r'DormerLayout::new|walk_junction_centre\(|projected_solid\(|seam_depth\(|roof_surface_height_at\(|struct RoofDormer|struct RoofAssembly|fn audit_plan'
nav={}
for i in range(9):
 lines=(p/f'source/support-{i:02}.source').read_text().splitlines();matches=[n for n,line in enumerate(lines,1) if re.search(pattern,line)];nav[str(i)]=matches
 spans=sorted(ranges[i]+[[n,n] for n in matches]);merged=[]
 for a,b in spans:
  if merged and a<=merged[-1][1]+1:merged[-1][1]=max(b,merged[-1][1])
  else:merged.append([a,b])
 ranges[i]=merged
(p/'navigation-exposures.json').write_text(json.dumps({'qualification':'Actual post-registration rg matching lines, included in read scopes but not full-body/function credit.','lines_by_support_index':nav},indent=2)+'\n')

def complement(rr,n):
 out=[];k=1
 for a,b in rr:
  if k<a:out.append([k,a-1])
  k=b+1
 if k<=n:out.append([k,n])
 return out
reads=[]
for i,x in enumerate(support):
 rr=ranges[i];assert all(1<=a<=b<=x['lines'] for a,b in rr);reads.append({'path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':complement(rr,x['lines']),'full_body_displayed':sum(b-a+1 for a,b in rr)==x['lines'],'planned_deviation':'Selected windows only; unopened lines remain unread, including test sources where applicable.'})
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'path':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in names],'reads':reads,'qualification':'Prospective permission for wider support body does not imply display; exact printed windows and unread complement above. All support bodies were prospectively registered; incidental navigation matches are within the recorded windows. No ordered-role credit. Test text shown only, never run.'},indent=2)+'\n');print('git proofs',len(proof),'objects',len(objects),'assigned',len(rows),'support',len(reads))
