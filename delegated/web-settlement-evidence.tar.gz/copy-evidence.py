import gzip,hashlib,json,pathlib,shutil
p=pathlib.Path('<LOCAL_PATH_0>');orig=pathlib.Path('<LOCAL_PATH_1>');prior=pathlib.Path('<LOCAL_PATH_2>');refs=p/'reference';refs.mkdir(exist_ok=True);h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
for n in ['059-queue-original-bytes.json.gz','original-transport-manifest.json.gz','original-registry.json.gz']:shutil.copyfile(prior/'reference'/n,refs/n)
for n in ['AGENTS.md','crates/AGENTS.md','crates/strategic-web/AGENTS.md']:
 d=refs/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(prior/'reference'/n,d)
shutil.copyfile(prior/'rules-evidence.json',p/'rules-evidence.json');shutil.copyfile(prior/'older-774-export-manifest.json',p/'older-774-export-manifest.json')
t={x['path']:x for x in json.load(gzip.open(refs/'original-transport-manifest.json.gz','rt'))['entries']};names=[]
for i in [379,380,384,386]:
 for v in ['READ','STATE','VERIFY']:names.append(f'adler/{v}-L11-{i}.json')
for i in [1243,1252]:names.append(f'adler/REGISTRATION-ADLER-{i}.json')
for i in [787,793]:
 for v in ['READ','STATE','VERIFY']:names.append(f'segovb/{v}-L12-{i}.json')
 names.extend([f'segovb/REGISTRATION-SEGOVB-L12-{i}.json',f'parallel-l12-20261029/PROPOSAL-L12-{i}.json'])
for i in [358,374]:names.append(f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json')
for i in ['007','008']:
 names.extend([f'segovb/READ-L12-CONNECTED-TEAM-{i}.json',f'parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-CONNECTED-TEAM{i}.json'])
names+=['parallel-l12-20261029/REGISTRATION-PAR-L12-360-CONNECTED-CAMP-DECLARATIONS.json','parallel-l12-20261029/REGISTRATION-PAR-L12-363-CONNECTED-CAMP-OWNER.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-787-CAMP-APPEARANCE-OWNERS.json','parallel-l12-20261029/REGISTRATION-PAR-L12-375-CONNECTED-SERVICE-LIVING-CLOSURE.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-793-SERVICE-LIVING-CLOSURE.json']
rows=[];missing=[]
for n in names:
 if n not in t or not (orig/n).is_file():missing.append(n);continue
 b=(orig/n).read_bytes();e=t[n];assert (len(b),h(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']),n;dest=p/'historical-059'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append({'original_path':n,'copy':str(dest.relative_to(p)),'bytes':len(b),'sha256':h(b),'git_blob':blob(b)})
q=json.load(gzip.open(refs/'059-queue-original-bytes.json.gz','rt'));inds=[179,181,191,*range(501,511),2452];(p/'historical-queue-selected.json').write_text(json.dumps({'qualification':'Derived navigation subset, original 059 queue remains exact and separate; no checkpoint3821 or scope credit.','entries':[{'index':i,'entry':q['entries'][i]} for i in inds]},indent=2)+'\n')
r=json.load(gzip.open(refs/'original-registry.json.gz','rt'));(p/'historical-registry-selected.json').write_text(json.dumps({'qualification':'Derived navigation subset; preserve original scopes and attribution.','roles':[{'index':i,'entry':r['files'][i]} for i in [2374,2382]]},indent=2)+'\n')
(p/'historical-059-index.json').write_text(json.dumps({'records':rows,'unavailable':missing,'qualification':'Exact copies from read-only extraction, validated against original transport. No status or reviewer promotion.'},indent=2)+'\n')
o=json.loads((prior/'older-774-index.json').read_text());trace=next(x for x in o['records'] if 'producer-supplement-after-owner/rig/traces.jsonl' in x['path'])
for n in [trace['original_copy'],trace['normalized_copy']]:
 d=p/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(prior/n,d)
(p/'older-774-index.json').write_text(json.dumps({'qualification':'Original rig producer trace and separately path-normalized export preserved and manifest verified; no newer status, other-lens credit, or repair-owner transfer.','records':[trace]},indent=2)+'\n');print('historical',len(rows),'missing',missing)
