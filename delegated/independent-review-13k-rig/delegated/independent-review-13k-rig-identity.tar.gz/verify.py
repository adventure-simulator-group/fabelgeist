#!/usr/bin/env python3
"""Read-only integrity and attribution checks for this bounded source review."""
from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile
P = Path(__file__).resolve().parent
read = lambda p: (P / p).read_bytes()
load = lambda p: json.loads(read(p))
sha = lambda b: hashlib.sha256(b).hexdigest()

def obj_id(kind, body):
    return hashlib.sha1(kind.encode() + b' ' + str(len(body)).encode() + b'\0' + body).hexdigest()

def tree_entries(b):
    result = {}
    i = 0
    while i < len(b):
        j = b.index(b'\0', i)
        mode, name = b[i:j].split(b' ', 1)
        assert j + 21 <= len(b)
        key = name.decode()
        assert key not in result
        result[key] = (mode.decode(), b[j + 1:j + 21].hex())
        i = j + 21
    assert i == len(b)
    return result

manifest = load('MANIFEST.json')
assert manifest['schema'] == '726-independent-13k-review-manifest-v1'
actual = {str(x.relative_to(P)) for x in P.rglob('*') if x.is_file()} - {'MANIFEST.json'}
assert actual == set(manifest['files'])
for name, identity in manifest['files'].items():
    b = read(name)
    assert sha(b) == identity['sha256'] and len(b) == identity['bytes'], name

index = load('inputs/central-proof-index.json')
archive = read('inputs/central-proof.tar.gz')
assert len(archive) == index['bytes'] and sha(archive) == index['sha256']
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
    members = tar.getmembers()
    assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members)
    bodies = {m.name: tar.extractfile(m).read() for m in members}
    assert len(bodies) == len(members)
proof = json.loads(bodies['proof.json'])
objects = {}
for oid, item in proof['objects'].items():
    body = bodies[item['archive']]
    assert len(body) == item['bytes'] and sha(body) == item['sha256'] and obj_id(item['type'], body) == oid
    objects[oid] = body
assert set(bodies) == {'proof.json'} | {item['archive'] for item in proof['objects'].values()}
reg = load('inputs/central-registration.json')
receipt = load('inputs/central-receipt.json')
assert sha(read('inputs/central-registration.json')) == receipt['registration_sha256']
assert receipt['registration'] == 'registration.json'  # Staging name; published mapping in assessment.
assert len(proof['paths']) == index['paths'] == len(reg['rows']) == len(receipt['reads']) == 12
assert len(objects) == index['objects'] == 23
for chain, row, r in zip(proof['paths'], reg['rows'], receipt['reads']):
    assert (chain['path'], chain['revision'], chain['blob'], chain['sha256']) == (row['path'], row['revision'], row['git_blob'], row['sha256'])
    assert all(row[k] == r[k] for k in ('revision','path','git_blob','sha256'))
    assert row['planned_display_ranges'] == r['actual_display_ranges']
    assert objects[chain['revision']].splitlines()[0] == b'tree ' + chain['root_tree'].encode()
    root = chain['root_tree']
    names = []
    for link in chain['chain']:
        assert link['tree'] == root
        assert tree_entries(objects[root])[link['name']] == (link['mode'],link['object'])
        names.append(link['name'])
        root = link['object']
    assert names == chain['path'].split('/') and root == chain['blob']
    assert sha(objects[root]) == chain['sha256'] and len(objects[root]) == chain['bytes']
    assert len(objects[root].splitlines()) == row['actual_eof']
    assert all(1 <= lo <= hi <= row['actual_eof'] for lo,hi in row['planned_display_ranges'])
assessment = load('inputs/assessment.json')
assert assessment['central_display_evidence'][0]['registration'] == 'CENTRAL-13K-REGISTRATION.json'
assert assessment['source_references'] == [{'revision':x['revision'],'path':x['path'],'lines':x['planned_display_ranges']} for x in reg['rows']]

mine = load('REGISTRATION.json'); supplement = load('SUPPLEMENT-REGISTRATION.json'); myreceipt = load('READ-RECEIPT.json')
assert sha(read('REGISTRATION.json')) == myreceipt['registration_sha256']
assert sha(read('SUPPLEMENT-REGISTRATION.json')) == myreceipt['supplement_registration_sha256']
assert datetime.datetime.fromisoformat(mine['registered_utc']) <= datetime.datetime.fromisoformat(myreceipt['recorded_utc'])
assert datetime.datetime.fromisoformat(supplement['registered_utc']) <= datetime.datetime.fromisoformat(myreceipt['recorded_utc'])
supplement_rows = {x['id']:x for x in supplement['rows']}
assert len(mine['rows']) == len(myreceipt['rows']) == 10 and len(supplement_rows) == 3
for a,b in zip(mine['rows'],myreceipt['rows']):
    body = read(a['file'])
    assert sha(body) == a['sha256'] and obj_id('blob', body) == a['blob'] and body == objects[a['blob']]
    assert a['revision'] == '95e63628f9d70b8dd6e6fede64334696c6995009'
    assert (a['id'],a['revision'],a['path'],a['sha256']) == (b['id'],b['revision'],b['path'],b['sha256'])
    assert a['planned_ranges'] == b['actual_display_ranges']
    s = supplement_rows.get(a['id'])
    assert b['supplement_actual_display_ranges'] == (s['planned_ranges'] if s else [])
    if s:
        assert all(s[k] == a[k] for k in ('id','path','revision','blob','sha256','file','eof'))
    actual_lines = set()
    for lo, hi in b['actual_display_ranges'] + b['supplement_actual_display_ranges']:
        assert 1 <= lo <= hi <= a['eof']
        actual_lines.update(range(lo,hi+1))
    unread = {line for lo,hi in b['unread_complement_after_both'] for line in range(lo,hi+1)}
    assert actual_lines.isdisjoint(unread) and actual_lines | unread == set(range(1,a['eof']+1))

for name in ('BASELINE-95E-20261110.json','RECONCILIATION-059.json','COVERAGE-L01-ROLES.json','baseline-head.json'):
    b = gzip.decompress(read('inputs/' + name + '.gz'))
    assert sha(b) == read('inputs/' + name + '.sha256').decode().strip()
baseline = json.loads(gzip.decompress(read('inputs/BASELINE-95E-20261110.json.gz')))
head = json.loads(gzip.decompress(read('inputs/baseline-head.json.gz')))
ident = 'local-candidate-garment-tube-kind-admission'
rows = [x for x in baseline['newly_assessed_ledger']['entries'] if x.get('id') == ident]
assert len(rows) == 1 and not [x for x in head['newly_assessed_ledger']['entries'] if x.get('id') == ident]
assert rows[0]['repair'] == 'not started' and rows[0]['validation'] == 'not performed'
coverage = json.loads(gzip.decompress(read('inputs/COVERAGE-L01-ROLES.json.gz')))
assert [coverage['roles'][i]['status'] for i in (2623,2624)] == ['unassessed','unassessed']
original_queue_bytes = gzip.decompress(read('inputs/original-059-queue.json.gz'))
assert sha(original_queue_bytes) == '2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'
q = json.loads(original_queue_bytes)['entries'][1818]
assert load('inputs/q1818-reconstructed.json')['entry'] == q
assert q['contract_id'] == 'Q-L12-ae99db0adb61f27b6ebb' and q['status'] == 'open-evidence-or-disposition'
assert q['body_or_population_credit'] == 0 and q['source_context_link_is_contract_identity_proof'] is False
reconciled = json.loads(gzip.decompress(read('inputs/RECONCILIATION-059.json.gz')))['entries'][1818]
assert reconciled['contract_id'] == q['contract_id'] and reconciled['historical_status'] == q['status']
prior = load('inputs/earlier-candidate-report.json')
assert prior['author'] == '/root/mhr_character' and any(x.get('id') == ident for x in prior['candidate_findings'])
assert load('inputs/prior-report.json')['author'] == '/root/rig_identity'
assert load('inputs/historical-059-read-L12-897.json')['rows'][0]['attribution'].startswith('Subagent /root/lens12_frontier')
additions = [json.loads(x) for x in gzip.decompress(read('inputs/historical-774-additional-contracts.jsonl.gz')).splitlines()]
assert {x['id'] for x in additions}.issuperset({'RIG-ADMISSION03-ADDITIONAL-072','RIG-ADMISSION03-ADDITIONAL-073'})
groups = [json.loads(x) for x in gzip.decompress(read('inputs/historical-774-contract-groups.jsonl.gz')).splitlines()]
assert any(x['id'] == 'RIG-ADMISSION03-CONTRACT-610' for x in groups)
print('Verified frozen file manifest, 12 central commit/tree/blob paths, registered ranges, selected prior provenance, 059 q1818, working/head distinction and nonclosure. This verifies evidence integrity, not the truth of a personal-read claim or product behavior.')
