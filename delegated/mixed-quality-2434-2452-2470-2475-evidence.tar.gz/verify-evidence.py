from pathlib import Path
from collections import Counter
from datetime import datetime
import gzip,hashlib,json,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();j=lambda p:json.loads((b/p).read_bytes());reg=j('registration.json');receipt=j('read-receipt.json');report=j('REPORT.json');history=j('historical-attribution.json');proof=j('git-proofs.json');inventory=j('structural-inventory.json');byid={e['id']:e for e in reg['entries']};rbyid={e['id']:e for e in receipt['reads']}
def u(ranges):
 out=[]
 for a,z in sorted(ranges):
  assert 1<=a<=z
  if out and a<=out[-1][1]+1:out[-1][1]=max(out[-1][1],z)
  else:out.append([a,z])
 return out
def complement(rs,n):
 out=[];i=1
 for a,z in u(rs):
  if i<a:out.append([i,a-1])
  i=z+1
 if i<=n:out.append([i,n])
 return out
assert receipt['registration_sha256']==sha((b/'registration.json').read_bytes());assert datetime.fromisoformat(reg['at_utc'])<=datetime.fromisoformat(receipt['recorded_utc']);assert len(byid)==8==len(rbyid)
for id,e in byid.items():
 d=(b/e['archive']).read_bytes();r=rbyid[id];assert len(d)==e['bytes'] and sha(d)==e['sha256'] and oid('blob',d)==e['git_blob'] and len(d.splitlines())==e['eof'];assert r['revision']==e['revision'] and r['sha256']==e['sha256'] and r['eof']==e['eof'];assert u(r['actual_display_chunks'])==r['actual_display_union']==u(e['prospective_personal_read_ranges']);assert complement(r['actual_display_union'],e['eof'])==r['unread_complement']
refs=[]
for part in ('observations','nonfindings'):
 for item in report[part]:refs.extend(item.get('source_refs',[]))
for x in refs:
 e=byid[x['id']];r=rbyid[x['id']];assert x['path']==e['git_path'] and x['revision']==e['revision'] and x['sha256']==e['sha256'] and x['archive']==e['archive']
 for a,z in x['lines']:assert any(a>=p and z<=q for p,q in r['actual_display_union']),(x['id'],a,z)
assert len(report['thirteen_bounded_perspectives'])==13
for e in j('base-comparisons.json')['entries']:
 d=(b/e['archive']).read_bytes();assert len(d)==e['bytes'] and sha(d)==e['sha256']==e['expected_sha256_from_registry_or_historical_role'] and oid('blob',d)==e['git_blob']
assert (b/'sources/comparison-1.rs').read_bytes()==(b/'sources/2452-current.rs').read_bytes();assert (b/'sources/comparison-4.toml').read_bytes()==(b/'sources/2434-historical.toml').read_bytes()
for r in history['references']:
 d=(b/r['archive']).read_bytes();raw=gzip.decompress(d);assert sha(d)==r['sha256'] and len(d)==r['bytes'] and sha(raw)==r['uncompressed_sha256'] and len(raw)==r['uncompressed_bytes']
original=json.loads(gzip.decompress((b/'historical/original-registry.json.gz').read_bytes()));assert sha(gzip.decompress((b/'historical/original-registry.json.gz').read_bytes()))=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';selected=j('historical/registry-selection-reconstructed.json')
for x in selected['rows']:
 i=x['original_index_zero_based'];assert x['record']==original['files'][i];e=byid[str(i)+'-historical'];assert e['sha256']==x['record']['sha256'] and e['git_path']==x['record']['path']
transport=json.loads(gzip.decompress((b/'historical/original-transport-manifest.json.gz').read_bytes()));ti={x['path']:x for x in transport['entries']}
for x in history['records_059']:
 d=(b/x['archive']).read_bytes();m=ti[x['original_path']];assert sha(d)==x['sha256']==m['sha256'] and len(d)==x['bytes']==m['bytes'] and oid('blob',d)==x['git_blob']==m['git_blob']
for x in history['records_774']:
 d=(b/x['archive']).read_bytes();raw=gzip.decompress(d);assert sha(d)==x['sha256'] and len(d)==x['bytes'] and sha(raw)==x['uncompressed_sha256'] and len(raw)==x['uncompressed_bytes'] and oid('blob',raw)==x['git_blob']
for x in history['patch_reproductions']:
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']==x['registered_sha256'];assert proof['commits'][x['head']]['parent_objects']==[x['base']]
q=json.loads(gzip.decompress((b/'historical/baseline-059-queue.json.gz').read_bytes()))['entries']
for x in j('historical/queue-selection-reconstructed.json')['rows']:assert x['record']==q[x['original_index_zero_based']]
for entry in history['prior_packets']:
 mcopy=next(x for x in entry['copies'] if x['source_name'].endswith('MANIFEST.json') or x['source_name']=='packet-manifest.json');assert mcopy['sha256']==entry['manifest_sha256'];m=j(mcopy['archive']);mi={x['path']:x for x in m['files']}
 for x in entry['copies']:
  data=(b/x['archive']).read_bytes();assert len(data)==x['bytes'] and sha(data)==x['sha256']
  if x is not mcopy:assert mi[x['source_name']]['sha256']==x['sha256']
for z in j('incident.json')['entries']:
 old=(b/z['original_copy']).read_bytes();new=(b/z['altered_copy']).read_bytes();assert sha(old)==z['old_recorded_sha256'] and sha(new)==z['new_sha256'] and len(old)==z['old_recorded_bytes'] and len(new)==z['new_bytes'];assert len(z['read_only_manifest_recheck_mismatches'])==1
objects={}
for ident,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved_bytes']).read_bytes());assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==ident;objects[ident]=(x['type'],raw)
def tree(raw):
 out={};i=0
 while i<len(raw):
  e=raw.index(b'\0',i);mode,name=raw[i:e].split(b' ',1);out[name.decode()]=(mode.decode(),raw[e+1:e+21].hex());i=e+21
 assert i==len(raw);return out
for rev,c in proof['commits'].items():
 typ,raw=objects[rev];assert typ=='commit' and raw.splitlines()[0].split()[1].decode()==c['root_tree'];assert [l.split()[1].decode() for l in raw.splitlines() if l.startswith(b'parent ')]==c['parent_objects']
for p in proof['paths']:
 d=(b/p['preserved_bytes']).read_bytes();d=gzip.decompress(d) if p['preserved_bytes'].endswith('.gz') else d;assert sha(d)==p['sha256'] and len(d)==p['bytes'] and oid('blob',d)==p['git_blob'];current=proof['commits'][p['revision']]['root_tree'];segs=p['path'].split('/');assert len(segs)==len(p['path_chain'])
 for seg,ch in zip(segs,p['path_chain']):
  assert ch['tree']==current and ch['name']==seg;typ,raw=objects[current];assert typ=='tree';mode,current=tree(raw)[seg];assert ch['mode']==mode and ch['object']==current
 assert current==p['git_blob']
for r in j('historical/774-selected-variant-comparison-reconstructed.json')['comparisons']:
 a=gzip.decompress((b/r['original_archive']).read_bytes());z=gzip.decompress((b/r['historical_export_archive']).read_bytes());assert (a==z)==r['whole_bytes_identical'];old=json.loads(a) if r['file'].endswith('sources.json') else [json.loads(l) for l in a.splitlines()];new=json.loads(z) if r['file'].endswith('sources.json') else [json.loads(l) for l in z.splitlines()]
 for x in r['rows']:
  i=x['zero_based_row'];assert old[i]==x['original'] and new[i]==x['historical_export'] and (old[i]==new[i])==x['rows_equal'];assert sorted(k for k in set(old[i])|set(new[i]) if old[i].get(k)!=new[i].get(k))==x['differing_top_level_keys']
for label,oldf,newf in [('baseline','2434-historical.toml','2434-current.toml'),('config','2475-historical.toml','2475-current.toml')]:
 old=tomllib.loads((b/'sources'/oldf).read_text());new=tomllib.loads((b/'sources'/newf).read_text());v=inventory[label]
 for k,n in v['old_counts'].items():assert len(old[k])==n
 for k,n in v['current_counts'].items():assert len(new[k])==n
 for key,delta in v['delta'].items():
  canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False);o=Counter(map(canon,old.get(key,[])));n=Counter(map(canon,new.get(key,[])));assert o-n==Counter(map(canon,delta['removed'])) and n-o==Counter(map(canon,delta['added']))
print(json.dumps({'schema':'726-source-evidence-verification-v1','status':'passed','source_objects':len(byid),'fresh_source_references':len(refs),'bounded_lenses':len(report['thirteen_bounded_perspectives']),'git_membership_paths':len(proof['paths']),'raw_git_objects':len(objects),'exact_059_records':len(history['records_059']),'historical_774_variant_records':len(history['records_774']),'patch_reproductions':len(history['patch_reproductions']),'incident_old_new_pairs':len(j('incident.json')['entries']),'qualification':'Read-only artifact hashing, generic TOML/JSON parsing, commit/tree/blob/path proof and source-coverage consistency only. No product execution, tests, builds, scanner, fixtures or runtime validation.'},indent=2))
