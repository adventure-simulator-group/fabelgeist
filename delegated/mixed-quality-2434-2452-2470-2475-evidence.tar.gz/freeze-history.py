from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).parent;pub=Path('<LOCAL_PATH_0>');ex=Path('<LOCAL_PATH_1>');previous=Path('<LOCAL_PATH_2>');rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);refs=[]
def save(d,p):
 f=b/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(d);return {'archive':p,'sha256':sha(d),'bytes':len(d)}
for source in ['original-registry.json.gz','original-transport-manifest.json.gz','baseline-059-queue.json.gz','baseline-059-ledger.json.gz']:
 data=(previous/source).read_bytes();raw=gzip.decompress(data);refs.append({'kind':'original older 059 full record, gzip compressed retention','source':str(previous/source),'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(data,'historical/'+source)})
registry=json.loads(gzip.decompress((b/'historical/original-registry.json.gz').read_bytes()));mi=json.loads(gzip.decompress((b/'historical/original-transport-manifest.json.gz').read_bytes()));index={x['path']:x for x in mi['entries']};queue=json.loads(gzip.decompress((b/'historical/baseline-059-queue.json.gz').read_bytes()))['entries'];ids=[2434,2452,2470,2475];(b/'historical/registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-historical-registry-selection-reconstructed-v1','qualification':'Mechanical selection from exact older registry; not checkpoint3821 and not a new reviewer record.','rows':[{'original_index_zero_based':i,'record':registry['files'][i]} for i in ids],'snapshots':[s for s in registry['snapshots'] if s['id'] in ('pr-working','rig-quality','report-p17')]},indent=2)+'\n')
qs=[165,460,562,565,637,1216,1231,1236,2940,3442];(b/'historical/queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-historical-queue-selection-reconstructed-v1','qualification':'Mechanical selection of original 059 queue entries, retaining their old statuses/reviewer; related not automatically aliases, no 3821 promotion.','rows':[{'original_index_zero_based':i,'record':queue[i]} for i in qs]},indent=2)+'\n')
paths=['segovb/READ-L11-402.json','segovb/REGISTRATION-SEGOVB-1323.json','segovb/READ-L12-819.json','parallel-l12-20261029/REGISTRATION-PAR-L12-443.json','parallel-l12-20261029/PROPOSAL-L12-819.json','parallel-l12-20261029/READ-INTERRUPTED-PAR-L12-819-ORIGINAL2434-TRUNCATED.json']+[f'segovb/READ-L11-402-PARTIAL-{i:03}.json' for i in range(1,7)]+[f'parallel-l12-20261029/READ-PARTIAL-PAR-L12-819-ORIGINAL2434-{i:03}.json' for i in range(1,10)]+['segovb/READ-L11-406.json','segovb/REGISTRATION-SEGOVB-1347.json','segovb/READ-L12-827.json','parallel-l12-20261029/REGISTRATION-PAR-L12-461.json','parallel-l12-20261029/READ-PARTIAL-PAR-L12-827-ORIGINAL2452-001.json','parallel-l12-20261029/PROPOSAL-L12-827.json','segovb/READ-L11-409.json','segovb/REGISTRATION-SEGOVB-1365.json','segovb/READ-L12-835.json','parallel-l12-20261029/REGISTRATION-PAR-L12-481.json','parallel-l12-20261029/READ-PARTIAL-PAR-L12-835-ORIGINAL2470-001.json','parallel-l12-20261029/PROPOSAL-L12-835.json','segovb/READ-L11-410.json','segovb/REGISTRATION-SEGOVB-1374.json','segovb/READ-L12-838.json','parallel-l12-20261029/REGISTRATION-PAR-L12-486.json','parallel-l12-20261029/READ-PARTIAL-PAR-L12-838-ORIGINAL2475-001.json','parallel-l12-20261029/PROPOSAL-L12-838.json']
old059=[]
for path in paths:
 data=(ex/path).read_bytes();m=index[path];assert len(data)==m['bytes'] and sha(data)==m['sha256'] and oid(data)==m['git_blob'],path;old059.append({'original_path':path,'git_blob':oid(data),**save(data,'historical/059/'+path)})
base='final-acceptance-20261021/wave-01/';old774=[]
paths774=[]
for variant,prefix in [('original','handoff/774/adler-original/audit/records/'),('historical-family-export','handoff/774/historical-family-execution/')]:
 for owner in ['root','native','rig']:
  for name in ['coverage.jsonl','contracts.jsonl']:
   paths774.append((variant,prefix+base+'audit-existing-type-owners/'+owner+'/'+name))
 paths774.append((variant,prefix+base+'audit-producer-propagation/rig/sources.json'))
paths774 += [('historical-operations-587','handoff/774/audit/reconcile-adler-20261023/audit-continuation/operations/contract-groups-587.json'),('historical-operations-592','handoff/774/audit/reconcile-adler-20261023/audit-continuation/operations/contract-groups-592.json'),('camera-original','handoff/774/adler-original/audit/continuation/camera/initial07-redundant-authority/findings.jsonl')]
for j,(variant,path) in enumerate(paths774):
 data=g('show',rev+':'+path);compressed=gzip.compress(data,mtime=0);old774.append({'variant':variant,'revision':rev,'transport_path':path,'uncompressed_sha256':sha(data),'uncompressed_bytes':len(data),'git_blob':oid(data),**save(compressed,f'historical/774/{j:02}-{Path(path).name}.gz')})
patches=[]
for tag,base,head,expected in [('p17','18360adba0fb43add88c75dfbd2f45d7e71d8ace','90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696','3c72c8c4f9816b49ae6306994d55571ceeff420b5a47bb5ff8bcec3c6668c9cd'),('rig','6533e444fa37552927070cc8d8190907fd3b413e','cbbbca08c89a8768926799371f54cf6057312e5e','6dcc1f6784b41bc1e76fd55bdd2f0c0b5083a5eb8ec18bcebd9519bdf4e869cf')]:
 data=g('diff',base,head);assert sha(data)==expected;assert g('rev-parse',head+'^').decode().strip()==base;patches.append({'kind':'independent read-only git diff <base> <head> reproduction','base':base,'head':head,'registered_sha256':expected,'qualification':'Exact matching digest and parent only; original invocation unknown; no patch-body personal display or present worktree cleanliness proof.',**save(data,'historical/'+tag+'-base-to-head-reproduced.patch')})
prior=[]
for name,dp,mn,rn,reads,archive in [('quality','<LOCAL_PATH_3>','MANIFEST.json','REPORT.json','personal-read-receipt.json',None),('p17-metrics','<LOCAL_PATH_4>','BUNDLE-MANIFEST.json','report.json','read-receipt.json','delegated/p17-metrics-evidence.tar.gz'),('rig-export','<LOCAL_PATH_5>','packet-manifest.json','report.json','read-receipt.json','delegated/rig-quality-export-hair-evidence.tar.gz')]:
 dp=Path(dp);md=(dp/mn).read_bytes();man=json.loads(md);files=man.get('files',[]);idx={x['path']:x for x in files};copies=[]
 for src in [mn,rn,reads]:
  data=(dp/src).read_bytes()
  if src!=mn:
   assert sha(data)==idx[src]['sha256'],(name,src)
  copies.append({'source_name':src,**save(data,'historical/prior/'+name+'/'+src)})
 record={'name':name,'original_dir':str(dp),'manifest_sha256':sha(md),'copies':copies,'qualification':'Prior agent report/read receipt retain original reviewer, revision and ranges; no read credit transferred.'}
 if archive:
  data=(pub/archive).read_bytes();record.update({'published_archive':archive,'published_archive_sha256':sha(data),'published_archive_bytes':len(data),'archive_qualification':'Published archive identity; content may have separately documented path redactions or incidents. Do not infer byte-identical to an untouched local packet.'})
 prior.append(record)
(b/'historical-attribution.json').write_text(json.dumps({'schema':'726-mixed-quality-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_059':old059,'records_774':old774,'patch_reproductions':patches,'prior_packets':prior,'qualification':'059/774 are recovered history; f82 transports recovered bytes, not source revision. Reconstructed selections and independently reproduced patch streams are distinct from original records. No promotion to checkpoint3821.'},indent=2)+'\n');print('old059',len(old059),'old774',len(old774),'patches',[(x['kind'],x['sha256']) for x in patches])
