from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';rows=[]
for path in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-character-creator/AGENTS.md']:
 d=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);dest='rules/'+path.replace('/','__');(b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(d);rows.append({'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'qualification':'Exact pinned rule bytes retained for context; no new personal read credit asserted. User-provided rules independently govern this task.'})
(b/'rules-index.json').write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows},indent=2)+'\n')
