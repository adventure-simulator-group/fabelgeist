from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=g('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev,'parent_objects':[x.split()[1].decode() for x in c.splitlines() if x.startswith(b'parent ')]}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();raw=gzip.decompress(raw) if body.endswith('.gz') else raw;cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur,(rev,path);proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for x in json.loads((b/'registration.json').read_bytes())['entries']:
 proof(x['revision'],x['git_path'],x['archive'],'exact personally registered old or 95e source bytes; source display remains receipt bounded')
 if x['kind']=='historical':proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],x['archive'],'historical recovered-object transport, not source revision')
for x in json.loads((b/'base-comparisons.json').read_bytes())['entries']:proof(x['revision'],x['git_path'],x['archive'],'registered byte-comparison object only; no display credit')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(f82,x['transport_path'],x['archive'],'retained original or separate historical-family 774 transport')
for x in json.loads((b/'rules-index.json').read_bytes())['entries']:proof(x['revision'],x['git_path'],x['archive'],'pinned contextual rule source; no new personal read credit')
out={'schema':'726-mixed-quality-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Individual Git commit/tree/blob memberships only. f82 transports frozen historical objects, it is not a source revision. 059 original evidence is verified against its own retained lossless transport manifest; payload commit itself is not present in publication object store. No worktree status or product validation inferred.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('proofs',len(proofs),'raw commits/trees',len(objects))
