from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,tomllib,hashlib
b=Path(__file__).parent
load=lambda n:tomllib.loads((b/'sources'/n).read_text())
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def arraydelta(a,z,k):
 ac=Counter(map(canon,a.get(k,[])));zc=Counter(map(canon,z.get(k,[])))
 return {'removed':[json.loads(x) for x,n in (ac-zc).items() for _ in range(n)],'added':[json.loads(x) for x,n in (zc-ac).items() for _ in range(n)]}
def doubles(rows,ks):
 c=Counter(tuple(r.get(k) for k in ks) for r in rows);return [{'key':list(k),'count':v} for k,v in c.items() if v>1]
old,new=load('2434-historical.toml'),load('2434-current.toml');co,cn=load('2475-historical.toml'),load('2475-current.toml')
oldkeys={'files':['path'],'functions':['path','item'],'findings':['rule','path','item','fingerprint']}
inv={'schema':'726-mixed-quality-structural-inventory-v1','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256((b/'inventory-registration.json').read_bytes()).hexdigest(),'method':'Python standard-library TOML parsing of archived bytes, structural evidence only; no product scanner or build and no personal displayed-range credit.','baseline':{'old_counts':{k:len(old[k]) for k in oldkeys},'current_counts':{k:len(new[k]) for k in oldkeys},'old_duplicate_keys':{k:doubles(old[k],v) for k,v in oldkeys.items()},'current_duplicate_keys':{k:doubles(new[k],v) for k,v in oldkeys.items()},'delta':{k:arraydelta(old,new,k) for k in oldkeys}},'config':{'old_counts':{k:len(v) for k,v in co.items() if isinstance(v,list)},'current_counts':{k:len(v) for k,v in cn.items() if isinstance(v,list)},'old_duplicate_scope_keys':doubles(co['scopes'],['kind','path','item']),'current_duplicate_scope_keys':doubles(cn['scopes'],['kind','path','item']),'old_duplicate_exception_keys':doubles(co['exceptions'],['rule','path','item','fingerprint']),'current_duplicate_exception_keys':doubles(cn['exceptions'],['rule','path','item','fingerprint']),'delta':{k:arraydelta(co,cn,k) for k in ['excluded_paths','scopes','semantic_families','exceptions']},'scalar_old':{k:v for k,v in co.items() if not isinstance(v,list)},'scalar_current':{k:v for k,v in cn.items() if not isinstance(v,list)}},'qualification':'Configuration descriptions and structural absence of duplicate selected keys do not establish named source behavior, source coverage, matcher policy, runtime features, or product validation. Different old baseline/config revisions remain separately identified.'}
(b/'structural-inventory.json').write_text(json.dumps(inv,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'baseline_counts':[inv['baseline']['old_counts'],inv['baseline']['current_counts']],'config_counts':[inv['config']['old_counts'],inv['config']['current_counts']],'config_delta':inv['config']['delta'],'duplicates':{k:v for k,v in inv['config'].items() if 'duplicate' in k}},indent=2))
