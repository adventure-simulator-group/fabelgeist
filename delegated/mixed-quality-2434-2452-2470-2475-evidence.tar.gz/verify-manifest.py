from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent;m=json.loads((b/'MANIFEST.json').read_bytes());expected={x['path']:x for x in m['files']};actual={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};assert actual==set(expected),(sorted(actual-set(expected)),sorted(set(expected)-actual))
for name,x in expected.items():
 d=(b/name).read_bytes();assert len(d)==x['bytes'] and hashlib.sha256(d).hexdigest()==x['sha256'],name
print('Manifest integrity passed for',len(expected),'files; no changes made.')
