from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess
b=Path(__file__).parent;pub='<LOCAL_PATH_0>';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';cur='95e63628f9d70b8dd6e6fede64334696c6995009';r=json.load(gzip.open('<LOCAL_PATH_1>','rt'));sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
spec={2434:('6533e444fa37552927070cc8d8190907fd3b413e',[[1,200],[12748,12847]],[[1,200],[12713,12812]]),2452:('90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696',[[1,150],[320,500]],[[1,150],[1150,1350]]),2470:('cbbbca08c89a8768926799371f54cf6057312e5e',[[1,150],[760,1000]],[[1,150],[710,960]]),2475:('cbbbca08c89a8768926799371f54cf6057312e5e','full','full')};out=[]
for i,(old,oldranges,newranges) in spec.items():
 e=r['files'][i];p=e['path'];tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+e['sha256'];t=subprocess.check_output(['git','-C',pub,'show',f82+':'+tp]);
 for kind,rev,ranges in [('historical',old,oldranges),('current',cur,newranges)]:
  d=subprocess.check_output(['git','-C',pub,'show',rev+':'+p]);h=sha(d);eof=len(d.splitlines());
  if kind=='historical':assert h==e['sha256'] and d==t
  if ranges=='full':ranges=[[1,eof]]
  assert all(1<=a<=z<=eof for a,z in ranges),(i,kind,eof,ranges)
  fn=f'sources/{i}-{kind}'+Path(p).suffix;(b/fn).parent.mkdir(exist_ok=True);(b/fn).write_bytes(d)
  out.append({'id':f'{i}-{kind}','role':i,'kind':kind,'original_source_id':e['source_id'],'original_snapshot':e['snapshot'],'revision':rev,'git_path':p,'archive':fn,'sha256':h,'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Historical/current sources separately identified. Retained bytes and structural parsing are not personal full source display or product validation.'})
(b/'registration.json').write_text(json.dumps({'schema':'726-mixed-quality-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':out},indent=2)+'\n');print(json.dumps([{k:e[k] for k in ['id','sha256','bytes','eof','prospective_personal_read_ranges']} for e in out],indent=2))
