from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).parent;r=json.loads((b/'registration.json').read_bytes());chunks={
'2434-historical':[[1,100],[12748,12797],[101,200],[12798,12847]],'2434-current':[[1,100],[12713,12762],[101,200],[12763,12812]],
'2452-historical':[[1,75],[320,410],[76,150],[411,500]],'2452-current':[[1,75],[1150,1250],[76,150],[1251,1350]],
'2470-historical':[[1,75],[760,840],[76,150],[841,920],[921,1000]],'2470-current':[[1,75],[710,790],[76,150],[791,870],[871,960]],
'2475-historical':[[1,125],[126,250],[251,375],[376,500],[501,625],[626,750],[751,875],[876,1001]],
'2475-current':[[1,125],[126,250],[251,375],[376,500],[501,625],[626,750],[751,875],[876,1000],[1001,1028]]}
def union(rs):
 o=[]
 for a,z in sorted(rs):
  if o and a<=o[-1][1]+1:o[-1][1]=max(o[-1][1],z)
  else:o.append([a,z])
 return o
def complement(rs,eof):
 o=[];n=1
 for a,z in union(rs):
  if n<a:o.append([n,a-1])
  n=z+1
 if n<=eof:o.append([n,eof])
 return o
rows=[]
for e in r['entries']:
 c=chunks[e['id']];assert union(c)==union(e['prospective_personal_read_ranges']);rows.append({'id':e['id'],'revision':e['revision'],'sha256':e['sha256'],'actual_display_chunks':c,'actual_display_union':union(c),'unread_complement':complement(c,e['eof']),'eof':e['eof']})
o={'schema':'726-mixed-quality-personal-display-receipt-v1','author':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256((b/'registration.json').read_bytes()).hexdigest(),'reads':rows,'qualification':'Exact bounded displayed chunks only; retained complete bytes and structural parsing are not personal full-body display. Prior reviewer displays are separate. Test-source text was inspected but no tests, product code or fixtures were executed.'};(b/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(rows,indent=2))
