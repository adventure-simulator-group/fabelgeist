from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile
b=Path(__file__).parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();out=[]
for name,src,manifest,archive in [('p17-metrics',Path('<LOCAL_PATH_1>'), 'BUNDLE-MANIFEST.json','p17-metrics-evidence.tar.gz'),('rig-export',Path('<LOCAL_PATH_2>'),'packet-manifest.json','rig-quality-export-hair-evidence.tar.gz')]:
 altered=(src/'evidence-verification.json').read_bytes();m=json.loads((src/manifest).read_bytes());entry=next(x for x in m['files'] if x['path']=='evidence-verification.json');dest=b/'incident'/name;dest.mkdir(parents=True,exist_ok=True);(dest/'altered-evidence-verification.json').write_bytes(altered)
 arch=pub/'delegated'/archive;matches=[]
 with tarfile.open(arch,'r:gz') as t:
  for member in t.getmembers():
   if member.isfile() and member.name.endswith('/evidence-verification.json') or member.isfile() and member.name=='evidence-verification.json':
    data=t.extractfile(member).read();matches.append({'member':member.name,'sha256':sha(data),'bytes':len(data),'matches_frozen_manifest':sha(data)==entry['sha256']})
    if sha(data)==entry['sha256']:(dest/'original-evidence-verification.json').write_bytes(data)
 out.append({'packet':str(src),'altered_path':str(src/'evidence-verification.json'),'old_recorded_sha256':entry['sha256'],'old_recorded_bytes':entry['bytes'],'new_sha256':sha(altered),'new_bytes':len(altered),'altered_copy':str((dest/'altered-evidence-verification.json').relative_to(b)),'published_archive':str(arch),'published_archive_sha256':sha(arch.read_bytes()),'published_archive_members':matches,'original_copy':str((dest/'original-evidence-verification.json').relative_to(b)) if (dest/'original-evidence-verification.json').exists() else None})
obj={'schema':'726-additive-evidence-verifier-rewrite-incident-v1','author':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'chronology':'After freezing the original packets, on 2026-11-12T05:31:14 UTC, /root/rig_identity invoked each previous evidence verification script. Both scripts unexpectedly rewrite their packet-local evidence-verification.json with a new verification timestamp. The old frozen manifests were not changed. Immediately afterward, changed files and any exact published original bytes were copied here. No user extraction or publication checkout files were edited.','qualification':'Archive/member matching demonstrates byte survival, not a claim that the overwritten /tmp packet remains manifest-clean. Original files are not restored in place. Source/report/read-receipt bytes were not modified by this action.','entries':out};(b/'incident.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps(obj,indent=2))
