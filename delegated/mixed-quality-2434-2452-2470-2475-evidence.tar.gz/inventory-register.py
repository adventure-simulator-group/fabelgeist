from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).parent; names=['2434-historical.toml','2434-current.toml','2475-historical.toml','2475-current.toml']; o={'schema':'726-structural-inventory-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'purpose':'Evidence-only generic TOML structural key/count and multiset comparison, no project quality scanner. Parsed whole bytes do not imply personal read of unshown lines.','files':[{'archive':'sources/'+n,'sha256':hashlib.sha256((b/'sources'/n).read_bytes()).hexdigest()} for n in names]};(b/'inventory-registration.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
