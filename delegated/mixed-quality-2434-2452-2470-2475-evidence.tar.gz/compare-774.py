from pathlib import Path
from datetime import datetime,timezone
import gzip,json
b=Path(__file__).parent;a=json.loads((b/'historical-attribution.json').read_bytes())['records_774'];result=[]
def obj(z):return gzip.decompress((b/z['archive']).read_bytes())
for owner in ['root','native','rig']:
 for name in ['coverage.jsonl','contracts.jsonl']:
  pair=[z for z in a if '/audit-existing-type-owners/'+owner+'/'+name in z['transport_path']];assert len(pair)==2;old,new=map(obj,pair);od=[json.loads(x) for x in old.splitlines()];nd=[json.loads(x) for x in new.splitlines()];assert len(od)==len(nd)
  if name=='coverage.jsonl': inds={'root':[25,26],'native':[289,628],'rig':[90]}[owner]
  else:
   ids={'root':['ROOT-OWNER-METADATA-001'],'native':['NATIVE-OWNER-REPORT-METRICS-005'],'rig':['RIG-OWNER-EXPORT-013','RIG-OWNER-PROBE-015']}[owner];inds=[i for i,r in enumerate(od) if r.get('id') in ids];assert all(any(od[i].get('id')==x for i in inds) for x in ids)
  rows=[]
  for i in inds:
   keys=sorted(set(od[i])|set(nd[i]));dif=[k for k in keys if od[i].get(k)!=nd[i].get(k)];rows.append({'zero_based_row':i,'id':od[i].get('id',od[i].get('source_id')),'rows_equal':od[i]==nd[i],'differing_top_level_keys':dif,'original':od[i],'historical_export':nd[i]})
  result.append({'owner':owner,'file':name,'original_archive':pair[0]['archive'],'historical_export_archive':pair[1]['archive'],'whole_bytes_identical':old==new,'rows':rows})
for suffix in ['audit-producer-propagation/rig/sources.json']:
 pair=[z for z in a if z['transport_path'].endswith(suffix)];old,new=map(obj,pair);od=json.loads(old);nd=json.loads(new);i=177;result.append({'owner':'rig','file':suffix,'original_archive':pair[0]['archive'],'historical_export_archive':pair[1]['archive'],'whole_bytes_identical':old==new,'rows':[{'zero_based_row':i,'id':od[i]['source_id'],'rows_equal':od[i]==nd[i],'differing_top_level_keys':sorted(k for k in set(od[i])|set(nd[i]) if od[i].get(k)!=nd[i].get(k)),'original':od[i],'historical_export':nd[i]}]})
(b/'historical/774-selected-variant-comparison-reconstructed.json').write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'qualification':'Mechanical selection/comparison only. Both complete historical variants are preserved with their own hashes. Comparison does not transfer original historical coverage to this reviewer or current revision.','comparisons':result},indent=2)+'\n');print(json.dumps([{'owner':r['owner'],'file':r['file'],'whole_equal':r['whole_bytes_identical'],'rows':[{k:v for k,v in x.items() if k in ('id','zero_based_row','rows_equal','differing_top_level_keys')} for x in r['rows']]} for r in result],indent=2))
