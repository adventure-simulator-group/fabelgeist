from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,tarfile
b=Path(__file__).resolve().parent;prev=Path('<LOCAL_PATH_0>');extract=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');sha=lambda d:hashlib.sha256(d).hexdigest();gb=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();w=lambda p,d:(b/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
reg=json.loads((b/'registration.json').read_bytes());reads=[]
for e in reg['entries']:
 covered=set(i for a,z in e['prospective_display_ranges'] for i in range(a,z+1));unread=[];start=None
 for i in range(1,e['eof']+2):
  if i<=e['eof'] and i not in covered:
   if start is None:start=i
  elif start is not None:unread.append([start,i-1]);start=None
 reads.append({'id':e['id'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_ranges':e['prospective_display_ranges'],'unread_complement':unread})
w('personal-read-receipt.json',{'recorded_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','registration_sha256':sha((b/'registration.json').read_bytes()),'reads':reads,'qualification':'Exact bounded registered windows displayed with numbered lines. Native compiler, test and fixture text was not executed; archived unread bytes provide no personal-read credit.'})
(b/'history').mkdir(exist_ok=True)
for n in ['original-registry.json.gz','original-transport-manifest.json.gz','baseline-059-queue.json.gz','p16-lock.source.gz','p16-recovery.json','p16-tracked.patch','p16-lock-and-recovery.json','older-774-handoff-manifest.json.gz','774-segovb-contract-615.json']:shutil.copyfile(prev/'history'/n,b/'history'/n)
orig=json.load(gzip.open(b/'history/original-registry.json.gz','rt'));q=json.load(gzip.open(b/'history/baseline-059-queue.json.gz','rt'));w('history/reconstructed-selections.json',{'qualification':'Mechanically reconstructed selections from recovered original registry and 059 queue; no checkpoint3821 promotion.','registry_sha256':sha(gzip.decompress((b/'history/original-registry.json.gz').read_bytes())),'registry_roles':{str(i):orig['files'][i] for i in [2567,2568,2569,2570]},'queue_sha256':sha(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes())),'queue_entries':{'2332':q['entries'][2332]}})
transport=json.load(gzip.open(b/'history/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in transport['entries']};entries=[];paths=set()
for name in ['bevy-remote','bevy-derive-meta']:
 prior=Path('<LOCAL_PATH_3>'+name);oa=json.loads((prior/'original-attribution.json').read_bytes())
 for x in oa['original_059_records']:paths.add(x['original_path'])
paths.add('parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-865-872.json')
for p in sorted(paths):
 d=(extract/p).read_bytes();x=idx[p];assert (len(d),sha(d),gb(d))==(x['bytes'],x['sha256'],x['git_blob']);dst='history/059/'+p;(b/dst).parent.mkdir(parents=True,exist_ok=True);(b/dst).write_bytes(d);entries.append({'kind':'059','original_path':p,'copy':dst,'sha256':sha(d),'bytes':len(d),'git_blob':gb(d)})
preva=json.loads((prev/'history/attribution-and-copies.json').read_bytes())
for x in preva['records']:
 if x['kind']=='774-f82':
  dst=x['copy'];(b/dst).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(prev/dst,b/dst);entries.append(x)
prior=Path('<LOCAL_PATH_3>bevy-remote');old=json.loads((prior/'original-attribution.json').read_bytes())
for x in old['older_774_receipts']:
 if 'source-qualifications-final-current.jsonl' in x['transport_path']:
  d=(prior/x['preserved_bytes']).read_bytes();assert sha(d)==x['sha256'] and gb(d)==x['git_blob'];dst='history/774/source-qualifications-final-current.jsonl';(b/dst).write_bytes(d);entries.append({'kind':'774-f82','transport_revision':x['transport_revision'],'transport_path':x['transport_path'],'copy':dst,'sha256_uncompressed':sha(d),'bytes_uncompressed':len(d),'git_blob':gb(d)})
comparisons=[]
for name in ['bevy-remote','bevy-derive-meta']:
 prior=Path('<LOCAL_PATH_3>'+name);base='history/prior-'+name;(b/base).mkdir(exist_ok=True)
 for n in ['REPORT.json','registration.json','personal-read-receipt.json','MANIFEST.json','original-attribution.json']:
  d=(prior/n).read_bytes();dst=base+'/'+n;(b/dst).write_bytes(d);entries.append({'kind':'prior-current','author':'/root/rig_identity','copy':dst,'sha256':sha(d),'bytes':len(d)})
 a=pub/'delegated'/(name+'-evidence.tar.gz');adst=base+'/published-evidence.tar.gz';shutil.copyfile(a,b/adst)
 with tarfile.open(a,'r:gz') as t:
  for n in ['REPORT.json','registration.json','personal-read-receipt.json','MANIFEST.json','original-attribution.json']:
   v=t.extractfile(n).read();o=(prior/n).read_bytes();comparisons.append({'packet':name,'member':n,'original':base+'/'+n,'archive':adst,'original_sha256':sha(o),'published_sha256':sha(v),'equal':o==v})
for name in ['REPORT.json','MANIFEST.json']:
 d=(prev/name).read_bytes();dst='history/prior-2565-'+name;(b/dst).write_bytes(d);entries.append({'kind':'prior-current','author':'/root/rig_identity','copy':dst,'sha256':sha(d),'bytes':len(d)})
w('history/published-comparisons.json',{'members':comparisons,'qualification':'Only specified members compared; published registration is path-redacted, not byte-identical. Original prior manifests do not prove transformed member identity. Exact original and published archives are preserved separately.'})
w('history/attribution-and-copies.json',{'records':entries,'original_774_pin_qualification':preva['original_774_pin_qualification'],'qualification':'059 records verified against original transport manifest; 774 files transported by f82; prior reports and receipts are separately attributed. No previous evidence is checkpoint3821.'});print('entries',len(entries),'reads',len(reads))
