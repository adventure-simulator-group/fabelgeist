from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objs={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objs:
  p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objs[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind):
 raw=(b/local).read_bytes();root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw),(rev,path,local);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw)})
r=json.loads((b/'registration.json').read_bytes());f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for x in r['rows']:
 old,cur=x['versions'];proof(cur['revision'],x['path'],cur['local'],'pinned current, only receipt actual ranges read')
 for c in x['comparison_git_paths']:proof(c['revision'],x['path'],c['local'],'per-file identity only, not source display or whole snapshot')
 proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+old['sha256'],old['local'],'exact PR registry object via f82 evidence transport; original 6533-based pr-working snapshot is independently qualified')
 
 if x['snapshot']=='physical-p16':proof('039329518e264f19206cf5b0b98d177433f40c17',x['path'],old['local'],'recorded P16 catalog file origin, not P16 source HEAD')
for n in ['support-registration.json','support-registration-extra.json','support-registration-hosts.json','support-registration-pitched.json','support-registration-bounds.json','support-registration-order.json','support-registration-envelope.json','support-registration-collision.json']:
 for x in json.loads((b/n).read_bytes())['entries']:proof(x['revision'],x['path'],x['local'],'current registered support, not historical role credit')
for x in json.loads((b/'historical-manifest.json').read_bytes())['records']:
 if x.get('transport_revision'):proof(x['transport_revision'],x['git_path'],x['local'],'exact original 774 record via f82 transport')
(b/'git-proofs.json').write_text(json.dumps({'schema':'726-spiral-core-bearings-tests-2840-2842-git-membership-v1','objects':objs,'proofs':proofs,'qualification':'PR is 6533-based with unrelated dirty files; per-file identity and f82 transport do not establish whole-tree cleanliness or the historical source HEAD.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objs),'sha256',h((b/'git-proofs.json').read_bytes()))
