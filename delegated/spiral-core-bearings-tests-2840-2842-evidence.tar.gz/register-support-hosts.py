from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path.cwd();repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();items=[('circuit-walk','crates/adventuresim-building-generator/src/generator/linear_defenses.rs',[[140,195]]),('gallery-floors','crates/adventuresim-building-generator/src/generator/projected_defenses.rs',[[215,270],[875,925]])];entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';entries.append({'name':name,'path':path,'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':loc});pending.append((loc,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective source windows for candidate eligible host creation only; no ordered-role or full producer credit.','entries':entries};(b/'support-registration-hosts.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:(b/n).write_bytes(raw)
print('registration',h((b/'support-registration-hosts.json').read_bytes()))
