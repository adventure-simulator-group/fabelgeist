from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path.cwd();repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();items=[('collision-orientation','crates/adventuresim-building-generator/src/collision.rs',[[25,105]]),('solid-projection','crates/adventuresim-building-generator/src/model/resolved_shapes.rs',[[370,390]])];entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';entries.append({'name':name,'path':path,'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':loc});pending.append((loc,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective native orientation representation support only; no collision execution or ordered-role credit.','entries':entries};(b/'support-registration-collision.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:(b/n).write_bytes(raw)
print('registration',h((b/'support-registration-collision.json').read_bytes()))
