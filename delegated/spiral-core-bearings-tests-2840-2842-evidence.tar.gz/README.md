# Bounded spiral stair source evidence: roles 2840–2842

This packet records `/root/hair_ops`'s static inspection of the original
`pr-working` source objects and independently pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. `REPORT.json` is the assessment;
`registration.json` and `read-receipt.json` distinguish prospective plans,
actual displays, historical material exclusions and separately read support.
The old, current and 6533 source files are byte-identical per file, but only
old and current bodies were separately displayed. `tests.rs` is source text:
no test or fixture was executed.

The historical record is preserved with original reviewer attribution. Native
registration rows match, while the recorded earlier whole-file registration
hash differs from the retained f82 file and all its complete-line prefixes.
The old 2840 material excludes line 37 context and 38–70; the latter was read
in this current audit only as separately registered support. The envelope
support registration requested 1–75, but the file ends at 68; nonexistent
69–75 were not read. Unrelated pr-working dirty paths and separate P16 recovery
qualifications are not erased or promoted to checkpoint 3821.

`git-proofs.json` and `git-objects/` preserve offline commit/tree/blob proof
chains, including transport objects. `historical-manifest.json` inventories
exact historical records and `historical-selections-reconstructed.json` is
explicitly a reconstructed selection. `recovered/` and `prior/` preserve the
individual evidence and relationship context; author and revision never
transfer. `MANIFEST.json` inventories every file in this packet except itself,
including nested manifests. Verify evidence integrity with:

```sh
python3 verify-evidence.py
```

This check executes only the packet's evidence verifier, not product code. It
verifies content hashes, source and Git object identities, registry and
historical reader links, coverage partitions, qualified support and manifest.
The verifier cannot independently prove an actual personal display; that is the
reviewer's contemporaneous recorded receipt. The candidate finding is
conditional and is not a product validation or an independent ledger count.
