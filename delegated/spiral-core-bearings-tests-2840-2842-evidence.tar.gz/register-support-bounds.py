from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path.cwd();repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();items=[('audit-bounds','crates/adventuresim-building-generator/src/audit/resolved_geometry_helpers.rs',[[1,40]]),('projected-solid','crates/adventuresim-building-generator/src/generator/defense_geometry.rs',[[170,220]])];entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';entries.append({'name':name,'path':path,'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':loc});pending.append((loc,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective exact audit AABB and host solid constructor support; not ordered-role credit.','entries':entries};(b/'support-registration-bounds.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:(b/n).write_bytes(raw)
print('registration',h((b/'support-registration-bounds.json').read_bytes()))
