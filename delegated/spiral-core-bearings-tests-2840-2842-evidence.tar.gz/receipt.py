from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path.cwd();h=lambda x:hashlib.sha256(x).hexdigest();L=lambda n:json.loads((b/n).read_bytes());reg=L('registration.json');nav={};navigation=[]
navfiles={'navigation-shapes.txt':'navigation-registration.json','navigation-bonds.txt':'navigation-registration-extra.json','navigation-roles.txt':'navigation-registration-owners.json','navigation-tilt.txt':'navigation-registration-tilt.json','navigation-bound-owner.txt':'navigation-registration-bound-owner.json','navigation-flow.txt':'navigation-registration-flow.json','navigation-collision.txt':'navigation-registration-collision.json'}
for name,rn in navfiles.items():
 raw=(b/name).read_bytes();lines=raw.decode().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m,(name,line);nav.setdefault(m.group(1),set()).add(int(m.group(2)))
 navigation.append({'output':name,'sha256':h(raw),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'registration':rn,'ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2840:[[1,36]],2841:[[1,69]],2842:[[1,110],[111,221]]};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];used=nums(d);extra=sorted(nav.get(row['path'],set())-used) if j else [];assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'local':v['local'],'sha256':v['sha256'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':extra,'unread_complement':comp(v['eof'],used|set(extra)),'qualification':'Old and current bodies separately read post-registration; 6533 copy mechanically compared. Role2842 is test source text only, no execution.'})
support=[]
files=['support-registration.json','support-registration-extra.json','support-registration-hosts.json','support-registration-pitched.json','support-registration-bounds.json','support-registration-order.json','support-registration-envelope.json','support-registration-collision.json']
for rn in files:
 for x in L(rn)['entries']:
  d=x['ranges'];d=[[1,90],[91,175]] if x['name']=='spiral-parent' else [[1,68]] if x['name']=='envelope-order' else d;used=nums(d);prior=[]
  for row in reg['rows']:
   if row['path']==x['path']:prior=chunks[row['original_index']]
  priornums=nums(prior);navonly=sorted(nav.get(x['path'],set())-used-priornums)
  support.append({'name':x['name'],'registration':rn,'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement':comp(x['eof'],used|priornums|set(navonly)),'registration_out_of_file_range':[[69,75]] if x['name']=='envelope-order' else [],'qualification':'Other support windows on same path remain separate; planned envelope 69–75 does not exist (EOF68). keep_core 37–70 is separate current support, not historical role material.','ordered_role_credit':0})
names=['registration.json',*files,*navfiles.values()];d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Reconstructed personal source displays and match-line-only navigation after prospective registration.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':L(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{k:sorted(v) for k,v in sorted(nav.items())},'prior_personal_support':'registration.json/prior_personal_support and preserved prior packet, not transferred ordered-role credit.','limits':'Source/evidence only; no product, geometry, fixtures, tests, build, runtime probe, repair or publication edit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt sha256',h((b/'read-receipt.json').read_bytes()))
