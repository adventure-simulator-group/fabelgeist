import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def complement(n,ranges):
 seen={i for lo,hi in ranges for i in range(lo,hi+1)}; out=[]
 for i in sorted(set(range(1,n+1))-seen):
  if not out or i>out[-1][1]+1: out.append([i,i])
  else: out[-1][1]=i
 return out
for reg,dst,key in [('registration.json','personal-read-receipt.json','assigned'),('support-registration.json','support-read-receipt.json','support'),('support2-registration.json','support2-read-receipt.json','support'),('support3-registration.json','support3-read-receipt.json','support'),('support4-registration.json','support4-read-receipt.json','support')]:
 r=json.loads((p/reg).read_bytes()); entries=r['sources']+r['locks'] if key=='assigned' else r['entries']; views=[]
 for e in entries:
  chunks=[[20,90],[91,165]] if e.get('original_index')==17 else e['registered_ranges']
  repeated={1:[[32,87],[138,190],[780,810]],2:[[1,40]],17:[[20,125]]}.get(e.get('original_index'),[]) if key=='assigned' else []
  views.append({'archive':e['archive'],'sha256':e['sha256'],'displayed_chunks':chunks,'repeat_displays':repeated,'unread_complement':complement(e['EOF'],chunks)})
 obj={'author':'/root/mhr_character','receipt_utc':now,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':views,'qualification':'Personal numbered untruncated displays after prospective registration. Only these ranges are credited; support is not ordered-role credit. An initial attempt to display support with reversed filenames failed and displayed no source; the registered correct files were subsequently displayed. Native manifests were parsed as package metadata, not displayed as source.'}
 (p/dst).write_text(json.dumps(obj,indent=2)+'\n')
