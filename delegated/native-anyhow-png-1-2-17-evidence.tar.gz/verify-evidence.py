import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and [e['original_index'] for e in sel['rows']]==[1,2,17] and all(reg['files'][e['original_index']]==e['row'] for e in sel['rows']);related=load('registry-related-reconstructed.json');assert all(reg['files'][int(k)]==v for k,v in related['roles'].items())
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256'],e['file']
manifest=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(manifest)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(manifest))['entries']}
snap=next(e for e in reg['snapshots'] if e['id']=='physical-p16');patch=(p/'reference/p16-tracked.patch').read_bytes();assert sha(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and snap['head']=='a120390947c89b703dc74c4255a13c035d054c50' and ' M Cargo.lock' in snap['status_porcelain'] and b'diff --git a/Cargo.lock b/Cargo.lock\n' in patch
r=load('registration.json')
for name,pack in r['packages'].items():
 b=(p/pack['archive']).read_bytes();assert sha(b)==pack['sha256']
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tar:
  mf=tar.extractfile(pack['manifest_member']).read();assert mf==(p/pack['manifest_archive']).read_bytes() and sha(mf)==pack['manifest_sha256'];meta=tomllib.loads(mf.decode());assert (meta['package']['name'],meta['package']['version'])==(pack['name'],pack['version'])
  for e in r['sources']:
   if e['package']==name:assert tar.extractfile(e['package_member']).read()==(p/e['archive']).read_bytes() and e['sha256']==reg['files'][e['original_index']]['sha256']
for e in r['locks']:
 b=(p/e['archive']).read_bytes();parsed=tomllib.loads(b.decode())['package']
 for x in e['package_stanzas']:
  found=[z for z in parsed if z.get('name')==x['package'] and z.get('version')==r['packages'][x['package']]['version']];assert len(found)==1 and found[0]==x['package_record'] and found[0]['checksum']==r['packages'][x['package']]['sha256']
 if e['label']=='p16':assert e['sha256']==reg['files'][39]['sha256']
 if e['label']=='historical_pr':assert e['sha256']==reg['files'][497]['sha256']
s=load('support-registration.json');tiny=(p/s['tiny_archive']['archive']).read_bytes();assert sha(tiny)==s['tiny_archive']['sha256'];te=next(e for e in s['entries'] if e['kind']=='native-package')
with tarfile.open(fileobj=io.BytesIO(tiny),mode='r:gz') as tar:assert tar.extractfile(te['package_member']).read()==(p/te['archive']).read_bytes()
lock=next(e for e in s['entries'] if e['kind']=='current-lock');assert lock['parsed_package']['checksum']==sha(tiny) and lock['parsed_package'] in tomllib.loads((p/lock['archive']).read_text())['package']
for label,rf,tf in [('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('support2','support2-registration.json','support2-read-receipt.json'),('support3','support3-registration.json','support3-read-receipt.json'),('support4','support4-registration.json','support4-read-receipt.json')]:
 a=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes()) and datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(a['registered_utc']);entries=a['sources']+a['locks'] if label=='assigned' else a['entries'];assert len(entries)==len(t['entries'])
 for e,v in zip(entries,t['entries']):
  b=(p/e['archive']).read_bytes();assert sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'] and e['archive']==v['archive'];planned={i for lo,hi in e['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in v['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in v['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and seen|missing==set(range(1,e['EOF']+1)) and not seen&missing and all(i in seen for lo,hi in v['repeat_displays'] for i in range(lo,hi+1))
  if e.get('kind')=='project' and e['label']=='historical':assert reg['files'][e['original_index']]['source_id']=='pr-working:'+e['path'] and reg['files'][e['original_index']]['sha256']==e['sha256']
 counts[label]=len(entries)
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
q=json.loads(gzip.decompress((p/'reference/queue.json.gz').read_bytes()));l=json.loads(gzip.decompress((p/'reference/ledger.json.gz').read_bytes()));select=load('059-selection-reconstructed.json');assert all(q['entries'][int(i)]==z for i,z in select['queue_entries'].items()) and l['discovery_findings_and_dependencies']['ADLER-L11-ICON-PNG-ERROR-OWNERSHIP']==select['ledger_entry']
for prefix,n in [('adler/','L11-328'),('segovb/','L12-706')]:
 read=(p/'history-059'/f'{prefix}READ-{n}.json').read_bytes();state=(p/'history-059'/f'{prefix}STATE-{n}.json').read_bytes();v=load(f'history-059/{prefix}VERIFY-{n}.json');assert v['receipt_sha256']==sha(read) and v['state_sha256']==sha(state)
a=load('history-059/adler/READ-L11-328.json');assert [a['sources'][i]['fresh_reads'] for i in (0,2)]==[[[1,521]],[[1,114]]] and a['connected_reinspection'][2]['fresh_reads']==[[155,182],[385,430]]
for i,f in [(0,'history-059/adler/REGISTRATION-ADLER-949.json'),(2,'history-059/adler/REGISTRATION-ADLER-951.json')]:assert a['sources'][i]['registration_sha256']==sha((p/f).read_bytes())
assert a['connected_reinspection'][2]['registration_sha256']==sha((p/'history-059/adler/REGISTRATION-ADLER-977.json').read_bytes())
a=load('history-059/segovb/READ-L12-706.json');assert a['proposal_sha256']==sha((p/'history-059'/a['proposal']).read_bytes());assert a['rows'][0]['attribution'].startswith('Subagent /root/lens12_frontier') and a['rows'][2]['fresh_personal_body_reads']==[[1,114]]
for i,f in [(0,'history-059/parallel-l12-20261029/REGISTRATION-PAR-L12-043.json'),(2,'history-059/parallel-l12-20261029/REGISTRATION-PAR-L12-045.json')]:assert a['rows'][i]['registration_sha256']==sha((p/f).read_bytes())
v=load('history-059/parallel-l12-20261029/READ-NATIVE-PAR-L12-706-PIXMAP.json');assert a['new_own_lens_native_views'][0]['sha256']==sha((p/'history-059/parallel-l12-20261029/READ-NATIVE-PAR-L12-706-PIXMAP.json').read_bytes()) and v['rows'][0]['registration_sha256']==sha((p/'history-059/parallel-l12-20261029/REGISTRATION-PAR-L12-049-NATIVE-PIXMAP.json').read_bytes()) and v['rows'][0]['fresh_personal_body_reads']==[[155,182],[385,430]]
owner=[json.loads(x) for x in gzip.decompress((p/'history-774/audit-existing-type-owners/rig/additional-sources.jsonl.gz').read_bytes()).splitlines()]
for i,row in [(1,111),(2,112),(17,88)]:
 e=owner[row];z=reg['files'][i];proof=z['owner_contract_proofs'][0];assert e['source_id']==z['source_id'] and e['observed_sha256']==z['sha256'] and e['read_ranges']==proof['read_ranges'] and proof['row']==row
f=[json.loads(x) for x in gzip.decompress((p/'history-774/audit-existing-type-owners/rig/findings.jsonl.gz').read_bytes()).splitlines()];assert f[11]['id']=='RIG-OWNER-F012' and f[15]['id']=='RIG-OWNER-F016'
tr=[json.loads(x) for x in gzip.decompress((p/'history-774/producer-supplement-after-owner/rig/traces.jsonl.gz').read_bytes()).splitlines()];t=tr[21];assert t['id']=='RIG-PPS-022' and t['fresh_current_source_reads'][14]['read_ranges']==[[20,165]] and t['fresh_current_source_reads'][14]['sha256']==reg['files'][17]['sha256']
pf=[json.loads(x) for x in gzip.decompress((p/'history-774/producer-supplement-after-owner/rig/findings.jsonl.gz').read_bytes()).splitlines()];assert pf[9]['id']=='RIG-PPS-F010' and 'RIG-OWNER-F012' in pf[9]['dedup']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==33 and len(report['lens_perspectives'])==13 and len({e['lens'] for e in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'scope':'Evidence integrity only: native archives and lock/member identities, dirty P16 patch/base, historical source and separate supplier scopes, prospective registrations and exact personal read/unread partitions, Git commit/tree paths. Not product, macro, encoder or runtime validation.'},indent=2))
