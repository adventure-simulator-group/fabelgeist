import json,hashlib,subprocess,pathlib,datetime
p=pathlib.Path('<LOCAL_PATH_0>')
repo='<LOCAL_PATH_1>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009'
specs=[('bestiary-additional','crates/adventuresim-core/src/bestiary.rs',[[330,385],[561,719],[730,740]]),('quest-catalog','crates/adventuresim-core/src/quest_catalog.rs',[[90,170],[250,280],[500,560],[720,785],[1030,1090]]),('quest-validation','crates/adventuresim-core/src/quest_catalog_validation.rs',[[260,310],[465,505],[660,710],[1200,1250]])]
entries=[]
for name,path,ranges in specs:
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]); target='support/'+name+'.rs'; (p/target).write_bytes(b)
 entries.append(dict(id=name,revision=rev,git_path=path,archive=target,sha256=hashlib.sha256(b).hexdigest(),git_blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),bytes=len(b),eof=len(b.splitlines()),prospective_personal_read_ranges=ranges,qualification='Separately registered current support only, not a role read or product validation.'))
(p/'support-registration-2.json').write_text(json.dumps(dict(schema='726-bestiary-support-prospective-v1',author='/root/rig_identity',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),entries=entries),indent=2)+'\n')
