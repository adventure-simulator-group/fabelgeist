from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
p=Path('<LOCAL_PATH_0>'); repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';path='crates/adventuresim-world-schema/src/basis_points.rs';b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);(p/'support/basis-points.rs').write_bytes(b)
e={'id':'basis-points','revision':rev,'git_path':path,'archive':'support/basis-points.rs','sha256':hashlib.sha256(b).hexdigest(),'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),'bytes':len(b),'eof':len(b.splitlines()),'prospective_personal_read_ranges':[[1,10]],'qualification':'Current constant support only.'};(p/'support-registration-4.json').write_text(json.dumps({'schema':'726-bestiary-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':[e]},indent=2)+'\n')
