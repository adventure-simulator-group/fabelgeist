# Roles 2836–2837: bounded source and evidence packet

`REPORT.json` records independently displayed historical/current quality and
catalog-test source, selected 95e support, historical relationships, two
conditional source observations, and thirteen scoped perspectives. It is not a
claim of full-lens completion. The two original role files individually match
6533 and 95e; the historical pr-working snapshot has unrelated changes.

`registration.json` and `support-registration*.json` are prospective source
registrations. The corresponding `read-receipt*.json` and
`support-read-receipt*.json` give exact personal displayed ranges and unread
complements; preserved full bytes outside those ranges are not read credit.
`support-read-receipt-3-completion.json` is an additive completion record:
the earlier receipt was recorded concurrently with the display calls and alone
cannot establish completion order. It remains preserved unchanged.

`history/` retains original 059 registry and transport manifest, five original
extraction records verified against that manifest, compressed historical 059
summaries, exact 774 transport records with separately proved Git paths, and
prior published current assessments. The registry records a different whole-file
registration hash from the f82 transport copy; selected rows match exactly and
the discrepancy's cause is unknown. `registry-selection-reconstructed.json`
and `queue-selection-reconstructed.json` are explicitly mechanical selections,
not original records or checkpoint 3821 evidence. Original 3821 queue and ledger
are not recovered by this packet.

`git-proofs.json` and `git-objects/` contain recoverable commit/tree membership
chains for all source and historical transport paths. `verify-evidence.py`
checks source hashes, paths, exact roles, reported source references,
registration/display receipts, prior attributions and historical comparisons
using evidence operations only. `MANIFEST.json` hashes packet members;
`verify-manifest.py` checks it. Neither verifier executes product code, builds,
tests, fixtures or probes, nor proves that any source-level assertion passed.
