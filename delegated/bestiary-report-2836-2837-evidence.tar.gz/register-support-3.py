import json,hashlib,subprocess,pathlib,datetime
p=pathlib.Path('<LOCAL_PATH_0>'); repo='<LOCAL_PATH_1>'; rev='95e63628f9d70b8dd6e6fede64334696c6995009'
specs=[('bestiary-diagnostic','crates/adventuresim-core/src/bestiary.rs',[[1166,1210]]),('quest-validation-bounds','crates/adventuresim-core/src/quest_catalog_validation.rs',[[711,735],[1270,1305]])]
e=[]
for name,path,ranges in specs:
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]); dest='support/'+name+'.rs';(p/dest).write_bytes(b);e.append({'id':name,'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(b).hexdigest(),'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),'bytes':len(b),'eof':len(b.splitlines()),'prospective_personal_read_ranges':ranges,'qualification':'Bounded current support only, no assigned role or execution credit.'})
(p/'support-registration-3.json').write_text(json.dumps({'schema':'726-bestiary-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':e},indent=2)+'\n')
