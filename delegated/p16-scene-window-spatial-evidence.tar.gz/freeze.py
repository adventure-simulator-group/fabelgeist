import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();files=[]
for x in sorted(a for a in p.rglob('*') if a.is_file() and a.name!='BUNDLE-MANIFEST.json'):
 b=x.read_bytes();files.append({'path':str(x.relative_to(p)),'bytes':len(b),'sha256':h(b)})
m={'schema':'726-delegate-bundle-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'self_excluded':True,'qualification':'Exact packet inventory; 059/774 and prior packet evidence are separately attributed, recovered P16 remains dirty with unrecovered patch; no product execution.','files':files};(p/'BUNDLE-MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');print('files',len(files),'manifest sha256',h((p/'BUNDLE-MANIFEST.json').read_bytes()))
