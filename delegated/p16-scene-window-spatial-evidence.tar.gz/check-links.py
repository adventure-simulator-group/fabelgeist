import datetime,difflib,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=p/'historical-059';H=lambda b:hashlib.sha256(b).hexdigest()
def check(n,sha):
 n=n.replace('\\','/').removeprefix('target/726-audit-adler-20261027/');assert H((h/n).read_bytes())==sha,n
x=json.loads((h/'segovb/READ-L11-418.json').read_text());rows=[r for r in x['sources'] if r['original_index'] in [2526,2527]];assert len(rows)==3
for r in rows:
 check(r['registration'],r['registration_sha256']);q=r.get('same_lens_prior')
 if q:assert not r['fresh_personal_body_reads'];check(q['receipt'],q['receipt_sha256']);check(q['entry']['registration'],q['entry']['registration_sha256'])
for i,role in [(857,2526),(858,2527)]:
 x=json.loads((h/f'segovb/READ-L12-{i}.json').read_text());check(x['proposal'],x['proposal_sha256']);assert not x['root_personal_rereads'];r=next(r for r in x['rows'] if r.get('original_index')==role);check(r['registration'],r['registration_sha256'])
prior=json.loads((p/'prior-references.json').read_text());count=0
for x in prior['packets']:
 a=pathlib.Path(x['prior_location']);manifest=a/'BUNDLE-MANIFEST.json';assert H(manifest.read_bytes())==x['manifest_sha256'];rows={v['path']:v for v in json.loads(manifest.read_text())['files']}
 for y in x['copies']:
  q=p/y['path'];assert H(q.read_bytes())==y['sha256'];name=q.name
  if name!='BUNDLE-MANIFEST.json':assert rows[name]['sha256']==y['sha256']
  count+=1
old=(p/'source/physical-p16-2526.source').read_text().splitlines(keepends=True);new=(p/'source/current-2526.source').read_text().splitlines(keepends=True);d=''.join(difflib.unified_diff(old,new,fromfile='physical-p16:spatial.rs',tofile='95e636:spatial.rs'));assert d==(p/'spatial-p16-to-current.diff').read_text();assert H(d.encode())==json.loads((p/'report.json').read_text())['baseline_and_recovery']['diff_sha256']
result={'schema':'726-evidence-link-verification-v1','status':'passed','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'059 L11 disjoint personal/inherited registration and prior source receipts; both L12 proposals/registrations; prior manifest-linked copied records; exact source delta.','prior_record_copies':count,'qualification':'No full prior archives embedded; linked frozen packets must remain available or be separately published. Evidence only, no product/runtime verification.'};(p/'evidence-links-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
