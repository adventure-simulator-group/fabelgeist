import pathlib
p=pathlib.Path('<LOCAL_PATH_0>');old=pathlib.Path('<LOCAL_PATH_1>')
s=(old/'build-proof.py').read_text().replace(str(old),str(p));a=s.index('ranges={');b=s.index('\ndef complement(',a);s=s[:a]+'''ranges={0:[[1,142]],1:[[1,95],[190,205],[230,270]],2:[[65,105]],3:[[1,150],[165,170],[230,240]],4:[[1,46]],5:[[1,110]],6:[[1,118]],7:[[1,75],[120,150],[230,240],[250,260]],8:[[1,10],[125,180],[430,440],[525,540]],9:[[1,217]],10:[[1,99]]}
# All displayed rg navigation matches are within the windows; no role credit transfer.
''' +s[b:];(p/'build-proof.py').write_text(s)
s=(old/'copy-evidence.py').read_text().replace(str(old),str(p));a=s.index('names=[');b=s.index('\nrows=[]',a);names=['segovb/READ-L11-418.json','segovb/REGISTRATION-SEGOVB-1431.json','segovb/REGISTRATION-SEGOVB-1432.json','segovb/REGISTRATION-SEGOVB-1438.json','adler/READ-L11-291.json','adler/REGISTRATION-ADLER-753.json','segovb/READ-L12-857.json','segovb/READ-L12-858.json','parallel-l12-20261029/PROPOSAL-L12-857.json','parallel-l12-20261029/PROPOSAL-L12-858.json','parallel-l12-20261029/REGISTRATION-PAR-L12-545.json','parallel-l12-20261029/REGISTRATION-PAR-L12-558.json'];s=s[:a]+'names='+repr(names)+s[b:];s=s.replace('inds=[49,65,563,588,1300,1399,1936,1939,1940,2107,2244,2251,2252,2303,2359,2705]','inds=[583,587,1474,1589,1597,1701,1739,1936,1939,1940,2107,2238,2243,2244]').replace('[2519,2520]','[2526,2527]');(p/'copy-evidence.py').write_text(s)
s=(old/'check-evidence.py').read_text().replace(str(old),str(p)).replace('[2519,2520]','[2526,2527]');a=s.index('for i in [2526,2527]:');b=s.index('\nold=json.loads',a);s=s[:a]+'''for i in [2526,2527]:
 a=[z for z in reg['sources'] if z['original_role']==i];assert len(a)==2 and a[0]['sha256']==r['files'][i]['sha256'];assert a[0]['base_path_bytes_equal'] is True
 if i==2526: assert a[0]['sha256']!=a[1]['sha256'] and a[0]['lines']==262 and a[1]['lines']==270
 else: assert a[0]['sha256']==a[1]['sha256'] and (p/a[0]['archive']).read_bytes()==(p/a[1]['archive']).read_bytes()
''' +s[b:];(p/'check-evidence.py').write_text(s)
