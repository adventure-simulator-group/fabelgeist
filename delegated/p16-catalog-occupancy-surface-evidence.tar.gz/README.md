# Bounded P16 catalogue occupancy and surface evidence

Original registry roles 2585 and 2586 are historical `physical-p16` dirty
snapshot source objects. `a120390947c89b703dc74c4255a13c035d054c50` is the
base, not a dirty-snapshot commit; each assigned object separately equals its
base file. `f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports archived
objects and historical records. Current source is pinned to
`95e63628f9d70b8dd6e6fede64334696c6995009`.

Start with `REPORT.json`, then `registration.json`, the separately scoped
support registrations and `personal-read-receipt.json`. The reconstructed
registry and queue selections are explicitly labeled; recovered original 059
and 774 evidence keeps the original attribution, revision and read limits.
Raw Git tree/commit proof objects and all selected source bytes are preserved.
Original 774 JSONL records stored as `.gz` decompress to exact original bytes.

The tracked P16 patch was later recovered and matches the original registry
hash. Seven untracked paths remain separate archived objects; neither matching
hashes nor per-file base equality establish historical custody, clean snapshot
status, or checkpoint 3821 restoration. Published complete supporting evidence
is hash-linked in `published-references.json` without copying large archives.

Run `python3 verify-evidence.py` for evidence identity and scope checks and
`python3 verify-manifest.py` for packet integrity. These checks need the
published audit repository at its recorded local path and do not run product
code. No repair, build, test, simulation, viewer, probe, or product validation
was performed. Thirteen perspectives cover only this bounded scope and do not
claim whole-lens clearance.
