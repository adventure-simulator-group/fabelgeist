from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for name,ranges in [('support/current-0.rs',[[1,45]]),('support/current-1.rs',[[1,89]])]:
 raw=(p/name).read_bytes();rows.append({'revision':'95e63628f9d70b8dd6e6fede64334696c6995009','source_archive':name,'sha256':sha(raw),'actual_EOF':len(raw.splitlines()),'registered_ranges':ranges,'purpose':'Diagnostic cap and document/schema serde entry declarations only.'})
r={'schema':'726-catalog-validation-support3-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','sources':rows,'qualification':'Additional bounded current support only; no uninspected body coverage.'};(p/'support3-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((p/'support3-registration.json').read_bytes()))
