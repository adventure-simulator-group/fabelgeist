from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
old=Path('<LOCAL_PATH_0>')
pub=Path('<LOCAL_PATH_1>')
sha=lambda x:hashlib.sha256(x).hexdigest()
oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
rpath='recovered/original-registry-source-archive/registry.json.gz';mpath='recovered/original-transport-manifest.json.gz';r=json.load(gzip.open(pub/rpath,'rt'))
sel={'schema':'726-registry-selection-reconstructed-v1','qualification':'Reconstructed exact selections from original registry, not an original standalone record, current source or checkpoint 3821. P16 head is base of a dirty snapshot, not dirty commit.','original_registry_sha256_uncompressed':sha(gzip.decompress((pub/rpath).read_bytes())),'rows':[{'original_index':i,**r['files'][i]} for i in (2585,2586)],'snapshots':[x for x in r['snapshots'] if x['id']=='physical-p16']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n')
q=json.loads((pub/'baseline-059/queue.json').read_bytes());wanted=['L12-CLOSURE-CATALOG-TYPED-ADMISSION-RESULT']; selected=[{'original_index_zero_based':i,'entry':e} for i,e in enumerate(q['entries']) if e.get('contract_id') in wanted]
(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-queue-selection-reconstructed-v1','qualification':'059 historical record selection; no current source/read/status credit','entries':selected,'requested_missing':[n for n in wanted if not any(x['entry'].get('contract_id')==n for x in selected)]},indent=2)+'\n')
m=json.load(gzip.open(pub/mpath,'rt'));idx={e['path']:e for e in m['entries']};paths=[]
for lens,n in [(11,424),(12,877)]:
 for k in ['READ','VERIFY','STATE']:paths.append(f'segovb/{k}-L{lens}-{n}.json')
for k in ['READ','VERIFY','STATE']:paths.append(f'segovb/{k}-L12-CONNECTED-TEAM-021.json')
paths += ['segovb/REGISTRATION-SEGOVB-1496.json','segovb/REGISTRATION-SEGOVB-1497.json','segovb/REGISTRATION-SEGOVB-L12-877.json','parallel-l12-20261029/REGISTRATION-PAR-L12-636.json','parallel-l12-20261029/REGISTRATION-PAR-L12-637.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-636-WINDOWS-ORIGINAL2585.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-637-WINDOWS-ORIGINAL2586.json','parallel-l12-20261029/PROPOSAL-L12-877.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-TEAM021-COMPLETED-SOURCE-VIEWS-v2.json','parallel-l12-20261029/REGISTRATION-PAR-L12-644.json','parallel-l12-20261029/REGISTRATION-PAR-L12-645.json']
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file():missing.append(p);continue
 raw=(old/p).read_bytes();e=idx[p];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(raw)==e['git_blob'];dst=b/'historical-059'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records.append({'original_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
prefix='handoff/774/adler-original/audit/continuation/rig/admission03/';paths774=[prefix+n for n in ['source-range-registration.jsonl','source-qualifications-final-current.jsonl','catalogue-helper-admission-002.json','catalogue-reconciliation-003.json']]
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records774=[]
for p in paths774:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+p]);assert oid(raw)==subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+p],text=True).strip();dst=b/'historical-774'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records774.append({'transport_revision':rev,'transport_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
refs=[]
for p in [rpath,mpath,'baseline-059/queue.json','baseline-059/ledger.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','recovered/physical-p16-patch-recovery/tracked.patch','recovered/physical-p16-patch-recovery/live-comparison-redacted.json','recovered/original-registry-source-archive/objects.tar.gz','ASSESSMENT-EQUIPMENT-TOPOLOGY-95E.json','ASSESSMENT-L01-INVENTORY-BOUNDARIES-95E.json','ASSESSMENT-L01-HISTORICAL-937-947.json']:
 raw=(pub/p).read_bytes();refs.append({'repository_relative_path':p,'sha256':sha(raw),'bytes':len(raw),'qualification':'Previously published evidence; original author/revision and unread scopes remain theirs.'})
(b/'published-references.json').write_text(json.dumps({'schema':'726-published-evidence-hash-links-v1','repository':'audit baseline publication','created_utc':datetime.now(timezone.utc).isoformat(),'entries':refs,'qualification':'Hash links to previously preserved complete evidence; verification requires publication repository. Patch recovered later and preserves historical snapshot, not 3821.'},indent=2)+'\n')
out={'schema':'726-original-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'original_059_records':records,'older_774_receipts':records774,'published_references':'published-references.json','missing_originals':missing,'qualification':'Historical recovered bytes, reconstructed selections, and current work retain revision, attribution, and read scopes. No promotion to checkpoint 3821.'}
(b/'original-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('059',len(records),'774',len(records774),'missing',missing,'published refs',len(refs))
