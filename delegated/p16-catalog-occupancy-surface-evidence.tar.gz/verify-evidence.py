from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,sys
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>')
sha=lambda x:hashlib.sha256(x).hexdigest()
def oid(t,x):return hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def load(n):return json.loads((b/n).read_bytes())
reg=load('registration.json');rr=load('personal-read-receipt.json');at=load('original-attribution.json');comp=load('historical-774-compressed-attribution.json');gp=load('git-proofs.json');rep=load('REPORT.json');r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));snap=next(x for x in r['snapshots'] if x['id']=='physical-p16')
assert len(snap['status_porcelain'])==159 and snap['base']=='a120390947c89b703dc74c4255a13c035d054c50'
assert sha((pub/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes())==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
assert len((pub/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes())==524542
for i in (2585,2586):
 e=r['files'][i];old=next(x for x in reg['entries'] if x['original_index']==i and x['transport_path']);cur=next(x for x in reg['entries'] if x['original_index']==i and not x['transport_path']);raw=(b/old['source_archive']).read_bytes();assert e['sha256']==old['sha256']==sha(raw) and e['bytes']==len(raw) and len(raw.splitlines())==e['actual_line_count'];assert not any(s[3:]==old['path'] for s in snap['status_porcelain']);assert any(x['revision']==old['revision'] and x['path']==old['path'] and x['sha256']==sha(raw) for x in gp['paths']);assert any(x['revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' and x['path']==old['transport_path'] and x['sha256']==sha(raw) for x in gp['paths']);assert any(x['revision']==cur['revision'] and x['path']==cur['path'] and x['sha256']==cur['sha256'] for x in gp['paths'])
for e in load('published-references.json')['entries']:
 raw=(pub/e['repository_relative_path']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],e['repository_relative_path']
m=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));mi={e['path']:e for e in m['entries']}
assert not at['missing_originals']
for e in at['original_059_records']:
 raw=(b/e['preserved_bytes']).read_bytes();x=mi[e['original_path']];assert len(raw)==e['bytes']==x['bytes'] and sha(raw)==e['sha256']==x['sha256'] and oid('blob',raw)==e['git_blob']==x['git_blob']
for e in at['older_774_receipts']:
 raw=(b/e['preserved_bytes']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
for e in comp['records']:
 raw=gzip.decompress((b/e['preserved_gzip']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
objects={}
for key,e in gp['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,c in gp['commits'].items():assert objects[rev].splitlines()[0]==b'tree '+c['root_tree'].encode()
for p in gp['paths']:
 raw=(b/p['preserved_bytes']).read_bytes();raw=gzip.decompress(raw) if p['preserved_bytes'].endswith('.gz') else raw
 assert sha(raw)==p['sha256'] and len(raw)==p['bytes'] and oid('blob',raw)==p['git_blob'];cur=gp['commits'][p['revision']]['root_tree'];assert [x['name'] for x in p['path_chain']]==p['path'].split('/')
 for step in p['path_chain']:
  assert step['tree']==cur and entries(objects[cur])[step['name']]==(step['mode'],step['object']);cur=step['object']
 assert cur==p['git_blob']
for x in rr['registrations']:
 assert sha((b/x['path']).read_bytes())==x['sha256'];t=json.loads((b/x['path']).read_bytes())['registered_utc'];assert datetime.fromisoformat(t)<datetime.fromisoformat(rr['recorded_utc'])
for e in rr['assigned_personal_reads']+rr['support_personal_reads']:
 raw=(b/e['source_archive']).read_bytes();assert sha(raw)==e['sha256'] and len(raw.splitlines())==e['actual_eof'];assert all(1<=a<=z<=e['actual_eof'] for a,z in e['display_chunks']);assert all(any(a<=c<=d<=z for a,z in e['displayed_ranges']) for c,d in e['display_chunks'])
# Every report source reference must fall in this reviewer's actual displayed ranges.
reads=rr['assigned_personal_reads']+rr['support_personal_reads']
def walk(x):
 if isinstance(x,dict):
  if 'source_archive' in x and 'line_range' in x:
   a,z=x['line_range'];assert sha((b/x['source_archive']).read_bytes())==x['sha256']; covered={i for e in reads if e['source_archive']==x['source_archive'] for k,j in e['displayed_ranges'] for i in range(k,j+1)};assert all(i in covered for i in range(a,z+1)),x
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(rep)
lenses=[e['lens'] for e in rep['lens_perspectives']];assert len(lenses)==13 and len(set(lenses))==13
q=load('queue-selection-reconstructed.json');assert not q['requested_missing'] and q['entries'][0]['original_index_zero_based']==2433 and q['entries'][0]['entry']['contract_id']=='L12-CLOSURE-CATALOG-TYPED-ADMISSION-RESULT'
assert (b/'source/2586-historical.rs').read_bytes()==(b/'source/2586-current.rs').read_bytes();assert (b/'source/2585-historical.rs').read_bytes()!=(b/'source/2585-current.rs').read_bytes()
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','checks':['Original registry selections and P16 status/snapshot qualification','Recovered tracked patch length and original SHA','Published hash-linked evidence bytes','059 original transport manifest byte counts, SHA-256 and Git blob IDs','774 exact original and compressed record identities','Offline raw commit and tree chains, assigned sources and supporting bodies','Separate personal read registrations, scopes, uninspected complements and report citation coverage','Thirteen bounded lenses, historical queue index, old/current role identities'],'limits':'Cryptographic checks verify preserved evidence and registration/receipt consistency, not independent proof that a person read the source, complete product reachability, product behavior, whole-lens completion, or uninterrupted historical custody. No tests or product validation.'}
if '--record' in sys.argv:(b/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: evidence consistency, offline Git membership, scopes and historical links; no product executed')
