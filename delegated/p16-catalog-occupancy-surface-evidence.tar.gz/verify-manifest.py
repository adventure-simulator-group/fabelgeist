from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent;m=json.loads((b/'MANIFEST.json').read_bytes());expected={e['path']:e for e in m['files']};actual={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and str(p.relative_to(b))!='MANIFEST.json'};assert actual==set(expected),(actual-set(expected),set(expected)-actual)
for p,e in expected.items():
 raw=(b/p).read_bytes();assert len(raw)==e['bytes'] and hashlib.sha256(raw).hexdigest()==e['sha256'],p
print('PASS',len(expected),'packet files; manifest sha256',hashlib.sha256((b/'MANIFEST.json').read_bytes()).hexdigest())
