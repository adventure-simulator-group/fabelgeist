from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,re
b=Path('<LOCAL_PATH_0>')
sha=lambda x:hashlib.sha256(x).hexdigest()
patterns={
 'absolute_home_path':re.compile(rb'<LOCAL_PATH_1>'),
 'private_key_header':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
 'github_token_shape':re.compile(rb'\b(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b'),
 'credential_assignment_shape':re.compile(rb'(?i)(?:api[_-]?key|access[_-]?token|secret)[ \t]*[:=][ \t]*["\x27][A-Za-z0-9_./+=-]{12,}["\x27]')}
scan={k:[] for k in patterns}; skipped=[]
for p in sorted(b.rglob('*')):
 if not p.is_file() or p.name in ['MANIFEST.json','PATH-AND-CREDENTIAL-SCAN.json']: continue
 if p.suffix in ('.gz','.crate'): skipped.append(str(p.relative_to(b)));continue
 raw=p.read_bytes()
 for name,pat in patterns.items():
  if pat.search(raw): scan[name].append(str(p.relative_to(b)))
scan_record={'schema':'726-evidence-publication-preflight-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'method':'Pattern scan reports matching filenames only, does not print matched text; compressed original artifacts skipped to preserve exact bytes. It is not a full secret or privacy review. Full historical source and records may contain personal paths or attribution and need central publication review.','matching_filenames':scan,'compressed_files_not_scanned':skipped}
(b/'PATH-AND-CREDENTIAL-SCAN.json').write_text(json.dumps(scan_record,indent=2)+'\n')
files=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':
  raw=p.read_bytes();files.append({'path':str(p.relative_to(b)),'bytes':len(raw),'sha256':sha(raw)})
m={'schema':'726-p17-continuity-evidence-manifest-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'self_excluded':True,'qualification':'Lists exact original historical evidence, explicitly reconstructed selection, newly assessed report, registered current and historical bodies, Git identity proofs and audit helper scripts. MANIFEST is excluded to avoid self-reference. No product behavior was run or verified.','files':files}
(b/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
print('manifest files',len(files),'scan filename counts',{k:len(v) for k,v in scan.items()},'compressed excluded from scan',len(skipped))
print('MANIFEST sha256',sha((b/'MANIFEST.json').read_bytes()))
print('REPORT sha256',sha((b/'REPORT.json').read_bytes()))
