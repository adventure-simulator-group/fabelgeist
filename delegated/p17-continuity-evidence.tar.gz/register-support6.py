from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');old='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696';cur='95e63628f9d70b8dd6e6fede64334696c6995009';plan={old:['crates/adventuresim-tactical-core/src/animation/measurement.rs','crates/adventuresim-tactical-core/src/animation/authored_angle.rs'],cur:['crates/adventuresim-tactical-client/src/animation_viewer/capture/root_motion.rs']};entries=[];pending=[]
for rev,paths in plan.items():
 for p in paths:
  raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_maximum_range':[1,len(raw.splitlines())],'scope':'bounded finite-admission and native root source support only'});pending.append((rev,p,raw))
r={'schema':'726-p17-continuity-prospective-support-v6','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','purpose':'Trace checked historical derived measures and local current native ground admission.','entries':entries};(b/'support6-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for rev,p,raw in pending:
 d=b/'support'/rev[:4]/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support6 SHA',hashlib.sha256((b/'support6-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
