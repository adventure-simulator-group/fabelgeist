from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';pre='crates/adventuresim-tactical-client/src/animation_viewer/';paths=[pre+'report/mod.rs',pre+'scenarios.rs'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_maximum_range':[1,len(raw.splitlines())],'scope':'bounded source support, no ordered-role credit'});pending.append((p,raw))
r={'schema':'726-p17-continuity-prospective-support-v2','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','purpose':'Qualify current actual plan/required-bone/terminal report gates, not infer runtime results.','entries':entries};(b/'support2-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'support'/'95e6'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support2 SHA',hashlib.sha256((b/'support2-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
