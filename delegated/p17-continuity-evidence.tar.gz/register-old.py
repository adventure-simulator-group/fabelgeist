from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');r=json.load(gzip.open('<LOCAL_PATH_1>','rt'))['files'];rev='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696';entries=[];pending=[]
for i in [2448,2449]:
 p=r[i]['path'];raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();actual=subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();assert sha==r[i]['sha256'] and len(raw)==r[i]['bytes'] and blob==actual,(i,sha,blob,actual);entries.append({'original_role':i,'revision':rev,'original_source_id':r[i]['source_id'],'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'planned_personal_body_ranges':[[1,len(raw.splitlines())]],'qualification':'Raw object SHA256, byte count and Git blob ID independently match original report-p17 registry; 90a is the recorded original snapshot head. Full prospective old-source body read only; old reviewers retain separate attribution.'});pending.append((p,raw))
r={'schema':'726-report-p17-prospective-old-source-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity, report-p17 capture','registration':'Before report-p17 source display or current-revision comparison; exact original registry hashes checked independently.','entries':entries};(b/'old-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'sources'/'90a4'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('old registration sha256',hashlib.sha256((b/'old-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
