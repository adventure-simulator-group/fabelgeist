import datetime,hashlib,io,json,pathlib,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');h=p/'historical-059';H=lambda b:hashlib.sha256(b).hexdigest()
def check(n,sha):
 n=n.replace('\\','/').removeprefix('target/726-audit-adler-20261027/');assert H((h/n).read_bytes())==sha,n
x=json.loads((h/'segovb/READ-L11-416.json').read_text());rows=[r for r in x['sources'] if r['original_index'] in [2513,2514]];assert len(rows)==2
for r in rows:
 assert not r['fresh_personal_body_reads'];check(r['registration'],r['registration_sha256']);q=r['same_lens_prior'];check(q['receipt'],q['receipt_sha256']);check(q['entry']['registration'],q['entry']['registration_sha256'])
x=json.loads((h/'segovb/READ-L12-853.json').read_text());check(x['proposal'],x['proposal_sha256']);assert not x['root_personal_rereads'];rows=[r for r in x['rows'] if r['original_index'] in [2513,2514]];assert len(rows)==2
for r in rows:check(r['registration'],r['registration_sha256'])
m=json.loads((h/'parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-851-853.json').read_text())
for r in m['proposals']:
 if r.get('batch')==853:check(r['path'],r['sha256'])
idx=json.loads((p/'prior-packets-index.json').read_text());count=0
for a in idx['packets']:
 b=(p/a['archive']).read_bytes();assert H(b)==a['sha256'] and len(b)==a['bytes'] and a['upstream_manifest_verified']
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:
  rows={x['path']:x for x in a['entries']};assert set(t.getnames())==set(rows)
  for n,x in rows.items():
   v=t.extractfile(n).read();assert len(v)==x['bytes'] and H(v)==x['sha256'];count+=1
result={'schema':'726-evidence-link-verification-v1','status':'passed','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'059 inherited L11 registration, adler historical receipts and prospective registration hashes, L12 proposal and delegated registrations, full prior packet archive inventory and bytes.','prior_packet_members':count,'scope':'Evidence-only, no product/runtime verification.'};(p/'evidence-links-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
