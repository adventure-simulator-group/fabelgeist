#!/usr/bin/env python3
"""Read-only evidence verification: hashes, Git membership, provenance and scopes only."""
import gzip,hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['at'] and len(receipt['reads'])==2
for x in receipt['reads']:
 b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof'];covered=set()
 for a,z in x['actual_display_ranges']:covered.update(range(a,z+1))
 assert covered==set(range(1,x['eof']+1)) and not x['unread_ranges']
 assert any(o['revision']==x['revision'] and o['sha256']==x['sha256'] and o['local_file']==x['source_file'] for row in r['rows'] for o in row['objects'])
for row in r['rows']:assert row['objects'][0]['sha256']==row['registry_entry']['sha256']==row['objects'][1]['sha256']
checks.append('Two separately registered personally displayed full old/current bodies and per-file hash identity')
for n in ('','-02','-03','-04','-05'):
 sr=load('support-registration'+n+'.json');s=load('support-read-receipt'+n+'.json');assert s['registration_sha256']==sha((p/('support-registration'+n+'.json')).read_bytes()) and sr['at']<s['at']
 for x in s['reads']:
  b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof']
  assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['prospective_ranges']==x['actual_ranges'] and y['file']==x['source_file'] for y in sr['rows'])
checks.append('Thirteen support source ranges were registered before their corresponding actual displays; unread ranges and navigation caveats remain explicit')
arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==r['registry_uncompressed_sha256'];registry=json.loads(orig)
 trans=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in trans['entries']}
for x in r['rows']:assert x['registry_entry']==registry['files'][x['original_index']]
for x in load('historical-index.json')['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original registry entries and nine recovered 059 records verified against published original-transport manifest; six 774 bytes preserved')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==23
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('23 raw commit/tree/blob membership chains establish 6533, 95e and f82 transport identity, including historical support identity without read credit')
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14))
for x in report['support_reads']:
 cov=set()
 for a,z in x['actual_ranges']:cov.update(range(a,z+1))
 missing=set()
 for a,z in x['unread_for_this_registration']:missing.update(range(a,z+1))
 assert not cov.intersection(missing) and cov.union(missing)==set(range(1,x['eof']+1))
old=gzip.decompress((p/'history-774/additional-contracts.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[71])['id']=='RIG-ADMISSION03-ADDITIONAL-086'
old=gzip.decompress((p/'history-774/initial06-type-ownership-findings.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[2])['id']=='RIG-INITIAL06-F003'
assert gzip.decompress((p/'history-774/findings.jsonl.gz').read_bytes())==gzip.decompress((p/'history-774/initial06-type-ownership-findings.jsonl.gz').read_bytes())
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());assert queue['entries'][614]['contract_id']=='Q-L11-311564a4d1d7c857a062' and queue['entries'][3438]['contract_id']=='L12-CLOSURE-GARMENT-POSE-PANEL-IDENTITY-SCOPE'
assert sha((pub/'ASSESSMENT-GEOMETRY-OWNERS-95E.json').read_bytes())=='c26745e0fd5678fa5a45833ff0aca5a79d86bf6611087b024616ccf534f9ca9c' and sha((pub/'ASSESSMENT-GARMENT-FIT-95E.json').read_bytes())=='dee9866a5c7b74847fa7baaacaf81cf4c6100642c770051931ccfee548453502'
lang=load('reference/language.json');b=gzip.decompress((p/lang['archive']).read_bytes());assert (len(b),sha(b))==(lang['bytes'],lang['sha256']) and b'will saturate to the maximum value of the integer type' in b
recovery=json.loads((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes());assert sha((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007' and sha((pub/recovery['recovered_patch']['path']).read_bytes())==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
checks.append('13 scoped perspectives, exact support complements, historical ADD-086/F003, queue and previous assessments, preserved Rust reference, P16 patch and rule copies')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and accountancy only. No product execution, testing, build, probe, simulation, rendering, implementation, publication edit, whole-lens closure or checkpoint3821 promotion.'},indent=2))
