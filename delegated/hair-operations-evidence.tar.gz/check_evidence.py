import hashlib,json,pathlib
root=pathlib.Path('<LOCAL_PATH_0>')
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
reg=json.loads((root/'registration.json').read_text())
for r in reg['ordered_roles']:
 b=(root/'source'/pathlib.Path(r['path']).name).read_bytes()
 assert (sha(b),blob(b),len(b),b.count(b'\n'))==(r['sha256'],r['git_blob'],r['bytes'],r['lines'][1]),r['path']
for n in (1,2,3,4):
 p=root/('support-registration-%02d.json'%n); d=json.loads(p.read_text())
 for r in d['registered_sources']:
  name=pathlib.Path(r['path']).name
  if r['path'].endswith('/look/groom.rs'): name='look-groom.rs'
  b=(root/'source'/('support-'+name)).read_bytes()
  assert (sha(b),blob(b),len(b),b.count(b'\n'))==(r['sha256'],r['blob'],r['bytes'],r['range'][1]),r['path']
manifest=json.loads((root/'historical-manifest.json').read_text())
for r in manifest['records']:
 b=(root/r['copy_path']).read_bytes()
 assert (sha(b),blob(b),len(b))==(r['sha256'],r['git_blob'],r['bytes']),r['copy_path']
report=json.loads((root/'report.json').read_text())
assert report['registration']['sha256']==sha((root/'registration.json').read_bytes())
assert report['historical_copy_manifest']['sha256']==sha((root/'historical-manifest.json').read_bytes())
for r in report['support_registration_and_actual_personal_read_scope']:
 assert r['registration_sha256']==sha((root/r['registration']).read_bytes())
print('Evidence integrity passed: 3 scoped source objects, 11 support source objects, 27 historical copies, registrations and report. No product build, test, algorithm or runtime probe ran.')
