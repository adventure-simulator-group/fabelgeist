import gzip,hashlib,json,pathlib
root=pathlib.Path('<LOCAL_PATH_0>')
pub=pathlib.Path('<LOCAL_PATH_1>')
out=pathlib.Path('<LOCAL_PATH_2>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f: manifest=json.load(f)
entries={e['path']:e for e in manifest['entries']}
paths=['adler/READ-L11-368.json','adler/STATE-L11-368.json','adler/VERIFY-L11-368.json','adler/REGISTRATION-ADLER-1160.json','adler/REGISTRATION-ADLER-1161.json','adler/REGISTRATION-ADLER-1162.json','adler/REGISTRATION-ADLER-1168.json','segovb/READ-L12-757.json','segovb/READ-L12-758.json','segovb/REGISTRATION-SEGOVB-L12-757.json','segovb/REGISTRATION-SEGOVB-L12-758.json','segovb/VERIFY-L12-757.json','segovb/VERIFY-L12-758.json','parallel-l12-20261029/REGISTRATION-PAR-L12-260.json','parallel-l12-20261029/REGISTRATION-PAR-L12-261.json','parallel-l12-20261029/REGISTRATION-PAR-L12-262.json','parallel-l12-20261029/PROPOSAL-L12-757.json','parallel-l12-20261029/PROPOSAL-L12-758.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-757-760.json','parallel-l11-20261029/READ-077.json','segovb/READ-L11-613.json','segovb/READ-L11-432.json','segovb/READ-L12-912.json','parallel-l12-20261029/PROPOSAL-L12-912.json','evidence/continuation-segovb/audit-resume-20261027/lens08/batch-097-hair-shell-particle-and-pose-contracts.json','evidence/continuation-segovb/audit-resume-20261027/REGISTRATION-139-derived-admission-native-receivers.json','evidence/audit05/inherited-original05-packets/contract-groups-024.json']
rows=[]
for p in paths:
 b=(root/p).read_bytes(); e=entries[p]; s=hashlib.sha256(b).hexdigest(); blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert (s,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),p
 dst=out/'historical'/p; dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists(): assert dst.read_bytes()==b,p
 else: dst.write_bytes(b)
 rows.append({'original_transport_path':p,'bytes':len(b),'sha256':s,'git_blob':blob,'copy_path':'historical/'+p,'qualification':'Exact recovered transport bytes, not checkpoint3821 or new personal read.'})
report={'schema':'delegated-recovered-historical-evidence-v1','transport_manifest':'recovered/original-transport-manifest.json.gz','evidence_only':True,'qualification':'Exact byte copies from the user-provided read-only extraction, each checked against the original transport manifest SHA-256, byte length and Git blob. Historical source revision and agent attribution stay as stated in each receipt. These copied originals may contain nonessential local paths; review and redact before public publication, preserving the original hash and redaction metadata.','records':rows}
(out/'historical-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print('verified and copied',len(rows),'original records')
print('manifest sha256',hashlib.sha256((out/'historical-manifest.json').read_bytes()).hexdigest())
