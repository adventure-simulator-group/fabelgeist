import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def missing(n,r):
 seen={i for a,z in r for i in range(a,z+1)};out=[]
 for i in sorted(set(range(1,n+1))-seen):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for reg,out in [('registration.json','read-receipt.json'),('support-registration.json','support-read-receipt.json')]:
 x=json.loads((p/reg).read_bytes());rows=[]
 for e in x['entries']:rows.append({'archive':e['archive'],'sha256':e['sha256'],'displayed_chunks':e['registered_ranges'],'unread_complement':missing(e['EOF'],e['registered_ranges'])})
 (p/out).write_text(json.dumps({'author':'/root/mhr_character','receipt_utc':now,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':rows,'qualification':'Independently displayed untruncated numbered scopes after registration; no borrowed source-read or other-lens credit. support config 710–745 contains test source only, never executed.'},indent=2)+'\n')
