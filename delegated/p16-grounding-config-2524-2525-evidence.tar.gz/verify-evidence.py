import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and [x['index'] for x in sel['rows']]==[2524,2525] and all(x['row']==reg['files'][x['index']] for x in sel['rows']);snap=next(z for z in reg['snapshots'] if z['id']=='physical-p16');assert snap==sel['snapshot'] and snap['head']=='a120390947c89b703dc74c4255a13c035d054c50';patch=(p/'reference/p16-tracked.patch').read_bytes();assert sha(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256'],e['file']
regn=load('registration.json')
for x in regn['comparisons']:
 assert x['p16_equals_base'] and x['p16_equals_current'] and x['base_equals_current'];assert not [z for z in snap['status_porcelain'] if z[3:]==x['path']];assert f"diff --git a/{x['path']} b/{x['path']}\n".encode() not in patch
for label,rf,tf in [('assigned','registration.json','read-receipt.json'),('support','support-registration.json','support-read-receipt.json')]:
 a=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes()) and datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(a['registered_utc']);assert len(a['entries'])==len(t['entries'])
 for e,v in zip(a['entries'],t['entries']):
  b=(p/e['archive']).read_bytes();assert sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'] and e['archive']==v['archive'];planned={i for lo,hi in e['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in v['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in v['unread_complement'] for i in range(lo,hi+1)};assert planned==seen and seen|missing==set(range(1,e['EOF']+1)) and not seen&missing
  if e.get('label')=='historical-p16':assert reg['files'][e['role']]['sha256']==e['sha256'] and reg['files'][e['role']]['material_ranges']==e['original_material_ranges']
 counts[label]=len(a['entries'])
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']}
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=json.loads(qraw);x=load('queue-selection-reconstructed.json');assert x['source_sha256']==sha(qraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for n in (588,603):
 x=load(f'history-059/segovb/READ-L12-{n}.json');assert x['plan_sha256']==sha((p/'history-059'/x['plan']).read_bytes());row=x['rows'][0];assert row['registration_sha256']==sha((p/'history-059'/row['registration']).read_bytes())
x=load('history-059/segovb/READ-L12-603.json');reuse=x['qualified_supporting_same_lens_reuse'][0];assert reuse['receipt_sha256']==sha((p/'history-059'/reuse['receipt']).read_bytes()) and reuse['assessed_ranges']==[[1,407]] and reuse['fresh_personal_body_reads_this_batch']==[]
for n in ('029','071'):
 x=load(f'history-059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-{n}.json');assert x['registration_sha256']==sha((p/'history-059'/x['registration']).read_bytes())
assert load('history-059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-029.json')['rows'][2]['fresh_personal_body_ranges']==[[1,26]] and load('history-059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-071.json')['rows'][0]['fresh_personal_body_ranges']==[[73,110]]
def lines(f):return [json.loads(z) for z in gzip.decompress((p/f).read_bytes()).splitlines()]
rig=lines('history-774/continuation/rig/owner-reached-producer-followup/additional-sources.jsonl.gz')[37];qual=lines('history-774/continuation/rig/owner-reached-producer-followup/source-qualifications.jsonl.gz')[37];cam=lines('history-774/continuation/camera/owner-reached-producer-followup/source-range-registration.jsonl.gz')[11];assert rig['id']=='RIG-OWNER-REACHED-PRODUCER-REGISTER-038' and rig['snapshot']=='p16' and rig['sha256']==reg['files'][2524]['sha256'] and rig['material_ranges']==[[68,110]];assert qual['qualified_material_ranges']==[[73,86],[104,110]] and qual['registration_id']==rig['id'];assert cam['id']=='CONT-CAMERA-PP-FOLLOWUP-LOCAL-REGISTRATION-012' and cam['snapshot']=='physical-p16' and cam['sha256']==reg['files'][2525]['sha256'] and cam['ranges']==[[1,26]]
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==18 and len(report['lens_perspectives'])==13 and len({z['lens'] for z in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'qualification':'Offline evidence integrity only; no product, source test, fixture, config, macro or runtime execution.'},indent=2))
