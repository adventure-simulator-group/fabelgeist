# Bounded P16 city compound and gate evidence

This packet contains /root/rig_identity's bounded audit of original roles 2522
and 2523, separately registered P16 recovered and pinned 95e current bodies,
bounded current supports, thirteen perspectives, and conditional findings.
Start with `REPORT.json`, `registration.json`, and `personal-read-receipt.json`.

The P16 registry records a dirty snapshot based at a120. The f82 Git objects
are transport for recovered bytes. Both assigned objects match individual files
at a120, 6533, and 95e; the original dirty patch bytes remain unrecovered, and
this equality does not establish the state of the entire snapshot.

`historical-059/` and `historical-774/` contain exact historical records. The
registry and queue selections are explicitly reconstructed, not original
records. `published-references.json` hash-links the complete registry, manifest,
queue, ledger, and earlier published gate assessments already present in the
central audit publication repository. `prior-delegate/` preserves exact earlier
reports, manifests, and personal receipts without duplicating the full packets.
Historical evidence retains its original attribution and does not become work at
checkpoint 3821.

`git-proofs.json` and `git-objects/` provide raw commit/tree inclusion chains;
`evidence-verification.json` checks evidence hashes, linked publication sources,
read scopes, and citations only. `MANIFEST.json` inventories the packet. Run
`python3 verify-manifest.py` on the frozen packet. Run `python3 verify-evidence.py
/path/to/publication` on a copied packet to repeat structural checks: it rewrites
that copy's verification timestamp. No implementation, repair, build, test,
fixture, UI, simulation, product execution, runtime probe, or product validation
was performed.
