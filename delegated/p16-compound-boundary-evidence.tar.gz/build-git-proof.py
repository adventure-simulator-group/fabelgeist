import gzip,hashlib,json,pathlib,subprocess
b=pathlib.Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();cur=root(rev);chain=[]
 for segment in path.split('/'):
  mode,child=entries(save('tree',cur))[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
rows=json.load(open(b/'registration.json'))['entries']
for e in rows:proof(e['transport_revision'],e['transport_path'],e['source_archive'],'P16 recovered archive object transport only' if e['source_identity']=='physical-p16 dirty snapshot' else 'pinned current assigned file')
for e in rows:
 if e['source_identity']=='physical-p16 dirty snapshot':
  for rev,tag in [('a120390947c89b703dc74c4255a13c035d054c50','recorded clean base exact file only'),('6533e444fa37552927070cc8d8190907fd3b413e','earlier PR file used by L11 same-lens proof')]:proof(rev,e['path'],e['source_archive'],tag)
for n in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json']:
 for e in json.load(open(b/n))['entries']:
  proof(e['revision'],e['path'],e['source_archive'],'bounded current support or rule')
for e in json.load(open(b/'original-attribution.json'))['older_774_receipts']:proof(e['transport_revision'],e['transport_path'],e['preserved_bytes'],'original 774 historical evidence transport only')
r={'schema':'726-p16-compound-boundary-git-proof-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Raw commit/tree chains prove exact file membership only. P16 is a recorded dirty snapshot; f82 is transport, a120 only base file, and original P16 patch bytes remain unrecovered.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'git-proofs.json').write_bytes(raw);print('proofs',len(proofs),'objects',len(objects),'sha',sha(raw))
