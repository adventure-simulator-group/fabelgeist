import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();r=json.loads((p/'registration.json').read_bytes());caller=json.loads((p/'caller-registration.json').read_bytes())
def collapse(nums):
 o=[]
 for i in sorted(nums):
  if not o or i>o[-1][1]+1:o.append([i,i])
  else:o[-1][1]=i
 return o
def numbers(ranges):return {i for a,b in ranges for i in range(a,b+1)}
rows=[]
for e in r['entries']:
 chunks=e['registered_ranges']
 if e['tag']=='surface-validation':chunks=[[8,85],[86,158]]
 if e['tag']=='validation':chunks=[[205,216],[249,273],[301,310],[770,815],[816,864]]
 seen=numbers(chunks);extra=[];navigation=[]
 if e['tag']=='validation':extra=caller['registered_ranges'];navigation=[24,301,313,527,546,637,1839,1886,1911];seen|=numbers(extra)|set(navigation)
 rows.append({'tag':e['tag'],'archive':e['archive'],'sha256':e['sha256'],'EOF':e['EOF'],'initial_registration_chunks':chunks,'caller_registration_chunks':extra,'prospectively_registered_navigation_singletons':navigation,'all_personally_displayed_union':collapse(seen),'unread_complement':collapse(set(range(1,e['EOF']+1))-seen)})
nav=[{'registration':'navigation-registration.json','matching_lines':[313,527,637,1839,1886,1911]},{'registration':'caller-registration.json','matching_lines':[313,546,637]},{'registration':'boundary-navigation-registration.json','matching_lines':[]},{'registration':'cap-navigation-registration.json','matching_lines':[24,301]}]
for z in nav:z['registration_sha256']=sha((p/z['registration']).read_bytes())
out={'author':'/root/mhr_character','recorded_utc':now,'initial_registration':'registration.json','initial_registration_sha256':sha((p/'registration.json').read_bytes()),'caller_registration_sha256':sha((p/'caller-registration.json').read_bytes()),'navigation':nav,'entries':rows,'qualification':'Exact actual independent untruncated displayed windows and singleton search hits after respective prospective registrations; unprinted file bodies and metadata scans confer no reading credit. Prior P16 and current delegate reads remain separately attributed. Search may expose test-source lines but no test executed.'};(p/'read-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
