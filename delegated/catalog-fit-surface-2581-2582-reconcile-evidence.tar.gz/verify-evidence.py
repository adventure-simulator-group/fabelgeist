import datetime,gzip,hashlib,json,pathlib,re
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(v==reg['files'][int(k)] for k,v in sel['roles'].items()) and sel['physical_p16_snapshot']==next(s for s in reg['snapshots'] if s['id']=='physical-p16')
for i in (2581,2582):assert reg['files'][i]['snapshot']=='physical-p16' and sha((p/f'source/p16-{i}.rs').read_bytes())==reg['files'][i]['sha256']
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256']
patch=(p/'reference/tracked.patch').read_bytes();recovery=load('reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert sha(patch)==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(patch)==recovery['recovered_patch']['bytes'] and recovery['live_comparison']['status_counts']['??']==7
lines=(p/'source/validation.rs').read_text().splitlines();assert [i for i,line in enumerate(lines,1) if re.search(r'fn validate_item|validate_equipment\(',line)]==[313,527,637,1839,1886,1911]
assert [i for i,line in enumerate(lines,1) if 300<=i<=650 and re.search(r'(?:^|\s)(?:fn|pub fn) ',line)]==[313,546,637]
assert [i for i,line in enumerate(lines,1) if 651<=i<=864 and re.search(r'(?:^|\s)(?:fn|pub fn) ',line)]==[]
assert [i for i,line in enumerate(lines,1) if 'MAX_DIAGNOSTICS' in line]==[24,301]
r=load('registration.json');t=load('read-receipt.json');caller=load('caller-registration.json');assert t['initial_registration_sha256']==sha((p/'registration.json').read_bytes()) and t['caller_registration_sha256']==sha((p/'caller-registration.json').read_bytes());assert len(r['entries'])==len(t['entries'])==8
for nav in t['navigation']:
 regnav=load(nav['registration']);assert nav['registration_sha256']==sha((p/nav['registration']).read_bytes()) and datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(regnav['registered_utc'])
assert datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(r['registered_utc'])
def nums(rs):return {i for lo,hi in rs for i in range(lo,hi+1)}
for e,v in zip(r['entries'],t['entries']):
 b=(p/e['archive']).read_bytes();assert e['tag']==v['tag'] and sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'];assert nums(e['registered_ranges'])==nums(v['initial_registration_chunks']);extras=nums(v['caller_registration_chunks']);nav=set(v['prospectively_registered_navigation_singletons']);seen=nums(v['initial_registration_chunks'])|extras|nav;unseen=nums(v['unread_complement']);assert seen==nums(v['all_personally_displayed_union']) and seen|unseen==set(range(1,e['EOF']+1)) and not seen&unseen
 if e['tag']=='validation':assert extras==nums(caller['registered_ranges']) and nav=={24,301,313,527,546,637,1839,1886,1911}
 else:assert not extras and not nav
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());lraw=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());q=json.loads(qraw);l=json.loads(lraw);x=load('059-selection-reconstructed.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items()) and all(l['segovb_continuation']['lens12']['pending_connected_contracts'][int(i)]==v for i,v in x['journal_entries'].items())
assert all(not q['entries'][i]['exact_source_identities_and_assessed_ranges'] and not q['entries'][i]['source_receipt_contexts'] for i in (1557,1749))
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for lens,n in [('L11',424),('L12',876)]:
 read=(p/f'history-059/segovb/READ-{lens}-{n}.json').read_bytes();state=(p/f'history-059/segovb/STATE-{lens}-{n}.json').read_bytes();v=load(f'history-059/segovb/VERIFY-{lens}-{n}.json');assert v['receipt_sha256']==sha(read) and v['state_sha256']==sha(state)
read=load('history-059/segovb/READ-L11-424.json')
for e in read['sources']:
 if e['original_index'] not in (2581,2582):continue
 rel=e['registration'].split('target/726-audit-adler-20261027/',1)[1];assert e['registration_sha256']==sha((p/'history-059'/rel).read_bytes()) and e['sha256']==reg['files'][e['original_index']]['sha256']
read=load('history-059/segovb/READ-L12-876.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes()) and read['validated_bundle']['sha256']==sha((p/'history-059'/read['validated_bundle']['path']).read_bytes())
for e in read['rows']:
 if e['original_index'] not in (2581,2582):continue
 assert e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes()) and e['source_sha256']==reg['files'][e['original_index']]['sha256']
prior=load('prior-index.json');m=(p/'prior/BUNDLE-MANIFEST.json').read_bytes();assert sha(m)==prior['original_manifest_sha256']=='a8a39868a29f7682acc9fc130a265eabd7317dcb5cc20a4a26e0b9c25ee4855c';idx={e['path']:e for e in json.loads(m)['files']}
for e in prior['selected_files']:
 b=(p/'prior'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(idx[e['path']]['bytes'],idx[e['path']]['sha256'])
pub=load('reference/DELEGATED-EVIDENCE-CHECKPOINT-14.json');entry=next(z for z in pub['bundles'] if z['bundle_id']=='catalog-fit-surface');assert entry['archive_sha256']==prior['published_archive_sha256'];member=next(z for z in entry['members'] if z['path']=='report.json');assert member['original_sha256']==sha((p/'prior/report.json').read_bytes()) and member['published_sha256']==sha((p/'reference/published-prior-report.json').read_bytes()) and member['changed'] and member['original_sha256']!=member['published_sha256']
q14=load('reference/DELEGATED-CHECKPOINT-14-QUALIFICATION.json');matched=0
for z in q14['entries']:
 for rel in z['original_transport_paths']:
  c=p/'history-059'/rel
  if c.is_file():assert sha(c.read_bytes())==z['original_sha256'];matched+=1
assert matched>=1
pin=hist['qualifications'];rec=json.loads(gzip.decompress((p/'historical-774/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));rreg=gzip.decompress((p/'historical-774/rig/admission03/source-range-registration.jsonl.gz').read_bytes());rq=gzip.decompress((p/'historical-774/rig/admission03/source-qualifications.jsonl.gz').read_bytes());assert rec['input_pins'][3]['sha256']==pin['root046_rig_registration_expected']!=sha(b''.join(rreg.splitlines(keepends=True)[:35]))==pin['later_first35_sha256'];assert rec['input_pins'][4]['sha256']==pin['root046_qualification_expected']==sha(b''.join(rq.splitlines(keepends=True)[:31]))==pin['later_first31_qualification_sha256']
quals={z['registration_id_resolved']:z['original_record'] for z in rec['role_qualifications'] if z.get('supplier')=='rig' and 'registration_id_resolved' in z}
for role,n in ((2581,14),(2582,15)):
 z=quals[f'RIG-ADMISSION03-REGISTER-{n:03}'];assert z['source_id']==reg['files'][role]['source_id'] and z['actual_material_body_ranges']==z['original_ranges']==reg['files'][role]['material_ranges']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==22 and len(report['lens_perspectives'])==13 and [z['index'] for z in report['related_history']['queue_selection']]==[1557,1749]
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_source_registrations':8,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(hist['records']),'selected_queue_entries':2,'lens_perspectives':13,'qualification':'Evidence-only integrity verification: registered windows and navigation, reconstructed queue, historical original 059/774 files, dirty P16 tracked-patch identity and seven-path exclusion, prior manifest/redactions and Git objects. No product, parser, fixture, test, build, or probe executed.'},indent=2))
