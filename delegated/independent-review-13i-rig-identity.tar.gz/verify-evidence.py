#!/usr/bin/env python3
"""Read-only verification of the critique and its hash-linked existing evidence."""
from pathlib import Path
import gzip,hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();r=json.loads((b/'REVIEW.json').read_bytes());p=Path(r['existing_evidence']['packet'])
for x in r['reviewed_staged_files'].values():
 stored=(b/x['preserved_copy']).read_bytes();assert sha(stored)==x['copy_sha256'];raw=gzip.decompress(stored) if x['encoding']=='gzip' else stored;assert (len(raw),sha(raw))==(x['index_bytes'],x['index_sha256'])
a=json.loads((b/'staged-assessment.json').read_bytes());base=json.loads(gzip.decompress((b/'staged-baseline.json.gz').read_bytes()));assert a['source_revision']==base['source_revision']==r['source_baseline'];assert base['newly_assessed_ledger']['entries'][1022]['id']=='SEGOVB-L11-ANIME-GAUGE-VALIDATION-ORDER' and base['newly_assessed_ledger']['entries'][1023]['id']=='REVIEW-ANIME-WARMUP-ALTERNATE-GAUGE-001'
e=r['existing_evidence'];assert sha((p/'REPORT.json').read_bytes())==e['report_sha256'] and sha((p/'MANIFEST.json').read_bytes())==e['manifest_sha256'];assert sha((p/'personal-read-receipt.json').read_bytes())==e['primary_receipt_sha256'] and sha((p/'supplement-read-receipt.json').read_bytes())==e['supplement_receipt_sha256'];assert sha(Path(e['peer_report']).read_bytes())==e['peer_report_sha256']
rr={}
for f in ['personal-read-receipt.json','supplement-read-receipt.json']:
 for x in json.loads((p/f).read_text())['reads']:rr[x['id']]=x
for x in r['registered_source_references']:
 d=Path(x['archive']).read_bytes();assert sha(d)==x['sha256']==rr[x['source_id']]['sha256'];covered={j for i,k in rr[x['source_id']]['actual_display_ranges'] for j in range(i,k+1)};assert all(j in covered for i,k in x['lines'] for j in range(i,k+1))
records=next(x['historical_records'] for x in r['conclusions'] if x['topic']=='Historical object and attribution')
for x in records:
 d=Path(x['path']).read_bytes()
 if x['path'].endswith('.gz'):
  d=gzip.decompress(d);assert sha(d)==x['uncompressed_sha256']
  if x['id']=='059 q641':assert json.loads(d)['entries'][641]['contract_id']=='Q-L11-5804bd738c3307701b02'
  if x['id']=='RIG-ADMISSION03-F049':assert any(json.loads(y)['id']==x['id'] for y in d.splitlines())
 else:assert sha(d)==x['sha256']
for line in (b/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert sha((b/name).read_bytes())==digest
print(json.dumps({'status':'passed','source_references':len(r['registered_source_references']),'historical_records':len(records),'writes':'none','product_execution':'none'},indent=2))
