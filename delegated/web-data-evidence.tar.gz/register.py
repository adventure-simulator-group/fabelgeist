import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/strategic-web/src/medical/administrations.rs','crates/strategic-web/src/regional_source.rs','crates/strategic-web/src/routes/data.rs'];rows=[]
for index,path in zip(range(2358,2361),paths):
 versions=[]
 for rev in [old,cur]:
  q=subprocess.run(['git','show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if q.returncode:versions.append({'revision':rev,'present':False});continue
  b=q.stdout;versions.append({'revision':rev,'present':True,'lines':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 rows.append({'original_index':index,'path':path,'versions':versions})
o={'schema':'delegated-audit-prospective-source-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Fresh full-body assessment for original strategic-web roles 2358–2360. Register both frozen 6533 and authoritative 95e before actual displays.','prior_personal_support':'medical/administrations.rs 1–28 was personally displayed earlier as support for previous roles 2355–2357, in <LOCAL_PATH_1> and report.json. That earlier support read grants no new ordered-role credit; a fresh fully displayed current source assessment follows this registration.','qualification':'Historical and current bytes must be independently verified; matching bytes do not establish unchanged connected consumers or transfer historical evidence to checkpoint3821. Additional supporting source will be prospectively registered and its actual read ranges separately recorded.','constraint':'No product changes, implementation, builds, tests, browser, runtime probes, simulations or product validation.','ordered_roles':rows}
(p/'registration.json').write_text(json.dumps(o,indent=2)+'\n');print('registered',o['registered_utc'],'sha256',hashlib.sha256((p/'registration.json').read_bytes()).hexdigest())
