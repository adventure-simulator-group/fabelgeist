import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/strategic-web/src/routes/settlements/party/inventory_medical.rs','crates/strategic-web/src/routes/settlements/party/location_personal.rs','crates/strategic-web/src/routes/parties.rs','crates/strategic-web/src/templates/settlement/character_health.rs'];rows=[]
for path in paths:
 b=subprocess.run(['git','show',rev+':'+path],stdout=subprocess.PIPE,check=True).stdout
 rows.append({'path':path,'range':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
o={'schema':'delegated-audit-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','revision':rev,'purpose':'Inspect bounded chronology/medical authorization and selected active-history consumers; record exact actual ranges, no ordered-role credit. Earlier same-agent readings retain previous support only.','registered_sources':rows}
(p/'support-registration-02.json').write_text(json.dumps(o,indent=2)+'\n'); print('registered',o['registered_utc'],hashlib.sha256((p/'support-registration-02.json').read_bytes()).hexdigest());print('\n'.join(f"{x['path']} {x['range'][1]}" for x in rows))
