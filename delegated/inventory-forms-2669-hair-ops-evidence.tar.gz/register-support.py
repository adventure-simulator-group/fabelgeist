'''Prospective bounded form producers and handlers; source-only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[('crates/strategic-web/src/routes/settlements/party/inventory_medical.rs',[[360,490]]),('crates/strategic-web/src/routes/settlements/party/transfers.rs',[[1,125],[160,250]]),('crates/strategic-web/src/routes/settlements/rest.rs',[[675,750]]),('crates/strategic-web/static/party-trade.js',[[180,275],[550,600]])];a=[]
for i,(path,ranges) in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.source';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':[[x,min(y,eof)] for x,y in ranges if x<=eof],'qualification':'Fresh current bounded support only; no ordered-role or prior read credit; source text only.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest());print([(x['path'],x['eof'],x['prospective_ranges']) for x in a])
