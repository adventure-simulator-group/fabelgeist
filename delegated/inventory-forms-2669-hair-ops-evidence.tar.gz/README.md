# Bounded inventory-form source evidence

`REPORT.json` records `/root/hair_ops` source-only review of original role 2669,
registered bounded 95e producers and consumers, historical relationships, and
thirteen partial perspectives. It does not complete whole lenses, implement a
repair, validate the product, or substitute for unrecovered checkpoint 3821.

`registration.json` prospectively registered the historical pr-working and
current 95e full bodies. `support-registration*.json` registered each bounded
support window before its display; `read-receipt.json` records actual displays
and unread complements. The pr-working, 6533, e275 and 95e files match per file;
the historical snapshot has unrelated changes, so no clean-tree claim follows.
Earlier rig, 059 and delegate personal reads retain their own exact scopes.

The packet retains full original registry/source archive, compressed 059
queue and ledger, exact selected 059 receipts, exact original 774 member JSONL
bytes, and exact small records from the previous `/root/mhr_character` bundle.
The queue selection is explicitly reconstructed from the retained full queue.
`historical-manifest.json` preserves source paths and hashes; previous bundle
hashes are provenance references, not a claim those bundles are reproduced.
`git-proofs.json` and `git-objects/` preserve Git membership. `MANIFEST.json`
fixes all local packet bytes. No verification depends on external local paths.

Run `python3 verify-evidence.py` for self-contained evidence-integrity checks.
It checks registered identities, displayed partitions, archive/registry/queue,
Git proofs, historical authors and manifest hashes. It does not execute the
product, database, browser, fixtures, tests, or repair code.
