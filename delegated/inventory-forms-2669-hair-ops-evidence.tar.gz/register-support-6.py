'''Prospectively register storefront reducer adapter.'''
import datetime,hashlib,json
from pathlib import Path
p=Path('<LOCAL_PATH_0>');s=json.loads((p/'support-registration-2.json').read_bytes())['sources'][0].copy();s['prospective_ranges']=[[2236,2280]];s['qualification']='Fresh current storefront reducer adapter, no earlier or ordered-role credit.';o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':[s]};(p/'support-registration-6.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-6.json').read_bytes()).hexdigest())
