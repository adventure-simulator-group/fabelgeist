'''Prospective inventory scope producers; source-only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[('crates/strategic-web/static/party-trade.js',[[320,350]]),('crates/strategic-web/static/live-regions.js',[[90,125]]),('crates/strategic-web/src/templates/settlement/trade/merchant.rs',[[230,250]])];a=[]
for i,(path,ranges) in enumerate(paths,9):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.source';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Fresh current bounded source support, no ordered or prior credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-5.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-5.json').read_bytes()).hexdigest())
