'''Self-contained evidence-integrity checks only. No product execution.'''
import gzip,hashlib,json,tarfile
from datetime import datetime
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');report=load('REPORT.json')
for x in hist['exact_059_records']:
 b=(p/x['local']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['local']
for x in rec['registrations']:
 assert h((p/x['path']).read_bytes())==x['sha256'];assert datetime.fromisoformat(load(x['path'])['registered_utc'])<=datetime.fromisoformat(rec['recorded_utc'])
for x in load('rules.json')['files']:assert h((p/x['local']).read_bytes())==x['sha256']
rbytes=gzip.decompress((p/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['registry_uncompressed_sha256']==hist['original_registry_uncompressed_sha256'];original=json.loads(rbytes)['files'];archive=p/'recovered/objects.tar.gz';assert h(archive.read_bytes())==reg['source_archive_sha256']==hist['original_registry_archive_sha256']
with tarfile.open(archive,'r:gz') as t:
 for x in reg['rows']:
  old=(p/x['old_archive']).read_bytes();prev=(p/f"source/{x['role']}-6533.rs").read_bytes();new=(p/f"source/{x['role']}-95e6.rs").read_bytes();assert original[x['role']]==x['original_registry_record'] and h(old)==x['old_sha256'] and old==prev==new==t.extractfile(x['old_sha256']).read();rr=next(v for v in rec['assigned'] if v['role']==x['role']);assert rr['unread_old_and_current']==[]
  for key,pk in [('pr_working_actual_display','pr_working'),('current_95e_actual_display','current95e')]:
   assert [i for a,z in rr[key] for i in range(a,z+1)]==list(range(1,len(old.splitlines())+1))
   for a,z in rr[key]:assert any(c<=a<=z<=d for c,d in x['prospective_display'][pk])
planned={}
for n in [v['path'] for v in rec['registrations'] if v['path'].startswith('support-registration')]:
 for x in load(n)['sources']:
  if x['saved'] not in planned:planned[x['saved']]=dict(x)
  else:planned[x['saved']]['prospective_ranges']+=x['prospective_ranges']
for x in rec['support']:
 s=planned[x['saved']];b=(p/x['saved']).read_bytes();assert h(b)==x['sha256']==s['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==x['eof']==s['eof'];used=[]
 for a,z in x['displayed']+x['unread_complement']:assert 1<=a<=z<=x['eof'];used.extend(range(a,z+1))
 assert len(used)==x['eof'] and set(used)==set(range(1,x['eof']+1))
 for a,z in x['displayed']:assert any(c<=a<=z<=d for c,d in s['prospective_ranges'])
objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 raise ValueError(name)
for x in proof['proofs']:
 current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for v in x['chain']:
  assert current==v['tree'] and lookup(objects[current],v['name'])==(v['mode'],v['object']);current=v['object']
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and h(b)==x['sha256']
rr=[json.loads(v) for v in (p/'historical/774-rig-source-range-registration.jsonl').read_bytes().splitlines()];add=[json.loads(v) for v in (p/'historical/774-rig-additional-contracts.jsonl').read_bytes().splitlines()];x=reg['rows'][0]
for ob in x['original_registry_record']['admission03_scope_observations']:assert rr[ob['row_1based']-1]==ob['original_record']
a=next(v for v in add if v['id']=='RIG-ADMISSION03-ADDITIONAL-134');assert a['sha256']==x['old_sha256'] and a['actual_source_ranges']==[[1,50]] and not a['later_lens_credit'] and a['repair']=='not_started'
l11=load('historical/059--segovb--READ-L11-437.json');r=next(v for v in l11['sources'] if v['original_index']==2669);assert r['fresh_personal_body_reads']==[[1,50]]
l12=load('historical/059--segovb--READ-L12-924.json');r=next(v for v in l12['rows'] if v['original_index']==2669);assert r['fresh_personal_body_reads']==[[1,50]] and '/root/lens12_frontier' in r['attribution'] and l12['root_personal_rereads']==[]
e=load('historical/059--segovb--READ-L11-590.json');r=next(v for v in e['rows'] if v.get('path')=='crates/strategic-web/src/routes/inventory_forms.rs');more=load('additional-revision.json');assert r['revision']==more['revision'] and r['fresh_personal_body_ranges']==[[1,150]] and r['sha256']==more['sha256'] and more['equal_95e'] and any(x['revision']==more['revision'] and x['blob']==more['git_blob'] for x in proof['proofs'])
qb=gzip.decompress((p/'recovered/059-queue.json.gz').read_bytes());lb=gzip.decompress((p/'recovered/059-ledger.json.gz').read_bytes());assert h(qb)==hist['queue_sha256'] and h(lb)==hist['ledger_sha256'];sel=load('historical/059-selected-records-reconstructed.json');assert sel['source_sha256']==h(qb);q=json.loads(qb)['entries']
for v in sel['rows']:assert q[v['index']]==v['entry']
manifest=load('historical/prior-web-trade-BUNDLE-MANIFEST.json');mapping={'report.json':'historical/prior-web-trade-report.json','support-read-receipt.json':'historical/prior-web-trade-support-read-receipt.json','support-registration.json':'historical/prior-web-trade-support-registration.json'}
for name,local in mapping.items():assert any(v['path']==name and v['sha256']==h((p/local).read_bytes()) for v in manifest['files'])
prior=load(mapping['support-read-receipt.json']);r=next(v for v in prior['reads'] if v['path']=='crates/strategic-web/src/routes/inventory_forms.rs');assert prior['agent']=='/root/mhr_character' and r['actual_display_union']==[[90,130]]
assert h((p/mapping['report.json']).read_bytes())==hist['prior_web_report_sha256'] and len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==[{k:v for k,v in x.items() if k!='qualification'} for x in rec['assigned']]
if (p/'MANIFEST.json').exists():
 for x in load('MANIFEST.json')['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
print(f"PASS: self-contained source/archive/registry and 059 evidence; one separately displayed full old/current pair; {len(proof['proofs'])} Git proofs; {len(rec['support'])} support partitions; exact 774/059/prior reviewer attribution. Evidence integrity only; no product, browser, DB, build, test or runtime execution.")
