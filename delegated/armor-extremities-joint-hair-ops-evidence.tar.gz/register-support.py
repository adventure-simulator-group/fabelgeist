'''Prospective source support registration, no body display.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/fabelgeist-armor/src/limb_armor.rs',[[230,376]]),('crates/fabelgeist-armor/src/joint_extension.rs',[[1,90]]),('crates/fabelgeist-armor/src/gpu/limb.rs',[[450,490]]),('crates/fabelgeist-armor/src/gpu/limb/joint_cup.rs',[[160,268]]),('crates/adventuresim-character-creator/src/device_extremities.rs',[[1,125]]),('crates/fabelgeist-armor/src/gpu/recipe.rs',[[90,165]]),('crates/fabelgeist-armor/src/gpu/chart.rs',[[250,355]]),('crates/fabelgeist-armor/src/gpu/mitten.rs',[[105,165]]),('crates/adventuresim-character-creator/src/limb_controls.rs',[[1,150]])]
a=[]
for i,(path,ranges) in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Bounded current support only; no prior or future ordered-role credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest());print(json.dumps([{k:x[k] for k in ('path','eof','prospective_ranges')} for x in a],indent=2))
