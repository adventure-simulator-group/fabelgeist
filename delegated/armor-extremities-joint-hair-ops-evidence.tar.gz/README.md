# Bounded armor evidence: original roles 2617–2618

`REPORT.json` contains bounded source observations, thirteen partial lens
perspectives, open questions and historical relationships. The prospective
registrations and `read-receipt.json` separate independent old/current displays,
prior reviewer scopes, and unread support ranges. Both original pr-working
objects match the 6533 and 95e files individually; f82 is evidence transport,
not source HEAD. The original pr-working snapshot had unrelated modifications.

`source/` and `support/` hold exact registered bytes; `git-objects/` and
`git-proofs.json` contain commit-to-blob membership proofs. The historical
manifest distinguishes exact 059 records, a reconstructed queue selection and
hash-linked published 774 and current assessments. Prior reviewers retain their
actual scopes. P16 patch recovery is separate from these pr-working roles and
no old record is promoted into checkpoint 3821.

`python3 verify-evidence.py` checks evidence integrity, assuming linked evidence
remains at the recorded absolute paths. Relocated links must be resolved by
SHA-256. This check reads source bytes and does not run or validate product
behavior. Shader source is text only; no compiler, device, test or probe ran.
