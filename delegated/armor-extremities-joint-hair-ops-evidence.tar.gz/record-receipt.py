import datetime,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json']
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};r=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):r.append([start,i-1]);start=None
 return r
reads=[]
for n in names[1:]:
 for x in json.loads((p/n).read_bytes())['sources']:
  ranges=[[1,80],[81,159]] if x['saved']=='support/12.rs' else x['prospective_ranges'];reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['eof'],'displayed':ranges,'unread_complement':complement(x['eof'],ranges),'qualification':'Current bounded support only; no earlier or ordered-role credit. WGSL source text was not compiled or executed.'})
assigned=[{'role':2617,'pr_working_actual_display':[[1,78]],'current_95e_actual_display':[[1,78]],'unread_old_and_current':[]},{'role':2618,'pr_working_actual_display':[[1,128]],'current_95e_actual_display':[[1,128]],'unread_old_and_current':[]}]
o={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in names],'assigned':assigned,'other_revision':'6533 copies were byte/Git verified only, not separately displayed. Old pr-working and current 95e bodies were displayed separately.','prior_current':'Earlier ASSESSMENT-HELMET-FOOTWEAR-95E records current support 2617 1–78; ASSESSMENT-LIMB-METAL-95E records 2618 100–127. Their unnamed authors and support scopes remain separate; this is an independent assigned read.','truncation_qualification':'Combined initial support output truncated part of device_extremities; current 1–125 was redisplayed individually in full and is the credited read.','support':reads,'constraints':'Source and evidence inspection only. No shader compilation, tests or product execution.'};(p/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n');print('receipt sha256',h((p/'read-receipt.json').read_bytes()))
