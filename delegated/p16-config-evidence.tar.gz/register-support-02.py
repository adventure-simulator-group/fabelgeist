import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-tactical-core/src/animation/measurement.rs','crates/adventuresim-tactical-client/src/animation/presentation/plugin.rs','crates/adventuresim-tactical-core/src/combat_config/defaults.rs']
rows=[]
for n,path in enumerate(paths,8):
 data=subprocess.check_output(['git','-C',repo,'show',f'{rev}:{path}']);dst=p/f'source/support-{n:02}.source';dst.write_bytes(data);lines=len(data.splitlines())
 rows.append({'kind':'current-support','revision':rev,'path':path,'archive':str(dst.relative_to(p)),'bytes':len(data),'lines':lines,'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'planned_ranges':[[1,lines]],'qualification':'Permitted full body, select bounded windows and record actual ranges, support only.'})
(p/'support-registration-02.json').write_text(json.dumps({'schema':'726-prospective-support-registration-v1','agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Check duration admission, terrain scheduling, canonical default source.','sources':rows},indent=2)+'\n');print([(x['path'],x['lines']) for x in rows])
