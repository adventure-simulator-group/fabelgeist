import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>')
repo='<LOCAL_PATH_1>'
origin=pathlib.Path('<LOCAL_PATH_2>')
r=json.load(gzip.open('<LOCAL_PATH_3>','rt')); snap=r['snapshots'][3]; H='a120390947c89b703dc74c4255a13c035d054c50'; C='95e63628f9d70b8dd6e6fede64334696c6995009'; assert snap['head']==H
rows=[]; absent=[]
for i,name in [(2483,'procedural'),(2484,'ragdoll'),(2485,'playback')]:
 path='crates/adventuresim-tactical-core/src/combat_config/'+name+'.rs'; entry=r['files'][i]; sha=entry['sha256']; b=(origin/sha).read_bytes();assert hashlib.sha256(b).hexdigest()==sha
 h=subprocess.check_output(['git','-C',repo,'show',f'{H}:{path}']);assert h==b
 for kind,rev,data in [('physical-p16',H,b),('current',C,None)]:
  if data is None:
   q=subprocess.run(['git','-C',repo,'show',f'{rev}:{path}'],capture_output=True)
   if q.returncode:
    absent.append({'original_role':i,'kind':kind,'revision':rev,'path':path,'qualification':'Exact path absent in current tree; prove nonmembership separately.'});continue
   data=q.stdout
  d=p/f'source/{kind}-{i}.source';d.write_bytes(data);n=len(data.splitlines())
  rows.append({'original_role':i,'kind':kind,'revision':rev,'revision_qualification':'For physical-p16 the revision is recorded base HEAD and separately identical per-path Git blob; snapshot is dirty and not equivalent to clean commit.' if kind=='physical-p16' else 'Pinned current Git tree.', 'path':path,'archive':str(d.relative_to(p)), 'bytes':len(data),'lines':n,'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'planned_display_chunks':[[k,min(k+79,n)] for k in range(1,n+1,80)],'original_extracted_source_object':str(origin/sha) if kind=='physical-p16' else None})
(p/'registration.json').write_text(json.dumps({'schema':'726-prospective-source-registration-v1','agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Independently assess original physical-p16 roles 2483–2485 and compare pinned current; source inspection only.','historical_snapshot':snap,'qualification':'Original extracted content-addressed source object, 059 registry SHA and base Git path byte equality verified individually; dirty snapshot and modified parent are not clean commit. Recorded patch hash is registry metadata unless its bytes are independently found.','sources':rows,'absent':absent,'constraints':'No product execution, tests, builds, probes, simulations, fixtures or repairs.'},indent=2)+'\n')
print([(x['original_role'],x['kind'],x['lines'],x['sha256']) for x in rows]);print('absent',absent)
