import json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');x=json.loads((p/'report.json').read_text());c='95e63628f9d70b8dd6e6fede64334696c6995009';core='crates/adventuresim-tactical-core/src/';client='crates/adventuresim-tactical-client/src/animation/'
refs={
'P16-CONFIG-RAGDOLL-STEP-RETENTION':[(core+'combat_config/ragdoll.rs',[[19,32]]),(client+'ragdoll/drive.rs',[[114,165]]),(client+'presentation/plugin.rs',[[38,68]]),('content/tactical/combat.yaml',[[320,346]])],
'P16-CONFIG-MUSCLE-ENVELOPE-POLICY':[(core+'combat_config/ragdoll.rs',[[35,58]]),('crates/adventuresim-core/src/elapsed.rs',[[9,35],[100,104]]),(core+'animation/response_parameters.rs',[[34,37],[177,195],[206,210]]),(client+'ragdoll/muscles.rs',[[18,36],[56,65],[88,100],[141,150]]),('content/tactical/combat.yaml',[[331,340]])],
'P16-CONFIG-PHASE-DEADBAND-SNAP':[(core+'combat_config/playback.rs',[[18,25],[33,46]]),(core+'animation/phase_response.rs',[[8,16],[29,36],[47,52]]),(client+'presentation.rs',[[70,75],[82,96],[127,169]]),('content/tactical/combat.yaml',[[200,207]])],
'P16-CONFIG-GROUPED-ERROR':[(core+'combat_config/procedural.rs',[[53,64]]),(core+'combat_config/playback.rs',[[33,46]]),(core+'combat_config.rs',[[395,408],[649,651]])]}
for f in x['findings_and_questions']: f['source_refs']=[{'revision':c,'path':path,'lines':rr} for path,rr in refs[f['id']]]
(p/'report.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
