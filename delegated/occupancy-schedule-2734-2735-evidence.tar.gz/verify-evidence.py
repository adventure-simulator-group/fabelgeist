from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile
b=Path(__file__).resolve().parent
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest()
load=lambda p:json.loads((b/p).read_bytes())
gun=lambda p:gzip.decompress((b/p).read_bytes())
history=load('historical-attribution.json');report=load('REPORT.json')
groups={n:load(n) for n in ['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json','support-registration-6.json','historical-support-registration.json']}
regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes()
 assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[182,256,1014,1079,2675,2734,2735]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
p16=next(x for x in registry['snapshots'] if x['id']=='physical-p16');pr=next(x for x in registry['snapshots'] if x['id']=='pr-working')
assert p16['base']==p16['head']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(p16['status_porcelain'])==159 and sha((b/'history/p16-tracked.patch').read_bytes())==p16['patch_sha256']
assert pr['base']=='3a50b708381ad00c116445c2c999a49c3943088b' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
for (n,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
for role,ranges in [(2734,[[1,122]]),(2735,[[1,77]])]:
 old=regs[('registration.json',f'{role}-historical')];cur=regs[('registration.json',f'{role}-current')]
 assert old['sha256']==cur['sha256']==registry['files'][role]['sha256'] and old['prospective_personal_read_ranges']==registry['files'][role]['material_ranges']==ranges
 assert (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes() and all(v['equal_to_historical'] for v in old['comparison_metadata'].values())
 snap=pr if role==2734 else p16
 assert not any(e[3:]==old['source_path'] for e in snap['status_porcelain'])
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json')
assert [x['original_index_zero_based'] for x in sel['entries']]==[513,514,515,516,548,1557,1749,2229]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[2229]['contract_id']=='PL13-238-EQUIPMENT-TRANSACTION-PENDING'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']]
 assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
r=load('history/059/segovb/READ-L11-446.json')
for role,ranges in [(2734,[[1,122]]),(2735,[[1,77]])]:
 e=next(x for x in r['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==ranges
r=load('history/059/root-l2-extension-20261030/READ-ROOT-L2-CURRENT-011.json');e=next(x for x in r['rows'] if x['registration']=='ROOT-L2-CURRENT-0077');assert e['fresh_personal_ranges']==[] and e['qualified_same_lens_reuse_ranges']==[[1,99]]
r=load('history/059/root-l3-extension-20261030/READ-ROOT-L3-CURRENT-007.json');e=next(x for x in r['rows'] if x['registration']=='ROOT-L3-CURRENT-0059');assert e['fresh_personal_ranges']==[] and e['frozen_source_adoption_pending']
r=load('history/059/parallel-l13-20261029/READ-PL13-238.json');assert len(r['partial_read_union'])==8 and r['partial_read_union'][-1]['union']==[[1,3983]]
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d)
 assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
oldregs=[json.loads(z) for z in gun('history/774/native/admission03/source-range-registration.jsonl.gz').splitlines()]
quals={x['registration_id']:x for n in ['source-qualifications-final-current.jsonl','source-qualifications-followthrough-current.jsonl'] for x in map(json.loads,gun('history/774/native/admission03/'+n+'.gz').splitlines())}
for role,ranges in [(2734,[[1,122]]),(2735,[[1,77]])]:
 x=registry['files'][role]['admission03_scope_observations'][0]
 assert oldregs[x['row_1based']-1]==x['original_record'] and x['effective_material_ranges']==ranges and quals[x['registration_id']]==x['local_qualifications'][0]
native=[json.loads(z) for z in gun('history/774/native/admission03/camera-lower-followthrough/findings.jsonl.gz').splitlines()]
root=[json.loads(z) for z in gun('history/774/root/admission03/findings.jsonl.gz').splitlines()]
assert any(x['id']=='NATIVE-LOWER-ADM03-F001' for x in native) and any(x['id']=='ROOT-ADM-F005' for x in root)
for x in history['prior_packets']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
  members={m.name for m in t.getmembers() if m.isfile()};mraw=t.extractfile(x['manifest_name']).read();assert sha(mraw)==x['manifest_sha256'];m=json.loads(mraw)
  assert {f['path'] for f in m['files']}|{x['manifest_name']}<=members
  for f in m['files']:
   raw=t.extractfile(f['path']).read();assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
  assert sha(t.extractfile(x['report_name']).read())==x['report_sha256']
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==38
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes()
 assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
coverage={}
def record(regname,id,chunks,unread,when,recorded_sha):
 x=regs[(regname,id)];assert datetime.fromisoformat(groups[regname]['at_utc'])<datetime.fromisoformat(when)
 assert recorded_sha==x['sha256']
 actual={i for a,z in chunks for i in range(a,z+1)}
 planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)}
 remaining={i for a,z in unread for i in range(a,z+1)}
 assert actual<=planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1))
 coverage[id]=actual
assigned=load('read-receipt.json')
assert assigned['registration_sha256']==sha((b/'registration.json').read_bytes())
for e in assigned['entries']:record('registration.json',e['registration_id'],e['actual_display_chunks'],e['unread_complement'],assigned['at_utc'],e['sha256'])
s=load('support-read-receipt.json')
for q in s['registrations']:assert q['sha256']==sha((b/q['path']).read_bytes())
for e in s['entries']:record(e['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
h=load('historical-support-read-receipt.json');assert h['registration_sha256']==sha((b/h['registration']).read_bytes())
for e in h['entries']:record(h['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],h['at_utc'],e['sha256'])
assert len(coverage)==len(regs)==18
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   possible=[e for (n,id),e in regs.items() if id==x['id']];assert len(possible)==1 and x['sha256']==possible[0]['sha256'] and x['archive']==possible[0]['archive']
   assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','registered_personal_scopes':len(regs),'assigned_historical_material':{'2734':[[1,122]],'2735':[[1,77]]},'059_records_match_original_manifest':len(history['records_059']),'774_historical_git_paths_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'prior_packets_verified':len(history['prior_packets']),'bounded_lenses':13,'p16_tracked_patch_digest_verified':True,'059_original_payload_git_path':'unavailable in inspected stores; matched original manifest','product_build_test_fixture_execution_probe_validation':'not performed'},indent=2))
