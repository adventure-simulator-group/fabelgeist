from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();(b/'support').mkdir(exist_ok=True)
spec=[('container-detach-impl','crates/adventuresim-stdb-module/src/inventory_container.rs',[[125,205]])]
rows=[]
for tag,path,ranges in spec:
 r=subprocess.run(['git','-C',repo,'show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if r.returncode!=0:print('UNAVAILABLE',path);continue
 d=r.stdout;eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/'+tag+'.source';(b/dest).write_bytes(d);rows.append({'id':tag,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Current support only; inspect preflight comment against actual detach helper; no product or transaction execution.'})
out={'schema':'726-prospective-occupancy-schedule-support4-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'support-registration-4.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
