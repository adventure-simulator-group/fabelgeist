# Bounded occupancy and schedule source evidence

Original role 2734 is the frozen dirty pr-working occupancy source; role 2735
is the distinct dirty physical-p16 schedule source. Their individually archived
bytes match their corresponding 95e63628f9d70b8dd6e6fede64334696c6995009 files,
but neither equality makes the original worktree clean. f82 is a transport
commit; the P16 a120 is its recorded base, not a dirty commit.

Read REPORT.json, source registrations, actual read receipts and
historical-attribution.json for attribution, scope and unread complements.
Raw commit/tree proof objects and complete registered source bytes are retained.
A retained full source body is not a claim of a full body read. Original 059
queue and ledger are historical summaries, while selected registry and queue
rows are labeled mechanical reconstructions. Missing checkpoint 3821 has not
been reconstructed or silently advanced.

The later reproduced P16 tracked patch matches the original registry digest;
seven untracked paths are separate, and the original invocation and
uninterrupted custody are not proved. The original 059 payload Git path was
unavailable in the inspected object stores; exact selected extracted records
match the original transport manifest's byte count, SHA-256 and Git blob.

Verify evidence only with python3 verify-evidence.py and verify the packet with
python3 verify-manifest.py. These read retained bytes and do not execute, build
or validate product code. Two earlier evidence packets are included byte-for-byte
with their original manifest and reviewer attribution; a public copy with
redacted paths must be labeled reconstructed and hashed separately.
