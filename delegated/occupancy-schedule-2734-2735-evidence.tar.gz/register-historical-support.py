from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
h='caa8a155d38c326bf43174ed106f7b885196bcc23fcddb76af341a1acb380e0c'
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
path='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+h
d=subprocess.check_output(['git','-C',repo,'show',rev+':'+path])
assert hashlib.sha256(d).hexdigest()==h
dest='support/p16-simulation-writer.source';(b/dest).write_bytes(d)
x={'id':'p16-simulation-writer','revision':rev,'snapshot':'physical-p16 dirty, recorded base a120; f82 transports object','git_path':path,'source_path':'crates/adventuresim-stdb-module/src/simulation.rs','sha256':h,'git_blob':hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest(),'bytes':len(d),'eof':len(d.splitlines()),'archive':dest,'prospective_personal_read_ranges':[[349,390],[420,480]],'qualification':'New historical support only. Original 774 REG122 qualified 349–494 and source P16 registry role256 are separately attributed; do not transfer role credit.'}
o={'schema':'726-prospective-historical-support-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':[x]}
(b/'historical-support-registration.json').write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(o,indent=2))
