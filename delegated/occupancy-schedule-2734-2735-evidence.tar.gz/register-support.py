from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();(b/'support').mkdir(exist_ok=True)
spec=[('schedule-owner','crates/adventuresim-core/src/strategic_schedule/allocation.rs',[[1,139],[175,282]]),('occupancy-fit','crates/adventuresim-core/src/item_catalog_fit.rs',[[1,49]]),('character-reducer','crates/adventuresim-stdb-module/src/character.rs',[[680,710],[2920,2985],[3010,3065],[3080,3165]]),('schedule-writer','crates/adventuresim-stdb-module/src/time/stationary.rs',[[190,263]]),('schedule-preview','crates/strategic-web/src/templates/settlement/character_skills.rs',[[2098,2117]])]
rows=[]
for tag,path,ranges in spec:
 r=subprocess.run(['git','-C',repo,'show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if r.returncode!=0:print('UNAVAILABLE',path);continue
 d=r.stdout;eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/'+tag+'.source';(b/dest).write_bytes(d);rows.append({'id':tag,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Independently registered bounded current support; historical and prior reviewers retain separate attribution. No extra ordered-role credit or product execution.'})
out={'schema':'726-prospective-occupancy-schedule-support-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
