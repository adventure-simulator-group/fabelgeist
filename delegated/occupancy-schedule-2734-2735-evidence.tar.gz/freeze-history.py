from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
ex=Path('<LOCAL_PATH_1>')
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d)
 return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[]
for src,dest,kind in [
 ('recovered/original-registry-source-archive/registry.json.gz','history/original-registry.json.gz','original recovered registry'),
 ('recovered/original-transport-manifest.json.gz','history/original-transport-manifest.json.gz','original 059 transport manifest'),
 ('RECOVERY-PHYSICAL-P16-PATCH-20261111.json','history/p16-patch-recovery.json','later independent tracked-patch recovery report'),
 ('recovered/physical-p16-patch-recovery/tracked.patch','history/p16-tracked.patch','reproduced tracked patch; seven untracked paths excluded'),
 ('ASSESSMENT-L05-SCHEDULE-AGGREGATE-95E.json','history/assessment-schedule-aggregate-95e.json','earlier current separate plan consistency question'),
 ('ASSESSMENT-DELEGATED-RECONCILIATION-8-95E.json','history/assessment-delegated-8-95e.json','earlier central occupancy display relationships'),
 ('ASSESSMENT-L01-HISTORICAL-178-184.json','history/assessment-historical-178-184.json','earlier original P16 role182 full read'),
 ('ASSESSMENT-EQUIPMENT-TOPOLOGY-95E.json','history/assessment-equipment-topology-95e.json','previous topology findings; independent reads')]:
 refs.append({'kind':kind,'original':src,**save((pub/src).read_bytes(),dest)})
for src,dest in [('baseline-059/queue.json','history/baseline-059-queue.json.gz'),('baseline-059/ledger.json','history/baseline-059-ledger.json.gz')]:
 raw=(pub/src).read_bytes()
 refs.append({'kind':'059 historical summary mechanically compressed; not final 3821','original':src,'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(gzip.compress(raw,mtime=0),dest)})
registry=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()))
idx={v['path']:v for v in json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()))['entries']}
inds=[182,256,1014,1079,2675,2734,2735]
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanically selected original rows and exact snapshot metadata; originals fully preserved; extra roles are historical context only and not claimed as assigned role credit; no checkpoint3821 promotion.','rows':[{'original_index':i,**registry['files'][i]} for i in inds],'snapshots':[x for x in registry['snapshots'] if x['id'] in ('physical-p16','pr-working')]},indent=2)+'\n')
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries']
qi=[513,514,515,516,548,1557,1749,2229]
(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-059-queue-reconstruction-v1','qualification':'Mechanical selection; preserve original queue identities/uncertainties, no new disposition or count.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in qi]},indent=2)+'\n')
paths=['segovb/READ-L11-446.json','segovb/REGISTRATION-SEGOVB-1653.json','segovb/REGISTRATION-SEGOVB-1654.json','segovb/STATE-L11-446.json','segovb/VERIFY-L11-446.json','root-l2-extension-20261030/READ-ROOT-L2-EXT-055-066.json','root-l2-extension-20261030/REGISTRATION-ROOT-L2-EXT-055-063.json','root-l2-extension-20261030/READ-ROOT-L2-CURRENT-011.json','root-l3-extension-20261030/READ-ROOT-L3-EXT-057-061.json','root-l3-extension-20261030/REGISTRATION-ROOT-L3-EXT-057-059.json','root-l3-extension-20261030/READ-ROOT-L3-CURRENT-007.json','root-l3-extension-20261030/REGISTRATION-ROOT-L3-CURRENT-007.json','segovb/READ-L13-PARALLEL-208.json','parallel-l13-20261029/READ-PL13-210.json','parallel-l13-20261029/READ-PL13-210-PARTIAL-001.json','parallel-l13-20261029/READ-PL13-210-PARTIAL-002.json','parallel-l13-20261029/REGISTRATION-PL13-210.json','parallel-l13-20261029/VERIFY-PL13-210.json','parallel-l13-20261029/VALIDATION-PROPOSAL-PL13-209-211.json']
paths += ['parallel-l13-20261029/CLOSURE-QUEUE-PROPOSAL-PL13-001-v2.json','parallel-l13-20261029/READ-PL13-238.json','parallel-l13-20261029/REGISTRATION-PL13-238.json','parallel-l13-20261029/STATE-PL13-238-PROPOSAL.json','parallel-l13-20261029/VERIFY-PL13-238.json'] + [f'parallel-l13-20261029/READ-PL13-238-PARTIAL-{i:03}.json' for i in range(1,9)]
records=[]
for p in paths:
 raw=(ex/p).read_bytes();m=idx[p]
 assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob']
 records.append({'original_path':p,'git_blob':m['git_blob'],**save(raw,'history/059/'+p)})
old=[];prefix='handoff/774/adler-original/audit/continuation/'
for p in ['native/admission03/source-range-registration.jsonl','native/admission03/source-qualifications-final-current.jsonl','native/admission03/source-qualifications-followthrough-current.jsonl','native/admission03/camera-support/source-qualification-066.json','native/admission03/camera-support/contracts-065.json','native/admission03/camera-lower-followthrough/schedule-contracts-001.json','native/admission03/camera-lower-followthrough/findings.jsonl','native/admission03/camera-lower-followthrough/completion-003.json','rig/admission03/contract-groups.jsonl','rig/admission03/additional-contracts.jsonl','root/admission03/contracts.jsonl','root/admission03/findings.jsonl','root/admission03/schedule-admission-021.json']:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+prefix+p])
 old.append({'revision':rev,'transport_path':prefix+p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+p+'.gz')})
for i in [1079]:
 obj=registry['files'][i];p='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+obj['sha256']
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+p])
 assert sha(raw)==obj['sha256']
 refs.append({'kind':'Prior historic dirty pr-working parent source, archived only; no personal read credit','original':p,'revision':rev,'git_blob':oid(raw),'source_path':'crates/adventuresim-stdb-module/src/character.rs',**save(raw,'history/archived-pr-character.source')})
prior=[]
for directory,manifest,report,author in [('<LOCAL_PATH_2>','MANIFEST.json','REPORT.json','/root/rig_identity'),('<LOCAL_PATH_3>','MANIFEST.json','REPORT.json','/root/rig_identity')]:
 d=Path(directory);mraw=(d/manifest).read_bytes();m=json.loads(mraw)
 for f in m['files']:
  raw=(d/f['path']).read_bytes();assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
 archive=b/('history/'+d.name+'-exact-local.tar.gz')
 with tarfile.open(archive,'w:gz') as t:
  for f in sorted(d.rglob('*')):
   if f.is_file():t.add(f,arcname=str(f.relative_to(d)),recursive=False)
 prior.append({'original_directory':directory,'author':author,'manifest_name':manifest,'manifest_sha256':sha(mraw),'report_name':report,'report_sha256':sha((d/report).read_bytes()),'qualification':'Exact prior frozen local packet; original reviewer and actual source scopes retained, not copied personal reading. Any future public redaction is a reconstructed copy with different hashes.','preserved':str(archive.relative_to(b)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size})
out={'schema':'726-occupancy-schedule-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_059':records,'records_774':old,'prior_packets':prior,'qualification':'059 extracted exact records match original transport manifest size/SHA/Git blob; original payload Git path unavailable in inspected object stores. f82 is evidence transport only. P16 matching tracked-patch reproduction does not prove original invocation or uninterrupted custody; seven untracked paths excluded. Never promote historical summary, source or reconstructed selected rows into missing checkpoint3821.'}
(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n')
print('references',len(refs),'059 records',len(records),'774 records',len(old),'prior archives bytes',[x['bytes'] for x in prior])
