from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent
chunks={'schedule-owner':[[1,50],[51,100],[101,139],[175,228],[229,282]],'occupancy-fit':[[1,46]],'character-reducer':[[680,710],[2920,2952],[2953,2985],[3010,3065],[3080,3122],[3123,3165]],'schedule-writer':[[190,226],[227,263]],'schedule-preview':[[2098,2117]],'character-reducer-extra':[[2860,2890],[2891,2919],[2986,3009],[3066,3079]],'simulation-writer-source':[[349,390],[420,450],[451,480]],'container-detach':[[230,270],[271,310]],'container-detach-impl':[[125,165],[166,205]],'schedule-allocated':[[75,98]],'schedule-quarter-hour':[[20,30]],'schedule-day':[[1,15]],'schedule-sum':[[410,420]]}
out={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':[],'entries':[]}
for fname in ['support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json','support-registration-6.json']:
 raw=(b/fname).read_bytes();reg=json.loads(raw);out['registrations'].append({'path':fname,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for e in reg['entries']:
  ch=chunks[e['id']];covers=set()
  for a,z in ch:covers.update(range(a,z+1))
  missing=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covers and start is None:start=i
   elif (i>e['eof'] or i in covers) and start is not None:missing.append([start,i-1]);start=None
  out['entries'].append({'registration':fname,'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':missing,'qualification':'Personally displayed current support only; does not supply ordered-role or historic read credit.'})
(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('Recorded',len(out['entries']),'support bodies')
