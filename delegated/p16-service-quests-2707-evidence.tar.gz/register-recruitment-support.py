from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();paths=['crates/adventuresim-stdb-module/src/capability.rs','crates/strategic-web/src/routes/parties.rs','crates/strategic-web/src/templates/recruitment.rs','crates/adventuresim-stdb-module/src/strategic/governance.rs'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+p]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+p],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;local='support/'+p;pending.append((local,raw));entries.append({'revision':rev,'path':p,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':local,'planned_display_ranges':[[1,len(raw.splitlines())]],'qualification':'Connected recruitment/capability support only; actual personal windows recorded in receipt.'})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective bounded review of service recruitment match presentation and actor-side/native behavior; independently registered support with no role or other-reader credit.','entries':entries};(b/'recruitment-support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('SHA256',h((b/'recruitment-support-registration.json').read_bytes()))
