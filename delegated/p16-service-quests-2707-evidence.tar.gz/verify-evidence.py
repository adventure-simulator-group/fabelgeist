'''Offline evidence-integrity verification only; never executes product or tests.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files'];assert all(original[i]==sel['registry_rows'][str(i)] for i in [2382,2707]);assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id'] in ['physical-p16','pr-working']]
snapshot=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['recovered_patch']['bytes']==len(patch) and recovery['live_comparison']['status_counts']['??']==7
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows'];old,cur=reg['versions'];body=(b/old['local']).read_bytes()
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:assert t.extractfile(old['sha256']).read()==body
assert h(body)==old['sha256']==original[2707]['sha256']==original[2382]['sha256']==catalog[2707]['expected_sha256']==catalog[2382]['expected_sha256'];assert catalog[2707]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+reg['path'];assert catalog[2382]['origin']=='git:6533e444fa37552927070cc8d8190907fd3b413e:'+reg['path']
for c in reg['comparison_git_paths']+load('historical-comparisons-registration.json')['entries']:assert (b/c['local']).read_bytes()==body and c['display_planned']==False
assert (b/cur['local']).read_bytes()==body
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def partition(n,ranges):
 nums=[i for a,z in ranges for i in range(a,z+1)];return len(nums)==n and set(nums)==set(range(1,n+1))
for v in reg['versions']:
 p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'];assert p['actual_assigned_displays']==[[38,44]] and partition(v['eof'],p['actual_assigned_displays']+p['additional_context_displays']+p['unread_complement'])
assert rec['assigned'][0]['unread_complement']==[[1,37],[45,725]] and rec['assigned'][1]['unread_complement']==[]
planned={}
for n in ['support-registration.json','more-support-registration.json','recruitment-support-registration.json','core-support-registration.json']:
 for x in load(n)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];assert partition(x['eof'],x['displayed']+x['unread_complement']);assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
r774=[json.loads(s) for s in (b/'historical/774/root-source-range-registration.jsonl').read_text().splitlines()];q774=[json.loads(s) for s in (b/'historical/774/root-source-qualifications-final.jsonl').read_text().splitlines()];ob=original[2707]['admission03_scope_observations'][0];j=ob['row_1based']-1;assert r774[j]==ob['original_record'] and q774[j]==ob['local_qualifications'][0];assert ob['original_record']['material_ranges']==[[38,50]] and ob['effective_material_ranges']==[[38,44]] and ob['local_qualifications'][0]['qualifications'][0]['context_excluded']==[[45,50]]
ob=original[2382]['producer_reached_contract_observations'][0];traces=[json.loads(s) for s in (b/'historical/774/rig-producer-traces.jsonl').read_text().splitlines()];t=next(x for x in traces if x['id']==ob['receipt']);key,index=ob['json_pointer'].strip('/').split('/');assert t[key][int(index)]==ob['source_context'] and ob['read_ranges_as_recorded']==[[1,43]]
l11=load('historical/059/segovb/READ-L11-441.json');x=next(x for x in l11['sources'] if x['original_index']==2707);assert x['fresh_personal_body_reads']==[[38,44]] and h((b/'historical/059/segovb/REGISTRATION-SEGOVB-1626.json').read_bytes())==x['registration_sha256']
a=load('historical/059/adler/READ-L11-386.json');x=next(x for x in a['sources'] if x['original_index']==2382);y=next(x for x in a['connected_reinspection'] if x['original_index']==2382);assert x['fresh_reads']==[[1,43]] and y['fresh_reads']==[[44,44]];assert h((b/'historical/059/adler/REGISTRATION-ADLER-1252.json').read_bytes())==x['registration_sha256'] and h((b/'historical/059/adler/REGISTRATION-ADLER-1255.json').read_bytes())==y['registration_sha256']
p=load('historical/059/segovb/READ-L11-569.json');x=next(x for x in p['rows'] if x.get('registration')=='PL11-0335');assert x['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and x['fresh_personal_body_ranges']==[] and x['qualified_same_lens_reuse_ranges']==[[1,44]];assert h((b/'historical/059'/p['proposal']).read_bytes())==p['proposal_sha256']
p=load('historical/059/segovb/READ-L12-793.json');x=next(x for x in p['rows'] if x['original_index']==2382);assert x['fresh_personal_body_reads']==[[1,43]] and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
p=load('historical/059/segovb/READ-L12-CONNECTED-TEAM-008.json');x=next(x for x in p['checked_rows'] if x['original_index']==2382);assert x['fresh_personal_body_reads']==[[44,44]] and '/root/lens12_frontier' in x['attribution'] and p['root_personal_rereads']==[];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
p=load('historical/059/root-l2-extension-20261030/READ-ROOT-L2-EXT-045-051.json');x=p['rows'][3];assert x['fresh_personal_ranges']==[[1,44]] and 'Root personal' in x['attribution'];assert h((b/'historical/059'/x['registration_ref']['path']).read_bytes())==x['registration_ref']['sha256']
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-941.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False;x=next(x for x in p['rows'] if x['original_index']==2707);assert x['fresh_personal_body_reads']==[[38,50]] and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256'];q=x['identity_specific_windows_qualification'];assert h((b/'historical/059'/q['path']).read_bytes())==q['sha256']
for x in p['partial_read_receipts']:assert h((b/'historical/059'/x['path']).read_bytes())==x['sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: P16 role2707 and 95e lines38–44 independently displayed; separate current support and original45–50 exclusion; historical reviewer/identity and unadopted proposal preserved; exact tracked-patch recovery with untracked qualification; %d Git proofs and %d registered bounded supports. Thirteen partial perspectives; offline evidence integrity only, no product/build/test/probe.'%(len(proof['proofs']),len(rec['support'])))
