from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objs={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objs:
  p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objs[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind):
 raw=(b/local).read_bytes();root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw)})
r=json.loads((b/'registration.json').read_bytes());old,cur=r['versions'];f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';proof(cur['revision'],r['path'],cur['local'],'pinned current assigned source');proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+old['sha256'],old['local'],'P16 archival object transported by f82; f82 is not source head')
for x in r['comparison_git_paths']+json.loads((b/'historical-comparisons-registration.json').read_bytes())['entries']:proof(x['revision'],r['path'],x['local'],'per-file comparison only, not snapshot equivalence or body-display credit')
for n in ['support-registration.json','more-support-registration.json','recruitment-support-registration.json','core-support-registration.json']:
 for x in json.loads((b/n).read_bytes())['entries']:proof(x['revision'],x['path'],x['local'],'current supporting source only, actual personal scope in receipt')
for x in json.loads((b/'historical-manifest.json').read_bytes())['records']:
 if x.get('transport_revision'):proof(x['transport_revision'],x['git_path'],x['local'],'original 774 historical record via f82 transport')
d={'schema':'726-p16-service2707-git-membership-v1','objects':objs,'proofs':proofs,'qualification':'Matching file bytes do not equate P16/pr-working dirty snapshots, historical personal reads or lens populations. f82 transports evidence.'};(b/'git-proofs.json').write_text(json.dumps(d,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objs),'sha256',h((b/'git-proofs.json').read_bytes()))
