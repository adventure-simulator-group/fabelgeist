from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';p='crates/strategic-web/src/routes/settlements/service_quests.rs';h=lambda x:hashlib.sha256(x).hexdigest();r=[];pending=[]
for rev,why in [('039329518e264f19206cf5b0b98d177433f40c17','older recovery catalogue origin'),('e2755a732c84e67296b5e3441a4259a84f461b2f','historical 059 e275 current-source source identity reuse')]:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+p]);oid=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+p],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid;n='source/2707-'+rev[:4]+'.rs';pending.append((n,raw));r.append({'revision':rev,'path':p,'purpose':why,'sha256':h(raw),'git_blob':oid,'eof':len(raw.splitlines()),'local':n,'display_planned':False,'equals_physical_p16_object':raw==(b/'source/2707-physical-p16.rs').read_bytes()})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Per-file identity comparison only; no body display or historical read attribution from same bytes.','entries':r};(b/'historical-comparisons-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:(b/n).write_bytes(raw)
print(json.dumps(d,indent=2))
