from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent
repo=Path('<LOCAL_PATH_0>')
base=repo/'recovered/original-registry-source-archive'
h=lambda x:hashlib.sha256(x).hexdigest()
r=json.load(gzip.open(base/'registry.json.gz','rt'));x=r['files'][2707];p=x['source_id'].split(':',1)[1]
with tarfile.open(base/'objects.tar.gz','r:gz') as t:old=t.extractfile(x['sha256']).read()
assert h(old)==x['sha256'] and len(old)==x['bytes'] and len(old.splitlines())==725
pending=[('source/2707-physical-p16.rs',old)]; versions=[{'identity':'physical-p16 registry archived source object','revision_qualification':'dirty a120-based P16 snapshot; f82 transport is not project head','sha256':h(old),'bytes':len(old),'eof':725,'local':'source/2707-physical-p16.rs','ordered_material_display_planned':[[38,44]],'other_lines_display_planned':[]}]; comps=[]
for rev in ['a120390947c89b703dc74c4255a13c035d054c50','6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']:
 raw=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+p]); blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+p],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 n='source/2707-'+rev[:4]+'.rs';pending.append((n,raw));d={'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':n,'equals_archived_p16_file':raw==old}
 if rev.startswith('95e6'): d['ordered_material_display_planned']=[[38,44]];d['separately_registered_support_display_planned']=[[1,37],[45,725]];versions.append(d)
 else: d['display_planned']=False;comps.append(d)
doc={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','original_index':2707,'source_id':x['source_id'],'path':p,'original_registry_uncompressed_sha256':h(gzip.decompress((base/'registry.json.gz').read_bytes())),'original_material_ranges':x['material_ranges'],'historical_qualification':'774 root registered38–50 and qualified38–44 only; 45–50 context excluded. Other lines have no ordered-role credit. physical-p16 is dirty a120-based, with later tracked-patch recovery and untracked files separately archived. f82 is only the evidence transport.','scope':'Prospective archived P16 and pinned 95e role lines38–44 separately displayed. Current 95e other lines1–37,45–725 separately registered as support, not original role credit; actual displays and unread complements recorded in receipt. a120 and 6533 copies for identity only, no display credit.','prior_read_disclosure':'/root/hair_ops previously displayed 95e 30–50 as support only in frozen <LOCAL_PATH_1> prospective living-registration.json and read-receipt.json. This does not transfer old role or another reviewer credit.','versions':versions,'comparison_git_paths':comps,'limits':'Static source/evidence only; no product execution, builds, tests, probes, repairs or publication edits.'}
(b/'registration.json').write_text(json.dumps(doc,indent=2)+'\n')
for n,raw in pending:
 q=b/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
print(json.dumps(doc,indent=2));print('REGISTRATION_SHA256',h((b/'registration.json').read_bytes()))
