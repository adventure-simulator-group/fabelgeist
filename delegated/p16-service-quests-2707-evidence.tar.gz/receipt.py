from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def missing(n,r):
 a=set(range(1,n+1));[a.difference_update(range(x,y+1)) for x,y in r];out=[]
 for x in sorted(a):
  if not out or x!=out[-1][1]+1:out.append([x,x])
  else:out[-1][1]=x
 return out
reg=load('registration.json');assigned=[]
for i,v in enumerate(reg['versions']):
 displayed=[[38,44]];assigned.append({'original_index':2707,'source_id':reg['source_id'],'identity':v.get('identity','pinned 95e current source'),'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_assigned_displays':displayed,'additional_context_displays':[] if i==0 else [[1,37],[45,180],[181,360],[361,540],[541,725]],'unread_complement':missing(v['eof'], displayed+([] if i==0 else [[1,37],[45,180],[181,360],[361,540],[541,725]])),'qualification':'P16 original role38–44 only; current other lines separately registered support, not historical material. P16 comparison bytes do not imply unseen historical source displays.'})
w={'crates/strategic-web/src/routes/quests.rs':[[1,30],[565,610],[620,705],[1145,1250],[1410,1475],[1850,1894],[2024,2040],[2050,2061],[2068,2080]],'crates/strategic-web/src/routes/settlements/overview.rs':[[115,225]],'crates/strategic-web/src/routes/settlements/mod.rs':[[50,75]],'crates/strategic-web/src/routes/settlements/encumbrance.rs':[[350,425]],'crates/strategic-web/src/routes/data.rs':[[1,150]],'crates/adventuresim-stdb-module/src/strategic/party_readiness.rs':[[1,55]],'crates/strategic-web/src/routes/mod.rs':[[180,200]],'crates/strategic-web/src/routes/settlements/camp.rs':[[925,1070],[1071,1246]],'crates/strategic-web/src/routes/travel.rs':[[385,480]],'crates/adventuresim-stdb-module/src/capability.rs':[[1,205]],'crates/strategic-web/src/routes/parties.rs':[[20,35],[140,210],[225,330],[355,355],[400,430],[475,580],[630,690],[735,750]],'crates/strategic-web/src/templates/recruitment.rs':[[10,30],[35,85],[320,350]],'crates/adventuresim-stdb-module/src/strategic/governance.rs':[[750,780],[830,850],[895,915],[930,945],[960,1030],[1068,1080],[1090,1150],[1180,1195],[1225,1348],[1350,1500]],'crates/adventuresim-core/src/capability.rs':[[120,225]]};supports=[]
for n in ['support-registration.json','more-support-registration.json','recruitment-support-registration.json','core-support-registration.json']:
 for x in load(n)['entries']:
  d=w[x['path']];supports.append({'revision':x['revision'],'path':x['path'],'sha256':x['sha256'],'local':x['local'],'eof':x['eof'],'displayed':d,'unread_complement':missing(x['eof'],d),'registration':n,'ordered_role_credit':0})
refs=[]
for n in ['registration.json','support-registration.json','more-support-registration.json','recruitment-support-registration.json','core-support-registration.json','historical-comparisons-registration.json']:refs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','method':'Prospective register then bounded personally displayed line-numbered source; navigation grep of registered supports is included in reported displayed windows. Test body text was inspected only. Receipt is new reconstruction of current work, not historical receipt.','registrations':refs,'assigned':assigned,'support':supports,'same_file_additional_context_is_support_only':True,'earlier_personal_support':'Prior 2706 95e service_quests.rs30–50 support, frozen separate evidence, is not imported into historical or ordered-role credit.','runtime_validation':'None; no product tests, builds, executions, fixtures, probes or repairs.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
