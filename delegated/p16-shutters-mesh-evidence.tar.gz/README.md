# Bounded P16 shutter-light and recipe-mesh evidence

This packet contains /root/rig_identity's bounded audit of original roles 2515
and 2516, separately registered P16 recovered objects and pinned 95e source,
separately registered current support, thirteen scoped perspectives, and
conditional findings. Start with `REPORT.json`, `registration.json`, and
`personal-read-receipt.json`.

The P16 registry records a dirty snapshot based at a120. The f82 Git objects
are transport for recovered bytes. Both assigned objects match their individual
files at a120, 6533, and 95e; the original dirty patch bytes remain unrecovered
and this equality does not establish the state of the entire snapshot.

`historical-059/` and `historical-774/` contain unmodified historical records.
The registry and queue selections are explicitly reconstructed, not original
records. `native-historical-packages/` preserves exact cached .crate bytes whose
hashes match the dirty P16 lock and whose extracted members match the original
059 files; this does not establish current dependency behavior or new native
body-read credit. `prior-packets/` retains the complete earlier finish/LOD
packet and its original manifest. Earlier publication assessments and source
archives retain their separate attribution and scopes. Historical records are
not checkpoint 3821 work.

`git-proofs.json` and `git-objects/` provide raw commit/tree inclusion chains;
`evidence-verification.json` covers evidence identities, historical packages,
archives, cited lines and read scopes only. `MANIFEST.json` inventories packet
files. Run `python3 verify-manifest.py` on the frozen packet. Run
`python3 verify-evidence.py` on a copied packet to repeat structural checks:
it rewrites that copy's verification timestamp. No product implementation,
repair, build, test, fixture, UI, simulation, native dependency execution,
runtime probe, or product validation was performed.
