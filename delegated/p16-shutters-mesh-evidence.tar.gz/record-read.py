from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');h=lambda p:hashlib.sha256((b/p).read_bytes()).hexdigest();reg=json.loads((b/'registration.json').read_bytes());sr=[json.loads((b/p).read_bytes()) for p in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json','support-registration-06.json','support-registration-07.json']]
def complement(n,ranges):
 used={i for a,z in ranges for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if (i>n or i in used) and start is not None:out.append([start,i-1]);start=None
 return out
assigned=[]
for e in reg['entries']:
 r=e['original_role'];material=e['original_material_ranges'];support=complement(e['actual_eof'],material) if material else [[1,e['actual_eof']]]
 assigned.append({'role':r,'path':e['path'],'source_identity':e['source_identity'],'sha256':e['sha256'],'actual_eof':e['actual_eof'],'contiguously_displayed_ranges':[[1,e['actual_eof']]],'not_contiguously_displayed_ranges':[],'display_chunks':[[1,115]] if r==2515 else [[1,87]],'p16_original_material_ranges':material,'separately_accounted_support_ranges':support,'source_archive':e['source_archive'],'qualification':'Personal full-body display; only P16 original material range is credited to original role; rest is bounded support. 95e is current separately.'})
support=[]
for r in sr:
 for e in r['entries']:
  seen=e['planned_ranges'];support.append({'path':e['path'],'revision':e['revision'],'sha256':e['sha256'],'actual_eof':e['actual_eof'],'contiguously_displayed_ranges':seen,'not_contiguously_displayed_ranges':complement(e['actual_eof'],seen),'source_archive':e['source_archive']})
x={'schema':'726-p16-shutters-mesh-personal-read-receipt-v1','reader':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'registrations':[{'path':p,'sha256':h(p)} for p in ['registration.json','support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json','support-registration-06.json','support-registration-07.json']],'assigned_personal_reads':assigned,'support_personal_reads':support,'qualification':'Prospective registration precedes actual displays; source code and existing fixtures inspected as text only. Historical reads by others remain separate.'};raw=(json.dumps(x,indent=2)+'\n').encode();(b/'personal-read-receipt.json').write_bytes(raw);print('sha256',hashlib.sha256(raw).hexdigest())
