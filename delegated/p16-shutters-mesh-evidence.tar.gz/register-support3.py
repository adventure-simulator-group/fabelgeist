from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';items=[('crates/adventuresim-building-generator/src/generator/wall_assemblies.rs',[(1020,1120)]),('crates/adventuresim-building-generator/src/model/layout.rs',[(1,100)])];entries=[]
for path,ranges in items:
 raw=subprocess.check_output(['git','show',rev+':'+path]);eof=len(raw.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/95e/'+path;p=b/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);entries.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':subprocess.check_output(['git','rev-parse',rev+':'+path],text=True).strip(),'bytes':len(raw),'actual_eof':eof,'planned_ranges':ranges,'source_archive':dest,'purpose':'bounded generator/opening identity support; no historical credit'})
r={'schema':'726-p16-shutters-mesh-support-registration-v3','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries};x=(json.dumps(r,indent=2)+'\n').encode();(b/'support-registration-03.json').write_bytes(x);print(hashlib.sha256(x).hexdigest());print('\n'.join(f"{e['path']} EOF {e['actual_eof']} {e['planned_ranges']}" for e in entries))
