use alloc::sync::Arc;
use bevy_derive::EnumVariantMeta;
use bevy_ecs::resource::Resource;
use bevy_math::Vec3;
#[cfg(feature = "serialize")]
use bevy_platform::collections::HashMap;
use bevy_platform::collections::HashSet;
use bytemuck::{bytes_of, cast_slice};
use core::hash::{Hash, Hasher};
#[cfg(feature = "serialize")]
use serde::{Deserialize, Serialize};
use thiserror::Error;
use wgpu_types::{BufferAddress, VertexAttribute, VertexFormat, VertexStepMode};

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MeshVertexAttribute {
    /// The friendly name of the vertex attribute
    pub name: &'static str,

    /// The _unique_ id of the vertex attribute. This will also determine sort ordering
    /// when generating vertex buffers. Built-in / standard attributes will use "close to zero"
    /// indices. When in doubt, use a random / very large u64 to avoid conflicts.
    pub id: MeshVertexAttributeId,

    /// The format of the vertex attribute.
    pub format: VertexFormat,
}

#[cfg(feature = "serialize")]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct SerializedMeshVertexAttribute {
    pub(crate) name: String,
    pub(crate) id: MeshVertexAttributeId,
    pub(crate) format: VertexFormat,
}

#[cfg(feature = "serialize")]
impl SerializedMeshVertexAttribute {
    pub(crate) fn from_mesh_vertex_attribute(attribute: MeshVertexAttribute) -> Self {
        Self {
            name: attribute.name.to_string(),
            id: attribute.id,
            format: attribute.format,
        }
    }

    pub(crate) fn try_into_mesh_vertex_attribute(
        self,
        possible_attributes: &HashMap<Box<str>, MeshVertexAttribute>,
    ) -> Option<MeshVertexAttribute> {
        let attr = possible_attributes.get(self.name.as_str())?;
        if attr.id == self.id {
            Some(*attr)
        } else {
            None
        }
    }
}

impl MeshVertexAttribute {
    pub const fn new(name: &'static str, id: u64, format: VertexFormat) -> Self {
        Self {
            name,
            id: MeshVertexAttributeId(id),
            format,
        }
    }

    pub const fn at_shader_location(&self, shader_location: u32) -> VertexAttributeDescriptor {
        VertexAttributeDescriptor::new(shader_location, self.id, self.name)
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Ord, PartialOrd, Hash)]
#[cfg_attr(feature = "serialize", derive(Serialize, Deserialize))]
pub struct MeshVertexAttributeId(u64);

impl From<MeshVertexAttribute> for MeshVertexAttributeId {
    fn from(attribute: MeshVertexAttribute) -> Self {
        attribute.id
    }
}

#[derive(Debug, Clone, Hash, Eq, PartialEq)]
pub struct MeshVertexBufferLayout {
    pub(crate) attribute_ids: Vec<MeshVertexAttributeId>,
    pub(crate) layout: VertexBufferLayout,
}

impl MeshVertexBufferLayout {
    pub fn new(attribute_ids: Vec<MeshVertexAttributeId>, layout: VertexBufferLayout) -> Self {
        Self {
            attribute_ids,
            layout,
        }
    }

    #[inline]
    pub fn contains(&self, attribute_id: impl Into<MeshVertexAttributeId>) -> bool {
        self.attribute_ids.contains(&attribute_id.into())
    }

    #[inline]
    pub fn attribute_ids(&self) -> &[MeshVertexAttributeId] {
        &self.attribute_ids
    }

    #[inline]
    pub fn layout(&self) -> &VertexBufferLayout {
        &self.layout
    }

    pub fn get_layout(
        &self,
        attribute_descriptors: &[VertexAttributeDescriptor],
    ) -> Result<VertexBufferLayout, MissingVertexAttributeError> {
        let mut attributes = Vec::with_capacity(attribute_descriptors.len());
        for attribute_descriptor in attribute_descriptors {
            if let Some(index) = self
                .attribute_ids
                .iter()
                .position(|id| *id == attribute_descriptor.id)
            {
                let layout_attribute = &self.layout.attributes[index];
                attributes.push(VertexAttribute {
                    format: layout_attribute.format,
                    offset: layout_attribute.offset,
                    shader_location: attribute_descriptor.shader_location,
                });
            } else {
                return Err(MissingVertexAttributeError {
                    id: attribute_descriptor.id,
                    name: attribute_descriptor.name,
                    pipeline_type: None,
                });
            }
        }

        Ok(VertexBufferLayout {
            array_stride: self.layout.array_stride,
            step_mode: self.layout.step_mode,
            attributes,
        })
    }
}

#[derive(Error, Debug)]
#[error("Mesh is missing requested attribute: {name} ({id:?}, pipeline type: {pipeline_type:?})")]
pub struct MissingVertexAttributeError {
    pub pipeline_type: Option<&'static str>,
    id: MeshVertexAttributeId,
    name: &'static str,
}

pub struct VertexAttributeDescriptor {
    pub shader_location: u32,
    pub id: MeshVertexAttributeId,
    name: &'static str,
}

impl VertexAttributeDescriptor {
    pub const fn new(shader_location: u32, id: MeshVertexAttributeId, name: &'static str) -> Self {
        Self {
            shader_location,
            id,
            name,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub(crate) struct MeshAttributeData {
    pub(crate) attribute: MeshVertexAttribute,
    pub(crate) values: VertexAttributeValues,
}

#[cfg(feature = "serialize")]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct SerializedMeshAttributeData {
    pub(crate) attribute: SerializedMeshVertexAttribute,
    pub(crate) values: VertexAttributeValues,
}

#[cfg(feature = "serialize")]
impl SerializedMeshAttributeData {
    pub(crate) fn from_mesh_attribute_data(data: MeshAttributeData) -> Self {
        Self {
            attribute: SerializedMeshVertexAttribute::from_mesh_vertex_attribute(data.attribute),
            values: data.values,
        }
    }

    pub(crate) fn try_into_mesh_attribute_data(
        self,
        possible_attributes: &HashMap<Box<str>, MeshVertexAttribute>,
    ) -> Option<MeshAttributeData> {
        let attribute = self
            .attribute
            .try_into_mesh_vertex_attribute(possible_attributes)?;
        Some(MeshAttributeData {
            attribute,
            values: self.values,
        })
    }
}

/// Compute a vector whose direction is the normal of the triangle formed by
/// points a, b, c, and whose magnitude is double the area of the triangle. This
/// is useful for computing smooth normals where the contributing normals are
/// proportionate to the areas of the triangles as [discussed
/// here](https://iquilezles.org/articles/normals/).
///
/// Question: Why double the area? Because the area of a triangle _A_ is
/// determined by this equation:
///
/// _A = |(b - a) x (c - a)| / 2_
///
/// By computing _2 A_ we avoid a division operation, and when calculating the
/// the sum of these vectors which are then normalized, a constant multiple has
/// no effect.
#[inline]
pub fn triangle_area_normal(a: [f32; 3], b: [f32; 3], c: [f32; 3]) -> [f32; 3] {
    let (a, b, c) = (Vec3::from(a), Vec3::from(b), Vec3::from(c));
    (b - a).cross(c - a).into()
}

/// Compute the normal of a face made of three points: a, b, and c.
#[inline]
pub fn triangle_normal(a: [f32; 3], b: [f32; 3], c: [f32; 3]) -> [f32; 3] {
    let (a, b, c) = (Vec3::from(a), Vec3::from(b), Vec3::from(c));
    (b - a).cross(c - a).normalize_or_zero().into()
}

/// Contains an array where each entry describes a property of a single vertex.
/// Matches the [`VertexFormats`](VertexFormat).
#[derive(Clone, Debug, EnumVariantMeta, PartialEq)]
#[cfg_attr(feature = "serialize", derive(Serialize, Deserialize))]
pub enum VertexAttributeValues {
    /// One unsigned byte (u8). `u32` in shaders.
    Uint8(Vec<u8>),
    /// Two unsigned bytes (u8). `vec2<u32>` in shaders.
    Uint8x2(Vec<[u8; 2]>),
    /// Four unsigned bytes (u8). `vec4<u32>` in shaders.
    Uint8x4(Vec<[u8; 4]>),
    /// One signed byte (i8). `i32` in shaders.
    Sint8(Vec<i8>),
    /// Two signed bytes (i8). `vec2<i32>` in shaders.
    Sint8x2(Vec<[i8; 2]>),
    /// Four signed bytes (i8). `vec4<i32>` in shaders.
    Sint8x4(Vec<[i8; 4]>),
    /// One unsigned byte (u8). [0, 255] converted to float [0, 1] `f32` in shaders.
    Unorm8(Vec<u8>),
    /// Two unsigned bytes (u8). [0, 255] converted to float [0, 1] `vec2<f32>` in shaders.
    Unorm8x2(Vec<[u8; 2]>),
    /// Four unsigned bytes (u8). [0, 255] converted to float [0, 1] `vec4<f32>` in shaders.
    Unorm8x4(Vec<[u8; 4]>),
    /// One signed byte (i8). [&minus;127, 127] converted to float [&minus;1, 1] `f32` in shaders.
    Snorm8(Vec<i8>),
    /// Two signed bytes (i8). [&minus;127, 127] converted to float [&minus;1, 1] `vec2<f32>` in shaders.
    Snorm8x2(Vec<[i8; 2]>),
    /// Four signed bytes (i8). [&minus;127, 127] converted to float [&minus;1, 1] `vec4<f32>` in shaders.
    Snorm8x4(Vec<[i8; 4]>),
    /// One unsigned short (u16). `u32` in shaders.
    Uint16(Vec<u16>),
    /// Two unsigned shorts (u16). `vec2<u32>` in shaders.
    Uint16x2(Vec<[u16; 2]>),
    /// Four unsigned shorts (u16). `vec4<u32>` in shaders.
    Uint16x4(Vec<[u16; 4]>),
    /// One signed short (i16). `i32` in shaders.
    Sint16(Vec<i16>),
    /// Two signed shorts (i16). `vec2<i32>` in shaders.
    Sint16x2(Vec<[i16; 2]>),
    /// Four signed shorts (i16). `vec4<i32>` in shaders.
    Sint16x4(Vec<[i16; 4]>),
    /// One unsigned short (u16). [0, 65535] converted to float [0, 1] `f32` in shaders.
    Unorm16(Vec<u16>),
    /// Two unsigned shorts (u16). [0, 65535] converted to float [0, 1] `vec2<f32>` in shaders.
    Unorm16x2(Vec<[u16; 2]>),
    /// Four unsigned shorts (u16). [0, 65535] converted to float [0, 1] `vec4<f32>` in shaders.
    Unorm16x4(Vec<[u16; 4]>),
    /// One signed short (i16). [&minus;32767, 32767] converted to float [&minus;1, 1] `f32` in shaders.
    Snorm16(Vec<i16>),
    /// Two signed shorts (i16). [&minus;32767, 32767] converted to float [&minus;1, 1] `vec2<f32>` in shaders.
    Snorm16x2(Vec<[i16; 2]>),
    /// Four signed shorts (i16). [&minus;32767, 32767] converted to float [&minus;1, 1] `vec4<f32>` in shaders.
    Snorm16x4(Vec<[i16; 4]>),
    /// One half-precision float (no Rust equiv). `f32` in shaders.
    Float16(Vec<half::f16>),
    /// Two half-precision floats (no Rust equiv). `vec2<f32>` in shaders.
    Float16x2(Vec<[half::f16; 2]>),
    /// Four half-precision floats (no Rust equiv). `vec4<f32>` in shaders.
    Float16x4(Vec<[half::f16; 4]>),
    /// One single-precision float (f32). `f32` in shaders.
    Float32(Vec<f32>),
    /// Two single-precision floats (f32). `vec2<f32>` in shaders.
    Float32x2(Vec<[f32; 2]>),
    /// Three single-precision floats (f32). `vec3<f32>` in shaders.
    Float32x3(Vec<[f32; 3]>),
    /// Four single-precision floats (f32). `vec4<f32>` in shaders.
    Float32x4(Vec<[f32; 4]>),
    /// One unsigned int (u32). `u32` in shaders.
    Uint32(Vec<u32>),
    /// Two unsigned ints (u32). `vec2<u32>` in shaders.
    Uint32x2(Vec<[u32; 2]>),
    /// Three unsigned ints (u32). `vec3<u32>` in shaders.
    Uint32x3(Vec<[u32; 3]>),
    /// Four unsigned ints (u32). `vec4<u32>` in shaders.
    Uint32x4(Vec<[u32; 4]>),
    /// One signed int (i32). `i32` in shaders.
    Sint32(Vec<i32>),
    /// Two signed ints (i32). `vec2<i32>` in shaders.
    Sint32x2(Vec<[i32; 2]>),
    /// Three signed ints (i32). `vec3<i32>` in shaders.
    Sint32x3(Vec<[i32; 3]>),
    /// Four signed ints (i32). `vec4<i32>` in shaders.
    Sint32x4(Vec<[i32; 4]>),
    /// One double-precision float (f64). `f32` in shaders. Requires [`wgpu_types::Features::VERTEX_ATTRIBUTE_64BIT`].
    Float64(Vec<f64>),
    /// Two double-precision floats (f64). `vec2<f32>` in shaders. Requires [`wgpu_types::Features::VERTEX_ATTRIBUTE_64BIT`].
    Float64x2(Vec<[f64; 2]>),
    /// Three double-precision floats (f64). `vec3<f32>` in shaders. Requires [`wgpu_types::Features::VERTEX_ATTRIBUTE_64BIT`].
    Float64x3(Vec<[f64; 3]>),
    /// Four double-precision floats (f64). `vec4<f32>` in shaders. Requires [`wgpu_types::Features::VERTEX_ATTRIBUTE_64BIT`].
    Float64x4(Vec<[f64; 4]>),
    /// Three unsigned 10-bit integers and one 2-bit integer, packed into a 32-bit integer (u32). [0, 1023] and [0, 3] converted to float [0, 1] `vec4<f32>` in shaders.
    Unorm10_10_10_2(Vec<u32>),
    /// Four unsigned 8-bit integers (u8) in BGRA. [0, 255] converted to float [0, 1] `vec4<f32>` RGBA in shaders.
    Unorm8x4Bgra(Vec<[u8; 4]>),
}

impl VertexAttributeValues {
    /// Creates a new [`VertexAttributeValues`] with the storage for given [`VertexFormat`].
    pub(crate) fn new(format: VertexFormat) -> Self {
        match format {
            VertexFormat::Uint8x2 => VertexAttributeValues::Uint8x2(Vec::new()),
            VertexFormat::Uint8x4 => VertexAttributeValues::Uint8x4(Vec::new()),
            VertexFormat::Sint8x2 => VertexAttributeValues::Sint8x2(Vec::new()),
            VertexFormat::Sint8x4 => VertexAttributeValues::Sint8x4(Vec::new()),
            VertexFormat::Unorm8x2 => VertexAttributeValues::Unorm8x2(Vec::new()),
            VertexFormat::Unorm8x4 => VertexAttributeValues::Unorm8x4(Vec::new()),
            VertexFormat::Snorm8x2 => VertexAttributeValues::Snorm8x2(Vec::new()),
            VertexFormat::Snorm8x4 => VertexAttributeValues::Snorm8x4(Vec::new()),
            VertexFormat::Uint16x2 => VertexAttributeValues::Uint16x2(Vec::new()),
            VertexFormat::Uint16x4 => VertexAttributeValues::Uint16x4(Vec::new()),
            VertexFormat::Sint16x2 => VertexAttributeValues::Sint16x2(Vec::new()),
            VertexFormat::Sint16x4 => VertexAttributeValues::Sint16x4(Vec::new()),
            VertexFormat::Unorm16x2 => VertexAttributeValues::Unorm16x2(Vec::new()),
            VertexFormat::Unorm16x4 => VertexAttributeValues::Unorm16x4(Vec::new()),
            VertexFormat::Snorm16x2 => VertexAttributeValues::Snorm16x2(Vec::new()),
            VertexFormat::Snorm16x4 => VertexAttributeValues::Snorm16x4(Vec::new()),
            VertexFormat::Float32 => VertexAttributeValues::Float32(Vec::new()),
            VertexFormat::Float32x2 => VertexAttributeValues::Float32x2(Vec::new()),
            VertexFormat::Float32x3 => VertexAttributeValues::Float32x3(Vec::new()),
            VertexFormat::Float32x4 => VertexAttributeValues::Float32x4(Vec::new()),
            VertexFormat::Uint32 => VertexAttributeValues::Uint32(Vec::new()),
            VertexFormat::Uint32x2 => VertexAttributeValues::Uint32x2(Vec::new()),
            VertexFormat::Uint32x3 => VertexAttributeValues::Uint32x3(Vec::new()),
            VertexFormat::Uint32x4 => VertexAttributeValues::Uint32x4(Vec::new()),
            VertexFormat::Sint32 => VertexAttributeValues::Sint32(Vec::new()),
            VertexFormat::Sint32x2 => VertexAttributeValues::Sint32x2(Vec::new()),
            VertexFormat::Sint32x3 => VertexAttributeValues::Sint32x3(Vec::new()),
            VertexFormat::Sint32x4 => VertexAttributeValues::Sint32x4(Vec::new()),
            VertexFormat::Uint8 => VertexAttributeValues::Uint8(Vec::new()),
            VertexFormat::Sint8 => VertexAttributeValues::Sint8(Vec::new()),
            VertexFormat::Snorm8 => VertexAttributeValues::Snorm8(Vec::new()),
            VertexFormat::Unorm8 => VertexAttributeValues::Unorm8(Vec::new()),
            VertexFormat::Uint16 => VertexAttributeValues::Uint16(Vec::new()),
            VertexFormat::Sint16 => VertexAttributeValues::Sint16(Vec::new()),
            VertexFormat::Snorm16 => VertexAttributeValues::Snorm16(Vec::new()),
            VertexFormat::Unorm16 => VertexAttributeValues::Unorm16(Vec::new()),
            VertexFormat::Float16 => VertexAttributeValues::Float16(Vec::new()),
            VertexFormat::Float16x2 => VertexAttributeValues::Float16x2(Vec::new()),
            VertexFormat::Float16x4 => VertexAttributeValues::Float16x4(Vec::new()),
            VertexFormat::Float64 => VertexAttributeValues::Float64(Vec::new()),
            VertexFormat::Float64x2 => VertexAttributeValues::Float64x2(Vec::new()),
            VertexFormat::Float64x3 => VertexAttributeValues::Float64x3(Vec::new()),
            VertexFormat::Float64x4 => VertexAttributeValues::Float64x4(Vec::new()),
            VertexFormat::Unorm8x4Bgra => VertexAttributeValues::Unorm8x4Bgra(Vec::new()),
            VertexFormat::Unorm10_10_10_2 => VertexAttributeValues::Unorm10_10_10_2(Vec::new()),
        }
    }

    /// Returns the number of vertices in this [`VertexAttributeValues`]. For a single
    /// mesh, all of the [`VertexAttributeValues`] must have the same length.
    #[expect(
        clippy::match_same_arms,
        reason = "Although the `values` binding on some match arms may have matching types, each variant has different semantics; thus it's not guaranteed that they will use the same type forever."
    )]
    pub fn len(&self) -> usize {
        match self {
            VertexAttributeValues::Float32(values) => values.len(),
            VertexAttributeValues::Sint32(values) => values.len(),
            VertexAttributeValues::Uint32(values) => values.len(),
            VertexAttributeValues::Float32x2(values) => values.len(),
            VertexAttributeValues::Sint32x2(values) => values.len(),
            VertexAttributeValues::Uint32x2(values) => values.len(),
            VertexAttributeValues::Float32x3(values) => values.len(),
            VertexAttributeValues::Sint32x3(values) => values.len(),
            VertexAttributeValues::Uint32x3(values) => values.len(),
            VertexAttributeValues::Float32x4(values) => values.len(),
            VertexAttributeValues::Sint32x4(values) => values.len(),
            VertexAttributeValues::Uint32x4(values) => values.len(),
            VertexAttributeValues::Sint16x2(values) => values.len(),
            VertexAttributeValues::Snorm16x2(values) => values.len(),
            VertexAttributeValues::Uint16x2(values) => values.len(),
            VertexAttributeValues::Unorm16x2(values) => values.len(),
            VertexAttributeValues::Sint16x4(values) => values.len(),
            VertexAttributeValues::Snorm16x4(values) => values.len(),
            VertexAttributeValues::Uint16x4(values) => values.len(),
            VertexAttributeValues::Unorm16x4(values) => values.len(),
            VertexAttributeValues::Sint8x2(values) => values.len(),
            VertexAttributeValues::Snorm8x2(values) => values.len(),
            VertexAttributeValues::Uint8x2(values) => values.len(),
            VertexAttributeValues::Unorm8x2(values) => values.len(),
            VertexAttributeValues::Sint8x4(values) => values.len(),
            VertexAttributeValues::Snorm8x4(values) => values.len(),
            VertexAttributeValues::Uint8x4(values) => values.len(),
            VertexAttributeValues::Unorm8x4(values) => values.len(),
            VertexAttributeValues::Uint8(values) => values.len(),
            VertexAttributeValues::Sint8(values) => values.len(),
            VertexAttributeValues::Unorm8(values) => values.len(),
            VertexAttributeValues::Snorm8(values) => values.len(),
            VertexAttributeValues::Uint16(values) => values.len(),
            VertexAttributeValues::Sint16(values) => values.len(),
            VertexAttributeValues::Unorm16(values) => values.len(),
            VertexAttributeValues::Snorm16(values) => values.len(),
            VertexAttributeValues::Float16(values) => values.len(),
            VertexAttributeValues::Float16x2(values) => values.len(),
            VertexAttributeValues::Float16x4(values) => values.len(),
            VertexAttributeValues::Float64(values) => values.len(),
            VertexAttributeValues::Float64x2(values) => values.len(),
            VertexAttributeValues::Float64x3(values) => values.len(),
            VertexAttributeValues::Float64x4(values) => values.len(),
            VertexAttributeValues::Unorm10_10_10_2(values) => values.len(),
            VertexAttributeValues::Unorm8x4Bgra(values) => values.len(),
        }
    }

    /// Returns `true` if there are no vertices in this [`VertexAttributeValues`].
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Returns the values as float triples if possible.
    pub fn as_float3(&self) -> Option<&[[f32; 3]]> {
        match self {
            VertexAttributeValues::Float32x3(values) => Some(values),
            _ => None,
        }
    }

    // TODO: add vertex format as parameter here and perform type conversions
    /// Flattens the [`VertexAttributeValues`] into a sequence of bytes. This is
    /// useful for serialization and sending to the GPU.
    #[expect(
        clippy::match_same_arms,
        reason = "Although the `values` binding on some match arms may have matching types, each variant has different semantics; thus it's not guaranteed that they will use the same type forever."
    )]
    pub fn get_bytes(&self) -> &[u8] {
        match self {
            VertexAttributeValues::Float32(values) => cast_slice(values),
            VertexAttributeValues::Sint32(values) => cast_slice(values),
            VertexAttributeValues::Uint32(values) => cast_slice(values),
            VertexAttributeValues::Float32x2(values) => cast_slice(values),
            VertexAttributeValues::Sint32x2(values) => cast_slice(values),
            VertexAttributeValues::Uint32x2(values) => cast_slice(values),
            VertexAttributeValues::Float32x3(values) => cast_slice(values),
            VertexAttributeValues::Sint32x3(values) => cast_slice(values),
            VertexAttributeValues::Uint32x3(values) => cast_slice(values),
            VertexAttributeValues::Float32x4(values) => cast_slice(values),
            VertexAttributeValues::Sint32x4(values) => cast_slice(values),
            VertexAttributeValues::Uint32x4(values) => cast_slice(values),
            VertexAttributeValues::Sint16x2(values) => cast_slice(values),
            VertexAttributeValues::Snorm16x2(values) => cast_slice(values),
            VertexAttributeValues::Uint16x2(values) => cast_slice(values),
            VertexAttributeValues::Unorm16x2(values) => cast_slice(values),
            VertexAttributeValues::Sint16x4(values) => cast_slice(values),
            VertexAttributeValues::Snorm16x4(values) => cast_slice(values),
            VertexAttributeValues::Uint16x4(values) => cast_slice(values),
            VertexAttributeValues::Unorm16x4(values) => cast_slice(values),
            VertexAttributeValues::Sint8x2(values) => cast_slice(values),
            VertexAttributeValues::Snorm8x2(values) => cast_slice(values),
            VertexAttributeValues::Uint8x2(values) => cast_slice(values),
            VertexAttributeValues::Unorm8x2(values) => cast_slice(values),
            VertexAttributeValues::Sint8x4(values) => cast_slice(values),
            VertexAttributeValues::Snorm8x4(values) => cast_slice(values),
            VertexAttributeValues::Uint8x4(values) => cast_slice(values),
            VertexAttributeValues::Unorm8x4(values) => cast_slice(values),
            VertexAttributeValues::Uint8(values) => cast_slice(values),
            VertexAttributeValues::Sint8(values) => cast_slice(values),
            VertexAttributeValues::Unorm8(values) => cast_slice(values),
            VertexAttributeValues::Snorm8(values) => cast_slice(values),
            VertexAttributeValues::Uint16(values) => cast_slice(values),
            VertexAttributeValues::Sint16(values) => cast_slice(values),
            VertexAttributeValues::Unorm16(values) => cast_slice(values),
            VertexAttributeValues::Snorm16(values) => cast_slice(values),
            VertexAttributeValues::Float16(values) => cast_slice(values),
            VertexAttributeValues::Float16x2(values) => cast_slice(values),
            VertexAttributeValues::Float16x4(values) => cast_slice(values),
            VertexAttributeValues::Float64(values) => cast_slice(values),
            VertexAttributeValues::Float64x2(values) => cast_slice(values),
            VertexAttributeValues::Float64x3(values) => cast_slice(values),
            VertexAttributeValues::Float64x4(values) => cast_slice(values),
            VertexAttributeValues::Unorm10_10_10_2(values) => cast_slice(values),
            VertexAttributeValues::Unorm8x4Bgra(values) => cast_slice(values),
        }
    }

    #[expect(
        clippy::match_same_arms,
        reason = "Although the `values` binding on some match arms may have matching types, each variant has different semantics; thus it's not guaranteed that they will use the same type forever."
    )]
    pub(crate) fn get_bytes_at(&self, i: usize) -> &[u8] {
        match self {
            VertexAttributeValues::Float32(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint32(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint32(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float32x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint32x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint32x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float32x3(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint32x3(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint32x3(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float32x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint32x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint32x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint16x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Snorm16x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint16x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm16x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint16x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Snorm16x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint16x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm16x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint8x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Snorm8x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint8x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm8x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint8x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Snorm8x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint8x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm8x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint8(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint8(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm8(values) => bytes_of(&values[i]),
            VertexAttributeValues::Snorm8(values) => bytes_of(&values[i]),
            VertexAttributeValues::Uint16(values) => bytes_of(&values[i]),
            VertexAttributeValues::Sint16(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm16(values) => bytes_of(&values[i]),
            VertexAttributeValues::Snorm16(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float16(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float16x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float16x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float64(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float64x2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float64x3(values) => bytes_of(&values[i]),
            VertexAttributeValues::Float64x4(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm10_10_10_2(values) => bytes_of(&values[i]),
            VertexAttributeValues::Unorm8x4Bgra(values) => bytes_of(&values[i]),
        }
    }

    #[expect(
        clippy::match_same_arms,
        reason = "Although the `values` binding on some match arms may have matching types, each variant has different semantics; thus it's not guaranteed that they will use the same type forever."
    )]
    pub(crate) fn push_from(&mut self, source: &VertexAttributeValues, i: usize) {
        match (self, source) {
            (VertexAttributeValues::Float32(this), VertexAttributeValues::Float32(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float32(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Sint32(this), VertexAttributeValues::Sint32(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint32(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint32(this), VertexAttributeValues::Uint32(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint32(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Float32x2(this), VertexAttributeValues::Float32x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float32x2(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Sint32x2(this), VertexAttributeValues::Sint32x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint32x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint32x2(this), VertexAttributeValues::Uint32x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint32x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Float32x3(this), VertexAttributeValues::Float32x3(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float32x3(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Sint32x3(this), VertexAttributeValues::Sint32x3(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint32x3(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint32x3(this), VertexAttributeValues::Uint32x3(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint32x3(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Float32x4(this), VertexAttributeValues::Float32x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float32x4(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Sint32x4(this), VertexAttributeValues::Sint32x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint32x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint32x4(this), VertexAttributeValues::Uint32x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint32x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Sint16x2(this), VertexAttributeValues::Sint16x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint16x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Snorm16x2(this), VertexAttributeValues::Snorm16x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Snorm16x2(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Uint16x2(this), VertexAttributeValues::Uint16x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint16x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Unorm16x2(this), VertexAttributeValues::Unorm16x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm16x2(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Sint16x4(this), VertexAttributeValues::Sint16x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint16x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Snorm16x4(this), VertexAttributeValues::Snorm16x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Snorm16x4(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Uint16x4(this), VertexAttributeValues::Uint16x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint16x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Unorm16x4(this), VertexAttributeValues::Unorm16x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm16x4(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Sint8x2(this), VertexAttributeValues::Sint8x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint8x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Snorm8x2(this), VertexAttributeValues::Snorm8x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Snorm8x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint8x2(this), VertexAttributeValues::Uint8x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint8x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Unorm8x2(this), VertexAttributeValues::Unorm8x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm8x2(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Sint8x4(this), VertexAttributeValues::Sint8x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint8x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Snorm8x4(this), VertexAttributeValues::Snorm8x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Snorm8x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint8x4(this), VertexAttributeValues::Uint8x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint8x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Unorm8x4(this), VertexAttributeValues::Unorm8x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm8x4(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint8(this), VertexAttributeValues::Uint8(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint8(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Sint8(this), VertexAttributeValues::Sint8(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint8(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Unorm8(this), VertexAttributeValues::Unorm8(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm8(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Snorm8(this), VertexAttributeValues::Snorm8(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Snorm8(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Uint16(this), VertexAttributeValues::Uint16(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Uint16(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Sint16(this), VertexAttributeValues::Sint16(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Sint16(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Unorm16(this), VertexAttributeValues::Unorm16(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm16(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Snorm16(this), VertexAttributeValues::Snorm16(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Snorm16(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Float16(this), VertexAttributeValues::Float16(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float16(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Float16x2(this), VertexAttributeValues::Float16x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float16x2(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Float16x4(this), VertexAttributeValues::Float16x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float16x4(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Float64(this), VertexAttributeValues::Float64(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float64(_), _) => panic!("Mismatched vertex attribute values"),
            (VertexAttributeValues::Float64x2(this), VertexAttributeValues::Float64x2(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float64x2(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Float64x3(this), VertexAttributeValues::Float64x3(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float64x3(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (VertexAttributeValues::Float64x4(this), VertexAttributeValues::Float64x4(source)) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Float64x4(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (
                VertexAttributeValues::Unorm10_10_10_2(this),
                VertexAttributeValues::Unorm10_10_10_2(source),
            ) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm10_10_10_2(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
            (
                VertexAttributeValues::Unorm8x4Bgra(this),
                VertexAttributeValues::Unorm8x4Bgra(source),
            ) => {
                this.push(source[i]);
            }
            (VertexAttributeValues::Unorm8x4Bgra(_), _) => {
                panic!("Mismatched vertex attribute values")
            }
        }
    }

    #[expect(
        clippy::match_same_arms,
        reason = "Although the `values` binding on some match arms may have matching types, each variant has different semantics; thus it's not guaranteed that they will use the same type forever."
    )]
    pub(crate) fn shrink_to_fit(&mut self) {
        match self {
            VertexAttributeValues::Float32(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint32(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint32(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float32x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint32x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint32x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float32x3(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint32x3(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint32x3(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float32x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint32x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint32x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint16x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Snorm16x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint16x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm16x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint16x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Snorm16x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint16x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm16x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint8x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Snorm8x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint8x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm8x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint8x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Snorm8x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint8x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm8x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint8(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint8(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm8(v) => v.shrink_to_fit(),
            VertexAttributeValues::Snorm8(v) => v.shrink_to_fit(),
            VertexAttributeValues::Uint16(v) => v.shrink_to_fit(),
            VertexAttributeValues::Sint16(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm16(v) => v.shrink_to_fit(),
            VertexAttributeValues::Snorm16(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float16(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float16x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float16x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float64(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float64x2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float64x3(v) => v.shrink_to_fit(),
            VertexAttributeValues::Float64x4(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm10_10_10_2(v) => v.shrink_to_fit(),
            VertexAttributeValues::Unorm8x4Bgra(v) => v.shrink_to_fit(),
        }
    }
}

impl From<&VertexAttributeValues> for VertexFormat {
    fn from(values: &VertexAttributeValues) -> Self {
        match values {
            VertexAttributeValues::Float32(_) => VertexFormat::Float32,
            VertexAttributeValues::Sint32(_) => VertexFormat::Sint32,
            VertexAttributeValues::Uint32(_) => VertexFormat::Uint32,
            VertexAttributeValues::Float32x2(_) => VertexFormat::Float32x2,
            VertexAttributeValues::Sint32x2(_) => VertexFormat::Sint32x2,
            VertexAttributeValues::Uint32x2(_) => VertexFormat::Uint32x2,
            VertexAttributeValues::Float32x3(_) => VertexFormat::Float32x3,
            VertexAttributeValues::Sint32x3(_) => VertexFormat::Sint32x3,
            VertexAttributeValues::Uint32x3(_) => VertexFormat::Uint32x3,
            VertexAttributeValues::Float32x4(_) => VertexFormat::Float32x4,
            VertexAttributeValues::Sint32x4(_) => VertexFormat::Sint32x4,
            VertexAttributeValues::Uint32x4(_) => VertexFormat::Uint32x4,
            VertexAttributeValues::Sint16x2(_) => VertexFormat::Sint16x2,
            VertexAttributeValues::Snorm16x2(_) => VertexFormat::Snorm16x2,
            VertexAttributeValues::Uint16x2(_) => VertexFormat::Uint16x2,
            VertexAttributeValues::Unorm16x2(_) => VertexFormat::Unorm16x2,
            VertexAttributeValues::Sint16x4(_) => VertexFormat::Sint16x4,
            VertexAttributeValues::Snorm16x4(_) => VertexFormat::Snorm16x4,
            VertexAttributeValues::Uint16x4(_) => VertexFormat::Uint16x4,
            VertexAttributeValues::Unorm16x4(_) => VertexFormat::Unorm16x4,
            VertexAttributeValues::Sint8x2(_) => VertexFormat::Sint8x2,
            VertexAttributeValues::Snorm8x2(_) => VertexFormat::Snorm8x2,
            VertexAttributeValues::Uint8x2(_) => VertexFormat::Uint8x2,
            VertexAttributeValues::Unorm8x2(_) => VertexFormat::Unorm8x2,
            VertexAttributeValues::Sint8x4(_) => VertexFormat::Sint8x4,
            VertexAttributeValues::Snorm8x4(_) => VertexFormat::Snorm8x4,
            VertexAttributeValues::Uint8x4(_) => VertexFormat::Uint8x4,
            VertexAttributeValues::Unorm8x4(_) => VertexFormat::Unorm8x4,
            VertexAttributeValues::Uint8(_) => VertexFormat::Uint8,
            VertexAttributeValues::Sint8(_) => VertexFormat::Sint8,
            VertexAttributeValues::Unorm8(_) => VertexFormat::Unorm8,
            VertexAttributeValues::Snorm8(_) => VertexFormat::Snorm8,
            VertexAttributeValues::Uint16(_) => VertexFormat::Uint16,
            VertexAttributeValues::Sint16(_) => VertexFormat::Sint16,
            VertexAttributeValues::Unorm16(_) => VertexFormat::Unorm16,
            VertexAttributeValues::Snorm16(_) => VertexFormat::Snorm16,
            VertexAttributeValues::Float16(_) => VertexFormat::Float16,
            VertexAttributeValues::Float16x2(_) => VertexFormat::Float16x2,
            VertexAttributeValues::Float16x4(_) => VertexFormat::Float16x4,
            VertexAttributeValues::Float64(_) => VertexFormat::Float64,
            VertexAttributeValues::Float64x2(_) => VertexFormat::Float64x2,
            VertexAttributeValues::Float64x3(_) => VertexFormat::Float64x3,
            VertexAttributeValues::Float64x4(_) => VertexFormat::Float64x4,
            VertexAttributeValues::Unorm10_10_10_2(_) => VertexFormat::Unorm10_10_10_2,
            VertexAttributeValues::Unorm8x4Bgra(_) => VertexFormat::Unorm8x4Bgra,
        }
    }
}

/// Describes how the vertex buffer is interpreted.
#[derive(Default, Clone, Debug, Hash, Eq, PartialEq)]
pub struct VertexBufferLayout {
    /// The stride, in bytes, between elements of this buffer.
    pub array_stride: BufferAddress,
    /// How often this vertex buffer is "stepped" forward.
    pub step_mode: VertexStepMode,
    /// The list of attributes which comprise a single vertex.
    pub attributes: Vec<VertexAttribute>,
}

impl VertexBufferLayout {
    /// Creates a new densely packed [`VertexBufferLayout`] from an iterator of vertex formats.
    /// Iteration order determines the `shader_location` and `offset` of the [`VertexAttributes`](VertexAttribute).
    /// The first iterated item will have a `shader_location` and `offset` of zero.
    /// The `array_stride` is the sum of the size of the iterated [`VertexFormats`](VertexFormat) (in bytes).
    pub fn from_vertex_formats<T: IntoIterator<Item = VertexFormat>>(
        step_mode: VertexStepMode,
        vertex_formats: T,
    ) -> Self {
        let mut offset = 0;
        let mut attributes = Vec::new();
        for (shader_location, format) in vertex_formats.into_iter().enumerate() {
            attributes.push(VertexAttribute {
                format,
                offset,
                shader_location: shader_location as u32,
            });
            offset += format.size();
        }

        VertexBufferLayout {
            array_stride: offset,
            step_mode,
            attributes,
        }
    }

    /// Returns a [`VertexBufferLayout`] with the shader location of every attribute offset by
    /// `location`.
    pub fn offset_locations_by(mut self, location: u32) -> Self {
        self.attributes.iter_mut().for_each(|attr| {
            attr.shader_location += location;
        });
        self
    }
}

/// Describes the layout of the mesh vertices in GPU memory.
///
/// At most one copy of a mesh vertex buffer layout ever exists in GPU memory at
/// once. Therefore, comparing these for equality requires only a single pointer
/// comparison, and this type's [`PartialEq`] and [`Hash`] implementations take
/// advantage of this. To that end, this type doesn't implement
/// [`bevy_derive::Deref`] or [`bevy_derive::DerefMut`] in order to reduce the
/// possibility of accidental deep comparisons, which would be needlessly
/// expensive.
#[derive(Clone, Debug)]
pub struct MeshVertexBufferLayoutRef(pub Arc<MeshVertexBufferLayout>);

/// Stores the single copy of each mesh vertex buffer layout.
#[derive(Clone, Default, Resource)]
pub struct MeshVertexBufferLayouts(HashSet<Arc<MeshVertexBufferLayout>>);

impl MeshVertexBufferLayouts {
    /// Inserts a new mesh vertex buffer layout in the store and returns a
    /// reference to it, reusing the existing reference if this mesh vertex
    /// buffer layout was already in the store.
    pub fn insert(&mut self, layout: MeshVertexBufferLayout) -> MeshVertexBufferLayoutRef {
        // Because the special `PartialEq` and `Hash` implementations that
        // compare by pointer are on `MeshVertexBufferLayoutRef`, not on
        // `Arc<MeshVertexBufferLayout>`, this compares the mesh vertex buffer
        // structurally, not by pointer.
        MeshVertexBufferLayoutRef(
            self.0
                .get_or_insert_with(&layout, |layout| Arc::new(layout.clone()))
                .clone(),
        )
    }
}

impl PartialEq for MeshVertexBufferLayoutRef {
    fn eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.0, &other.0)
    }
}

impl Eq for MeshVertexBufferLayoutRef {}

impl Hash for MeshVertexBufferLayoutRef {
    fn hash<H: Hasher>(&self, state: &mut H) {
        // Hash the address of the underlying data, so two layouts that share the same
        // `MeshVertexBufferLayout` will have the same hash.
        (Arc::as_ptr(&self.0) as usize).hash(state);
    }
}
