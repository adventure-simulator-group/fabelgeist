from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,io,tomllib
b=Path(__file__).resolve().parent;sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();reg=json.load(gzip.open(b/'original-registry.json.gz','rt'));assigned=json.loads((b/'registration.json').read_bytes())['entries'];receipt=json.loads((b/'personal-read-receipt.json').read_bytes());proof=json.loads((b/'git-proofs.json').read_bytes());report=json.loads((b/'REPORT.json').read_bytes());man=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in man['entries']}
for e in assigned:
 raw=(b/e['source_archive']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and len(raw.splitlines())==e['actual_eof'] and oid('blob',raw)==e['git_blob']
 if e['source_identity']=='physical-p16 dirty snapshot':
  row=reg['files'][e['original_role']];assert e['sha256']==row['sha256'] and e['bytes']==row['bytes'] and e['original_material_ranges']==row['material_ranges']
for role in (2515,2516):
 rows=[e for e in assigned if e['original_role']==role];assert len(rows)==2 and rows[0]['sha256']==rows[1]['sha256'] and rows[0]['git_blob']==rows[1]['git_blob']
s=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert s['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(s['status_porcelain'])==159
old=json.loads((b/'original-attribution.json').read_bytes());assert not old['missing_originals']
for e in old['original_059_records']:
 raw=(b/e['preserved_bytes']).read_bytes();orig=idx[e['original_path']];assert sha(raw)==e['sha256']==orig['sha256'] and len(raw)==orig['bytes'] and oid('blob',raw)==orig['git_blob']==e['git_blob']
for e in old['older_774_receipts']:
 raw=(b/e['preserved_bytes']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and oid('blob',raw)==e['git_blob']
lock=tomllib.loads((b/'historical-059/parallel-l12-20261029/source-854-native-tangents-20261030/1191ee1e830f870d16ebaa30e6d84953656acaed04cf9c2a0367bbbcb1f78201').read_text())
for e in old['native_historical_packages']:
 raw=(b/e['archive']).read_bytes();assert sha(raw)==e['historical_lock_checksum_sha256'] and len(raw)==e['package_bytes'];assert next(x for x in lock['package'] if x['name']==e['name'] and x['version']==e['version'])['checksum']==sha(raw)
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  for p in e['matched_historical_extracted_members']:
   original=b/'historical-059/parallel-l12-20261029/source-854-native-tangents-20261030'/p;assert t.extractfile(p).read()==original.read_bytes()
for e in old['prior_packets']:
 raw=(b/e['frozen_archive']).read_bytes();assert sha(raw)==e['archive_sha256']
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  base=e['name']+'/';mraw=t.extractfile(base+'MANIFEST.json').read();assert sha(mraw)==e['manifest_sha256'];manifest=json.loads(mraw);assert len(manifest['files'])==e['manifest_entries_verified']
  for x in manifest['files']:
   data=t.extractfile(base+x['path']).read();assert sha(data)==x['sha256'] and len(data)==x['bytes']
  assert sha(t.extractfile(base+'REPORT.json').read())==e['report_sha256']
for e in old['prior_publication_assessments']:
 raw=(b/e['preserved_bytes']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes']
 for a in e['archived_sources']:
  raw=(b/'prior-publication'/a['source_path']).read_bytes();assert sha(raw)==a['sha256'];decoded=gzip.decompress(raw) if a['source_path'].endswith('.gz') else raw;assert sha(decoded)==a['uncompressed_sha256']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
objects={}
for key,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,e in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==e['root_tree']
for p in proof['paths']:
 curr=proof['commits'][p['revision']]['root_tree'];parts=p['path'].split('/');assert len(parts)==len(p['path_chain'])
 for name,step in zip(parts,p['path_chain']):
  assert step['tree']==curr and step['name']==name;mode,child=entries(objects[curr])[name];assert mode==step['mode'] and child==step['object'];curr=child
 raw=(b/p['preserved_bytes']).read_bytes();assert oid('blob',raw)==curr==p['git_blob'] and sha(raw)==p['sha256'] and len(raw)==p['bytes']
assert len(receipt['assigned_personal_reads'])==4 and len(receipt['support_personal_reads'])==17 and len(report['lenses'])==13
for e in receipt['assigned_personal_reads']+receipt['support_personal_reads']:
 seen=set();absent=set()
 for a,z in e['contiguously_displayed_ranges']:
  assert 1<=a<=z<=e['actual_eof'];seen.update(range(a,z+1))
 for a,z in e['not_contiguously_displayed_ranges']:
  assert 1<=a<=z<=e['actual_eof'];absent.update(range(a,z+1))
 assert seen.isdisjoint(absent) and len(seen)+len(absent)==e['actual_eof']
for e in receipt['assigned_personal_reads']:assert e['contiguously_displayed_ranges']==([[1,115]] if e['role']==2515 else [[1,87]])
scopes={}
for e in receipt['support_personal_reads']:
 scopes.setdefault(e['path'],set()).update(i for a,z in e['contiguously_displayed_ranges'] for i in range(a,z+1))
for e in receipt['assigned_personal_reads']:
 if e['source_identity']=='95e63628f9d70b8dd6e6fede64334696c6995009':scopes.setdefault(e['path'],set()).update(range(1,e['actual_eof']+1))
def visit(x):
 if isinstance(x,dict):
  if x.get('revision')=='95e63628f9d70b8dd6e6fede64334696c6995009' and 'ranges' in x:
   assert x['path'] in scopes
   for a,z in x['ranges']:assert set(range(a,z+1))<=scopes[x['path']],(x['path'],a,z)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Assigned P16 registry hashes, EOF and recovered object bytes match; individual current objects identical','Raw commit/tree chains bind f82 archive, 95e, a120 base and 6533 individual files, not the unrecovered dirty patch','059 records match original extracted transport manifest; 774 records match transport blobs; historical native .crate checksums match dirty P16 lock and retained member bytes','Full prior finish/LOD packet manifest, current historical assessments/source archives, four personal assigned bodies, 17 bounded support displays, citations and thirteen perspectives checked'],'scope':'Evidence/hash/Git chain/citation verification only; no product, native execution, test, build or runtime validation.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw);print('PASS',sha(raw),'proofs',len(proof['paths']),'059',len(old['original_059_records']),'native archives',len(old['native_historical_packages']))
