use serde_core::ser::{
    Serialize, SerializeMap, SerializeSeq, SerializeStruct, SerializeStructVariant, SerializeTuple,
    SerializeTupleStruct, SerializeTupleVariant,
};
use std::fmt::Write;

use super::helpers::{BoolCapture, StrCapture, UsizeCapture, scalar_key_to_string};
use super::{AnchorId, YamlSerializer};
use crate::ser::options::CommentPosition;
use crate::ser::{Error, Result};

/// From the spec:
///
/// > If the "?" indicator is omitted, parsing needs to see past the implicit key to recognize it as such.
/// > To limit the amount of lookahead required, the ":" indicator must appear at most 1024 Unicode characters beyond the start of the key.
/// > In addition, the key is restricted to a single line.
const SIMPLE_KEY_MAX_LEN: usize = 1024;

#[inline]
fn is_simple_key_text(text: &str) -> bool {
    // UTF-8 bytes are an upper bound on Unicode scalar count.
    text.len() <= SIMPLE_KEY_MAX_LEN || text.chars().count() <= SIMPLE_KEY_MAX_LEN
}

// ------------------------------------------------------------
// Seq / Tuple serializers
// ------------------------------------------------------------

/// Serializer for sequences and tuples.
///
/// Created by `YamlSerializer::serialize_seq`/`serialize_tuple`. Holds a mutable
/// reference to the parent serializer and formatting state for the sequence.
#[doc(hidden)]
pub struct SeqSer<'a, 'b, W: Write> {
    /// Parent YAML serializer.
    pub(super) ser: &'a mut YamlSerializer<'b, W>,
    /// Target indentation depth for block-style items.
    pub(super) depth: usize,
    /// Whether the sequence is being written in flow style (`[a, b]`).
    pub(super) flow: bool,
    /// Whether the next element is the first (comma handling in flow style).
    pub(super) first: bool,
    /// A block node property was already emitted, so an empty sequence must
    /// still emit `[]` even when the general empty-braces option is disabled.
    pub(super) force_empty_marker: bool,
}

impl<W: Write> SerializeTuple for SeqSer<'_, '_, W> {
    type Ok = ();
    type Error = Error;

    fn serialize_element<T: ?Sized + Serialize>(&mut self, v: &T) -> Result<()> {
        SerializeSeq::serialize_element(self, v)
    }
    fn end(self) -> Result<()> {
        SerializeSeq::end(self)
    }
}

// Re-implement SerializeSeq for SeqSer with correct end.
impl<W: Write> SerializeSeq for SeqSer<'_, '_, W> {
    type Ok = ();
    type Error = Error;

    fn serialize_element<T: ?Sized + Serialize>(&mut self, v: &T) -> Result<()> {
        if self.flow {
            if !self.first {
                self.ser.out.write_str(", ")?;
            }
            self.ser.with_in_flow(|s| v.serialize(s))?;
        } else {
            // If we are the value of a mapping key, we deferred the newline until we knew the
            // sequence is non-empty. Insert it now before emitting the first dash.
            if self.first && self.ser.state.pending_layout.pending_space_after_colon {
                self.ser.state.pending_layout.pending_space_after_colon = false;
                if !self.ser.state.at_line_start {
                    self.ser.newline()?;
                }
                self.ser.state.pending_layout.pending_inline_map = false;
            }
            // If previous element was an inline map after a dash, just clear the flag; do not change depth.
            if !self.first && self.ser.state.pending_layout.inline_map_after_dash {
                self.ser.state.pending_layout.inline_map_after_dash = false;
            }
            if self.first
                && (!self.ser.state.at_line_start
                    || self.ser.state.pending_layout.pending_inline_map)
            {
                // Inline the first element of this nested sequence right after the outer dash
                // (either we are already mid-line, or the parent staged inline via pending_inline_map).
                // Do not write indentation here.
            } else {
                self.ser.write_indent(self.depth)?;
            }
            self.ser.out.write_str("- ")?;
            self.ser.state.at_line_start = false;
            if self.first && self.ser.state.pending_layout.inline_map_after_dash {
                // We consumed the inline-after-dash behavior for this child sequence.
                self.ser.state.pending_layout.inline_map_after_dash = false;
            }
            // Capture the dash's indentation depth for potential struct-variant that follows.
            self.ser.state.after_dash_depth = Some(self.depth);
            // Hint to emit first key/element of a following mapping/sequence inline on the same line.
            self.ser.state.pending_layout.pending_inline_map = true;
            // A sibling element's block-collection state must not leak into this element.
            self.ser.state.last_value_was_block = false;
            v.serialize(&mut *self.ser)?;
        }
        self.first = false;
        Ok(())
    }

    fn end(self) -> Result<()> {
        if self.flow {
            self.ser.out.write_str("]")?;
            if self.ser.state.in_flow == 0 {
                self.ser.newline()?;
            }
        } else if self.first {
            // Empty block-style sequence.
            if self.ser.settings.empty_as_braces || self.force_empty_marker {
                // If we were pending a space after a colon (map value position), write it now.
                if self.ser.state.pending_layout.pending_space_after_colon {
                    self.ser.out.write_str(" ")?;
                    self.ser.state.pending_layout.pending_space_after_colon = false;
                } else if self.ser.state.at_line_start {
                    // If at line start, indent appropriately.
                    self.ser.write_indent(self.depth)?;
                }
                self.ser.out.write_str("[]")?;
                self.ser.newline()?;
            } else {
                // Preserve legacy behavior: just emit a newline (empty body).
                // Clear map-value pending state so it does not leak into following elements.
                self.ser.state.pending_layout.pending_space_after_colon = false;
                self.ser.newline()?;
            }
        } else {
            // Block collection finished and it was not empty.
            self.ser.state.last_value_was_block = true;
            // Clear any dash/inline hints so they cannot affect the next sibling value
            // (e.g., a mapping field following a block sequence value).
            self.ser.state.pending_layout.pending_inline_map = false;
            self.ser.state.after_dash_depth = None;
            self.ser.state.pending_layout.inline_map_after_dash = false;
        }
        Ok(())
    }
}

/// Serializer for tuple-structs.
///
/// Used for three shapes:
/// - Normal tuple-structs (treated like sequences in block style),
/// - Anchors:
///   - Internal strong-anchor payloads (`__yaml_anchor`),
///   - Internal weak-anchor payloads (`__yaml_weak_anchor`).
#[doc(hidden)]
pub struct TupleSer<'a, 'b, W: Write> {
    inner: TupleSerInner<'a, 'b, W>,
}

enum TupleSerInner<'a, 'b, W: Write> {
    Seq(SeqSer<'a, 'b, W>),
    Special(SpecialTupleSer<'a, 'b, W>),
}

/// State machine for the internal anchor/comment tuple wrappers.
struct SpecialTupleSer<'a, 'b, W: Write> {
    /// Parent YAML serializer.
    ser: &'a mut YamlSerializer<'b, W>,
    /// Variant describing how to interpret fields.
    kind: TupleKind,
    /// Current field index being serialized.
    idx: usize,
    /// Captured pointer identity for a weak-anchor payload while waiting for
    /// its `present` field.
    weak_anchor_ptr: usize,

    // ---- Extra fields for refactoring/perf/correctness ----
    /// For strong anchors: if Some(id) then we must emit an alias instead of a definition at field #2.
    strong_alias_id: Option<AnchorId>,
    /// For weak anchors: whether the `present` flag was true.
    weak_present: bool,
    /// Skip serializing the 3rd field (value) in weak case if present==false.
    skip_third: bool,
    /// For weak anchors: hold alias id if value should be emitted as alias in field #3.
    weak_alias_id: Option<AnchorId>,
    /// For commented wrapper: captured comment text from field #0.
    comment_text: Option<String>,
    /// For tagged wrapper: resolved tag identity captured from field #0.
    resolved_tag: Option<String>,
}
enum TupleKind {
    AnchorStrong, // [ptr, value]
    AnchorWeak,   // [ptr, present, value]
    Commented,    // [comment, value]
    Tagged,       // [resolved tag, value]
}
impl<'a, 'b, W: Write> TupleSer<'a, 'b, W> {
    pub(super) fn sequence(seq: SeqSer<'a, 'b, W>) -> Self {
        Self {
            inner: TupleSerInner::Seq(seq),
        }
    }

    /// Create a tuple serializer for internal strong-anchor payloads.
    pub(super) fn anchor_strong(ser: &'a mut YamlSerializer<'b, W>) -> Self {
        Self {
            inner: TupleSerInner::Special(SpecialTupleSer::new(ser, TupleKind::AnchorStrong)),
        }
    }
    /// Create a tuple serializer for internal weak-anchor payloads.
    pub(super) fn anchor_weak(ser: &'a mut YamlSerializer<'b, W>) -> Self {
        Self {
            inner: TupleSerInner::Special(SpecialTupleSer::new(ser, TupleKind::AnchorWeak)),
        }
    }
    /// Create a tuple serializer for internal commented wrapper.
    pub(super) fn commented(ser: &'a mut YamlSerializer<'b, W>) -> Self {
        Self {
            inner: TupleSerInner::Special(SpecialTupleSer::new(ser, TupleKind::Commented)),
        }
    }
    /// Create a tuple serializer for the internal tagged wrapper.
    pub(super) fn tagged(ser: &'a mut YamlSerializer<'b, W>) -> Self {
        Self {
            inner: TupleSerInner::Special(SpecialTupleSer::new(ser, TupleKind::Tagged)),
        }
    }
}

impl<'a, 'b, W: Write> SpecialTupleSer<'a, 'b, W> {
    fn new(ser: &'a mut YamlSerializer<'b, W>, kind: TupleKind) -> Self {
        Self {
            ser,
            kind,
            idx: 0,
            weak_anchor_ptr: 0,
            strong_alias_id: None,
            weak_present: false,
            skip_third: false,
            weak_alias_id: None,
            comment_text: None,
            resolved_tag: None,
        }
    }
}

impl<W: Write> SerializeTupleStruct for TupleSer<'_, '_, W> {
    type Ok = ();
    type Error = Error;

    fn serialize_field<T: ?Sized + Serialize>(&mut self, value: &T) -> Result<()> {
        match &mut self.inner {
            TupleSerInner::Seq(seq) => SerializeSeq::serialize_element(seq, value),
            TupleSerInner::Special(s) => s.serialize_field(value),
        }
    }

    fn end(self) -> Result<()> {
        match self.inner {
            TupleSerInner::Seq(seq) => SerializeSeq::end(seq),
            TupleSerInner::Special(_) => Ok(()),
        }
    }
}

impl<W: Write> SpecialTupleSer<'_, '_, W> {
    fn serialize_field<T: ?Sized + Serialize>(&mut self, value: &T) -> Result<()> {
        match self.kind {
            TupleKind::AnchorStrong => {
                match self.idx {
                    0 => {
                        // capture ptr, decide define vs alias
                        let mut cap = UsizeCapture::default();
                        value.serialize(&mut cap)?;
                        let ptr = cap.finish()?;
                        let (id, fresh) = self.ser.alloc_anchor_for(ptr)?;
                        if fresh {
                            self.ser.anchors.pending_id = Some(id); // define before value
                            self.strong_alias_id = None;
                        } else {
                            self.strong_alias_id = Some(id); // alias instead of value
                        }
                    }
                    1 => {
                        if let Some(id) = self.strong_alias_id.take() {
                            // Already defined earlier -> emit alias
                            self.ser.write_alias_id(id)?;
                        } else {
                            // First sight -> serialize value; pending_anchor_id (if any) will be emitted
                            value.serialize(&mut *self.ser)?;
                        }
                    }
                    _ => return Err(Error::unexpected("unexpected field in __yaml_anchor")),
                }
            }
            TupleKind::AnchorWeak => {
                match self.idx {
                    0 => {
                        let mut cap = UsizeCapture::default();
                        value.serialize(&mut cap)?;
                        let ptr = cap.finish()?;
                        self.weak_anchor_ptr = ptr;
                    }
                    1 => {
                        let mut bc = BoolCapture::default();
                        value.serialize(&mut bc)?;
                        self.weak_present = bc.finish()?;
                        if self.weak_present {
                            let ptr = self.weak_anchor_ptr;
                            let (id, fresh) = self.ser.alloc_anchor_for(ptr)?;
                            if fresh {
                                self.ser.anchors.pending_id = Some(id); // define before value
                                self.weak_alias_id = None;
                            } else {
                                self.weak_alias_id = Some(id); // alias in field #3
                            }
                        } else {
                            // present == false: emit null and skip field #3
                            self.ser.write_space_if_pending()?;
                            self.ser.write_scalar_prefix_if_anchor()?;
                            if self.ser.state.at_line_start {
                                self.ser.write_indent(self.ser.state.depth)?;
                            }
                            self.ser.out.write_str("null")?;
                            // Use shared end-of-scalar so pending inline comments (if any) are appended
                            self.ser.write_end_of_scalar()?;
                            self.skip_third = true;
                        }
                    }
                    2 => {
                        if self.skip_third {
                            // nothing to do
                        } else if let Some(id) = self.weak_alias_id.take() {
                            self.ser.write_alias_id(id)?;
                        } else {
                            // definition path: pending_anchor_id (if any) will be placed automatically
                            value.serialize(&mut *self.ser)?;
                        }
                    }
                    _ => return Err(Error::unexpected("unexpected field in __yaml_weak_anchor")),
                }
            }
            TupleKind::Commented => {
                match self.idx {
                    0 => {
                        // Capture comment string
                        let mut sc = StrCapture::default();
                        value.serialize(&mut sc)?;
                        self.comment_text = Some(sc.finish()?);
                    }
                    1 => {
                        let comment = self.comment_text.take().unwrap_or_default();
                        let sanitized = YamlSerializer::<W>::sanitize_comment_text(&comment);
                        match self.ser.settings.comment_position {
                            CommentPosition::Inline => {
                                if self.ser.state.in_flow == 0 && !sanitized.is_empty() {
                                    // Stage the comment so scalar/alias serializers append it inline via write_end_of_scalar.
                                    self.ser.state.pending_inline_comment = Some(sanitized);
                                }
                                // Serialize the inner value as-is. Complex values will ignore the comment (it will be cleared).
                                value.serialize(&mut *self.ser)?;
                                // Ensure no leftover staged comment leaks to subsequent tokens.
                                self.ser.state.pending_inline_comment = None;
                            }
                            CommentPosition::Above => {
                                let saved_depth = self.ser.state.depth;
                                let target_depth = self.ser.write_above_comment(&sanitized)?;
                                if let Some(depth) = target_depth {
                                    self.ser.state.depth = depth;
                                }
                                let result = value.serialize(&mut *self.ser);
                                self.ser.state.depth = saved_depth;
                                result?;
                                self.ser.state.pending_inline_comment = None;
                            }
                        }
                    }
                    _ => return Err(Error::unexpected("unexpected field in __yaml_commented")),
                }
            }
            TupleKind::Tagged => match self.idx {
                0 => {
                    let mut sc = StrCapture::default();
                    value.serialize(&mut sc)?;
                    self.resolved_tag = Some(sc.finish()?);
                }
                1 => {
                    let tag = self.resolved_tag.take().unwrap_or_default();
                    self.ser.serialize_tagged_value(&tag, value)?;
                }
                _ => return Err(Error::unexpected("unexpected field in __yaml_tagged")),
            },
        }
        self.idx += 1;
        Ok(())
    }
}

// Tuple variant (enum Variant: ( ... )).
// `serialize_tuple_variant` writes the variant name and colon, then hands the
// fields to a `SeqSer`: the body is just a block sequence, so it reuses the same
// dash/indentation logic as `serialize_seq`.
impl<W: Write> SerializeTupleVariant for SeqSer<'_, '_, W> {
    type Ok = ();
    type Error = Error;

    fn serialize_field<T: ?Sized + Serialize>(&mut self, value: &T) -> Result<()> {
        SerializeSeq::serialize_element(self, value)
    }
    fn end(self) -> Result<()> {
        SerializeSeq::end(self)
    }
}

// ------------------------------------------------------------
// Map / Struct serializers
// ------------------------------------------------------------

/// Serializer for maps and structs.
///
/// Created by `YamlSerializer::serialize_map`/`serialize_struct`. Manages indentation
/// and flow/block style for key-value pairs.
#[doc(hidden)]
pub struct MapSer<'a, 'b, W: Write> {
    /// Parent YAML serializer.
    ser: &'a mut YamlSerializer<'b, W>,
    /// Target indentation depth for block-style entries.
    depth: usize,
    /// Flow/block layout and block-only alignment state.
    layout: MapLayout,
    /// Number of values successfully emitted.
    entries_written: usize,
    /// Kind of key waiting for its corresponding value.
    pending_key: Option<MapKeyKind>,
    /// A block node property was already emitted, so an empty mapping must
    /// still emit `{}` even when the general empty-braces option is disabled.
    force_empty_marker: bool,
}

/// Output layout selected when a mapping is created.
///
/// The two block-only flags live inside the `Block` variant so flow mappings
/// cannot accidentally carry indentation state that has no meaning for them.
enum MapLayout {
    /// Emit the mapping as `{key: value}`.
    Flow,
    /// Emit one mapping entry per block line.
    Block {
        /// Align continuation lines below a mapping opened immediately after `- `.
        align_after_dash: bool,
        /// Delay the first newline while an unknown-length map may still be empty.
        inline_value_start: bool,
    },
}

impl MapLayout {
    fn is_flow(&self) -> bool {
        matches!(self, Self::Flow)
    }

    fn align_after_dash(&self) -> bool {
        matches!(
            self,
            Self::Block {
                align_after_dash: true,
                ..
            }
        )
    }

    /// Consume the deferred inline start when the first actual key proves the map is non-empty.
    fn take_inline_value_start(&mut self) -> bool {
        match self {
            Self::Block {
                inline_value_start, ..
            } => std::mem::take(inline_value_start),
            Self::Flow => false,
        }
    }
}

/// Shape of the serialized key whose value is expected next.
///
/// Complex block keys need a separate `:` line before their value; scalar keys
/// already wrote their colon while serializing the key.
#[derive(Clone, Copy, PartialEq, Eq)]
enum MapKeyKind {
    Simple,
    Complex,
}

impl<'a, 'b, W: Write> MapSer<'a, 'b, W> {
    pub(super) fn flow(ser: &'a mut YamlSerializer<'b, W>, depth: usize) -> Self {
        Self {
            ser,
            depth,
            layout: MapLayout::Flow,
            entries_written: 0,
            pending_key: None,
            force_empty_marker: false,
        }
    }

    pub(super) fn block(
        ser: &'a mut YamlSerializer<'b, W>,
        depth: usize,
        align_after_dash: bool,
        inline_value_start: bool,
        force_empty_marker: bool,
    ) -> Self {
        Self {
            ser,
            depth,
            layout: MapLayout::Block {
                align_after_dash,
                inline_value_start,
            },
            entries_written: 0,
            pending_key: None,
            force_empty_marker,
        }
    }

    /// Emit a scalar key inline as `key:`.
    fn write_simple_key(&mut self, text: &str) -> Result<()> {
        // Indent continuation lines. If this map started inline after a dash,
        // align under the first key by adding two spaces instead of a full indent step.
        if self.layout.align_after_dash() && self.ser.state.at_line_start {
            let base = self.depth.saturating_sub(1);
            self.ser.write_indent_spaces(base)?;
            self.ser.out.write_str("  ")?; // width of "- "
            self.ser.state.at_line_start = false;
        } else {
            self.ser.write_indent(self.depth)?;
        }
        self.ser.out.write_str(text)?;
        self.ser.out.write_str(":")?;
        self.ser.state.pending_layout.pending_space_after_colon = true;
        self.ser.state.at_line_start = false;
        self.pending_key = Some(MapKeyKind::Simple);
        Ok(())
    }

    /// Emit an over-long scalar key in explicit `? key` form using its precomputed key-safe
    /// `text`. Re-serializing via the value serializer would use value-position quoting and
    /// could drop trailing whitespace, which YAML treats as separation in plain style.
    fn write_explicit_scalar_key(&mut self, text: &str) -> Result<()> {
        self.ser.write_indent(self.depth)?;
        self.ser.out.write_str("? ")?;
        self.ser.out.write_str(text)?;
        self.ser.newline()?;
        self.pending_key = Some(MapKeyKind::Complex);
        Ok(())
    }

    /// Emit a key using the explicit `? key` form; the value follows on a `: value` line.
    fn write_explicit_key<T: ?Sized + Serialize>(&mut self, key: &T) -> Result<()> {
        self.ser.write_anchor_for_complex_node()?;
        self.ser.write_indent(self.depth)?;
        self.ser.out.write_str("? ")?;
        self.ser.state.at_line_start = false;

        let saved_depth = self.ser.state.depth;
        let saved_current_map_depth = self.ser.state.current_map_depth;
        let saved_pending_inline_map = self.ser.state.pending_layout.pending_inline_map;
        let saved_inline_map_after_dash = self.ser.state.pending_layout.inline_map_after_dash;
        let saved_after_dash_depth = self.ser.state.after_dash_depth;

        self.ser.state.pending_layout.pending_inline_map = true;
        self.ser.state.depth = self.depth;
        // Provide a base depth for nested maps within this complex key so that
        // continuation lines indent one level deeper than the parent mapping.
        self.ser.state.current_map_depth = Some(self.depth);
        self.ser.state.after_dash_depth = None;
        key.serialize(&mut *self.ser)?;

        self.ser.state.depth = saved_depth;
        self.ser.state.current_map_depth = saved_current_map_depth;
        self.ser.state.pending_layout.pending_inline_map = saved_pending_inline_map;
        self.ser.state.pending_layout.inline_map_after_dash = saved_inline_map_after_dash;
        self.ser.state.after_dash_depth = saved_after_dash_depth;
        // A complex key may have been serialized as a block collection, which sets
        // `last_value_was_block`. That state must NOT affect the *value* of this same
        // map entry (e.g. we still want `: x: 3` inline for composite-key maps).
        self.ser.state.last_value_was_block = false;
        self.pending_key = Some(MapKeyKind::Complex);
        Ok(())
    }
}

impl<W: Write> SerializeMap for MapSer<'_, '_, W> {
    type Ok = ();
    type Error = Error;

    fn serialize_key<T: ?Sized + Serialize>(&mut self, key: &T) -> Result<()> {
        if self.layout.is_flow() {
            if self.entries_written > 0 {
                self.ser.out.write_str(", ")?;
            }
            let text = scalar_key_to_string(key, self.ser.settings.yaml_12)?;
            if is_simple_key_text(&text) {
                self.ser.out.write_str(&text)?;
                self.ser.out.write_str(": ")?;
            } else {
                self.ser.out.write_str("? ")?;
                self.ser.out.write_str(&text)?;
                self.ser.out.write_str(" : ")?;
            }
            self.ser.state.at_line_start = false;
            self.pending_key = Some(MapKeyKind::Simple);
        } else {
            // If this mapping started inline as a value (after "key:"), but now we
            // are about to emit the first entry, move to the next line before the key.
            if self.layout.take_inline_value_start() {
                // Cancel a pending space after ':' and break the line.
                if self.ser.state.pending_layout.pending_space_after_colon {
                    self.ser.state.pending_layout.pending_space_after_colon = false;
                }
                if !self.ser.state.at_line_start {
                    self.ser.newline()?;
                }
            } else if !self.ser.state.at_line_start {
                self.ser.write_space_if_pending()?;
            }

            // A new key in a block map should clear any pending inline hints from previous siblings.
            self.ser.state.after_dash_depth = None;
            self.ser.state.pending_layout.pending_inline_map = false;
            self.ser.state.last_value_was_block = false;

            match scalar_key_to_string(key, self.ser.settings.yaml_12) {
                Ok(text) if is_simple_key_text(&text) => {
                    self.write_simple_key(&text)?;
                }
                Ok(text) => self.write_explicit_scalar_key(&text)?,
                Err(Error::Unexpected { msg }) if msg == "non-scalar key" => {
                    self.write_explicit_key(key)?;
                }
                Err(e) => return Err(e),
            }
        }
        Ok(())
    }

    fn serialize_value<T: ?Sized + Serialize>(&mut self, value: &T) -> Result<()> {
        let key_kind = self.pending_key.take();
        if self.layout.is_flow() {
            self.ser.with_in_flow(|s| value.serialize(s))?;
        } else {
            let saved_pending_inline_map = self.ser.state.pending_layout.pending_inline_map;
            let saved_depth = self.ser.state.depth;
            if key_kind == Some(MapKeyKind::Complex) {
                if self.layout.align_after_dash() && self.ser.state.at_line_start {
                    let base = self.depth.saturating_sub(1);
                    self.ser.write_indent_spaces(base)?;
                    self.ser.out.write_str("  ")?;
                    self.ser.state.at_line_start = false;
                } else {
                    self.ser.write_indent(self.depth)?;
                }
                self.ser.out.write_str(":")?;
                self.ser.state.pending_layout.pending_space_after_colon = true;
                self.ser.state.pending_layout.pending_inline_map = true;
                self.ser.state.at_line_start = false;
                self.ser.state.depth = self.depth;
            }
            let prev_map_depth = self.ser.state.current_map_depth.replace(self.depth);
            let result = value.serialize(&mut *self.ser);
            self.ser.state.current_map_depth = prev_map_depth;
            // Always restore the parent's pending_inline_map to avoid leaking inline hints
            // across sibling values (e.g., after finishing a sequence value like `groups`).
            self.ser.state.pending_layout.pending_inline_map = saved_pending_inline_map;
            if key_kind == Some(MapKeyKind::Complex) {
                self.ser.state.depth = saved_depth;
            }
            result?;
        }
        self.entries_written = self.entries_written.saturating_add(1);
        Ok(())
    }

    fn end(self) -> Result<()> {
        if self.layout.is_flow() {
            self.ser.out.write_str("}")?;
            if self.ser.state.in_flow == 0 {
                self.ser.newline()?;
            }
        } else if self.entries_written == 0 {
            // Empty block-style map.
            if self.ser.settings.empty_as_braces || self.force_empty_marker {
                // If we were pending a space after a colon (map value position), write it now.
                if self.ser.state.pending_layout.pending_space_after_colon {
                    self.ser.out.write_str(" ")?;
                    self.ser.state.pending_layout.pending_space_after_colon = false;
                }
                // If at line start, indent appropriately.
                if self.ser.state.at_line_start {
                    // If we are aligning after a dash, mimic the indentation logic used for keys.
                    if self.layout.align_after_dash() {
                        let base = self.depth.saturating_sub(1);
                        self.ser.write_indent_spaces(base)?;
                        self.ser.out.write_str("  ")?; // width of "- "
                        self.ser.state.at_line_start = false;
                    } else {
                        self.ser.write_indent(self.depth)?;
                    }
                }
                self.ser.out.write_str("{}")?;
                self.ser.newline()?;
            } else {
                // Preserve legacy behavior: just emit a newline (empty body).
                self.ser.newline()?;
            }
        } else {
            // Block collection finished and it was not empty.
            self.ser.state.last_value_was_block = true;
        }
        Ok(())
    }
}
impl<W: Write> SerializeStruct for MapSer<'_, '_, W> {
    type Ok = ();
    type Error = Error;

    fn serialize_field<T: ?Sized + Serialize>(
        &mut self,
        key: &'static str,
        value: &T,
    ) -> Result<()> {
        SerializeMap::serialize_key(self, &key)?;
        SerializeMap::serialize_value(self, value)
    }
    fn end(self) -> Result<()> {
        SerializeMap::end(self)
    }
}

/// Serializer for struct variants (enum Variant: { ... }).
///
/// Created by `YamlSerializer::serialize_struct_variant` to emit the variant name
/// followed by a block mapping of fields.
///
/// This must remain public because it is exposed as the associated
/// `SerializeStructVariant` type of the public `YamlSerializer` implementation;
/// crate-only visibility would leak a private type through that interface (E0446).
#[doc(hidden)]
pub struct StructVariantSer<'a, 'b, W: Write> {
    inner: StructVariantSerInner<'a, 'b, W>,
}

enum StructVariantSerInner<'a, 'b, W: Write> {
    /// The usual externally tagged representation, whose variant key and
    /// newline have already been emitted.
    External {
        ser: &'a mut YamlSerializer<'b, W>,
        depth: usize,
        fields_written: bool,
    },
    /// A YAML tag already selected the variant, so the fields are the root
    /// mapping payload rather than the value of another `Variant:` mapping.
    Payload(MapSer<'a, 'b, W>),
}

impl<'a, 'b, W: Write> StructVariantSer<'a, 'b, W> {
    pub(super) fn external(ser: &'a mut YamlSerializer<'b, W>, depth: usize) -> Self {
        Self {
            inner: StructVariantSerInner::External {
                ser,
                depth,
                fields_written: false,
            },
        }
    }

    pub(super) fn payload(map: MapSer<'a, 'b, W>) -> Self {
        Self {
            inner: StructVariantSerInner::Payload(map),
        }
    }
}

impl<W: Write> SerializeStructVariant for StructVariantSer<'_, '_, W> {
    type Ok = ();
    type Error = Error;

    fn serialize_field<T: ?Sized + Serialize>(
        &mut self,
        key: &'static str,
        value: &T,
    ) -> Result<()> {
        match &mut self.inner {
            StructVariantSerInner::External {
                ser,
                depth,
                fields_written,
            } => {
                let text = scalar_key_to_string(&key, ser.settings.yaml_12)?;
                ser.write_indent(*depth)?;
                ser.out.write_str(&text)?;
                // Defer spacing/newline decision to the value serializer similarly to map entries.
                ser.out.write_str(":")?;
                ser.state.pending_layout.pending_space_after_colon = true;
                ser.state.at_line_start = false;
                // Ensure nested mappings/collections used as this field's value indent relative to this struct variant.
                let prev_map_depth = ser.state.current_map_depth.replace(*depth);
                let result = value.serialize(&mut **ser);
                ser.state.current_map_depth = prev_map_depth;
                if result.is_ok() {
                    *fields_written = true;
                }
                result
            }
            StructVariantSerInner::Payload(map) => {
                SerializeStruct::serialize_field(map, key, value)
            }
        }
    }

    fn end(self) -> Result<()> {
        match self.inner {
            StructVariantSerInner::External {
                ser,
                depth,
                fields_written,
            } => {
                if !fields_written {
                    ser.write_indent(depth)?;
                    ser.out.write_str("{}")?;
                    ser.newline()?;
                }
                Ok(())
            }
            StructVariantSerInner::Payload(map) => SerializeStruct::end(map),
        }
    }
}
