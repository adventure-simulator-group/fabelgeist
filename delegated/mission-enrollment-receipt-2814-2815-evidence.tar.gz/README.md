# Mission enrollment and receipt: bounded evidence

Roles 2814 and 2815 were separately registered and personally displayed from
historical pr-working archive objects and pinned revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Historical per-file bytes match
`6533e444fa37552927070cc8d8190907fd3b413e` and current; this is not a claim
that the 6533-based pr-working snapshot was clean. Archived 6533 copies were
compared mechanically and not separately displayed.

`REPORT.json` gives findings, history, questions and thirteen bounded
perspectives. `registration.json`, `support-registration*.json` and
`navigation-registration*.json` are prospective; `read-receipt.json` records
actual displays, match-line-only navigation and unread complements. Complete
archive and support bytes are retained for recovery, not read credit. Navigation
outputs are retained as matching lines; Git membership is proved for the
assigned and registered support source files, not every navigation-only file.

`historical-manifest.json` records exact recovered historical and prior records;
`historical-selections-reconstructed.json` is a newly reconstructed selection.
774 nominal registrations, qualifications, native aggregate analysis and Root
admission are preserved side by side. Adler's historical future reads and
Segovb's later qualified reuse remain separately attributed. No historical item
is promoted to checkpoint 3821 or treated as a fresh read by another reviewer.

`git-proofs.json` and `git-objects/` prove recorded per-path Git identities;
`recovered/MANIFEST.json` and its archive preserve original registry bytes. The
unrelated P16 tracked patch is a later matching-digest recovery with its own
custody and untracked-file qualifications, not evidence of a clean P16 tree.
`MANIFEST.json` covers every packet file except itself, including nested
manifests. Run `python3 verify-evidence.py` for offline evidence-integrity
verification only. The verifier does not run product code, fixtures, or tests.
