from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');nav={};navigation=[]
files=['navigation-mission.txt','navigation-receipt.txt','navigation-roster.txt','navigation-accumulator.txt','navigation-injury.txt','navigation-receipt-validation.txt','navigation-injury-owners.txt']
for name in files:
 lines=(b/name).read_text().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m,(name,line);path,num=m.group(1),int(m.group(2));nav.setdefault(path,set()).add(num)
 rn='navigation-registration-injury-owners.json' if name==files[-1] else 'navigation-registration-extra.json' if name in files[4:6] else 'navigation-registration.json'
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'registration':rn,'ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2814:[[1,65],[66,125]],2815:[[1,76]]};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];shown=nums(d);navonly=sorted(nav.get(row['path'],set())-shown) if j else []
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':navonly,'unread_after_assigned_and_navigation':comp(v['eof'],shown|set(navonly)),'qualification':'Old and current source objects personally displayed separately after prospective registration. 6533 copies were mechanically compared, not displayed. Navigation only is not body credit.'})
bodies={'mission-mod':[[27,99]],'mission-systems':[[45,85],[175,250]],'server-main':[[80,110],[150,180]],'roster':[[1,63]],'mission-core':[[1,25]],'strategic-receipt':[[1142,1185],[1186,1230]],'combat':[[175,225]],'consequence':[[170,222],[223,275]],'injury-path':[[1,60],[272,308]],'receipt-commit':[[1037,1087],[1230,1285]],'injury-owner':[[55,78],[465,535]]};support=[]
for name in ['support-registration.json','support-registration-extra.json','support-registration-injury-owner.json']:
 for x in load(name)['entries']:
  d=bodies[x['name']];shown=nums(d);prior=[];navonly=sorted(nav.get(x['path'],set())-shown)
  support.append({'name':x['name'],'registration':name,'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement_after_this_support_and_assigned':comp(x['eof'],shown|set(navonly)),'qualification':'Other support entries for the same path are kept separate; complement does not union them. Incidental test source was not executed.','ordered_role_credit':0})
names=['registration.json','navigation-registration.json','navigation-registration-extra.json','navigation-registration-injury-owners.json','support-registration.json','support-registration-extra.json','support-registration-injury-owner.json']
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Newly reconstructed contemporaneous personal display and navigation receipts after prospective registration. Separate old/current body displays and actual unread complements; not inherited review credit.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'additional_repeat_display':'95e tactical.rs 1142–1178 was also displayed via byte-identical support/receipt-commit.rs after registration; the same source/path/hash/range was already prospectively covered by support-registration.json strategic-receipt, so this adds no range or ordered-role credit.','limits':'Source/evidence only; no product, generated code, macro, test, fixture, build, runtime probe, repair or publication edit.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('read-receipt sha256',h((b/'read-receipt.json').read_bytes()))
