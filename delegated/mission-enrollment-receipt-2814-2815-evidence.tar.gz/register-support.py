from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[
('mission-mod','crates/adventuresim-tactical-server/src/mission/mod.rs',[[27,99]]),
('mission-systems','crates/adventuresim-tactical-server/src/mission/systems.rs',[[45,85],[175,250]]),
('server-main','crates/adventuresim-tactical-server/src/main.rs',[[80,110],[150,180]]),
('roster','crates/adventuresim-core/src/mission/roster.rs',[[1,63]]),
('mission-core','crates/adventuresim-core/src/mission.rs',[[1,25]]),
('strategic-receipt','crates/adventuresim-stdb-module/src/tactical.rs',[[1142,1230]]),
('combat','crates/adventuresim-tactical-server/src/combat.rs',[[175,225]]),
('consequence','crates/adventuresim-tactical-server/src/combat/consequence.rs',[[170,275]])
]
entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob and max(z for a,z in ranges)<=len(raw.splitlines()),(name,len(raw.splitlines()))
 entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':'support/'+name+'.rs'});pending.append((name,raw))
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Current connected source support only; no ordered-role credit and archived full bytes do not imply all lines read.','entries':entries}
(b/'support-registration.json').write_text(json.dumps(x,indent=2)+'\n')
for name,raw in pending:
 p=b/('support/'+name+'.rs');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(x,indent=2))
