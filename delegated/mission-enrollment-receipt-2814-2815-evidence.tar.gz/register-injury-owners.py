from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
path='crates/adventuresim-core/src/combat.rs';raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip()
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Current applied injury bound support; no original role credit.','entries':[{'name':'injury-owner','path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':[[55,78],[465,535]],'local':'support/injury-owner.rs'}]}
(b/'support-registration-injury-owner.json').write_text(json.dumps(x,indent=2)+'\n');(b/'support/injury-owner.rs').write_bytes(raw)
