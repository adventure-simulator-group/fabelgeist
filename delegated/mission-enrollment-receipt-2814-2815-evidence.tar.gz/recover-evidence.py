from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>'); orig=Path('<LOCAL_PATH_1>'); prev=Path('<LOCAL_PATH_2>'); workspace=Path('<LOCAL_PATH_3>'); h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/n,'recovered/'+n,'Archive/registry and 059 copies as labelled by original manifest; catalog reconstructed; later independently reproduced tracked patch is not original dirty-tree recovery.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-core/AGENTS.md','crates/adventuresim-tactical-server/src/combat/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Current governing source rules; explicit source-only prohibition prevails.')
for n in ['COVERAGE-L01-ROLES.json','ASSESSMENT-MISSION-ENROLLMENT-95E.json','ASSESSMENT-COMBAT-CONSEQUENCE-RECEIPTS-95E.json','ASSESSMENT-RECONNECT-CONTINUITY-95E.json','MISSION-ENROLLMENT-HISTORICAL-GIT-PROOFS.json','COMBAT-CONSEQUENCE-HISTORICAL-GIT-PROOFS.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Published prior historical/current assessment or later recovery: attribution and source scope retained; not a new personal read.')
names=['segovb/READ-L11-458.json','segovb/STATE-L11-458.json','segovb/VERIFY-L11-458.json','segovb/REGISTRATION-SEGOVB-1735.json','segovb/REGISTRATION-SEGOVB-1736.json','adler/READ-L11-322.json','adler/REGISTRATION-ADLER-912.json','adler/REGISTRATION-ADLER-913.json']
for n in names:copy(orig/n,'historical/059/'+n,'Exact original extracted 059 receipt/registration; no past reviewer or lens credit transfer.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for owner,folder,names in [('native','initial05-aggregate-states',['source-range-registration.jsonl','source-qualifications.jsonl','contract-groups-115.json','coverage.jsonl']),('root','admission03',['new-parallel-admission-171.json'])]:
 for n in names:
  gp=f'handoff/774/adler-original/audit/continuation/{owner}/{folder}/{n}';raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{owner}-{n}','git:'+rev+':'+gp,'Exact original 774 record via f82 evidence transport; f82 is not original reviewer workspace revision.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw);qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw);cv=json.loads((b/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=[2814,2815]
selection={'kind':'Newly reconstructed selected rows from exact historical and current coverage records; not original standalone record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in ids},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')],'queue_uncompressed_sha256':h(qraw),'queue_entries':{str(i):q['entries'][i] for i in [25,270,1710,1712,3128,3133,3134]},'prior_coverage_sha256':h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes()),'prior_coverage_roles':{str(i):next(x for x in cv['roles'] if x['original_index']==i) for i in ids},'qualification':'PR based on 6533 but recorded unrelated dirty files; P16 distinct. No historical evidence promoted to 3821; queue IDs 1710/1712 are preserved without assuming equality to prior overlay references.'}
(b/'historical-selections-reconstructed.json').write_text(json.dumps(selection,indent=2)+'\n');(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'Old authors and revision scopes preserved; f82 transports evidence only.'},indent=2)+'\n');print('records',len(records),'historical-manifest sha256',h((b/'historical-manifest.json').read_bytes()))
