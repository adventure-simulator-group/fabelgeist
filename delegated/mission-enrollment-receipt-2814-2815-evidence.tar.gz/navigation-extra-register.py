from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'Navigation match lines only; register actual body scopes before display.','queries':[{'name':'injury','path':'crates/adventuresim-tactical-server/src','pattern':'record_party_injury|cut_damage|blunt_damage'},{'name':'receipt-validation','path':'crates/adventuresim-stdb-module/src/tactical.rs','pattern':'validate_tactical_receipt_bounds|validate_tactical_receipt|apply_tactical_receipt'}]}
Path('navigation-registration-extra.json').write_text(json.dumps(x,indent=2)+'\n')
