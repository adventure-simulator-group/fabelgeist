from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[('injury-path','crates/adventuresim-tactical-server/src/combat/consequence.rs',[[1,60],[272,308]]),('receipt-commit','crates/adventuresim-stdb-module/src/tactical.rs',[[1037,1087],[1230,1285]])]
entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':'support/'+name+'.rs'});pending.append((name,raw))
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Additional bounded current injury aggregation and strategic receipt commit support; no ordered-role credit.','entries':entries}
(b/'support-registration-extra.json').write_text(json.dumps(x,indent=2)+'\n')
for name,raw in pending:(b/('support/'+name+'.rs')).write_bytes(raw)
