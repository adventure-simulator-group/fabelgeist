from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent;o=Path('<LOCAL_PATH_0>');h=lambda x:hashlib.sha256(x).hexdigest();manifest=json.loads((b/'historical-manifest.json').read_bytes()); seen={r['local'] for r in manifest['records']};expected={}
a=json.loads((b/'prior/ASSESSMENT-MISSION-ENROLLMENT-95E.json').read_bytes())
for x in a['recovered_historical_records']:expected[x['original_path']]=x['sha256']
q=json.loads((b/'historical-selections-reconstructed.json').read_bytes())['queue_entries']
for n in ['3128','3133','3134']:
 for x in q[n]['exact_source_identities_and_assessed_ranges']:
  for k in ['receipt','registration']:
   y=x.get(k)
   if isinstance(y,dict) and y.get('path') and y.get('sha256'):expected[y['path']]=y['sha256']
 y=q[n].get('proposal')
 if isinstance(y,dict) and y.get('path') and y.get('sha256'):expected[y['path']]=y['sha256']
added=[];missing=[]
for n,digest in sorted(expected.items()):
 src=(o/n).resolve();assert src.is_relative_to(o.resolve());local='historical/059/'+n
 if not src.is_file():missing.append({'path':n,'expected_sha256':digest});continue
 raw=src.read_bytes();assert h(raw)==digest,(n,h(raw),digest)
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True)
 if local in seen:assert p.read_bytes()==raw;continue
 p.write_bytes(raw);record={'origin':str(src),'local':local,'sha256':digest,'bytes':len(raw),'kind':'Exact original 059 linked historical source receipt/registration/proposal; read claims remain attributed and do not become new source displays.'};manifest['records'].append(record);seen.add(local);added.append(local)
manifest['related_059_missing_originals']=missing;(b/'historical-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('related additions',len(added),'missing',len(missing),'manifest sha256',h((b/'historical-manifest.json').read_bytes()))
