from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'Current navigation match lines only; additional support source bodies separately registered before display.','queries':[
 {'name':'mission','path':'crates/adventuresim-tactical-server/src','pattern':'PartyEnrollment|reconnect_grace|tactical_consequence_receipt|observe_loaded|ready_for_outcome|allows_join'},
 {'name':'receipt','path':'crates/adventuresim-stdb-module/src','pattern':'TacticalConsequenceReceipt|MAX_TACTICAL_RECEIPT_PARTICIPANTS|equipment_contacts'},
 {'name':'roster','path':'crates','pattern':'TacticalPartyRoster|MAX_TACTICAL_RECEIPT_PARTICIPANTS'},
 {'name':'accumulator','path':'crates/adventuresim-tactical-server/src','pattern':'TacticalConsequenceAccumulator|equipment_contacts'}
]}
Path('navigation-registration.json').write_text(json.dumps(x,indent=2)+'\n')
