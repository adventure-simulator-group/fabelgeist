from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'Navigation match lines only, separately register body before inspection.','queries':[{'path':'crates','pattern':'fn apply_clamped_limb_damage|fn apportion_attack_health_damage|fn health_damage_from_attack'}]}
Path('navigation-registration-injury-owners.json').write_text(json.dumps(x,indent=2)+'\n')
