import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'registration.json').read_bytes());rows=[]
def comp(n,rs):
 unseen=set(range(1,n+1))-{i for a,b in rs for i in range(a,b+1)};out=[]
 for i in sorted(unseen):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for e in r['entries']:
 chunks=e['registered_ranges'];tag=e['tag']
 if tag in ('p16-2591','current-2591'):chunks=[[1,70],[71,131]]
 if tag=='p16-2592':chunks=[[1,55],[56,106]]
 if tag=='current-2592':chunks=[[1,55],[56,107]]
 if tag=='selection':chunks=[[1,85],[86,170]]
 rows.append({'tag':tag,'kind':e['kind'],'role':e.get('role'),'archive':e['archive'],'sha256':e['sha256'],'EOF':e['EOF'],'displayed_chunks':chunks,'unread_complement':comp(e['EOF'],chunks)})
(p/'read-receipt.json').write_text(json.dumps({'author':'/root/mhr_character','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration':'registration.json','registration_sha256':sha((p/'registration.json').read_bytes()),'entries':rows,'qualification':'Actually displayed numbered untruncated source chunks after prospective registration; P16/current, support and other readers are separate. No product data, fixtures or runtime executed.'},indent=2)+'\n')
(p/'staging-qualification.json').write_text(json.dumps({'author':'/root/mhr_character','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':'Initial attempt to stage and register sources requested recipe.rs 1–30, but the source ended at line 16. Registration script stopped before writing a registration and printed only the tag and EOF; no source body was displayed. The corrected prospective registration bounds each requested window at EOF, and all actual source displays followed its successful registration.','initial_output':"AssertionError: ('recipe', 16)",'scope_credit':'No prior registration or source read credit is claimed from failed staging.'},indent=2)+'\n')
