import datetime,difflib,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes())
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(v==reg['files'][int(k)] for k,v in sel['roles'].items());assert reg['files'][2740]['source_id'].startswith('pr-working:') and reg['files'][2740]['snapshot']=='pinned-native-dependency' and reg['files'][2740]['sha256']==reg['files'][2591]['sha256'];assert reg['files'][922]['source_id'].startswith('pr-working:')
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256']
patch=(p/'reference/tracked.patch').read_bytes();recovery=load('reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert sha(patch)==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(patch)==recovery['recovered_patch']['bytes'] and recovery['live_comparison']['status_counts']['??']==7
r=load('registration.json');t=load('read-receipt.json');assert t['registration_sha256']==sha((p/'registration.json').read_bytes()) and len(r['entries'])==len(t['entries'])==11 and datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert load('staging-qualification.json')['initial_output']=="AssertionError: ('recipe', 16)"
def nums(rs):return {i for lo,hi in rs for i in range(lo,hi+1)}
for e,v in zip(r['entries'],t['entries']):
 b=(p/e['archive']).read_bytes();assert e['tag']==v['tag'] and sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'];seen=nums(v['displayed_chunks']);unseen=nums(v['unread_complement']);assert nums(e['registered_ranges'])==seen and seen|unseen==set(range(1,e['EOF']+1)) and not seen&unseen
 if e['kind']=='historical-physical-p16':assert e['sha256']==reg['files'][e['role']]['sha256']
assert (p/'source/p16-2591.rs').read_bytes()==(p/'source/current-2591.rs').read_bytes() and (p/'source/p16-2592.rs').read_bytes()!=(p/'source/current-2592.rs').read_bytes();old=(p/'source/p16-2592.rs').read_text().splitlines(keepends=True);cur=(p/'source/current-2592.rs').read_text().splitlines(keepends=True);diff=''.join(difflib.unified_diff(old,cur,fromfile='physical-p16/equipment_assets.rs',tofile='95e/equipment_assets.rs'));assert diff==(p/'reconstructed-p16-current-2592.diff').read_text()
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());lraw=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());q=json.loads(qraw);l=json.loads(lraw);x=load('059-selection-reconstructed.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for path,v in x['journal_entries'].items():
 z=l
 for part in path.strip('/').split('/'):z=z[int(part)] if isinstance(z,list) else z[part]
 assert z==v
assert not q['entries'][1255]['exact_source_identities_and_assessed_ranges'] and not q['entries'][1255]['source_receipt_contexts'] and q['entries'][2482]['granular_contract_views']
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for lens,n in [('L11',425),('L12',880),('L12',881)]:
 read=(p/f'history-059/segovb/READ-{lens}-{n}.json').read_bytes();state=(p/f'history-059/segovb/STATE-{lens}-{n}.json').read_bytes();v=load(f'history-059/segovb/VERIFY-{lens}-{n}.json');assert v['receipt_sha256']==sha(read) and v['state_sha256']==sha(state)
read=load('history-059/segovb/READ-L11-425.json')
for e in read['sources']:
 if e['original_index'] not in (2591,2592):continue
 rel=e['registration'].split('target/726-audit-adler-20261027/',1)[1];assert e['registration_sha256']==sha((p/'history-059'/rel).read_bytes()) and e['sha256']==reg['files'][e['original_index']]['sha256']
for n in (880,881):
 read=load(f'history-059/segovb/READ-L12-{n}.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes())
 for e in read['rows']:
  if e['original_index'] not in (2591,2592):continue
  assert e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes()) and e['source_sha256']==reg['files'][e['original_index']]['sha256']
def verify_queue_refs(o):
 if isinstance(o,dict):
  if isinstance(o.get('path'),str) and o['path'] in idx and isinstance(o.get('sha256'),str):assert o['sha256']==sha((p/'history-059'/o['path']).read_bytes())
  if isinstance(o.get('verification'),str) and o['verification'] in idx and isinstance(o.get('verification_sha256'),str):assert o['verification_sha256']==sha((p/'history-059'/o['verification']).read_bytes())
  for value in o.values():verify_queue_refs(value)
 elif isinstance(o,list):
  for value in o:verify_queue_refs(value)
verify_queue_refs(q['entries'][2482])
prior=load('prior-index.json');m=(p/'prior/MANIFEST.json').read_bytes();assert sha(m)==prior['original_manifest_sha256']=='333133377e70b4aec2f95f8476e9bf65762c175b79881dece2ba20f50584d605';idxprior={e['path']:e for e in json.loads(m)['files']}
for e in prior['selected_files']:
 b=(p/'prior'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(idxprior[e['path']]['bytes'],idxprior[e['path']]['sha256'])
pub=load('reference/DELEGATED-EVIDENCE-CHECKPOINT-15.json');entry=next(z for z in pub['bundles'] if z['bundle_id']=='p16-weapon-assets-hair-ops');assert entry['archive_sha256']==prior['published_archive_sha256'];member=next(z for z in entry['members'] if z['path']=='REPORT.json');assert member['original_sha256']==sha((p/'prior/REPORT.json').read_bytes()) and member['published_sha256']==sha((p/'reference/published-prior-report.json').read_bytes())
pin=hist['rig_registration_pin_qualification'];rec=json.loads(gzip.decompress((p/'history-774/continuation/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));rreg=gzip.decompress((p/'history-774/continuation/rig/admission03/source-range-registration.jsonl.gz').read_bytes());rq=gzip.decompress((p/'history-774/continuation/rig/admission03/source-qualifications.jsonl.gz').read_bytes());assert rec['input_pins'][3]['sha256']==pin['root046_rig_registration_expected']!=sha(b''.join(rreg.splitlines(keepends=True)[:35]))==pin['later_first35_sha256'];assert rec['input_pins'][4]['sha256']==pin['root046_qualification_expected']==sha(b''.join(rq.splitlines(keepends=True)[:31]))==pin['later_first31_qualification_sha256']
quals={z['registration_id_resolved']:z['original_record'] for z in rec['role_qualifications'] if z.get('supplier')=='rig' and 'registration_id_resolved' in z}
for role,n in ((2591,24),(2592,26)):
 z=quals[f'RIG-ADMISSION03-REGISTER-{n:03}'];obs=next(o for o in reg['files'][role]['admission03_scope_observations'] if o['registration_id']==f'RIG-ADMISSION03-REGISTER-{n:03}');assert z.get('source_id',reg['files'][role]['source_id'])==reg['files'][role]['source_id'] and z.get('original_ranges',z.get('original_requested_ranges'))==obs['original_record']['material_ranges'] and z.get('actual_material_body_ranges',z.get('actual_ranges'))==obs['effective_material_ranges']
cam=hist['camera_registration_pin_qualification'];craw=gzip.decompress((p/'history-774/continuation/camera/admission03/source-range-registration.jsonl.gz').read_bytes());assert rec['input_pins'][2]['sha256']==cam['root046_camera_first7_pin']!=sha(b''.join(craw.splitlines(keepends=True)[:7]))==cam['later_f82_first7_sha256'] and sha(craw)==cam['later_f82_full_sha256'] and sha(b''.join(craw.splitlines(keepends=True)[:12]))==cam['later_f82_first12_sha256'];row=json.loads(craw.splitlines()[11]);assert row['id']=='CAMERA-ADM03-REG012-physical-p16' and datetime.datetime.fromisoformat(row['at'])>datetime.datetime.fromisoformat(rec['at'])
for z in load('prior/historical/774-camera-selection-reconstructed.json')['rows']:
 rel=z['source_git_path'].split('handoff/774/adler-original/audit/',1)[1];raw=gzip.decompress((p/'history-774'/(rel+'.gz')).read_bytes());line=raw.splitlines(keepends=True)[z['row_1based']-1];assert sha(raw)==z['source_sha256'] and len(raw)==z['source_bytes'] and line.decode()==z['raw_utf8'] and sha(line)==z['row_sha256']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
for x in proof['absences']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(x['existing_chain'])<len(parts)
 for name,link in zip(parts,x['existing_chain']):
  assert tree==link['tree'] and name==link['name'];typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 missing=x['first_missing_entry'];assert missing['tree']==tree and missing['name']==parts[len(x['existing_chain'])] and missing['name'] not in entries(objs[tree][1])
report=load('report.json');assert len(proof['proofs'])==25 and len(proof['absences'])==1 and len(report['lens_perspectives'])==13 and [z['index'] for z in report['historical_relations']['selected_059_queue']]==[1255,2482]
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_sources':len(r['entries']),'git_proofs':len(proof['proofs']),'clean_base_absence_proofs':len(proof['absences']),'git_objects':len(objs),'historical_records':len(hist['records']),'selected_queue_entries':2,'lens_perspectives':13,'qualification':'Evidence integrity only: bounded personal source displays, earlier 059/774 attribution, original and public redaction identities, reconstruction diff, rig/camera pin mismatch, dirty P16 tracked patch and seven exclusions, Git membership and base-only absence. No parser, product, build, test, fixture, macro or probe execution.'},indent=2))
