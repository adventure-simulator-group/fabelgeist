import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/strategic-web/src/routes/dialogue.rs','crates/strategic-web/src/routes/dialogue/claims.rs'];rows=[]
for index,path in zip([2361,2362],paths):
 versions=[]
 for rev in [old,cur]:
  q=subprocess.run(['git','show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if q.returncode:versions.append({'revision':rev,'present':False});continue
  b=q.stdout;versions.append({'revision':rev,'present':True,'lines':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 rows.append({'original_index':index,'path':path,'versions':versions})
o={'schema':'delegated-audit-prospective-source-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Prospective full assigned source bodies and actual personally displayed ranges for original roles 2361–2362 at pinned 95e and frozen 6533; no other lens or checkpoint transfer.','prior_personal_support':'Previously in web-data delegation this agent personally displayed dialogue.rs 770–815 and 850–905 under <LOCAL_PATH_1> that support read remains separately attributed and is not new ordered credit. Full fresh body display follows this registration.','qualification':'Current and historical bytes will be independently verified; same bytes do not establish unchanged connected producer/consumer semantics. Any unread assigned ranges will be explicitly reported.','constraint':'No product edits, repairs, builds, tests, browser use, runtime probes or simulations.','ordered_roles':rows}
(p/'registration.json').write_text(json.dumps(o,indent=2)+'\n');print('registered',o['registered_utc'],'sha256',hashlib.sha256((p/'registration.json').read_bytes()).hexdigest())
