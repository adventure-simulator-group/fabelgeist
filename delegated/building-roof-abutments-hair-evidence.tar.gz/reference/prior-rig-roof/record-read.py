from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009'
def missing(n,spans):
 covered={i for lo,hi in spans for i in range(lo,hi+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in covered:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
assigned=[]
for name in ['old-registration.json','current-registration.json']:
 for e in json.loads((b/name).read_bytes())['entries']:
  old=name.startswith('old');role=e['original_role'];full=[[1,e['actual_line_count']]]
  assigned.append({'role':role,'path':e['path'],'source_revision':e.get('source_revision',e.get('revision')),'sha256':e['sha256'],'actual_eof':e['actual_line_count'],'contiguously_displayed_body_ranges':full,'original_material_scope_personally_displayed':e.get('original_material_ranges') if old else None,'historical_excluded_personal_support_ranges':e.get('planned_personal_support_ranges') if old else [],'not_displayed_ranges':[],'registration':name,'qualification':'Separate newly assessed personal read, does not transfer earlier reviewers attribution or confer other-lens credit.'})
base='crates/adventuresim-building-generator/src/';scopes={
 'crates/AGENTS.md':([[21,86],[141,153],[182,192]],[]),
 'crates/fabelgeist-geometry/src/measurement.rs':([[1,104]],[]),
 base+'model/layout.rs':([[1,112],[155,212],[260,310]],[]),
 base+'generator/church_apse.rs':([[1,75]],[]),
 base+'generator/roof_assemblies.rs':([[1,50],[115,165],[255,277]],[91,101,102,105,107,208,231,234]),
 base+'generator/roof_cutting.rs':([[60,165],[365,410]],[170,184,217,243,257,267,276,277,279,313,323]),
 base+'generator/framed_roofs.rs':([[1,46]],[]),
 base+'generator/architectural_envelope.rs':([[1,68]],[]),
 base+'model/player_build.rs':([[1,180],[375,446]],[]),
 base+'model/editor.rs':([[60,120]],[4]),
 base+'viewer/player_build_scene.rs':([[1,115]],[121,198,329,342,346,348,385]),
 base+'generator/civilian_roofs.rs':([[1,41]],[]),
 base+'audit/roofs.rs':([[185,245],[975,1045],[1100,1155]],[26,602,801,809,853,861,862,864,868,880,888,1392,1393,1399]),
 base+'generator/roof_derivation.rs':([[1,32]],[104,108,129,177,216,249]),
 base+'generator/core.rs':([[180,215],[255,311]],[153,221,224,227,237,240,243]),
 base+'model/building_program.rs':([[1,66]],[]),
 base+'model/building_program/residential.rs':([[55,90]],[13,50,98,115,129,175]),
 base+'model/building_program/institutional.rs':([[1,50]],[69,89])}
support=[]
for fn in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json']:
 for e in json.loads((b/fn).read_bytes())['entries']:
  ranges,snips=scopes[e['path']];support.append({'revision':rev,'path':e['path'],'sha256':e['sha256'],'actual_eof':e['actual_line_count'],'contiguously_displayed_body_ranges':ranges,'isolated_search_result_lines_outside_displayed_ranges':snips,'not_contiguously_displayed_ranges':missing(e['actual_line_count'],ranges),'registration':fn,'qualification':'Support only, no original role or other-lens credit. Search snippets are not contiguous body reads.'})
r={'schema':'726-personal-source-read-receipt-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'/root/rig_identity','assigned_personal_reads':assigned,'support_personal_reads':support,'historical_attribution':{'774_rig':'RIG-OWNER-REACHED-PRODUCER-REGISTER-003/QUALIFICATION-003 role2491 producer1–80 only; 81–123 excluded; no other lens/owner verdict.', '774_native':'NATIVE-ROOF-PPS-SOURCE-001 historical 6533 roof_geometry1–34,56–470; SOURCE-002 roof_resolution1–738; bounded producer audit by native supplier, root reconciled narratives in producer-followup-acceptance-028; no transfer to current.', '059_segovb_l11':'READ-L11-413 fresh REG1392 original role1–80 and REG1393 separate81–123; READ-L11-414 fresh REG1394 1–34,56–470, REG1395 1–738 and REG1400 separate35–55.', '059_delegated_l12':'READ-L12-844 PAR506 /root/lens12_frontier fresh role2491 1–80; READ-L12-845 PAR510 fresh role2492 1–34,56–470; READ-L12-846 PAR511 cumulative role2493 1–738 consisting earlier READ-PARTIAL personal1–555 and new556–738, no full reread, root personal rereads empty.'},'execution':'Source/evidence inspection and symbolic reasoning only; no tests, fixtures, product, viewer, renderer, physics, build, simulation, probe, source edit or repair.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'personal-read-receipt.json').write_bytes(raw);print('receipt',hashlib.sha256(raw).hexdigest(),'assigned',len(assigned),'support',len(support))
