from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,shutil,subprocess
b=Path('<LOCAL_PATH_0>');prev=Path('<LOCAL_PATH_1>');old=Path('<LOCAL_PATH_2>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
for p in ['original-registry.json.gz','original-transport-manifest.json.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:shutil.copyfile(prev/p,b/p)
r=json.load(gzip.open(b/'original-registry.json.gz','rt'));recon={'schema':'726-original-registry-selection-reconstructed-v1','qualification':'Reconstruction from exact original 059 registry; not an original historical record or checkpoint3821.','original_registry_sha256_uncompressed':sha(gzip.decompress((b/'original-registry.json.gz').read_bytes())),'rows':[{'original_index':i,**r['files'][i]} for i in [2491,2492,2493]],'snapshots':[x for x in r['snapshots'] if x['id'] in ['physical-p16','pr-working']]};(b/'registry-selection-reconstructed.json').write_text(json.dumps(recon,indent=2)+'\n')
m=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in m['entries']};paths=[]
for n in [413,414,844,845,846]:
 for k in ['READ','VERIFY','STATE']:paths.append(f'segovb/{k}-L{11 if n in [413,414] else 12}-{n}.json')
for n in [1392,1393,1394,1395,1400]:paths.append(f'segovb/REGISTRATION-SEGOVB-{n}.json')
for n in [506,510,511]:paths.append(f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json')
for n,i in [(506,2491),(510,2492),(511,2493)]:paths.append(f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{n}-WINDOWS-ORIGINAL{i}.json')
for n in [844,845,846]:paths.append(f'parallel-l12-20261029/PROPOSAL-L12-{n}.json')
paths.append('parallel-l12-20261029/READ-PARTIAL-PAR-L12-846-ORIGINAL2493-001.json')
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file(): missing.append(p);continue
 x=(old/p).read_bytes();e=idx[p];assert len(x)==e['bytes'] and sha(x)==e['sha256'] and oid(x)==e['git_blob'];d=b/'historical-059'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(x);records.append({'original_path':p,'sha256':sha(x),'bytes':len(x),'git_blob':oid(x),'preserved_bytes':str(d.relative_to(b))})
paths774=['handoff/774/adler-original/audit/continuation/rig/owner-reached-producer-followup/additional-sources.jsonl','handoff/774/adler-original/audit/continuation/rig/owner-reached-producer-followup/source-qualifications.jsonl','handoff/774/adler-original/audit/continuation/root/producer-scope-extension-authority-022.json','handoff/774/adler-original/audit/continuation/native/producer-registry-reconciliation/candidate-002.json','handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/read-plan.json','handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/coverage.jsonl','handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/findings.jsonl','handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/traces.jsonl','handoff/774/adler-original/audit/continuation/root/producer-followup-acceptance-028.json','handoff/774/adler-original/audit/continuation/producer-followup-scope-extensions-020.json'];rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records774=[]
for p in paths774:
 proc=subprocess.run(['git','show',rev+':'+p],capture_output=True)
 if proc.returncode:missing.append('774 '+p);continue
 x=proc.stdout;assert oid(x)==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();d=b/'historical-774'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(x);records774.append({'transport_revision':rev,'transport_path':p,'sha256':sha(x),'bytes':len(x),'git_blob':oid(x),'preserved_bytes':str(d.relative_to(b))})
r={'schema':'726-bounded-historical-attribution-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'original_059_records':records,'older_774_receipts':records774,'missing_records':missing,'qualification':'Exact 059 and 774 bytes retained under their original historical identities; transport is not current checkpoint and reconstruction grants no prior read credit.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'original-attribution.json').write_bytes(raw);print('059',len(records),'774',len(records774),'missing',missing,'sha',sha(raw))
