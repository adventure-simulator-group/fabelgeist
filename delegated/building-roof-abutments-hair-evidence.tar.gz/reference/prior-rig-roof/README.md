# Bounded physical and roof source audit evidence

This packet covers original role 2491 from the physical-p16 recorded dirty
snapshot and roles 2492–2493 from the pr-working recorded 6533 snapshot,
compared with pinned revision 95e63628f9d70b8dd6e6fede64334696c6995009.
See `REPORT.json` for conditions, nonfindings, open questions, historical
relationships, and thirteen perspectives bounded to these source roles.

`old-registration.json` and `current-registration.json` were written before
source display. Their original material scopes and separately read support
are retained in `personal-read-receipt.json`. `support-registration*.json`
identifies additional registered source; the receipt distinguishes actually
displayed ranges, search snippets, and unread lines. Full archived bytes and
hashes never grant read credit by themselves.

`original-registry.json.gz`, `original-transport-manifest.json.gz`, original
059 queue and ledger bytes, and `historical-059/` are recovered historical
records. `registry-selection-reconstructed.json` is an explicitly marked
reconstruction, not a historic original. `historical-774/` contains original
records recovered from f82, which is an evidence transport revision. The
physical-p16 source is a dirty snapshot identity; its particular cuboid blob
happens to equal the file at the recorded a120 base. The two roof bodies match
their separate 6533 file objects and the current 95e file objects. These facts
do not establish that either recorded working snapshot was clean.

`git-proofs.json` and `git-objects/` preserve commit and tree objects for
independent membership proof; source bytes and historical 774 records supply
the terminal blobs. `evidence-verification.json` records source/hash, receipt,
reference, and Git-chain checks only. `MANIFEST.json` hashes every packet file
except itself. No product execution, build, test, runtime probe, viewer,
physics, renderer, fixture, simulation, repair, or source edit was performed.
Historical evidence is not checkpoint 3821 evidence; central reconciliation
owns unique findings, authoritative baseline, and publication.
