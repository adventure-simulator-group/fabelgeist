from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json
b=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();reg=json.load(gzip.open(b/'original-registry.json.gz','rt'));old=json.loads((b/'old-registration.json').read_bytes())['entries'];current=json.loads((b/'current-registration.json').read_bytes())['entries'];receipt=json.loads((b/'personal-read-receipt.json').read_bytes());proof=json.loads((b/'git-proofs.json').read_bytes());report=json.loads((b/'REPORT.json').read_bytes());man=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in man['entries']}
for e in old:
 x=(b/e['source_archive']).read_bytes();row=reg['files'][e['original_role']];assert sha(x)==row['sha256']==e['sha256'] and len(x)==row['bytes']==e['bytes'] and len(x.splitlines())==row['actual_line_count'] and row['material_ranges']==e['original_material_ranges']
for e in current:
 x=(b/e['source_archive']).read_bytes();assert sha(x)==e['sha256'] and len(x)==e['bytes'] and len(x.splitlines())==e['actual_line_count']
assert (b/old[0]['source_archive']).read_bytes().splitlines()[:80]==(b/current[0]['source_archive']).read_bytes().splitlines()[:80]
assert old[1]['sha256']==current[1]['sha256'] and old[2]['sha256']==current[2]['sha256'] and old[0]['sha256']!=current[0]['sha256']
for f in ['original-attribution.json','connected-original-059.json']:
 j=json.loads((b/f).read_bytes());rows=j.get('original_059_records',j.get('records',[]));assert not j.get('missing_records',j.get('missing',[]))
 for e in rows:
  x=(b/e['preserved_bytes']).read_bytes();orig=idx[e['original_path']];assert sha(x)==e['sha256']==orig['sha256'] and len(x)==orig['bytes'] and oid('blob',x)==orig['git_blob']==e['git_blob']
for e in json.loads((b/'original-attribution.json').read_bytes())['older_774_receipts']:
 x=(b/e['preserved_bytes']).read_bytes();assert sha(x)==e['sha256'] and len(x)==e['bytes'] and oid('blob',x)==e['git_blob']
def tree_entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
objects={}
for key,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,e in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==e['root_tree']
for p in proof['paths']:
 curr=proof['commits'][p['revision']]['root_tree'];parts=p['path'].split('/');assert len(parts)==len(p['path_chain'])
 for name,step in zip(parts,p['path_chain']):
  assert step['tree']==curr and step['name']==name;mode,child=tree_entries(objects[curr])[name];assert mode==step['mode'] and child==step['object'];curr=child
 raw=(b/p['preserved_bytes']).read_bytes();assert oid('blob',raw)==curr==p['git_blob'] and sha(raw)==p['sha256'] and len(raw)==p['bytes']
assert len(receipt['assigned_personal_reads'])==6 and len(receipt['support_personal_reads'])==18 and len(report['lenses'])==13
for e in receipt['assigned_personal_reads']:
 assert e['contiguously_displayed_body_ranges']==[[1,e['actual_eof']]] and not e['not_displayed_ranges']
for e in receipt['support_personal_reads']:
 seen=set()
 for a,z in e['contiguously_displayed_body_ranges']:
  assert 1<=a<=z<=e['actual_eof'];seen.update(range(a,z+1))
 absent=set()
 for a,z in e['not_contiguously_displayed_ranges']:
  assert 1<=a<=z<=e['actual_eof'];absent.update(range(a,z+1))
 assert seen.isdisjoint(absent) and len(seen)+len(absent)==e['actual_eof']
# Every current cited line is among personally displayed assigned or support body ranges.
scopes={e['path']:e['contiguously_displayed_body_ranges'] for e in receipt['support_personal_reads']}
for e in receipt['assigned_personal_reads']:
 if e['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009':scopes[e['path']]=e['contiguously_displayed_body_ranges']
def visit(x):
 if isinstance(x,dict):
  if x.get('revision')=='95e63628f9d70b8dd6e6fede64334696c6995009' and 'lines' in x:
   assert x['path'] in scopes
   for a,z in x['lines']:assert any(a>=lo and z<=hi for lo,hi in scopes[x['path']]),(x['path'],a,z)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Three historical bodies match original registry source bytes, ranges and line counts; independent current hashes and body counts','P16/current first 80 lines equal; historical roof object SHA equals 95e; P16 full SHA differs','All copied 059 originals match recovered transport manifest SHA, byte count and Git blob; 774 records match Git blob','Raw Git commit/tree/blob chain proves f82 transport, 6533, 95e and a120 particular file equality separately','Six personally displayed role bodies and bounded support receipt complements checked; every current report citation falls inside a personally displayed range','Thirteen bounded lens entries present; no execution or validation of product'], 'scope':'Evidence-only structural/hash checks, not product validation.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw);print('PASS',sha(raw),'proofs',len(proof['paths']),'Git objects',len(objects),'059 records',len(json.loads((b/'original-attribution.json').read_bytes())['original_059_records'])+len(json.loads((b/'connected-original-059.json').read_bytes())['records']))
