from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');reg=json.load(gzip.open('<LOCAL_PATH_1>','rt'))['files']; old='6533e444fa37552927070cc8d8190907fd3b413e'; transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'; cur='95e63628f9d70b8dd6e6fede64334696c6995009'; o=[];c=[]; pending=[]
def show(rev,path): return subprocess.check_output(['git','show',rev+':'+path])
def sha(raw): return hashlib.sha256(raw).hexdigest()
def blob(raw): return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
for i in (2491,2492,2493):
 row=reg[i];p=row['source_id'].split(':',1)[1]; archive='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'] if i==2491 else p; rev=transport if i==2491 else old
 raw=show(rev,archive);gitblob=subprocess.check_output(['git','rev-parse',rev+':'+archive],text=True).strip();assert sha(raw)==row['sha256'] and len(raw)==row['bytes'] and blob(raw)==gitblob and len(raw.splitlines())==row['actual_line_count']
 src=f'sources/{"p16" if i==2491 else "6533"}/{p}';pending.append((src,raw));o.append({'original_role':i,'original_source_id':row['source_id'],'original_registry_locator':row['path'],'source_revision':'physical-p16 dirty working snapshot' if i==2491 else old,'recorded_snapshot_base':'a120390947c89b703dc74c4255a13c035d054c50' if i==2491 else None,'transport_revision':rev,'transport_path':archive,'path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob_at_transport':gitblob,'actual_line_count':len(raw.splitlines()),'original_material_ranges':row['material_ranges'],'planned_personal_role_ranges':row['material_ranges'],'planned_personal_support_ranges':[[81,123]] if i==2491 else ([[35,55]] if i==2492 else []),'source_archive':src,'qualification':'physical-p16 is recorded dirty state; f82 is archive transport and not the P16 source commit' if i==2491 else 'Independent exact 6533 file-object match, not proof that pr-working whole tree was clean.'})
 raw=show(cur,p);gitblob=subprocess.check_output(['git','rev-parse',cur+':'+p],text=True).strip();assert blob(raw)==gitblob;src=f'sources/95e6/{p}';pending.append((src,raw));c.append({'original_role':i,'revision':cur,'path':p,'sha256':sha(raw),'git_blob':gitblob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'planned_personal_body_ranges':[[1,len(raw.splitlines())]],'source_archive':src,'byte_equal_to_original':sha(raw)==row['sha256'],'qualification':'Separate current personal display is planned; archive equality alone does not transfer read attribution.'})
t=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC');
for name,rows in [('old-registration.json',o),('current-registration.json',c)]:
 raw=(json.dumps({'schema':'726-prospective-bounded-source-registration-v1','created_utc':t,'reader':'/root/rig_identity','registration':'Prospective registration before any assigned source body display. Full bytes retained; personal role and support ranges kept separate.','entries':rows},indent=2)+'\n').encode();(b/name).write_bytes(raw);print(name,sha(raw));print(json.dumps(rows,indent=2))
for path,raw in pending:
 d=b/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
