from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-building-generator/src/generator/civilian_roofs.rs','crates/adventuresim-building-generator/src/audit/roofs.rs'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();src='support/95e6/'+p;pending.append((src,raw));entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'planned_bounded_ranges':[[1,len(raw.splitlines())]],'source_archive':src,'qualification':'Separate bounded producer/admission support; no original role credit. Actual display ranges in receipt.'})
r={'schema':'726-prospective-support-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'support-registration-04.json').write_bytes(raw)
for p,x in pending:
 d=b/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(x)
print(hashlib.sha256(raw).hexdigest());print(json.dumps(entries,indent=2))
