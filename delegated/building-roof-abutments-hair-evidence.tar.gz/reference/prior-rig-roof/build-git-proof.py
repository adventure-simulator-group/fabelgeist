import gzip,hashlib,json,pathlib,subprocess
b=pathlib.Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();cur=root(rev);chain=[]
 for segment in path.split('/'):
  mode,child=entries(save('tree',cur))[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
old=json.load(open(b/'old-registration.json'))['entries'];cur=json.load(open(b/'current-registration.json'))['entries']
for e in old:proof(e['transport_revision'],e['transport_path'],e['source_archive'],'historical P16 archive object; transport not source commit' if e['original_role']==2491 else 'historical pr-working exact source file')
proof('a120390947c89b703dc74c4255a13c035d054c50',old[0]['path'],old[0]['source_archive'],'recorded P16 base file is equal only; base is not dirty snapshot commit')
for e in cur:proof(e['revision'],e['path'],e['source_archive'],'pinned current source file')
for n in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json']:
 for e in json.load(open(b/n))['entries']:proof(e['revision'],e['path'],e['source_archive'],'bounded current support source or rule')
for e in json.load(open(b/'original-attribution.json'))['older_774_receipts']:proof(e['transport_revision'],e['transport_path'],e['preserved_bytes'],'774 historical evidence transport only')
r={'schema':'726-physical-roof-git-proof-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Raw commit and tree bytes prove exact file membership. physical-p16 dirty state is identified independently via original registry SHA and f82 recovered object; a120 matching file does not turn dirty snapshot into a commit. None of these proofs grants read credit.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'git-proofs.json').write_bytes(raw);print('proofs',len(proofs),'objects',len(objects),'sha',sha(raw))
