import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>'; sha=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_bytes()); names=['support-registration.json','support-registration-02.json'];sup=[x for n in names for x in json.loads((p/n).read_bytes())['sources']];(p/'git-objects').mkdir(exist_ok=True);objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for role in reg['roles']:
 for v in role['versions']:members.append({'revision':v['revision'],'path':role['path'],'local':v['local_path'],'sha256':v['sha256'],'git_blob':v['git_blob']})
 v=role['versions'][0];members.append({'revision':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+v['sha256'],'local':v['local_path'],'sha256':v['sha256'],'git_blob':v['git_blob'],'qualification':'f82 archive transport of original 6533 object, not source revision or 3821 proof'})
members+=sup
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();proofs.append({'revision':s['revision'],'path':s['path'],'archive':s['local'],'commit_tree':root,'chain':chain,'blob':tree,'qualification':s.get('qualification')})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Commit/tree membership for exact pinned and historical bodies and archived recovered objects only; f82 is archive transport, not a source revision. Git tree bytes do not establish a whole-worktree cleanliness claim.','objects':objects,'proofs':proofs},indent=2)+'\n')
role_reads=[{'index':2496,'displayed_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','displayed_windows':[[1,110],[111,210]],'unread_complement':[],'historical_revision':'6533e444fa37552927070cc8d8190907fd3b413e','historical_displayed_windows':[],'historical_unread_complement':[[1,210]],'byte_equality_verified':True},{'index':2497,'displayed_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','displayed_windows':[[1,90],[91,175],[176,251]],'unread_complement':[],'historical_revision':'6533e444fa37552927070cc8d8190907fd3b413e','historical_displayed_windows':[],'historical_unread_complement':[[1,251]],'byte_equality_verified':True}]
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registration':'registration.json','registration_sha256':sha((p/'registration.json').read_bytes()),'roles':role_reads,'qualification':'95e bodies displayed in full after registration, including existing test source without execution. Historical copies verified byte-identical and archived but not separately displayed; equality does not transfer personal historical read credit.'},indent=2)+'\n')
ranges={'generator/roof_contacts.rs':[[1,106]],'generator/roof_assemblies.rs':[[1,80],[80,180],[180,245],[240,277]],'generator/roof_resolution.rs':[[390,455],[450,485],[565,660],[710,738]],'generator/roof_editing.rs':[[1,62],[60,145]],'model/layout.rs':[[55,95],[160,290]],'model/resolved_networks.rs':[],'audit/resolved_geometry.rs':[[1,95]],'audit/roofs.rs':[[1,45],[195,230],[1110,1150],[1210,1285],[1274,1296],[1330,1420]],'generator/core.rs':[[185,235],[255,311]],'generator/civilian_roofs.rs':[[1,41]],'generator/roof_derivation.rs':[[1,105],[205,265]],'generator/church_assembly.rs':[[1,30],[235,260]],'generator/roof_geometry.rs':[[56,125]],'generator/small_church.rs':[[1,40]],'generator/tower_derivation.rs':[]}; reads=[]
for s in sup:
 short=s['path'].split('/src/',1)[1]; windows=ranges[short];eof=s['prospective_range'][1];covered=set()
 for a,b in windows:covered.update(range(a,b+1))
 unread=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in covered and start is None:start=i
  if start is not None and (i==eof+1 or i in covered):unread.append([start,i-1]);start=None
 reads.append({'path':s['path'],'revision':s['revision'],'archive':s['local'],'sha256':s['sha256'],'eof':eof,'actual_display_windows':windows,'unread_complement':unread})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in names],'reads':reads,'qualification':'Only recorded windows are full-line displays; registered bodies outside those windows unread. rg -n -o navigation emitted symbol matches only and confers no body credit. No ordered-role or external reviewer credit.'},indent=2)+'\n');print('git membership proofs',len(proofs),'tree objects',len(objects),'role reads',len(role_reads),'support registrations',len(sup))
