import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());reg=load('registration.json');rr=load('read-receipt.json');sr=load('support-read-receipt.json');proof=load('git-proofs.json');hist=load('historical-manifest.json');report=load('report.json');original=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));older=json.loads(gzip.decompress((p/'reference/older-774-handoff-manifest.json.gz').read_bytes()));registry=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()));queue=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()));
assert rr['registration_sha256']==sha((p/'registration.json').read_bytes())
assert datetime.datetime.fromisoformat(reg['registered_utc'])<datetime.datetime.fromisoformat(rr['recorded_utc'])
reads={}
def check_partition(eof,windows,unread):
 a=set(); b=set()
 for lo,hi in windows: assert 1<=lo<=hi<=eof;a.update(range(lo,hi+1))
 for lo,hi in unread: assert 1<=lo<=hi<=eof;b.update(range(lo,hi+1))
 assert not (a&b) and a|b==set(range(1,eof+1));return a
for role,receipt in zip(reg['roles'],rr['roles']):
 assert role['original_index']==receipt['index'];old,current=role['versions'];b=(p/old['local_path']).read_bytes();assert b==(p/current['local_path']).read_bytes()
 assert old['sha256']==current['sha256']==registry['files'][role['original_index']]['sha256']==catalog['rows'][role['original_index']]['expected_sha256']==sha(b)
 assert pathlib.Path(catalog['rows'][role['original_index']]['object']).read_bytes()==b
 for v in [old,current]:
  s=(p/v['local_path']).read_bytes();assert len(s)==v['bytes'] and sha(s)==v['sha256'] and blob(s)==v['git_blob'] and len(s.splitlines())==v['prospective_full_range'][1]
  assert subprocess.check_output(['git','-C',repo,'show',v['revision']+':'+role['path']])==s
 assert receipt['displayed_revision']==current['revision'] and receipt['historical_revision']==old['revision']
 reads[role['path']]=check_partition(current['prospective_full_range'][1],receipt['displayed_windows'],receipt['unread_complement'])
 assert not receipt['historical_displayed_windows'];check_partition(old['prospective_full_range'][1],receipt['historical_displayed_windows'],receipt['historical_unread_complement'])
for f in sr['prospective_registrations']:assert sha((p/f['path']).read_bytes())==f['sha256'] and datetime.datetime.fromisoformat(load(f['path'])['registered_utc'])<datetime.datetime.fromisoformat(sr['recorded_utc'])
sup=[s for f in sr['prospective_registrations'] for s in load(f['path'])['sources']];assert len(sup)==len(sr['reads'])
for s,r in zip(sup,sr['reads']):
 b=(p/s['local']).read_bytes();assert s['path']==r['path'] and sha(b)==s['sha256']==r['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==r['eof'] and blob(b)==s['git_blob'];assert subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['path']])==b;reads[s['path']]=check_partition(r['eof'],r['actual_display_windows'],r['unread_complement'])
objs={}
for oid,o in proof['objects'].items():
 b=gzip.decompress((p/o['archive']).read_bytes());assert len(b)==o['bytes'] and sha(b)==o['sha256'];assert hashlib.sha1(o['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=b
def tree_entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
for q in proof['proofs']:
 assert objs[q['revision']].splitlines()[0].split()[1].decode()==q['commit_tree'];tree=q['commit_tree']
 for name,chain in zip(q['path'].split('/'),q['chain']):
  assert chain['tree']==tree and chain['name']==name;mode,tree=tree_entries(objs[tree])[name];assert mode==chain['mode'] and tree==chain['object']
 assert tree==q['blob']==blob((p/q['archive']).read_bytes())
for o in hist['records']:
 b=(p/o['copy']).read_bytes();assert sha(b)==o['sha256'] and len(b)==o['bytes'] and blob(b)==o['git_blob'];index=original['entries'] if o['scope']=='059' else older['files'];match=next(x for x in index if x['path']==o['original_path']);assert match['bytes']==len(b) and match['sha256']==sha(b);assert o['scope']!='059' or match['git_blob']==blob(b)
assert not hist['unavailable'];prior=p/hist['prior_packet']['path'];man=(prior/'MANIFEST.json').read_bytes();assert sha(man)==hist['prior_packet']['manifest_sha256'];m=json.loads(man)
for f in m['files']:
 b=(prior/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
assert sha((prior/'REPORT.json').read_bytes())==hist['prior_packet']['report_sha256'];assert json.loads((prior/'REPORT.json').read_bytes())['delegate']=='/root/rig_identity'
oldf=load('historical/774/audit/reconcile-adler-20261023/audit-continuation/redundant-authority/finding-F127.json');oldsum=load('historical/059/evidence/audit07-delta/predecessor/frozen-findings.json');assert oldf==oldsum[57] and oldf['id']=='CONT07-F127' and oldf['validation_status']=='not_run'
assert queue['entries'][639]['contract_id']=='Q-L11-2f8a2a6324127b4f5f82' and queue['entries'][639]['status']=='open-evidence-or-disposition'
assert len(report['lenses'])==13 and len(set(x['lens'] for x in report['lenses']))==13
references=[]
def visit(x):
 if isinstance(x,dict):
  if {'revision','path','lines'}<=x.keys():references.append(x)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
for r in references:
 assert r['revision']==reg['roles'][0]['versions'][1]['revision'] and r['path'] in reads
 for lo,hi in r['lines']:assert all(i in reads[r['path']] for i in range(lo,hi+1)),(r['path'],lo,hi)
result={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'source_objects_git_registry_catalog_and_equality':len(reg['roles'])*2,'independently_verified_commit_tree_membership_proofs':len(proof['proofs']),'support_source_objects_and_personal_read_partitions':len(sup),'exact_059_774_historical_records':len(hist['records']),'prior_rig_roof_manifest_files':len(m['files']),'source_references_within_actual_personal_windows':len(references),'bounded_lens_perspectives':len(report['lenses']),'historical_cont07_record_equals_059_frozen_copy':True,'old_q639_identity_and_open_status':True},'qualification':'Evidence integrity and membership verification only; no product, geometry, simulation, tests, builds, runtime probes or product validation.'}
(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
