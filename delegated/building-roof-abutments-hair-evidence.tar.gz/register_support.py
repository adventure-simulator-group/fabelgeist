import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>'); repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
names=['generator/roof_contacts.rs','generator/roof_assemblies.rs','generator/roof_resolution.rs','generator/roof_editing.rs','model/layout.rs','model/resolved_networks.rs','audit/resolved_geometry.rs','audit/roofs.rs','generator/core.rs']
rows=[]
for name in names:
 path='crates/adventuresim-building-generator/src/'+name; b=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True,check=True).stdout
 local='support/'+name.replace('/','__');(out/local).write_bytes(b)
 rows.append({'revision':rev,'path':path,'local':local,'prospective_range':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
f=out/'support-registration.json';f.write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','scope':'Current supporting files; only specifically displayed windows count as read. No ordered-role credit.','sources':rows},indent=2)+'\n'); print('registration sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(rows,indent=1))
