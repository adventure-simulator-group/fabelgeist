import datetime, hashlib, json, pathlib, subprocess, shutil
out=pathlib.Path('<LOCAL_PATH_0>')
repo='<LOCAL_PATH_1>'
older=pathlib.Path('<LOCAL_PATH_2>')
catalog=json.loads((older/'catalog.json').read_text())
revs=['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']
paths=['crates/adventuresim-building-generator/src/generator/gable_enclosure.rs','crates/adventuresim-building-generator/src/generator/roof_abutments.rs']
roles=[]
for idx,path in zip([2496,2497],paths):
 versions=[]
 for rev in revs:
  p=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True,check=True); b=p.stdout
  local=f'source/{idx}-{rev[:4]}.rs'; (out/local).write_bytes(b); h=hashlib.sha256(b).hexdigest()
  row={'revision':rev,'present':True,'local_path':local,'bytes':len(b),'prospective_full_range':[1,len(b.splitlines())],'sha256':h,'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
  if rev==revs[0]:
   c=catalog['rows'][idx]; assert c['source_id']=='pr-working:'+path and c['origin']=='git:'+rev+':'+path and c['expected_sha256']==h and pathlib.Path(c['object']).read_bytes()==b
   row.update({'recovered_catalog_object':c['object'],'recovered_catalog_origin':c['origin']})
  versions.append(row)
 roles.append({'original_index':idx,'path':path,'versions':versions})
for f in ['registry.json.gz','older-source-catalog.json.gz','original-transport-manifest.json.gz','queue-059.json.gz','older-774-handoff-manifest.json.gz','rule-AGENTS.md','rule-crates__AGENTS.md']:
 shutil.copyfile('<LOCAL_PATH_3>'+f,out/'reference'/f)
reg={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','scope':'Prospective full exact pr-working 6533 and pinned current 95e bodies; only personally displayed bounded ranges confer read credit.','qualification':'Original pr-working records and attribution remain historical, not checkpoint3821.','constraint':'Source and evidence integrity only; no product, geometry, tests, builds, runtime probes, simulations or repair.','roles':roles}
f=out/'registration.json';f.write_text(json.dumps(reg,indent=2)+'\n');print('registration sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(roles,indent=1))
