from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();objects={};proofs=[]
def save(t,k):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,b)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(b,mtime=0));objects[k]={'type':t,'size':len(b),'sha256':h(b),'local':p}
 return b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);m,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return m.decode(),k
 raise KeyError(n)
def proof(rev,path,local,kind,encoding=None):
 b=(r/local).read_bytes();b=gzip.decompress(b) if encoding=='gzip' else b;root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for part in path.split('/'):
  mode,k=lookup(save('tree',tree),part);chain.append({'tree':tree,'name':part,'mode':mode,'object':k});tree=k
 assert tree==oid('blob',b),(rev,path,local);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'encoding':encoding,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(b)})
reg=json.loads((r/'registration.json').read_bytes());base='6533e444fa37552927070cc8d8190907fd3b413e';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for e in reg['entries']:
 if 'original_index' in e:
  proof(e['historical_transport_revision'],e['historical_transport_path'],e['versions'][0]['local'],'historical pr-working source object via f82 transport')
  proof(base,e['project_path'],e['versions'][0]['local'],'individual pr-working base file equality only')
  v=e['versions'][1];proof(v['revision'],e['project_path'],v['local'],'95e current individual file')
 else:
  v=e['versions'][0];proof(v['revision'],e['project_path'],v['local'],'registered 95e current support')
for e in json.loads((r/'sampling-extension-registration.json').read_bytes())['entries']:proof(e['revision'],e['project_path'],e['local'],'separately registered 95e sampling support')
rev='eb407672813424d64ec31f208193969f5a62620c'
for path,local in [('handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json','recovered/original-059-queue.json.gz'),('handoff/726-audit-20261030-adler/evidence/continuation-segovb/ledger.json','recovered/original-059-ledger.json.gz')]:proof(rev,path,local,'original 059 source, not 3821','gzip')
for name in ['source-range-registration.jsonl','additional-contracts.jsonl','contract-groups.jsonl']:
 proof(f82,'handoff/774/adler-original/audit/continuation/rig/admission03/'+name,'prior/visor-buffe/history-774/'+name+'.gz','exact 774 rig record via f82','gzip')
proof(f82,'handoff/774/adler-original/audit/continuation/rig/initial06-type-ownership/contracts-022.json','prior/visor-buffe/history-774/contracts-022.json.gz','exact 774 rig type-ownership record via f82','gzip')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-roles2613-2614-central-reconciliation-git-proofs-v1','objects':objects,'proofs':proofs,'qualification':'f82 transports selected historical objects; it is not project source revision. Individual matches do not prove whole pr-working/P16 snapshot clean, historical personal reading, native behavior, or missing checkpoint3821.'},indent=2)+'\n');print('git proofs',len(proofs),'objects',len(objects),'sha256',h((r/'git-proofs.json').read_bytes()))
