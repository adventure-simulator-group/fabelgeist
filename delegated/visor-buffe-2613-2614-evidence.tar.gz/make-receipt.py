from pathlib import Path
import json,hashlib,datetime
r=Path(__file__).resolve().parent;files=['registration.json','support-extension-registration.json','sampling-extension-registration.json'];hashes={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files};reads=[]
for file in files:
 o=json.loads((r/file).read_bytes())
 for e in o['entries']:
  versions=e.get('versions',[e])
  for v in versions:
   windows=v['registered_windows'];got=set(n for a,z in windows for n in range(a,z+1));un=[];start=None
   for n in range(1,v['eof']+1):
    if n not in got and start is None:start=n
    if n in got and start is not None:un.append([start,n-1]);start=None
   if start is not None:un.append([start,v['eof']])
   chunks=[[1,75],[76,149]] if e.get('original_index')==2613 else windows
   reads.append({'registration':file,'local':v['local'],'project_path':e['project_path'],'original_index':e.get('original_index'),'identity':v.get('identity','pinned current project 95e'),'revision':v.get('revision'),'sha256':v['sha256'],'displayed_ranges':windows,'displayed_chunks':chunks,'unread_complement_per_registration':un})
receipt={'schema':'726-roles2613-2614-reconciliation-read-receipt-v1','reader':'/root/hair_ops','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration_sha256':hashes,'actual_displays':reads,'qualification':'All listed historical and current source windows were independently displayed as bounded untruncated output after the corresponding registration. Where the same source has an extension, complements are per registration, not a statement that extension windows were never read. No historical read or role credit is transferred from or to another reviewer. Sampling metadata navigation returned only path and line before its extension registration.'};out=(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n').encode();(r/'read-receipt.json').write_bytes(out);print('receipt',hashlib.sha256(out).hexdigest(),'views',len(reads))
