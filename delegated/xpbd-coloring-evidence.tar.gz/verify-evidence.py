#!/usr/bin/env python3
"""Read-only source/evidence hash, membership, and scope accounting; no product validation."""
import gzip,hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['timestamp_utc'] and len(receipt['actual_displays'])==4
for x in receipt['actual_displays']:
 row=next(y for y in r['rows'] if y['original_index']==x['role']);o=next(y for y in row['objects'] if y['label']==x['revision']);b=(p/o['local_file']).read_bytes();assert sha(b)==o['sha256'] and len(b.splitlines())==o['eof'];covered=set()
 for a,z in x['ranges']:covered.update(range(a,z+1))
 assert covered==set(range(1,o['eof']+1)) and not x['unread']
for row in r['rows']:assert row['objects'][0]['sha256']==row['registry_entry']['sha256']==row['objects'][1]['sha256']
checks.append('Four prospective separate historical/current displays cover both full assigned bodies; per-file identity only')
for suffix in ('','-02'):
 sr=load('support-registration'+suffix+'.json');s=load('support-read-receipt'+suffix+'.json');assert s['registration_sha256']==sha((p/('support-registration'+suffix+'.json')).read_bytes()) and sr['at']<s['at'] and len(s['reads'])==(6 if not suffix else 3)
 for x in s['reads']:
  b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof']
  assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['prospective_ranges']==x['actual_ranges'] and y['file']==x['source_file'] for y in sr['rows'])
checks.append('Nine current support files were separately registered before the displayed windows')
arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==r['registry_uncompressed_sha256'];registry=json.loads(orig)
 trans=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in trans['entries']}
for x in r['rows']:assert x['registry_entry']==registry['files'][x['original_index']]
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==14 and sum(x['kind']=='historical-774' for x in hi['records'])==5
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original registry and fourteen exact 059 records match original transport manifest; five 774 files retained')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==20
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Twenty raw commit/tree/blob chains establish 6533, 95e and f82 transport identities')
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14))
for x in report['support_reads']:
 cov=set()
 for a,z in x['actual_ranges']:cov.update(range(a,z+1))
 missing=set()
 for a,z in x['unread_for_this_registration']:missing.update(range(a,z+1))
 assert not cov.intersection(missing) and cov.union(missing)==set(range(1,x['eof']+1))
old=gzip.decompress((p/'history-774/additional-contracts.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[102])['id']=='RIG-ADMISSION03-ADDITIONAL-117' and json.loads(old[103])['id']=='RIG-ADMISSION03-ADDITIONAL-118'
old=gzip.decompress((p/'history-774/source-range-registration.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[116])['id']=='RIG-ADMISSION03-REG-117' and json.loads(old[117])['id']=='RIG-ADMISSION03-REG-118'
old=gzip.decompress((p/'history-774/findings.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[100])['id']=='RIG-ADMISSION03-F073-SUPPLEMENT-002'
groups=json.loads(gzip.decompress((p/'history-774/contracts-012.json.gz').read_bytes()))['groups'];assert 'xpbd-mass-and-projection-numerical-owners' in groups and 'xpbd-incidence-coloring-and-constraint-owner' in groups
for batch,role,ranges in [(915,2654,[[1,40]]),(916,2655,[[1,151]])]:
 old=load(f'history-059/READ-L12-{batch}.json');assert old['root_personal_rereads']==[];row=next(x for x in old['rows'] if x['original_index']==role);assert row['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in row['attribution']
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());q=load('queue-related-extract.json');assert sha((pub/'baseline-059/queue.json').read_bytes())==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'
for e in q['entries']:assert queue['entries'][e['zero_based_index']]==e['entry']
assert sha((pub/'delegated/xpbd-dynamics-report.json').read_bytes())=='da285fe579f2301a8f2873682fa99a0cecabc00a32a84b3caf87bae982d66fe4' and sha((pub/'delegated/xpbd-dynamics-evidence.tar.gz').read_bytes())=='55e757a97545e896be79e0631e48969e4d26eb59ebe20f831c50ff65d6262710'
assert sha((pub/'ASSESSMENT-DELEGATED-RECONCILIATION-4-95E.json').read_bytes())=='03c45328fd71303d6144eb869e1274cd2c3ee1c163ee9b31ed388fbc0c6c3600'
assert sha((pub/'delegated/xpbd-solver-evidence.tar.gz').read_bytes())=='c05836fc02c2ada48438a626b0c90c767f5af2d6d34fb27f57cee96f62634fe6'
recovery=json.loads((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes());assert sha((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007' and sha((pub/recovery['recovered_patch']['path']).read_bytes())==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
checks.append('Thirteen bounded perspectives, support complements, original reader attribution, REG/ADDITIONAL-117/118 and F073-SUPPLEMENT-002, queue extraction, prior published evidence and P16 recovery hash links')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and accounting only. No product execution, testing, build, probe, simulation, rendering, implementation, publication edit, whole-lens closure or checkpoint3821 promotion.'},indent=2))
