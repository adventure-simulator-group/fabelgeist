# XPBD coloring and multiplier: source-only evidence packet

This packet independently assesses original roles 2654–2655 against pinned
current 95e and the recorded 6533 pr-working per-file identities. `report.json`
contains findings, exact references, attribution and thirteen scoped lenses.

`registration.json` and `read-receipt.json` record separate prospective and
actual historical/current displays. Support registrations and receipts cover
only the specified windows: preserved whole bytes do not imply whole-file
personal reads. Historical 059 and 774 records retain their original reviewers,
ranges, project revisions and transport qualifications.

`git-proofs.json` and `git-objects/` preserve raw Git membership proofs;
`historical-index.json` lists exact source evidence. `queue-related-extract.json`
is a reconstructed subset rather than an original standalone document. The
verification script takes the publication directory containing the hash-linked
registry, transport manifest, original queue and previously published packets:

```
python3 verify-evidence.py /path/to/target/726-audit-baseline/publication
```

`verification.json` records evidence-integrity checks only. No product, build,
test, simulation, GPU, shader, fixture, probe, implementation or repair ran.
There is no checkpoint3821 or whole-lens completion claim.
