from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');p='crates/adventuresim-tactical-client/src/animation_viewer/report/metrics/support_slip.rs';revs=['90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696','95e63628f9d70b8dd6e6fede64334696c6995009'];entries=[];pending=[]
for rev in revs:
 raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_maximum_range':[1,len(raw.splitlines())],'scope':'paired supported-slip producer support; no ordered-role credit'});pending.append((rev,raw))
r={'schema':'726-p17-facing-prospective-support-v4','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','purpose':'Compare unsupported versus unavailable versus measured slip without assuming all missing support is defective.','entries':entries};(b/'support4-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for rev,raw in pending:
 d=b/'support'/rev[:4]/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support4 SHA',hashlib.sha256((b/'support4-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
