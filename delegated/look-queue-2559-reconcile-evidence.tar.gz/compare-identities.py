from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).parent;repo='<LOCAL_PATH_0>';path='crates/adventuresim-tactical-client/src/animation/procedural.rs';old=(b/'sources/p16-role.rs').read_bytes();current=(b/'sources/current-role.rs').read_bytes();revs=['a120390947c89b703dc74c4255a13c035d054c50','6533e444fa37552927070cc8d8190907fd3b413e','039329518e264f19206cf5b0b98d177433f40c17'];spec={'author':'/root/rig_identity','registered_utc':datetime.now(timezone.utc).isoformat(),'path':path,'revisions':revs,'purpose':'Static per-file identity comparison only, no body display or P16 clean-snapshot inference.'};(b/'comparison-registration.json').write_text(json.dumps(spec,indent=2)+'\n');out=[]
for r in revs:
 d=subprocess.check_output(['git','-C',repo,'show',r+':'+path]);assert d==old;out.append({'revision':r,'path':path,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'identical_to':'sources/p16-role.rs','qualification':'Per-file identity only; does not identify dirty snapshot with its base or transfer a reviewer.'})
a=old.splitlines();z=current.splitlines();assert len(a)==len(z)==1813
for start,end in [[81,230],[669,716]]:assert a[start-1:end]==z[start-1:end]
(b/'comparison-result.json').write_text(json.dumps({'per_file_proofs':out,'personally_displayed_equal_old_current_ranges':[[81,230],[669,716]],'whole_file_sha_equal':hashlib.sha256(old).digest()==hashlib.sha256(current).digest(),'qualification':'No claim of equivalence outside displayed windows, despite additional whole-byte identity navigation; historical scopes remain their own.'},indent=2)+'\n');print('three per-file revision comparisons match; old/current whole source differs; displayed registered ranges match')
