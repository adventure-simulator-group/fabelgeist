from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objs={};commits={};proofs=[]
def save(t,k):
 if k not in objs:
  d=g('cat-file',t,k);assert oid(t,d)==k;p='git-objects/'+k+'.'+t+'.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(d,mtime=0));objs[k]={'type':t,'sha256':sha(d),'bytes':len(d),'preserved_bytes':p}
 return gzip.decompress((b/objs[k]['preserved_bytes']).read_bytes())
def entries(raw):
 out={};i=0
 while i<len(raw):
  end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1);out[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());i=end+21
 return out
def root(rev):
 if rev not in commits:
  d=save('commit',rev);commits[rev]={'root_tree':d.splitlines()[0].split()[1].decode(),'parent_objects':[x.split()[1].decode() for x in d.splitlines() if x.startswith(b'parent ')]}
 return commits[rev]['root_tree']
def proof(rev,path,file,kind):
 d=(b/file).read_bytes();d=gzip.decompress(d) if file.endswith('.gz') else d;cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',d)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(d),'bytes':len(d),'git_blob':cur,'preserved_bytes':file,'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for x in json.loads((b/'registration.json').read_bytes())['entries']:
 if x['kind']=='historical dirty physical-p16':proof(f82,x['transport_path'],x['archive'],'dirty P16 recovered object transport, not source commit')
 else:proof(x['revision'],x['git_path'],x['archive'],'exact pinned current source; personal ranges separately registered')
for x in json.loads((b/'extra-registration-3.json').read_bytes())['entries']:proof(x['revision'],x['git_path'],x['archive'],'additional independently registered current type support')
for x in json.loads((b/'comparison-result.json').read_bytes())['per_file_proofs']:proof(x['revision'],x['path'],x['identical_to'],'separate committed per-file equality; no full snapshot or read attribution transfer')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(f82,x['transport_path'],x['archive'],'original older reviewer record transported by f82')
(b/'git-proofs.json').write_text(json.dumps({'schema':'726-look-queue-git-proofs-v1','commits':commits,'objects':objs,'paths':proofs,'qualification':'Per-file commit/tree/blob identities and historical source transport only. P16 dirty snapshot is not a commit and current worktree status, product execution and whole-lens clearance are not established.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objs))
