from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).parent;regs=[json.loads((b/n).read_bytes()) for n in ['registration.json','extra-registration.json','extra-registration-2.json','extra-registration-3.json']];chunks={'p16-role':[[81,156],[157,230],[669,716]],'p16-response':[[20,45],[115,145]],'p16-config':[[1,66]],'current-role':[[81,156],[157,230],[669,716]],'current-response':[[20,45],[115,145]],'current-config':[[1,66]],'current-measurement':[[70,107]],'current-plugin':[[65,100]],'current-net-client':[[610,650]],'current-player':[[1365,1415]],'current-bot':[[620,672],[673,725],[755,790]],'bot-production':[[250,325]],'player-write':[[190,235],[1065,1105]],'player-consume':[[1158,1190]],'bot-schedule':[[322,365]],'response-conversion':[[150,180]],'authored-angle':[[1,13],[75,95]]}
def u(xs):
 out=[]
 for a,z in sorted(xs):
  if out and a<=out[-1][1]+1:out[-1][1]=max(out[-1][1],z)
  else:out.append([a,z])
 return out
def comp(xs,n):
 out=[];i=1
 for a,z in u(xs):
  if i<a:out.append([i,a-1])
  i=z+1
 if i<=n:out.append([i,n])
 return out
rows=[]
for reg,name in zip(regs,['registration.json','extra-registration.json','extra-registration-2.json','extra-registration-3.json']):
 for e in reg['entries']:
  c=chunks[e['id']];assert u(c)==u(e['prospective_ranges']);rows.append({'id':e['id'],'archive':e['archive'],'sha256':e['source_sha256'],'registration':name,'actual_display_chunks':c,'actual_display_union':u(c),'unread_complement_for_this_registration':comp(c,e['eof']),'eof':e['eof']})
(b/'personal-read-receipt.json').write_text(json.dumps({'schema':'726-look-queue-personal-display-v1','recorded_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','registrations':[{'file':n,'sha256':hashlib.sha256((b/n).read_bytes()).hexdigest()} for n in ['registration.json','extra-registration.json','extra-registration-2.json','extra-registration-3.json']],'reads':rows,'qualification':'Exact fresh windows and registration-specific complements. Read test source as text only; no tests or fixtures executed. Separate earlier authors and original P16 role materials are not enlarged.'},indent=2)+'\n');print('reads',len(rows))
