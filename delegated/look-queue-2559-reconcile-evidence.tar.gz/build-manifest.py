from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;files=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':
  d=p.read_bytes();files.append({'path':str(p.relative_to(b)),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
(b/'MANIFEST.json').write_text(json.dumps({'schema':'726-look-queue-2559-manifest-v1','created_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','self_excluded':True,'qualification':'Bounded source evidence and separately attributed historic records.','files':files},indent=2)+'\n');print('manifest files',len(files))
