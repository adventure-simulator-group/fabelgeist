from pathlib import Path
from datetime import datetime,timezone
import json
b=Path(__file__).parent;reg=json.loads((b/'registration.json').read_bytes());d={x['id']:x for x in reg['entries']};rows=[]
for id,source,ranges in [('player-consume','current-player',[[1158,1190]]),('bot-schedule','current-bot',[[322,365]])]:
 x=d[source];rows.append({'id':id,'kind':'additional current bounded producer support','revision':x['revision'],'git_path':x['git_path'],'archive':x['archive'],'source_sha256':x['source_sha256'],'git_blob':x['git_blob'],'bytes':x['bytes'],'eof':x['eof'],'prospective_ranges':ranges,'purpose':'Connect producer installation and validated assignment; no role credit.'})
(b/'extra-registration-2.json').write_text(json.dumps({'schema':'726-look-producer-extra-registration-v1','author':'/root/rig_identity','registered_utc':datetime.now(timezone.utc).isoformat(),'entries':rows,'qualification':'Prospective before exact additional display; no inference of execution.'},indent=2)+'\n')
