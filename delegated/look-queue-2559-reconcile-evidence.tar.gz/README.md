# Role 2559 look producer and retained-state reconciliation

This additive packet relates the original dirty physical-p16 producer role 2559
and selected older queue records to bounded source at pinned project revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Start with `REPORT.json`.

The original role material is 157–230 and 669–716. The registration files and
`personal-read-receipt.json` record exact fresh historical/current displays and
separate support windows. Full archived bytes are not full-read credit. P16 is
a dirty snapshot based on a120; individual old file equality to a120, 6533 and
039329 is proved without making the whole snapshot a commit. The later matching
tracked-patch recovery and separate untracked-object/custody qualifications are
preserved, alongside the prior packet’s contemporaneous missing-patch report.

The older 059 registry, queue, ledger and transport records are retained; their
selected rows are mechanical reconstructions. 774 records retain their supplier
and source scope. Recovered transcript values are normalized historical output
or field projections, not complete queue files or checkpoint 3821. The earlier
agent’s exact original and path-redacted published registrations are distinct.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` for read-only
evidence integrity checks. No product, build, test, viewer, fixture, simulation
or runtime probe was executed, and no source or publication was changed.
