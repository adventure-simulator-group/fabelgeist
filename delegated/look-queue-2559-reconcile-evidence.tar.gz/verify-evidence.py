from pathlib import Path
from datetime import datetime
import gzip,hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();j=lambda p:json.loads((b/p).read_bytes());names=['registration.json','extra-registration.json','extra-registration-2.json','extra-registration-3.json'];regs=[j(n) for n in names];es={x['id']:x for r in regs for x in r['entries']};receipt=j('personal-read-receipt.json');rs={x['id']:x for x in receipt['reads']};history=j('historical-attribution.json');report=j('REPORT.json');proof=j('git-proofs.json')
def u(xs):
 out=[]
 for a,z in sorted(xs):
  assert 1<=a<=z
  if out and a<=out[-1][1]+1:out[-1][1]=max(out[-1][1],z)
  else:out.append([a,z])
 return out
def complement(xs,eof):
 out=[];i=1
 for a,z in u(xs):
  if i<a:out.append([i,a-1])
  i=z+1
 if i<=eof:out.append([i,eof])
 return out
for name,r in zip(names,regs):
 assert datetime.fromisoformat(r['registered_utc'])<=datetime.fromisoformat(receipt['recorded_utc']);assert next(x['sha256'] for x in receipt['registrations'] if x['file']==name)==sha((b/name).read_bytes())
for id,e in es.items():
 d=(b/e['archive']).read_bytes();r=rs[id];assert len(d)==e['bytes'] and sha(d)==e['source_sha256']==r['sha256'] and oid('blob',d)==e['git_blob'] and len(d.splitlines())==e['eof'];assert u(r['actual_display_chunks'])==r['actual_display_union']==u(e['prospective_ranges']) and r['unread_complement_for_this_registration']==complement(r['actual_display_union'],e['eof'])
refs=[]
for x in report['findings_and_open_relationships']:refs+=x['source_refs']
for x in refs:
 e=es[x['id']];assert x['archive']==e['archive'] and x['sha256']==e['source_sha256'] and x['path']==e['git_path']
 for a,z in x['lines']:assert any(a>=i and z<=k for i,k in rs[x['id']]['actual_display_union']),(x['id'],a,z)
assert len(report['thirteen_bounded_perspectives'])==13
old=(b/'sources/p16-role.rs').read_bytes();current=(b/'sources/current-role.rs').read_bytes();assert sha(old)!=sha(current)
for a,z in j('comparison-result.json')['personally_displayed_equal_old_current_ranges']:assert old.splitlines()[a-1:z]==current.splitlines()[a-1:z]
for x in history['references']:
 d=(b/x['archive']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes']
 if x['archive'].endswith('.gz'):
  raw=gzip.decompress(d);assert sha(raw)==x['uncompressed_sha256'] and len(raw)==x['uncompressed_bytes']
rraw=gzip.decompress((b/'history/original-registry.json.gz').read_bytes());assert sha(rraw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';r=json.loads(rraw)
for x in j('history/registry-selection-reconstructed.json')['rows']:assert x['entry']==r['files'][x['index']]
assert r['files'][2559]['sha256']==sha(old) and r['files'][1356]['sha256']==sha(old);assert r['files'][2559]['material_ranges']==[[157,230],[669,716]]
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries']
for x in j('history/queue-selection-reconstructed.json')['rows']:assert x['entry']==q[x['index']]
assert q[1151]['contract_id']=='Q-L12-24ec01d299d573c6e7a0';assert q[45]['contract_id']=='ADLER-L11-RAISED-SUPPORT-OBSERVATION-DISPATCH'
index={x['path']:x for x in json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()))['entries']}
for x in history['records_059']:
 d=(b/x['archive']).read_bytes();v=index[x['original_path']];assert len(d)==x['bytes']==v['bytes'] and sha(d)==x['sha256']==v['sha256'] and oid('blob',d)==x['git_blob']==v['git_blob']
for x in history['records_774']:
 d=(b/x['archive']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['original_bytes'] and sha(raw)==x['original_sha256'] and oid('blob',raw)==x['git_blob']
p=history['prior_packet'];copies={x['name']:x for x in p['copies']};m=copies['BUNDLE-MANIFEST.json'];assert sha((b/m['archive']).read_bytes())==p['original_manifest_sha256'];mi={x['path']:x for x in j(m['archive'])['files']}
for x in p['copies']:
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if x['name']!='BUNDLE-MANIFEST.json':assert x['sha256']==mi[x['name']]['sha256']
red=p['published_registration'];d=(b/red['archive']).read_bytes();assert sha(d)==red['sha256']==p['published_registration_metadata']['published_sha256'];assert copies['registration.json']['sha256']==p['published_registration_metadata']['original_sha256'] and copies['registration.json']['sha256']!=red['sha256']
frag=j('history/fragments-selection-reconstructed.json');idx=json.loads(gzip.decompress((b/'history/fragments/EXTENDED-INDEX.json.gz').read_bytes()));assert frag['snapshot_sha256']==idx['snapshot_sha256'];ids={'ADLER-L11-BODY-OBSERVATION-FRAME','ADLER-L11-RAISED-SUPPORT-OBSERVATION-DISPATCH','L1-P19-RAISED-SUPPORT-OBSERVATION-DISPATCH','Q-L12-24ec01d299d573c6e7a0'};assert frag['index_hits']==[x for x in idx['entries'] if x['contract_id'] in ids];keys={x['normalized_sha256'] for x in frag['index_hits']};allvalues=[json.loads(x) for x in gzip.decompress((b/'history/fragments/PRINTED-VALUES.jsonl.gz').read_bytes()).splitlines()];assert frag['values']==[x for x in allvalues if x['normalized_sha256'] in keys]
for x in frag['values']:assert sha((json.dumps(x['value'],indent=2,ensure_ascii=False)+'\n').encode())==x['normalized_sha256']
assert sha((b/'history/p16-tracked-reproduced.patch').read_bytes())=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
objects={}
for key,x in proof['objects'].items():
 d=gzip.decompress((b/x['preserved_bytes']).read_bytes());assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==key;objects[key]=(x['type'],d)
def tree(raw):
 out={};i=0
 while i<len(raw):
  e=raw.index(b'\0',i);mode,name=raw[i:e].split(b' ',1);out[name.decode()]=(mode.decode(),raw[e+1:e+21].hex());i=e+21
 return out
for rev,c in proof['commits'].items():
 typ,d=objects[rev];assert typ=='commit' and d.splitlines()[0].split()[1].decode()==c['root_tree']
for x in proof['paths']:
 d=(b/x['preserved_bytes']).read_bytes();d=gzip.decompress(d) if x['preserved_bytes'].endswith('.gz') else d;assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob'];cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for seg,ch in zip(parts,x['path_chain']):
  assert ch['tree']==cur and ch['name']==seg;typ,raw=objects[cur];assert typ=='tree';mode,cur=tree(raw)[seg];assert mode==ch['mode'] and cur==ch['object']
 assert cur==x['git_blob']
print(json.dumps({'schema':'726-look-queue-evidence-verification-v1','status':'passed','fresh_registrations':len(es),'fresh_source_references':len(refs),'git_path_proofs':len(proof['paths']),'raw_git_objects':len(objects),'exact_059_records':len(history['records_059']),'old_774_records':len(history['records_774']),'normalized_historical_print_values':len(frag['values']),'qualification':'Read-only evidence hashing, JSON/gzip and Git object membership only. No product execution, build, test, fixture, viewer, simulation or runtime probe.'},indent=2))
