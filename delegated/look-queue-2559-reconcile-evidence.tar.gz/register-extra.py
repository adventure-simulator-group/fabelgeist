from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).parent;reg=json.loads((b/'registration.json').read_bytes());d={x['id']:x for x in reg['entries']};rows=[]
for id,source,ranges in [('bot-production','current-bot',[[250,325]]),('player-write','current-player',[[190,235],[1065,1105]])]:
 x=d[source];rows.append({'id':id,'kind':'additional current bounded producer support','revision':x['revision'],'git_path':x['git_path'],'archive':x['archive'],'source_sha256':x['source_sha256'],'git_blob':x['git_blob'],'bytes':x['bytes'],'eof':x['eof'],'prospective_ranges':ranges,'purpose':'Additional actual write and request-validation call path; no ordered-role credit.'})
(b/'extra-registration.json').write_text(json.dumps({'schema':'726-look-producer-extra-registration-v1','author':'/root/rig_identity','registered_utc':datetime.now(timezone.utc).isoformat(),'entries':rows,'qualification':'Prospective after earlier navigational filenames/line numbers and before these source displays. Unshown ranges remain unread.'},indent=2)+'\n');print(json.dumps(rows,indent=2))
