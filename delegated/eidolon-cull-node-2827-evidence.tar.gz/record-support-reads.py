from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;names=['support-registration.json','support-registration-2.json'];spec={'native-plugin':([[1,62]],[]),'native-paged':([[1,40],[107,125]],[[41,106],[126,309]]),'native-backend':([[1,30]],[[31,71]]),'native-resource':([[32,47],[112,122],[167,182]],[[1,31],[48,111],[123,166]]),'native-runner':([[108,118]],[[1,107]]),'old-grass':([[120,155]],[[1,119],[156,623]]),'old-view':([[110,167]],[[1,109]]),'old-understory':([[46,65],[106,125],[220,300]],[[1,45],[66,105],[126,219],[301,322]])};entries=[];registrations=[]
for n in names:
 raw=(b/n).read_bytes();reg=json.loads(raw);registrations.append({'path':n,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for x in reg['entries']:
  chunks,unread=spec[x['id']];entries.append({'registration':n,'id':x['id'],'sha256':x['sha256'],'actual_display_chunks':chunks,'unread_complement':unread,'qualification':'Separate bounded Rust source support only; prior role and author credit unchanged, no WGSL body or execution.'})
out={'schema':'726-native-cull-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':registrations,'entries':entries};(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('recorded support',len(entries))
