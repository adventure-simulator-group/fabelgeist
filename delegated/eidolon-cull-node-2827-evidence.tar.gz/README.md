# Native Eidolon cull node role 2827

`REPORT.json` records the bounded source audit, thirteen lens perspectives, the
existing F053 dispatch-count relationship, prior allocator findings and open
reachability and policy questions. There is no new accepted unique count. This
assignment did not inspect WGSL bodies, execute GPU or native code, run product,
builds, tests, fixtures or probes, or edit the publication checkout.

Role 2827 is the separately identified native `bevy_eidolon` Git commit
`1a5aff8d4809287e5f5713fb4cf72181b2285fff`, not a project revision. The
historical 6533 root lock selects this version and commit; the four previously
enumerated tracked 95e lockfiles do not contain it. Those copied lock bodies and
their prior author's structural inventory remain distinct from personal source
displays, feature resolution and arbitrary external/untracked builds. 6533
pr-working state had unrelated modifications. f82 transports exact recovered
records and objects only. Current project source is pinned at 95e.

`registration.json`, `read-receipt.json`, `support-registration*.json`, and
`support-read-receipt.json` preserve exact personally displayed Rust ranges and
unread complements. Earlier 2790–2793 and 2794–2797 reports/manifests retain
their authors and read scopes. The peer's additive correction preserves the
separate native-prepare and native-inputs receipts and does not alter either
frozen prior packet. Full earlier evidence packets and the original native Git
bundle are hash-linked at their documented published locations.

`history/` retains exact recovered registry and extraction manifest, 059
records, losslessly compressed historical 059 queue/ledger, 774 records, and
prior report references. The selected camera registration row matches its
registry embedded record, but its whole-file SHA differs from the f82 version;
the original variant and cause remain unknown. Reconstructed selections are
labeled, and nothing is promoted to the unavailable checkpoint 3821.

`git-proofs.json` and `git-objects/` preserve independently verified native,
project and transport commit/tree evidence, the eight lock identities and one
current-tree path absence. Run `python3 verify-evidence.py` and
`python3 verify-manifest.py` to check evidence integrity only; they do not
resolve runtime behavior or execute product code.
