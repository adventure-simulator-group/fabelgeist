from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;raw=(b/'registration.json').read_bytes();r=json.loads(raw);x=r['entries'][0];out={'schema':'726-native-cull-personal-read-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(raw).hexdigest(),'entries':[{'id':x['id'],'sha256':x['sha256'],'actual_display_chunks':[[1,60],[61,119]],'unread_complement':[],'qualification':'Personal Rust source display at native 1a5 only; no WGSL or GPU execution.'}]};(b/'read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('recorded')
