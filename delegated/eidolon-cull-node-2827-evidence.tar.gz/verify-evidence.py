from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json');names=['registration.json','support-registration.json','support-registration-2.json'];groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert len(sel['rows'])==1 and sel['rows'][0]['original_index']==2827 and {k:v for k,v in sel['rows'][0].items() if k!='original_index'}==registry['files'][2827]
for x in sel['snapshots']:assert x in registry['snapshots']
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
x=regs[('registration.json','2827-native')];assert x['sha256']==registry['files'][2827]['sha256'] and x['prospective_personal_read_ranges']==registry['files'][2827]['material_ranges']==[[1,119]] and x['native_revision']=='1a5aff8d4809287e5f5713fb4cf72181b2285fff'
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in sel['entries']]==[1313,1314,1315]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
e=next(x for x in load('history/059/segovb/READ-L11-459.json')['sources'] if x['original_index']==2827);assert e['fresh_personal_body_reads']==e['assessed_ranges']==[[1,119]] and e['sha256']==registry['files'][2827]['sha256']
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
e=registry['files'][2827]['scope_registration'][0];p='history/774/'+e['record'].removeprefix('continuation/')+'.gz';raw=gun(p);rows=[json.loads(z) for z in raw.splitlines()];m=history['registration_file_hash_mismatch'];assert sha(raw)==m['f82_whole_file_sha256']!=e['sha256']==m['registry_recorded_whole_file_sha256'] and rows[e['row_1based']-1]==e['original_record']
root=[json.loads(z) for z in gun('history/774/root/initial04-invariant-operations/findings.jsonl.gz').splitlines()];f=next(x for x in root if x.get('id')=='ROOT-INITIAL04-F053');assert f['locations']==[[89,107]] and f['source_id']==registry['files'][2827]['source_id']
camera='history/774/camera/initial07-redundant-authority/';c=[json.loads(z) for z in gun(camera+'contracts.jsonl.gz').splitlines()];assert any(x.get('id')=='CAMERA-INITIAL07-CONTRACT-219' for x in c);quals=[json.loads(z) for z in gun(camera+'qualifications.jsonl.gz').splitlines()];assert any(x.get('id')=='CAMERA-INITIAL07-QUAL169' for x in quals)
for p in history['prior_reports_manifests']:
 for name in [p['report_name'],p['manifest_name']]:
  x=p[name];raw=(b/x['preserved']).read_bytes();assert sha(raw)==x['sha256'] and len(raw)==x['bytes']
 manifest=json.loads((b/p[p['manifest_name']]['preserved']).read_bytes());entry=next(x for x in manifest['files'] if x['path']==p['report_name']);assert entry['sha256']==p[p['report_name']]['sha256']
correction=load('history/prior-prepare-read-correction.json');assert correction['author']=='/root/mhr_character' and 'native-inputs' in correction['correction'] and '106–226' in correction['correction']
for x in history['copied_prior_lock_evidence']:
 raw=(b/x['preserved']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
lreg=load('lock-registration.json');inv=load('lock-inventory.json');assert inv['registration_sha256']==sha((b/'lock-registration.json').read_bytes()) and datetime.fromisoformat(lreg['at_utc'])<datetime.fromisoformat(inv['at_utc']) and len(lreg['entries'])==len(inv['entries'])==8
for x,y in zip(lreg['entries'],inv['entries']):
 raw=(b/x['archive']).read_bytes();assert x['id']==y['id'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']==y['sha256'] and oid('blob',raw)==x['git_blob'];doc=tomllib.loads(raw.decode());packages=doc.get('package',[]);matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in packages if p['name']=='bevy_eidolon'];consumers=[p['name'] for p in packages if any(a.split(' ',1)[0]=='bevy_eidolon' for a in p.get('dependencies',[]))];assert len(packages)==y['package_count'] and matches==y['matches'] and consumers==y['consumer_names']
 if x['revision'].startswith('95e'):assert matches==[]
old=next(x for x in inv['entries'] if x['id']=='6533e44:Cargo.lock');assert old['matches']==[{'name':'bevy_eidolon','version':'0.5.0','source':'git+https://github.com/barsoosayque/bevy_eidolon?branch=fablegeist-0.19#1a5aff8d4809287e5f5713fb4cf72181b2285fff','checksum':None}]
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
assert proof['commits']['1a5aff8d4809287e5f5713fb4cf72181b2285fff']['namespace']=='native Git' and proof['commits']['95e63628f9d70b8dd6e6fede64334696c6995009']['namespace']=='project Git'
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
for x in proof['absent_paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');chain=x['path_chain_to_parent']
 for name,s in zip(parts,chain):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 assert x['parent_tree']==cur and parts[len(chain)]==x['missing_segment'] and x['missing_segment'] not in entries(objects[cur])
assert len(proof['paths'])==26 and len(proof['absent_paths'])==1
coverage={}
def record(regname,id,chunks,unread,when,recorded_sha):
 x=regs[(regname,id)];assert datetime.fromisoformat(groups[regname]['at_utc'])<datetime.fromisoformat(when) and recorded_sha==x['sha256'];actual={i for a,z in chunks for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in unread for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage.setdefault(id,set()).update(actual)
a=load('read-receipt.json');assert a['registration_sha256']==sha((b/'registration.json').read_bytes())
for e in a['entries']:record('registration.json',e['id'],e['actual_display_chunks'],e['unread_complement'],a['at_utc'],e['sha256'])
s=load('support-read-receipt.json')
for x in s['registrations']:assert x['sha256']==sha((b/x['path']).read_bytes())
for e in s['entries']:record(e['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
assert len(regs)==len(coverage)==9
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(e['id']==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','original_native_role':2827,'personal_scopes':len(regs),'059_records_manifest_matched':len(history['records_059']),'774_records_git_proved':len(history['records_774']),'historic_registration_whole_file_mismatch':'preserved; selected row matches','git_paths_proved':len(proof['paths']),'git_tree_absences_proved':len(proof['absent_paths']),'prior_reports_manifest_hashes_linked':len(history['prior_reports_manifests']),'prior_read_correction_preserved':True,'locks_structurally_verified':8,'bounded_lenses':13,'feature_resolution':'not inferred','wgsl_gpu_build_test_fixture_product_execution_probe_validation':'not performed'},indent=2))
