from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;project='<LOCAL_PATH_0>';native='<LOCAL_PATH_1>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();g=lambda repo,*a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[];absences=[]
def save(repo,t,k):
 if k not in objects:
  raw=g(repo,'cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(repo,rev):
 if rev not in commits:
  c=save(repo,'commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev,'namespace':'native Git' if repo==native else 'project Git'}
 return commits[rev]['root_tree']
def proof(repo,rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(repo,rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save(repo,'tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
def absence(repo,rev,path):
 cur=root(repo,rev);chain=[]
 for seg in path.split('/'):
  es=entries(save(repo,'tree',cur))
  if seg not in es:
   absences.append({'revision':rev,'path':path,'path_chain_to_parent':chain,'parent_tree':cur,'missing_segment':seg,'qualification':'Exact committed path absence only; no resolution/runtime claim.'});return
  mode,child=es[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 raise ValueError('path present')
nr='1a5aff8d4809287e5f5713fb4cf72181b2285fff';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';cur='95e63628f9d70b8dd6e6fede64334696c6995009';x=json.loads((b/'registration.json').read_bytes())['entries'][0];proof(native,nr,x['native_git_path'],x['archive'],'native assigned original role');proof(project,f82,x['transport_path'],x['archive'],'f82 historical source object, not source revision')
for name in ['support-registration.json','support-registration-2.json']:
 for x in json.loads((b/name).read_bytes())['entries']:proof(native if x['kind']=='native' else project,x['revision'],x['git_path'],x['archive'],'independent bounded Rust support')
for x in json.loads((b/'lock-registration.json').read_bytes())['entries']:proof(project,x['revision'],x['git_path'],x['archive'],'prior author structural TOML inventory, not personal full-body display')
for path in ['AGENTS.md','crates/AGENTS.md']:
 dest='rules/'+path.replace('/','-');(b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(g(project,'show',cur+':'+path));proof(project,cur,path,dest,'applicable project guide')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(project,x['revision'],x['transport_path'],x['preserved'],'original historical 774 review record transported by f82')
absence(project,cur,'crates/adventuresim-tactical-client/src/presentation/ground_scatter/instanced_grass/view_culling.rs')
out={'schema':'726-native-eidolon-cull-node-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'absent_paths':absences,'qualification':'Native 1a5 package and 6533/95e project commits are separate; f82 is evidence transport. Per-file/tree proof does not establish whole snapshot cleanliness, feature selection or GPU/runtime result.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('git paths',len(proofs),'objects',len(objects),'absences',len(absences))
