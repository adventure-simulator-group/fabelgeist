from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();git=lambda *args:subprocess.check_output(['git','-C',repo,*args]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();cur=root(rev);chain=[]
 for part in path.split('/'):
  mode,child=entries(save('tree',cur))[part];chain.append({'tree':cur,'name':part,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
reg=json.loads((b/'registration.json').read_text());rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for row in reg['roles']:
 proof(rev,row['transport_path'],row['source_archive'],'content-addressed 774 historical source object transport, not package/project revision')
 proof(rev,'handoff/774/adler-original/audit/continuation/camera/admission03/dependency-snapshots/spacetimedb-bindings-macro-2.6.1/'+('lib.rs' if row['original_index']==2561 else 'sats.rs'),row['source_archive'],'original camera dependency snapshot path transport, not package/project revision')
for rev,l in reg['locks'].items():proof(rev,'Cargo.lock',l['archive'],'project lock per pinned revision; source package bytes remain external')
for row in json.loads((b/'project-support-registration.json').read_text())['sources']:proof(row['revision'],row['path'],row['source_archive'],'bounded current support; no prior reviewer credit')
for row in json.loads((b/'original-attribution.json').read_text())['older_774_receipts']:proof(row['transport_revision'],row['transport_path'],row['preserved_bytes'],'original camera/authority historical records transported by f82')
res={'schema':'726-pinned-macro-git-proof-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Raw commit/tree chains prove exact Git membership. f82 transports historical records and package snapshots; no claim f82 is a package or product revision. Archive member and lock checksum bindings are separately verified.'};(b/'git-proofs.json').write_text(json.dumps(res,indent=2)+'\n');print('proofs',len(proofs),'trees/commits',len(objects))
