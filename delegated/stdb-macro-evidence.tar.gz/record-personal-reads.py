from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'registration.json').read_text());out=[]
for row in r['roles']:
 out.append({'source':row['source_archive'],'package':row['package'],'version':row['version'],'sha256':row['sha256'],'actual_EOF':row['actual_EOF'],'registration':'registration.json','registered_ranges':row['registered_personal_display_ranges'],'displayed_chunks':row['planned_chunks'],'unread_complement':[],'role_credit':'Personal package source review for this bounded task; original supplier ranges preserved separately.'})
for file,items in [('support-registration.json',['sources','locks']),('project-support-registration.json',['sources']),('namespace-support-registration.json',['sources','locks']),('sats-root-support-registration.json',['source']),('endian-support-registration.json',['sources'])]:
 d=json.loads((p/file).read_text())
 for item in items:
  values=d[item] if isinstance(d[item],list) else [d[item]]
  for x in values:
   out.append({'source':x.get('source_archive'),'revision':x.get('revision'),'package':x.get('package'),'sha256':x.get('sha256'),'registration':file,'displayed_chunks':x['registered_ranges'],'role_credit':'Support only; no ordered role or earlier reviewer credit.'})
for rev,x in r['locks'].items():out.append({'source':x['archive'],'revision':rev,'sha256':x['sha256'],'registration':'registration.json','displayed_chunks':x['registered_ranges'],'role_credit':'Lock package clause support only.'})
doc=json.loads((p/'rustdoc-support-registration.json').read_text())['reconstructed_text'];out.append({'source':doc['source_archive'],'sha256':doc['sha256'],'registration':'rustdoc-support-registration.json','displayed_chunks':doc['registered_ranges'],'role_credit':'Document support only, mechanically extracted from preserved Rust standard library HTML.'})
receipt={'schema':'726-personal-read-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','registration_sha256':sha((p/'registration.json').read_bytes()),'read_entries':out,'qualification':'All displays occurred after their registrations and were returned untruncated. Archived entire support bodies do not imply reading other lines. Prior reviewers retain their dates, revisions and scopes. Source and evidence only; no macro, build, tests, probes, execution or product validation.'};(p/'personal-read-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',sha((p/'personal-read-receipt.json').read_bytes()),'entries',len(out))
