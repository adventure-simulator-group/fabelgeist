from pathlib import Path
from html.parser import HTMLParser
import datetime,hashlib,json
p=Path(__file__).resolve().parent;origin=Path('<LOCAL_PATH_0>');raw=origin.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
class P(HTMLParser):
 def __init__(self):super().__init__();self.t=[]
 def handle_data(self,d):
  if d.strip():self.t.append(' '.join(d.split()))
x=P();x.feed(raw.decode());(p/'support/rust-std-ptr-read.html').write_bytes(raw);(p/'support/rust-std-ptr-read-extracted.txt').write_text('\n'.join(x.t)+'\n');d={'schema':'726-rustdoc-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','html':{'origin':str(origin),'source_archive':'support/rust-std-ptr-read.html','sha256':sha(raw),'bytes':len(raw),'documentation_url':'https://doc.rust-lang.org/std/ptr/fn.read.html'},'reconstructed_text':{'source_archive':'support/rust-std-ptr-read-extracted.txt','sha256':sha((p/'support/rust-std-ptr-read-extracted.txt').read_bytes()),'segments':len(x.t),'registered_ranges':[[34,54]],'qualification':'Mechanical HTML text-node extraction; source HTML retained, not a Rust project source role.'}};(p/'rustdoc-support-registration.json').write_text(json.dumps(d,indent=2)+'\n');print('registration',sha((p/'rustdoc-support-registration.json').read_bytes()),'html',sha(raw))
