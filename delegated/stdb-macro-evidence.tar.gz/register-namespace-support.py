from pathlib import Path
import datetime,hashlib,json,tarfile,tomllib
p=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');cache=Path('<LOCAL_PATH_1>');sha=lambda b:hashlib.sha256(b).hexdigest();(p/'archives').mkdir();rows=[];locks=[];archives=[]
for name,archive,files in [('spacetimedb-lib',cache/'spacetimedb-lib-2.6.1.crate',[('lib.rs',[[1,55]])]),('spacetimedb-sats',pub/'native-evidence/spacetimedb-sats-2.6.1/spacetimedb-sats-2.6.1.crate',[('typespace.rs',[[300,325]])])]:
 ab=archive.read_bytes(); h=sha(ab);localarchive=None
 if name=='spacetimedb-lib':localarchive='archives/spacetimedb-lib-2.6.1.crate';(p/localarchive).write_bytes(ab)
 archives.append({'package':name,'version':'2.6.1','sha256':h,'bytes':len(ab),'original_path':str(archive),'preserved_bytes':localarchive})
 with tarfile.open(archive,'r:gz') as t:
  for path,ranges in files:
   member=f'{name}-2.6.1/src/{path}';b=t.extractfile(member).read();f='support/'+name+'__'+path;(p/f).write_bytes(b);rows.append({'package':name,'version':'2.6.1','archive_member':member,'source_archive':f,'sha256':sha(b),'bytes':len(b),'actual_EOF':len(b.splitlines()),'registered_ranges':ranges,'purpose':'conditional project namespace support, no feature or runtime inference'})
 for short,rev in [('6533','6533e444fa37552927070cc8d8190907fd3b413e'),('95e6','95e63628f9d70b8dd6e6fede64334696c6995009')]:
  f=p/'lock'/f'{short}-Cargo.lock';b=f.read_bytes();pk=[x for x in tomllib.loads(b.decode())['package'] if x['name']==name];assert len(pk)==1 and pk[0]['version']=='2.6.1' and pk[0]['checksum']==h;lines=b.decode().splitlines();idx=lines.index('name = "'+name+'"');end=next((i for i in range(idx+1,len(lines)) if lines[i]=='[[package]]'),len(lines));locks.append({'revision':rev,'source_archive':str(f.relative_to(p)),'package':name,'sha256':sha(b),'registered_ranges':[[idx,end]]})
r={'schema':'726-macro-namespace-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','archives':archives,'sources':rows,'locks':locks,'qualification':'Native reexport and package checksum proof only; feature selection, generated expansion and actual ingress remain separate.'};(p/'namespace-support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((p/'namespace-support-registration.json').read_bytes()));print('sources',[(x['source_archive'],x['registered_ranges'],x['sha256']) for x in rows]);print('locks',[(x['package'],x['revision'][:4],x['registered_ranges']) for x in locks])
