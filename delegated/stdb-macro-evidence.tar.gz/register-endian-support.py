from pathlib import Path
import datetime,hashlib,json,tarfile
p=Path(__file__).resolve().parent;arch=Path('<LOCAL_PATH_0>');sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
with tarfile.open(arch,'r:gz') as t:
 for rel,local,ranges in [('buffer.rs','support/buffer.rs',[[75,145]]),('bsatn/ser.rs','support/bsatn__ser.rs',[[50,95]])]:
  member='spacetimedb-sats-2.6.1/src/'+rel;b=t.extractfile(member).read();f=p/local
  if f.exists():assert f.read_bytes()==b
  else:f.write_bytes(b)
  rows.append({'package':'spacetimedb-sats','version':'2.6.1','archive_member':member,'source_archive':local,'sha256':sha(b),'bytes':len(b),'actual_EOF':len(b.splitlines()),'registered_ranges':ranges})
r={'schema':'726-macro-endian-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','archive_sha256':sha(arch.read_bytes()),'sources':rows,'qualification':'Check little-endian boundary versus native-memory fast path as conditional source question only; no platform/runtime use.'};(p/'endian-support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((p/'endian-support-registration.json').read_bytes()),[(r['source_archive'],r['registered_ranges']) for r in rows])
