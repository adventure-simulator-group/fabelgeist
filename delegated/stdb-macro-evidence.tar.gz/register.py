from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,tarfile,tomllib
p=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
arch=pub/'recovered/l2-native-registration-evidence/archives/spacetimedb-bindings-macro-2.6.1.crate'
regpath=pub/'recovered/original-registry-source-archive/registry.json.gz'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-C',str(pub),*a])
(p/'source').mkdir(); (p/'lock').mkdir()
archive=arch.read_bytes();checksum=sha(archive)
assert checksum=='fce86c7657dcb42a33ce55f0100f98964dc15b64e79f06803a478676b74d6c82'
registry=json.loads(gzip.decompress(regpath.read_bytes()))
locks={}
for rev in ['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']:
 b=git('show',rev+':Cargo.lock'); pkg=[x for x in tomllib.loads(b.decode())['package'] if x['name']=='spacetimedb-bindings-macro'];assert len(pkg)==1 and pkg[0]['version']=='2.6.1' and pkg[0]['checksum']==checksum
 lines=b.decode().splitlines(); idx=lines.index('name = "spacetimedb-bindings-macro"'); end=next((i for i in range(idx+1,len(lines)) if lines[i]=='[[package]]'),len(lines)); local='lock/'+rev[:4]+'-Cargo.lock'; (p/local).write_bytes(b)
 locks[rev]={'archive':local,'sha256':sha(b),'git_blob':git('rev-parse',rev+':Cargo.lock').decode().strip(),'package':pkg[0],'registered_ranges':[[idx, end]],'actual_EOF':len(lines)}
roles=[]
with tarfile.open(arch,'r:gz') as t:
 pkg=tomllib.loads(t.extractfile('spacetimedb-bindings-macro-2.6.1/Cargo.toml').read().decode())['package']; assert pkg['name']=='spacetimedb-bindings-macro' and pkg['version']=='2.6.1'
 for idx,rel in [(2561,'lib.rs'),(2562,'sats.rs')]:
  row=registry['files'][idx]; member='spacetimedb-bindings-macro-2.6.1/src/'+rel; b=t.extractfile(member).read();h=sha(b); assert row['sha256']==h and row['bytes']==len(b) and row['actual_line_count']==len(b.splitlines()); historical=git('show','f82adcabd9d89c4fa2dd7f99253a45297a0681ee:handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+h); assert historical==b
  local='source/'+str(idx)+'.rs';(p/local).write_bytes(b)
  roles.append({'original_index':idx,'source_id':row['source_id'],'package':'spacetimedb-bindings-macro','version':'2.6.1','archive_member':member,'source_archive':local,'sha256':h,'bytes':len(b),'actual_EOF':len(b.splitlines()),'historical_material_ranges':row['material_ranges'],'registered_personal_display_ranges':[[1,len(b.splitlines())]],'planned_chunks':[[i,min(i+119,len(b.splitlines()))] for i in range(1,len(b.splitlines())+1,120)],'transport_revision':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','transport_path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+h})
d={'schema':'726-delegate-pinned-macro-prospective-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','authority':'bounded personal source review, source/evidence inspection only','package_archive':{'path':str(arch),'sha256':checksum,'bytes':len(archive),'note':'Hash-linked already-published crate archive; source-member, Cargo lock and f82 object identity are independently compared, but this is no product Git revision.'},'roles':roles,'locks':locks,'qualification':'Full-body personal reading is newly assessed source; original camera supplier scopes and later reviewers retain their exact ranges and dates. Package identity, current lock presence and package name do not establish macro activation, callsite, feature path or runtime behavior. Original ranges are not checkpoint 3821 evidence.','prohibited':'No macro execution, compilation, product builds, tests, fixtures, runtime probes, implementation, source/publication edits.'}
(p/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
print('registration',sha((p/'registration.json').read_bytes()))
print('roles',[(x['original_index'],x['actual_EOF'],x['sha256']) for x in roles])
print('locks',[(r,v['sha256'],v['git_blob'],v['registered_ranges']) for r,v in locks.items()])
