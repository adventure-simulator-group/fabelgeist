from pathlib import Path
from datetime import datetime,timezone
from html.parser import HTMLParser
import gzip,hashlib,json,sys,tarfile,tomllib
b=Path(__file__).resolve().parent;args=[x for x in sys.argv[1:] if x!='--record'];pub=Path(args[0]) if args else Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();refs=json.loads((b/'published-references.json').read_bytes());published={}
for e in refs['entries']:
 path=(pub/e['path']) if 'path' in e else (b/e['preserved_bytes']);raw=path.read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'],str(path);published[e.get('path',e.get('external_path'))]=path
prior=json.loads((b/'prior-delegate/sdk-noiz-sats-hair-ops/packet-manifest.json').read_bytes());entries={x['path']:x for x in prior['files']};r=(b/'prior-delegate/sdk-noiz-sats-hair-ops/report.json').read_bytes();assert sha(r)==entries['report.json']['sha256'] and len(r)==entries['report.json']['bytes']
reg=json.loads((b/'registration.json').read_bytes());receipt=json.loads((b/'personal-read-receipt.json').read_bytes());rsource=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));transport=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));tidx={x['path']:x for x in transport['entries']};report=json.loads((b/'REPORT.json').read_bytes());original=json.loads((b/'original-attribution.json').read_bytes());assert not original['missing_originals'];archives={'spacetimedb-bindings-macro':pub/'recovered/l2-native-registration-evidence/archives/spacetimedb-bindings-macro-2.6.1.crate','spacetimedb-sats':pub/'native-evidence/spacetimedb-sats-2.6.1/spacetimedb-sats-2.6.1.crate','spacetimedb-lib':b/'archives/spacetimedb-lib-2.6.1.crate'};checksums={k:sha(v.read_bytes()) for k,v in archives.items()};assert checksums['spacetimedb-bindings-macro']==reg['package_archive']['sha256']
assert [x['original_index'] for x in reg['roles']]==[2561,2562]
def package_source(x):
 raw=(b/x['source_archive']).read_bytes();assert sha(raw)==x['sha256'] and len(raw)==x['bytes'] and len(raw.splitlines())==x['actual_EOF'];a=archives[x['package']]
 with tarfile.open(a,'r:gz') as t:assert t.extractfile(x['archive_member']).read()==raw
for x in reg['roles']:
 package_source(x);old=rsource['files'][x['original_index']];assert x['source_id']==old['source_id'] and x['sha256']==old['sha256'] and x['historical_material_ranges']==old['material_ranges'] and x['actual_EOF']==old['actual_line_count']
 assert x['registered_personal_display_ranges']==[[1,x['actual_EOF']]]
for rev,l in reg['locks'].items():
 raw=(b/l['archive']).read_bytes();assert sha(raw)==l['sha256'] and oid('blob',raw)==l['git_blob'];pk={x['name']:x for x in tomllib.loads(raw.decode())['package'] if x['name'] in archives};assert len(pk)==3
 for name in archives:assert pk[name]['version']=='2.6.1' and pk[name]['source']=='registry+https://github.com/rust-lang/crates.io-index' and pk[name]['checksum']==checksums[name]
for path in ['support-registration.json','namespace-support-registration.json','endian-support-registration.json']:
 data=json.loads((b/path).read_bytes())
 for x in data['sources']:package_source(x)
package_source(json.loads((b/'sats-root-support-registration.json').read_bytes())['source'])
for x in json.loads((b/'project-support-registration.json').read_bytes())['sources']:
 raw=(b/x['source_archive']).read_bytes();assert sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob'] and len(raw.splitlines())==x['actual_EOF']
selection=json.loads((b/'registry-selection-reconstructed.json').read_bytes())
for x in selection['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==rsource['files'][x['original_index']]
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());qs=json.loads((b/'queue-selection-reconstructed.json').read_bytes());assert not qs['missing']
for x in qs['entries']:assert {k:v for k,v in x.items() if k!='original_queue_index'}==queue['entries'][x['original_queue_index']]
for x in original['original_059_records']:
 raw=(b/x['preserved_bytes']).read_bytes();t=tidx[x['original_path']];assert len(raw)==x['bytes']==t['bytes'] and sha(raw)==x['sha256']==t['sha256'] and oid('blob',raw)==x['git_blob']==t['git_blob']
for x in original['older_774_receipts']:
 raw=(b/x['preserved_bytes']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob']
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
proof=json.loads((b/'git-proofs.json').read_bytes());objects={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved_bytes']).read_bytes());assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==key;objects[key]=raw
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,step in zip(parts,x['path_chain']):
  assert step['tree']==cur and step['name']==name;mode,child=entries(objects[cur])[name];assert mode==step['mode'] and child==step['object'];cur=child
 raw=(b/x['preserved_bytes']).read_bytes();assert oid('blob',raw)==cur==x['git_blob'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']
assert len(proof['paths'])==13
scopes={};regtime=[]
for row in receipt['read_entries']:
 local=row['source'];raw=(b/local).read_bytes();assert sha(raw)==row['sha256'];d=json.loads((b/row['registration']).read_bytes());regtime.append(datetime.fromisoformat(d['registered_utc']));eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in row['displayed_chunks']);displayed={i for a,z in row['displayed_chunks'] for i in range(a,z+1)};scopes.setdefault(local,set()).update(displayed)
 def registered_ranges(obj):
  result=[]
  if isinstance(obj,dict):
   if local in (obj.get('source_archive'),obj.get('archive')):
    for key in ('registered_ranges','registered_personal_display_ranges'):
     if key in obj:result.extend(obj[key])
   for v in obj.values():result.extend(registered_ranges(v))
  elif isinstance(obj,list):
   for v in obj:result.extend(registered_ranges(v))
  return result
 allowed={i for a,z in registered_ranges(d) for i in range(a,z+1)};assert displayed<=allowed,(row['registration'],local,row['displayed_chunks'])
 if local.startswith('source/'):
  source=next(x for x in reg['roles'] if x['source_archive']==local);assert row['displayed_chunks']==source['planned_chunks'] and row['unread_complement']==[] and scopes[local]==set(range(1,eof+1))
assert max(regtime)<datetime.fromisoformat(receipt['recorded_utc']) and receipt['registration_sha256']==sha((b/'registration.json').read_bytes())
for x in report['findings']:
 for e in x['evidence']:
  assert e['file'] in scopes
  for a,z in e['lines']:assert set(range(a,z+1))<=scopes[e['file']],(e['file'],a,z)
names=['magic-strings','magic-numbers','type-ownership','existing-type-owners','type-granularity','invariant-operations','aggregate-states','admission-contracts','enum-shapes','redundant-authority','behavior-preservation','producer-propagation','derivability'];assert [x['lens'] for x in report['lenses']]==names
class P(HTMLParser):
 def __init__(self):super().__init__();self.t=[]
 def handle_data(self,d):
  if d.strip():self.t.append(' '.join(d.split()))
rust=json.loads((b/'rustdoc-support-registration.json').read_bytes());raw=(b/rust['html']['source_archive']).read_bytes();assert sha(raw)==rust['html']['sha256'];x=P();x.feed(raw.decode());assert ('\n'.join(x.t)+'\n').encode()==(b/rust['reconstructed_text']['source_archive']).read_bytes()
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Both original package roles match archive members, 059 registry and camera/f82 transported snapshots; crate checksum matches each 6533 and 95e lock.','Native SATS and lib package support match their locked archive checksums and exact source members.','Raw Git commit/tree chains prove lock, 95e support and f82 historical transports; f82 is not project/package source revision.','Original 059 evidence matches transport manifest; 774 records match f82 trees; selected 059 registry and queue are labelled reconstructions.','Both full assigned source read receipts and explicitly bounded support citations match registrations; thirteen bounded lens perspectives present.','Rust standard pointer documentation text is a mechanical extraction of preserved HTML; prior delegate report matches its manifest.'],'scope':'Evidence checks and source scope only; no product, macro, test, build, runtime probe, fixture, repair or product validation.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw) if '--record' in sys.argv else None;print('PASS',sha(raw),'Git proofs',len(proof['paths']),'original 059 records',len(original['original_059_records']),'read entries',len(receipt['read_entries']))
