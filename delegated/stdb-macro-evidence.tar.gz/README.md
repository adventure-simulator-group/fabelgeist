# Bounded pinned-registry macro audit

This packet records a source-only audit of original registry roles 2561–2562,
`spacetimedb-bindings-macro` 2.6.1 `src/lib.rs` and `src/sats.rs`. Their
package/archive identity is distinct from project Git revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. `REPORT.json` states the
conditional findings, thirteen scoped perspectives, relationships, open
questions, and authorship. `registration.json` and
`personal-read-receipt.json` define the actual personal source scopes.

The 774 camera and 059 reviewer records are original historical evidence;
`registry-selection-reconstructed.json` and
`queue-selection-reconstructed.json` are explicitly reconstructed selections.
No record is promoted to checkpoint 3821. `git-proofs.json` preserves raw
commit/tree path chains, including the f82 evidence transport rather than a
claim that f82 is the project or package revision.

`published-references.json` hash-links the existing publication's complete
macro and SATS package archives, historical registry/manifest, queue/ledger,
and a prior current source assessment. The third native archive (lib 2.6.1),
source bodies, two lockfiles, relevant historical evidence and selected prior
report/manifest are preserved here. Verify the packet from this directory:

```text
python3 verify-manifest.py
python3 verify-evidence.py /path/to/audit-baseline/publication
```

Checks cover evidence identity, bounded scopes and ancestry only. No macro
expansion, compilation, product build, test, fixture, runtime probe, product
validation, implementation or repair was performed.
