from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;p=b/'sources/2601-historical.rs';raw=p.read_bytes();x={'schema':'726-pow10-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','sources':[{'archive':'sources/2601-historical.rs','identity':'serde_json 1.0.151 src/de.rs','sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'eof':len(raw.splitlines()),'registered_ranges':[[1300,1340]],'planned_chunks':[[1300,1340]],'purpose':'Bounded native power table provenance, no parser execution.'}]};(b/'pow10-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(hashlib.sha256((b/'pow10-registration.json').read_bytes()).hexdigest())
