from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();spec=[('sources/2601-historical.rs','serde_json 1.0.151 src/de.rs',[[20,106],[2640,2714]]),('support/native-0.rs','serde 1.0.229 src/private/de.rs',[[1090,1119]]),('support/current-7.source','95e crates/adventuresim-tactical-client/src/browser_runtime.rs',[[100,125],[245,265]])];out=[]
for name,identity,ranges in spec:
 raw=(b/name).read_bytes();assert all(z<=len(raw.splitlines()) for a,z in ranges);out.append({'archive':name,'identity':identity,'sha256':sha(raw),'bytes':len(raw),'eof':len(raw.splitlines()),'registered_ranges':ranges,'planned_chunks':ranges,'purpose':'Bounded streaming initialization, Content map dispatch or browser f32 consumer; no product or macro execution.'})
x={'schema':'726-serde-tagged-extra-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','sources':out,'qualification':'Additional bounded registered support, outside role2601 original material; no independent runtime, feature activation or product credit.'};(b/'extra-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('extra',sha((b/'extra-registration.json').read_bytes()))
