from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256((b/p).read_bytes()).hexdigest();names=['registration.json','support-registration.json','browser-registration.json','native-support-registration.json','native-support2-registration.json','extra-registration.json','extra2-registration.json','core-f32-registration.json','historical-browser-registration.json','lexical-registration.json','pow10-registration.json']
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if (i>n or i in used) and a is not None:out.append([a,i-1]);a=None
 return out
reg=json.loads((b/names[0]).read_bytes());roles=[]
for e in reg['roles']:
 chunks=e['planned_chunks'];rs=e['registered_ranges'];roles.append({'role':e['role'],'identity':e['identity'],'revision':e['revision'],'path':e['path'],'archive':e['archive'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_chunks':chunks,'actual_display_ranges':rs,'unread_complement':complement(e['eof'],rs),'original_material_ranges':e['original_material_ranges'],'qualification':'Personally displayed actual registered source body, no uninspected range, source equality or another reviewer credit transfer.'})
support=[]
for name in names[1:]:
 for e in json.loads((b/name).read_bytes())['sources']:
  rs=[[1,83]] if name=='lexical-registration.json' else ([[1,106]] if name=='native-support-registration.json' and e['archive']=='support/native-1.rs' else e['registered_ranges']);chunks=rs if name=='lexical-registration.json' or (name=='native-support-registration.json' and e['archive']=='support/native-1.rs') else e['planned_chunks'];support.append({'registration':name,'identity':e.get('identity',e.get('revision',e.get('package'))),'path':e.get('path'),'archive':e['archive'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_chunks':chunks,'actual_display_ranges':rs,'unread_complement_for_registration':complement(e['eof'],rs),'qualification':'Separately registered support; complements are registration-specific and may be covered elsewhere. Lexical requested 1–125 overran EOF83; additive lexical-eof-qualification records actual1–83 and nonexistent84–125.' if name=='lexical-registration.json' else 'Separately registered support; derive request 1–110 overran EOF106 and first receipt incorrectly included nonexistent107–110; additive derive-eof-qualification preserves both and corrects the actual display.' if name=='native-support-registration.json' and e['archive']=='support/native-1.rs' else 'Separately registered support; complements here are registration-specific and may be covered by other registrations.'})
x={'schema':'726-serde-tree-growth-personal-read-receipt-v1','reader':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registrations':[{'path':n,'sha256':sha(n)} for n in names],'assigned_personal_reads':roles,'support_personal_reads':support,'qualification':'Corrected receipt: the initial erroneous receipt is separately retained and the derive EOF correction is additive. All registration records precede displayed ranges. Search singletons are navigation only; exact records and truncation qualifier separately retained. Support may include test source text but none executed. Serde macro source read without expansion.'};(b/'personal-read-receipt.json').write_text(json.dumps(x,indent=2)+'\n');print('assigned',len(roles),'support',len(support))
