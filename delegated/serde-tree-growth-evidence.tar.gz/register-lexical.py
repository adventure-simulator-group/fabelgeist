from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,tarfile
b=Path(__file__).resolve().parent;crate=(b/'metadata/serde_json-1.0.151.crate').read_bytes();path='src/lexical/parse.rs';
with tarfile.open(fileobj=io.BytesIO(crate),mode='r:gz') as t:raw=t.extractfile('serde_json-1.0.151/'+path).read()
(b/'support/native-lexical.rs').write_bytes(raw);ranges=[[1,125]];x={'schema':'726-serde-json-lexical-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','sources':[{'package':'serde_json','version':'1.0.151','path':path,'archive':'support/native-lexical.rs','sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'eof':len(raw.splitlines()),'registered_ranges':ranges,'planned_chunks':ranges,'crate_archive':'metadata/serde_json-1.0.151.crate','crate_sha256':hashlib.sha256(crate).hexdigest(),'purpose':'Bounded float_roundtrip concise parser implementation, no parsing or numeric execution.'}]};(b/'lexical-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(hashlib.sha256((b/'lexical-registration.json').read_bytes()).hexdigest())
