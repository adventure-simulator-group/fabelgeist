from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();spec=[('sources/2601-historical.rs','serde_json 1.0.151 src/de.rs',[[2500,2535]]),('support/native-0.rs','serde 1.0.229 src/private/de.rs',[[1145,1170]])];out=[]
for name,identity,ranges in spec:
 raw=(b/name).read_bytes();out.append({'archive':name,'identity':identity,'sha256':sha(raw),'bytes':len(raw),'eof':len(raw.splitlines()),'registered_ranges':ranges,'planned_chunks':ranges,'purpose':'Native from_trait and owned content map dispatch; evidence-only source reading.'})
x={'schema':'726-serde-tagged-extra2-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','sources':out,'qualification':'Separate bounded native support beyond original 2601 material; no runtime, macro or feature activation assertion.'};(b/'extra2-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(sha((b/'extra2-registration.json').read_bytes()))
