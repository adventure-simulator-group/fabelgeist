from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,tomllib,sys
b=Path(__file__).resolve().parent
pub=Path(sys.argv[1]) if len(sys.argv)>1 and not sys.argv[1].startswith('--') else Path('<LOCAL_PATH_0>')
sha=lambda x:hashlib.sha256(x).hexdigest()
oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def load(p): return json.loads(Path(p).read_bytes())
def gun(p): return gzip.decompress(Path(p).read_bytes())
links=load(b/'evidence-links.json')
for x in links['published']:
 raw=(pub/x['path']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],x['path']
for pp in links['prior_packets']:
 for x in pp['records']:
  raw=Path(x['path']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],x['path']
reg=json.loads(gun(pub/'recovered/original-registry-source-archive/registry.json.gz')); rr=load(b/'registry-selection-reconstructed.json');
for x in rr['rows']:
 idx=x['original_index'];assert {k:v for k,v in x.items() if k!='original_index'}==reg['files'][idx],idx
for x in rr['snapshots']: assert x in reg['snapshots']
pr=next(x for x in reg['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4 and not any('growth_axes.rs' in x for x in pr['status_porcelain'])
p16=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
queue=load(pub/'baseline-059/queue.json')['entries'];qq=load(b/'queue-selection-reconstructed.json')['entries'];assert [x['original_index_zero_based'] for x in qq]==[50,77,80,2484]
for x in qq: assert x['entry']==queue[x['original_index_zero_based']]
at=load(b/'historical-attribution.json'); assert not at['missing'];transport=json.loads(gun(pub/'recovered/original-transport-manifest.json.gz'));ix={e['path']:e for e in transport['entries']}
for x in at['059']:
 raw=(b/x['preserved_bytes']).read_bytes();e=ix[x['original_path']];assert sha(raw)==x['sha256']==e['sha256'] and len(raw)==x['bytes']==e['bytes'] and oid('blob',raw)==x['git_blob']==e['git_blob'],x['original_path']
for x in at['774_compressed']:
 raw=gun(b/x['preserved_gzip']);assert sha(raw)==x['sha256'] and len(raw)==x['bytes'] and oid('blob',raw)==x['git_blob'];assert json.loads(raw.splitlines()[24])['id']=='RIG-ADMISSION03-F025'
originalrange=next(Path(x['path']) for p in links['prior_packets'] for x in p['records'] if x['path'].endswith('/source-range-registration.jsonl'))
origrows=[json.loads(l) for l in originalrange.read_bytes().splitlines()]
for row in rr['rows']:
 for x in row['admission03_scope_observations']: assert origrows[x['row_1based']-1]==x['original_record']
for filename,wanted in [('contract-groups.jsonl.gz',['RIG-ADMISSION03-CONTRACT-409']),('additional-contracts.jsonl.gz',['RIG-ADMISSION03-ADDITIONAL-042','RIG-ADMISSION03-ADDITIONAL-044'])]:
 path=next(Path(x['path']) for p in links['prior_packets'] for x in p['records'] if x['path'].endswith('/'+filename));records=[json.loads(s) for s in gun(path).splitlines()];ids={r['id'] for r in records};assert set(wanted)<=ids
proof=load(b/'git-proofs.json');objects={}
for key,x in proof['objects'].items():
 raw=gun(b/x['preserved_bytes']);assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==key;objects[key]=raw
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
for x in proof['paths']:
 curr=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,step in zip(parts,x['path_chain']):
  assert step['tree']==curr and step['name']==name;mode,child=entries(objects[curr])[name];assert (mode,child)==(step['mode'],step['object']);curr=child
 path=b/x['preserved_bytes'];raw=gun(path) if str(path).endswith('.gz') else path.read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob']==curr,x['path']
assign=load(b/'registration.json');receipt=load(b/'personal-read-receipt.json');assert len(assign['roles'])==len(receipt['assigned_personal_reads'])==3
for x in assign['roles']:
 raw=(b/x['archive']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and len(raw.splitlines())==x['eof']
 if x['original_material_ranges'] is not None: assert x['sha256']==reg['files'][x['role']]['sha256'] and x['original_material_ranges']==reg['files'][x['role']]['material_ranges']
assert assign['roles'][1]['sha256']!=assign['roles'][2]['sha256']
package_paths={
 'serde_json-1.0.151':b/'metadata/serde_json-1.0.151.crate',
 'serde-1.0.229':b/'metadata/serde-1.0.229.crate',
 'serde_derive-1.0.229':b/'metadata/serde_derive-1.0.229.crate',
 'serde_core-1.0.229':Path('<LOCAL_PATH_1>')}
expected={'serde_json-1.0.151':'c841b55ecdae098c80dcae9cf767f6f8a0c2cdb3416bbef72181df4d0fe73f14','serde-1.0.229':'4148590afebada386688f18773da617792bf2ef03ffc1e4cbd2b1d45b023e0ba','serde_derive-1.0.229':'e7a5d71263a5a7d47b41f6b3f06ba276f10cc18b0931f1799f710578e2309348','serde_core-1.0.229':'67dca2c9c51e58a4791a4b1ed58308b39c64224d349a935ab5039aa360942a48'}
for k,v in package_paths.items():assert sha(v.read_bytes())==expected[k]
package_members=[('serde_json-1.0.151','src/de.rs','sources/2601-historical.rs'),('serde_json-1.0.151','src/lexical/parse.rs','support/native-lexical.rs'),('serde-1.0.229','src/private/de.rs','support/native-0.rs'),('serde_derive-1.0.229','src/de/enum_internally.rs','support/native-1.rs'),('serde_derive-1.0.229','src/de/struct_.rs','support/native2-1.rs'),('serde_core-1.0.229','src/de/mod.rs','support/native2-0.rs'),('serde_core-1.0.229','src/de/impls.rs','support/native3-core.rs')]
for pkg,member,archive in package_members:
 with tarfile.open(package_paths[pkg],'r:gz') as t: assert t.extractfile(pkg+'/'+member).read()==(b/archive).read_bytes(),member
for lock in [b/'metadata/pr-base-Cargo.lock.gz',b/'metadata/current-Cargo.lock.gz',Path(assign['p16_dirty_lock_reference']['path'])]:
 raw=gun(lock);data=tomllib.loads(raw.decode());packages={x['name']+'-'+x['version']:x for x in data['package'] if x['name'] in ['serde','serde_core','serde_derive','serde_json']}
 for pkg,cs in expected.items():assert packages[pkg]['checksum']==cs,(lock,pkg)
assert sha(gun(assign['p16_dirty_lock_reference']['path']))==assign['p16_dirty_lock_reference']['uncompressed_sha256']
for r in receipt['registrations']:
 raw=(b/r['path']).read_bytes();assert sha(raw)==r['sha256'];assert datetime.fromisoformat(json.loads(raw)['registered_utc'])<datetime.fromisoformat(receipt['recorded_utc'])
for row in receipt['assigned_personal_reads']+receipt['support_personal_reads']:
 raw=(b/row['archive']).read_bytes();assert sha(raw)==row['sha256'] and len(raw.splitlines())==row['eof']
 if row in receipt['assigned_personal_reads']:
  match=[x for x in assign['roles'] if x['role']==row['role'] and x['revision']==row['revision']];assert len(match)==1;rs=match[0];assert row['actual_display_ranges']==rs['registered_ranges'] and row['actual_display_chunks']==rs['planned_chunks']
 else:
  o=load(b/row['registration']);match=[x for x in o['sources'] if x['archive']==row['archive']];assert len(match)==1;rs=match[0]
  if row['registration']=='lexical-registration.json':assert rs['registered_ranges']==[[1,125]] and row['actual_display_ranges']==[[1,83]] and row['actual_display_chunks']==[[1,83]]
  elif row['registration']=='native-support-registration.json' and row['archive']=='support/native-1.rs': assert rs['registered_ranges']==[[1,110]] and row['actual_display_ranges']==[[1,106]] and row['actual_display_chunks']==[[1,106]]
  else:assert row['actual_display_ranges']==rs['registered_ranges'] and row['actual_display_chunks']==rs['planned_chunks']
 actual={i for a,z in row['actual_display_ranges'] for i in range(a,z+1)};chunks={i for a,z in row['actual_display_chunks'] for i in range(a,z+1)}; assert actual==chunks and all(1<=i<=row['eof'] for i in actual)
 unread=row.get('unread_complement',row.get('unread_complement_for_registration')); assert unread is not None
 other={i for a,z in unread for i in range(a,z+1)};assert actual.isdisjoint(other) and actual|other==set(range(1,row['eof']+1))
qual=load(b/'lexical-eof-qualification.json');assert qual['actual_eof']==83 and qual['existing_displayed_range']==[1,83] and qual['nonexistent_requested_range']==[84,125] and sha((b/qual['registration']).read_bytes())==qual['registration_sha256']
derive=load(b/'derive-eof-qualification.json'); assert derive['actual_eof']==106 and derive['actual_displayed_range']==[1,106] and derive['nonexistent_requested_range']==[107,110] and sha((b/derive['prospective_registration']).read_bytes())==derive['prospective_registration_sha256'] and sha((b/derive['initial_receipt']).read_bytes())==derive['initial_receipt_sha256']; initial=load(b/derive['initial_receipt']); assert next(x for x in initial['support_personal_reads'] if x['archive']=='support/native-1.rs' and x['registration']=='native-support-registration.json')['actual_display_ranges']==[[1,110]]
nav=load(b/'navigation-exposures.json')
for x in nav['entries']:assert sha((b/x['path']).read_bytes())==x['sha256']
# A mechanical byte-search supports a negative observation, not a contiguous personal-read credit.
assert b'__deserialize_content_v1' not in (b/'sources/2601-historical.rs').read_bytes()
report=load(b/'REPORT.json');assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
scopes={}
for x in receipt['assigned_personal_reads']+receipt['support_personal_reads']:
 scopes.setdefault((x['archive'],x['sha256']),set()).update(i for a,z in x['actual_display_ranges'] for i in range(a,z+1))
def visit(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x and 'sha256' in x:
   a,z=x['lines'];assert set(range(a,z+1))<=scopes[(x['archive'],x['sha256'])],x
  for y in x.values():visit(y)
 elif isinstance(x,list):
  for y in x:visit(y)
visit(report)
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','checks':['Hash-linked original registry, queue, transport, P16 recovery and prior packets','Exact 059 source bytes, original 774 registry rows/F025/linked contracts, reconstructed selections and original attribution','Raw Git commit/tree path chains and complete source blobs for assigned and project support identities','Exact package archives and native source members bound to 6533, 95e and later recovered dirty P16 lock records; no feature graph claimed','Prospective registrations, personal read partitions, both additive EOF qualifications, preserved initial receipt, bounded source citations and thirteen perspectives','Mechanical source-byte search, not personal full-file inspection'], 'counts':{'git_paths':len(proof['paths']),'original_059_records':len(at['059']),'assigned_read_entries':len(receipt['assigned_personal_reads']),'support_read_entries':len(receipt['support_personal_reads'])},'scope':'Evidence and source verification only; no product validation, tests, macro execution, fixtures or runtime probes.'}
raw=(json.dumps(result,indent=2)+'\n').encode()
if '--record' in sys.argv:(b/'evidence-verification.json').write_bytes(raw)
print('PASS',sha(raw),result['counts'])
