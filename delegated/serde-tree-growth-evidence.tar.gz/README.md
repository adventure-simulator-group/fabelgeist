# Bounded source evidence: roles 2601 and 2602

`REPORT.json` contains this reviewer’s thirteen bounded perspectives, current
source observations, open questions and historical relationships. It is a
source-only assessment for central reconciliation; it is not a completed
repository-wide lens, implementation, or product validation.

- Role 2601 is the pinned `serde_json` 1.0.151 package source, not a project
  Git revision. Its exact original material ranges and separately registered
  support reads are in `personal-read-receipt.json`.
- Role 2602 is a historical per-file pr-working object matching 6533 and a
  separately read current 95e object. The historical whole snapshot had four
  unrelated modified paths. The objects, raw Git path proofs, Cargo archives
  and exact record bytes are retained here.
- Original 059 and older 774 records retain their original readers and source
  revisions. Registry and queue selections are explicitly reconstructed;
  hash-linked full originals remain distinct. The later P16 dirty-patch
  recovery and its custody limits are recorded in the report and references.
- Two requests ran beyond file EOF. `lexical-eof-qualification.json` retains
  the request for lines 1–125 and credits only actual 1–83. The derive support
  request for lines 1–110 actually displayed 1–106; its initial receipt
  mistakenly claimed lines 107–110. The original receipt is retained as
  `personal-read-receipt-initial.json`, the correction as
  `derive-eof-qualification.json`, and the final receipt credits only lines
  that exist. Neither correction changes the prospective registration.

`evidence-links.json` hash-links the published registry, transport manifest,
queue, ledger, later P16 recovery, current assessments and four prior packets.
Those external records are required for complete independent verification;
retain them or provide hash-identical published references before relying on a
copy of this compact packet. In particular, the linked earlier package includes
the `serde_core` archive and recovered P16 lock; another contains exact 774
range and contract records. Previous delegate reads remain credited to their
own authors.

For evidence-only verification, run `python3 verify-evidence.py` after making
its linked published and prior-packet files available. `MANIFEST.json` covers
packet files; `python3 verify-manifest.py` checks that inventory. These scripts
parse and hash evidence only. They do not run or validate product code.
