import gzip,hashlib,json,pathlib
src=pathlib.Path('<LOCAL_PATH_0>');pub=pathlib.Path('<LOCAL_PATH_1>');out=pathlib.Path('<LOCAL_PATH_2>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f: entries={e['path']:e for e in json.load(f)['entries']}
paths=['adler/READ-L11-378.json','adler/STATE-L11-378.json','adler/VERIFY-L11-378.json','adler/REGISTRATION-ADLER-1221.json','adler/REGISTRATION-ADLER-1222.json','adler/REGISTRATION-ADLER-1223.json','adler/REGISTRATION-ADLER-1226.json','adler/READ-L11-385.json','adler/REGISTRATION-ADLER-1246.json','parallel-l12-20261029/PROPOSAL-L12-777.json','parallel-l12-20261029/PROPOSAL-L12-778.json','parallel-l12-20261029/PROPOSAL-L12-779.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-777-LOCATION-DECLARATIONS.json','parallel-l12-20261029/REGISTRATION-PAR-L12-323.json','parallel-l12-20261029/REGISTRATION-PAR-L12-324.json','parallel-l12-20261029/REGISTRATION-PAR-L12-325-CONNECTED-LOCATION-PATTERNS.json','parallel-l12-20261029/REGISTRATION-PAR-L12-326.json','parallel-l12-20261029/REGISTRATION-PAR-L12-331.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-774-778.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-779-781.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-769-779-AUDIT-ONLY-HEADERS.json']
for i in [777,778,779]:
 paths.extend([f'segovb/READ-L12-{i}.json',f'segovb/REGISTRATION-SEGOVB-L12-{i}.json',f'segovb/VERIFY-L12-{i}.json'])
rows=[];missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file():missing.append(path);continue
 b=(src/path).read_bytes();e=entries[path];h=hashlib.sha256(b).hexdigest();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),path
 dst=out/'historical'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
 rows.append({'original_transport_path':path,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+path})
o={'schema':'delegated-recovered-historical-evidence-v1','qualification':'Exact copies from read-only original extraction independently checked against original transport SHA-256, length and Git blob; each retains its original revision, reviewer, range and unresolved status. Not checkpoint3821 or current personal reads. Public release may require nonessential local-path redaction.','records':rows,'unavailable':missing}
(out/'historical-manifest.json').write_text(json.dumps(o,indent=2)+'\n');print('verified',len(rows),'missing',missing,'manifest',hashlib.sha256((out/'historical-manifest.json').read_bytes()).hexdigest())
