import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>'); rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=['crates/adventuresim-core/src/organization.rs','crates/adventuresim-core/src/physiology.rs','crates/adventuresim-stdb-module/src/disease.rs','crates/adventuresim-stdb-client/src/backend_physiology_administration_type.rs','crates/strategic-web/src/spacetimedb/types.rs','crates/strategic-web/static/strategic-navigation.js','crates/strategic-web/src/templates/architecture.rs','crates/strategic-web/src/templates/settlement/social.rs'];rows=[]
for path in paths:
 b=subprocess.run(['git','show',rev+':'+path],stdout=subprocess.PIPE,check=True).stdout
 rows.append({'path':path,'range':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
o={'schema':'delegated-audit-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','revision':rev,'purpose':'Bounded exact source connections for settlement service production, administration dose backend admission, strategic navigation consumer; actual personally displayed ranges separately recorded, no ordered-role credit.','registered_sources':rows}
(p/'support-registration-02.json').write_text(json.dumps(o,indent=2)+'\n');print('registered',o['registered_utc'],'sha256',hashlib.sha256((p/'support-registration-02.json').read_bytes()).hexdigest())
