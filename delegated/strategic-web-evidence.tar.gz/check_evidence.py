import gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(rev,path):return subprocess.run(['git','-C',repo,'show',rev+':'+path],stdout=subprocess.PIPE,check=True).stdout
r=json.loads((p/'registration.json').read_text());current='95e63628f9d70b8dd6e6fede64334696c6995009';old='6533e444fa37552927070cc8d8190907fd3b413e'
for x in r['ordered_roles']:
 b=(p/'source'/pathlib.Path(x['path']).name).read_bytes()
 for v in x['versions']:
  assert v['present'] and (len(b),len(b.splitlines()),sha(b),blob(b))==(v['bytes'],v['lines'][1],v['sha256'],v['git_blob'])
  assert b==git(v['revision'],x['path']),x['path']
count=0
report=json.loads((p/'report.json').read_text())
assert report['registration']['sha256']==sha((p/'registration.json').read_bytes())
for d in report['support']:
 path=d['registration'];assert sha((p/path).read_bytes())==d['sha256'];reg=json.loads((p/path).read_text())
 for x in reg['registered_sources']:
  b=(p/'source'/('support-'+x['path'].replace('/','__'))).read_bytes()
  assert (len(b),len(b.splitlines()),sha(b),blob(b))==(x['bytes'],x['range'][1],x['sha256'],x['git_blob']),x['path']
  assert b==git(current,x['path']),x['path']
  assert all(1<=a<=z<=x['range'][1] for a,z in d['actual_personal_ranges'][x['path']]);count+=1
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:transport={x['path']:x for x in json.load(f)['entries']}
h=json.loads((p/'historical-manifest.json').read_text());assert not h['unavailable']
for x in h['records']:
 b=(p/x['copy_path']).read_bytes();e=transport[x['original_transport_path']]
 assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
assert report['historical_manifest']['sha256']==sha((p/'historical-manifest.json').read_bytes())
ref=json.loads((p/'reference/manifest.json').read_text())
for x in ref['records']:
 b=(p/x['copy']).read_bytes()
 if 'compressed_sha256' in x:
  assert (len(b),sha(b))==(x['compressed_bytes'],x['compressed_sha256']);raw=gzip.decompress(b)
  assert (len(raw),sha(raw))==(x['original_bytes'],x['original_sha256']);q=json.loads(raw)
  for i,id in [(178,'ADLER-L11-STRATEGIC-FRAGMENT-READ-FAILURE'),(193,'ADLER-L11-MEDICAL-HISTORY-AVAILABILITY'),(454,'SEGOVB-L12-CONNECTED-LOCATION-SERVICE-ADMISSION'),(456,'SEGOVB-L12-STRATEGIC-FRAGMENT-BODY-CAUSE-ERASURE'),(459,'SEGOVB-L12-CONNECTED-MEDICAL-BACKEND-DOSE-ADMISSION')]:assert q['entries'][i]['contract_id']==id
 else:assert (len(b),sha(b))==(x['bytes'],x['sha256'])
assert report['reference_archives']['sha256']==sha((p/'reference/manifest.json').read_bytes())
print('Evidence integrity passed:',len(r['ordered_roles']),'identical historical/current source objects,',count,'registered current support objects,',len(h['records']),'transport-verified historical records, 059 queue and reference archives, registrations and current rules.')
print('Only Git object reads, evidence hashing and JSON/gzip parsing; no product execution, test, browser, simulated fixture or build.')
