import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/strategic-web/src/templates/settlement/trade/merchant.rs','crates/strategic-web/src/templates/settlement/trade/repairs.rs','crates/strategic-web/static/strategic-mutations.js'];rows=[]
for path in paths:
 b=subprocess.run(['git','show',rev+':'+path],stdout=subprocess.PIPE,check=True).stdout
 rows.append({'path':path,'range':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
o={'schema':'delegated-audit-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','revision':rev,'purpose':'Trace exact merchant/repair service producers and negotiated mutation consumer as bounded support only; no browser, execution or ordered-role credit.','registered_sources':rows}
(p/'support-registration-04.json').write_text(json.dumps(o,indent=2)+'\n');print('registered',o['registered_utc'],'sha256',hashlib.sha256((p/'support-registration-04.json').read_bytes()).hexdigest());print('\n'.join(f"{x['path']} {x['range'][1]}" for x in rows))
