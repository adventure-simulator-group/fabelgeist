import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>')
current='95e63628f9d70b8dd6e6fede64334696c6995009';old='6533e444fa37552927070cc8d8190907fd3b413e'
paths=['crates/strategic-web/src/location_urls.rs','crates/strategic-web/src/main.rs','crates/strategic-web/src/medical.rs'];rows=[]
for index,path in zip(range(2355,2358),paths):
 versions=[]
 for r in [old,current]:
  q=subprocess.run(['git','show',r+':'+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if q.returncode: versions.append({'revision':r,'present':False});continue
  b=q.stdout; versions.append({'revision':r,'present':True,'lines':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 rows.append({'original_index':index,'path':path,'versions':versions})
o={'schema':'delegated-audit-prospective-source-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Prospective full-body read of original roles 2355–2357 at frozen 6533 and authoritative 95e; compare exact object identity. No whole-lens, queue or historical checkpoint transfer.','ordered_roles':rows,'scope_policy':'Register each separately reached supporting source before displaying any body. Same-byte historical source proves only bytes, not unchanged downstream semantics. Retain historic reviewer scopes and qualifications.','constraint':'No product edits, repairs, builds, tests, browser, runtime probes, simulated fixtures or shader execution.'}
(p/'registration.json').write_text(json.dumps(o,indent=2)+'\n');print('registered',o['registered_utc'],'sha256',hashlib.sha256((p/'registration.json').read_bytes()).hexdigest())
