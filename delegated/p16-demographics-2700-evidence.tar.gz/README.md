# Physical P16 demographics role 2700

This source-only packet is authored by `/root/hair_ops` for central audit
reconciliation. Start with `REPORT.json`, `read-receipt.json`, registrations,
and `historical-manifest.json`. The original archived P16 and 95e source
bodies were separately displayed. The a120 and 039 comparisons prove per-file
byte identity only and were not separately displayed. P16 itself is the
recorded dirty a120-based state, not a clean commit.

`recovered/physical-p16-patch-recovery/tracked.patch` is the later independently
reproduced tracked stream with the registry-recorded SHA-256. The seven
untracked files are separately in the recovered original source archive; the
patch does not include them. Earlier qualified recovery records and the
reconstructed redacted comparison remain separately attributed. The original
archive, 059 queue/ledger and historical reviewer records retain their own
revisions, scopes and authors. The local selections file is reconstructed.
The 938/TEAM025 Lens12 records are later proposals, not an invented 3821 or
assumed root adoption.

`git-proofs.json` and `git-objects/` preserve offline commit/tree/blob membership
proofs for project bodies and historical transport. `native/` contains the
checksum-bound strum_macros 0.28.0 registry crate and selected source members;
this native package is distinct from project Git and from the earlier 0.27.2
scenario assessment. `MANIFEST.json` hashes every packet file except itself,
including the nested recovered manifest.

Run `python3 verify-evidence.py` for offline evidence-integrity checking only.
No product code, macro, fixture or test is executed by that verifier. This
packet covers thirteen bounded perspectives, not whole-lens clearance. No
implementation, build, product/test execution, runtime probe, rendering or
publication edit was performed.
