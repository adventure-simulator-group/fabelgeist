from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['Cargo.toml','Cargo.lock','crates/adventuresim-world-schema/Cargo.toml'];entries=[];pending=[]
for path in paths:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;n=len(raw.splitlines());local='support/'+path;entries.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':n,'local':local,'planned_display_ranges':[[1,n]]});pending.append((local,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective pinned dependency provenance; actual windows recorded separately. Earlier unregistered working-checkout Cargo.lock navigation displayed lines10151–10180; that checkout may differ from pinned current and does not count as a pinned body read.','entries':entries};(b/'dependencies-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('sha256',hashlib.sha256((b/'dependencies-registration.json').read_bytes()).hexdigest())
