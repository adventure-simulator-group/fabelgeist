'''Offline evidence-integrity verification only; no product or tests.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile,tomllib
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['original_registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files'];assert original[2700]==sel['registry_rows']['2700'];assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id']=='physical-p16']
snapshot=sel['snapshot_rows'][0];patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['recovered_patch']['bytes']==len(patch) and recovery['live_comparison']['status_counts']['??']==7
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows'];x=reg['rows'][0];old=x['versions'][0];body=(b/old['local']).read_bytes()
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:assert t.extractfile(old['sha256']).read()==body
assert h(body)==old['sha256']==original[2700]['sha256'] and catalog[2700]['expected_sha256']==h(body);cmp=load('historical-comparison-039-registration.json');assert catalog[2700]['origin']=='git:'+cmp['revision']+':'+x['path'] and (b/cmp['local']).read_bytes()==body and cmp['equals_registry_object'];base=x['historical_a120_per_file'];assert (b/base['local']).read_bytes()==body and base['equals_physical_p16_object'] and base['display_planned']==False;assert (b/x['versions'][1]['local']).read_bytes()==body
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def partition(n,ranges):
 nums=[i for a,z in ranges for i in range(a,z+1)];return len(nums)==n and set(nums)==set(range(1,n+1))
for r in reg['rows']:
 for v in r['versions']:
  p=next(x for x in rec['assigned'] if x['original_index']==r['original_index'] and x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'];assert partition(v['eof'],p['displayed']+p['unread_complement']) and p['unread_complement']==[]
planned={}
for n in ['support-registration.json','consumers-registration.json','dependencies-registration.json']:
 for x in load(n)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];assert partition(x['eof'],x['displayed']+x['unread_complement']);assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
native=load('native-registration.json');arch=(b/native['archive']['local']).read_bytes();assert h(arch)==native['archive']['sha256']=='ab85eea0270ee17587ed4156089e10b9e6880ee688791d45a905f5b1ca36f664';lock=tomllib.loads((b/'support/Cargo.lock').read_text());pk=next(x for x in lock['package'] if x['name']=='strum_macros' and x['version']=='0.28.0');assert pk['checksum']==h(arch);world=next(x for x in lock['package'] if x['name']=='adventuresim-world-schema');assert 'strum 0.28.0' in world['dependencies'];st=next(x for x in lock['package'] if x['name']=='strum' and x['version']=='0.28.0');assert 'strum_macros 0.28.0' in st['dependencies']
with tarfile.open(b/native['archive']['local'],'r:gz') as t:
 for e in native['entries']:
  raw=(b/e['local']).read_bytes();assert t.extractfile(e['archive_member']).read()==raw and h(raw)==e['sha256'];x=next(x for x in rec['native_support'] if x['local']==e['local']);assert x['sha256']==h(raw) and x['eof']==len(raw.splitlines()) and partition(x['eof'],x['displayed']+x['unread_complement'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
r774=[json.loads(s) for s in (b/'historical/774/source-range-registration.jsonl').read_text().splitlines()];q774=[json.loads(s) for s in (b/'historical/774/source-qualifications-final-current.jsonl').read_text().splitlines()]
for ob in original[2700]['admission03_scope_observations']:
 j=ob['row_1based']-1;assert r774[j]==ob['original_record'] and q774[j]==ob['local_qualifications'][0]
assert original[2700]['material_ranges']==[[1,41]]
l11=load('historical/059/segovb/READ-L11-440.json');rows=[x for x in l11['sources'] if x['original_index']==2700];assert [x['fresh_personal_body_reads'] for x in rows]==[[[1,41]],[[42,43]]]
for x in rows:assert h((b/'historical/059/segovb'/Path(x['registration']).name).read_bytes())==x['registration_sha256']
pre=load('historical/059/segovb/READ-L11-571.json');x=next(x for x in pre['rows'] if x.get('registration')=='PL11-0351');assert x['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and x['fresh_personal_body_ranges']==[] and x['qualified_same_lens_reuse_ranges']==[[42,43]]
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-938.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False;x=next(x for x in p['rows'] if x['original_index']==2700);assert x['fresh_personal_body_reads']==[[1,41]] and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256'];q=x['identity_specific_windows_qualification'];assert h((b/'historical/059'/q['path']).read_bytes())==q['sha256']
for x in p['partial_read_receipts']:assert h((b/'historical/059'/x['path']).read_bytes())==x['sha256']
p=load('historical/059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-TEAM025-SOURCE-AND-CANONICAL-QUALIFICATION.json');x=p['rows'][0];assert x['original_index']==2700 and x['fresh_personal_body_reads']==[[42,43]] and '/root/lens12_frontier' in x['attribution'] and p['authoritative_ledger_written']==False;assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: original dirty-P16 role2700 and 95e separately displayed, a120/039 per-file comparisons, later exact tracked patch and untracked qualification, original 774/059 plus unadopted 938/TEAM025 scopes, %d Git proofs, %d bounded project supports, %d checksum-bound native sources and thirteen partial perspectives. Evidence integrity only; no product, builds, tests, fixtures, macro execution or probes.'%(len(proof['proofs']),len(rec['support']),len(rec['native_support'])))
