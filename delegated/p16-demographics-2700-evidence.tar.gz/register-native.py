from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile
b=Path(__file__).resolve().parent;root=Path('<LOCAL_PATH_0>');archive=root/'cache/index.crates.io-1949cf8c6b5b557f/strum_macros-0.28.0.crate';raw=archive.read_bytes();h=lambda x:hashlib.sha256(x).hexdigest();assert h(raw)=='ab85eea0270ee17587ed4156089e10b9e6880ee688791d45a905f5b1ca36f664';paths=['src/macros/enum_variant_array.rs','src/macros/strings/from_string.rs','src/macros/strings/as_ref_str.rs','src/helpers/variant_props.rs','src/helpers/type_props.rs','src/helpers/case_style.rs'];entries=[];pending=[]
with tarfile.open(archive,'r:gz') as t:
 for path in paths:
  member='strum_macros-0.28.0/'+path;body=t.extractfile(member).read();installed=(root/'src/index.crates.io-1949cf8c6b5b557f'/member).read_bytes();assert body==installed;n=len(body.splitlines());local='native/'+member;entries.append({'identity':'strum_macros 0.28.0 registry package source, not project Git','archive_member':member,'sha256':h(body),'bytes':len(body),'eof':n,'local':local,'planned_display_ranges':[[1,n]]});pending.append((local,body))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective native macro source support; no macro execution or role credit. Full selected source windows and unread complements recorded separately.','archive':{'origin':str(archive),'package':'strum_macros','version':'0.28.0','sha256':h(raw),'bytes':len(raw),'local':'native/strum_macros-0.28.0.crate','checksum_provenance':'95e Cargo.lock:10207–10211; world-schema Cargo.toml:18 and lock:530–540,10173–10180'},'entries':entries};(b/'native-registration.json').write_text(json.dumps(d,indent=2)+'\n');(b/d['archive']['local']).parent.mkdir(parents=True,exist_ok=True);(b/d['archive']['local']).write_bytes(raw)
for n,body in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
print(json.dumps(d,indent=2));print('sha256',h((b/'native-registration.json').read_bytes()))
