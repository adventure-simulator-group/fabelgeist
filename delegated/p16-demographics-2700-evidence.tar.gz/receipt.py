from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
r=load('registration.json');assigned=[]
for x in r['rows']:
 for v in x['versions']:
  assigned.append({'original_index':2700,'source_id':x['source_id'],'identity':v.get('identity','pinned current'),'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'displayed':[[1,v['eof']]],'unread_complement':[],'qualification':'Full archived object and current body separately displayed. Equal clean-base copy was not displayed separately.'})
windows={'crates/adventuresim-core/src/starting_character.rs':[[580,660]],'crates/adventuresim-core/src/settlement_population.rs':[[1,110],[180,310],[450,500]],'crates/adventuresim-core/src/courtship/child_identity.rs':[[1,97]],'crates/adventuresim-world-schema/src/name_catalog_validation.rs':[[220,290],[335,385]],'crates/adventuresim-stdb-module/src/settlement_population/resident_drafts.rs':[[1,110]],'crates/fabelgeist-determinism/src/stream.rs':[[1,169]],'crates/adventuresim-stdb-module/src/strategic/mission_bootstrap.rs':[[1490,1565]],'crates/adventuresim-stdb-module/src/strategic/dialogue_provenance.rs':[[1355,1395]],'Cargo.toml':[[1,211]],'Cargo.lock':[[525,545],[10150,10220]],'crates/adventuresim-world-schema/Cargo.toml':[[1,31]]};regs=[];supports=[]
for n in ['registration.json','support-registration.json','consumers-registration.json','dependencies-registration.json','native-registration.json','historical-comparison-039-registration.json']:
 d=load(n);regs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':d['created_utc']})
 if n in ['support-registration.json','consumers-registration.json','dependencies-registration.json']:
  for e in d['entries']:
   rs=windows[e['path']];supports.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'local':e['local'],'eof':e['eof'],'displayed':rs,'unread_complement':complement(e['eof'],rs),'ordered_role_credit':0})
native=[]
for e in load('native-registration.json')['entries']:
 native.append({'identity':e['identity'],'archive_member':e['archive_member'],'sha256':e['sha256'],'local':e['local'],'eof':e['eof'],'displayed':[[1,e['eof']]],'unread_complement':[],'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','basis':'Archived physical-p16 and pinned current assigned bodies personally displayed separately after prospective registration; all registered support windows after respective registration. Source tests and native macro text were inspected, never executed.','assigned':assigned,'support':supports,'native_support':native,'registrations':regs,'comparison_copies':'Direct clean a120 and older-catalogue 039 source comparisons archived and hash/Git-proved, not separately displayed; equal bytes do not imply separate a120 or 039 personal reading or clean entire P16 snapshot.','pre_registration_disclosure':'An unregistered working-checkout Cargo.lock navigation displayed selected lines10151–10180 before dependencies-registration. At the later hash check its full SHA-256 cb227fddbf85f10ea6d3bf929827ea395f240eae2d948a2c4c590ae526ba1f73 matched the pinned 95e Cargo.lock. This peek is disclosed and is not retroactively registered or used to claim ordered credit; independently registered pinned ranges were then personally displayed.','navigation':'Other initial source discovery used filenames only; after registration rg context displays are contained in the reported source windows. Earlier 774/059 authors retain their own scopes; no 3821 credit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
