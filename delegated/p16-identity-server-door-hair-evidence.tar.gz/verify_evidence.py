"""Check packet evidence only. Never executes product or linked historical scripts."""
import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());reg=load('registration.json');rr=load('read-receipt.json');sr=load('support-read-receipt.json');proof=load('git-proofs.json');hist=load('historical-manifest.json');report=load('report.json');registry=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()))
assert rr['prospective_registration_sha256']==sha((p/'registration.json').read_bytes());assert datetime.datetime.fromisoformat(reg['registered_utc'])<datetime.datetime.fromisoformat(rr['recorded_utc']);reads={}
def partition(eof,w,u):
 a=set();b=set()
 for lo,hi in w:assert 1<=lo<=hi<=eof;a.update(range(lo,hi+1))
 for lo,hi in u:assert 1<=lo<=hi<=eof;b.update(range(lo,hi+1))
 assert not a&b and a|b==set(range(1,eof+1));return a
proofkeys={(x['revision'],x['path'],x['archive']) for x in proof['proofs']}
for role,r in zip(reg['roles'],rr['roles']):
 idx=role['original_index'];assert idx==r['original_index'] and idx in (2528,2529)
 v=role['p16'];b=(p/v['local']).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']==registry['files'][idx]['sha256']==catalog['rows'][idx]['expected_sha256'] and blob(b)==v['git_blob'];assert not r['0393_a120_6533_personal_display_windows']
 reads[(v['archive_revision'],role['path'])]=partition(r['p16_eof'],r['p16_display_windows'],r['p16_unread_complement'])
 reads[(r['current_revision'],role['path'])]=partition(r['current_eof'],r['current_display_windows'],r['current_unread_complement'])
 assert (v['archive_revision'],v['archive_path'],v['local']) in proofkeys
 for s in role['versions']:
  q=(p/s['local']).read_bytes();assert s['present'] and s['equals_p16'] and q==b and sha(q)==s['sha256'] and blob(q)==s['git_blob'] and len(q)==s['bytes'];assert (s['revision'],role['path'],s['local']) in proofkeys
snap=next(x for x in registry['snapshots'] if x['id']=='physical-p16');assert snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snap['changed_variants']==159 and snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for f in sr['prospective_registrations']:
 assert sha((p/f['path']).read_bytes())==f['sha256'] and datetime.datetime.fromisoformat(load(f['path'])['registered_utc'])<datetime.datetime.fromisoformat(sr['recorded_utc'])
support=[s for f in sr['prospective_registrations'] for s in load(f['path'])['sources']];assert len(support)==len(sr['reads'])
for s,r in zip(support,sr['reads']):
 b=(p/s['local']).read_bytes();assert s['path']==r['path'] and s['index']==r['index'] and sha(b)==s['sha256']==r['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==r['eof'] and blob(b)==s['git_blob'];assert (s['revision'],s['git_path'],s['local']) in proofkeys;readset=partition(r['eof'],r['actual_display_windows'],r['unread_complement']);reads.setdefault((s['revision'],s['path']),set()).update(readset)
objs={}
for oid,o in proof['objects'].items():
 b=gzip.decompress((p/o['archive']).read_bytes());assert len(b)==o['bytes'] and sha(b)==o['sha256'] and hashlib.sha1(o['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
for q in proof['proofs']:
 assert objs[q['revision']].splitlines()[0].split()[1].decode()==q['commit_tree'];tree=q['commit_tree'];assert len(q['path'].split('/'))==len(q['chain'])
 for name,c in zip(q['path'].split('/'),q['chain']):
  assert c['tree']==tree and c['name']==name;mode,tree=entries(objs[tree])[name];assert mode==c['mode'] and tree==c['object']
 assert tree==q['blob']==blob((p/q['archive']).read_bytes())
for e in hist['records']:
 b=(p/e['copy']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
 if e['scope'] in ['059','774']:
  m=e['manifest_entry'];assert m['path']==e['origin'] and m['bytes']==len(b) and m['sha256']==sha(b)
 else:assert (e['revision'],e['origin'],e['copy']) in proofkeys
linked={}
for kind in ['manifest_reference_059','manifest_reference_774']:
 link=hist[kind];f=pathlib.Path(link['path']);linked[kind]=f.is_file()
 if f.is_file():
  z=f.read_bytes();assert sha(z)==link['sha256'];d=json.loads(gzip.decompress(z));key='entries' if kind.endswith('059') else 'files';scope='059' if kind.endswith('059') else '774'
  for e in [x for x in hist['records'] if x['scope']==scope]:assert next(x for x in d[key] if x['path']==e['origin'])==e['manifest_entry']
for q in hist['prior_packet_hash_links']:
 b=(p/q['report_copy']).read_bytes();assert sha(b)==q['report_sha256'];f=pathlib.Path(q['manifest_path']);linked[q['role']]=f.is_file()
 if f.is_file():
  z=f.read_bytes();assert sha(z)==q['manifest_sha256'];m=json.loads(z);assert next(x for x in m['files'] if x['path']=='report.json')['sha256']==q['report_sha256']
queue=load(hist['reconstructed_queue']);qf=pathlib.Path(queue['original_compressed_path']);linked['queue_059']=qf.is_file()
if qf.is_file():
 z=qf.read_bytes();assert sha(z)==queue['original_compressed_sha256'];d=json.loads(gzip.decompress(z));assert all(d['entries'][e['index']]==e['record'] for e in queue['rows'])
assert [(e['index'],e['record']['contract_id'],e['record']['status']) for e in queue['rows']]==[(1741,'Q-L12-41c24499aa29694a546d','open-evidence-or-disposition'),(2243,'L12-CLOSURE-SCENE-DOOR-PAIRED-POSE-AUTHORITY','open-granular-reconciliation')]
assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
refs=[]
def visit(x):
 if isinstance(x,dict):
  if {'revision','path','lines'}<=x.keys():refs.append(x)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
for r in refs:
 k=(r['revision'],r['path']);assert k in reads,k
 for lo,hi in r['lines']:assert all(i in reads[k] for i in range(lo,hi+1)),(k,lo,hi)
result={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'exact_p16_objects_and_four_revision_comparisons':len(reg['roles']),'recorded_dirty_snapshot_and_unrecovered_patch_qualification':True,'commit_tree_membership_proofs':len(proof['proofs']),'registered_support_read_partitions':len(support),'original_historical_and_publication_records':len(hist['records']),'source_references_within_personal_read_windows':len(refs),'bounded_lens_perspectives':len(report['lenses']),'historical_059_contracts_remain_open':True},'linked_previous_evidence_available_and_checked':linked,'qualification':'Evidence integrity and source-read receipt checks only. Reconstructed queue selections and manifest entry extracts retain hash links to complete original archives. Missing external links are disclosed, not claimed verified; no product, tests, builds, runtime probe or validation.'};(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
