# Bounded P16 building-identity and server-door evidence

This is /root/hair_ops's source-only review of original roles 2528 and 2529
against current revision `95e63628f9d70b8dd6e6fede64334696c6995009`. P16
identity 1–40 and doors 1–672 and their current counterparts were separately
personally displayed after registration. Test bodies were source text only.
Each exact P16 object individually equals its 0393, a120, 6533, and 95e
counterpart; those other copies were verified but not separately displayed.
This does not make the historical P16 snapshot clean: the registry records a
159-path dirty delta at a120, whose full patch remains unrecovered. f82 is an
archive transport revision, not the dirty snapshot head.

`report.json` records thirteen bounded perspectives, citations, conditions,
open questions, nonfindings, and historical authorship. The right-hinged gate
and actor-exemption expiry observations are reinspections of the existing
central gate-handedness assessment, with no additional count. The related 059
cleanup row has no source locator, so its theme is not treated as alias proof.
The separately registered server scene-setup support contains a production
`expect` contrary to the governing crate rule; no reachable panic is claimed.
A prior L1 identity record's empty current-read range and conflicting prose
about a current reread are both preserved without resolving the discrepancy.

`read-receipt.json` and `support-read-receipt.json` distinguish actual source
displays from archived bytes; `git-proofs.json` and `git-objects/` contain
commit/tree/blob membership evidence. Exact selected 059, 774 and prior
publication records are retained. Selected queue rows and original-manifest
entries are explicitly reconstructed, with hashes linking to complete original
archives. Previous full packets remain separately hash-linked and only their
compact reports are copied, preserving original authors and read scopes.

`verify_evidence.py` checks evidence, source-read partitions and available
hash-linked records; it does not execute product code. Re-running it changes
the timestamped verification output, so use a copy to preserve frozen bytes.
No product, server, viewer, builds, tests, runtime probes, simulations,
implementation, repair or source/publication edits occurred. Central
coordination owns ledger disposition, reconciliation and publication.
