from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
b=Path(__file__).resolve().parent
chunks={'sources/2708-pr_head.rs':[[1,44],[45,58]],'sources/2708-current.rs':[[1,44],[45,58]],'support/enclosure.source':[[1,45],[46,90],[210,263]],'support/foundations.source':[[1,57],[58,114],[115,171],[172,228]],'support/binding.source':[[1,45],[145,205]],'support/collision.source':[[1,62]],'support/batching.source':[[100,163]],'native/glam-vec3.rs':[[1419,1428],[1644,1660],[1787,1797],[2081,2088]],'support/position.source':[[1,55],[56,105]],'support/finite.source':[[1,28]],'support/frames.source':[[1,50]],'support/foundation-append.source':[[229,270]],'native/bevy-lib.rs':[[45,55]],'native/bevy-internal-lib.rs':[[56,72]],'native/bevy-math-lib.rs':[[95,103]],'native/bevy-math-Cargo.toml':[[115,125]]};rows=[]
for reg in ('registration.json','support-registration.json','numeric-registration.json','extra-registration.json','bevy-registration.json'):
 r=json.loads((b/reg).read_bytes())
 for e in r['entries']:
  c=chunks[e['archive']];actual={i for a,z in c for i in range(a,z+1)};planned={i for a,z in e['prospective_personal_read_ranges'] for i in range(a,z+1)};assert actual==planned;unread=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in actual and start is None:start=i
   if start is not None and (i>e['eof'] or i in actual):unread.append([start,i-1]);start=None
  rows.append({'registration':reg,'registration_sha256':hashlib.sha256((b/reg).read_bytes()).hexdigest(),'registration_at_utc':r['at_utc'],'archive':e['archive'],'revision':e['revision'],'git_path':e['git_path'],'package':e.get('package'),'sha256':e['sha256'],'eof':e['eof'],'actual_personal_display_chunks':c,'unread_complement':unread,'reader':'/root/rig_identity','qualification':'Displayed after listed prospective registration, source-only; full archived bytes and others read receipts grant no further credit.'})
out={'schema':'726-personal-source-read-receipt-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'recording timestamp is after displays, not individual display times; old/new body displays independent; extension45–58 is separate from older 774 original1–44'};(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('read scopes',len(rows))
