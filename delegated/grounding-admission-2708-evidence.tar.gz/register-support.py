from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[('enclosure','crates/adventuresim-tactical-core/src/city_layout/grounding/enclosure.rs',[[1,90],[210,263]]),('foundations','crates/adventuresim-tactical-core/src/city_layout/grounding/foundations.rs',[[1,228]]),('binding','crates/adventuresim-tactical-core/src/city_layout/grounding/enclosure/binding.rs',[[1,45],[145,205]]),('collision','crates/adventuresim-tactical-core/src/city_layout/grounding/collider.rs',[[1,62]]),('batching','crates/adventuresim-tactical-client/src/presentation/buildings/boundaries/batching.rs',[[100,163]])]
rows=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);n=len(raw.splitlines());assert all(1<=a<=z<=n for a,z in ranges),(name,n);dest=f'support/{name}.source';(b/dest).write_bytes(raw);rows.append({'name':name,'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'eof':n,'prospective_personal_read_ranges':ranges,'qualification':'current bounded support only; no historical role or earlier reviewer credit'})
out={'schema':'726-prospective-support-registration-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
