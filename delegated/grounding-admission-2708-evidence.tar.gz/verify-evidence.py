from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json');receipt=load('personal-read-receipt.json')
names=('registration.json','support-registration.json','numeric-registration.json','extra-registration.json','bevy-registration.json');groups={n:load(n) for n in names};allregs={(name,e['archive']):e for name,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('historical/registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('historical/transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[*range(2693,2700),2708]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4 and pr['patch_sha256']=='dba7a85bb2105ccdf0587c4713fdc2a33b374600457f5c05e9c5f29d087193b1'
for r in groups.values():
 for x in r['entries']:
  d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
  if 'git_blob' in x:assert oid('blob',d)==x['git_blob']
old,cur=groups['registration.json']['entries'];assert old['sha256']==cur['sha256']==registry['files'][2708]['sha256'] and old['eof']==cur['eof']==58 and old['inherited_original_material']==registry['files'][2708]['material_ranges']==[[1,44]] and old['later_059_registered_extension']==[[45,58]] and (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes()
queue=json.loads(gun('historical/baseline-059-queue.json.gz'))['entries'];q=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in q['entries']]==[102,1291,1491,1494,1496,1499,1509,2369,*range(2956,2968),3125]
for x in q['entries']:assert x['entry']==queue[x['original_index_zero_based']]
assert queue[102]['contract_id']=='ADLER-L11-FOUNDATION-VOLUME-ARITHMETIC' and queue[1491]['contract_id']=='Q-L12-ef88f4da1aba2ced6275'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
adler=load('historical/059/adler/READ-L11-271.json');entry=next(x for x in adler['connected_reinspection'] if x['original_index']==2708);assert entry['fresh_reads']==[[1,58]] and entry['additional_original_frontier_credit']==0
seg=load('historical/059/segovb/READ-L11-441.json');entry=next(x for x in seg['sources'] if x['original_index']==2708);assert entry['fresh_personal_body_reads']==[] and entry['same_lens_prior']['entry']['fresh_reads']==[[1,58]]
later=load('historical/059/segovb/READ-L11-569.json');entry=next(x for x in later['rows'] if x.get('path','').endswith('grounding/admission.rs'));assert entry['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and entry['fresh_personal_body_ranges']==[] and entry['qualified_same_lens_reuse_ranges']==[[1,58]]
for lens in (2,3):
 historic=load(f'historical/059/root-l{lens}-extension-20261030/READ-ROOT-L{lens}-EXT-'+('021-033.json' if lens==2 else '020-027.json'));entry=next(x for x in historic['rows'] if x.get('source_id','').endswith('grounding/admission.rs'));assert entry['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and entry['fresh_personal_ranges']==[[1,58]]
 later=load(f'historical/059/root-l{lens}-extension-20261030/READ-ROOT-L{lens}-CURRENT-'+('008.json' if lens==2 else '004.json'));entry=next(x for x in later['rows'] if x.get('source_id','').endswith('grounding/admission.rs'));assert entry['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and entry['fresh_personal_ranges']==[] and entry.get('qualified_same_lens_reuse_ranges',entry.get('qualified_reuse_ranges'))==[[1,58]]
seg=load('historical/059/segovb/READ-L11-440.json');entry=next(x for x in seg['sources'] if x['original_index']==2699);assert entry['fresh_personal_body_reads']==[] and entry['same_lens_prior']['entry']['fresh_reads']==[[1,56]]
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
regs=[json.loads(z) for z in gun('historical/774/rig/admission03/source-range-registration.jsonl.gz').splitlines()];norms={x['registration_id']:x for x in map(json.loads,gun('historical/774/rig/admission03/source-qualifications-final-current.jsonl.gz').splitlines())}
for x in registry['files'][2708]['admission03_scope_observations']:
 assert regs[x['row_1based']-1]==x['original_record']
 for y in x['local_qualifications']:assert norms[y['registration_id']]==y
records=[json.loads(z) for z in gun('historical/774/rig/admission03/root-support/additional-contracts.jsonl.gz').splitlines()];entry=next(x for x in records if x['id']=='RIG-ROOT-ADM03-ADDITIONAL-001');assert entry['actual_material_ranges']==[[1,44]] and entry['registered_ranges']==[[1,47]]
for x in history['prior_packets']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
  names={e.name for e in t.getmembers() if e.isfile()};raw=t.extractfile(x['manifest_name']).read();assert sha(raw)==x['manifest_sha256'];manifest=json.loads(raw);assert names=={e['path'] for e in manifest['files']}|{x['manifest_name']}
  for e in manifest['files']:
   raw=t.extractfile(e['path']).read();assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
  assert sha(t.extractfile(x['report_name']).read())==x['report_sha256']
num=groups['numeric-registration.json'];lockraw=gun(num['lock']['archive']);assert len(lockraw)==num['lock']['bytes'] and sha(lockraw)==num['lock']['sha256'] and oid('blob',lockraw)==num['lock']['git_blob'];lock=tomllib.loads(lockraw.decode());packages={x['name']:x for x in lock['package'] if (x['name']=='glam' and x['version']=='0.32.1') or (x['name'] in ('bevy','bevy_internal','bevy_math') and x['version']=='0.19.1')};assert set(packages)=={'glam','bevy','bevy_internal','bevy_math'}
archives=[num['package_archive']]+groups['bevy-registration.json']['package_archives'];byname={}
for x in archives:
 d=(b/x['path']).read_bytes();name=x.get('name','glam');assert len(d)==x['bytes'] and sha(d)==x['sha256']==packages[name]['checksum'];byname[name]=d
for group in (num,groups['bevy-registration.json']):
 for x in group['entries']:
  if x.get('kind')=='locked native package member':
   d=byname[x['package']];assert sha(d)==x['package_checksum']
   with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:assert t.extractfile(x['member']).read()==(b/x['archive']).read_bytes()
assert 'bevy_internal' in packages['bevy']['dependencies'] and 'bevy_math' in packages['bevy_internal']['dependencies'] and 'glam 0.32.1' in packages['bevy_math']['dependencies']
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==23
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
assert len(receipt['entries'])==len(allregs)==16;cover={}
for e in receipt['entries']:
 source=allregs[(e['registration'],e['archive'])];rr=groups[e['registration']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']) and e['registration_sha256']==sha((b/e['registration']).read_bytes()) and e['sha256']==source['sha256']
 actual={i for a,z in e['actual_personal_display_chunks'] for i in range(a,z+1)};planned={i for a,z in source['prospective_personal_read_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(unread) and actual|unread==set(range(1,source['eof']+1));cover[(e['archive'],e['revision'])]=actual
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   possible=[e for e in allregs.values() if e['archive']==x['archive'] and e['revision']==x['revision']];assert possible and x['sha256']==possible[0]['sha256'] and x['git_path']==possible[0]['git_path'] and x['native_package']==possible[0].get('package')
   assert all(set(range(a,z+1))<=cover[(x['archive'],x['revision'])] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','registered_personal_read_scopes':len(receipt['entries']),'historical_059_records_manifest_matched':len(history['records_059']),'historical_774_records_git_path_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'locked_native_packages':len(byname),'complete_prior_packets_verified':len(history['prior_packets']),'bounded_lenses':len(report['thirteen_lens_dispositions']),'historic_059_payload_git_path_proof':'not available in inspected publication and project object databases; exact selected records match original recovered manifest','product_validation':'not performed'},indent=2))
