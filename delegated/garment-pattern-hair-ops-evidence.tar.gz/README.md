# Bounded garment pattern source audit

Author: `/root/hair_ops`. Assigned original registry roles 2629–2630.
Working revision: `95e63628f9d70b8dd6e6fede64334696c6995009`.
Historical sources: registered `pr-working` objects, individually equal to
`6533e444fa37552927070cc8d8190907fd3b413e`. Their containing historical
snapshot had unrelated changes. `f82adcabd9d89c4fa2dd7f99253a45297a0681ee`
is transport, not their source revision. Old and current bodies were displayed
separately after registration, including test sections as source text only;
no tests were run. The 6533 copies were compared, not separately displayed.

`REPORT.json` states findings, historical relationships, conditions and all
thirteen bounded perspectives. `registration.json`,
`support-registration.json`, `read-receipt.json` and `git-proofs.json` retain
source identities, prospective scopes, actual reads and Git membership.
`historical-manifest.json` identifies exact copied historical receipts and
hash-linked existing evidence. The selected 059 queue rows are explicitly
reconstructed selections. Those records retain their original reviewers,
revision, narrower historical scopes and chronology; none are checkpoint3821
records. See `MANIFEST.json` for this packet's file hashes.

Run `python3 verify-evidence.py` only to verify evidence integrity. It reads
hash-linked evidence dependencies; it does not execute or validate the
product. The packet reports one conditional panel-order candidate with
reachability and alias decisions pending, and reconnects earlier edge and
panel-reference records without duplicate counts.
