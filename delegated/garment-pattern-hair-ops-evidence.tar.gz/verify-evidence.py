'''Evidence-integrity verification only; no product execution or validation.'''
import gzip,hashlib,json,tarfile
from datetime import datetime
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');report=load('REPORT.json')
for x in hist['hash_links']:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
for x in hist['exact_original_files']:
 b=(p/x['local']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'] and Path(x['source_path']).read_bytes()==b,x['local']
for x in rec['registrations']:
 assert h((p/x['path']).read_bytes())==x['sha256'];assert datetime.fromisoformat(load(x['path'])['registered_utc'])<=datetime.fromisoformat(rec['recorded_utc'])
registry=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/registry.json.gz')));rb=gzip.decompress(registry.read_bytes());assert h(rb)==reg['registry_uncompressed_sha256'];original=json.loads(rb)['files']
archive=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/objects.tar.gz')));assert h(archive.read_bytes())==reg['source_archive_sha256']
with tarfile.open(archive,'r:gz') as t:
 for x in reg['rows']:
  old=(p/x['old_archive']).read_bytes();prev=(p/f"source/{x['role']}-6533.rs").read_bytes();new=(p/f"source/{x['role']}-95e6.rs").read_bytes()
  assert original[x['role']]==x['original_registry_record'] and h(old)==x['old_sha256'] and old==prev==new==t.extractfile(x['old_sha256']).read()
  assert len(old.splitlines())==x['old_lines'] and h(new)==x['git_comparisons'][reg['current_revision']]['sha256']
  rr=next(v for v in rec['assigned'] if v['role']==x['role']);assert rr['unread_old_and_current']==[]
  for key,pk,n in [('pr_working_actual_display','pr_working',len(old.splitlines())),('current_95e_actual_display','current95e',len(new.splitlines()))]:
   assert [i for a,z in rr[key] for i in range(a,z+1)]==list(range(1,n+1))
   for a,z in rr[key]:assert any(c<=a<=z<=d for c,d in x['prospective_display'][pk])
planned={x['saved']:x for x in load('support-registration.json')['sources']}
for x in rec['support']:
 s=planned[x['saved']];b=(p/x['saved']).read_bytes();assert h(b)==x['sha256']==s['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==x['eof']==s['eof'];used=[]
 for a,z in x['displayed']+x['unread_complement']:assert 1<=a<=z<=x['eof'];used.extend(range(a,z+1))
 assert len(used)==x['eof'] and set(used)==set(range(1,x['eof']+1))
 for a,z in x['displayed']:assert any(c<=a<=z<=d for c,d in s['prospective_ranges'])
objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 raise ValueError(name)
for x in proof['proofs']:
 current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for s in x['chain']:
  assert current==s['tree'] and lookup(objects[current],s['name'])==(s['mode'],s['object']);current=s['object']
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and h(b)==x['sha256']
with tarfile.open(hist['prior_774_records_in_published_archive']['archive'],'r:gz') as t:
 rr=[json.loads(v) for v in t.extractfile('historical/774-rig-source-range-registration.jsonl').read().splitlines()];add=[json.loads(v) for v in t.extractfile('historical/774-rig-additional-contracts.jsonl').read().splitlines()]
 for x,num,ranges in zip(reg['rows'],[84,85],[[[1,141]],[[1,14],[67,99]]]):
  for ob in x['original_registry_record']['admission03_scope_observations']:assert rr[ob['row_1based']-1]==ob['original_record']
  a=next(v for v in add if v['id']==f'RIG-ADMISSION03-ADDITIONAL-{num:03}');assert a['sha256']==x['old_sha256'] and a['actual_source_ranges']==ranges and not a['assigned802_credit'] and not a['later_lens_credit']
l11=load('historical/059--segovb--READ-L11-430.json')
for role,ranges in [(2629,[[1,141]]),(2630,[[1,14],[67,99]])]:
 row=next(v for v in l11['sources'] if v['original_index']==role);assert row['fresh_personal_body_reads']==ranges
l902=load('historical/059--segovb--READ-L12-902.json');r=l902['rows'][0];assert r['original_index']==2629 and r['fresh_personal_body_reads']==[] and r['new_original_credit']==0 and l902['new_original_roles']==1 and l902['root_personal_rereads']==[]
l903=load('historical/059--segovb--READ-L12-903.json');r=l903['rows'][0];assert r['original_index']==2630 and r['fresh_personal_body_reads']==[[1,14],[67,99]] and l903['root_personal_rereads']==[]
connected=load('historical/059--parallel-l12-20261029--READ-CONNECTED-PAR-L12-746-PANEL-IDENTITY.json');assert connected['rows'][0]['fresh_personal_body_reads']==[[1,141]] and connected['rows'][2]['fresh_personal_body_reads']==[[142,468]] and '/root/lens12_frontier' in connected['rows'][0]['attribution']
sel=load(hist['reconstructed_selection']);qb=Path(sel['queue_path']).read_bytes();assert h(qb)==sel['queue_sha256'];q=json.loads(qb)['entries']
for x in sel['queue_rows']:assert q[x['index']]==x['entry']
prior=json.loads(Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/ASSESSMENT-GARMENT-FIT-95E.json'))).read_bytes())
for path,ranges in [('crates/fabelgeist-garment-code/src/pattern/spec.rs',[[1,134],[211,270],[300,330]]),('crates/fabelgeist-garment-code/src/pattern/core.rs',[[56,99]])]:assert next(v for v in prior['current_supporting_sources'] if v['path']==path)['ranges']==ranges
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==[{k:v for k,v in x.items() if k!='qualification'} for x in rec['assigned']]
if (p/'MANIFEST.json').exists():
 for x in load('MANIFEST.json')['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
print(f"PASS: two separately displayed full old/current bodies; {len(proof['proofs'])} Git membership proofs; {len(rec['support'])} support partitions; original 774/059 receipts and reconstructed queue links. Evidence integrity only; no product execution or validation.")
