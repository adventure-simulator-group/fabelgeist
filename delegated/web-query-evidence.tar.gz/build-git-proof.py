import gzip,hashlib,json,pathlib,subprocess
root=pathlib.Path('<LOCAL_PATH_0>');sha=lambda b:hashlib.sha256(b).hexdigest();oid=lambda kind,b:hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
objects={};commits={};proofs=[]
def save(kind,k):
 if k not in objects:
  body=git('cat-file',kind,k);assert oid(kind,body)==k;path=f'git-objects/{k}.{kind}.gz';(root/path).parent.mkdir(parents=True,exist_ok=True);(root/path).write_bytes(gzip.compress(body,mtime=0));objects[k]={'type':kind,'bytes':len(body),'sha256':sha(body),'preserved_bytes':path}
 return gzip.decompress((root/objects[k]['preserved_bytes']).read_bytes())
def entries(body):
 rows={};i=0
 while i<len(body):
  z=body.index(b'\0',i);mode,name=body[i:z].split(b' ',1);rows[name.decode()]=(mode.decode(),body[z+1:z+21].hex());i=z+21
 assert i==len(body);return rows
def proof(rev,path,body,kind):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 current=commits[rev]['root_tree'];chain=[]
 for segment in path.split('/'):
  t=save('tree',current);mode,child=entries(t)[segment];chain.append({'tree':current,'name':segment,'mode':mode,'object':child});current=child
 assert oid('blob',body)==current
 proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(body),'bytes':len(body),'git_blob':current,'path_chain':chain})
for e in json.load(open(root/'registration.json'))['entries']:proof(e['revision'],e['path'],(root/'sources'/e['revision'][:4]/e['path']).read_bytes(),'original role')
for name in ['support-registration.json','support-registration-2.json']:
 for e in json.load(open(root/name))['entries']:proof(e['revision'],e['path'],(root/'support'/e['path']).read_bytes(),'bounded current support')
for e in json.load(open(root/'historical-support-6533-registration.json'))['entries']:
 if e.get('status')=='absent_in_historical_revision':continue
 proof(e['revision'],e['path'],(root/'historical-support-6533'/e['path']).read_bytes(),'historical support bytes; unread')
for e in json.load(open(root/'history-manifest.json'))['older_774_receipts']:proof(e['transport_revision'],e['transport_path'],(root/e['preserved_bytes']).read_bytes(),'older historical 774 transport record')
d={'schema':'726-delegated-raw-git-path-membership-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Raw commit and binary tree bytes bind each exact source or historical record body to the named immutable Git path. Full bytes do not expand read ranges; f82 is a historical transport commit, never checkpoint3821.'};raw=(json.dumps(d,indent=2)+'\n').encode();(root/'git-proofs.json').write_bytes(raw);print('git proof entries',len(proofs),'raw objects',len(objects),'proof sha256',sha(raw))
