from pathlib import Path
import json,hashlib,datetime,gzip
r=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256((r/p).read_bytes()).hexdigest();rev='95e63628f9d70b8dd6e6fede64334696c6995009';central=json.loads(gzip.decompress((r/'central/RECONCILIATION-059.json.gz').read_bytes()))['entries'];base=json.loads(gzip.decompress((r/'central/BASELINE-95E-20261110.json.gz').read_bytes()));matches=[x for x in base['newly_assessed_ledger']['entries'] if 'BESAGEW' in x.get('id','') or 'RADIAL' in x.get('id','')]
o={
 'schema':'726-checkpoint17-besagew-radial-reconciliation-proposal-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/hair_ops',
 'scope':'Bounded evidence for checkpoint17 original pr-working roles2619–2620, their selected current callers and existing historical contracts. No new ordered-role population, accepted finding count, alias decision, whole-lens completion or central ledger edit.',
 'current_revision':rev,'registrations':{p:h(p) for p in ['registration.json','support-extension-registration.json','guard-extension-registration.json']},
 'read_receipt':{'path':'read-receipt.json','sha256':h('read-receipt.json')},'guard_extension_read_receipt':{'path':'guard-extension-read-receipt.json','sha256':h('guard-extension-read-receipt.json')},'git_proofs':{'path':'git-proofs.json','sha256':h('git-proofs.json')},'history':'historical/evidence-index.json',
 'identity_and_recovery_qualifications':[
  'Original roles2619/2620 are pr-working archived source objects, recorded base 6533e444fa37552927070cc8d8190907fd3b413e with unrelated working modifications. Each assigned file individually matches 6533 and 95e; that does not establish a clean snapshot. f82adcabd9d89c4fa2dd7f99253a45297a0681ee transports historic evidence, not the project source head.',
  'Physical-P16 is separately dirty with recorded base a120390947c89b703dc74c4255a13c035d054c50; matching later tracked patch excludes seven separately preserved untracked files and does not prove original invocation or uninterrupted custody. No P16 read or source identity is inferred from pr-working.',
  '774 rig RIG-ADMISSION03-REGISTER-067/068 and ADDITIONAL-067/068 recorded personal historic reads of 2619 1–47 and 2620 1–49. The original 059 /root/segovb READ-L11-428 separately recorded those old roles, and /root/lens12_frontier READ-L12-895/896 was adopted by root without root personal rereads. Historical identity and authors are retained.',
  'Original 059 queue/ledger are compressed byte-identical Git objects; selected rows are reconstructed, not standalone original records or checkpoint3821. Nested crates/ paths in q2691 are source locators, not missing user-extraction receipts. The chart object matches 6533 and f82 in offline proofs, but this packet did not personally display the historical chart version.',
  'Prior /root/rig_identity packet contains separately displayed historical/current full roles and earlier current support; the original 774 rig F050 and CONTRACT-588/595 retain their own scope and author. Their evidence and all prior delegate observations remain separate from our new source reading.',
  'Central files are captured working snapshots at the evidence-index timestamp, possibly staged or uncommitted, and are not claimed to remain current. At capture no current newly-assessed-ledger ID containing BESAGEW or RADIAL was found; this bounded ID check does not prove global novelty or rule out indirect aliases. No prior verifier ran.'
 ],
 'proposals':[
  {
   'prior_delegate_id':'REVIEW-BESAGEW-RADIAL-TRIANGLE-BUDGET-95E','prior_author':'/root/rig_identity',
   'classification':'Existing delegate source-derived conditional budget question; propose central review, no accepted new count or inferred alias with other equipment-budget questions.',
   'source_references':['pr-working recovered/95e crates/fabelgeist-armor/src/besagew.rs:5–27,31–45 and radial_fluting.rs:5–49','95e crates/fabelgeist-armor/src/limb_armor.rs:118–150,282–285,328–341','95e crates/fabelgeist-armor/src/gpu/limb.rs:268–289,412–433,466–478','95e crates/fabelgeist-armor/src/gpu/chart.rs:93–153,186–205','95e crates/fabelgeist-armor/src/gpu/recipe.rs:47–56, part/layout.rs:100–107, shell_plan.rs:39–61,73–119','95e crates/fabelgeist-armor/src/gpu/limb_build.rs:7–20 and crates/adventuresim-character-creator/src/device_limb.rs:20–30','95e crates/adventuresim-character-creator/src/besagew_controls.rs:5–10,40–47; crates/fabelgeist-armor/src/sampling.rs:1–8; crate armor AGENTS runtime-budget guidance'],
   'trace':'The optional BesagewDesign defaults to no fluting; the editor source can separately enable its radial default. That default has count24; at 12 samples per spoke it yields288 columns, above the selected 96 minimum. The selected spaulder constructs a 24-row CyclicApex chart with no PlateFluting in its base chart grid. Chart layout creates 23 cyclic strips, each with two triangles per column, plus one apex triangle per column: (23*2+1)*288 = 13,536 carrier triangles. If ShellPlan::new succeeds, it retains those outer triangles and adds an inner copy, yielding at least 27,072 planned shell triangles before any return walls or other spaulder shells.',
   'safeguards':['The selected limb shape invokes LimbArmorDesign::validate before dispatch, which calls the optional besagew and radial validators.','Radial count4–48 and a 96 minimum give positive selected column counts; 24 rows avoid the generic zero-row/empty-stride F050 preconditions.','ShellPlan checks counts, indices, triangle grouping and edge consistency and can return InvalidSurface instead of constructing a plan.'],
   'limits':'These are source-level planned counts, not actual mesh, GPU, fit, exported readback or runtime measurements. Successful kernel/chart/shell/fit path, supported asset lifecycle, bake-only versus shipped representation, later simplification and applicable per-model scope are open. sampling.rs names a normal 10,000-triangle runtime budget and crate guidance says generally below it, but neither establishes an unconditional hard rejection for this path. No UI, geometry, device or product ran.',
   'historical_relationship':'774 rig CONTRACT-595 and ADDITIONAL-067/068 already establish selected source/count gates; their full old source scopes and author remain unchanged. 059 q1814/1815 broadly cover limb validation/native consumers. Earlier /root/hair_ops equipment-budget-scope question and this disc-specific count may have overlapping repair scope but their exact relationship is unresolved.'
  },
  {
   'prior_delegate_id':'REVIEW-RADIAL-EDITOR-RAW-ARITHMETIC-QUESTION','prior_author':'/root/rig_identity',
   'classification':'Existing delegate conditional admission question; no observed failure, new count or claim that the checked loader produces invalid input.',
   'source_references':['P16 is not inferred; pr-working recovered/95e crates/fabelgeist-armor/src/radial_fluting.rs:5–13,29–41 and besagew.rs:31–45','95e crates/adventuresim-character-creator/src/besagew_controls.rs:40–80, armor_design_input.rs:69–75,104–110,119–121,122–138 and armor_recipes.rs:11–30','95e crates/fabelgeist-armor/src/limb_armor.rs:282–285,328–341'],
   'trace':'Editor source forms end−2*fade, start+2*fade and (end−start)/2 directly from raw u16 fields while creating dependent control ranges. Arbitrary already-invalid authoring values can violate those arithmetic preconditions. A selected saved-design parse and override decode call validate_design, which dispatches ParametricDesign::Limb to LimbArmorDesign::validate and then BesagewDesign/RadialFluting validators.',
   'safeguards':['Radial start200–700 and end800–1000 are disjoint, fade50–250 is bounded, and end−start>=2*fade is checked after those raw ranges; arithmetic in the validator itself is therefore safe on the evaluated route.','For an initially valid pattern, the editor expressions have nonnegative end−2*fade and end−start and start+2*fade<=end<=1000.','The selected editor toggles in a valid radial default; the observed saved-design and override routes validate before return.'],
   'limits':'The number-control implementation, all other in-memory producers, intermediate mutations during rendering and supported malformed ingress remain unexamined. No editor, parser, product or runtime operation was executed. Do not assert an actual overflow or invalid persisted state.'
  },
  {
   'historical_id':'RIG-ADMISSION03-F050','classification':'Original 774 rig generic raw chart admission candidate; selected validated besagew sender is a bounded nonfinding, not an assumed closure or separate current issue.',
   'source_references':['95e crates/fabelgeist-armor/src/gpu/chart.rs:70–90,93–153,186–205','95e crates/fabelgeist-armor/src/gpu/limb.rs:412–433,466–478','P16 not inferred; historical 6533 chart per-file equality proof only, without fresh historical display'],
   'trace':'Generic crate-visible PlateChart::last_row subtracts one for an apex and indices subtracts one for noncyclic stride before a separate layout admission gate. The selected validated besagew instead uses rows24, cyclic-apex and at least96 columns; those selected underflow/empty-stride conditions are excluded on that route.',
   'limits':'No arbitrary malformed chart caller, runtime error, global caller inventory or precise 059 alias is established. q2691 names the separate shader-source compilation boundary and should not be equated merely because it touches chart code.'
  },
  {
   'prior_delegate_id':'REVIEW-BESAGEW-TILT-ADAPTER-REUSE-95E','prior_author':'/root/rig_identity',
   'classification':'Existing delegate maintenance suggestion, not demonstrated numeric divergence or new source-of-truth defect.',
   'source_references':['pr-working recovered/95e crates/fabelgeist-armor/src/besagew.rs:7–14','95e crates/fabelgeist-armor/src/design.rs:40–45 and gpu/limb.rs:412–420,448–455'],
   'trace':'Selected chart-axis and design-float projections both evaluate the borrowed outward tilt as f32::from(raw)/1000; Milliradians::radians already implements the same conversion.',
   'limits':'No behavioral mismatch or actual duplication of mutable authority is shown. Whether reuse is desirable and whether all native consumers preserve sign and scale are separate decisions; no new count.'
  }
 ],
 'historical_relationships':[
  {'record':'774 RIG-ADMISSION03-REGISTER-067/068 and ADDITIONAL-067/068','scope':'Historical rig reviewer pr-working 2619 1–47 and 2620 1–49; radial gate proves bounded raw count and safe arithmetic on its validated path.'},
  {'record':'774 RIG-ADMISSION03-CONTRACT-595','scope':'Historical rig reviewer full pr-working gpu/limb.rs 1–478; selected validated limb/count route, distinct from raw chart first admission.'},
  {'record':'774 RIG-ADMISSION03-CONTRACT-588 and F050','scope':'Historical rig reviewer generic chart source and named conditional raw chart issue; selected besagew safeguards do not close other callers.'},
  {'record':'059 q609, q1814, q1815','scope':'Broader pending armor carrier/native and limb source obligations; partial current evidence is not full history reconciliation or automatic candidate alias.'},
  {'record':'059 q2691 L12-CLOSURE-EXTREMITY-SHADER-SOURCE-BOUNDARY','scope':'Separate shader text/native program owner question; not the raw chart or triangle budget first contract.'}
 ],
 'historical_read_attribution':[
  {'reader':'774 rig reviewer','record':'prior/visor-buffe/history-774/source-range-registration.jsonl.gz, additional-contracts.jsonl.gz, contract-groups.jsonl.gz and prior/besagew-radial/historical-774/rig-findings.jsonl.gz','scope':'Original pr-working 2619/2620 roles and original chart/limb contracts; no later-lens transfer.'},
  {'reader':'059 /root/segovb','record':'prior/besagew-radial/historical-059/segovb/READ-L11-428.json and registrations1534/1535','scope':'Original 6533/pr-working role2619 1–47 and role2620 1–49.'},
  {'reader':'059 /root/lens12_frontier; subsequent root adoption without personal reread','record':'prior/besagew-radial/historical-059/segovb/READ-L12-895.json, READ-L12-896.json and registrations685/686','scope':'Historic role2619/2620 full material; no 95e or other-lens read transfer.'},
  {'reader':'/root/rig_identity','record':'prior/besagew-radial/REPORT.json and personal-read-receipt.json','scope':'Prior separately displayed 6533 and 95e full roles2619/2620, separately registered current supports and three attributed candidate questions.'},
  {'reader':'/root/hair_ops','record':'prior/pierced-sampling/REPORT.json and read-receipt.json','scope':'Earlier distinct 2615/2616 packet includes generic equipment triangle-budget scope question; not automatically the same issue.'},
  {'reader':'/root/hair_ops','record':'read-receipt.json','scope':'Fresh separately displayed historic/current bodies and selected current supports, plus independently registered current caller extensions; per-registration unread complements explicit.'}
 ],
 'bounded_lens_perspectives':{
  'producer_propagation':'Selected editor design flows into a checked limb sender and chart/shell planning; actual runtime/export producer and downstream reductions remain open.',
  'existing_type_owners':'Milliradians already owns an equivalent radians conversion; native float projections do not show behavioral divergence.',
  'admission_contracts':'Validated radial ranges protect selected input arithmetic and chart cardinality; raw editor and generic chart callers remain separate boundaries.',
  'invariant_operations':'The selected default topology gives a source-derived 13,536 carrier and conditional 27,072 outer/inner triangles; actual geometry is not executed.',
  'aggregate_states':'A radial pattern’s end, start and fade jointly constrain safe control ranges, while chart rows, columns and boundary jointly define topology.',
  'type_ownership':'Distinguish authoring units, validated fluting, chart/native counts and model-level budget rather than guessing a shared owner.',
  'redundant_authority':'Two immutable tilt float projections are numerically identical; no competing mutable authority is proven.',
  'behavior_preservation':'Preserve optional unfluted/unattached discs, deliberate appearance and existing valid chart modes in any later work.',
  'enum_shapes':'CyclicApex is an explicit boundary mode; no shape change is justified from count observations alone.',
  'derivability':'Derived Serde leaves raw design representable; it does not certify cross-field validity or product export.',
  'type_granularity':'Radial flute count, chart sample count, triangle budget and GPU/native counts have different roles despite numeric overlap.',
  'magic_strings':'UI labels are presentation; shader program text is an intentional native boundary with separate q2691 context.',
  'magic_numbers':'Twelve samples per spoke, 96 minimum, 24 rows and 10,000 normal runtime target belong to different policy/geometry decisions; actual target scope remains open.'
 },
 'captured_central':{'qualification':'Captured working-state snapshot at evidence-index time; not a claim it remains live.','matched_besagew_or_radial_ids':matches,'reconciliation_rows':{str(i):central[i] for i in [609,1814,1815,2691]}},
 'open_questions':['Which production asset path uses this disc as dense bake, shipped runtime, or reduced detail, and what is the actual whole-model budget policy?','Are there supported, unvalidated editor inputs or intermediate control mutations that violate radial arithmetic before admission?','What do other raw PlateChart constructors and native capacity/error boundaries require?','Should tilt native projections reuse the existing radians method without changing values or sign?','What are the exact cross-lens aliases for the delegate candidate and earlier general equipment-budget questions?','Other source families, full thirteen-lens closure and missing checkpoint3821 remain open.'],
 'new_ledger_rows':[],'accepted_unique_count_change':0,'repair':'not started','product_validation':'not performed'
}
(r/'REPORT.json').write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n');print('report sha256',h('REPORT.json'))
