from pathlib import Path
import gzip,json,hashlib,shutil,datetime
r=Path(__file__).resolve().parent;prev=Path('<LOCAL_PATH_0>');user=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest()
for d in ['recovered','historical','prior','central']:(r/d).mkdir()
for n in ['MANIFEST.json','registry.json.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:shutil.copyfile(prev/'recovered'/n,r/'recovered'/n)
(r/'recovered/p16').mkdir()
for n in ['tracked.patch','RECOVERY.json']:shutil.copyfile(prev/'recovered/p16'/n,r/'recovered/p16'/n)
q=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'));ledger=json.load(gzip.open(r/'recovered/original-059-ledger.json.gz','rt'));inds=[609,1814,1815,2691];rows={str(i):q['entries'][i] for i in inds};findings={e['contract_id']:ledger['discovery_findings_and_dependencies'][e['contract_id']] for e in rows.values() if e['contract_id'] in ledger['discovery_findings_and_dependencies']}
(r/'historical/selections-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed selected rows of exact recovered 059 queue and ledger bytes, neither standalone original records nor checkpoint3821. Related contracts are not asserted aliases.','queue_rows':rows,'ledger_findings':findings},indent=2,ensure_ascii=False)+'\n')
refs={}
def walk(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str) and len(x['sha256'])==64:refs[x['path']]=x['sha256']
  if isinstance(x.get('verification'),str) and isinstance(x.get('verification_sha256'),str):refs[x['verification']]=x['verification_sha256']
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for y in x:walk(y)
for row in rows.values():walk(row)
receipt_refs={p:d for p,d in refs.items() if not p.startswith('crates/')};source_locators={p:d for p,d in refs.items() if p.startswith('crates/')}
for p,d in receipt_refs.items():
 b=(user/p).read_bytes();assert h(b)==d,p;out=r/'historical'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
prior=Path('<LOCAL_PATH_3>');history=json.loads((prior/'historical-attribution.json').read_bytes());historicfiles=[x['preserved_bytes'] for x in history['records_059']]
packets=[('besagew-radial',str(prior),'d0180fcf54e74c48f90d0c6f6e048f5900e83ec67f73ee5351023fb050b076bb',['REPORT.json','registration.json','personal-read-receipt.json','support-registration.json','chart-registration.json','budget-registration.json','editor-registration.json','input-registration.json','historical-attribution.json','historical-774/rig-findings.jsonl.gz']+historicfiles),('visor-buffe','<LOCAL_PATH_4>','3aebb9d51f80bbfe32ebdff97bd3dce5b263397e0939ebf371256f723a2bc00f',['history-774/source-range-registration.jsonl.gz','history-774/additional-contracts.jsonl.gz','history-774/contract-groups.jsonl.gz']),('pierced-sampling','<LOCAL_PATH_5>','5e98f9550e19a46e5d41fd05d5807920d99a23820a0c2684e256e50c5dce07bf',['REPORT.json','registration.json','read-receipt.json'])]
pktinfo=[]
for label,old,expected,files in packets:
 p=Path(old);mb=(p/'MANIFEST.json').read_bytes();assert h(mb)==expected;mapping={v['path']:v['sha256'] for v in json.loads(mb)['files']};dest=r/'prior'/label;dest.mkdir();(dest/'MANIFEST.json').write_bytes(mb)
 for f in files:
  b=(p/f).read_bytes();assert h(b)==mapping[f],(label,f);out=dest/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 pktinfo.append({'label':label,'previous_directory':old,'manifest_sha256':expected,'members':files})
central=['RECONCILIATION-059.json','BASELINE-95E-20261110.json','DELEGATED-EVIDENCE-CHECKPOINT-17.json','ASSESSMENT-LIMB-METAL-95E.json','ASSESSMENT-ARMOR-CONSTRUCTION-95E.json']
centralmeta=[]
for n in central:
 b=(pub/n).read_bytes();out='central/'+n+'.gz';(r/out).write_bytes(gzip.compress(b,mtime=0));centralmeta.append({'path':n,'local':out,'sha256':h(b),'bytes':len(b)})
o={'schema':'726-roles2619-2620-evidence-index-v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_059_receipts_from_queue_hashes':receipt_refs,'queue_nested_source_locators_not_receipts':source_locators,'prior_frozen_packets':pktinfo,'central_working_snapshots':centralmeta,'qualification':'Queue-linked receipt copies match original 059 hashes. Nested crates/ paths are source registry locators, not user-extraction receipts; they are recorded separately and not falsely reported missing. Prior 059 and 774 records copied unchanged under verified manifests. Central files are captured working snapshots, potentially staged/uncommitted, not asserted as a published commit. No prior verifiers invoked and no reader, dirty-P16 or checkpoint3821 credit transferred.'}
(r/'historical/evidence-index.json').write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n');print('059 queue-linked receipts',len(receipt_refs),'source locators',len(source_locators),'prior packets',len(pktinfo),'central snapshots',len(centralmeta))
