# Delegated shell contact audit

The central audit owns the authoritative baseline, reconciliation, role
statuses, ledger, review and publication. This packet covers original roles
2340–2342 and separately registered current support. Start with `report.json`.
The source audit is bounded; it neither completes a lens nor authorizes repairs.

`registration.json` and `read-receipt.json` identify the historical and
current personal reads. Their exact source bodies are archived separately even
where byte-identical. Support registration and its receipt record full bounded
support reads with no ordered-role credit. Registration clock values were
sampled before writing; actual registration file times were recorded before
subsequent source displays. Git commit/tree objects and `git-proofs.json`
prove membership of every archived source body in its stated revision.

`historical-059/` preserves exact recovered original records and the index
checks each against the original transport manifest. The original transport
manifest and original registry are preserved as compressed originals. The
complete 059 queue is retained as a separately compressed transport of its
original bytes; decompression restores its recorded SHA-256 exactly. The
registry and queue subset JSON files are derived navigation aids, not original
records. The older 774 folder holds distinct exact original and path-normalized
export records, separately checked against the export manifest. Historical
reviews retain their original revision, reviewer, scope and qualifications.
Nothing here substitutes for missing original checkpoint 3821 ledger or queue.

`check-evidence.py` verifies archived evidence only; its result is recorded in
`evidence-verification.json`. Test source was read but never executed. No
product repair, build, test, fixture, runtime probe, simulation, shader execution
or product validation occurred. Some original records contain local paths and
require reviewed, documented redaction before publication; preserve the
original and normalized hashes and provenance.
