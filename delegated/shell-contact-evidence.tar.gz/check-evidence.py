import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
reg=json.loads((p/'registration.json').read_text());sreg=json.loads((p/'support-registration.json').read_text());entries=reg['sources']+sreg['sources']
for e in entries:
 b=(p/e['source_file']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob_sha1'],e['bytes'],e['lines'])
for regfile,receiptfile in [('registration.json','read-receipt.json'),('support-registration.json','support-read-receipt.json')]:
 a=json.loads((p/regfile).read_text());b=json.loads((p/receiptfile).read_text());
 for e,x in zip(a['sources'],b['actual_source_displays'],strict=True):
  assert all(e[k]==x[k] for k in ('kind','revision','path','source_file','sha256')); assert x['ranges']==e['planned_display_ranges']
allowed={e['path']:e['planned_display_ranges'] for e in entries if e['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009'}
report=json.loads((p/'report.json').read_text());refs=[]
def walk(v):
 if isinstance(v,dict):
  if {'revision','path','lines'}<=v.keys() and isinstance(v['lines'],list):refs.append(v)
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(report)
for r in refs:
 assert r['revision']==report['current_revision'] and r['path'] in allowed,r
 for a,b in r['lines']:assert any(x<=a<=b<=y for x,y in allowed[r['path']]),r
proof=json.loads((p/'git-proofs.json').read_text());cache={}
for f in (p/'git-objects').iterdir():
 oid,typ=f.name.split('.');b=f.read_bytes();assert hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid;cache[(oid,typ)]=b
def tree_entries(data):
 pos=0;d={}
 while pos<len(data):
  nul=data.index(b'\0',pos);mode,name=data[pos:nul].split(b' ',1);oid=data[nul+1:nul+21].hex();d[name.decode()]=(mode.decode(),oid);pos=nul+21
 assert pos==len(data);return d
for e in proof['proofs']:
 assert cache[(e['revision'],'commit')].split(b'\n',1)[0]==b'tree '+e['commit_tree'].encode();tree=e['commit_tree']; path=[]
 for item in e['membership']:
  assert item['parent_tree']==tree; assert tree_entries(cache[(tree,'tree')])[item['entry']]==(item['mode'].lstrip('0'),item['object']);tree=item['object'];path.append(item['entry'])
 assert '/'.join(path)==e['path'];assert tree==e['blob_sha1']==blob((p/e['source_file']).read_bytes())
assert len(proof['proofs'])==len(entries)
h=json.loads((p/'historical-059-index.json').read_text());mfraw=(p/'historical-inputs/original-transport-manifest.json.gz').read_bytes();assert sha(mfraw)==h['transport_manifest_sha256'];manifest=json.loads(gzip.decompress(mfraw));lookup={e['path']:e for e in manifest['entries']}
for e in h['records']:
 b=(p/e['copy']).read_bytes();assert (sha(b),blob(b),len(b))==(e['sha256'],e['git_blob'],e['bytes']); assert all(lookup[e['path']][k]==e[k] for k in ('sha256','git_blob','bytes'))
regraw=(p/'historical-inputs/original-registry.json.gz').read_bytes();regjson=gzip.decompress(regraw);reg0=json.loads(regjson);subset=json.loads((p/'historical-registry-subset.json').read_text());assert sha(regraw)==subset['source_registry_gzip_sha256'];assert sha(regjson)==subset['source_registry_decompressed_sha256']
for i in (2340,2341,2342):
 assert reg0['files'][i]==subset['roles'][str(i)]; assert next(e for e in entries if e.get('original_role_index')==i and e['kind']=='historical')['sha256']==reg0['files'][i]['sha256']
qraw=gzip.decompress((p/'historical-inputs/059-queue-original-bytes.json.gz').read_bytes());q=json.loads(qraw);qsel=json.loads((p/'historical-queue-subset.json').read_text());assert sha(qraw)==qsel['source_sha256']
for e in qsel['entries']:assert e['entry']==q['entries'][e['queue_index']]
o=json.loads((p/'older-774/INDEX.json').read_text());mraw=(p/o['export_manifest_copy']).read_bytes();assert sha(mraw)==o['export_manifest_sha256']; ol={e['file']:e for e in json.loads(mraw)['files']}
for e in o['records']:
 assert ol[e['manifest_entry']['file']]==e['manifest_entry']; assert sha((p/e['original_copy']).read_bytes())==e['original_sha256']==e['manifest_entry']['original_record_sha256']
 if e['export_differs']:assert sha((p/e['normalized_copy']).read_bytes())==e['normalized_sha256']==e['manifest_entry']['published_export_sha256']
r={'kind':'Evidence-only consistency verification','status':'passed','ordered_bodies':len(reg['sources']),'support_bodies':len(sreg['sources']),'report_source_refs_within_displayed_ranges':len(refs),'git_membership_proofs':len(proof['proofs']),'git_commit_tree_objects':len(cache),'original_059_exact_records':len(h['records']),'historical_queue_original_bytes':len(qraw),'historical_queue_selected_entries':len(qsel['entries']),'older_774_originals':len(o['records']),'separate_normalized_exports':sum(e['export_differs'] for e in o['records']),'qualification':'Evidence verification only. No product implementation, build, tests, fixtures, runtime probes, simulations, shader execution or product validation.'};(p/'evidence-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
