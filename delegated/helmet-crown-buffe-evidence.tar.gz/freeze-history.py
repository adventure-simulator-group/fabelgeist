from pathlib import Path
import gzip,hashlib,json
b=Path(__file__).parent;pub=Path('<LOCAL_PATH_0>');ex=Path('<LOCAL_PATH_1>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();registry=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));manifest=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));index={x['path']:x for x in manifest['entries']};p16=next(x for x in registry['snapshots'] if x['id']=='physical-p16');pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');rows=[{'original_index':i,**registry['files'][i]} for i in [2611,2612]]
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-registry-reconstruction-v1','qualification':'Selected reconstructed rows and original snapshot records, not a standalone historical original; P16 is separate and no checkpoint3821 restoration is claimed.','rows':rows,'snapshots':[pr,p16]},indent=2)+'\n')
q=json.load(open(pub/'baseline-059/queue.json'))['entries'];indices=[1813,2404,3141];(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-original-queue-reconstruction-v1','qualification':'Exact selected rows reconstructed from original baseline059 queue; no status or acceptance change.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in indices]},indent=2)+'\n')
paths=['segovb/READ-L11-427.json','segovb/VERIFY-L11-427.json','segovb/STATE-L11-427.json','segovb/REGISTRATION-SEGOVB-1523.json','segovb/REGISTRATION-SEGOVB-1524.json','segovb/READ-L12-892.json','segovb/VERIFY-L12-892.json','segovb/STATE-L12-892.json','parallel-l12-20261029/PROPOSAL-L12-892.json','parallel-l12-20261029/REGISTRATION-PAR-L12-677.json','parallel-l12-20261029/REGISTRATION-PAR-L12-678.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-677-ORIGINAL2611.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-678-ORIGINAL2612.json']
records=[];missing=[]
for path in paths:
 f=ex/path
 if not f.exists() or path not in index:missing.append({'path':path,'local':f.exists(),'in_transport':path in index});continue
 raw=f.read_bytes();m=index[path];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];dest=b/'historical-059'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);records.append({'original_path':path,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dest.relative_to(b))})
assert not missing,missing
(b/'historical-attribution.json').write_text(json.dumps({'schema':'726-helmet-historical-attribution-v1','records_059':records,'missing':missing,'qualification':'Exact 059 records retained with revision, reader and exclusions; older 774 source-range and contract lines remain hash-linked as whole original files.'},indent=2)+'\n')
links=[]
def link(path,origin,qualification):
 p=Path(path);d=p.read_bytes();links.append({'path':str(p),'sha256':sha(d),'bytes':len(d),'origin':origin,'qualification':qualification})
for path in ['recovered/original-registry-source-archive/registry.json.gz','recovered/original-transport-manifest.json.gz','baseline-059/queue.json','baseline-059/ledger.json','BASELINE-95E-20261110.json','ASSESSMENT-HELMET-FOOTWEAR-95E.json','ASSESSMENT-ARMOR-BODY-COORD-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json','recovered/physical-p16-patch-recovery/tracked.patch']:
 link(pub/path,'published evidence','Current assessment, original historical state and P16 recovery each retain their own revision and qualifications.')
old=Path('<LOCAL_PATH_2>')
for path in ['MANIFEST.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774-compressed/additional-contracts.jsonl.gz','historical-774-compressed-attribution.json','git-proofs.json']:
 link(old/path,'prior /root/rig_identity frozen packet','Original older 774 records and earlier authorship; no read credit transfer.')
peer=Path('<LOCAL_PATH_3>')
for path in ['MANIFEST.json','REPORT.json','read-receipt.json']:
 link(peer/path,'prior /root/hair_ops roles2609–2610','Earlier personally registered reads, separate attribution; no read transfer.')
peer2=Path('<LOCAL_PATH_4>')
for path in ['MANIFEST.json','REPORT.json','read-receipt.json']:
 link(peer2/path,'parallel /root/hair_ops roles2615–2616','Fresh 95e visor breaths 1–149 and burgonet 200–285 support, plus close-helmet 1–125; no upstream course-height personal read or transferred role credit.')
(b/'evidence-links.json').write_text(json.dumps({'schema':'726-helmet-hash-links-v1','links':links,'qualification':'Hash links keep the packet compact; exact linked bytes must be retained alongside durable publication.'},indent=2)+'\n');print('original059',len(records),'hashlinks',len(links),'missing',missing)
