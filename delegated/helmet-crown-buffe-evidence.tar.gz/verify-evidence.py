from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys
b=Path(__file__).parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda p:json.loads(Path(p).read_bytes());gun=lambda p:gzip.decompress(Path(p).read_bytes())
links=load(b/'evidence-links.json')['links']
for e in links:
 raw=Path(e['path']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],e['path']
r=load(b/'personal-read-receipt.json');reg=load(b/'registration.json');report=load(b/'REPORT.json');old=json.loads(gun(pub/'recovered/original-registry-source-archive/registry.json.gz'));sel=load(b/'registry-selection-reconstructed.json')
for e in sel['rows']:assert {k:v for k,v in e.items() if k!='original_index'}==old['files'][e['original_index']]
for e in sel['snapshots']:assert e in old['snapshots']
pr=next(x for x in old['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
p16=next(x for x in old['snapshots'] if x['id']=='physical-p16');assert p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(p16['status_porcelain'])==159
recovery=load(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256'] and recovery['recovered_patch']['bytes']==524542 and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7}
for e in reg['entries']:
 raw=(b/e['archive']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and len(raw.splitlines())==e['actual_eof']
 if e['original_registry_ranges'] is not None:
  o=old['files'][e['role']];assert o['sha256']==e['sha256'] and o['material_ranges']==e['original_registry_ranges'] and not any(x[3:]==e['path'] for x in pr['status_porcelain'])
for i in (2611,2612):assert (b/f'sources/{i}-historical.rs').read_bytes()==(b/f'sources/{i}-current.rs').read_bytes()
queue=load(pub/'baseline-059/queue.json')['entries'];qs=load(b/'queue-selection-reconstructed.json')['entries'];assert [x['original_index_zero_based'] for x in qs]==[1813,2404,3141]
for x in qs:assert x['entry']==queue[x['original_index_zero_based']]
at=load(b/'historical-attribution.json');assert not at['missing'];manifest=json.loads(gun(pub/'recovered/original-transport-manifest.json.gz'));idx={x['path']:x for x in manifest['entries']}
for x in at['records_059']:
 raw=(b/x['preserved_bytes']).read_bytes();z=idx[x['original_path']];assert sha(raw)==x['sha256']==z['sha256'] and len(raw)==x['bytes']==z['bytes'] and oid('blob',raw)==x['git_blob']==z['git_blob'],x['original_path']
old11=load(b/'historical-059/segovb/READ-L11-427.json');old12=load(b/'historical-059/segovb/READ-L12-892.json')
for i,expected in [(2611,[[1,34]]),(2612,[[1,64]])]:
 x=next(x for x in old11['sources'] if x.get('original_index')==i);y=next(x for x in old12['rows'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected and y['fresh_personal_body_reads']==expected and '/root/lens12_frontier' in y['attribution']
rangefile=next(Path(x['path']) for x in links if x['path'].endswith('/source-range-registration.jsonl'));orig=[json.loads(x) for x in rangefile.read_bytes().splitlines()]
for i in [2611,2612]:
 for x in old['files'][i]['admission03_scope_observations']:assert orig[x['row_1based']-1]==x['original_record']
file=next(Path(x['path']) for x in links if x['path'].endswith('/additional-contracts.jsonl.gz'));records=[json.loads(x) for x in gun(file).splitlines()];ids={e['id'] for e in records};assert {'RIG-ADMISSION03-ADDITIONAL-056','RIG-ADMISSION03-ADDITIONAL-057'}<=ids
prior=load(pub/'ASSESSMENT-HELMET-FOOTWEAR-95E.json');support={x['path']:x for x in prior['current_supporting_sources']}
for i,tail in [(2611,'helmet_crown.rs'),(2612,'helmets_buffe.rs')]:
 x=next(v for k,v in support.items() if k.endswith('/'+tail));assert x['sha256']==old['files'][i]['sha256'] and gun(pub/x['preserved_bytes'])==(b/f'sources/{i}-current.rs').read_bytes()
assert any(x['id']=='REVIEW-BUFFE-BREATH-COURSE-CONTEXT-95E' for x in prior['new_current_candidates'])
proof=load(b/'git-proofs.json');objects={}
for key,x in proof['objects'].items():
 raw=gun(b/x['preserved_bytes']);assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==key;objects[key]=raw
for rev,e in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==e['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
for p in proof['paths']:
 curr=proof['commits'][p['revision']]['root_tree'];parts=p['path'].split('/');assert len(parts)==len(p['path_chain'])
 for name,s in zip(parts,p['path_chain']):
  assert s['tree']==curr and s['name']==name;mode,child=entries(objects[curr])[name];assert mode==s['mode'] and child==s['object'];curr=child
 raw=(b/p['preserved_bytes']).read_bytes();assert len(raw)==p['bytes'] and sha(raw)==p['sha256'] and oid('blob',raw)==p['git_blob']==curr
for x in r['registrations']:
 raw=(b/x['path']).read_bytes();assert sha(raw)==x['sha256'] and datetime.fromisoformat(json.loads(raw)['registered_utc'])<datetime.fromisoformat(r['recorded_utc'])
for x in r['reads']:
 data=load(b/x['registration']);m=[e for e in data['entries'] if e['archive']==x['archive'] and e['revision']==x['revision']];assert len(m)==1;e=m[0];raw=(b/x['archive']).read_bytes();assert sha(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['actual_eof']==e['actual_eof'] and x['actual_display_ranges']==e['registered_ranges'] and x['actual_display_chunks']==e['planned_chunks']
 seen={i for a,z in x['actual_display_ranges'] for i in range(a,z+1)};chunks={i for a,z in x['actual_display_chunks'] for i in range(a,z+1)};other={i for a,z in x['unread_complement_for_this_registration'] for i in range(a,z+1)};assert seen==chunks and seen.isdisjoint(other) and seen|other==set(range(1,x['actual_eof']+1))
assert len(r['reads'])==16 and sum(x['kind']=='assigned' for x in r['reads'])==4
nav=load(b/'navigation-and-rules.json')
for x in nav['navigation']:assert sha((b/x['path']).read_bytes())==x['sha256']
for x in nav['rules']:
 raw=subprocess.check_output(['git','-C',str(pub),'show','95e63628f9d70b8dd6e6fede64334696c6995009:'+x['path']]);assert sha(raw)==x['sha256'] and len(raw)==x['bytes']
assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
scopes={}
for x in r['reads']:scopes.setdefault((x['archive'],x['sha256']),set()).update(i for a,z in x['actual_display_ranges'] for i in range(a,z+1))
def visit(x):
 if isinstance(x,dict):
  if all(k in x for k in ['archive','lines','sha256']):
   a,z=x['lines'];assert set(range(a,z+1))<=scopes[(x['archive'],x['sha256'])],x
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','counts':{'git_paths':len(proof['paths']),'original_059_records':len(at['records_059']),'assigned_read_entries':4,'support_read_entries':12},'checks':['Original registry and queue reconstructions, historical 059 bytes, 774 registrations and linked additional contracts','Historical/current identical assigned bodies and raw Git path proof; preserved pr-working and dirty P16 recovery distinctions','Prospective registrations, actual personal ranges, unread complements, citations and 13 bounded perspectives','Earlier 95e support source bytes and existing breath/course finding preserved without attribution transfer','No product builds, executions, tests, rendering, simulation, fixtures, shader compilation or probes.']};raw=(json.dumps(result,indent=2)+'\n').encode()
if '--record' in sys.argv:(b/'evidence-verification.json').write_bytes(raw)
print('PASS',sha(raw),result['counts'])
