from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();rev='95e63628f9d70b8dd6e6fede64334696c6995009';specs=[('breaths','crates/fabelgeist-armor/src/visor_breaths.rs',[[116,149]]),('pierced','crates/fabelgeist-armor/src/pierced_plate_domain.rs',[[1,50]])];rows=[]
for name,path,rs in specs:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path]);eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in rs);archive='support/'+name+'.rs';p=b/archive
 if p.exists():assert p.read_bytes()==raw
 else:p.write_bytes(raw)
 blob=subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+path]).decode().strip();rows.append({'revision':rev,'path':path,'archive':archive,'sha256':sha(raw),'bytes':len(raw),'git_blob':blob,'actual_eof':eof,'registered_ranges':rs,'planned_chunks':rs,'qualification':'Separate support for earlier related cross-field boundary; no ordered role credit.'})
x={'schema':'726-helmet-pierced-extra-support-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows};raw=(json.dumps(x,indent=2)+'\n').encode();(b/'extra-registration.json').write_bytes(raw);print('sha256',sha(raw))
