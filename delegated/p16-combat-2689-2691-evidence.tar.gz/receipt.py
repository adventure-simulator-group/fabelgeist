from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
reg=load('registration.json');assigned=[]
for r in reg['rows']:
 for v in r['versions']:
  n=v['eof'];chunks=([[1,160],[161,300],[301,450],[451,540],[541,n]] if r['original_index']==2689 else [[1,n]] if r['original_index']==2690 else [[1,160],[161,n]])
  assigned.append({'original_index':r['original_index'],'source_id':r['source_id'],'identity':v['identity'],'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':n,'displayed':chunks,'unread_complement':complement(n,chunks),'qualification':'One new personal display of exact original source object or separately pinned current copy; source bodies are not replaced by 039/f82 comparison labels.'})
windows={'crates/adventuresim-tactical-server/src/combat/ingress/lunge.rs':[[1,100],[130,200]],'crates/adventuresim-tactical-client/src/player/action_clock.rs':[[1,100]],'crates/adventuresim-tactical-core/src/physics.rs':[[930,965]],'crates/adventuresim-tactical-server/src/combat/condition.rs':[[1,120]],'crates/adventuresim-tactical-server/src/combat/ingress/work.rs':[[1,50]],'crates/adventuresim-core/src/combat/fatigue.rs':[[1,263]],'crates/adventuresim-tactical-server/src/bot/offense/facts.rs':[[120,160]],'crates/fabelgeist-geometry/src/measurement.rs':[[1,85]],'crates/adventuresim-core/src/unit_interval.rs':[[1,97]],'crates/adventuresim-core/src/elapsed.rs':[[1,131]]};supports=[];regs=[]
for n in ['registration.json','support-registration.json','owners-registration.json']:
 d=load(n);regs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':d['created_utc']})
 if n!='registration.json':
  for e in d['entries']:
   r=windows[e['path']];supports.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'local':e['local'],'eof':e['eof'],'displayed':r,'unread_complement':complement(e['eof'],r),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','basis':'Each archived historical and pinned current assigned body was prospectively registered, then separately displayed untruncated in these bounded chunks. Tests are source text only, never executed. Support displays occurred after separate registrations. Earlier 774 and 059 personal reads remain at their original authors and ranges.','assigned':assigned,'support':supports,'registrations':regs,'comparison_copies':'039/f82 direct project source bodies were archived for Git identity comparison, not displayed separately; their equality to separately displayed archive/current bodies does not imply independent personal reads at those revisions.','navigation':'Before support registration only Git grep -l listed paths; after support registration grep with one line of context printed selected bodies, all included in the displayed support windows.','qualification':'Matching file at 039 is independent committed-byte evidence, not proof of original p16 reviewer workspace, snapshot identity or checkpoint3821.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
