from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objs={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objs:
  p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objs[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind):
 raw=(b/local).read_bytes();root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw)})
r=json.loads((b/'registration.json').read_bytes());f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for x in r['rows']:
 proof(x['versions'][1]['revision'],x['path'],x['versions'][1]['local'],'current assigned source')
 for c in x['comparison_git_paths']:
  if c['present']:proof(c['revision'],x['path'],c['local'],'direct project comparison only; does not establish p16 reviewer revision')
 proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['versions'][0]['sha256'],x['versions'][0]['local'],'original archived object via f82 transport, not direct project f82 identity')
for n in ['support-registration.json','owners-registration.json']:
 for x in json.loads((b/n).read_bytes())['entries']:proof(x['revision'],x['path'],x['local'],'registered bounded support; exact personal windows in read receipt')
for x in json.loads((b/'historical-manifest.json').read_bytes())['records']:
 if x.get('transport_revision'):proof(x['transport_revision'],x['git_path'],x['local'],'774 original registration or qualification via f82 transport')
d={'schema':'726-p16-combat-source-git-membership-v1','objects':objs,'proofs':proofs,'qualification':'039 project path membership proves byte identity only, not actual historical workspace revision; f82 source path conflict is preserved separately from f82 archived-object transport. Original p16 is not identified with physical-p16; 95e is current.'};(b/'git-proofs.json').write_text(json.dumps(d,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objs),'sha256',h((b/'git-proofs.json').read_bytes()))
