# P16-labeled combat roles 2689–2691

`REPORT.json` assesses the three exact original registry source objects and the
pinned `95e63628f9d70b8dd6e6fede64334696c6995009` source bodies. All six were
prospectively registered and separately displayed in full; tests were read as
source text only. `read-receipt.json` identifies every bounded personal display
and the unread complements of separately registered support.

The registry labels these original roles `p16` but has no `p16` entry in its
snapshot list. Each recovered body matches a direct project path at
`039329518e264f19206cf5b0b98d177433f40c17`; that establishes per-file identity,
not the original reviewer workspace or a clean snapshot. `physical-p16` is a
different registry label for a dirty a120-based snapshot whose complete patch
has not been recovered; no equivalence is inferred.

For the authority body, a separate 059 Lens13 receipt for physical-p16 role 382
claims a direct f82 revision, but its recorded 672-line hash differs from the
674-line direct f82 file. The f82 recovered-source object path transports the
historical bytes. `prior/PHYSICAL-P16-RECEIPT-REVISION-COMPARISON.json`, exact
old receipts and the raw commit/tree proofs retain this contradiction without
changing original attribution. No cause for the mismatch is established.

The later Lens12 933 record is a delegate proposal, not an adopted root receipt;
its exact source scopes and original attribution remain preserved. Historical
registry selections are explicitly reconstructed from the full retained files,
not original receipts. Checkpoint 3821 remains unrecovered and receives no
promoted evidence. The raw lunge-distance question is conditional and does not
establish a supported gameplay failure or a distinct unique finding.

Run `python3 verify-evidence.py` to check packet integrity offline. The root
`MANIFEST.json` covers every file except itself, including nested manifests. No
product execution, builds, tests, probes, fixtures, simulations or repairs ran.
