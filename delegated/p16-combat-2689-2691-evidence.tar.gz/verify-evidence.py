'''Offline evidence-integrity checks only; no product or test execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['original_registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);assert not any(x['id']=='p16' for x in registry['snapshots']);original=registry['files']
for i in [382,2689,2690,2691]:assert original[i]==sel['registry_rows'][str(i)]
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows']
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for x in reg['rows']:
  old=x['versions'][0];body=(b/old['local']).read_bytes();assert t.extractfile(old['sha256']).read()==body and h(body)==old['sha256']==original[x['original_index']]['sha256'];c=catalog[x['original_index']];assert c['expected_sha256']==old['sha256'] and c['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+x['path']
  for cmp in x['comparison_git_paths']:
   if cmp['present']:raw=(b/cmp['local']).read_bytes();assert h(raw)==cmp['sha256'] and (raw==body)==cmp['equals_original_object']
assert reg['rows'][0]['comparison_git_paths'][0]['equals_original_object'] and not reg['rows'][0]['comparison_git_paths'][1]['equals_original_object'];assert reg['rows'][1]['versions'][0]['sha256']==reg['rows'][1]['versions'][1]['sha256'];assert reg['rows'][2]['versions'][0]['sha256']!=reg['rows'][2]['versions'][1]['sha256']
for x in rec['registrations']:
 assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
for r in reg['rows']:
 for v in r['versions']:
  p=next(x for x in rec['assigned'] if x['original_index']==r['original_index'] and x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'];nums=[i for a,z in p['displayed']+p['unread_complement'] for i in range(a,z+1)];assert len(nums)==v['eof'] and set(nums)==set(range(1,v['eof']+1)) and p['unread_complement']==[]
planned={}
for n in ['support-registration.json','owners-registration.json']:
 for x in load(n)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];nums=[i for a,z in x['displayed']+x['unread_complement'] for i in range(a,z+1)];assert len(nums)==x['eof'] and set(nums)==set(range(1,x['eof']+1));assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
r774=[json.loads(s) for s in (b/'historical/774/source-range-registration.jsonl').read_text().splitlines()];q774=[json.loads(s) for s in (b/'historical/774/source-qualifications-final-082.jsonl').read_text().splitlines()]
for i in [2689,2690,2691]:
 for ob in original[i]['admission03_scope_observations']:
  j=ob['row_1based']-1;assert r774[j]==ob['original_record'] and q774[j]==ob['local_qualifications'][0]
assert original[2691]['admission03_scope_observations'][0]['effective_material_ranges']==[]
l11=load('historical/059/segovb/READ-L11-439.json');expected={2689:[[24,43]],2690:[[1,54]],2691:[[49,57],[88,108]]}
for i,ranges in expected.items():
 x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==ranges;name=Path(x['registration']).name;assert h((b/'historical/059/segovb'/name).read_bytes())==x['registration_sha256']
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-933.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False
for i,ranges in {2689:[[1,44]],2690:[[1,57]],2691:[[31,37],[49,57],[60,80],[88,108]]}.items():
 x=next(x for x in p['rows'] if x['original_index']==i);assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution'];name=Path(x['registration']).name;assert h((b/'historical/059/parallel-l12-20261029'/name).read_bytes())==x['registration_sha256']
l13a=load('historical/059/parallel-l13-20261029/READ-PL13-006.json');l13b=load('historical/059/parallel-l13-20261029/READ-PL13-007.json');x=next(x for x in l13a['rows'] if x.get('original')==382);y=next(x for x in l13b['rows'] if x.get('original')==382);assert x['fresh_personal_assessed_ranges']==[[1,70]] and y['fresh_personal_assessed_ranges']==[[71,672]] and x['sha256']==y['sha256']==original[2689]['sha256']
comparison=load('prior/PHYSICAL-P16-RECEIPT-REVISION-COMPARISON.json');x=next(x for x in comparison['comparisons'] if x['original_index']==382);assert x['recorded_sha256']==original[2689]['sha256'] and x['claimed_committed_body_matches_recorded']==False and x['claimed_committed_sha256']==reg['rows'][0]['versions'][1]['sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: 3 original p16-labeled objects plus separate 95e bodies; absent p16 snapshot metadata and role382 f82 direct-path conflict preserved; 774 corrections, 059 historical and later unadopted 933 proposal attribution verified; %d raw Git proofs, %d bounded supports and thirteen partial perspectives. Evidence integrity only; no product, tests, builds, fixtures or probes.'%(len(proof['proofs']),len(rec['support'])))
