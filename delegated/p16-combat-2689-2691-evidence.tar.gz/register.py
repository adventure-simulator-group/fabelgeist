from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';base=Path(repo)/'recovered/original-registry-source-archive';r=json.load(gzip.open(base/'registry.json.gz','rt'));assert not any(s['id']=='p16' for s in r['snapshots']);rev='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda x:hashlib.sha256(x).hexdigest();rows=[];pending=[]
with tarfile.open(base/'objects.tar.gz','r:gz') as tar:
 for i in [2689,2690,2691]:
  x=r['files'][i];path=x['source_id'].split(':',1)[1];old=tar.extractfile(x['sha256']).read();assert sha(old)==x['sha256'] and len(old)==x['bytes'] and len(old.splitlines())==x['actual_line_count'];local=f'source/{i}-p16-archive.rs';pending.append((local,old));entries=[{'identity':'p16 exact original registry/archive object; no recorded snapshot head','sha256':sha(old),'bytes':len(old),'eof':len(old.splitlines()),'local':local,'planned_display_ranges':[[1,len(old.splitlines())]]}]
  current=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);oid=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(current)).encode()+b'\0'+current).hexdigest()==oid;local=f'source/{i}-95e.rs';pending.append((local,current));entries.append({'identity':'pinned current','revision':rev,'sha256':sha(current),'git_blob':oid,'bytes':len(current),'eof':len(current.splitlines()),'local':local,'planned_display_ranges':[[1,len(current.splitlines())]]})
  comparisons=[]
  for comp in ['039329518e264f19206cf5b0b98d177433f40c17','f82adcabd9d89c4fa2dd7f99253a45297a0681ee']:
   proc=subprocess.run(['git','-C',repo,'show',comp+':'+path],capture_output=True);item={'revision':comp,'present':proc.returncode==0}
   if proc.returncode==0:
    raw=proc.stdout;local=f'comparison/{i}-{comp[:4]}.rs';pending.append((local,raw));item.update({'sha256':sha(raw),'bytes':len(raw),'eof':len(raw.splitlines()),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'equals_original_object':raw==old,'local':local,'display_planned':False})
   else:item['qualification']='No object bytes; verify nonmembership in Git tree independently if used.'
   comparisons.append(item)
  rows.append({'original_index':i,'source_id':x['source_id'],'path':path,'original_material_ranges':x['material_ranges'],'versions':entries,'comparison_git_paths':comparisons})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective historical archived and pinned 95e assigned role bodies, to display separately in bounded chunks; comparative Git bodies retained for identity only, not body-read credit.','snapshot_qualification':'Original registry label p16 has no matching metadata snapshot row. Do not infer p16=physical-p16 or a recorded source commit. Original recovered object hash governs; same-file Git matches are independent evidence only. f82 is original evidence transport, and direct project f82 path is distinct.','original_registry_uncompressed_sha256':sha(gzip.decompress((base/'registry.json.gz').read_bytes())),'rows':rows,'limits':'Static source and evidence integrity only; no product execution, tests, builds, repairs or probes.'};(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for name,raw in pending:
 out=b/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
print(json.dumps(d,indent=2));print('registration_sha256',sha((b/'registration.json').read_bytes()))
