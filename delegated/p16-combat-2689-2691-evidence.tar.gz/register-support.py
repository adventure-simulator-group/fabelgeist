from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-tactical-server/src/combat/ingress/lunge.rs','crates/adventuresim-tactical-client/src/player/action_clock.rs','crates/adventuresim-tactical-core/src/physics.rs','crates/adventuresim-tactical-server/src/combat/condition.rs','crates/adventuresim-tactical-server/src/combat/ingress/work.rs','crates/adventuresim-core/src/combat/fatigue.rs','crates/adventuresim-tactical-server/src/bot/offense/facts.rs'];out=[];pending=[]
for path in paths:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;local='support/'+path;out.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,len(raw.splitlines())]],'local':local});pending.append((local,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective current bounded connected producer/consumer traces, no ordered-role credit; exact actual display windows and complements to follow. Filename-only Git grep preceded registration; no support source body was displayed by that search. Other earlier agent receipts remain independent.','entries':out};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('sha256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
