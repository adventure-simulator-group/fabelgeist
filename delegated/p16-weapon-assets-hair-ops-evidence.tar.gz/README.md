# Roles 2591–2592: P16 weapon and equipment-asset evidence

This packet is a bounded source assessment, authored by `/root/hair_ops`, for
central review. `REPORT.json` describes source facts, historical attributions,
conditions, open questions, and all thirteen bounded lens perspectives.
`read-receipt.json` records the separately displayed P16 and 95e bodies and
exact support read ranges. It does not transfer earlier review credit.

`registration.json` and the support registrations predate the corresponding
source displays. `source/` and `support/` retain exact registered bytes;
`git-proofs.json` and `git-objects/` reconstruct Git membership without Git.
The `historical/` directory distinguishes exact original receipts from
reconstructed selections containing exact original row bytes. Its reconstructed
static source diff is not a historical artifact.

The historical source registry, source archive, full selected historical
records, prior assessments and P16 tracked patch are hash-linked by absolute
path in `historical-manifest.json` and the selected-row wrappers. To publish a
standalone recovery, preserve these exact linked bytes or relink them by the
recorded hashes. The P16 snapshot is dirty; the two assigned P16 files' equality
to clean-base blobs is only per-file evidence. The later hash-matching tracked
patch does not prove its original generation command or uninterrupted custody.

`python3 verify-evidence.py` performs evidence-integrity checks only. No
product code, build, tests, fixture, runtime probe, repair or product validation
was performed. The manifest hashes all packet files other than itself.
