from pathlib import Path
import hashlib,json,subprocess
p=Path('<LOCAL_PATH_0>'); root=Path('<LOCAL_PATH_1>'); repo='<LOCAL_PATH_2>'; rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'; digest=lambda b:hashlib.sha256(b).hexdigest(); selected=[]
for name,needle in [('source-range-registration.jsonl','CAMERA-ADM03-REG012-physical-p16'),('source-qualifications-final-current.jsonl','CAMERA-ADM03-REG012-physical-p16'),('additional-sources.jsonl','CAMERA-ADM03-REG012-physical-p16'),('contracts.jsonl','CAMERA-ADM03-057')]:
 path=root/name; data=path.read_bytes(); gp='handoff/774/adler-original/audit/continuation/camera/admission03/'+name; remote=subprocess.check_output(['git','-C',repo,'show',rev+':'+gp]); assert data==remote
 lines=data.splitlines(keepends=True); hits=[(i,b) for i,b in enumerate(lines,1) if json.loads(b).get('id',json.loads(b).get('registration_id'))==needle];assert len(hits)==1
 i,b=hits[0];selected.append({'source_path':str(path),'source_revision':rev,'source_git_path':gp,'source_sha256':digest(data),'source_bytes':len(data),'row_1based':i,'raw_utf8':b.decode(),'row_sha256':digest(b)})
(p/'historical/774-camera-selection-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed wrapper preserving exact row bytes; full original files remain hash-linked. No credit beyond original reviewer scope.','rows':selected},indent=2)+'\n')
print('camera historic selected',len(selected))
