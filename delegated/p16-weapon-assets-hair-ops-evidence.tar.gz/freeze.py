import hashlib,json,subprocess,datetime
from pathlib import Path
p=Path('<LOCAL_PATH_0>');sha=lambda b:hashlib.sha256(b).hexdigest()
proc=subprocess.run(['python3',str(p/'verify-evidence.py')],capture_output=True,text=True,check=True)
(p/'evidence-verification.json').write_text(json.dumps({'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'python3 verify-evidence.py','exit_code':proc.returncode,'stdout':proc.stdout,'scope':'Evidence integrity only; no product execution, build, test, repair, simulation or validation.'},indent=2)+'\n')
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='MANIFEST.json':
  b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':sha(b)})
(p/'MANIFEST.json').write_text(json.dumps({'kind':'Frozen bounded evidence packet; hash-linked dependencies are separately recorded in historical-manifest and selected history wrappers.','files':files},indent=2)+'\n')
proc=subprocess.run(['python3',str(p/'verify-evidence.py')],capture_output=True,text=True,check=True)
print(proc.stdout.strip());print('report_sha256',sha((p/'REPORT.json').read_bytes()));print('manifest_sha256',sha((p/'MANIFEST.json').read_bytes()));print('files',len(files),'local_bytes',sum(x['bytes'] for x in files))
