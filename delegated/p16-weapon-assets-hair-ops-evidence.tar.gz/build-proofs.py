import gzip,hashlib,json,subprocess,datetime
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());s1=json.loads((p/'support-registration.json').read_bytes());s2=json.loads((p/'support-registration-2.json').read_bytes());hist=json.loads((p/'historical-manifest.json').read_bytes());pr=json.loads((p/'pr-file-comparison.json').read_bytes());objects={};proofs=[];(p/'git-objects').mkdir()
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for x in reg['rows']:
 n=x['role'];members.extend([{'revision':reg['p16_transport'],'path':x['f82_transport_object'],'local':f'source/p16-{n}.rs','qualification':'Historical P16 evidence object; not whole clean snapshot.'},{'revision':reg['p16_base'],'path':x['path'],'local':f'source/p16-{n}.rs','qualification':'P16 clean-base per-file equality.'},{'revision':reg['source_revision'],'path':x['path'],'local':f'source/95e-{n}.rs','qualification':'Pinned current source personally displayed.'}])
for x in pr['rows']:members.append({'revision':x['revision'],'path':x['path'],'local':f"source/95e-{x['role']}.rs",'qualification':'6533 per-file identity only, not new 6533 body read.'})
for x in s1['sources']+s2['sources']:members.append({'revision':x['revision'],'path':x['path'],'local':x['saved'],'qualification':'95e source support only.'})
members.append({'revision':'6533e444fa37552927070cc8d8190907fd3b413e','path':s1['sources'][0]['path'],'local':'support/0.rs','qualification':'Selection module same 6533/current blob; only 95e copy personally displayed.'})
for x in hist['exact_original_files']:
 if x.get('transport_revision'):members.append({'revision':x['transport_revision'],'path':x['git_path'],'local':x['local'],'qualification':'Original 774 reviewer record; attribution retained.'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();top=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert tree==blob(b);proofs.append({**s,'commit_tree':top,'chain':chain,'blob':tree,'sha256':sha(b)})
rev=reg['p16_base'];target='crates/adventuresim-core/src/equipment_assets/selection.rs';tree=obj('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[];parts=target.split('/')
for j,name in enumerate(parts):
 ent=entries(obj('tree',tree))
 if name not in ent:
  missing={'revision':rev,'target':target,'commit_tree':root,'chain':chain,'missing_name':name,'missing_at_tree':tree,'remaining_parts':parts[j+1:],'qualification':'Nonmembership at clean a120 base only; original P16 dirty registry and later live observation are separate.'};break
 mode,child=ent[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
else:raise AssertionError('expected absence')
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Per-file f82 source/receipt and a120,6533,95e Git memberships; selection nonmembership is clean-base evidence, not whole P16 state.','objects':objects,'proofs':proofs,'selection_base_nonmembership':missing},indent=2)+'\n')
windows={'support/0.rs':[[1,170]],'support/1.rs':[[1,65]],'support/2.rs':[[50,105],[130,210],[700,760]],'support/3.rs':[[1,16]],'support/4.rs':[[1,59]],'support/5.rs':[[175,230]],'support/6.rs':[[1,47]],'support/7.rs':[[50,100]]}
def complement(n,ranges):
 used=set()
 for a,b in ranges:used.update(range(a,b+1))
 arr=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):arr.append([start,i-1]);start=None
 return arr
reads=[]
for x in s1['sources']+s2['sources']:
 w=windows[x['saved']];reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['lines'],'actual_display_ranges':w,'unread_complement':complement(x['lines'],w),'qualification':'Support only; prior/other ordered-role attribution retained. Any test source displayed as text was not run.'})
rr={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in ['registration.json','support-registration.json','support-registration-2.json']],'assigned_roles':[{'index':x['role'],'historical_p16_source':f"source/p16-{x['role']}.rs",'historical_eof':x['p16_eof'],'historical_display_ranges':[[1,x['p16_eof']]],'historical_unread':[],'current_95e_source':f"source/95e-{x['role']}.rs",'current_eof':x['base_and_current'][1]['eof'],'current_display_ranges':[[1,x['base_and_current'][1]['eof']]],'current_unread':[],'prior_774_rig_material':x['original_registry_record']['material_ranges'],'original_snapshot_field':x['original_registry_record']['snapshot'],'source_id':x['original_registry_record']['source_id'],'qualification':'P16 and 95e copies personally displayed separately after registration; 6533 and a120 versions hash/Git verified only. 2592 P16 ends at 106, current ends at 107.'} for x in reg['rows']],'support_reads':reads,'navigation':'Filename and symbol navigation outside the reported windows is not claimed as assessed body coverage.','qualification':'Historical/current reads are separate; role2740 and other prior author scopes remain distinct. No product, build, test, fixture, probe or runtime.'}
(p/'read-receipt.json').write_text(json.dumps(rr,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'base missing',missing['missing_name'],'support',len(reads))
