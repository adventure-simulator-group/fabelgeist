'''Offline evidence-integrity checks only; no product, build, test, fixture or runtime execution.'''
import gzip,hashlib,json,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
load=lambda f:json.loads((p/f).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');pr=load('pr-file-comparison.json')
for x in hist['hash_links']:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
for x in hist['exact_original_files']:
 b=(p/x['local']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and Path(x['source_path']).read_bytes()==b
for x in rec['prospective_registrations']:assert sha((p/x['path']).read_bytes())==x['sha256']
archive=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/objects.tar.gz')));assert sha(archive.read_bytes())==reg['registry_source_archive_sha256']
registry_path=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/registry.json.gz')));registry_bytes=gzip.decompress(registry_path.read_bytes());assert sha(registry_bytes)==reg['registry_sha256'];original=json.loads(registry_bytes)
with tarfile.open(archive,'r:gz') as tar:
 for i,x in enumerate(reg['rows']):
  old=(p/f"source/p16-{x['role']}.rs").read_bytes();new=(p/f"source/95e-{x['role']}.rs").read_bytes();assert original['files'][x['role']]==x['original_registry_record'];assert old==tar.extractfile(x['p16_sha256']).read() and sha(old)==x['p16_sha256'] and len(old)==x['p16_bytes'] and len(old.splitlines())==x['p16_eof'];c=x['base_and_current'][1];assert sha(new)==c['sha256'] and len(new)==c['bytes'] and len(new.splitlines())==c['eof'] and (old==new)==c['equal_p16_object']; assert (old==new)==pr['rows'][i]['matches_p16'] and sha(new)==pr['rows'][i]['sha256']
  rr=rec['assigned_roles'][i];assert rr['historical_display_ranges']==[[1,x['p16_eof']]] and rr['current_display_ranges']==[[1,c['eof']]] and rr['historical_unread']==rr['current_unread']==[]
assert (p/'source/p16-2591.rs').read_bytes()==(p/'source/95e-2591.rs').read_bytes()
assert (p/'source/p16-2592.rs').read_bytes()!=(p/'source/95e-2592.rs').read_bytes()
support=sum([load(n)['sources'] for n in ['support-registration.json','support-registration-2.json']],[]);by={x['saved']:x for x in support}
for x in rec['support_reads']:
 b=(p/x['saved']).read_bytes();s=by[x['saved']];assert sha(b)==x['sha256']==s['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==x['eof']==s['lines']
 used=[]
 for a,z in x['actual_display_ranges']+x['unread_complement']:
  assert 1<=a<=z<=x['eof'];used.extend(range(a,z+1))
 assert len(used)==x['eof'] and set(used)==set(range(1,x['eof']+1))
 for a,z in x['actual_display_ranges']:assert any(ra<=a<=z<=rz for ra,rz in s['prospective_ranges'])
objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 return None
for x in proof['proofs']:
 current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for st in x['chain']:
  assert current==st['tree'];assert lookup(objects[current],st['name'])==(st['mode'],st['object']);current=st['object']
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and sha(b)==x['sha256']
x=proof['selection_base_nonmembership'];current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
for st in x['chain']:
 assert current==st['tree'] and lookup(objects[current],st['name'])==(st['mode'],st['object']);current=st['object']
assert current==x['missing_at_tree'] and lookup(objects[current],x['missing_name']) is None
rr=[json.loads(l) for l in (p/'historical/774-rig--admission03--source-range-registration.jsonl').read_text().splitlines()];qq=[json.loads(l) for l in (p/'historical/774-rig--admission03--source-qualifications.jsonl').read_text().splitlines()]
for x in reg['rows']:
 for ob in x['original_registry_record']['admission03_scope_observations']:assert rr[ob['row_1based']-1]==ob['original_record'] and all(q in qq for q in ob['local_qualifications'])
sel=load('historical/774-contract-selection-reconstructed.json');b=Path(sel['source_path']).read_bytes();assert len(b)==sel['source_bytes'] and sha(b)==sel['source_sha256'];lines=b.splitlines(keepends=True)
for x in sel['rows']:assert lines[x['row_1based']-1]==x['raw_utf8'].encode() and sha(lines[x['row_1based']-1])==x['sha256']
for x in load('historical/774-camera-selection-reconstructed.json')['rows']:
 b=Path(x['source_path']).read_bytes();assert len(b)==x['source_bytes'] and sha(b)==x['source_sha256'];line=b.splitlines(keepends=True)[x['row_1based']-1];assert line==x['raw_utf8'].encode() and sha(line)==x['row_sha256']
ob=reg['rows'][0]['original_registry_record']['admission03_increment077_role_observations'][0];camera=load('historical/774-camera-selection-reconstructed.json')['rows'];assert json.loads(camera[0]['raw_utf8'])==ob['original_record'] and json.loads(camera[1]['raw_utf8'])==ob['local_qualifications'][0]
sel=load(hist['prior_queue_selection']);b=Path(sel['source_path']).read_bytes();assert sha(b)==sel['source_sha256'];q=json.loads(b)
for x in sel['rows']:assert q['entries'][x['index']]==x['entry']
sel=load(hist['role2740_selection']);assert sel['original_registry_sha256']==sha(registry_bytes) and original['files'][sel['index']]==sel['entry']
if (p/'MANIFEST.json').exists():
 for x in load('MANIFEST.json')['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
print(f"Evidence integrity passed: two old/current role objects, {len(proof['proofs'])} Git membership proofs and clean-base nonmembership, {len(rec['support_reads'])} support partitions, original registry and rig/camera historical records, selected 059 entries and linked evidence. No product execution or validation.")
