import gzip,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';j=json.loads((p/'git-proofs.json').read_bytes());objs=j['objects'];sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]); assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objs:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objs[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
cam=json.loads((p/'historical/774-camera-selection-reconstructed.json').read_bytes())['rows'];hist=json.loads((p/'historical-manifest.json').read_bytes())['original_774_contract_file'];members=[{'revision':x['source_revision'],'path':x['source_git_path'],'local':x['source_path'],'qualification':'Hash-linked exact full 774 camera original file; no new historical source credit.'} for x in cam];members.append({'revision':hist['revision'],'path':hist['git_path'],'local':hist['path'],'qualification':'Hash-linked exact full 774 rig contract file; exact rows are retained locally.'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();top=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=Path(s['local']).read_bytes();assert tree==blob(b);j['proofs'].append({**s,'commit_tree':top,'chain':chain,'blob':tree,'sha256':sha(b)})
(p/'git-proofs.json').write_text(json.dumps(j,indent=2)+'\n');print('proofs',len(j['proofs']),'objects',len(objs))
