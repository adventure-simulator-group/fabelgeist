import gzip,hashlib,json,pathlib
b=pathlib.Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
oid=lambda kind,x:hashlib.sha1(kind.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
report=json.loads((b/'REPORT.json').read_bytes());h=json.loads((b/'history-manifest.json').read_bytes());tm=(b/'original-transport-manifest.json.gz').read_bytes();m=json.loads(gzip.decompress(tm));idx={x['path']:x for x in m['entries']};assert sha(tm)==h['original_transport_manifest_sha256']
for e in h['original_059_records']:
 raw=(b/e['preserved_bytes']).read_bytes();x=idx[e['original_path']];assert len(raw)==e['bytes']==x['bytes'] and sha(raw)==e['sha256']==x['sha256'] and oid('blob',raw)==e['git_blob']==x['git_blob'],e['original_path']
for e in h['older_774_receipts']:
 raw=(b/e['preserved_bytes']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob'],e['transport_path']
for name in ['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json','historical-support-registration.json']:
 raw=(b/name).read_bytes();assert sha(raw)==report['registrations'][name]['sha256'];reg=json.loads(raw)
 for e in reg['entries']:
  p=(b/'sources'/e['revision'][:4]/e['path']) if name=='registration.json' else ((b/'historical-support'/e['path']) if name=='historical-support-registration.json' else (b/'support'/e['path']))
  raw=p.read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob'],e['path']
for e in report['original_roles']:
 assert (b/e['current_source']).read_bytes()==(b/e['historical_source']).read_bytes()
 assert e['current_displayed_ranges']==e['historical_displayed_ranges']
expected={'queue':'2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08','ledger':'3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac'}
for name,v in expected.items():assert sha(gzip.decompress((b/('original-059-'+name+'.json.gz')).read_bytes()))==v
selection=json.loads((b/'registry-selection-reconstructed.json').read_bytes());regzip=(b/selection['exact_registry_gzip']).read_bytes();assert sha(regzip)==selection['exact_registry_gzip_sha256'];registry=json.loads(gzip.decompress(regzip))
for i,row in enumerate(selection['rows'],2349):assert row['original_index']==i and {k:v for k,v in row.items() if k!='original_index'}==registry['files'][i]
proof=json.loads((b/'git-proofs.json').read_bytes());objects={}
for k,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==k;objects[k]=raw
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
oldrec={e['transport_path']:e for e in h['older_774_receipts']}
for e in proof['paths']:
 c=proof['commits'][e['revision']];assert objects[c['commit_object']].splitlines()[0]==b'tree '+c['root_tree'].encode();current=c['root_tree']
 for link in e['path_chain']:
  assert link['tree']==current;mode,child=entries(objects[current])[link['name']];assert mode==link['mode'] and child==link['object'];current=child
 assert current==e['git_blob'] and '/'.join(link['name'] for link in e['path_chain'])==e['path']
 kind=e['kind'];path=e['path']
 if kind=='original role':raw=(b/'sources'/e['revision'][:4]/path).read_bytes()
 elif kind in ['bounded support','historical support identity only, no body-read credit']:raw=(b/'support'/path).read_bytes()
 elif kind=='bounded historical support':raw=(b/'historical-support'/path).read_bytes()
 elif kind=='older historical 774 transport record':raw=(b/oldrec[path]['preserved_bytes']).read_bytes()
 else:raise AssertionError(kind)
 assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
vers=json.loads((b/'support-version-qualification.json').read_bytes())['rows'];assert len(vers)==24
for v in vers:
 rows=[e for e in proof['paths'] if e['path']==v['path'] and e['revision']==v['historical_revision']]
 assert len(rows)==1 and rows[0]['sha256']==v['historical_sha256']
 assert (v['relation']=='byte-identical')==(v['historical_sha256']==v['current_sha256'])
assert not h['unavailable_original_records'] and len(report['thirteen_lens_dispositions'])==13
print('Evidence integrity passed:',len(h['original_059_records']),'exact original 059 records,',len(h['older_774_receipts']),'774 transport originals/variants,',len(proof['paths']),'Git path proofs,',len(proof['objects']),'raw commit/tree objects, registered source bytes, historical/current source comparisons, registry selection and 059 queue/ledger. No product tests or probes.')
