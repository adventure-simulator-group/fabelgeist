import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(reg['files'][e['original_index']]==e['row'] for e in sel['rows']);assert [e['original_index'] for e in sel['rows']]==[2370,2371]
rel=load('registry-related-reconstructed.json');assert all(reg['files'][int(k)]==v for k,v in rel['roles'].items());assert rel['snapshots']==[s for s in reg['snapshots'] if s['id'] in ('pr-working','physical-p16')];assert reg['files'][458]['sha256']==reg['files'][2370]['sha256'] and reg['files'][459]['sha256']==reg['files'][2371]['sha256']
t=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(t)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';m={e['path']:e for e in json.loads(gzip.decompress(t))['entries']};q=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(q)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(q);assert all(queue['entries'][int(k)]==v for k,v in load('queue-selection-reconstructed.json')['entries'].items())
for n in ('reference-index.json','rules.json','skills.json'):
 for e in load(n)['records']:assert sha((p/e['file']).read_bytes())==e['sha256'],e['file']
groups=[('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('support2','support2-registration.json','support2-read-receipt.json'),('support3','support3-registration.json','support3-read-receipt.json')]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert (sha(body),blob(body),len(body.splitlines()))==(a['sha256'],a['git_blob'],a['EOF']);assert a['sha256']==b['sha256'] and a['archive']==b['source'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};beyond={i for lo,hi in b['registered_nonexistent_ranges'] for i in range(lo,hi+1)};assert seen==planned&set(range(1,a['EOF']+1)) and beyond==planned-set(range(1,a['EOF']+1));assert seen|missing==set(range(1,a['EOF']+1)) and not seen&missing
 counts[name]=len(r['entries'])
r=load('registration.json');assert len(r['entries'])==4 and all(c['all_equal_per_file'] for c in r['comparisons'])
for e in r['entries']:
 row=reg['files'][e['original_index']];assert e['source_id']==row['source_id'] and e['snapshot']==row['snapshot']=='pr-working' and e['sha256']==row['sha256'] and e['EOF']==({2370:930,2371:2102}[e['original_index']])
a=load('support3-registration.json')['entries'][0];b=load('support3-read-receipt.json')['entries'][0];assert a['tag']=='site-context' and a['EOF']==40 and a['registered_ranges']==[[1,80]] and b['displayed_chunks']==[[1,40]] and b['registered_nonexistent_ranges']==[[41,80]]
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  a=m[e['transport_path']];assert (a['bytes'],a['sha256'],a['git_blob'])==(len(b),sha(b),blob(b))
h=p/'history-059';x=json.loads((h/'adler/READ-L11-382.json').read_bytes());y=json.loads((h/'adler/READ-L11-383.json').read_bytes());assert x['sources'][1]['fresh_reads']==[[1,930]] and y['sources'][0]['fresh_reads']==[[1,2102]];assert x['sources'][1]['registration_sha256']==sha((h/'adler/REGISTRATION-ADLER-1239.json').read_bytes()) and y['sources'][0]['registration_sha256']==sha((h/'adler/REGISTRATION-ADLER-1240.json').read_bytes());assert json.loads((h/'adler/REGISTRATION-ADLER-1238.json').read_bytes())['ranges']==[[1,935]]
for batch,role,partial,fresh in [(784,2370,[[1,385]],[[386,930]]),(785,2371,[[1,975]],[[976,2102]])]:
 ad=json.loads((h/f'segovb/READ-L12-{batch}.json').read_bytes());row=ad['rows'][0];assert row['original_index']==role and row['fresh_personal_body_reads']==fresh and row['qualified_same_agent_previous_partial']['personal_ranges_used_for_original']==partial;assert row['qualified_same_agent_previous_partial']['sha256']==sha((h/row['qualified_same_agent_previous_partial']['path']).read_bytes());assert row['registration_sha256']==sha((h/row['registration']).read_bytes());assert ad['proposal_sha256']==sha((h/ad['proposal']).read_bytes())
r=load('history-reconciliation.json');assert len(r['entries'])==9
for e in r['entries']:
 b=gzip.decompress((p/e['file']).read_bytes());record=json.loads(b.splitlines()[e['transport_line_one_based']-1]) if e['transport_line_one_based'] else json.loads(b);row=reg['files'][e['role']]
 if e['kind']=='owner':assert record['source_id']==row['source_id'] and record['read_ranges']==e['recorded_ranges']
 else:
  v=record
  for k in e['pointer'].strip('/').split('/'):v=v[int(k)] if isinstance(v,list) else v[k.replace('~1','/').replace('~0','~')]
  assert v==next(z for z in row['producer_reached_contract_observations'] if z['receipt']==e['receipt'])['source_context']
files=load('historical-index.json')['records'];f=next(e for e in files if e['transport_path'].endswith('producer-supplement-after-owner/rig/findings.jsonl'));x=[json.loads(l) for l in gzip.decompress((p/f['file']).read_bytes()).splitlines()];assert x[20]['id']=='RIG-PPS-F021'
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==23;report=load('report.json');assert len(report['lens_perspectives'])==13 and len({e['lens'] for e in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','scope':'Offline original registry and dirty-snapshot identities, exact 059 transport/reader scopes and strict EOF, 774 source records, independent prospective registration and actual read/unread partition, site-context EOF deviation and raw Git commit/tree proofs. No product validation.','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(files),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
