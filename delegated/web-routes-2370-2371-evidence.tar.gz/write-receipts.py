import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
chunks={'2370-historical':[[516,600],[601,680],[681,760],[761,840],[841,903]],'2370-current':[[516,600],[601,680],[681,760],[761,840],[841,903]],'2371-historical':[[710,770],[771,822],[902,970],[971,1040],[1041,1110],[1111,1180],[1181,1250],[1251,1320],[1321,1390],[1391,1411]],'2371-current':[[710,770],[771,822],[902,970],[971,1040],[1041,1110],[1111,1180],[1181,1250],[1251,1320],[1321,1390],[1391,1411]]}
for reg,dst in [('registration.json','personal-read-receipt.json'),('support-registration.json','support-read-receipt.json'),('support2-registration.json','support2-read-receipt.json'),('support3-registration.json','support3-read-receipt.json')]:
 x=json.loads((p/reg).read_bytes());out=[]
 for e in x['entries']:
  if reg=='registration.json':scope=chunks[f"{e['original_index']}-{e['label']}"]
  elif reg=='support-registration.json':scope=([[180,240],[241,300],[301,350],[904,930]] if e['original_index']==2370 else [[823,901],[1412,1505],[1550,1604]])
  elif reg=='support3-registration.json' and e['tag']=='sites':scope=[[1,70],[71,135]]
  else:scope=[[lo,min(hi,e['EOF'])] for lo,hi in e['registered_ranges'] if lo<=e['EOF']]
  vals={i for lo,hi in scope for i in range(lo,hi+1)};missing=sorted(set(range(1,e['EOF']+1))-vals);g=[]
  for i in missing:
   if not g or i>g[-1][1]+1:g.append([i,i])
   else:g[-1][1]=i
  beyond=[[max(lo,e['EOF']+1),hi] for lo,hi in e['registered_ranges'] if hi>e['EOF']];out.append({'source':e['archive'],'sha256':e['sha256'],'revision':e['revision'],'displayed_chunks':scope,'unread_complement':g,'registered_nonexistent_ranges':beyond})
 y={'author':'/root/mhr_character','receipt_utc':at,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':out,'qualification':'Personally displayed numbered untruncated source views after prospective registration. The site-context support request 1–80 ended at actual EOF40; requested lines41–80 do not exist and receive no coverage. No other author read credit transferred.'};(p/dst).write_text(json.dumps(y,indent=2)+'\n');print(dst,sha((p/dst).read_bytes()))
