import gzip,json,pathlib
p=pathlib.Path(__file__).parent;reg=json.load(open(p/'registry-selection-reconstructed.json'))['rows'];idx=json.load(open(p/'historical-index.json'))['records'];out=[]
for r in reg:
 row=r['row'];eof=930 if r['original_index']==2370 else 2102
 for x in row.get('owner_contract_proofs',[]):
  z=next(y for y in idx if y['transport_path'].endswith(x['record']));rr=json.loads(gzip.decompress((p/z['file']).read_bytes()).splitlines()[x['row']]);assert rr['source_id']==row['source_id'] and rr['read_ranges']==x['read_ranges'];beyond=[[max(lo,eof+1),hi] for lo,hi in x['read_ranges'] if hi>eof];out.append({'role':r['original_index'],'kind':'owner','supplier':x['supplier'],'recorded_row_zero_based':x['row'],'transport_line_one_based':x['row']+1,'file':z['file'],'recorded_ranges':rr['read_ranges'],'nonexistent_ranges':beyond,'recorded_read_status':x['read_status']})
 for x in row.get('producer_reached_contract_observations',[]):
  z=next(y for y in idx if y['transport_path'].endswith(x['record']));b=gzip.decompress((p/z['file']).read_bytes());ls=b.splitlines() if x['record'].endswith('.jsonl') else [b];matches=[(i,json.loads(l)) for i,l in enumerate(ls,1) if json.loads(l).get('id')==x['receipt'] or json.loads(l).get('trace_id')==x['receipt']];
  if not matches and len(ls)==1:matches=[(1,json.loads(b))]
  assert len(matches)==1;line,v=matches[0]
  for k in x['json_pointer'].strip('/').split('/'):v=v[int(k)] if isinstance(v,list) else v[k.replace('~1','/').replace('~0','~')]
  assert v==x['source_context'];out.append({'role':r['original_index'],'kind':'producer','receipt':x['receipt'],'file':z['file'],'transport_line_one_based':line if x['record'].endswith('.jsonl') else None,'pointer':x['json_pointer'],'recorded_ranges':x['read_ranges_as_recorded'],'source_context_exact_match':True})
(p/'history-reconciliation.json').write_text(json.dumps({'entries':out,'qualification':'Original historical records agree at selected pointers; camera owner raw 899–935 includes nonexistent 931–935 at EOF930. Separately preserved Adler/Lens12 EOF qualifications do not amend older record bytes; continuation joined RIG038 rather than claiming another fresh full read.'},indent=2)+'\n');print('reconciled',len(out))
