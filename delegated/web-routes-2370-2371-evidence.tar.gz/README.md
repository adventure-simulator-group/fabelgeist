# Bounded strategic-web route review

`report.json` records the current and historical identity, thirteen scoped
perspectives, reconciled older findings, a conditional availability refinement,
and open questions. `registration.json` and `personal-read-receipt.json`
record independent historical and current displays of role 2370 lines 516–903
and role 2371 lines 710–822 and 902–1411. The remaining assigned bodies are
unread under that registration. Current-only support receipts preserve exact
additional ranges and unread complements.

One support registration requested `site_context.rs` lines 1–80, but its exact
EOF is 40. The numbered display stopped at line 40; nonexistent lines 41–80
receive no coverage. The older camera owner record separately requested
`routes/mod.rs` 899–935, while the file ends at 930; its original bytes and
subsequent strict EOF qualification remain distinct.

`source/` and `support/` archive exact source bytes; full archived bytes do not
imply full personal reading. `git-proofs.json` and `git-objects/` prove f82
historical transport, per-file 6533 membership, and pinned 95e membership.
The recorded pr-working snapshot contains unrelated changes; per-file equality
does not make that historical tree clean. `history-059/` holds exact original
transport-manifest-matched records, `history-774/` contains f82 tree-bound
records, and registry/queue selections are explicitly reconstructed subsets.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` to verify
evidence integrity only. No product, test, fixture, build, browser, simulation,
probe, repair or runtime validation occurred. Central review owns aliases,
source-role disposition, counts, ledger, and checkpoint publication; these
records are not the unrecovered checkpoint 3821 ledger.
