from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
specs=[(2843,'crates/fabelgeist-armor/src/gpu/coif_drape.rs','f9ccb3bf0662590f4dd34ea6de4ce89569348359037efc93e3736a9524c3bca1',[[1,12]]),(2844,'crates/adventuresim-character-creator/src/hair/scalp_map.rs','717bbedb859bc7b5df413aeea35d20cccbdf1e08dc53f2f8d692b72dc2cc662e',[[1,147]]),(2845,'crates/adventuresim-character-creator/src/hair/gpu/mod.rs','f8844fc7362364c5217079615e4459865865020ba4a36f5b25a8997cdd9c8f92',[[1,138]])]
e=[]
for role,path,h,ranges in specs:
 for name,rev in [('historical',old),('current',cur)]:
  raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);assert hashlib.sha256(raw).hexdigest()==h;dest=f'sources/{role}-{name}.rs';(b/dest).write_bytes(raw);tpath='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+h
  if name=='historical': assert subprocess.check_output(['git','-C',repo,'show',f82+':'+tpath])==raw
  e.append({'id':f'{role}-{name}','role':role,'revision':rev,'git_path':path,'archive':dest,'sha256':h,'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),'bytes':len(raw),'eof':len(raw.splitlines()),'prospective_personal_read_ranges':ranges,'transport_revision':f82 if name=='historical' else None,'transport_path':tpath if name=='historical' else None,'qualification':'Separate individual revision role read; 2843 is prefix 1–12 only. Old snapshot has unrelated modifications; no shader, GPU, test or fixture execution.'})
(b/'registration.json').write_text(json.dumps({'schema':'726-coif-scalp-hair-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':e},indent=2)+'\n')
