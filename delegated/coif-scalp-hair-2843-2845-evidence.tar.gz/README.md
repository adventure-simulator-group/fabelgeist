# Roles 2843–2845: bounded source and evidence packet

`REPORT.json` contains independently registered and displayed historical and
current coif, scalp-map, and hair-GPU source scopes, bounded support, preserved
review relationships, conditional questions and thirteen scoped perspectives.
This is not a claim of whole-lens completion. The three individual role objects
match 6533 and 95e; the historical pr-working snapshot had unrelated changes.
Role 2843 personally covers only lines 1–12 of a 72-line file.

`registration.json` and `support-registration*.json` are prospective source
registrations. Their `read-receipt*.json` and `support-read-receipt*.json` give
exact personal display ranges and unread complements. Full archived bytes outside
those ranges do not grant read credit. Shader and test references are text only.

`history/` preserves the original registry and transport manifest, six original
059 extraction records matched to that manifest, mechanically compressed 059
summaries, six 774 transport records with separately proved Git membership, and
the earlier published 95e hair-GPU assessment. The registry records two earlier
registration whole-file hashes distinct from the f82 transport version. Selected
rows 44–46 match exactly; cause of the whole-file differences is unknown. The
selected registry is explicitly reconstructed metadata, not original checkpoint
3821 coverage or a recovery of its missing queue or ledger.

`git-proofs.json` and `git-objects/` preserve the source and historical transport
commit/tree path proofs. `verify-evidence.py` checks hashes, Git object paths,
registered versus displayed source partitions, linked historical scopes, and
report references. `MANIFEST.json` hashes the packet members and
`verify-manifest.py` verifies them. These are evidence checks only; no product,
shader, GPU, test, fixture, render, build or runtime probe was performed.
