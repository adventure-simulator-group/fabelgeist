from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';(b/'support').mkdir(exist_ok=True)
specs=[('device-coif','crates/adventuresim-character-creator/src/device_coif.rs',[[1,45],[145,215],[275,295],[470,488]]),('groom','crates/adventuresim-character-creator/src/hair/groom.rs',[[1,115]]),('bake','crates/adventuresim-character-creator/src/hair/gpu/bake/mod.rs',[[35,60],[155,235]]),('cap','crates/adventuresim-character-creator/src/hair/cap.rs',[[65,120]]),('surface','crates/fabelgeist-hair/src/surface.rs',[[1,115]]),('head','crates/fabelgeist-hair/src/head.rs',[[65,140]])]
e=[]
for name,path,ranges in specs:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);dest='support/'+name+'.rs';(b/dest).write_bytes(raw)
 e.append({'id':name,'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),'bytes':len(raw),'eof':len(raw.splitlines()),'prospective_personal_read_ranges':ranges,'qualification':'Bounded current support only; no additional ordered-role, original reviewer or other lens credit. Static text only.'})
(b/'support-registration.json').write_text(json.dumps({'schema':'726-coif-scalp-hair-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':e},indent=2)+'\n')
