from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
specs=[('groom-tail','crates/adventuresim-character-creator/src/hair/groom.rs',[[116,195]]),('preview','crates/adventuresim-character-creator/src/hair_preview.rs',[[105,165]])]
e=[]
for name,path,ranges in specs:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);dest='support/'+name+'.rs';(b/dest).write_bytes(raw)
 e.append({'id':name,'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),'bytes':len(raw),'eof':len(raw.splitlines()),'prospective_personal_read_ranges':ranges,'qualification':'Individually registered bounded current support, not original ordered-role credit; no execution.'})
(b/'support-registration-2.json').write_text(json.dumps({'schema':'726-coif-scalp-hair-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':e},indent=2)+'\n')
