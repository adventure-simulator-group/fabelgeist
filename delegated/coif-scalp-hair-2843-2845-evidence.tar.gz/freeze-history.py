from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');ex=Path('<LOCAL_PATH_1>');rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d);return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[]
for src,dest,kind in [('recovered/original-registry-source-archive/registry.json.gz','history/original-registry.json.gz','exact recovered 059 registry'),('recovered/original-transport-manifest.json.gz','history/original-transport-manifest.json.gz','059 extraction manifest'),('ASSESSMENT-HAIR-GPU-MODULE-95E.json','history/prior-hair-gpu-module-95e.json','prior independently attributed current fabelgeist-hair GPU assessment')]:refs.append({'kind':kind,'original':src,**save((pub/src).read_bytes(),dest)})
for src,dest in [('baseline-059/queue.json','history/baseline-059-queue.json.gz'),('baseline-059/ledger.json','history/baseline-059-ledger.json.gz')]:
 raw=(pub/src).read_bytes();refs.append({'kind':'059 historical summary mechanically compressed; not checkpoint 3821','original':src,'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(gzip.compress(raw,mtime=0),dest)})
r=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()));idx={v['path']:v for v in json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()))['entries']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanical selection from preserved original registry; metadata is not read credit or checkpoint 3821.','rows':[{'original_index':i,**r['files'][i]} for i in [2843,2844,2845]],'snapshots':[x for x in r['snapshots'] if x['id']=='pr-working']},indent=2)+'\n')
paths=['segovb/READ-L11-462.json','segovb/STATE-L11-462.json','segovb/VERIFY-L11-462.json','segovb/REGISTRATION-SEGOVB-1764.json','segovb/REGISTRATION-SEGOVB-1765.json','segovb/REGISTRATION-SEGOVB-1766.json'];records=[]
for p in paths:
 raw=(ex/p).read_bytes();m=idx[p];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];records.append({'original_path':p,'git_blob':m['git_blob'],**save(raw,'history/059/'+p)})
old=[];prefix='handoff/774/adler-original/audit/continuation/'
for p in ['camera/initial07-redundant-authority/source-range-registration.jsonl','camera/initial07-redundant-authority/qualifications.jsonl','camera/initial07-redundant-authority/scope-role-coverage.jsonl','camera/initial07-redundant-authority/additional-sources.jsonl','camera/initial07-redundant-authority/contracts.jsonl','camera/initial07-redundant-authority/findings.jsonl']:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+prefix+p]);old.append({'revision':rev,'transport_path':prefix+p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+p+'.gz')})
raw=gzip.decompress((b/'history/774/camera/initial07-redundant-authority/source-range-registration.jsonl.gz').read_bytes());rows=[json.loads(x) for x in raw.splitlines()];m=[]
for i in [2843,2844,2845]:
 e=r['files'][i]['scope_registration'][0];assert rows[e['row_1based']-1]==e['original_record'];m.append({'role':i,'row':e['row_1based'],'registry_recorded_whole_file_sha256':e['sha256'],'f82_whole_file_sha256':sha(raw),'selected_row_equal':True})
out={'schema':'726-coif-scalp-hair-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_059':records,'records_774':old,'registration_file_comparison':m,'qualification':'059 selected records match extraction transport manifest size/SHA/Git blob; original 059 payload Git path unavailable in inspected collections. f82 is transport only, recorded pr-working snapshot had unrelated modifications. Registry registration whole-file hashes are historical variants and differ from this f82 file, selected rows match, cause unknown. Preserve original camera and segovb attributions and all original obligations. No evidence promoted to checkpoint 3821.'}
(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('refs',len(refs),'059',len(records),'774',len(old),'comparisons',m)
