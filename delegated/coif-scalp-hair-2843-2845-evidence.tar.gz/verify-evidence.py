from pathlib import Path
from datetime import datetime
import gzip,hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json')
names=['registration.json','support-registration.json','support-registration-2.json'];groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2843,2844,2845]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
for (_,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
for role,ranges in [(2843,[[1,12]]),(2844,[[1,147]]),(2845,[[1,138]])]:
 old=regs[('registration.json',str(role)+'-historical')];cur=regs[('registration.json',str(role)+'-current')];assert old['sha256']==registry['files'][role]['sha256']==cur['sha256'] and registry['files'][role]['material_ranges']==ranges and (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes()
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
r=load('history/059/segovb/READ-L11-462.json')
for role,ranges in [(2843,[[1,12]]),(2844,[[1,147]]),(2845,[[1,138]])]:
 e=next(x for x in r['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==ranges and e['sha256']==registry['files'][role]['sha256']
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
raw=gun('history/774/camera/initial07-redundant-authority/source-range-registration.jsonl.gz');rows=[json.loads(z) for z in raw.splitlines()]
for x in history['registration_file_comparison']:
 e=registry['files'][x['role']]['scope_registration'][0];assert sha(raw)==x['f82_whole_file_sha256']!=e['sha256']==x['registry_recorded_whole_file_sha256'] and rows[e['row_1based']-1]==e['original_record']
quals=[json.loads(z) for z in gun('history/774/camera/initial07-redundant-authority/qualifications.jsonl.gz').splitlines()]
qual=next(x for x in quals if x.get('id')=='CAMERA-INITIAL07-QUAL181');assert qual['source']['material_ranges']==[[1,12]]
additional=[json.loads(z) for z in gun('history/774/camera/initial07-redundant-authority/additional-sources.jsonl.gz').splitlines()]
for id,ran in [('CAMERA-INITIAL07-REG045',[[1,147]]),('CAMERA-INITIAL07-REG046',[[1,138]])]:
 e=next(x for x in additional if x.get('id')==id);assert e['material_ranges']==ran and e['actual_read_status']=='fresh_full_registered_body_read_current07'
contracts=[json.loads(z) for z in gun('history/774/camera/initial07-redundant-authority/contracts.jsonl.gz').splitlines()];assert all(any(x.get('id')==id for x in contracts) for id in ['CAMERA-INITIAL07-CONTRACT-255','CAMERA-INITIAL07-CONTRACT-267'])
findings=[json.loads(z) for z in gun('history/774/camera/initial07-redundant-authority/findings.jsonl.gz').splitlines()];assert all(any(x.get('id')==id for x in findings) for id in ['CAMERA-INITIAL07-F052','CAMERA-INITIAL07-F057'])
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
assert len(proof['paths'])==27
coverage={}
for receipt_name in ['read-receipt.json','support-read-receipt.json','support-read-receipt-2.json']:
 r=load(receipt_name);name=r['registration'];assert r['registration_sha256']==sha((b/name).read_bytes());assert datetime.fromisoformat(groups[name]['at_utc'])<datetime.fromisoformat(r['at_utc'])
 for e in r['entries']:
  x=regs[(name,e['id'])];assert e['sha256']==x['sha256'] and e['revision']==x['revision'];actual={i for a,z in e['actual_personal_display_ranges'] for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in e['unread_ranges'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage[e['id']]=actual
assert len(regs)==len(coverage)==14
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(e['id']==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','original_roles':[2843,2844,2845],'personal_scopes':len(regs),'separate_6533_and_95e_bodies':True,'059_records_manifest_matched':len(history['records_059']),'774_records_git_proved':len(history['records_774']),'registration_hash_mismatch':'preserved; selected rows match','git_paths_proved':len(proof['paths']),'bounded_lenses':13,'coif_role_2843':'only 1–12, 13–72 unread','product_build_test_fixture_execution_runtime_probe_validation':'not performed'},indent=2))
