import datetime,gzip,hashlib,json,pathlib,subprocess,difflib
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());supports=json.loads((p/'support-registration.json').read_text())['sources'];present=[{'path':role['path'],**v} for role in reg['roles'] for v in role['versions'] if v['present']]+supports;absent=[{'path':role['path'],**v} for role in reg['roles'] for v in role['versions'] if not v['present']];objdir=p/'git-objects';objdir.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=objdir/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);out[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in present:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 assert tree==x['git_blob'];b=(p/x['local_path']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'revision':rev,'path':x['path'],'archive':x['local_path'],'commit_tree':root,'chain':chain,'blob':tree})
absences=[]
for x in absent:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[];parts=x['path'].split('/')
 for name in parts[:-1]:
  mode,child=entries(get('tree',tree))[name];assert mode in ('40000','040000');chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 parent=get('tree',tree);assert parts[-1] not in entries(parent)
 absences.append({'revision':rev,'path':x['path'],'commit_tree':root,'parent_chain':chain,'parent_tree':tree,'missing_name':parts[-1]})
(p/'git-absence-proofs.json').write_text(json.dumps({'qualification':'Raw Git trees prove path nonmembership; absence does not itself prove feature removal and grants no reading credit.','proofs':absences},indent=2)+'\n')
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw Git commit/tree plus exact source bytes independently verify revision/path membership only, not source-read credit.','objects':objects,'proofs':proof},indent=2)+'\n')
for role in reg['roles']:
 vs=role['versions'];old=(p/vs[0]['local_path']).read_text().splitlines(keepends=True)
 if vs[2]['present']:
  cur=(p/vs[2]['local_path']).read_text().splitlines(keepends=True);diff=''.join(difflib.unified_diff(old,cur,fromfile='report-p17:90a:'+str(role['original_index']),tofile='current:95e:'+str(role['original_index'])));(p/(str(role['original_index'])+'-p17-to-current.diff')).write_text(diff)
ranges={0:[[65,110],[190,260],[527,590],[675,700]],1:[[232,285],[600,620]],2:[[175,210]],3:[[1,73]],4:[[425,495],[515,590]],5:[],6:[[1,105]],7:[[350,375]],8:[[1,70]],9:[[30,50],[108,129]],10:[[1,78]],11:[[175,200]],12:[[217,244]]};reads=[]
for i,x in enumerate(supports):reads.append({'path':x['path'],'revision':x['revision'],'archive':x['local_path'],'sha256':x['sha256'],'eof':x['registered_range'][1],'actual_body_display_ranges':ranges[i]})
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registration':{'path':'support-registration.json','sha256':hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest()},'reads':reads,'qualification':'Only stated ranges personally displayed and support-only; archived bytes, rg navigation and other agents do not confer additional or ordered-role body credit. Broad scenario navigation output was truncated and is not used to claim source reads. No tests were executed.'},indent=2)+'\n')
readroles=[{'original_index':2450,'path':reg['roles'][0]['path'],'p17_revision':reg['roles'][0]['versions'][0]['revision'],'fresh_p17_actual_display_ranges':[[1,50],[51,100],[101,142]],'current_revision':reg['roles'][0]['versions'][2]['revision'],'fresh_current_actual_display_ranges':[[1,50],[51,99]],'pr_working_revision':reg['roles'][0]['versions'][1]['revision'],'pr_working_actual_display_ranges':[],'qualification':'A separately archived identical 6533 copy was hash-verified but not separately displayed; the personal current display is 95e.'},{'original_index':2451,'path':reg['roles'][1]['path'],'p17_revision':reg['roles'][1]['versions'][0]['revision'],'fresh_p17_actual_display_ranges':[[1,30]],'current_revision':reg['roles'][1]['versions'][2]['revision'],'current_actual_display_ranges':[],'pr_working_revision':reg['roles'][1]['versions'][1]['revision'],'pr_working_actual_display_ranges':[],'qualification':'Path absent at both 6533 and 95e; inline 95e validator only separately registered support.'}]
(p/'read-receipt.json').write_text(json.dumps({'schema':'726-role-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registration':{'path':'registration.json','sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest()},'reads':readroles,'qualification':'Fresh prospective and bounded body displays only; no prior-agent credit, no product execution.'},indent=2)+'\n')
print('membership proofs',len(proof),'tree/commit objects',len(objects),'nonmembership',len(absences),'support',len(reads))
