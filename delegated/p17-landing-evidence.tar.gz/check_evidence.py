import datetime,gzip,hashlib,json,pathlib,subprocess,tarfile,difflib
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def checkref(x):
 b=(p/x['path']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256']),x['path']
def entries(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
report=json.loads((p/'report.json').read_text());r=json.loads((p/'registration.json').read_text());sup=json.loads((p/'support-registration.json').read_text())['sources'];receipt=json.loads((p/'read-receipt.json').read_text());support=json.loads((p/'support-read-receipt.json').read_text());regist=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()));assert regist['snapshots'][2]['head']==report['report_p17_revision'];assert len(report['thirteen_lens_perspectives'])==13 and len(set(x['lens'] for x in report['thirteen_lens_perspectives']))==13
for key in ['registration','read_receipt','support_registration','support_read_receipt','historical_manifest','reference_archives','older_774_selection','prior_current_selection']:checkref(report[key])
assert datetime.datetime.fromisoformat(r['registered_utc'])<datetime.datetime.fromisoformat(receipt['recorded_utc']);assert datetime.datetime.fromisoformat(json.loads((p/'support-registration.json').read_text())['registered_utc'])<datetime.datetime.fromisoformat(support['recorded_utc'])
for role in r['roles']:
 for v in role['versions']:
  z=subprocess.run(['git','-C',repo,'show',v['revision']+':'+role['path']],capture_output=True)
  if not v['present']:
   assert z.returncode!=0 and subprocess.check_output(['git','-C',repo,'ls-tree','-r','--name-only',v['revision'],'--',role['path']])==b'';continue
  b=(p/v['local_path']).read_bytes();assert z.stdout==b and (len(b),len(b.splitlines()),sha(b),blob(b))==(v['bytes'],v['lines'][1],v['sha256'],v['git_blob'])
  if v['revision']==report['report_p17_revision']:
   row=catalog['rows'][role['original_index']];assert row['origin']=='git:'+v['revision']+':'+role['path'] and row['expected_sha256']==sha(b);assert regist['files'][role['original_index']]['sha256']==sha(b);assert pathlib.Path(v['frozen_catalog_object']).read_bytes()==b==pathlib.Path(v['archive_local']).read_bytes()==pathlib.Path(v['handoff_archive']).read_bytes()
for s,a in zip(sup,support['reads']):
 b=(p/s['local_path']).read_bytes();assert (len(b),len(b.splitlines()),sha(b),blob(b))==(s['bytes'],s['registered_range'][1],s['sha256'],s['git_blob']);assert b==subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['path']]);assert (a['path'],a['revision'],a['sha256'])==(s['path'],s['revision'],s['sha256']);assert all(1<=i<=j<=s['registered_range'][1] for i,j in a['actual_body_display_ranges'])
objects=json.loads((p/'git-proofs.json').read_text());raw={}
for oid,x in objects['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b))==(x['bytes'],x['sha256']);assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;raw[oid]=b
for x in objects['proofs']:
 tree=raw[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for c in x['chain']:
  assert c['tree']==tree and entries(raw[tree])[c['name']]==(c['mode'],c['object']);tree=c['object']
 assert tree==x['blob'] and blob((p/x['archive']).read_bytes())==tree
for x in json.loads((p/'git-absence-proofs.json').read_text())['proofs']:
 tree=raw[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for c in x['parent_chain']:
  assert c['tree']==tree and entries(raw[tree])[c['name']]==(c['mode'],c['object']);tree=c['object']
 assert tree==x['parent_tree'] and x['missing_name'] not in entries(raw[tree])
h=json.loads((p/'historical-manifest.json').read_text());assert not h['unavailable'];transport={x['path']:x for x in json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()))['entries']}
for x in h['records']:
 b=(p/x['copy_path']).read_bytes();e=transport[x['original_transport_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
refs=json.loads((p/'reference/manifest.json').read_text())
for x in refs['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256']);assert 'uncompressed_sha256' not in x or sha(gzip.decompress(b))==x['uncompressed_sha256']
old=json.loads((p/'reference/older-774-selection.json').read_text());mb=gzip.decompress((p/old['manifest_compressed']).read_bytes());assert sha(mb)==old['manifest_uncompressed_sha256'];ix={e['path']:e for e in json.loads(mb)['files']}
for x in old['records']:
 b=gzip.decompress((p/x['compressed_copy']).read_bytes());e=ix[x['manifest_path']];assert (len(b),sha(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256']);assert x['merged_copy'] is None or b==pathlib.Path(x['merged_copy']).read_bytes()
cov=next(x for x in old['records'] if x['manifest_path'].endswith('native/coverage.jsonl'));lines=[json.loads(x) for x in gzip.decompress((p/cov['compressed_copy']).read_bytes()).splitlines()]
for role,ii in zip(r['roles'],[[280,619],[281,620]]):
 for i in ii:
  x=lines[i];assert x['source_id']=='report-p17:'+role['path'] and x['observed_sha256']==role['versions'][0]['sha256'] and x['read_ranges']==[role['versions'][0]['lines']]
prior=json.loads((p/'reference/prior-current-selection.json').read_text());assert refs['prior_manifest_sha256']==sha((p/'reference/prior-current-selection.json').read_bytes())
for x in prior['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
 for s in x['source_records']:
  z=(p/s['copy']).read_bytes();assert sha(z)==s['compressed_sha256'];b=gzip.decompress(z);assert sha(b)==s['sha256'] and b==subprocess.check_output(['git','-C',repo,'show',s['revision_as_recorded']+':'+s['path']])
queue=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()))
for x in report['historical_queue']:assert (queue['entries'][x['index']]['contract_id'],queue['entries'][x['index']]['status'])==(x['id'],x['status_as_recovered'])
checkref(report['prior_packet']['archive']);archive=p/report['prior_packet']['archive']['path']
with tarfile.open(archive,'r:gz') as t:
 root='726-delegate-p17-capture/';mb=t.extractfile(root+'BUNDLE-MANIFEST.json').read();assert sha(mb)==report['prior_packet']['original_bundle_manifest_sha256'];manifest=json.loads(mb)
 for x in manifest['files']:
  b=t.extractfile(root+x['path']).read();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
 data=json.loads(t.extractfile(root+'report.json').read());assert data['agent']=='/root/mhr_character' and any(x['id']=='CAPTURE-LANDING-MISSING-HEIGHT-AS-ZERO-95E' for x in data['findings_and_reconciliations'])
for x in report['navigation_receipts']:checkref(x)
proof={'result':'passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'objects':len(objects['proofs']),'raw_commit_tree_objects':len(raw),'path_nonmembership_proofs':2,'historic_059_records':len(h['records']),'older_774_manifest_records':len(old['records']),'prior_assessments':len(prior['records']),'prior_entire_packet_files_verified':len(manifest['files']),'bounded_lenses':len(report['thirteen_lens_perspectives']),'qualification':'Evidence integrity only. No product execution, test, simulation, build, rendering, probe or implementation.'}
(p/'evidence-verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
