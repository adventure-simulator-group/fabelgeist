import gzip,hashlib,json,pathlib,subprocess,shutil
out=pathlib.Path('<LOCAL_PATH_0>')
src=pathlib.Path('<LOCAL_PATH_1>')
pub=pathlib.Path('<LOCAL_PATH_2>')
old=pathlib.Path('<LOCAL_PATH_3>')
handoff=pathlib.Path('<LOCAL_PATH_4>')
ref=out/'reference';ref.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();refs=[]
for n in ['registry.json.gz','original-transport-manifest.json.gz','queue-059.json.gz']:
 p=pathlib.Path('<LOCAL_PATH_5>')/n;b=p.read_bytes();(ref/n).write_bytes(b);refs.append({'source':str(p),'copy':'reference/'+n,'bytes':len(b),'sha256':sha(b),'qualification':'Original recovered registry/transport/queue; no checkpoint3821 promotion.'})
catalog=(old/'reconcile-adler-20261023/recovered-sources/catalog.json').read_bytes();(ref/'older-source-catalog.json.gz').write_bytes(gzip.compress(catalog,mtime=0));refs.append({'source':str(old/'reconcile-adler-20261023/recovered-sources/catalog.json'),'copy':'reference/older-source-catalog.json.gz','bytes':(ref/'older-source-catalog.json.gz').stat().st_size,'sha256':sha((ref/'older-source-catalog.json.gz').read_bytes()),'uncompressed_sha256':sha(catalog),'qualification':'Original older source catalog; metadata confers no reading credit.'})
entries={e['path']:e for e in json.loads(gzip.decompress((ref/'original-transport-manifest.json.gz').read_bytes()))['entries']}
paths=['segovb/READ-L11-405.json','segovb/REGISTRATION-SEGOVB-1345.json','segovb/REGISTRATION-SEGOVB-1346.json','segovb/READ-L12-826.json','segovb/VERIFY-L12-826.json','parallel-l12-20261029/REGISTRATION-PAR-L12-459.json','parallel-l12-20261029/REGISTRATION-PAR-L12-460.json','parallel-l12-20261029/PROPOSAL-L12-826.json','segovb/READ-L11-404.json','segovb/READ-L12-823.json']
rows=[];missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file():missing.append(path);continue
 b=(src/path).read_bytes();e=entries[path];assert (sha(b),len(b),blob(b))==(e['sha256'],e['bytes'],e['git_blob']),path;dst=out/'historical'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);rows.append({'original_transport_path':path,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'copy_path':'historical/'+path})
(out/'historical-manifest.json').write_text(json.dumps({'qualification':'Original 059 bytes with original review attribution and revision, not checkpoint3821.','records':rows,'unavailable':missing},indent=2)+'\n')
mb=(handoff/'MANIFEST.json').read_bytes();(ref/'older-774-handoff-manifest.json.gz').write_bytes(gzip.compress(mb,mtime=0));ix={e['path']:e for e in json.loads(mb)['files']};older=[]
paths=['audit/reconcile-adler-20261023/audit-continuation/operations/contract-groups-586.json','audit/reconcile-adler-20261023/audit-continuation/redundant-authority/contract-566.json','historical-family-execution/final-acceptance-20261021/wave-01/audit-existing-type-owners/native/coverage.jsonl','audit/reconcile-adler-20261023/audit-continuation/operations/source/report-p17/crates/adventuresim-tactical-client/src/animation_viewer/report/html.rs','audit/reconcile-adler-20261023/audit-continuation/operations/source/report-p17/crates/adventuresim-tactical-client/src/animation_viewer/report/landing_validation.rs']
for n in paths:
 b=(handoff/n).read_bytes();e=ix[n];assert (len(b),sha(b))==(e['bytes'],e['sha256']);merged=None
 if n.startswith('audit/'):
  merged=old/n.removeprefix('audit/');assert merged.read_bytes()==b
 name='older-774-'+n.replace('/','__')+'.gz';(ref/name).write_bytes(gzip.compress(b,mtime=0));older.append({'manifest_path':n,'merged_copy':str(merged) if merged else None,'bytes':len(b),'sha256':sha(b),'compressed_copy':'reference/'+name,'qualification':'Exact earlier 774 handoff/manifest, with actual original reviewer and revision retained.'})
(ref/'older-774-selection.json').write_text(json.dumps({'manifest_compressed':'reference/older-774-handoff-manifest.json.gz','manifest_uncompressed_sha256':sha(mb),'records':older},indent=2)+'\n')
assess=['ASSESSMENT-L01-HISTORICAL-1427-1432.json','ASSESSMENT-SCENARIO-LABEL-ADMISSION-95E.json','ASSESSMENT-REPORT-EVENT-ORDERING-95E.json','ASSESSMENT-REPORT-METRIC-SUPPORT-95E.json','ASSESSMENT-INSPECTION-REPORT-BOUNDARIES-95E.json','ASSESSMENT-SCENARIO-CLOCK-CONFIG-95E.json','ASSESSMENT-CAPTURE-SETUP-VIEW-95E.json'];paths_of_interest={x['path'] for x in json.loads((out/'support-registration.json').read_text())['sources']};paths_of_interest.update(x['path'] for x in json.loads((out/'registration.json').read_text())['roles']);prior=[]
for n in assess:
 b=(pub/n).read_bytes();name='prior-'+n;(ref/name).write_bytes(b);d=json.loads(b);sources=[]
 for x in d.get('current_supporting_sources',[]):
  if x.get('path') not in paths_of_interest or not x.get('preserved_bytes'):continue
  s=(pub/x['preserved_bytes']).read_bytes();plain=gzip.decompress(s);assert (len(plain),sha(plain))==(x['bytes'],x['sha256']);assert plain==subprocess.run(['git','-C',str(pub),'show',x['revision']+':'+x['path']],capture_output=True,check=True).stdout
  name2='prior-source-'+sha(s)+'.gz';(ref/name2).write_bytes(s);sources.append({'path':x['path'],'revision_as_recorded':x['revision'],'ranges_as_recorded':x['ranges'],'original_preserved_bytes':x['preserved_bytes'],'copy':'reference/'+name2,'compressed_sha256':sha(s),'sha256':x['sha256']})
 for x in d.get('historical_source_roles',[]):
  if x.get('original_index')!=1432:continue
  c=x['current_comparison'];s=(pub/c['preserved_bytes']).read_bytes();assert sha(gzip.decompress(s))==c['sha256'];name2='prior-source-'+sha(s)+'.gz';(ref/name2).write_bytes(s);sources.append({'path':c['path'],'revision_as_recorded':c['source_revision'],'ranges_as_recorded':x['new_personal_read_ranges'],'original_preserved_bytes':c['preserved_bytes'],'copy':'reference/'+name2,'compressed_sha256':sha(s),'sha256':c['sha256'],'qualification':'Earlier historical personal 6533 read and current byte equality; no new current reading credit.'})
 prior.append({'assessment':n,'copy':'reference/'+name,'bytes':len(b),'sha256':sha(b),'source_records':sources,'qualification':'Earlier author, revision and declared scope preserved; no personal read transfer.'})
(ref/'prior-current-selection.json').write_text(json.dumps({'records':prior},indent=2)+'\n')
for name in ['rules-evidence.json','reference/AGENTS.md']:
 p=pathlib.Path('<LOCAL_PATH_6>')/name;dst=ref/('prior-'+name.replace('/','__'));dst.write_bytes(p.read_bytes());refs.append({'source':str(p),'copy':str(dst.relative_to(out)),'bytes':dst.stat().st_size,'sha256':sha(dst.read_bytes()),'qualification':'Prior frozen rules record; applies as specified, not a new source reading.'})
(ref/'manifest.json').write_text(json.dumps({'records':refs,'older_manifest_sha256':sha((ref/'older-774-selection.json').read_bytes()),'prior_manifest_sha256':sha((ref/'prior-current-selection.json').read_bytes())},indent=2)+'\n')
print('059 verified',len(rows),'missing',missing,'774',len(older),'assessments',len(prior),'support',sum(len(x['source_records']) for x in prior))
