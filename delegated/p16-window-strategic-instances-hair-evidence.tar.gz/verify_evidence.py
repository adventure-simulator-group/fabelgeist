"""Verify retained evidence and read receipts. Does not execute product code."""
import datetime, gzip, hashlib, json, pathlib, tarfile
p = pathlib.Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
load = lambda n: json.loads((p / n).read_bytes())
unzip_json = lambda n: json.loads(gzip.decompress((p / n).read_bytes()))
reg, rr, sr, proof, hist, report = (load(n) for n in ('registration.json','read-receipt.json','support-read-receipt.json','git-proofs.json','historical-manifest.json','report.json'))
original = unzip_json('reference/original-transport-manifest.json.gz')
older = unzip_json('reference/older-774-handoff-manifest.json.gz')
registry = unzip_json('reference/registry.json.gz')
catalog = unzip_json('reference/older-source-catalog.json.gz')
queue = unzip_json('reference/queue-059.json.gz')
assert rr['prospective_registration_sha256'] == sha((p/'registration.json').read_bytes())
assert datetime.datetime.fromisoformat(reg['registered_utc']) < datetime.datetime.fromisoformat(rr['recorded_utc'])
reads = {}
def partition(eof, windows, unread):
    seen, rest = set(), set()
    for lo, hi in windows:
        assert 1 <= lo <= hi <= eof
        seen.update(range(lo, hi+1))
    for lo, hi in unread:
        assert 1 <= lo <= hi <= eof
        rest.update(range(lo, hi+1))
    assert not seen & rest and seen | rest == set(range(1,eof+1))
    return seen
for role, read in zip(reg['roles'], rr['roles']):
    idx=role['original_index']; assert idx == read['original_index']
    v=role['p16']; b=(p/v['local']).read_bytes()
    assert len(b)==v['bytes'] and sha(b)==v['sha256']==registry['files'][idx]['sha256']==catalog['rows'][idx]['expected_sha256'] and blob(b)==v['git_blob']
    assert not read['0393_a120_6533_personal_display_windows']
    assert len(b.splitlines())==read['p16_eof']; partition(read['p16_eof'],read['p16_display_windows'],read['p16_unread_complement'])
    reads[role['path']]=partition(read['current_eof'],read['current_display_windows'],read['current_unread_complement'])
    for version in role['versions']:
        assert version['present']; body=(p/version['local']).read_bytes()
        assert version['equals_p16'] and body == b and sha(body)==version['sha256'] and blob(body)==version['git_blob'] and len(body)==version['bytes']
        assert (version['revision'], role['path'], version['local']) in {(q['revision'],q['path'],q['archive']) for q in proof['proofs']}
    assert (v['archive_revision'],v['archive_path'],v['local']) in {(q['revision'],q['path'],q['archive']) for q in proof['proofs']}
snapshot=next(x for x in registry['snapshots'] if x['id']=='physical-p16')
assert snapshot['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snapshot['changed_variants']==159 and snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for f in sr['prospective_registrations']:
    assert sha((p/f['path']).read_bytes())==f['sha256'] and datetime.datetime.fromisoformat(load(f['path'])['registered_utc']) < datetime.datetime.fromisoformat(sr['recorded_utc'])
support=[s for f in sr['prospective_registrations'] for s in load(f['path'])['sources']]
assert len(support)==len(sr['reads'])
for s,r in zip(support,sr['reads']):
    b=(p/s['local']).read_bytes()
    assert s['path']==r['path'] and sha(b)==s['sha256']==r['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==r['eof'] and blob(b)==s['git_blob']
    assert (s['revision'],s['path'],s['local']) in {(q['revision'],q['path'],q['archive']) for q in proof['proofs']}
    reads[s['path']]=partition(r['eof'],r['actual_display_windows'],r['unread_complement'])
objects={}
for oid,o in proof['objects'].items():
    b=gzip.decompress((p/o['archive']).read_bytes())
    assert len(b)==o['bytes'] and sha(b)==o['sha256'] and hashlib.sha1(o['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
    objects[oid]=b
def entries(b):
    result={}; i=0
    while i<len(b):
        a=b.index(b' ',i); z=b.index(b'\0',a)
        result[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex()); i=z+21
    return result
for q in proof['proofs']:
    assert objects[q['revision']].splitlines()[0].split()[1].decode()==q['commit_tree']
    tree=q['commit_tree']; assert len(q['path'].split('/'))==len(q['chain'])
    for name,chain in zip(q['path'].split('/'),q['chain']):
        assert chain['tree']==tree and chain['name']==name
        mode,tree=entries(objects[tree])[name]
        assert mode==chain['mode'] and tree==chain['object']
    assert tree==q['blob']==blob((p/q['archive']).read_bytes())
for o in hist['records']:
    b=(p/o['copy']).read_bytes(); assert sha(b)==o['sha256'] and len(b)==o['bytes'] and blob(b)==o['git_blob']
    if o['scope'] in ['059','774']:
        index=original['entries'] if o['scope']=='059' else older['files']
        m=next(x for x in index if x['path']==o['original_path'])
        assert m['bytes']==len(b) and m['sha256']==sha(b)
        assert o['scope']!='059' or m['git_blob']==blob(b)
    else:
        assert (o['archive_revision'],o['original_path'],o['copy']) in {(q['revision'],q['path'],q['archive']) for q in proof['proofs']}
for s in hist['prior_publication_payloads']:
    b=(p/s['copy']).read_bytes()
    if 'source_path' in s:
        assert sha(b)==s['compressed_sha256'] and sha(gzip.decompress(b))==s['body_sha256']
    else:
        assert len(b)==s['bytes'] and sha(b)==s['sha256']
native_members=0
for n in ['bevy_camera-0.19.1','bevy_ecs-0.19.1']:
    native=p/'reference/prior-publication/native-evidence'/n
    m=json.loads((native/'MANIFEST.json').read_bytes()); z=(native/m['archive']).read_bytes()
    assert len(z)==m['bytes'] and sha(z)==m['sha256']
    with tarfile.open(native/m['archive'],'r:gz') as tar:
        for e in m['inspected_members']:
            b=tar.extractfile(e['path']).read(); assert len(b)==e['bytes'] and sha(b)==e['sha256']; native_members+=1
prior=hist['prior_delegate_packet']; prior_path=p/prior['path']; mb=(prior_path/'packet-manifest.json').read_bytes()
assert sha(mb)==prior['manifest_sha256'] and sha((prior_path/'report.json').read_bytes())==prior['report_sha256']
manifest=json.loads(mb); assert len(manifest['files'])==manifest['file_count']==prior['verified_file_count']
for e in manifest['files']:
    b=(prior_path/e['path']).read_bytes(); assert len(b)==e['bytes'] and sha(b)==e['sha256']
assert not hist['unavailable']
assert queue['entries'][2251]['contract_id']=='L12-CLOSURE-WINDOW-OBSERVER-RESOURCE-LIFECYCLE' and queue['entries'][2251]['status']=='open-granular-reconciliation'
assert len(report['lenses'])==13 and len(set(x['lens'] for x in report['lenses']))==13
rig=p/'historical/adler-original'
f1=[json.loads(l) for l in (rig/'owner-reached-producer-followup/findings.jsonl').read_text().splitlines()]
f2=[json.loads(l) for l in (rig/'producer-reached-owner81/findings.jsonl').read_text().splitlines()]
assert any(x['id']=='RIG-OWNER-REACHED-PRODUCER-F004' for x in f1) and any(x['id']=='RIG-OWNER81-F004' for x in f2)
refs=[]
def visit(x):
    if isinstance(x,dict):
        if {'revision','path','lines'} <= x.keys(): refs.append(x)
        for v in x.values(): visit(v)
    elif isinstance(x,list):
        for v in x: visit(v)
visit(report)
for r in refs:
    assert r['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and r['path'] in reads
    for lo,hi in r['lines']: assert all(i in reads[r['path']] for i in range(lo,hi+1)),(r['path'],lo,hi)
result={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'exact_p16_objects_and_per_revision_comparisons':len(reg['roles']),'p16_recorded_dirty_snapshot_and_unrecovered_patch_qualification':True,'independent_commit_tree_membership_proofs':len(proof['proofs']),'support_objects_and_read_partitions':len(support),'original_historical_and_prior_publication_records':len(hist['records']),'prior_publication_payload_hashes':len(hist['prior_publication_payloads']),'native_prior_archive_members_hash_verified':native_members,'prior_delegate_packet_files':len(manifest['files']),'current_source_references_within_personal_windows':len(refs),'bounded_lens_perspectives':len(report['lenses']),'both_original_rig_f004_records_present':True,'059_q2251_open_identity_verified':True},'qualification':'Self-contained evidence integrity and read-receipt checks only. Current assigned/support Git membership is proved from retained objects; earlier source payload hashes retain prior attribution. No product, tests, builds, runtime probe or validation.'}
(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
