# Bounded P16 window and strategic-instance evidence

This packet records /root/hair_ops's evidence-only review of original roles
2517 and 2518. The current authoritative source revision is
`95e63628f9d70b8dd6e6fede64334696c6995009`. The two physical-p16 objects
are bound independently to the recovered registry, catalog, and f82 archive;
that archive is transport, not the historical snapshot head. The dirty P16
snapshot was based on `a120390947c89b703dc74c4255a13c035d054c50`. The full
159-path patch has not been recovered; its registry-recorded hash is retained
as a historical assertion, not evidence that the entire delta was restored.
The two reviewed P16 bodies individually equal their 0393, a120, 6533, and
95e counterparts, which does not make the snapshot clean or establish product
equivalence.

`registration.json` predates the personally displayed complete P16 and 95e
bodies, separately, for windows 1–77 and instances 1–95. The 0393, a120, and
6533 copies were verified by hashes and Git membership but were not separately
displayed. `read-receipt.json` and `support-read-receipt.json` give actual
ranges and unread complements; support registrations predate their displays.
An earlier same-agent 95e windows 1–77 support read is preserved separately in
`reference/prior-window-facade-packet`, with no transfer of role credit.

`report.json` supplies thirteen bounded perspectives, observations, open
questions, nonfindings, source references and original attribution. The
ordinary source construction of successful, unmodified window mesh batches
narrows the missing-primary-material question in historical 059 q2251 under
the specified normal-completion and nonzero-board conditions. Asset ownership,
other exceptional paths and cleanup remain open; q2251 is not closed here.
The strategic queued-prefix error path relates to an existing current central
assessment; no duplicate defect, supported failure, native command outcome or
runtime behavior is asserted.

`historical/` and `reference/` preserve original 059/774 records, the earlier
source packet and prior central assessments with their respective authors and
scopes. Transcript-hash-matched records retain their explicit reconstruction
qualifications and are not attributed to checkpoint 3821. `git-proofs.json`
and `git-objects/` retain self-contained Git membership evidence. Run
`python3 verify_evidence.py` solely to recheck evidence integrity and receipt
partitions; it performs no product execution. `packet-manifest.json` records
the complete retained file set and hashes. Running the verifier rewrites its
timestamped result, so compare that result to the frozen manifest before
re-running or run a copy if exact frozen bytes must be preserved.

No repairs, product/source/publication edits, builds, tests, product execution,
renderer, viewer, browser, runtime probes, simulations or validation occurred.
Central coordination owns reconciliation, ledger disposition and publication.
