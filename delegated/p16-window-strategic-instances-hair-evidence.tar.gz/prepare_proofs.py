import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());names=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json'];sup=[x for n in names for x in json.loads((p/n).read_bytes())['sources']];hist=json.loads((p/'historical-manifest.json').read_bytes());(p/'git-objects').mkdir(exist_ok=True);objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for role in reg['roles']:
 for v in role['versions']:
  if v['present']:members.append({'revision':v['revision'],'path':role['path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob']})
 v=role['p16'];members.append({'revision':v['archive_revision'],'path':v['archive_path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob'],'qualification':'Archive object only; not P16 source revision or complete dirty patch.'})
members+=sup
for x in hist['records']:
 if x['scope'] in ['adler-original-f82','prior-publication']:members.append({'revision':x['archive_revision'],'path':x['original_path'],'local':x['copy'],'sha256':x['sha256'],'git_blob':x['git_blob'],'qualification':x['scope']+' prior evidence, not personal reading'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();proofs.append({'revision':s['revision'],'path':s['path'],'archive':s['local'],'commit_tree':root,'chain':chain,'blob':tree,'qualification':s.get('qualification')})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Dirty P16 recorded 159-path delta at a120; f82 transports selected old objects/records only. Whole patch remains unrecovered. Individual object identity does not reclassify snapshot.' ,'objects':objects,'proofs':proofs},indent=2)+'\n')
def comp(eof,w):
 a=set()
 for lo,hi in w:a.update(range(lo,hi+1))
 out=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in a and start is None:start=i
  if start is not None and (i==eof+1 or i in a):out.append([start,i-1]);start=None
 return out
reads=[]
for role in reg['roles']:
 oe=role['p16']['prospective_range'][1];ce=role['versions'][-1]['prospective_range'][1];pw=[[1,oe]];cw=[[1,ce]];reads.append({'original_index':role['original_index'],'p16_eof':oe,'p16_display_windows':pw,'p16_unread_complement':comp(oe,pw),'current_revision':role['versions'][-1]['revision'],'current_eof':ce,'current_display_windows':cw,'current_unread_complement':comp(ce,cw),'0393_a120_6533_personal_display_windows':[],'prior_personal_support':'Earlier /root/hair_ops at 95e lines1–77 in <LOCAL_PATH_2> separate prior support with no automatic ordered-role credit.' if role['original_index']==2517 else None})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration_sha256':sha((p/'registration.json').read_bytes()),'roles':reads,'qualification':'P16 and current versions personally displayed separately after prospectively registering; other versions were verified but not displayed.'},indent=2)+'\n')
ranges=[[[1,95]],[[1,105],[105,177]],[[50,95]],[[1,59]],[],[[15,61]],[[1,70]],[[1,65],[100,155]],[[1,108]],[[1,90]],[[1,155],[155,207]],[[1,105]],[[54,87]],[[1,14]]];assert len(ranges)==len(sup);r=[]
for s,w in zip(sup,ranges):
 eof=s['registered_range'][1];r.append({'path':s['path'],'revision':s['revision'],'archive':s['local'],'sha256':s['sha256'],'eof':eof,'actual_display_windows':w,'unread_complement':comp(eof,w)})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in names],'reads':r,'qualification':'Support only; token-only rg navigation is not full-line reading. Existing tests in displayed windows are source only.'},indent=2)+'\n');print('proofs',len(proofs),'trees',len(objects),'support',len(sup))
