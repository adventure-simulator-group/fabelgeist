import datetime,gzip,hashlib,json,pathlib,subprocess,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());reg=load('registration.json');rr=load('read-receipt.json');sr=load('support-read-receipt.json');proof=load('git-proofs.json');hist=load('historical-manifest.json');report=load('report.json');original=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));older=json.loads(gzip.decompress((p/'reference/older-774-handoff-manifest.json.gz').read_bytes()));registry=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()));queue=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()));
assert rr['prospective_registration_sha256']==sha((p/'registration.json').read_bytes());assert datetime.datetime.fromisoformat(reg['registered_utc'])<datetime.datetime.fromisoformat(rr['recorded_utc']);reads={}
def partition(eof,w,u):
 a=set();b=set()
 for lo,hi in w:assert 1<=lo<=hi<=eof;a.update(range(lo,hi+1))
 for lo,hi in u:assert 1<=lo<=hi<=eof;b.update(range(lo,hi+1))
 assert not a&b and a|b==set(range(1,eof+1));return a
for role,r in zip(reg['roles'],rr['roles']):
 idx=role['original_index'];assert idx==r['original_index'];v=role['p16'];b=(p/v['local']).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']==registry['files'][idx]['sha256']==catalog['rows'][idx]['expected_sha256'] and blob(b)==v['git_blob'];assert pathlib.Path(catalog['rows'][idx]['object']).read_bytes()==b;assert subprocess.check_output(['git','-C',repo,'show',v['archive_revision']+':'+v['archive_path']])==b
 assert not r['0393_a120_6533_personal_display_windows'];partition(r['p16_eof'],r['p16_display_windows'],r['p16_unread_complement']);reads[role['path']]=partition(r['current_eof'],r['current_display_windows'],r['current_unread_complement'])
 for s in role['versions']:
  assert s['present'];q=(p/s['local']).read_bytes();assert (q==b)==s['equals_p16'] and sha(q)==s['sha256'] and blob(q)==s['git_blob'] and len(q)==s['bytes'];assert subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+role['path']])==q
snapshot=next(x for x in registry['snapshots'] if x['id']=='physical-p16');assert snapshot['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snapshot['changed_variants']==159 and snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for f in sr['prospective_registrations']:assert sha((p/f['path']).read_bytes())==f['sha256'] and datetime.datetime.fromisoformat(load(f['path'])['registered_utc'])<datetime.datetime.fromisoformat(sr['recorded_utc'])
sup=[s for f in sr['prospective_registrations'] for s in load(f['path'])['sources']];assert len(sup)==len(sr['reads'])
for s,r in zip(sup,sr['reads']):
 b=(p/s['local']).read_bytes();assert s['path']==r['path'] and sha(b)==s['sha256']==r['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==r['eof'] and blob(b)==s['git_blob'];assert subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['path']])==b;reads[s['path']]=partition(r['eof'],r['actual_display_windows'],r['unread_complement'])
objs={}
for oid,o in proof['objects'].items():
 b=gzip.decompress((p/o['archive']).read_bytes());assert len(b)==o['bytes'] and sha(b)==o['sha256'] and hashlib.sha1(o['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
for q in proof['proofs']:
 assert objs[q['revision']].splitlines()[0].split()[1].decode()==q['commit_tree'];tree=q['commit_tree'];assert len(q['path'].split('/'))==len(q['chain'])
 for name,chain in zip(q['path'].split('/'),q['chain']):
  assert chain['tree']==tree and chain['name']==name;mode,tree=entries(objs[tree])[name];assert mode==chain['mode'] and tree==chain['object']
 assert tree==q['blob']==blob((p/q['archive']).read_bytes())
for o in hist['records']:
 b=(p/o['copy']).read_bytes();assert sha(b)==o['sha256'] and len(b)==o['bytes'] and blob(b)==o['git_blob']
 if o['scope'] in ['059','774']:
  index=original['entries'] if o['scope']=='059' else older['files'];m=next(x for x in index if x['path']==o['original_path']);assert m['bytes']==len(b) and m['sha256']==sha(b);assert o['scope']!='059' or m['git_blob']==blob(b)
 else:assert subprocess.check_output(['git','-C',repo,'show',o['archive_revision']+':'+o['original_path']])==b
for s in hist['prior_city_payloads']:
 b=(p/s['copy']).read_bytes()
 if 'source_path' in s:
  assert sha(b)==s['compressed_sha256'];raw=gzip.decompress(b);assert sha(raw)==s['body_sha256'] and raw==subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['source_path']])
 else:assert len(b)==s['bytes'] and sha(b)==s['sha256']
nat=p/'reference/prior-city/native-evidence/bevy_pbr-0.19.1';m=json.loads((nat/'MANIFEST.json').read_bytes());z=(nat/m['archive']).read_bytes();assert len(z)==m['bytes'] and sha(z)==m['sha256']
with tarfile.open(nat/m['archive'],'r:gz') as tar:
 for e in m['inspected_members']:
  b=tar.extractfile(e['path']).read();assert len(b)==e['bytes'] and sha(b)==e['sha256']
assert not hist['unavailable'];assert queue['entries'][585]['contract_id']=='Q-L11-65c1ca69792ec528b64f' and queue['entries'][585]['status']=='open-evidence-or-disposition';assert len(report['lenses'])==13 and len(set(x['lens'] for x in report['lenses']))==13
rig=p/'historical/adler-original';f1=[json.loads(l) for l in (rig/'owner-reached-producer-followup/findings.jsonl').read_text().splitlines()];f2=[json.loads(l) for l in (rig/'producer-reached-owner81/findings.jsonl').read_text().splitlines()];assert any(x['id']=='RIG-OWNER-REACHED-PRODUCER-F004' for x in f1) and any(x['id']=='RIG-OWNER81-F004' for x in f2)
d=load('diff-index.json');a=(p/'source/2512-p16.rs').read_bytes();b=(p/'source/2512-95e6.rs').read_bytes();assert sha(a)==d['old_sha256'] and sha(b)==d['current_sha256'] and sha((p/'p16-to-95e-materials.diff').read_bytes())==d['diff_sha256'];assert a.splitlines()[:407]==b.splitlines()[:407] and all(x['old_range'][0]>=408 and x['current_range'][0]>=408 for x in d['hunks'])
refs=[]
def visit(x):
 if isinstance(x,dict):
  if {'revision','path','lines'}<=x.keys():refs.append(x)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
for r in refs:
 assert r['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and r['path'] in reads
 for lo,hi in r['lines']:assert all(i in reads[r['path']] for i in range(lo,hi+1)),(r['path'],lo,hi)
y={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'exact_p16_objects_and_per_revision_comparisons':len(reg['roles']),'p16_recorded_dirty_snapshot_and_unrecovered_patch_qualification':True,'independent_commit_tree_membership_proofs':len(proof['proofs']),'support_objects_and_read_partitions':len(sup),'original_historical_and_prior_publication_records':len(hist['records']),'earlier_city_payloads':len(hist['prior_city_payloads']),'native_prior_archive_members_hash_verified':len(m['inspected_members']),'current_source_references_within_personal_windows':len(refs),'bounded_lens_perspectives':len(report['lenses']),'both_original_rig_f004_records_present':True,'059_q585_open_identity_verified':True,'all_material_diff_hunks_inside_test_source':True},'qualification':'Evidence-integrity checks only; no product, geometry, texture generator, tests, builds, render, runtime probe or validation.'};(p/'evidence-verification.json').write_text(json.dumps(y,indent=2)+'\n');print(json.dumps(y,indent=2))
