import datetime,difflib,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());names=['support-registration.json','support-registration-02.json','support-registration-03.json'];sup=[x for n in names for x in json.loads((p/n).read_bytes())['sources']];hist=json.loads((p/'historical-manifest.json').read_bytes());(p/'git-objects').mkdir(exist_ok=True);objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for role in reg['roles']:
 for v in role['versions']:
  if v['present']:members.append({'revision':v['revision'],'path':role['path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob']})
 v=role['p16'];members.append({'revision':v['archive_revision'],'path':v['archive_path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob'],'qualification':'Archive object only; not P16 source revision or complete dirty patch.'})
members+=sup
for x in hist['records']:
 if x['scope'] in ['adler-original-f82','prior-publication']:members.append({'revision':x['archive_revision'],'path':x['original_path'],'local':x['copy'],'sha256':x['sha256'],'git_blob':x['git_blob'],'qualification':x['scope']+' prior evidence, not personal reading'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();proofs.append({'revision':s['revision'],'path':s['path'],'archive':s['local'],'commit_tree':root,'chain':chain,'blob':tree,'qualification':s.get('qualification')})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'P16 remains the recorded dirty 159-path delta based at a120; f82 only transports individual recovered objects and prior records. Its complete patch remains unrecovered. File equality does not reclassify that snapshot.','objects':objects,'proofs':proofs},indent=2)+'\n')
def complement(eof,w):
 a=set()
 for lo,hi in w:a.update(range(lo,hi+1))
 out=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in a and start is None:start=i
  if start is not None and (i==eof+1 or i in a):out.append([start,i-1]);start=None
 return out
reads=[]
for role,pw,cw in [(reg['roles'][0],[[1,80],[81,150]],[[1,52],[53,59]]),(reg['roles'][1],[[1,100],[200,230],[430,525]],[[1,100],[101,200],[201,300],[301,400],[401,480],[481,556]])]:
 oe=role['p16']['prospective_range'][1];ce=role['versions'][-1]['prospective_range'][1];reads.append({'original_index':role['original_index'],'p16_eof':oe,'p16_display_windows':pw,'p16_unread_complement':complement(oe,pw),'current_revision':role['versions'][-1]['revision'],'current_eof':ce,'current_display_windows':cw,'current_unread_complement':complement(ce,cw),'0393_a120_6533_personal_display_windows':[],'qualification':'All source test statements were read only. Archive equality does not transfer personal-read credit; bounded diff context also lies inside the recorded source windows.'})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration_sha256':sha((p/'registration.json').read_bytes()),'roles':reads},indent=2)+'\n')
ranges=[[[120,205],[270,380],[535,596],[1,120],[364,391]],[[100,145]],[],[[1,61]],[[1,77]],[[1,110],[290,345]],[[1,69]],[[1,40]],[[1,55],[90,140],[145,215],[220,275]],[[1,65]],[[1,39]],[[1,28]],[[1,85]],[[45,105]],[[1,130],[165,180]]];assert len(ranges)==len(sup);r=[]
for s,w in zip(sup,ranges):
 eof=s['registered_range'][1];r.append({'path':s['path'],'revision':s['revision'],'archive':s['local'],'sha256':s['sha256'],'eof':eof,'actual_display_windows':w,'unread_complement':complement(eof,w)})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in names],'reads':r,'qualification':'Support only; token-only rg navigation does not confer full-line body credit. Existing test modules read only, never executed.'},indent=2)+'\n')
a=(p/'source/2512-p16.rs').read_text().splitlines(keepends=True);b=(p/'source/2512-95e6.rs').read_text().splitlines(keepends=True);ops=[{'tag':t,'old_range':[i+1,j],'current_range':[k+1,l]} for t,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if t!='equal'];diff=''.join(difflib.unified_diff(a,b,fromfile='physical-p16:2512',tofile='95e:2512')).encode();(p/'p16-to-95e-materials.diff').write_bytes(diff);(p/'diff-index.json').write_text(json.dumps({'old_sha256':sha(''.join(a).encode()),'current_sha256':sha(''.join(b).encode()),'hunks':ops,'diff_sha256':sha(diff),'qualification':'Full file source diff; every changed line lies in test module and was personally displayed in both revisions. No test run or runtime-equivalence claim.'},indent=2)+'\n');print('proofs',len(proofs),'tree objects',len(objects),'support',len(sup),'diff hunks',len(ops))
