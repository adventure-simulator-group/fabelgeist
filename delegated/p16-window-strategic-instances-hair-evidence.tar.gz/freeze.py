"""Freeze the current packet; no product code or external source is run."""
import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).resolve().parent
manifest=p/'packet-manifest.json'
files=[]
for f in sorted(x for x in p.rglob('*') if x.is_file() and x != manifest):
    data=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
m={'schema':'726-bounded-evidence-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file_count':len(files),'files':files,'qualification':'Evidence packet only; prior author scopes and dirty snapshot qualifications are preserved.'}
manifest.write_text(json.dumps(m,indent=2)+'\n')
print('files',len(files),'manifest_sha256',hashlib.sha256(manifest.read_bytes()).hexdigest())
