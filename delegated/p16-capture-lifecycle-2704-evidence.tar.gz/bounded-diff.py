from pathlib import Path
import difflib
p=Path(__file__).parent;a=(p/'source/2704-historical.rs').read_text().splitlines();b=(p/'source/2704-current.rs').read_text().splitlines();out=[]
for old,new in [((1593,1644),(1602,1653)),((2656,3327),(2665,3394))]:
 x=a[old[0]-1:old[1]];y=b[new[0]-1:new[1]];out.append(f'Historic {old[0]}–{old[1]} vs 95e {new[0]}–{new[1]}; bounded source diff\n');out.extend(s+'\n' for s in difflib.unified_diff(x,y,fromfile=f'P16:{old[0]}',tofile=f'95e:{new[0]}',n=1))
(p/'bounded-source-diff.txt').write_text(''.join(out))
