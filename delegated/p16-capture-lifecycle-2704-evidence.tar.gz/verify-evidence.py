#!/usr/bin/env python3
"""Evidence identity, preservation, read accounting and Git tree proof only."""
import difflib,gzip,hashlib,io,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
def values(r):return {i for lo,hi in r for i in range(lo,hi+1)}
def source(e):
 d=(p/e['source_archive']).read_bytes();assert (sha(d),blob(d),len(d),len(d.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF'])
r=load('registration.json');rc=load('personal-read-receipt.json');assert rc['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<rc['recorded_utc'] and len(rc['actual_displays'])==len(r['entries'])==2
sc=load('read-scope-summary.json')
for e,x in zip(r['entries'],rc['actual_displays']):
 source(e);assert x['source_archive']==e['source_archive'] and x['displayed_chunks']==e['planned_chunks'] and x['displayed_ranges']==e['registered_ranges'] and values(e['planned_chunks'])==values(e['registered_ranges']);s=sc['assigned'][e['source_archive']];assert s['displayed_ranges']==e['registered_ranges'] and not values(s['displayed_ranges'])&values(s['unread_complement']) and values(s['displayed_ranges'])|values(s['unread_complement'])==set(range(1,e['actual_EOF']+1))
old,cur=r['entries'];cmp=r['comparison'];base=(p/cmp['base_archive']).read_bytes();assert old['registered_ranges']==[[1593,1644],[2656,3327]] and cur['registered_ranges']==[[1590,1655],[2665,3395]] and (sha(base),blob(base))==(old['sha256'],old['git_blob']) and cmp['historical_equals_base'] and not cmp['current_equals_historical'] and not cmp['status_porcelain'];checks.append('P16 and 95e independently registered and actually displayed assigned windows; exact unread complements and per-file base equality')
sr=load('support-registration.json');rr=load('support-read-receipt.json');assert rr['registration_sha256']==sha((p/'support-registration.json').read_bytes()) and sr['registered_utc']<rr['recorded_utc'] and len(sr['entries'])==len(rr['actual_displays'])==5
for e,x in zip(sr['entries'],rr['actual_displays']):
 source(e);assert x['source_archive']==e['source_archive'] and x['displayed_chunks']==e['planned_chunks'];s=sc['support'][e['source_archive']];assert s['displayed_ranges']==e['registered_ranges'] and values(e['planned_chunks'])==values(e['registered_ranges']) and not values(s['displayed_ranges'])&values(s['unread_complement']) and values(s['displayed_ranges'])|values(s['unread_complement'])==set(range(1,e['actual_EOF']+1))
prior_ranges=load('prior-capture-review/read-scope-summary.json')['support']['support/viewer.rs']['displayed_ranges'];assert load('registration-chronology-note.json')['earlier_2702_2703_viewer_actual_ranges']==prior_ranges and values(cur['registered_ranges'])-values(prior_ranges)==set(range(2766,3030));checks.append('Five independently registered support re-displays, prior viewer read chronology and unread complements retained')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['original_registry_sha256_uncompressed']==sha(raw) and sel['rows'][0]['entry']==reg['files'][2704];snap=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert sel['physical_p16_snapshot']==snap and snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and sha((p/'reference/p16-tracked.patch').read_bytes())==snap['patch_sha256'] and len(snap['status_porcelain'])==159
raw=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(raw)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';entries={x['path']:x for x in json.loads(gzip.decompress(raw))['entries']};hist=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hist['records'])==28 and sum(x['kind']=='historical-774' for x in hist['records'])==4
for x in hist['records']:
 d=(p/x['file']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (len(d),sha(d),blob(d))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
search=load('recovery-search.json');assert len(search['roots'])==2 and len(search['filenames'])==3 and not search['results'] and not search['errors'] and not search['transport_manifest_matches'] and not any(pathlib.PurePosixPath(x).name in search['filenames'] for x in entries);checks.append('Original dirty P16 registry, recovered tracked patch and 28 verified 059/4 774 records; bounded proposal adoption search')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];d=gzip.decompress((p/x['archive']).read_bytes());assert (len(d),sha(d),hashlib.sha1(x['type'].encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest())==(x['bytes'],x['sha256'],oid);return d
def trees(d):
 out={};i=0
 while i<len(d):
  s=d.index(b' ',i);z=d.index(b'\0',s);out[d[s+1:z].decode()]=(d[i:s].decode(),d[z+1:z+21].hex());i=z+21
 return out
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==14
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 d=(p/x['archive']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (sha(d),blob(d),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Fourteen offline raw Git-tree membership proofs covering f82 transport, per-file a120/039, 6533/95e, and support')
reg774=[json.loads(x) for x in gzip.decompress((p/'history-774/root/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines()];a=next(x for x in reg774 if x['id']=='ROOT-ADMISSION03-REG-045');assert a['material_ranges']==[[1593,1648],[2656,3328]] and a['sha256']==old['sha256'];quals=[json.loads(x) for x in gzip.decompress((p/'history-774/root/admission03/source-qualifications-final-current.jsonl.gz').read_bytes()).splitlines()];q=next(x for x in quals if x['registration_id']=='ROOT-ADMISSION03-REG-045');assert q['effective_material_ranges']==old['registered_ranges'] and q['qualifications'][0]['context_excluded']==[[1645,1648],[3328,3328]];g=json.loads(gzip.decompress((p/'history-774/root/admission03/map-capture-producers-073.json.gz').read_bytes()));assert g['id']=='ROOT-ADM-G073' and g['finding']['id']=='ROOT-ADM-G073-F001' and g['finding']['status']=='source_backed_static_normal_producer_terminal_edge_not_runtime_confirmed'
l11=next(x for x in load('history-059/segovb/READ-L11-441.json')['sources'] if x['original_index']==2704);assert l11['fresh_personal_body_reads']==old['registered_ranges'];adler=next(x for x in load('history-059/adler/READ-L11-246.json')['sources'] if x['original_index']==1699);assert values(adler['fresh_reads'])==set(range(1,4478)) and adler['sha256']==cur['sha256'];s12=next(x for x in load('history-059/segovb/READ-L12-543.json')['rows'] if x['original_index']==1699);assert s12['fresh_personal_body_reads']==[[1,4477]] and s12['source_sha256']==cur['sha256'];expected=[[[1593,1648]],[[2656,2850]],[[2851,3045]],[[3046,3240]],[[3241,3328]]]
for i,rr in enumerate(expected,1):
 row=next(x for x in load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-940-{i:03d}.json')['rows'] if x['original_index']==2704);assert row['fresh_personal_body_reads']==rr and '/root/lens12_frontier' in row['attribution'] and row['source_sha256']==old['sha256']
assert 'root adoption required' in load('history-059/parallel-l12-20261029/PROPOSAL-L12-940.json')['kind'];checks.append('Exact original 774 registration/qualification/finding and separately attributed 059 P16, 6533, proposal partial scopes')
idx=load('prior-capture-index.json');m=(p/'prior-capture-review/BUNDLE-MANIFEST.json').read_bytes();assert sha(m)==idx['manifest_sha256']=='7f5301db97563a007f0876e7f4b9a212a687f2b28b2692dc86390b321cbc297a';members={x['path']:x for x in json.loads(m)['files']}
for x in idx['selected_records']:
 d=(p/x['file']).read_bytes();e=members[x['prior_member']];assert (sha(d),len(d))==(x['sha256'],x['bytes'])==(e['sha256'],e['bytes'])
assert sha((p/'prior-capture-review/prior-readiness/BUNDLE-MANIFEST.json').read_bytes())=='95ed71a5988513740f514a84a612af4b6f057ec22f1cac3def9524cf7be06e5a';raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert queue['entries'][int(n)]==e
for x in load('prior-evidence-index.json')['records']:
 d=(p/x['preserved_bytes']).read_bytes();assert (sha(d),len(d))==(x['sha256'],x['bytes'])
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
for x in load('skills.json')['records']:assert sha((p/x['file']).read_bytes())==x['sha256']
for x in load('local-774-equality.json')['records']:
 d=gzip.decompress((p/x['transport_file']).read_bytes());assert x['local_exact_bytes_equal_transport'] and (len(d),sha(d))==(x['bytes'],x['sha256'])
checks.append('Prior capture/readiness manifest-selected evidence, original reconstructed queue and prior assessments')
native=load('native-provenance.json');archive=(p/native['archive']).read_bytes();assert sha(archive)==native['archive_sha256']=='fc86a32b2eef9859e1e7d323c6d1a9150fe77aa17c30fd05abebc12f645929dc'
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:d=tar.extractfile(native['member']).read()
assert d==(p/native['member_bytes']).read_bytes() and sha(d)==native['member_sha256']=='f49e4ca4f0929fc51a5c55fc002294c6009ae7a4c1c07dc6ef6c8ff737df0c5b' and native['previously_inspected_ranges']==[[125,195]]
a=(p/old['source_archive']).read_text().splitlines();b=(p/cur['source_archive']).read_text().splitlines();out=[]
for x,y in [((1593,1644),(1602,1653)),((2656,3327),(2665,3394))]:
 out.append(f'Historic {x[0]}–{x[1]} vs 95e {y[0]}–{y[1]}; bounded source diff\n');out.extend(s+'\n' for s in difflib.unified_diff(a[x[0]-1:x[1]],b[y[0]-1:y[1]],fromfile=f'P16:{x[0]}',tofile=f'95e:{y[0]}',n=1))
assert (p/'bounded-source-diff.txt').read_text()==''.join(out) and a[1592:1644]==b[1601:1653];report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14)) and report['scope']['roles']==[2704];checks.append('Pinned native archive/member prior-read provenance, bounded diff and 13 non-closing lens perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and source read accounting only. No product, viewer, fixture, test, runtime probe, rendering, execution, implementation, checkpoint3821 promotion, proposal adoption or whole-lens closure.'},indent=2))
