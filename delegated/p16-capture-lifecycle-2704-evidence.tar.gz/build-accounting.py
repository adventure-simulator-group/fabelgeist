import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;load=lambda x:json.loads((p/x).read_bytes());write=lambda name,obj:(p/name).write_text(json.dumps(obj,indent=2)+'\n')
def complement(ranges,eof):
 vals={i for a,b in ranges for i in range(a,b+1)}; out=[];start=None
 for i in range(1,eof+2):
  unread=i<=eof and i not in vals
  if unread and start is None:start=i
  if not unread and start is not None:out.append([start,i-1]);start=None
 return out
reg=load('registration.json');sup=load('support-registration.json');assigned={};support={}
for e in reg['entries']:assigned[e['source_archive']]={'revision':e['revision'],'snapshot':e['snapshot'],'EOF':e['actual_EOF'],'displayed_ranges':e['registered_ranges'],'unread_complement':complement(e['registered_ranges'],e['actual_EOF'])}
for e in sup['entries']:support[e['source_archive']]={'path':e['path'],'revision':e['revision'],'EOF':e['actual_EOF'],'displayed_ranges':e['registered_ranges'],'unread_complement':complement(e['registered_ranges'],e['actual_EOF'])}
write('read-scope-summary.json',{'author':'/root/mhr_character','assigned':assigned,'support':support,'qualification':'Only actual displays in this assigned review; archived whole bodies and metadata comparisons do not constitute personal reads. Support viewer 930–970 is separate from assigned role display, and previous packets remain separately attributed.'})
prior=load('prior-capture-review/read-scope-summary.json')['support']['support/viewer.rs']['displayed_ranges'];write('registration-chronology-note.json',{'qualification':'The preceding 2702–2703 packet separately records this reviewer’s earlier current viewer support displays, and the nested 2519–2520 packet retains earlier readiness/openings reads. This role prospectively registered and intentionally re-displayed overlapping current windows; historical body has its own receipt. No ordered role credit or prior authorship is transferred. Original P16 REG045 additionally registered 1645–1648 and 3328 but subsequently excluded them from effective material; later Lens12 frontier independently read them as context.','earlier_2702_2703_viewer_actual_ranges':prior,'prior_receipts':['prior-capture-review/support-read-receipt.json','prior-capture-review/gate-read-receipt.json','prior-capture-review/view-policy-read-receipt.json','prior-capture-review/read-scope-summary.json','prior-capture-review/prior-readiness/support-read-receipt.json'],'this_role_receipts':['personal-read-receipt.json','support-read-receipt.json'],'newly_displayed_in_this_role_not_in_prior_2702_2703_viewer_support':[[2766,3029]],'qualification_new_range':'Relative to cited 2702–2703 viewer support union only, not all earlier work.'})
roots=['<LOCAL_PATH_0>','<LOCAL_PATH_1>'];names=['READ-L12-940.json','VERIFY-L12-940.json','STATE-L12-940.json'];results=[];errors=[]
for root in roots:
 for name in names:
  r=subprocess.run(['rg','--files','--hidden','--no-ignore','-g',name,root],capture_output=True,text=True)
  results.extend(r.stdout.splitlines());
  if r.returncode not in [0,1]:errors.append({'root':root,'name':name,'returncode':r.returncode,'stderr':r.stderr})
man=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));matches=[e['path'] for e in man['entries'] if pathlib.PurePosixPath(e['path']).name in names];write('recovery-search.json',{'searched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roots':roots,'filenames':names,'method':'rg --files --hidden --no-ignore with exact filename globs in these two target roots, and basename scan of original 059 transport manifest.','results':results,'errors':errors,'transport_manifest_matches':matches,'qualification':'Bounded search does not establish global absence. 940 is a proposal explicitly requiring root adoption; adoption is not established by these scans.'});print('search results',len(results),'errors',len(errors),'manifest',len(matches))
