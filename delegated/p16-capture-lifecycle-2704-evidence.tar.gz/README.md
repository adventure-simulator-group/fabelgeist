# Bounded role 2704 capture lifecycle evidence

This packet preserves independently registered source inspection and recovery
for historical physical-P16 registry role 2704 and pinned project revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The P16 snapshot is dirty; its
recorded `a120390947c89b703dc74c4255a13c035d054c50` is the clean base, and
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports archived evidence.
Per-file identity does not establish a clean snapshot. A later recovered tracked
patch matches the original digest; its seven untracked objects remain separate,
and original invocation and uninterrupted custody are not proved.

Start with `report.json`, `registration.json`, `personal-read-receipt.json`,
`support-registration.json`, `support-read-receipt.json`, and
`read-scope-summary.json`. The old qualified material 1593–1644 and 2656–3327
and selected current windows 1590–1655 and 2665–3395 were personally displayed
in bounded chunks. Unread complements are explicit. Earlier support re-reads,
original 774 material and the separately attributed 059 review and proposal
remain separate. The original proposal is not shown to have been adopted.

`git-proofs.json` and `git-objects/` preserve offline raw commit/tree proof,
including 14 source and history membership proofs. Original 059 and 774 records,
reconstructed queue and registry selections, prior assessments, and nested
manifest-qualified predecessor records are retained. `bounded-source-diff.txt`
compares only personally displayed analogous windows. `native-provenance.json`
retains the earlier Bevy screenshot source package with original reader scope;
this role did not personally display or execute that native source.

Run `python3 verify-evidence.py` solely to verify evidence identity, read
accounting and the static source relationships. `python3 verify-manifest.py`
checks the frozen packet including both nested manifests. Neither command runs
product code or establishes product validation. No checkpoint 3821 evidence,
whole-lens closure, implementation, test, viewer, fixture, rendering, probe or
runtime outcome is claimed.
