import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());rs=['support-registration.json','support-registration-02.json'];sup=[x for n in rs for x in json.loads((p/n).read_bytes())['sources']];(p/'git-objects').mkdir(exist_ok=True);objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
locks=[{'revision':rev,'path':'Cargo.lock','local_path':v['path'],'sha256':v['sha256'],'git_blob':v['git_blob']} for rev,v in reg['lock_provenance'].items()]
for s in [x for x in sup if x['kind']=='project git support']+locks:
 rev=s['revision'];commit=obj('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local_path']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();proofs.append({'revision':rev,'path':s['path'],'archive':s['local_path'],'commit_tree':root,'chain':chain,'blob':tree})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Source/lock Git identities only; SDK objects instead derive from verified crates.io archive member and lock checksum. Identity does not convey reading credit.','objects':objects,'proofs':proofs},indent=2)+'\n')
role_reads={2476:[[1,110],[111,220],[221,330],[331,441]],2477:[[1,100],[101,200],[201,275],[276,343]]};read=[{'original_index':r['original_index'],'package':r['package'],'version':r['version'],'sha256':r['sha256'],'actual_display_ranges':role_reads[r['original_index']],'unread_ranges':[],'eof':r['registered_range'][1]} for r in reg['roles']];(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration':{'path':'registration.json','sha256':sha((p/'registration.json').read_bytes())},'reads':read,'qualification':'These are exact personally displayed native source bodies, including existing test/example source text, not execution. Other historical reviewers retain their own scopes.'},indent=2)+'\n')
ranges=[[[1,125],[119,220]],[[1,127]],[[1,98]],[[1,107]],[[1,44]],[[1,31]],[[124,138],[169,182]],[[1,120]],[[1,98]],[[350,435]],[[1,65]],[[275,330]]];assert len(sup)==len(ranges);reads=[]
for s,rr in zip(sup,ranges):reads.append({'kind':s['kind'],'revision':s.get('revision'),'path':s.get('path',s.get('member')),'archive':s['local_path'],'sha256':s['sha256'],'eof':s['registered_range'][1],'actual_body_display_ranges':rr})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in rs],'reads':reads,'qualification':'Support only; precisely displayed windows, no ordered-role credit. Remainder archived, not read. Native time_duration is package archive member, not project Git source.'},indent=2)+'\n');print('project support+lock proofs',len(proofs),'support reads',len(reads))
