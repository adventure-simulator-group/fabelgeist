# Delegated noiz and SpacetimeDB SATS source evidence

This packet covers original source roles 2476–2477 by `/root/hair_ops`.
`report.json` contains the bounded assessment and thirteen lens perspectives.
`registration.json` and `read-receipt.json` record exact prospective native
source identities and personally displayed ranges. The support registrations
and receipt delimit the separately inspected project and native context.

These are external registry sources, not project Git snapshots. The exact
noiz 0.5.0 and spacetimedb-sats 2.6.1 source members match their original
recovered source objects and the included cached package archives. Both archive
checksums match the package entries in the included 6533 and 95e Cargo.lock
bytes. Git commit/tree proofs cover the lockfiles and current project support,
while archive/member checks prove the external source identity. Lockfile
selection is not proof of a resolved feature set or executed package.

Both assigned native files were displayed completely, including any examples
or test source text, without execution. Historical 059/774 supplier, delegated
and central reviewer ranges and attributions remain distinct. In particular,
the L12 timestamp-tail root adoption and the later pending-adoption statement
are both retained as conflicting historical records. Nothing is promoted to
checkpoint 3821. Existing related queue and native observations are carried
forward without assigning a new application defect or automatically merging
first failures.

The report names the limits of the current terrain and clock traces; uninspected
noiz sibling algorithms, Chrono/platform behavior, actual runtime ranges and
other callers remain open. `evidence-verification.json` reports evidence
identity and accounting checks only. No package, product, renderer, browser,
build, test, runtime probe, simulated fixture, or repair was executed.
