import datetime,gzip,hashlib,json,pathlib,subprocess,tarfile,tomllib
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());unzip=lambda n:gzip.decompress((p/n).read_bytes());reg=load('registration.json');orig=json.loads(unzip('reference/registry.json.gz'));cat=json.loads(unzip('reference/older-source-catalog.json.gz'));gp=load('git-proofs.json');checks=[]
for rev,lock in reg['lock_provenance'].items():
 b=(p/lock['path']).read_bytes();assert sha(b)==lock['sha256'] and blob(b)==lock['git_blob'] and subprocess.check_output(['git','-C',repo,'show',rev+':Cargo.lock'])==b;d=tomllib.loads(b.decode());assert {x['name']:x for x in d['package'] if x['name'] in ('noiz','spacetimedb-sats')}==lock['packages']
for r in reg['roles']:
 row=orig['files'][r['original_index']];c=[x for x in cat['rows'] if x['scope_index']==r['original_index']];assert len(c)==1 and row['source_id']==r['source_id']==c[0]['source_id'] and row['sha256']==r['sha256']==c[0]['expected_sha256'];b=(p/r['local_source']).read_bytes();a=(p/r['archive']).read_bytes();assert (len(b),sha(b),len(b.splitlines()))==(r['bytes'],r['sha256'],r['registered_range'][1]);assert sha(a)==r['archive_sha256'] and len(a)==r['archive_bytes'];assert pathlib.Path(r['original_recovered_object']).read_bytes()==b==pathlib.Path(r['local_registry_origin']).read_bytes()
 with tarfile.open(p/r['archive'],'r:gz') as t:
  assert t.extractfile(r['member']).read()==b;cb=t.extractfile(r['package']+'-'+r['version']+'/Cargo.toml').read();package=tomllib.loads(cb.decode())['package'];assert package['name']==r['package'] and package['version']==r['version'] and cb==(p/r['archive_cargo_toml']).read_bytes() and sha(cb)==r['archive_cargo_toml_sha256']
 for lock in reg['lock_provenance'].values():
  pk=lock['packages'][r['package']];assert pk['version']==r['version'] and pk['checksum']==r['archive_sha256'] and pk['source']=='registry+https://github.com/rust-lang/crates.io-index'
checks.append('both external package/member identities match original 059 registry, 774 recovered objects, local extraction, crate archives, package manifests and both git-versioned Cargo.lock checksums')
support=[s for n in ['support-registration.json','support-registration-02.json'] for s in load(n)['sources']]
for s in support:
 b=(p/s['local_path']).read_bytes();assert (len(b),sha(b),len(b.splitlines()))==(s['bytes'],s['sha256'],s['registered_range'][1])
 if s['kind']=='project git support':assert blob(b)==s['git_blob'] and subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['path']])==b
 else:
  assert sha((p/s['archive']).read_bytes())==s['archive_sha256']
  with tarfile.open(p/s['archive'],'r:gz') as t:assert t.extractfile(s['member']).read()==b
checks.append('11 current git support bodies and native TimeDuration member match their registered identities')
def tree_entries(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);z=b.index(b'\0',j);d[b[j+1:z].decode()]=(b[i:j].decode(),b[z+1:z+21].hex());i=z+21
 return d
def object_data(oid):
 v=gp['objects'][oid];b=unzip(v['archive']);t=v['type'];assert len(b)==v['bytes'] and sha(b)==v['sha256'] and hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;return b
for oid in gp['objects']:object_data(oid)
for proof in gp['proofs']:
 commit=object_data(proof['revision']);tree=commit.splitlines()[0].split()[1].decode();assert tree==proof['commit_tree']
 for e in proof['chain']:
  assert e['tree']==tree and tree_entries(object_data(tree))[e['name']]==(e['mode'],e['object']);tree=e['object']
 assert tree==proof['blob']==blob((p/proof['archive']).read_bytes())
assert len(gp['proofs'])==13;checks.append('13 archived raw Git commit/tree/source membership chains independently verified for project support and lockfiles')
rr=load('read-receipt.json');assert rr['prospective_registration']['sha256']==sha((p/'registration.json').read_bytes())
for row in rr['reads']:
 ranges=row['actual_display_ranges'];covered=set()
 for a,b in ranges:assert 1<=a<=b<=row['eof'];covered.update(range(a,b+1))
 assert len(covered)==row['eof'] and row['unread_ranges']==[]
sr=load('support-read-receipt.json');assert len(sr['reads'])==12
for x in sr['reads']:
 for a,b in x['actual_body_display_ranges']:assert 1<=a<=b<=x['eof']
for x in sr['prospective_registrations']:assert sha((p/x['path']).read_bytes())==x['sha256']
checks.append('full native personal displays and bounded support display scopes recorded under prior registrations')
trans={e['path']:e for e in json.loads(unzip('reference/original-transport-manifest.json.gz'))['entries']};h=load('historical-manifest.json');assert not h['unavailable']
for x in h['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
checks.append(f"{len(h['records'])} original 059 records match transport bytes, SHA256 and Git blob")
oldix={x['path']:x for x in json.loads(unzip('reference/older-774-handoff-manifest.json.gz'))['files']};old=load('reference/older-selection.json')
for x in old['records']:
 b=unzip(x['copy']);e=oldix[x['path']];assert (len(b),sha(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256'])
additional=next(x for x in old['records'] if x['path'].endswith('additional-sources.jsonl'));lines=unzip(additional['copy']).splitlines();assert json.loads(lines[33])['sha256']==reg['roles'][0]['sha256'] and json.loads(lines[33])['read_ranges']==[[100,180]];assert json.loads(lines[30])['sha256']==reg['roles'][1]['sha256'] and json.loads(lines[30])['read_ranges']==[[1,195]]
trace=next(x for x in old['records'] if x['path'].endswith('traces.jsonl'));assert json.loads(unzip(trace['copy']).splitlines()[27])['id']=='ROOT-PPS-BOUNDARY-METADATA-028';checks.append('774 original supplier rows and producer trace match handoff manifest, exact role ranges and prior source authorship')
for x in load('reference/prior-selection.json')['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
manifest=load('reference/prior-native-evidence__spacetimedb-sats-2.6.1__MANIFEST.json');assert manifest['sha256']==reg['roles'][1]['archive_sha256'] and manifest['inspected_members'][0]['sha256']==reg['roles'][1]['sha256'];priorlock=unzip('reference/prior-main-advance-95e__basis-wire-sources__01.source.gz');assert sha(priorlock)==reg['lock_provenance']['95e63628f9d70b8dd6e6fede64334696c6995009']['sha256'];checks.append('prior central SATS native manifest and separately preserved current lock bytes match identities, without read credit transfer')
for x in load('reference/rules.json')['rules']:assert sha((p/x['copy']).read_bytes())==x['sha256']
q=json.loads(unzip('reference/queue-059.json.gz'))['entries'];r=load('report.json');assert len(r['lenses'])==13 and {x['number'] for x in r['lenses']}==set(range(1,14));assert all(q[x['zero_based_index']]['contract_id']==x['contract_id'] and q[x['zero_based_index']]['status']==x['status'] for x in r['historical_queue']);a=load('historical/segovb/READ-L12-CONNECTED-TEAM-015.json');b=load('historical/segovb/READ-L12-839.json');assert a['at']<b['at'] and 'needs separate root adoption' in json.dumps(b['pending']);assert any(row.get('original_index')==2477 and row.get('fresh_personal_body_reads')==[[196,343]] for row in a['checked_rows']);checks.append('13 bounded lens views, original queue statuses and 059 timestamp-tail adoption/pending discrepancy preserved')
out={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','checks':checks,'qualification':'Evidence identity and accountancy only; no package/product execution, test, build, probe, simulation, fixture, repair or validation.'};(p/'evidence-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
