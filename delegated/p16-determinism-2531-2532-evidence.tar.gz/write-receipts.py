import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def missing(n,r):
 seen={i for a,z in r for i in range(a,z+1)};out=[]
 for i in sorted(set(range(1,n+1))-seen):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for reg,out in [('registration.json','read-receipt.json'),('support-registration.json','support-read-receipt.json')]:
 x=json.loads((p/reg).read_bytes());rows=[]
 for e in x['entries']:
  r=([[1,75],[76,150],[151,213]] if e['role']==2531 else [[1,60],[61,120],[121,169]]) if reg=='registration.json' else e['registered_ranges']
  rows.append({'archive':e['archive'],'sha256':e['sha256'],'displayed_chunks':r,'unread_complement':missing(e['EOF'],r)})
 (p/out).write_text(json.dumps({'author':'/root/mhr_character','receipt_utc':now,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':rows,'qualification':'Personal untruncated numbered source displays after registration. Test source was read as text only and was never executed; no earlier read or other-lens credit transfers.'},indent=2)+'\n')
