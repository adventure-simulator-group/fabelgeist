import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and [x['index'] for x in sel['rows']]==[2531,2532] and all(x['row']==reg['files'][x['index']] for x in sel['rows']);snap=next(z for z in reg['snapshots'] if z['id']=='physical-p16');assert snap==sel['snapshot'] and snap['head']=='a120390947c89b703dc74c4255a13c035d054c50';patch=(p/'reference/p16-tracked.patch').read_bytes();assert sha(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256'],e['file']
for x in load('registration.json')['comparisons']:
 assert x['p16_equals_base'] and x['p16_equals_current'] and x['base_equals_current'];assert not [z for z in snap['status_porcelain'] if z[3:]==x['path']];assert f"diff --git a/{x['path']} b/{x['path']}\n".encode() not in patch
for label,rf,tf in [('assigned','registration.json','read-receipt.json'),('support','support-registration.json','support-read-receipt.json')]:
 a=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes()) and datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(a['registered_utc']);assert len(a['entries'])==len(t['entries'])
 for e,v in zip(a['entries'],t['entries']):
  b=(p/e['archive']).read_bytes();assert sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'] and e['archive']==v['archive'];planned={i for lo,hi in e['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in v['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in v['unread_complement'] for i in range(lo,hi+1)};assert planned==seen and seen|missing==set(range(1,e['EOF']+1)) and not seen&missing
  if e.get('label')=='historical-p16':assert reg['files'][e['role']]['sha256']==e['sha256'] and reg['files'][e['role']]['material_ranges']==e['original_material_ranges']
 counts[label]=len(a['entries'])
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']}
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=json.loads(qraw);x=load('queue-selection-reconstructed.json');assert x['source_sha256']==sha(qraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for n in ('001','004'):
 x=load(f'history-059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-{n}.json');assert x['registration_sha256']==sha((p/'history-059'/x['registration']).read_bytes())
x=load('history-059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-001.json');assert x['rows'][2]['fresh_personal_body_ranges']==[[1,213]] and x['rows'][3]['fresh_personal_body_ranges']==[[1,169]] and x['rows'][2]['sha256']==reg['files'][2531]['sha256'] and x['rows'][3]['sha256']==reg['files'][2532]['sha256']
x=load('history-059/segovb/READ-L12-724.json');assert x['proposal_sha256']==sha((p/'history-059'/x['proposal']).read_bytes());z=x['connected_future_original_evidence'][0];assert z['receipt_sha256']==sha((p/'history-059'/z['receipt']).read_bytes()) and z['registration_sha256']==sha((p/'history-059'/z['registration']).read_bytes()) and z['assessed_ranges']==[[1,169]] and z['source_sha256']==reg['files'][2532]['sha256']
def lines(f):return [json.loads(z) for z in gzip.decompress((p/f).read_bytes()).splitlines()]
prefix='history-774/continuation/';rig=lines(prefix+'rig/owner-reached-producer-followup/additional-sources.jsonl.gz');qual=lines(prefix+'rig/owner-reached-producer-followup/source-qualifications.jsonl.gz');adm=lines(prefix+'rig/admission03/source-range-registration.jsonl.gz')
for role,row in ((2531,48),(2532,49)):
 x=rig[row];y=qual[row];pentry=reg['files'][role]['producer_followup_scope_additions'][0]['registered_before_body_analysis'][0];assert all(x[k]==pentry['original_record'][k] for k in ('id','source_id','snapshot','sha256','actual_EOF','material_ranges','authority','status')) and all(y[k]==pentry['per_registration_qualification']['original_record'][k] for k in ('id','registration_ref','registration_id','source_id','snapshot','sha256','actual_EOF','original_registered_ranges','qualified_material_ranges','body_proof','scope_and_owner_gate')) and y['qualified_material_ranges']==reg['files'][role]['material_ranges'] and x['snapshot']=='p16'
for e in load('history-reconciliation.json')['comparisons']:
 row=e['source_row_one_based']-1; pe=reg['files'][e['role']]['producer_followup_scope_additions'][0]['registered_before_body_analysis'][0]; a,b=(rig[row],pe['original_record']) if e['type']=='registration' else (qual[row],pe['per_registration_qualification']['original_record']);actual=[{'field':k,'774_record_value':a.get(k),'registry_embedded_value':b.get(k)} for k in sorted(set(a)|set(b)) if a.get(k)!=b.get(k)];assert e['differences']==actual
for role,row in ((2531,30),(2532,31)):
 e=reg['files'][role]['admission03_increment046_role_observations'][0];assert adm[row]==e['original_record'] and adm[row]['snapshot']=='physical-p16'
native=lines(prefix+'native/admission03/source-range-registration.jsonl.gz')[86];camera=lines(prefix+'camera/admission03/source-range-registration.jsonl.gz')[28];extra=reg['files'][2532]['admission03_increment077_role_observations'];assert native==extra[0]['original_record'] and camera==extra[1]['original_record'];nqual=lines(prefix+'native/admission03/camera-support/source-qualifications-011.jsonl.gz')[14];assert nqual==extra[0]['local_qualifications'][0]['qualification_history'][0]['payload'] and nqual['qualified_material_ranges']==[[12,28],[105,115]]
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==24 and len(report['lens_perspectives'])==13 and len({z['lens'] for z in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'qualification':'Offline evidence integrity only; no RNG, product, test, fixture, macro or runtime execution.'},indent=2))
