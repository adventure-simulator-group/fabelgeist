import gzip,json,pathlib
p=pathlib.Path(__file__).parent;reg=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));lines=lambda f:[json.loads(x) for x in gzip.decompress((p/f).read_bytes()).splitlines()];rig=lines('history-774/continuation/rig/owner-reached-producer-followup/additional-sources.jsonl.gz');qual=lines('history-774/continuation/rig/owner-reached-producer-followup/source-qualifications.jsonl.gz');out=[]
for role,row in [(2531,48),(2532,49)]:
 e=reg['files'][role]['producer_followup_scope_additions'][0]['registered_before_body_analysis'][0]
 for label,a,b in [('registration',rig[row],e['original_record']),('qualification',qual[row],e['per_registration_qualification']['original_record'])]:
  differences=[{'field':k,'774_record_value':a.get(k),'registry_embedded_value':b.get(k)} for k in sorted(set(a)|set(b)) if a.get(k)!=b.get(k)]
  out.append({'role':role,'type':label,'source_row_one_based':row+1,'differences':differences})
(p/'history-reconciliation.json').write_text(json.dumps({'comparisons':out,'qualification':'Exact 774 and embedded registry values differ in some narrative strings; 774 source uses readable Unicode while embedded registry displays mojibake. IDs, hashes, source labels, line ranges and qualification semantics are separately checked. Neither copy is changed, nor is a cause or silent normalization assumed.'},indent=2,ensure_ascii=False)+'\n');print('differing fields',sum(len(x['differences']) for x in out))
