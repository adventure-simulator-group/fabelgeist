from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,tarfile
b=Path(__file__).resolve().parent;prior=Path('<LOCAL_PATH_0>');previous=Path('<LOCAL_PATH_1>');extract=Path('<LOCAL_PATH_2>');pub=Path('<LOCAL_PATH_3>');sha=lambda d:hashlib.sha256(d).hexdigest();gb=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();w=lambda p,d:(b/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
reg=json.loads((b/'registration.json').read_bytes());reads=[]
for e in reg['entries']:
 covered=set(i for a,z in e['prospective_display_ranges'] for i in range(a,z+1));unread=[];start=None
 for i in range(1,e['eof']+2):
  if i<=e['eof'] and i not in covered:
   if start is None:start=i
  elif start is not None:unread.append([start,i-1]);start=None
 reads.append({'id':e['id'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_ranges':e['prospective_display_ranges'],'unread_complement':unread})
w('personal-read-receipt.json',{'recorded_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','registration_sha256':sha((b/'registration.json').read_bytes()),'reads':reads,'qualification':'Exact prospectively registered windows displayed with line numbers; stored unread bytes are not source-read credit.'})
(b/'history').mkdir(exist_ok=True)
for name in ['original-registry.json.gz','original-transport-manifest.json.gz','baseline-059-queue.json.gz']:shutil.copyfile(previous/'history'/name,b/'history'/name)
orig=json.load(gzip.open(b/'history/original-registry.json.gz','rt'));q=json.load(gzip.open(b/'history/baseline-059-queue.json.gz','rt'));w('history/reconstructed-selections.json',{'qualification':'Mechanically reconstructed selection of exact original recovered 059 queue and source registry; not an original standalone record or checkpoint3821 status.','registry_sha256':sha(gzip.decompress((b/'history/original-registry.json.gz').read_bytes())),'registry_roles':{str(i):orig['files'][i] for i in [2565,2566]},'queue_sha256':sha(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes())),'queue_entries':{'2332':q['entries'][2332]}})
manifest=json.load(gzip.open(b/'history/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in manifest['entries']};entries=[]
paths=['segovb/READ-L11-422.json','segovb/REGISTRATION-SEGOVB-1472.json','segovb/REGISTRATION-SEGOVB-1473.json','segovb/READ-L12-870.json','parallel-l12-20261029/PROPOSAL-L12-870.json','parallel-l12-20261029/REGISTRATION-PAR-L12-612.json','parallel-l12-20261029/REGISTRATION-PAR-L12-613.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-612-WINDOWS-ORIGINAL2565.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-613-WINDOWS-ORIGINAL2566.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-865-872.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-869-MACRO-LOCK-AUTHORITY.json']
for p in paths:
 d=(extract/p).read_bytes();x=idx[p];assert (len(d),sha(d),gb(d))==(x['bytes'],x['sha256'],x['git_blob']);dest='history/059/'+p;(b/dest).parent.mkdir(parents=True,exist_ok=True);(b/dest).write_bytes(d);entries.append({'kind':'059','original_path':p,'copy':dest,'sha256':sha(d),'bytes':len(d),'git_blob':gb(d)})
old=json.loads((prior/'historical-774-index.json').read_bytes())
for x in old['records']:
 src=prior/x['copy'];dest='history/774/'+Path(x['copy']).name;d=gzip.decompress(src.read_bytes());assert sha(d)==x['sha256'] and len(d)==x['bytes'] and gb(d)==x['git_blob_sha1'];(b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(src.read_bytes());entries.append({'kind':'774-f82','transport_revision':x['git_transport_revision'],'transport_path':x['git_transport_path'],'copy':dest,'encoding':'gzip','sha256_uncompressed':sha(d),'bytes_uncompressed':len(d),'git_blob':gb(d)})
for n in ['report.json','registration.json','read-receipt.json','support-read-receipt.json','BUNDLE-MANIFEST.json','historical-774-index.json']:
 d=(prior/n).read_bytes();dest='history/prior-'+n;(b/dest).write_bytes(d);entries.append({'kind':'prior-95e-delegate','author':'/root/mhr_character','copy':dest,'sha256':sha(d),'bytes':len(d)})
for n in ['REPORT.json','MANIFEST.json']:
 d=(previous/n).read_bytes();dest='history/prior-2563-'+n;(b/dest).write_bytes(d);entries.append({'kind':'prior-95e-delegate','author':'/root/rig_identity','copy':dest,'sha256':sha(d),'bytes':len(d)})
a=pub/'delegated/reflect-opaque-common-evidence.tar.gz';comparison=[]
with tarfile.open(a,'r:gz') as t:
 for n in ['report.json','registration.json','read-receipt.json','support-read-receipt.json','BUNDLE-MANIFEST.json','historical-774-index.json']:
  p=t.extractfile(n).read();o=(prior/n).read_bytes();dest='history/public-prior-'+n;(b/dest).write_bytes(p);comparison.append({'member':n,'original_sha256':sha(o),'published_sha256':sha(p),'equal':o==p,'published_copy':dest})
w('history/published-comparison.json',{'published_archive':'delegated/reflect-opaque-common-evidence.tar.gz','published_archive_sha256':sha(a.read_bytes()),'original_and_published_members':comparison,'qualification':'Only these selected members were compared. Their identities differ where local paths were redacted. Exact public archive remains separately hash-linked at its published location; no whole-archive equality inferred.'})
w('history/attribution-and-copies.json',{'records':entries,'original_774_pin_qualification':old['hash_qualifications'],'qualification':'Original 059 copies match transport manifest; 774 copies match raw Git blobs under f82; prior delegate report and receipt are separately attributed. No checkpoint3821 promotion.'});print('reads',len(reads),'history records',len(entries),'published comparisons',len(comparison))
