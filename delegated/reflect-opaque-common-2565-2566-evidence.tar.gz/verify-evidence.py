#!/usr/bin/env python3
from pathlib import Path
import gzip,hashlib,json,tarfile,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();read=lambda p:(b/p).read_bytes();js=lambda p:json.loads(read(p));jgz=lambda p:json.loads(gzip.decompress(read(p)))
reg=js('registration.json');receipt=js('personal-read-receipt.json');assert receipt['registration_sha256']==sha(read('registration.json')) and receipt['recorded_utc']>=reg['registered_utc'];rr={x['id']:x for x in receipt['reads']};assert len(rr)==len(reg['entries'])
with tarfile.open(b/reg['archive']['path'],'r:gz') as t:
 assert sha(read(reg['archive']['path']))==reg['archive']['sha256']=='5fc5f820ee52afeca6d3bb83f15c1bf61ea6196c840a761a21a8bc266a3b166e'
 cargo=tomllib.loads(t.extractfile('bevy_reflect_derive-0.19.1/Cargo.toml').read().decode());assert cargo['package']['name']=='bevy_reflect_derive' and cargo['package']['version']=='0.19.1'
 for e in reg['entries']:
  d=read(e['archive']);assert sha(d)==e['sha256'] and len(d)==e['bytes'] and len(d.splitlines())==e['eof'];r=rr[e['id']];assert r['sha256']==e['sha256'] and r['eof']==e['eof'] and r['actual_display_ranges']==e['prospective_display_ranges'];covered=set(i for a,z in r['actual_display_ranges'] for i in range(a,z+1));unread=set(i for a,z in r['unread_complement'] for i in range(a,z+1));assert not covered&unread and covered|unread==set(range(1,e['eof']+1))
  if e.get('member'):assert d==t.extractfile(e['member']).read()
  if e['id'].startswith('lock-'):
   lock=tomllib.loads(d.decode());p=[x for x in lock['package'] if x['name']=='bevy_reflect_derive' and x['version']=='0.19.1'];assert len(p)==1 and p[0]['source']=='registry+https://github.com/rust-lang/crates.io-index' and p[0]['checksum']==reg['archive']['sha256']
report=js('REPORT.json');assert [x['index'] for x in report['historical_queue_relationships']]==[2332]
for a in report['assessments']:
 for ref in a['references']:
  covered=set(i for x,y in rr[ref['source']]['actual_display_ranges'] for i in range(x,y+1));assert all(i in covered for x,y in ref['lines'] for i in range(x,y+1))
gp=js('git-proofs.json');raw={}
for key,x in gp['objects'].items():
 d=gzip.decompress(read(x['preserved_bytes']));assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==key;raw[key]=d
for rev,x in gp['commits'].items():assert raw[rev].splitlines()[0]==b'tree '+x['root_tree'].encode()
def ents(d):
 z={};i=0
 while i<len(d):
  j=d.index(b'\0',i);m,n=d[i:j].split(b' ',1);z[n.decode()]=(m.decode(),d[j+1:j+21].hex());i=j+21
 return z
for x in gp['paths']:
 d=read(x['preserved_bytes']);d=gzip.decompress(d) if x['preserved_bytes'].endswith('.gz') else d;assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob'];cur=gp['commits'][x['revision']]['root_tree'];names=[]
 for y in x['path_chain']:
  assert cur==y['tree'];mode,child=ents(raw[cur])[y['name']];assert (mode,child)==(y['mode'],y['object']);cur=child;names.append(y['name'])
 assert '/'.join(names)==x['path'] and cur==x['git_blob']
registry=jgz('history/original-registry.json.gz');queue=jgz('history/baseline-059-queue.json.gz');transport=jgz('history/original-transport-manifest.json.gz');idx={x['path']:x for x in transport['entries']};sel=js('history/reconstructed-selections.json')
for path,file in [('evidence/audit05/original-scope-072.json','history/original-registry.json.gz'),('workflow-20261030/CLOSURE-QUEUE-100.json','history/baseline-059-queue.json.gz')]:
 d=gzip.decompress(read(file));assert (len(d),sha(d),oid('blob',d))==(idx[path]['bytes'],idx[path]['sha256'],idx[path]['git_blob'])
assert sha(gzip.decompress(read('history/original-registry.json.gz')))==sel['registry_sha256'] and sha(gzip.decompress(read('history/baseline-059-queue.json.gz')))==sel['queue_sha256']
for n in [2565,2566]:assert sel['registry_roles'][str(n)]==registry['files'][n] and registry['files'][n]['sha256']==next(x['sha256'] for x in reg['entries'] if x.get('role')==n)
assert sel['queue_entries']['2332']==queue['entries'][2332] and queue['entries'][2332]['status']=='open-source-reconciliation'
attrs=js('history/attribution-and-copies.json')
for x in attrs['records']:
 d=read(x['copy']);d=gzip.decompress(d) if x.get('encoding')=='gzip' else d
 if x['kind']=='774-f82':assert (len(d),sha(d),oid('blob',d))==(x['bytes_uncompressed'],x['sha256_uncompressed'],x['git_blob'])
 else:assert (len(d),sha(d))==(x['bytes'],x['sha256'])
 if x['kind']=='059':
  y=idx[x['original_path']];assert (len(d),sha(d),oid('blob',d))==(y['bytes'],y['sha256'],y['git_blob'])
root=jgz('history/774/admission03-scope-reconciliation-044.json.gz');regp=gzip.decompress(read('history/774/source-range-registration.jsonl.gz'));qp=gzip.decompress(read('history/774/source-qualifications.jsonl.gz'));pin=[x for x in root['input_pins'] if x['supplier']=='rig' and x.get('rows')==13][0];qpin=[x for x in root['input_pins'] if x['supplier']=='rig' and x.get('kind')=='qualification'][0];assert len(regp.splitlines())==145 and sha(regp)=='24fb01a82c91de97fd9895740404dc79a73877fcd79a846c832c45cbf2495bdb';assert pin['sha256']=='c75d93513422266bff64a096b243766fbd002d346f1d8c3c5b58f54af25ba06c' and sha(b''.join(regp.splitlines(keepends=True)[:13]))=='442704cfbcdb6f971a06981c68f1442451ccbd9eb7e039dfda32e5d639a772d9'!=pin['sha256'];assert sha(b''.join(qp.splitlines(keepends=True)[:13]))==qpin['sha256']=='70717aa1c0908935341afa5297937f1bf79513146453c1328076848d00e94e53';assert jgz('history/774/completion-112.json.gz')['pins'][4]['sha256']=='698ec787519f08585b75f3ce7f2fd08f0e8793f4f4837f91d88151c2c7783db1'
old=jgz('history/older-774-handoff-manifest.json.gz');match=[x for x in old['files'] if x['path']=='audit/reconcile-adler-20261023/audit-continuation/operations/contract-groups-615.json'];d=read('history/774-segovb-contract-615.json');assert len(match)==1 and (len(d),sha(d))==(match[0]['bytes'],match[0]['sha256'])
prior=js('history/prior-BUNDLE-MANIFEST.json');pi={x['path']:x for x in prior['files']}
for n in ['report.json','registration.json','read-receipt.json','support-read-receipt.json','historical-774-index.json']:
 d=read('history/prior-'+n);assert (len(d),sha(d))==(pi[n]['bytes'],pi[n]['sha256'])
c=js('history/published-comparison.json')
for x in c['original_and_published_members']:
 p=read(x['published_copy']);o=read('history/prior-'+x['member']);assert sha(p)==x['published_sha256'] and sha(o)==x['original_sha256'] and (p==o)==x['equal']
p16=js('history/p16-lock-and-recovery.json');d=gzip.decompress(read(p16['historic_lock']['copy']));assert sha(d)==p16['historic_lock']['sha256']==registry['files'][39]['sha256'];lock=tomllib.loads(d.decode());assert any(p['name']=='bevy_reflect_derive' and p['version']=='0.19.1' and p['checksum']==reg['archive']['sha256'] for p in lock['package']);rec=js('history/p16-recovery.json');assert sha(read('history/p16-tracked.patch'))==rec['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
print(json.dumps({'status':'passed','source_entries':len(reg['entries']),'historical_records':len(attrs['records']),'git_path_proofs':len(gp['paths']),'git_objects':len(gp['objects']),'queue_entries':[2332],'original_774_pin_mismatch':'confirmed and explicitly preserved','product_execution':'none; evidence verification only','writes':'none'},indent=2))
