import gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';reg=json.loads((p/'registration.json').read_bytes());records=[]
for e in reg['entries']:
 records.append({'kind':'assigned historical per-file base' if e['original_material_ranges'] else 'assigned current','revision':e['revision'],'path':e['path'],'archive':e['source_archive'],'sha256':e['sha256'],'blob':e['git_blob']})
 if e['original_material_ranges']:records.append({'kind':'historical original object transport','revision':f82,'path':e['transport_path'],'archive':e['source_archive'],'sha256':e['sha256'],'blob':e['git_blob']})
for f in ['support-registration.json','extra-registration.json','projection-registration.json','treatment-registration.json','reducer-registration.json','gates-registration.json']:
 for e in json.loads((p/f).read_bytes())['rows']:records.append({'kind':'current support','revision':e['revision'],'path':e['path'],'archive':e['file'],'sha256':e['sha256'],'blob':e['blob']})
e=json.loads((p/'historical-support-unread.json').read_bytes());records.append({'kind':'original 774 supporting object, preserved but unread by this reviewer','revision':e['transport_revision'],'path':e['transport_path'],'archive':e['preserved_bytes'],'sha256':e['sha256'],'blob':e['git_blob']})
for e in json.loads((p/'historical-index.json').read_bytes())['records']:
 if e['kind']=='historical-774':records.append({'kind':'historical 774 transport','revision':f82,'path':e['transport_path'],'archive':e['file'],'sha256':e['sha256'],'blob':e['git_blob'],'encoding':'gzip'})
(p/'git-objects').mkdir(exist_ok=True);objs={};proof=[]
def data(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objs:
  dst=p/'git-objects'/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objs[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in records:
 commit=data('commit',x['revision']);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(data('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (hashlib.sha256(b).hexdigest(),oid,tree)==(x['sha256'],x['blob'],x['blob']);proof.append(dict(x,commit_tree=root,chain=chain))
(p/'git-proofs.json').write_text(json.dumps({'objects':objs,'proofs':proof,'qualification':'Per-file source membership at a120/current 95e; f82 is evidence transport, not project revision. Physical P16 is a dirty snapshot.'},indent=2)+'\n');print('proofs',len(proof),'objects',len(objs))
