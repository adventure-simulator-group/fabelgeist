import pathlib,subprocess,hashlib,json,datetime
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';(p/'support').mkdir(exist_ok=True);rows=[]
specs=[('crates/adventuresim-stdb-module/src/world_actor.rs',[[176,250],[835,935]])]
for i,(path,ranges) in enumerate(specs):
 b=subprocess.check_output(['git','-C',repo,'show',f'{rev}:{path}']);blob=subprocess.check_output(['git','-C',repo,'rev-parse',f'{rev}:{path}'],text=True).strip();rel=f'support/projection-{i}.rs';(p/rel).write_bytes(b);rows.append(dict(path=path,revision=rev,sha256=hashlib.sha256(b).hexdigest(),blob=blob,bytes=len(b),eof=len(b.splitlines()),prospective_ranges=ranges,file=rel))
x=dict(author='/root/mhr_character',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='Current context-view projection and treatment actor clock conditions only; bounded support.',navigation_qualification='Exact-spelling source metadata navigation and earlier current evidence report read occurred before registration; no new support source bodies displayed.',rows=rows);(p/'projection-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
