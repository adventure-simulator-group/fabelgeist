#!/usr/bin/env python3
"""Self-contained source/evidence integrity and read-scope checks, no product execution."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('personal-read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['recorded_utc'] and len(receipt['reads'])==len(r['entries'])==2
for x in receipt['reads']:
 e=next(y for y in r['entries'] if y['snapshot']==x['snapshot']);b=(p/x['archive']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['actual_display_chunks']==e['planned_chunks'] and x['actual_display_ranges']==[[1,196]] and not x['unread_complement']
assert r['entries'][0]['sha256']==r['entries'][1]['sha256'];checks.append('Distinct prospectively registered historical/current full 1–196 displays and exact per-file identity')
reads=[]
for key,count in [('support',4),('extra',4),('projection',1),('treatment',2),('reducer',2),('gates',1)]:
 sr=load(key+'-registration.json');rc=load(key+'-read-receipt.json');assert rc['registration_sha256']==sha((p/(key+'-registration.json')).read_bytes()) and sr['at']<rc['at'] and len(rc['reads'])==count;reads.extend(rc['reads'])
 for x in rc['reads']:
  e=next(e for e in sr['rows'] if e['file']==x['source_file']);b=(p/e['file']).read_bytes();assert (sha(b),blob(b),len(b.splitlines()))==(e['sha256'],e['blob'],e['eof']) and e['prospective_ranges']==x['actual_ranges'];a={i for f,t in x['actual_ranges'] for i in range(f,t+1)};u={i for f,t in x['unread_for_this_registration'] for i in range(f,t+1)};assert not a&u and a|u==set(range(1,e['eof']+1))
note=load('registration-chronology-note.json');assert len(note['overlapping_registrations'])==2 and '835–855' in note['overlapping_registrations'][0]['previously_displayed_overlap']
checks.append('Fourteen current support body registrations, actual ranges/complements and overlapping pre-registered re-displays')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['original_registry_sha256_uncompressed']==sha(raw)
for x in sel['rows']:assert reg['files'][x['original_index']]==x['entry']
snap=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert sel['physical_p16_snapshot']==snap and snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and not any(x[3:]=='crates/adventuresim-stdb-module/src/world_actor/presence.rs' for x in snap['status_porcelain'])
assert sha((p/'reference/p16-tracked.patch').read_bytes())==snap['patch_sha256'] and sha((p/'reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007';h=load('historical-support-unread.json');b=(p/h['preserved_bytes']).read_bytes();assert h['registry_role']==317 and reg['files'][317]['sha256']==h['sha256'] and (len(b),sha(b),blob(b))==(h['bytes'],h['sha256'],h['git_blob']) and ' M crates/adventuresim-stdb-module/src/world_actor.rs' in snap['status_porcelain']
assert sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));entries={x['path']:x for x in manifest['entries']}
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==10 and sum(x['kind']=='historical-774' for x in hi['records'])==3
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
assert not any('segovb/'+t+'-L12-934.json' in entries for t in ['READ','VERIFY','STATE']);assert len(load('recovery-search.json')['roots'])==2
checks.append('Original dirty P16 registry, later patch and unread modified parent object; ten 059 and three 774 records verified')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==21
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Twenty-one raw project and f82 transport membership proofs')
l11=load('history-059/segovb/READ-L11-439.json');row=next(x for x in l11['sources'] if x['original_index']==2692);assert row['fresh_personal_body_reads']==[[1,196]] and l11['fresh_bounded_windows']['1610']==[[1,150],[151,196]]
reg12=load('history-059/parallel-l12-20261029/REGISTRATION-PAR-L12-757.json');proposal=load('history-059/parallel-l12-20261029/PROPOSAL-L12-934.json');partial=[]
for i,expected in [(1,[[1,195]]),(2,[[196,196]])]:
 d=load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-934-{i:03d}.json');x=next(x for x in d['rows'] if x['original_index']==2692);assert x['fresh_personal_body_reads']==expected and x['registered_at']==reg12['registered_at'] and x['registered_at']<d['at']<proposal['at'] and '/root/lens12_frontier' in x['attribution'];partial.append(d['at'])
assert partial[0]<partial[1] and 'root adoption required' in proposal['kind']
native=gzip.decompress((p/'history-774/native/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines();assert json.loads(native[53])['id']=='NATIVE-ADMISSION03-REG-054';g=json.loads(gzip.decompress((p/'history-774/native/admission03/contract-groups-069.json.gz').read_bytes()));assert 'p16-actual-context-admission' in g['groups']
checks.append('Original Native054, 059 Lens11 windows and Lens12 independent partial proposal; root adoption not inferred')
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert queue['entries'][int(n)]==e
assert [q['entries'][str(n)]['contract_id'] for n in [179,181,217,1046]]==['ADLER-L11-OBSERVER-FRONTIER-SNAPSHOT','ADLER-L11-NPC-PRESENCE-CLOCK-ADMISSION','SEGOVB-L12-CASE-SITE-PRESENCE-PRIVATE-READMISSION','Q-L12-09e949f0c0a4f8354fa8']
for x in load('prior-evidence-index.json')['records']:
 b=(p/x['preserved_bytes']).read_bytes();assert (sha(b),len(b))==(x['sha256'],x['bytes'])
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
rep=load('report.json');assert rep['support_reads']==reads and {x['number'] for x in rep['lenses']}==set(range(1,14))
checks.append('Reconstructed historical queue selection, prior assessments, applicable rules and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and scope only. No product execution, runtime probe, build, test, repair, validation, checkpoint3821 promotion or inferred 059 root adoption.'},indent=2))
