from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');supp=load('support-registration.json');nav={};navigation=[]
for name in ['navigation-hair.txt','navigation-combat.txt','navigation-shell.txt','navigation-limb.txt','navigation-garment.txt']:
 lines=(b/name).read_text().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m;nav.setdefault(m.group(1),set()).add(int(m.group(2)))
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2770:[[1,46]],2771:[[7,8]],2772:[[1,64]],2773:[[1,70],[71,138]],2774:[[1,70],[71,132]]};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];shown=nums(d);navonly=sorted(nav.get(row['path'],set())-shown) if j else []
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'snapshot':row['snapshot'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines':navonly,'unread_complement':comp(v['eof'],shown|set(navonly)),'qualification':'Comparison Git bytes not separately displayed; prior readers retain their own scope; historical excluded tests and helper bodies not role credit.'})
body={'hair-parting':[[90,170]],'hair-braid':[[120,140],[400,430]],'combat-precision':[[1,65],[66,113]],'combat-contact':[[390,465]],'combat-surface':[[1,75]],'shell-layout':[[85,120],[140,165],[220,270]],'shell-part':[[280,315]],'limb-shape':[[455,478]],'pauldron':[[50,90]],'garment-spec':[[1,60]]};support=[]
for x in supp['entries']:
 d=body[x['name']];shown=nums(d);navonly=sorted(nav.get(x['path'],set())-shown)
 support.append({'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'navigation_only_lines':navonly,'unread_complement':comp(x['eof'],shown|set(navonly)),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Newly reconstructed actual personal source displays and navigation receipts following prospective registration. Archive, comparison and other-agent reads do not grant this reader coverage.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in ['registration.json','navigation-registration.json','support-registration.json']],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'limits':'No shader or product code, test/fixture, macro, generation, execution, build, probe, implementation or publication edit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('sha256',h((b/'read-receipt.json').read_bytes()))
