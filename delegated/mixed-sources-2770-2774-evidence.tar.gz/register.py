from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent;repo=Path('<LOCAL_PATH_0>');base=repo/'recovered/original-registry-source-archive';h=lambda x:hashlib.sha256(x).hexdigest();r=json.load(gzip.open(base/'registry.json.gz','rt'));rows=[];pending=[]
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 for i in range(2770,2775):
  x=r['files'][i];path=x['source_id'].split(':',1)[1];old=t.extractfile(x['sha256']).read();assert h(old)==x['sha256'] and len(old)==x['bytes'] and len(old.splitlines())==x['actual_line_count']
  loc=f'source/{i}-historical.rs';pending.append((loc,old));vs=[{'identity':'archived exact '+x['snapshot']+' registry object','sha256':h(old),'bytes':len(old),'eof':len(old.splitlines()),'local':loc,'original_material_planned':x['material_ranges']}];compare=[]
  revs=(['a120390947c89b703dc74c4255a13c035d054c50','6533e444fa37552927070cc8d8190907fd3b413e'] if x['snapshot']=='physical-p16' else ['6533e444fa37552927070cc8d8190907fd3b413e'])+['95e63628f9d70b8dd6e6fede64334696c6995009']
  for rev in revs:
   p=subprocess.run(['git','-C',str(repo),'show',rev+':'+path],capture_output=True)
   if p.returncode:
    d={'revision':rev,'path_absent':True,'stderr':p.stderr.decode(errors='replace'),'display_planned':False};(vs if rev.startswith('95e') else compare).append(d);continue
   raw=p.stdout;blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
   loc=f'source/{i}-{rev[:4]}.rs';pending.append((loc,raw));d={'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':loc,'equals_historical_object':raw==old}
   if rev.startswith('95e'):d['current_body_planned']=x['material_ranges'] if raw==old else [[1,len(raw.splitlines())]];vs.append(d)
   else:d['display_planned']=False;compare.append(d)
  rows.append({'original_index':i,'source_id':x['source_id'],'snapshot':x['snapshot'],'path':path,'original_material_ranges':x['material_ranges'],'historical_scope_limits':x['scope_limits'],'versions':vs,'comparison_git_paths':compare})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively register original material and separately pinned 95e counterpart; changed current files register full body but actual read/unread must be disclosed. Compare base/6533 Git bytes by identity only; no credit from equality. Any excluded context or additional support requires separate registration before display.','original_registry_uncompressed_sha256':h(gzip.decompress((base/'registry.json.gz').read_bytes())),'snapshot_qualification':'pr-working 6533-based with unrelated changes, not clean whole tree. physical-p16 dirty a120-based; later independently reproduced tracked patch plus separately preserved seven untracked objects. f82 transports source archives, not source head. No checkpoint 3821 promotion.','earlier_current_support':[{'reader':'/root/hair_ops','path':'crates/fabelgeist-hair/src/identity.rs','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','ranges':[[1,64]],'record':'<LOCAL_PATH_1>','report_sha256':'7133d95f6907010d5fb6e40d4216dff0128b4604378402dfea655ad02e5b427a','qualification':'Earlier support only, no ordered role credit; a new independent fresh display follows this registration.'},{'reader':'/root/rig_identity','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','record':'<LOCAL_PATH_2>','report_sha256':'dc92077a7c6268c996c083027c4e953c9cd26a1bc2b1853398c14dcaa5396bdb','support':{'gpu/limb_build.rs':[[7,20]],'gpu/shell_plan.rs':[[39,61],[73,119]]},'qualification':'Prior reviewer support retained separately; no transfer of personal reading or ordered role.'}],'rows':rows,'limits':'Source and evidence inspection only, no code generation, shader, macro or product execution, fixtures, builds, tests, probes, repairs or publication edits.'}
(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 q=b/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
print(json.dumps(d,indent=2));print('REGISTRATION_SHA256',h((b/'registration.json').read_bytes()))
