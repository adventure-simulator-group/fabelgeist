from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
specs=[('hair-parting','crates/fabelgeist-hair/src/ops/interpolate.rs',[[90,170]]),('hair-braid','crates/fabelgeist-hair/src/hairdo.rs',[[120,140],[400,430]]),('combat-precision','crates/adventuresim-core/src/combat/weapon_contact.rs',[[1,115]]),('combat-contact','crates/adventuresim-core/src/combat.rs',[[390,465]]),('combat-surface','crates/adventuresim-core/src/equipment/armor.rs',[[1,75]]),('shell-layout','crates/fabelgeist-armor/src/gpu/part/layout.rs',[[85,120],[140,165],[220,270]]),('shell-part','crates/fabelgeist-armor/src/gpu/part.rs',[[280,315]]),('limb-shape','crates/fabelgeist-armor/src/gpu/limb.rs',[[455,490]]),('pauldron','crates/fabelgeist-armor/src/gpu/pauldron.rs',[[50,90]]),('garment-spec','crates/fabelgeist-garment-code/src/pattern/spec.rs',[[1,60]])]
entries=[];pending=[]
for name,path,ranges in specs:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(raw.splitlines());blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];local='support/'+name+'.rs';pending.append((local,raw));entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':eof,'planned_display_ranges':ranges,'local':local,'credit':'connected support only'})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Prospective exact current source support registrations after separately recorded line-only navigation; no ordered-role credit.','entries':entries};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for loc,raw in pending:
 p=b/loc;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('SHA256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
