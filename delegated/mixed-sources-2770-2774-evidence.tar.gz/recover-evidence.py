from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');orig=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');workspace=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/n,'recovered/'+n,'Exact retained original registry/archive/059 data; separately labelled reconstructed 774 catalogue or later patch recovery.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/fabelgeist-armor/AGENTS.md','crates/adventuresim-core/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Applicable current rules, with user source-only restrictions overriding implementation and validation workflows.')
for n in ['ASSESSMENT-PAULDRON-PART-95E.json','ASSESSMENT-ARMOR-BODY-COORD-95E.json','ASSESSMENT-DELEGATED-RECONCILIATION-95E.json','ASSESSMENT-MELEE-REPORT-IDENTITY-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Prior published bounded assessment/recovery; preserve stated revision and reader; no read transfer.')
for n in ['REPORT.json','MANIFEST.json']:
 copy(Path('<LOCAL_PATH_4>')/n,'prior/besagew-'+n,'Earlier bounded report by /root/rig_identity; original author and support scopes remain distinct.')
for n in ['report.json','support-registration-01.json']:
 copy(Path('<LOCAL_PATH_5>')/n,'prior/own-hair-'+n,'Earlier support by /root/hair_ops, separate from fresh ordered-role inspection.')
names=['segovb/READ-L11-452.json','segovb/READ-L11-453.json','segovb/READ-L11-503.json','segovb/READ-L11-580.json','segovb/REGISTRATION-SEGOVB-1906.json','segovb/PLAN-L11-SHARED-503.json','evidence/shared-material-successor/source-extensions-196.json','parallel-l11-20261029/READ-044.json','parallel-l11-20261029/VERIFY-044.json','segovb/VALIDATE-INHERITED-044-ROOT-005-POSTINSPECTION.json','adler/READ-L11-368.json','segovb/READ-L12-757.json']+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in range(1690,1695)]
for n in names:copy(orig/n,'historical/059/'+n,'Exact original 059 historical receipt, registration, plan or qualified adoption.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for owner,folder,names in [('rig','initial06-type-ownership',['source-range-registration.jsonl','additional-sources.jsonl','coverage.jsonl','contracts-021.json','contracts-023.json','contracts-026.json']),('camera','initial07-redundant-authority',['source-range-registration.jsonl','additional-sources.jsonl','contracts.jsonl']),('native','initial05-aggregate-states',['source-range-registration.jsonl','source-qualifications.jsonl','contract-groups-023.json'])]:
 for n in names:
  gp=f'handoff/774/adler-original/audit/continuation/{owner}/{folder}/{n}';raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{owner}-{n}','git:'+rev+':'+gp,'Exact original 774 supplier record via f82 evidence transport; f82 is not source head.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw);qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw)['entries'];d={'kind':'Newly reconstructed selections from exact original registry and 059 queue; not original standalone records.','registry_uncompressed_sha256':h(rraw),'queue_uncompressed_sha256':h(qraw),'registry_rows':{str(i):r['files'][i] for i in range(2770,2775)},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ['pr-working','physical-p16']],'queue_rows':{str(i):q[i] for i in [162,164,372]},'qualification':'Earlier 059 and 774 retained without credit promotion to checkpoint3821; original P16/PR snapshot identities remain distinct.'};(b/'historical-selections-reconstructed.json').write_text(json.dumps(d,indent=2)+'\n')
(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'Earlier source displays do not become this reader\'s or any other-lens evidence.'},indent=2)+'\n');print('records',len(records),'manifest_sha256',h((b/'historical-manifest.json').read_bytes()))
