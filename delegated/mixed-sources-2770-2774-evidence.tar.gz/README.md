# Bounded source evidence: original roles 2770–2774

`REPORT.json` records source references, thirteen partial lens perspectives,
conditional historical relationships and remaining questions. `registration`
and the navigation/support registrations predate the actual displays recorded
in `read-receipt.json`. Stored source bytes, unprinted context and prior
reviewers' reads do not transfer personal or ordered-role credit.

The historical combat role uses the separately recorded dirty physical-p16
snapshot. The recovered tracked patch matches the historical digest; seven
untracked objects and their separate qualifications remain distinct. Other
roles use the 6533-based pr-working snapshot with unrelated changes. Individual
file matches do not equate complete snapshots. The f82 Git revision transports
evidence and is not a project source head.

`historical/` retains exact original 059 and 774 receipts. `recovered/` retains
the original registry and source archive and an explicitly reconstructed 774
catalog. `historical-selections-reconstructed.json` is a new extraction, not an
original standalone record. `prior/` preserves related earlier reports without
transferring authorship. No checkpoint 3821 reconstruction is asserted.

Run `python3 verify-evidence.py` for offline evidence-integrity checks only.
It does not execute product or fixture code, shaders, macros, builds or tests.
The top-level manifest includes nested manifests.
