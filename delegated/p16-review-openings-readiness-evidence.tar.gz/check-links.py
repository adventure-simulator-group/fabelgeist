import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=p/'historical-059';H=lambda b:hashlib.sha256(b).hexdigest()
def check(n,sha):
 n=n.replace('\\','/').removeprefix('target/726-audit-adler-20261027/');assert H((h/n).read_bytes())==sha,n
x=json.loads((h/'segovb/READ-L11-417.json').read_text());rows=[r for r in x['sources'] if r['original_index'] in [2519,2520]];assert len(rows)==2
for r in rows:
 check(r['registration'],r['registration_sha256']);q=r.get('same_lens_prior')
 if q:check(q['receipt'],q['receipt_sha256']);check(q['entry']['registration'],q['entry']['registration_sha256'])
for i,role in [(855,2519),(856,2520)]:
 x=json.loads((h/f'segovb/READ-L12-{i}.json').read_text());check(x['proposal'],x['proposal_sha256']);assert not x['root_personal_rereads'];r=next(r for r in x['rows'] if r.get('original_index')==role);check(r['registration'],r['registration_sha256'])
m=json.loads((h/'parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-854-856.json').read_text())
for r in m['proposals']:
 if r.get('batch') in [855,856]:check(r['path'],r['sha256'])
prior=json.loads((p/'prior-references.json').read_text());count=0
for x in prior['packets']:
 a=pathlib.Path(x['prior_location']);manifest=a/'BUNDLE-MANIFEST.json';assert H(manifest.read_bytes())==x['manifest_sha256'];rows={v['path']:v for v in json.loads(manifest.read_text())['files']}
 for y in x['copies']:
  q=p/y['path'];assert H(q.read_bytes())==y['sha256'];name=q.name
  if name!='BUNDLE-MANIFEST.json':assert rows[name]['sha256']==y['sha256']
  count+=1
result={'schema':'726-evidence-link-verification-v1','status':'passed','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'059 L11 personal/inherited registration and prior source receipts; both L12 proposals and registrations; hash-linked prior manifests and copied exact relevant records.','prior_record_copies':count,'qualification':'No full prior archives embedded; linked frozen packets must remain available or be separately published. Evidence-only, no product/runtime verification.'};(p/'evidence-links-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
