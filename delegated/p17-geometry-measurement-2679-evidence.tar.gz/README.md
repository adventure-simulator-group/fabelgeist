# Role 2679: report-p17 geometry measurement

This packet preserves a source-only assessment of role 2679 against the exact
report-p17 `90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696` and pinned current
`95e63628f9d70b8dd6e6fede64334696c6995009`. `REPORT.json` is the assessment;
`read-receipt.json` records bounded displays and prior navigation qualifications.
`registration.json` and the two support registrations precede the actual full
assigned and bounded support displays. Initial navigation grep printed isolated
lines before registration; see the receipt and do not infer initial clean-slate
reading or retrospective credit.

`historical/` holds exact 774 and 059 records with original author, source and
scope. `historical-selections-reconstructed.json` is an explicitly reconstructed
selection from the full preserved registry and queue; it is not an original
receipt. `recovered/` contains the exact source archive, registry, older catalogue,
original 059 ledger and queue. `git-proofs.json` plus `git-objects/` preserve raw
Git commit/tree membership for each assigned or support object, the 774 record
transport and selected per-file prior identities. The earlier bearing-area
assessment is copied with its own attribution in `prior/`.

The physical-p16 dirty snapshot is a different identity; the complete dirty
patch has not been recovered. Checkpoint 3821 remains unrecovered. Nothing in
this packet promotes historical findings or coverage to that checkpoint. This is
not product validation, and no repairs, tests, builds, fixtures, runtime probes,
viewer or geometry were executed.

Run `python3 verify-evidence.py` from any directory to check offline evidence
integrity. The root `MANIFEST.json` covers every file except itself, including
all nested manifest files. Its hash is published separately by the coordinator.
