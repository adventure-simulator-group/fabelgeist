from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
p=Path(__file__).resolve().parent;files=[]
for f in sorted(x for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'):
 raw=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
d={'schema':'726-2679-evidence-manifest-v1','created_utc':datetime.now(timezone.utc).isoformat(),'qualification':'All files beneath this packet except this root manifest; nested manifests included. Integrity only, no product validation.','files':files};(p/'MANIFEST.json').write_text(json.dumps(d,indent=2)+'\n');print('files',len(files),'manifest_sha256',hashlib.sha256((p/'MANIFEST.json').read_bytes()).hexdigest())
