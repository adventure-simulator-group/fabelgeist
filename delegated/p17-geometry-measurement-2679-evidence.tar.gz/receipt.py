from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');sha=lambda d:hashlib.sha256(d).hexdigest()
def complements(n,ranges):
 used={i for a,z in ranges for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
reg=json.loads((b/'registration.json').read_text());supports=[];registrations=[]
for name in ['registration.json','support-registration.json','extra-support-registration.json']:
 d=json.loads((b/name).read_text());registrations.append({'path':name,'sha256':sha((b/name).read_bytes()),'created_utc':d['created_utc']})
 if name!='registration.json':
  for e in d['entries']:supports.append({'revision':e['revision'],'path':e['path'],'source_sha256':e['sha256'],'saved':e['local'],'eof':e['eof'],'displayed':e['planned_display_ranges'],'unread_complement':complements(e['eof'],e['planned_display_ranges']),'ordered_role_credit':0})
assigned=[{'role':2679,'revision':x['revision'],'path':x['path'],'source_sha256':x['sha256'],'saved':x['preserved_source'],'eof':x['eof'],'displayed':x['planned_display_ranges'],'unread_complement':[]} for x in reg['versions']]
r={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','basis':'Personally displayed nl -ba bounded ranges after each prospective registration; source bytes archived are not independent reading evidence. Both assigned revision bodies were separately displayed. Support displays are independently registered and have no ordered role credit.','registrations':registrations,'assigned':assigned,'support':supports,'output_truncation':'The two assigned displays and three bounded support outputs were untruncated.','earlier_credit':'No earlier reviewer or support credit is transferred to this delegate.'};r['pre_registration_navigation']={'qualification':'The first bounded Git grep navigation printed isolated current role and support lines before role/support registration. These prior peeks are not prospectively registered coverage and do not constitute full-body read credit. Subsequent registered assigned full displays and bounded support displays were separate and untruncated. Some earlier navigation results were truncated, so do not infer an exhaustive navigation range list.', 'current_role_95e_exact_visible_lines':[13,14,21,25,26,33,35,40,72,77,83,86,100], 'known_support_navigation':'Before support registration, grep output included current cuboid, lib, building reexport, bonding_metrics and bell_swing matches; historical capture/admission and observation matches; and later resolved_networks and wall_corner_bonds matches before extra-support registration.'};(b/'read-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('receipt',sha((b/'read-receipt.json').read_bytes()))
