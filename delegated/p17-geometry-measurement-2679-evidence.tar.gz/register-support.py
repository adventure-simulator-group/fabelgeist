from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>'
old='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696';cur='95e63628f9d70b8dd6e6fede64334696c6995009'
spec=[(old,'crates/fabelgeist-geometry/src/length.rs',[(1,999)],'historical positive-length admission owner'),(cur,'crates/fabelgeist-geometry/src/length.rs',[(1,999)],'current positive-length admission owner'),(cur,'crates/fabelgeist-geometry/src/lib.rs',[(1,999)],'geometry owner reexports'),(cur,'crates/fabelgeist-geometry/src/cuboid.rs',[(1,85)],'signed-length nonnegative aggregate consumer'),(cur,'crates/adventuresim-building-generator/src/spatial_geometry.rs',[(1,35)],'canonical geometry reexport'),(cur,'crates/adventuresim-building-generator/src/audit/bonding_metrics.rs',[(1,100)],'squared-metre producer/consumer'),(cur,'crates/adventuresim-building-generator/src/audit/bell_swing.rs',[(1,75),(205,240)],'squared-radius role and usage'),(old,'crates/adventuresim-tactical-client/src/animation_viewer/capture/admission.rs',[(105,150)],'historical scenario-distance admission'),(old,'crates/adventuresim-tactical-client/src/animation_viewer/report/observation.rs',[(1,35),(115,135)],'historical measured signed range')]
entries=[];pending=[]
for rev,p,ranges,reason in spec:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+p]);oid=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+p],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
 lines=len(raw.splitlines());ranges=[[a,min(z,lines)] for a,z in ranges if a<=lines];name='support/'+rev[:4]+'/'+p;pending.append((name,raw));entries.append({'revision':rev,'path':p,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':oid,'bytes':len(raw),'eof':lines,'planned_display_ranges':ranges,'purpose':reason,'local':name})
d={'kind':'Prospective bounded connected support, not ordered-role credit','created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','entries':entries,'limits':'Personal displays recorded independently; older support or agents reads not transferred.'};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for name,raw in pending:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('registration_sha256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
