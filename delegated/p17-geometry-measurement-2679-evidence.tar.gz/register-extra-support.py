from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';items=[('crates/adventuresim-building-generator/src/model/resolved_networks.rs',[(190,220)],'JunctionBond stored threshold fields'),('crates/adventuresim-building-generator/src/generator/wall_corner_bonds.rs',[(165,200)],'one threshold producer')];rows=[];pending=[]
for p,ranges,reason in items:
 data=subprocess.check_output(['git','-C',repo,'show',rev+':'+p]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+p],text=True).strip();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob;local='support/95e6/'+p;pending.append((local,data));rows.append({'revision':rev,'path':p,'sha256':hashlib.sha256(data).hexdigest(),'git_blob':blob,'bytes':len(data),'eof':len(data.splitlines()),'planned_display_ranges':ranges,'purpose':reason,'local':local})
d={'kind':'Prospective extra bounded current support only','created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','entries':rows};(b/'extra-support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for p,data in pending:
 dest=b/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
print(json.dumps(d,indent=2));print('sha256',hashlib.sha256((b/'extra-support-registration.json').read_bytes()).hexdigest())
