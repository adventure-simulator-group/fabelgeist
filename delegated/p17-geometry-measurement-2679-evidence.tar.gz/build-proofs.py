from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objects={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);m,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return m.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind):
 raw=(b/local).read_bytes();tree=save('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw);proofs.append({'revision':rev,'path':path,'preserved':local,'kind':kind,'commit_tree':root,'path_chain':chain,'blob':tree,'sha256':sha(raw)})
reg=json.loads((b/'registration.json').read_bytes())
for x in reg['versions']:proof(x['revision'],x['path'],x['preserved_source'],'separately personally displayed assigned revision')
for name in ['support-registration.json','extra-support-registration.json']:
 for x in json.loads((b/name).read_bytes())['entries']:proof(x['revision'],x['path'],x['local'],'prospectively registered and personally displayed bounded support')
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';historical='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/7424133b695eecdc9d04383ff3021b7f902952c2c24354e06ca31f104642c471';proof(f82,historical,'source/90a4-measurement.rs','historical 774 frozen object transport only')
for e in json.loads((b/'historical-manifest.json').read_bytes())['records']:
 if e.get('transport_revision'):proof(e['transport_revision'],e['git_path'],e['local'],'historical 774 exact original record transport only')
for rev in ['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','7a9d92ad7357779e9280146c521bd8588b86fcdb']:
 proof(rev,reg['versions'][1]['path'],reg['versions'][1]['preserved_source'],'file-byte identity only, no independent personal source display or transferred read credit')
d={'schema':'726-2679-git-membership-proof-v1','objects':objects,'proofs':proofs,'qualification':'90a P17 original source and 95e pinned current distinct from f82 evidence transport, 6533 pr-working per-file identity, and prior e275/7a9 files. Raw commit/tree membership links exact preserved source bytes; equality does not grant reviewer credit or whole-tree cleanliness.'};(b/'git-proofs.json').write_text(json.dumps(d,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'sha',sha((b/'git-proofs.json').read_bytes()))
