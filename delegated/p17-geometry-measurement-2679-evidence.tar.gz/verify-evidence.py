'''Offline integrity checks on frozen evidence only, not product execution or validation.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda p:json.loads((b/p).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');report=load('REPORT.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');selection=load('historical-selections-reconstructed.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_sha256']==hist['original_registry_uncompressed_sha256']==selection['original_registry_uncompressed_sha256'];original=json.loads(rbytes)['files'];assert original[2679]==selection['registry_rows']['2679'] and original[452]==selection['registry_rows']['452']
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==selection['059_queue_uncompressed_sha256'];assert json.loads(qbytes)['entries'][2343]==selection['queue_rows']['2343'];assert selection['queue_rows']['2343']['contract_id']=='ADLER-L11-CAMERA-PROFILE-INVARIANTS#l1-current-camera-negative-boom-domain'
catalog=load('recovered/catalog-774.json')['rows'][2679];assert catalog['expected_sha256']==reg['versions'][0]['sha256'] and catalog['origin']=='git:'+reg['versions'][0]['revision']+':'+reg['versions'][0]['path']
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 old=(b/reg['versions'][0]['preserved_source']).read_bytes();assert old==t.extractfile(reg['exact_archive_member']).read() and h(old)==original[2679]['sha256']
for x in rec['registrations']:
 r=load(x['path']);assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(r['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
for source,disp in zip(reg['versions'],rec['assigned']):
 raw=(b/source['preserved_source']).read_bytes();assert source['revision']==disp['revision'] and h(raw)==source['sha256']==disp['source_sha256'] and len(raw.splitlines())==source['eof']==disp['eof'];assert disp['displayed']==source['planned_display_ranges']==[[1,source['eof']]] and disp['unread_complement']==[]
planned={}
for name in ['support-registration.json','extra-support-registration.json']:
 for x in load(name)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['saved']];raw=(b/x['saved']).read_bytes();assert h(raw)==x['source_sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];assert x['displayed']==e['planned_display_ranges'];all_lines=[i for a,z in x['displayed']+x['unread_complement'] for i in range(a,z+1)];assert len(all_lines)==x['eof'] and set(all_lines)==set(range(1,x['eof']+1))
objects={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objects[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);m,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return m.decode(),child
 raise AssertionError(n)
for e in proof['proofs']:
 tree=objects[e['revision']].splitlines()[0].split()[1].decode();assert tree==e['commit_tree']
 for c in e['path_chain']:
  assert c['tree']==tree and lookup(objects[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/e['preserved']).read_bytes();assert tree==e['blob']==oid('blob',raw) and h(raw)==e['sha256']
records=[json.loads(l) for l in (b/'historical/774/source-range-registration.jsonl').read_text().splitlines()];quals=[json.loads(l) for l in (b/'historical/774/source-qualifications-final-082.jsonl').read_text().splitlines()];ob=original[2679]['admission03_scope_observations'][0];assert records[34]==ob['original_record'] and quals[34]==ob['local_qualifications'][0] and records[34]['material_ranges']==[[1,79]]
l11=load('historical/059/segovb/READ-L11-438.json');rows=[x for x in l11['sources'] if x.get('original_index')==2679];assert [x['fresh_personal_body_reads'] for x in rows]==[[[1,79]],[[80,102]]]
l12=load('historical/059/segovb/READ-L12-929.json');row=next(x for x in l12['rows'] if x['original_index']==2679);assert row['fresh_personal_body_reads']==[[1,79]] and '/root/lens12_frontier' in row['attribution'] and l12['root_personal_rereads']==[]
for e in rows:
 name=Path(e['registration']).name;assert h((b/'historical/059/segovb'/name).read_bytes())==e['registration_sha256']
assert h((b/'historical/059/parallel-l12-20261029/REGISTRATION-PAR-L12-743.json').read_bytes())==row['registration_sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and report['pre_registration_navigation']==rec['pre_registration_navigation']
if (b/'MANIFEST.json').exists():
 for e in load('MANIFEST.json')['files']:
  raw=(b/e['path']).read_bytes();assert len(raw)==e['bytes'] and h(raw)==e['sha256'],e['path']
print('PASS: offline self-contained evidence integrity; exact 90a archive and native 774 original records; separate 90a/95e source displays; 059 historical attribution and partial scopes; %d raw Git membership proofs; %d bounded support partitions; thirteen partial perspectives. Navigation prior to registration is explicitly qualified. No product execution, builds, tests or probes.'%(len(proof['proofs']),len(rec['support'])))
