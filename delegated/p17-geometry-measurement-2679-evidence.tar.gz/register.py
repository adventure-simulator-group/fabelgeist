from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, tarfile
b=Path('<LOCAL_PATH_0>')
repo='<LOCAL_PATH_1>'
base=Path(repo)/'recovered/original-registry-source-archive'
r=json.load(gzip.open(base/'registry.json.gz','rt'))['files'][2679]
p='crates/fabelgeist-geometry/src/measurement.rs'; old='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696'; cur='95e63628f9d70b8dd6e6fede64334696c6995009'
sha=lambda d:hashlib.sha256(d).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',repo,*a])
rows=[]; bodies=[]
for revision in [old,cur]:
 raw=git('show',revision+':'+p); oid=git('rev-parse',revision+':'+p).decode().strip(); assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
 name='source/'+revision[:4]+'-measurement.rs'; bodies.append((name,raw));rows.append({'revision':revision,'path':p,'sha256':sha(raw),'git_blob':oid,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,len(raw.splitlines())]],'preserved_source':name})
assert rows[0]['sha256']==r['sha256'] and rows[0]['bytes']==r['bytes'] and rows[0]['eof']==r['actual_line_count']
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 hits=[x for x in t.getmembers() if x.name.split('/')[-1]==r['sha256'] and x.isfile()];assert len(hits)==1
 archived=t.extractfile(hits[0]).read(); assert archived==bodies[0][1]
reg={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Prospective exact role 2679 historical and pinned current source registration, before any assigned source displays','source_id':r['source_id'],'original_registry_sha256':sha(gzip.decompress((base/'registry.json.gz').read_bytes())),'original_material_ranges':r['material_ranges'],'versions':rows,'exact_archive_member':hits[0].name,'historical_attribution':'Original native historical and later source-reader credit remains independently attributed; registered whole bodies do not inherit previous credit.','revision_qualification':'90a is report-p17 source revision, f82 is historical evidence transport, 95e is pinned current.','limits':'No source edits, product execution, builds, tests, probes or simulations.'}
(b/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
for n,data in bodies:
 out=b/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
print(json.dumps(reg,indent=2));print('registration_sha256',sha((b/'registration.json').read_bytes()))
