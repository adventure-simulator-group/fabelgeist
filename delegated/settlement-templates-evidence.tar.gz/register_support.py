import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=['crates/strategic-web/src/routes/travel.rs','crates/strategic-web/src/routes/settlements/rest.rs','crates/strategic-web/src/spacetimedb/types.rs','crates/strategic-web/static/travel-planner.js','crates/strategic-web/static/rest-duration.js','crates/adventuresim-stdb-module/src/strategic/travel_planning.rs','crates/adventuresim-stdb-module/src/strategic/travel_reducers.rs','crates/adventuresim-stdb-module/src/strategic/journey_camp.rs','crates/adventuresim-stdb-client/src/journey_terrain_weights_type.rs']
rows=[]
for path in paths:
 b=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True,check=True).stdout;(out/'source'/('support-'+path.replace('/','__'))).write_bytes(b)
 rows.append({'path':path,'revision':rev,'range':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
o={'schema':'delegated-support-prospective-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Bounded support for return-route durations, planner protocol, terrain weights and rest supply presentation.','registered_sources':rows,'qualification':'Full exact current objects archived; only personally displayed ranges separately recorded count; no transferred past or ordered-role credit.'}
f=out/'support-registration-01.json';f.write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256(f.read_bytes()).hexdigest());print('\n'.join(x['path']+' '+str(x['range']) for x in rows))
