import gzip,hashlib,json,pathlib
src=pathlib.Path('<LOCAL_PATH_0>');pub=pathlib.Path('<LOCAL_PATH_1>');out=pathlib.Path('<LOCAL_PATH_2>');old=pathlib.Path('<LOCAL_PATH_3>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f:entries={e['path']:e for e in json.load(f)['entries']}
paths=[]
for i in (394,396):paths += [f'adler/READ-L11-{i}.json',f'adler/STATE-L11-{i}.json',f'adler/VERIFY-L11-{i}.json']
paths += [f'adler/REGISTRATION-ADLER-{i}.json' for i in (1282,1283,1284,1285,1286,1291)]
for i in (807,810):paths += [f'segovb/READ-L12-{i}.json',f'segovb/REGISTRATION-SEGOVB-L12-{i}.json',f'segovb/VERIFY-L12-{i}.json',f'parallel-l12-20261029/PROPOSAL-L12-{i}.json']
paths += [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json' for i in (412,413,419)]
paths += ['parallel-l12-20261029/QUALIFICATION-PAR-L12-412-WINDOWS-ORIGINAL2407.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-413-WINDOWS-ORIGINAL2408.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-419-WINDOWS-ORIGINAL2413.json','root-l2-extension-20261030/PROPOSAL-BUNDLE-ROOT-L2-EXT-052-054.json','root-l2-extension-20261030/READ-ROOT-L2-EXT-052-054.json','root-l2-extension-20261030/REGISTRATION-ROOT-L2-EXT-052-054.json','root-l2-extension-20261030/READ-ROOT-L2-CURRENT-011.json','root-l2-extension-20261030/READ-ROOT-L2-CURRENT-012.json','segovb/VERIFY-L2-EXT-CURRENT-014.json','root-l3-extension-20261030/CONTRACT-PROPOSALS-ROOT-L3-EXT-046-056.json','root-l3-extension-20261030/READ-ROOT-L3-EXT-046-055.json','root-l3-extension-20261030/REGISTRATION-ROOT-L3-EXT-046-055.json','root-l3-extension-20261030/READ-ROOT-L3-CURRENT-006.json','segovb/READ-L12-802.json','parallel-l12-20261029/PROPOSAL-L12-802.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-392-WINDOWS-ORIGINAL2397.json']
rows=[];missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file():missing.append(path);continue
 b=(src/path).read_bytes();e=entries[path];h=hashlib.sha256(b).hexdigest();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),path
 dst=out/'historical'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);rows.append({'original_transport_path':path,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+path})
o={'schema':'delegated-recovered-historical-evidence-v1','qualification':'Exact copies from read-only original 059 extraction checked against transport SHA-256, byte length and Git blob. Preserve original attribution, revision and open status; no promotion to checkpoint3821.','records':rows,'unavailable':missing}
f=out/'historical-manifest.json';f.write_text(json.dumps(o,indent=2)+'\n');print('verified',len(rows),'unavailable',missing,'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
ref=out/'reference';ref.mkdir(exist_ok=True)
refs=[('<LOCAL_PATH_4>','registry.json.gz','exact original registry'),('<LOCAL_PATH_5>','original-transport-manifest.json.gz','exact original manifest'),('<LOCAL_PATH_6>','queue-059.json.gz','lossless exact 059 queue, not checkpoint3821'),('<LOCAL_PATH_7>','strategic-web-AGENTS-95e.md','governing source rules'),(str(old/'ledger.json'),'older-774-ledger.json','original old local ledger; preserve 13fc revision, tree and unfinished review status'),(str(old/'reconcile-adler-20261023/local-findings-snapshot.json'),'older-774-local-findings-snapshot.json','older local findings snapshot, not current or checkpoint3821')]
refs += [('<LOCAL_PATH_8>','prior-same-agent-web-travel-report.json','earlier personally read routes travel role, not fresh support credit'),('<LOCAL_PATH_9>','prior-same-agent-web-residence-report.json','earlier personally read routes rest role, not fresh support credit')]
assess=['ASSESSMENT-L1-STRATEGIC-CALENDAR.json','ASSESSMENT-L01-ENCOUNTER-MOVEMENT-95E.json','ASSESSMENT-L12-THREAT-MATERIALIZATION-95E.json','ASSESSMENT-L11-THREAT-ID-95E.json','ASSESSMENT-L01-TRAVEL-WATER-FORECAST-95E.json']
for i,n in enumerate(assess):
 path=pub/n;o=json.loads(path.read_text());refs.append((str(path),f'prior-assessment-{i}.json','earlier bounded assessment; its original revision and authorship remain unchanged'))
 for x in o.get('current_sources',[]):
  if x.get('path')=='crates/strategic-web/src/templates/settlement/travel.rs' and x.get('preserved_bytes'):
   refs.append((str(pub/x['preserved_bytes']),f'prior-travel-source-{i}.gz','earlier exact compressed travel role source; range and revision in prior assessment'))
rs=[];unavailable=[]
for source,name,cl in refs:
 s=pathlib.Path(source)
 if not s.is_file():unavailable.append(source);continue
 b=s.read_bytes();(ref/name).write_bytes(b);rs.append({'source':source,'copy':'reference/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'classification':cl})
f=ref/'manifest.json';f.write_text(json.dumps({'records':rs,'unavailable':unavailable},indent=2)+'\n');print('references',len(rs),'unavailable',unavailable,'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
