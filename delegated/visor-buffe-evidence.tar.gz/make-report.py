import pathlib,json,datetime
p=pathlib.Path(__file__).parent;load=lambda s:json.loads((p/s).read_bytes());reg=load('registration.json');read=load('read-receipt.json'); history=load('historical-index.json');supports=load('support-read-receipt.json')['reads']+load('support-read-receipt-02.json')['reads']
for x in supports:
 covered=set()
 for a,b in x['actual_ranges']:covered.update(range(a,b+1))
 missing=sorted(set(range(1,x['eof']+1))-covered);comps=[]
 for n in missing:
  if comps and comps[-1][1]==n-1:comps[-1][1]=n
  else:comps.append([n,n])
 x['unread_for_this_registration']=comps
lenses=[
('producer-propagation','Current editor independently mutates optional courses and breaths; HelmetDesign validates then recipe dispatches through Burgonet to pierced domain. UI persistence/error presentation and other callers remain untraced.'),
('existing-type-owners','Millimeters, Permille, SlotInclination and VentSides retain distinct units/closed alternatives. Public wrappers and raw fields do not by themselves ensure contextual slot-within-course constraints.'),
('admission-contracts','VisorBreaths and BuffeCourses each enforce their own scalar/spacing relations. Parent calls them independently; sampled out-of-course combination is rejected later at the geometry domain. Whether parent admission must reject it remains open.'),
('invariant-operations','The validated count-zero and count-one branches avoid count subtraction/division hazards; rows-zero yields no loop. Lower boundary is range-checked before +180 due to short-circuit. No arbitrary caller safety claimed.'),
('aggregate-states','Breath extent depends on top course extent, overlap and pattern geometry; separately valid breath and course values can nevertheless yield out-of-course holes. The concrete conditional source-math witness is documented as candidate only.'),
('type-ownership','VisorBreaths owns pattern and its unit/side distinctions; BuffeCourses owns seam/overlap, while pierced geometry checks the actual domain. Placement of a cross-field policy requires design decision, not automatic new generic type.'),
('redundant-authority','Authored fraction and actual mm domain are different representations of placement; 100 mm face chart and shortened course height are related by geometry, not proven independent competing facts. Their compatibility requires explicit policy.'),
('behavior-preservation','Two assigned historical source objects are byte-identical to 6533 and 95e individually; surrounding application changes, runtime behavior and full snapshot cleanliness are not established.'),
('enum-shapes','Both/Left/Right preserve closed side alternatives and Option courses/breaths are supported modes. Zero count deliberately produces no openings; do not require arbitrary nonempty geometry.'),
('derivability','Assigned structures use ordinary derive and Serde. No manual trait replacement or serialization behavior change is established from these bounded files.'),
('type-granularity','Degree SlotInclination differs from signed continuous radians; chart millimetres and Permille placement differ from count and course index. A single generic fraction or angle is not proven adequate.'),
('magic-strings','No material business string-valued field or API in assigned sources. Error variants and enum choices are typed; broader UI labels or unrelated source families remain outside scope.'),
('magic-numbers','Range limits, 3 mm web and 100 mm chart are concrete numeric contracts; top course physical height and chart height need joint interpretation. No arbitrary blanket wrapper or visual correctness claim follows.')]
refs={
'pattern':'95e:crates/fabelgeist-armor/src/visor_breaths.rs:53-103,105-149',
'courses':'95e:crates/fabelgeist-armor/src/helmets_buffe_courses.rs:4-47',
'parent':'95e:crates/fabelgeist-armor/src/helmets_buffe.rs:24-62 and helmets.rs:322-398',
'editor':'95e:crates/adventuresim-character-creator/src/visor_breath_controls.rs:1-48 and buffe_controls.rs:1-88',
'call':'95e:crates/fabelgeist-armor/src/gpu/helmet/mod.rs:24-30, parts.rs:115-129, burgonet.rs:110-160,248-269',
'domain':'95e:crates/fabelgeist-armor/src/pierced_plate_domain.rs:20-26,101-125,144-153'}
report={
'schema':'726-bounded-visor-buffe-2613-2614-v1','author':'/root/mhr_character','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'status':'Bounded source-only assessment. Central owner decides ledger, alias, count and publication. No checkpoint3821 promotion, whole-lens closure, product validation or execution.',
'source_authority':{'historical':'Original pr-working snapshot recorded 6533e444fa37552927070cc8d8190907fd3b413e plus unrelated modifications. Each assigned recovered object separately matches 6533; do not describe snapshot as clean.','current':'95e63628f9d70b8dd6e6fede64334696c6995009; each assigned role independently matches historical bytes, with separate displays.','transport':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee carries recovered objects and 774 records; it is not the source revision.','p16':'This bounded registry hash lookup identified only pr-working entries 2613/2614 for these assigned bytes; it does not establish absence of a same-path P16 object with different bytes. Separate dirty P16 recorded base a120390947c89b703dc74c4255a13c035d054c50 retains its own scope and authors. Later tracked patch recovery RECOVERY-PHYSICAL-P16-PATCH-20261111.json SHA-256 30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007 identifies tracked.patch SHA-256 fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7, while seven untracked files were separately preserved. No P16 review is inferred from these reads.','checkpoint3821':'No old receipt or observation is promoted to checkpoint3821.'},
'roles':[{'original_index':r['original_index'],'source_id':r['registry_entry']['source_id'],'source_sha256':r['registry_entry']['sha256'],'objects':r['objects'],'actual_personal_reads':[x for x in read['reads'] if x['original_index']==r['original_index']]} for r in reg['rows']],
'support_reads':supports,'support_qualification':'Current 95e only, separate prospective registrations. Ranges and per-registration unread complements are explicit; same-hash archived copies do not confer read credit. Navigation qualifications in support-registration files, including pre-registration grep lines, remain in force.',
'historical_records':history['records'],
'historical_relationships':[
{'id':'RIG-ADMISSION03-REGISTER-058/059 and ADDITIONAL-058/059','attribution':'774 rig reviewer; original pr-working snapshot','source_ranges':'visor breaths 1–149, courses 1–47','relation':'Original admissions, spacing, count and overflow reasoning; no later-lens credit. Registry preserves exact dates, original object hashes, and exclusions.'},
{'id':'RIG-ADMISSION03-CONTRACT-591','attribution':'774 rig, historical pr-working Burgonet 1–342; original queue_index 564 in this historical record','relation':'Records validated recipe, chart and domain fallibility, and bounded course count/index. Relates to the same chain but does not specifically assess a valid 950‰ breath in a 35 mm course; do not assume alias or distinct count.'},
{'id':'RIG-INITIAL06-GROUP-022 helmet-piercing-source-to-native-domain','attribution':'774 rig, historical Burgonet 1–342, VisorBreaths 1–149 and PiercedDomain 1–188','relation':'Feature geometry owns inner/outer/web constraints, degree/radian and source/native distinctions. Does not decide whether design validation promises geometry success.'},
{'id':'READ-L11-427 and REGISTRATION-SEGOVB-1525/1526','attribution':'Original 059 segovb reviewer, historical 6533/pr-working; fresh 2613 1–149 and 2614 1–47','relation':'Records disabled count, protected arithmetic and frame/open admission questions. No 95e or checkpoint3821 personal read transfer.'},
{'id':'READ-L12-892 and PROPOSAL-L12-892 with registrations PAR-L12-679/680 and source qualifications','attribution':'Original 059 /root/lens12_frontier; root adoption expressly root_personal_rereads empty; 6533 fresh 2613 1–149 and 2614 1–47','relation':'Historical scoped string and admission analysis, no new findings and no other-lens transfer; later source comparison remains independent.'},
{'id':'READ-L12-728 with PROPOSAL-L12-728 and registrations PAR-L12-138/139/140','attribution':'Original 059 /root/lens12_frontier, 6533 full Burgonet 1–342, recipe 1–54, parts 1–339; root adoption with no personal root rereads','relation':'Connects validation and dispatch with conditional chart/native questions; 95e support reads are newly registered and only bounded; no transfer.'}],
'candidate_findings':[{'id':'local-candidate-buffe-course-breath-extent','status':'Source-supported conditional cross-field contract question; central disposition/alias/count and product policy remain open.','condition':'Otherwise valid enclosing Burgonet with BuffeDesign default values, Some(default three-course BuffeCourses), Some(VisorBreaths::buffe() with height=950), nonzero count and successful recipe kernel construction. The individual course and breath predicates accept these fields. Editor code passes 50..=950 to a number control and constructs default courses and breaths independently; control implementation, UI behavior and persistence were not exercised.',
'mathematical_reasoning':'Default upper boundary 700 per mille and overlap 5 mm give top-course height 100*(1 - 0.700)+5 ≈35 mm. Breath height 950 per mille produces center 95 mm in the 100 mm full-face chart; width 3 mm, length 12 mm, inclination 0 leave vertices around y=89–101 mm, outside 0–35 mm. Slot spacing passes: required span 4*3+3*3=21 <=54, opposite-side gap 2*36-54=18 >=3, one row. PiercedDomain tests hole vertices against the outer rectangle and returns typed VisorOpeningSpacing before triangulation. This is source arithmetic, not a simulated fixture or runtime observation.',
'impact':'A design whose separate child predicates pass may later fail geometry admission. Whether this is a defect depends on the intended contract and whether the caller exposes the typed error; no accepted malformed mesh, product outage, actual interaction, or silent failure is claimed.',
'future_direction':'Resolve whether the height is relative to the full face or top course and whether this state should be prevented at the owning design/editor boundary or represented as an explicit fallible geometry outcome. Retain valid zero-disabled patterns and the domain web/clearance check; do not presuppose UI or visual behavior.',
'references':refs,'historical_alias_qualification':'Related to historical rig CONTRACT-591 and INITIAL06-GROUP-022; neither bounded record explicitly proves this numerical combination. Search was bounded and cannot establish global novelty; central decides aliases and count.'}],
'nonfindings':[
'For zero count other scalar controls are still validated, then spacing returns early and no openings are produced; it is a supported disabled setting, not itself an invalid state.',
'Validated count one uses a dedicated offset branch; zero rows cannot enter the row body. On validated courses, +180 follows lower range guard, so no overflow follows from that operation.',
'Upper seam remains range-checked for a two-course descriptor; alone this is not evidence that two-course mode is invalid.',
'Left/Right signs depend on the carrier coordinate convention; no anatomical reversal is established by sign alone.',
'Geometry rejects hole vertices outside the top course or within the 3 mm web before CDT; this observation does not claim a malformed mesh is built.' ],
'open_questions':[
'Is design.validate intended to guarantee all deterministic geometric combinations, or is fallible geometry-level admission an accepted contract?',
'If this state is considered unsupported, is its typed error visible and actionable to the author, and where should course/slot relationship be owned?',
'What exact chart-frame convention and all supported carriers govern Left/Right?',
'What are the producer persistence, other geometry callers, device kernel failures, native triangulator guarantees, and actual UI interaction? These were not assessed.',
'Is the candidate already covered by another recovered queue/ledger contract outside the bounded searches? Central reconciliation decides.' ],
'lenses':[{'number':i,'name':name,'assessment':a} for i,(name,a) in enumerate(lenses,1)],
'limitations':['No source edits, implementation, product build, test, fixture generation, browser, rendering, simulation, runtime probe or product validation.','Evidence verification scripts only hash, decompress and check Git object membership.','All historical reviewer scopes and revision/snapshot distinctions remain separate; assigned current files being equal does not prove current caller behavior on other paths.','All thirteen perspectives are scoped to these roles and listed support; no whole-lens, entire audit, queue or ledger closure is implied.']}
(p/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print('report written with',len(lenses),'lens perspectives')
