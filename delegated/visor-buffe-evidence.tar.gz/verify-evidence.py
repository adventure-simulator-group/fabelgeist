#!/usr/bin/env python3
"""Read-only evidence verification: hashes, Git membership, provenance and scopes only."""
import gzip,hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['at'] and len(receipt['reads'])==4
for x in receipt['reads']:
 b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof'];covered=set()
 for a,z in x['actual_display_ranges']:covered.update(range(a,z+1))
 assert covered==set(range(1,x['eof']+1)) and not x['unread_ranges']
 assert any(o['revision']==x['revision'] and o['sha256']==x['sha256'] and o['local_file']==x['source_file'] for row in r['rows'] for o in row['objects'])
for row in r['rows']:assert row['objects'][0]['sha256']==row['registry_entry']['sha256']==row['objects'][1]['sha256']
checks.append('Four separately registered personally displayed full old/current bodies and per-file hash identity')
for n in ('','-02'):
 sr=load('support-registration'+n+'.json');s=load('support-read-receipt'+n+'.json');assert s['registration_sha256']==sha((p/('support-registration'+n+'.json')).read_bytes()) and sr['at']<s['at']
 for x in s['reads']:
  b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof']
  assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['prospective_ranges']==x['actual_ranges'] and y['file']==x['source_file'] for y in sr['rows'])
checks.append('Ten support source ranges were registered before their corresponding actual displays; unread ranges and navigation caveats remain explicit')
arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==r['registry_uncompressed_sha256'];registry=json.loads(orig)
 trans=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in trans['entries']}
for x in r['rows']:assert x['registry_entry']==registry['files'][x['original_index']]
for x in load('historical-index.json')['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original registry entries and 14 recovered 059 records verified against published original-transport manifest; four 774 bytes preserved')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==20
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('20 raw commit/tree/blob membership chains establish 6533, 95e and f82 transport identity')
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14))
for x in report['support_reads']:
 cov=set()
 for a,z in x['actual_ranges']:cov.update(range(a,z+1))
 missing=set()
 for a,z in x['unread_for_this_registration']:missing.update(range(a,z+1))
 assert not cov.intersection(missing) and cov.union(missing)==set(range(1,x['eof']+1))
old=gzip.decompress((p/'history-774/contract-groups.jsonl.gz').read_bytes()).splitlines();row=json.loads(old[590]);assert row['id']=='RIG-ADMISSION03-CONTRACT-591' and row['queue_index']==564
checks.append('Scoped 13 lens perspectives, exact support complements, historical CONTRACT-591 record and rule copies')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and accountancy only. No product execution, testing, build, probe, simulation, rendering, implementation, publication edit, whole-lens closure or checkpoint3821 promotion.'},indent=2))
