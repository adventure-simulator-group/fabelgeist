#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='c1ede4a4146af386d6783cea9e75ccf5b7621ede47efc0a519e000084405d5cf';verify_manifest(root,'MANIFEST-PRIVATE.json')
 v1=(root/'DRAFT-v1.json').read_bytes();v2=(root/'DRAFT-v2.json').read_bytes();assert sha(v1)=='d78774d4c9bb446ca83d0ae2e410af71653539bff56b5dfdbe0bde91404ef6ba';assert sha(v2)=='61fd2079860f8b6f0bc2a975d7ee6f2f1c1747dd7207a8deb5d513bc91f63eb9';x=json.loads(v1);y=json.loads(v2);c=json.loads((root/'CORRECTION.json').read_bytes())
 assert c['predecessor_sha256']==y['predecessor_sha256']==sha(v1) and c['successor_sha256']==sha(v2)
 manifest=(root/'prior-review-MANIFEST.json').read_bytes();assert sha(manifest)=='37b32431c78f847cfd78e9ce444492d7fa7510da2445635d0ee861b5131a5489'==c['q10_review_manifest_sha256'];m=json.loads(manifest);r=(root/'prior-review-REPORT.md').read_bytes();assert sha(r)==m['files']['REPORT.md']['sha256'] and len(r)==m['files']['REPORT.md']['bytes']
 q=x['partial_queue_assessments'][0];n=y['partial_queue_assessments'][0];assert q['queue_index']==n['queue_index']==10 and q['historical_lens']==n['historical_lens']==13 and n['independent_review_manifest_sha256']==sha(manifest);assert q['assessment']==n['assessment'] and x['ledger_relationships'][0]==y['ledger_relationships'][0] and x['counts']==y['counts'];assert q['proposed_status']==n['proposed_status'] and x['repair']==y['repair']=='not started' and x['product_validation']==y['product_validation']=='not performed'
 assert n['historical_relationship'].startswith(q['historical_relationship'])
 for s in ['recovered dirty snapshot','not a clean a120 tree','normalized 774','missing pre-export originals','SOURCE004','73 nontext/no-positive-EOF']:assert s in n['historical_relationship']
 for s in ['15c0150f1690cd72ab06baf25cc5d41ce141294160d29d9bb7af22f6c29f6a6f','public-v1 preflight','historical-ledger hash','private attachment verifier','replay-manifest hash','not separately captured byte-for-byte']:assert s in n['custody_qualification']
 def diff(a,b,path=''):
  if isinstance(a,dict) and isinstance(b,dict):
   out=[]
   for k in sorted(set(a)|set(b)):
    if k not in a:out.append([path+'/'+k,'added'])
    elif k not in b:out.append([path+'/'+k,'removed'])
    else:out.extend(diff(a[k],b[k],path+'/'+k))
   return out
  if isinstance(a,list) and isinstance(b,list):
   out=[]
   if len(a)!=len(b):out.append([path,'list-length-changed'])
   for i in range(min(len(a),len(b))):out.extend(diff(a[i],b[i],path+'/'+str(i)))
   return out
  return [] if a==b else [[path,'changed']]
 changes=diff(x,y);assert changes==json.loads((root/'STRUCTURAL-DIFF.json').read_bytes()) and [x[0] for x in changes]==c['changed_json_pointers']
 assert y['created_utc']==x['created_utc'] and 'predecessor metadata' in y['timestamp_qualification'] and y['corrected_created_utc'];print('q10 v1/v2, review identity, unchanged assessment/relationship/counts, and recovery additions: PASS');print('Diff includes q13 paths; no q13 semantic finding. Timestamps self-reported; no product or independent-custody claim.')
if __name__=='__main__':main()
