#!/usr/bin/env python3
import pathlib,json,hashlib,argparse,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest(); J=lambda n:json.loads((P/n).read_bytes())
ap=argparse.ArgumentParser();ap.add_argument('--restricted');a=ap.parse_args()
m=J('MANIFEST.json');files={x['path']:x for x in m['files']};actual={str(x.relative_to(P)):x for x in P.rglob('*') if x.is_file() and x.name!='MANIFEST.json'};assert set(files)==set(actual)
for n,x in actual.items():
 d=x.read_bytes();assert H(d)==files[n]['sha256'] and len(d)==files[n]['bytes'] and oct(x.stat().st_mode&0o777)==files[n]['mode']
assert {str(x.relative_to(P)):oct(x.stat().st_mode&0o777) for x in P.rglob('*') if x.is_dir()}==m['dirs']
c=J('stage/CROSSWALK.json');assert H((P/'stage/CROSSWALK.json').read_bytes())=='31495c742501fa2da79bd384e017435fe59cbcfd8f7087f2972a38090563f06e'
for r in c['rows']:assert H((P/'stage'/r['public_file']).read_bytes())==r['public_sha256']
q=J('stage/Q10-Q13-v2.json');r=J('stage/ROLE0057-v3.json');z=J('REVIEW-011-COMPACT.json')
assert [v['queue_index'] for v in q['partial_queue_assessments']]+[v['record']['queue_index'] for v in r['partial_queue_assessments']]==[10,13,3447,3448,3450,3451]
assert [v['historical_lens'] for v in q['partial_queue_assessments']]+[v['record']['historical_lens'] for v in r['partial_queue_assessments']]==[13,12,1,2,5,6]
assert z['unassessed']==2349 and z['other_statuses_combined']==1364 and z['a422_entries']==3713
assert q['counts']['proposed_partial_additions']==2 and q['counts']['proposed_planning_relationships']==2 and r['counts']['proposed_partial_assessments']==4 and r['counts']['proposed_planning_relationships']==1
for x in [q,r]:
 assert x['counts']['accepted_unique_defect_increment']==x['counts']['semantic_queue_closures']==x['counts']['lens_completions']==0 and x['repair']=='not started' and x['product_validation']=='not performed'
v1=J('stage-corrected/REVIEW-STATUS-v1.json');v2=J('stage-corrected/REVIEW-STATUS.json');assert set(k for k in set(v1)|set(v2) if v1.get(k)!=v2.get(k))=={'status','predecessor_status_sha256','chronology_qualification'}
assert J('stage-corrected/VERIFY-STATUS-SCOPE.json')['verifier_sha256']==H((P/'stage/VERIFY-STATUS.py').read_bytes())
assert J('stage-replay/privacy-SCAN.json')['counts']=={} and all(x==0 for x in J('stage-replay/RESULT.json')['returncodes'].values())
if a.restricted:
 p=pathlib.Path(a.restricted);assert H((p/'MANIFEST.json').read_bytes())=='40ae37ec9b681b1b3b9c3f9da07601a1ded0f204a8e4f79481116019f4f45e73'
 for f in P.rglob('*'):
  if f.is_file() and f.relative_to(P).as_posix() not in {'MANIFEST.json','README.md','VERIFY.py'}:assert f.read_bytes()==(p/f.relative_to(P)).read_bytes()
 z=subprocess.run([sys.executable,str(p/'VERIFY-v3.py')],capture_output=True,text=True);assert z.returncode==0,z.stderr
 print('Separately held restricted originals, Git objects and review archives passed full evidence replay.')
else:print('Public identity and structural checks passed; full original reconstruction, Git-object and archive checks require separately held restricted evidence.')
print('Local timestamps are not trusted. Privacy scanning is finite. No product validation, adoption or closure is certified.')
