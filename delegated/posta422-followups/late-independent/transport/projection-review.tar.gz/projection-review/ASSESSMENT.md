# Independent review of the proposal projections

The two public files are faithful **parsed-value reconstructions** of their
separately held exact drafts. The q10/q13 projection differs at exactly four
listed attribution fields; the role0057 projection differs at exactly eight.
Every other parsed value is equal. Three public aliases map consistently and
one-to-one to three distinct original labels: the q10 and role0057 delegate
share one alias, q13 uses a different alias, and the coordinator uses a third.
The crosswalk gives whole-file SHA-256 values and changed pointers; it does not
publish a digest of any individual removed label. The public files cannot
reconstruct the removed values or byte-identical originals without restricted
custody. Their exact identities are:

* q10/q13 original `61fd2079860f8b6f0bc2a975d7ee6f2f1c1747dd7207a8deb5d513bc91f63eb9`;
  projection `1e4f8bc88f7de6bc3fd0d6e4994349255caa1e5a984c39b350caa00591650b7d`.
* role0057 original `7526a7280d08ebddcca91471961dc1604e627b655f3cce8526524e7c5d277bab`;
  projection `c13804d0db9a6b655a5847436a73561e90f21ba3f98c02290161ae1a196c24e1`.
* Crosswalk `31495c742501fa2da79bd384e017435fe59cbcfd8f7087f2972a38090563f06e`.

The captured a422 commit, tree and reconciliation blob verify independently.
All six selected records q10/lens13, q13/lens12 and q3447/q3448/q3450/q3451
lenses 1/2/5/6 are unassessed in that snapshot and match the projections'
contract IDs. The snapshot contains 3713 records: 2349 unassessed and 1364
whose reconciliation text begins with “partial”. Those are existing snapshot
counts, not closures. Projection counts are unchanged from their originals;
all additions and relationships remain proposed, with no unique-defect
increment, semantic closure, repair or product validation claimed.

The original historical and recovery qualifications are unchanged in the
projections. In particular, original q13 has no recorded source identity,
range or reader, the physical-p16 snapshot is not a clean a120 tree, the
normalized 774 transport is not its missing pre-export original, and the
missing checkpoint 3821 and 73 nontext/no-positive-EOF obligations remain
separate and open. The same aliases preserve the distinct delegate and reader
attributions; this review claims no product-source reading credit.

## Draft-time review status

The original q10/q13 and role0057 drafts retain their original statements that
some later reviews were pending. Those are draft-time statements. The additive
status correction preserves the first status annotation and changes only its
status wording plus predecessor/correction metadata. Exact q13 and role0057
review reports and four public transport archives match their recorded manifest
identities and member bytes/modes; the q13 successor review names the exact
q10/q13 corrected original and reports no blocking q13 issue, while the
role0057 v3 review names its exact original and finds no further bounded
correction. Their source scopes and authorship remain separate.

Observed local filesystem metadata puts the q13 v1 public manifest and receipt
before the q10/q13 corrected draft, while its restricted manifest and custody
replay follow that draft. The q13 v2 and role0057 v3 review public manifests
also follow their respective draft files in the observed local metadata. The
q10 v1 public manifest self-reports a time before the corrected q10/q13 draft.
These are self-reported or mutable local timestamps, not independently
trusted time. The first status annotation's blanket q13 v1 chronology was
therefore too broad; the corrected annotation distinguishes public availability
from later restricted custody and explicitly qualifies the local times. A
reviewer initially supplied an incorrect approximate q10 time and then
corrected it; both messages and the exact manifest observations are retained.

The corrected status annotation retains the predecessor's `recorded_utc`.
That field should be labeled as the predecessor's timestamp, not a verified
creation time for the correction; no correction time is established here.
The separately added verifier-scope note correctly states that the preserved
status verifier binds public identities but does not itself prove chronological
ordering. The three stage evidence verifiers passed in a fresh copied layout;
their success does not authenticate time or certify product behavior.

A bounded scan of the captured projections, crosswalk, status annotations and
verifier scripts found no matches against 66 derived private values/prefixes,
including raw and SHA-256/SHA-1/MD5 raw and hexadecimal forms, or generic path,
email and credential markers. This finite scan is not a complete privacy proof.
The review preserves the initial truncated transport-inventory display, an
explicitly sliced role projection display, an overbroad/truncated status-count
output and a metadata-only member-name listing without a specific advance
registration. Later bounded redisplays and the original artifacts remain
separate; none confers source-reading credit.

The projections and annotation are unadopted. No product source was read for
this review, and no product code, build, test, runtime probe or repair was run.
