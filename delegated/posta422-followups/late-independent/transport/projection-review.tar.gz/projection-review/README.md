# Independent proposal projection review

This public evidence contains path-safe proposal projections, registered status
corrections, compact results and local-time observations. The restricted packet
retains exact private originals, the a422 Git objects, archive bytes, chronology
capture, preseal failures and independent full replay. Its manifest SHA-256 is
40ae37ec9b681b1b3b9c3f9da07601a1ded0f204a8e4f79481116019f4f45e73.

Run VERIFY.py for public identity and structural checks. Supplying --restricted
with the separately held restricted directory additionally replays the full
private comparison and object/archive checks, and matches public files to their
captured sources. The public packet does not reconstruct withheld attribution
values or exact original bytes on its own. Local timestamps are mutable and
not independently trusted. Finite privacy scans cannot guarantee absence of
all sensitive information. Product behavior and adoption are outside scope.
