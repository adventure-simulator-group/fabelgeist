# q2534: personality-axis adapter and projection operations

This is a bounded, independently read Lens 4 assessment for historical q2534.
It does not close the queue entry, assert a new unique defect, change the
ledger, or establish product behavior at runtime.

## Scope and attribution

Original 059 entry 2534 is `EXTENSION-L4-ROOT-L2-EXT-0058`, with status
`pending-independent-lens-qualification` and no Lens 4 ranges recorded. The
immutable a422 reconciliation marks it `unassessed`. Its registered source is
`crates/strategic-web/src/spacetimedb/types.rs` at
`6533e444fa37552927070cc8d8190907fd3b413e`, lines 1–140 and 1204–1222 of
2,523. The original and reconstructed 059 queue streams differ as whole
files; their selected q2534 objects compare equal as parsed.

That one source file is byte-identical at 6533, e275 and the pinned current
revision `95e63628f9d70b8dd6e6fede64334696c6995009`, SHA-256
`df37c376e240735c231aaeca1737d1a0392643d37ab962f902a7d02df42ece02`.
The reviewer separately registered and displayed the required historical and
current windows. The e275 capture is identity evidence, not a separate
personal display. A full-file hash does not establish whole-tree equality.

The old Lens 2 supplier record attributes a full 1–2,523 read to Rig, with
Root reinspection separately recorded; the historical qualified selection is
only the ranges above. The separately recovered supplier metadata matches the
recorded full-file hash and row 562 matches the receipt. Those Lens 2 records
do not confer Lens 4 coverage. All supporting source windows below have their
own current-revision registrations and reader attribution.

## Selected operations and boundaries

* `types.rs:1204–1222` maps each of 15 generated native personality-axis
  variants to the matching core variant by an exhaustive match. The inspected
  adapter does no arithmetic, indexing or mutation. The generated declaration
  and core owner are shown in `personality_axis_type.rs:1–44` and
  `adventuresim-core/src/social.rs:162–180`; no wire decoder or generated code
  was executed. The related web consumer passes the axis and raw `i8` value
  to a label lookup with an uncertain fallback
  (`templates/settlement/social.rs:118–124, 191–199, 277–281`).
* The selected producer writes a belief only when its code is legal for the
  axis and the backend view filters illegal axis/value pairs
  (`adventuresim-stdb-module/src/social.rs:1303–1317, 1352–1365, 2481–2513`).
  In those selected checks, the separate `f32` confidence field has no explicit
  finiteness check; the displayed web consumer clamps and formats it. The
  actual producer and admission of non-finite confidence, native serialization
  and any resulting display remain open. The separately sealed q2510 review
  also considers `diagnosed_axis` inputs; it is a distinct source assessment,
  not transferred credit or an established alias.
* The scoped prefix declares numeric character and settlement projection
  fields. Selected constructors copy character experience, level and age or
  settlement coordinates and population from native rows without numerical
  conversion (`types.rs:467–549`, `live.rs:541–557`). The current world-import
  path checks finite, inclusive coordinate bounds before assigning longitude
  and latitude to the persisted settlement row (`world_import.rs:625–710`,
  `coordinates.rs:11–20`). The projection does not itself recheck those
  values. Other producers, direct deserialization, current stored values and
  the complete world-import pipeline were not assessed. Zero population is a
  documented missing-estimate sentinel on the source row; the selected category
  function falls back to level (`world_import.rs:46–67, 108–118`).
* For a visible, alive, co-located member under an active actor, the selected
  route replaces `social_notification_count` with a count of eligible source
  rows not in the successful-address set (`encumbrance.rs:389–479`,
  `adventuresim-core/src/social.rs:469–493`). The selected portrait reads and
  displays that count (`chrome/portraits.rs:86–114`). There is no explicit
  numeric narrowing or intermediate addition in this selected path.

The notification path has a separate conditional error-policy question. A
source-query error is replaced with an empty source list for that member; an
address-query error is replaced with an empty successful-address set. If the
branch and failures occur, these defaults can respectively omit relevant
notifications or count eligible rows that had actually been addressed. Source
inspection alone does not establish a failure, its user-visible occurrence,
intended fallback policy, complete error handling, or an exact ledger alias.

## Relationships and recovery limits

Original 059 q541 and a422 ledger row 843 concern the separate typed-axis to
slug to hint operation. They are related by the axis owner, not proven aliases
of a numeric or notification question. Other q2532–q2543 obligations retain
their own lenses and readers. A bounded search of the original queue and a422
ledger for the listed notification identifiers returned no matches; that is
not a global alias search or a new unique count.

The first combined display of the two registered notification windows was
truncated by the tool. Exact windows were captured before display and each was
subsequently redisplayed without reported truncation. The initial tool-emitted
transcript was not separately saved byte-for-byte. A later generated-file
request extended through line 45 although the actual EOF was 44; no nonexistent
line receives credit. One locator was repeated for capture; the repeat is not
represented as the original wrapper transcript.

The recovered 774 catalog remains normalized and its pre-export originals
remain missing. SOURCE004 and 73 nontext/no-positive-EOF qualifications remain.
Checkpoint 3821 has not been recovered or supplemented from older state.
The public packet requires its separately preserved restricted originals and
Git proofs for full replay; those are same-machine copies, not independent
custody or public-only recovery. The privacy scan is bounded, not proof of the
absence of every sensitive value.
