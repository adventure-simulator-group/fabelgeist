#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='ca20ceccec02cf9b82af8d802ab5fd98a6826341866ff27a182b8c7fc2483f6e';verify_manifest(root,'MANIFEST-PRIVATE.json')
 src=proof(root,'SOURCE-GIT-PROOF.json','source-git-objects',True);hist=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert len(src)==15 and len(hist)==3
 revs=['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','95e63628f9d70b8dd6e6fede64334696c6995009'];path='crates/strategic-web/src/spacetimedb/types.rs';expected='df37c376e240735c231aaeca1737d1a0392643d37ab962f902a7d02df42ece02'
 assert all(src[(r,path)]==src[(revs[0],path)] and sha(src[(r,path)])==expected for r in revs);assert len(src[(revs[0],path)].decode().splitlines())==2523
 objects=json.loads((root/'SOURCE-GIT-PROOF.json').read_bytes())['objects'];kind,c=decode_object(root/'source-git-objects',revs[2],objects[revs[2]]);assert kind=='commit' and c.split(b'\n',1)[0]==b'tree 1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
 old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';rec='dac7d0055716053f245139971eb67ddfd87fa462';hp='baseline-059/queue.json';assert sha(hist[(old,hp)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(hist[(rec,hp)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 o=exact_selections(hist[(old,hp)],[2534])[2534];n=exact_selections(hist[(rec,hp)],[2534])[2534];assert o[0]==n[0];assert o[1]==(root/'original-q2534-exact.json').read_bytes() and n[1]==(root/'reconstructed-q2534-exact.json').read_bytes();q=o[0];x=q['exact_source_identities_and_assessed_ranges'][0];assert q['contract_id']=='EXTENSION-L4-ROOT-L2-EXT-0058' and q['lens']==4 and q['status']=='pending-independent-lens-qualification' and q['new_source_or_original_or_unique_credit']==0;assert x['revision']==revs[0] and x['required_ranges']==[[1,140],[1204,1222]] and x['this_lens_assessed_ranges']==[]
 cp='a4223bf23487b5872bc5efe5b272d40f859456f2';base=json.loads(src[(cp,'BASELINE-95E-20261110.json')]);rq=json.loads(src[(cp,'RECONCILIATION-059.json')]);assert rq['entries'][2534]['current_reconciliation']=='unassessed';rows=base['newly_assessed_ledger']['entries'];rel=json.loads((root/'ledger-008-exact.json').read_bytes());assert len(rel)==1 and rel[0]['index']==843 and rel[0]['row']==rows[843] and rows[843]['id']=='SEGOVB-L12-SOCIAL-PERSONALITY-AXIS-SLUG-ROUNDTRIP'
 for name,digest in [('REGISTRATION-ROOT-L2-EXT-055-063.json','80050300f1444900b4e83feaa34cd9fff15e8e42d08d94240bc4600ab66109fd'),('READ-ROOT-L2-EXT-055-066.json','b7fe7d69310e522f8ae05bdbeded0b382a244466b8b203a3e467f55f10ee418a'),('QUALIFIED-INHERITED-L2-EXT-055-058-060-061-001.json','bd94d9ee48850460d399a43ad162a05de0601918d3f4431e50417b63d4e408d6')]:assert sha((root/('receipt-'+name)).read_bytes())==digest
 l2=json.loads((root/'receipt-READ-ROOT-L2-EXT-055-066.json').read_bytes())['rows'][3];inh=json.loads((root/'receipt-QUALIFIED-INHERITED-L2-EXT-055-058-060-061-001.json').read_bytes())['rows'][3];assert l2['fresh_personal_ranges']==[] and l2['qualified_inherited_same_lens_ranges']==[[1,140],[1204,1222]] and inh['supplier']=='rig' and inh['prior_assessed_ranges']==[[1,2523]] and inh['qualified_selected_same_lens_ranges']==[[1,140],[1204,1222]]
 supplier=(root/'supplier-metadata.raw').read_bytes();assert sha(supplier)=='77178019c52b79087c5c69a67e85861bd5c94a35aadd2947f955bb5057d17cc9';assert json.loads(supplier.splitlines()[562])==inh['raw_row']==json.loads((root/'supplier-row-562.json').read_bytes())
 count=0
 for label in ['historical','current']:
  for lo,hi in [(1,70),(71,140),(1204,1222)]:window(root,label+'-types.raw',f'{label}-types-{lo:04}-{hi:04}.txt',lo,hi);count+=1
 for f in ['SUPPORT-IDENTITIES-005.json','SUPPLEMENT-IDENTITIES-007.json','SETTLEMENT-IDENTITIES-009.json','ADMISSION-IDENTITIES-013.json','NOTIFICATION-IDENTITIES-015.json']:
  for item in json.loads((root/f).read_bytes()):
   assert item['revision']==revs[2] and src[(revs[2],item['path'])]==(root/item['capture']).read_bytes()
   for w in item['views']:window(root,item['capture'],w['capture'],w['lo'],w['hi']);count+=1
 for raw,out,lo,hi in [('settlement-2.raw','world-import-0600-0710.txt',600,710),('support-3.raw','count-producer-0440-0510.txt',440,510),('notification-0.raw','notification-context-0380-0425.txt',380,425)]:window(root,raw,out,lo,hi);count+=1
 assert count==29;generated=json.loads((root/'SUPPLEMENT-IDENTITIES-007.json').read_bytes())[0];assert generated['lines']==44 and generated['views'][0]['requested_hi']==45 and generated['views'][0]['hi']==44
 related=json.loads((root/'RELATED-SEARCH-004.json').read_bytes());queue=json.loads(hist[(old,hp)])['entries'];assert all(r['row']==queue[r['index']] for r in related['original_059']);assert related['a422_ledger']==[]
 terms=json.loads((root/'REGISTRATION-019.json').read_bytes())['terms'];found=json.loads((root/'NOTIFICATION-RELATED-019.json').read_bytes());assert found=={'original_059':[],'a422_ledger':[]}
 for collection in (queue,rows):
  for item in collection:
   text=json.dumps(item,ensure_ascii=False).lower();assert not any(t.lower() in text for t in terms)
 print('restricted manifest, 15 source/checkpoint bindings, q2534 and 059 proof, a422 ledger, Rig receipt: PASS')
 print('29 registered source windows and bounded notification relationship search: PASS')
 print('Scope: evidence bytes and registered displays; no semantic closure, product execution, validation, independent custody or checkpoint 3821 claim.')
if __name__=='__main__':main()
