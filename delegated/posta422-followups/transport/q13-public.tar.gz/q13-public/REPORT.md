# q13: projectile kind selected from an item ID

This is a bounded, fresh Lens 12 source review by `verifier_scope`, at product
revision `95e63628f9d70b8dd6e6fede64334696c6995009`, whose root tree is
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The current source still chooses
projectile kind from a substring of the selected ranged weapon's open item ID.
This is a source-level classification contract; no incorrect stock outcome,
supported alternative catalog, runtime event, unique count, alias, or audit
closure is established. Central reconciliation owns the repair ledger.

## Historical evidence and current scope

Original 059 q13, `LENS12-PROJECTILE-ID-SUBSTRING`, is Lens 12 and was
`open-reconciliation`. Its original queue row records no source identity,
assessed range, receipt, or personal reader. The separate original 059 ledger
names a Segovb-continuation Lens 12 receipt. That receipt records an earlier
independent full read of physical-p16
`crates/adventuresim-stdb-module/src/capability/equipment_projection.rs`,
lines 1–266, SHA-256
`4a77425e90eace3b800f13d7f8e81ad2ba781bfda422b9a0decbba0de870eae9`.
The receipt identifies the substring branch and leaves native item admission,
projectile metadata, exact aliases and currentness open. Its historical reader,
revision and lens are not transferred to this reviewer.

Two local receipt copies match observed whole-file SHA-256
`d9ba7364ab54058fe5be389634c3c06855e26ea9156064b5e08c13c6fad4bb78`;
the 059 ledger gives its path, not that digest. The physical-p16 source bytes
are independently bound to the f82 normalized 774 transport object. This
does not identify the pre-export source as current 95e or prove unavailable
pre-export originals were recovered. The original and reconstructed full 059
queue and ledger streams have different hashes; the selected q13 records
compare equal as parsed values.

The older projection at physical-p16 lines 95–144 selected the ranged item
and computed the kind at lines 113–119. The separately read 95e projection
file is a different 85-line body; the relevant current branch is now in
`capability.rs:519–525`. The immutable f2ec reconciliation observed for this
review marks q13 `unassessed`. The current `capability.rs` read was bounded to
lines 1–85 and 245–560; its other lines and unrelated string contracts remain
unassessed here. Historical and current `capability/armor.rs` are equal for
that file only; the historical receipt's earlier read does not grant new
reviewer credit.

## Exact string and data flow

The current item table has an open `String` ID and a separate `ranged` flag
(`item.rs:77–109`). Authored definition projection copies both the ID and the
weapon's ranged flag (`item.rs:140–150,221–251,290–301`). The effective-item
lookup follows the inventory item's ID to the item row and applies condition
adjustments to selected stats (`capability/armor.rs:54–69`).
`StrategicEquipment::load` inspects left then right held selections and keeps
the first item whose kind is Weapon and whose ranged flag is true
(`capability.rs:278–296,347–365`). Earlier required lookups and weapon
projection must also succeed before the later classification is returned.

For a selected ranged weapon, `capability.rs:519–525` uses the
case-sensitive substring predicate `weapon.id.contains("arquebus")`: a match
becomes `ProjectileKind::Ball`, and a nonmatch becomes
`ProjectileKind::Arrowhead`. The existing typed enum has precisely those two
variants (`projectile.rs:1–10`), but this branch chooses between them from the
name rather than a displayed projectile-capability field. The valid authored
ID character check accepts nonempty IDs of at most 64 lowercase ASCII letters,
digits and underscores (`item_catalog_validation.rs:362–370,1447–1453`).
That check alone does not establish uniqueness, all other item constraints,
references, or an admitted alternative item.

For example, a hypothetical selected ranged item named `musket` would take
the nonmatching branch, while one named `not_arquebus` would take the matching
branch. These examples illustrate the string predicate and its unanchored
matching; their intended projectile, complete admission and supported
producers are not established. The pinned authored catalog does contain
`hooked_arquebus` and `matchlock_arquebus`, both marked ranged weapons
(`content/items/catalog.yaml:2381–2442,4008–4069`). Both match the predicate;
that fact does not demonstrate a wrong result for either stock item.

The adjacent ammunition count tests exact ID `arrow` and excludes
fireplace-rooted rows (`capability.rs:366–380`); a separate strategic
consumption function also selects the exact ID `arrow`
(`strategic/autoresolve.rs:155–178`). Those exact-ID operations have different
first contracts from substring-based projectile classification. Their policy,
all ammo categories, and any connection to an actual game outcome remain open.

`CombatEquipment` carries `Option<ProjectileKind>`, the combatant projection
passes the equipment into battle, and ranged battle recording carries the
kind into `BattleLogEntry` (`autoresolve/model.rs:82–99`,
`capability/combatant.rs:43–81`, `autoresolve.rs:780–814,995–1031`). The
recorder defaults an absent ranged kind to Arrowhead (`autoresolve.rs:558–574`);
that fallback is a separate condition from the present selected-ID branch.

A generic strategic consequence path passes a log kind to injury commitment
for an allied defender with positive health damage, and the surgery code
inserts a retained projectile only with positive cut plus blunt damage
(`strategic/encounters.rs:976–1000`, `surgery.rs:257–273,310–326`). In the
inspected random and mission paths, item-backed party combatants are allies,
enemies are constructed through a separate authored-threat path, and ranged
attacks target the opposing side. The selected Item-derived kind is therefore
not shown to reach an allied retained injury. Separately, the inspected
post-combat body projection stores only whether a projectile was present,
not its typed kind (`autopsy.rs:104–123`). These are bounded source facts,
not observed battles or complete reachability conclusions.

## Related records and remaining decisions

Original 059 q1009 and q1011, with their exact historical journal values,
remain unassessed in f2ec. They raise projectile contribution and projectile
identity/absence questions; neither is an automatic q13 alias. The broad
search also located q1872, whose f2ec status is separately partial and whose
scope includes unrelated service behavior. f2ec ledger rows 388 and 394
concern a tactical ammunition receipt cap and ranged miss/hit payload shape,
respectively; their first operations and attributions remain distinct.
Searches were literal and bounded; the word `arrow` also matched `narrowing`.
No global alias-absence or unique-count inference follows.

Open work includes the intended authored projectile/ammunition capability,
complete item and reference admission, supported held-weapon producers,
selection and attack reachability, native schema and all relevant consumers,
and exact reconciliation with earlier records. The historical repair
dependency proposes carrying a typed capability while retaining open item IDs;
its final owner and behavior need reconciliation before any implementation.

## Recovery and verification limits

The offline evidence verifier checks original/reconstructed 059 queue and
ledger objects, the immutable f2ec snapshot, the observed historical receipt,
21 source revision/path bindings, the 95e commit's root tree, 39 registered
source displays and selected historical relationships. It verifies captured
bytes, not product semantics, source-reader attention, all source families,
or privacy beyond the bounded scan. The strongest replay needs the separately
held restricted collection containing raw Git objects and path-bearing
originals; same-machine custody is not independent public recoverability.
No individual removed local-path digest is published.

The initial attempt treated `1eec` as a commit abbreviation and failed because
it was ambiguous; its stderr and empty stdout are captured, while the
visible assertion traceback was not separately preserved byte-for-byte. The
95e commit's exact root tree was then established. The historical receipt
itself records an older broad navigation command whose output was truncated;
it granted that command no source-body credit and records later scoped reads.
Some source windows include test declarations, read as text only; no tests,
fixtures, product code, builds, probes or validation ran.

Preserve normalized 774 separately from missing pre-export originals, the
SOURCE004 and 73 nontext/no-positive-EOF qualifications, and the absent
checkpoint 3821. Earlier records are not promoted into 3821. No protected
extraction, product source, publication or central ledger was modified.
