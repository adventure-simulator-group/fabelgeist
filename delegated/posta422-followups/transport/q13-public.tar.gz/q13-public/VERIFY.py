#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='abef6bafc82beb75c90343f969b78a7c908248ff288695cb539f888ebc279adc';verify_manifest(root,'MANIFEST-PRIVATE.json')
 source=proof(root,'SOURCE-GIT-PROOF.json','source-git-objects',True);checkpoint=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);history=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert len(source)==23 and len(checkpoint)==2 and len(history)==3
 product='95e63628f9d70b8dd6e6fede64334696c6995009';si=json.loads((root/'SOURCE-GIT-PROOF.json').read_bytes());kind,commit=decode_object(root/'source-git-objects',product,si['objects'][product]);assert kind=='commit' and commit.startswith(b'tree 1eec97de340d9b7debbb30ca0c0fb2240a73b93f\n')
 original='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';recon='dac7d0055716053f245139971eb67ddfd87fa462';qp='baseline-059/queue.json';lp='baseline-059/ledger.json';assert sha(history[(original,qp)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(history[(recon,qp)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173';assert sha(source[(original,lp)])=='3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac' and sha(source[(recon,lp)])=='f9501199085284117ef88969fae443654af353429c657fd6bd1efb916582b180'
 indices=[13,1009,1011,1872];old=exact_selections(history[(original,qp)],indices);new=exact_selections(history[(recon,qp)],indices);assert all(old[i][0]==new[i][0] for i in indices);q=old[13][0];assert q['contract_id']=='LENS12-PROJECTILE-ID-SUBSTRING' and q['lens']==12 and q['status']=='open-reconciliation' and q['exact_source_identities_and_assessed_ranges']==[] and q['historical_receipt'] is None and q['body_or_population_credit']==0
 for label,sel in [('original',old),('reconstructed',new)]:assert (root/f'{label}-q13-exact.json').read_bytes()==sel[13][1] and json.loads((root/f'{label}-q13-pretty.json').read_bytes())==sel[13][0]
 ol=json.loads(source[(original,lp)]);nl=json.loads(source[(recon,lp)]);x=ol['discovery_findings_and_dependencies'][q['contract_id']];y=nl['discovery_findings_and_dependencies'][q['contract_id']];assert x==y and x==json.loads((root/'original-ledger-q13.json').read_bytes())==json.loads((root/'reconstructed-ledger-q13.json').read_bytes());assert x['source'].endswith('lens12/receipt-023-originals172-177.json')
 receipt=(root/'historical-receipt-023.json').read_bytes();assert sha(receipt)=='d9ba7364ab54058fe5be389634c3c06855e26ea9156064b5e08c13c6fad4bb78';rc=json.loads(receipt);rs=next(z for z in rc['sources'] if z['original_index']==176);assert rs['source_id']=='physical-p16:crates/adventuresim-stdb-module/src/capability/equipment_projection.rs' and rs['sha256']=='4a77425e90eace3b800f13d7f8e81ad2ba781bfda422b9a0decbba0de870eae9' and rs['actual_ranges']==[[1,266]];assert sha((root/'historical-projection.raw').read_bytes())==rs['sha256'] and len((root/'historical-projection.raw').read_bytes().splitlines())==266 and len((root/'current-projection.raw').read_bytes().splitlines())==85
 assert (root/'historical-effective-item.raw').read_bytes()==(root/'current-effective-item.raw').read_bytes() and sha((root/'current-effective-item.raw').read_bytes())=='027f27a4294fe1574bcb9c7f376db05904519094f99936be09bcf66d5459b7e0'
 f2ec='f2ec8cbad7becbcc9a8e9da22ba512f52975768f';base=checkpoint[(f2ec,'BASELINE-95E-20261110.json')];rq=checkpoint[(f2ec,'RECONCILIATION-059.json')];assert sha(base)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041' and sha(rq)=='73bc3864944276b88944163257e3cfc67dde6141b2dc3f82588af66621003945';rows=json.loads(base)['newly_assessed_ledger']['entries'];rqs=json.loads(rq)['entries'];assert len(rows)==1101 and len(rqs)==3713 and rqs[13]==json.loads((root/'published-q13.json').read_bytes()) and rqs[13]['current_reconciliation']=='unassessed'
 related=json.loads((root/'RELATED-QUEUE-004.json').read_bytes());assert [z['index'] for z in related]==[1009,1011,1872]
 for z in related:assert z['original']==old[z['index']][0] and z['reconstructed']==new[z['index']][0] and z['published']==rqs[z['index']]
 journal=json.loads((root/'JOURNAL-RELATED-013.json').read_bytes());assert len(journal)==2
 for z in journal:
  values=[]
  for ledger in [ol,nl]:
   v=ledger
   for part in z['pointer'].strip('/').split('/'):v=v[int(part)] if isinstance(v,list) else v[part]
   values.append(v)
  assert values[0]==values[1]==z['original']==z['reconstructed'] and z['parsed_equal']
 selected=json.loads((root/'LEDGER-SELECTED-010.json').read_bytes());assert all(rows[z['index']]==z['row'] for z in selected);assert rows[388]['id']=='REVIEW-TACTICAL-AMMUNITION-RECEIPT-CAP-001' and rows[394]['id']=='SEGOVB-L12-RANGED-MISS-HIT-PAYLOAD-OWNERSHIP'
 reg=json.loads((root/'REGISTRATION-009.json').read_bytes());hits=[]
 for i,row in enumerate(rows):
  s=json.dumps(row,ensure_ascii=False).casefold();terms=[t for t in reg['ledger_terms'] if t in s]
  if terms:hits.append({'index':i,'id':row.get('id'),'terms':terms,'row':row})
 assert hits==json.loads((root/'PUBLISHED-RELATED-009.json').read_bytes()) and len(hits)==45
 assert sha((root/'SKILL-magic-strings.md').read_bytes())=='4288426f134e7b781da6ea3b9167722776db976f577b56e7936e787306fb277c'
 windows=[]
 for name,key in [('REGISTRATION-006.json','display_windows'),('REGISTRATION-007.json','windows'),('REGISTRATION-008.json','windows'),('REGISTRATION-010.json','source_windows'),('REGISTRATION-011.json','windows'),('REGISTRATION-012.json','windows'),('REGISTRATION-014.json','windows'),('REGISTRATION-015.json','windows'),('REGISTRATION-016.json','windows')]:
  reg=json.loads((root/name).read_bytes())
  for w in reg[key]:
   for lo,hi in w.get('ranges',[w.get('range')]):windows.append((w['file'],f"{w['file']}-{lo}-{hi}.txt",lo,hi))
 assert len(windows)==39
 for x in windows:window(root,*x)
 print('restricted manifest, 21 source and 2 ledger Git selections, 95e tree, original/reconstructed queues, f2ec, receipt, relationships and 39 captured windows: PASS')
 print('Evidence only; no product execution, semantic closure, runtime validation, independent custody or checkpoint 3821 claim.')
if __name__=='__main__':main()
