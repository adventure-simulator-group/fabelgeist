#!/usr/bin/env python3
"""Read-only corrected verification of the unchanged private custody packet."""
import argparse,hashlib,json,pathlib,sys
if sys.flags.optimize:raise RuntimeError('assertions required')
p=pathlib.Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path,required=True);a=ap.parse_args();r=a.restricted;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda x:json.loads(x.read_bytes());c=J(p/'CORRECTION.json');assert H((r/'PRIVATE-MANIFEST.json').read_bytes())==c['private_manifest_sha256'];m=J(r/'PRIVATE-MANIFEST.json');assert r.stat().st_mode&0o777==0o700 and not any(x.is_symlink() for x in r.rglob('*'))
files={x.relative_to(r).as_posix() for x in r.rglob('*') if x.is_file() and x!=r/'PRIVATE-MANIFEST.json'};dirs={x.relative_to(r).as_posix() for x in r.rglob('*') if x.is_dir()};assert files==set(m['files']) and dirs==set(m['directories'])
for n,v in m['files'].items():
 x=r/n;b=x.read_bytes();assert len(b)==v['bytes'] and H(b)==v['sha256'] and x.stat().st_mode&0o777==v['mode']
for n,v in m['directories'].items():assert (r/n).stat().st_mode&0o777==v
inv=J(r/'CUSTODY-INVENTORY.json');assert inv['replay_manifest_sha256']==c['recorded_transcription'] and H((r/'public-replay-receipt/MANIFEST.json').read_bytes())==c['corrected_replay_whole_manifest_sha256'];assert H((r/'public-transport/MANIFEST.json').read_bytes())==inv['public_manifest_sha256'] and H((r/'public-privacy-receipt/MANIFEST.json').read_bytes())==inv['privacy_manifest_sha256']
manifest=J(p/'MANIFEST.json');actual={x.name for x in p.iterdir() if x.is_file() and x.name!='MANIFEST.json'};assert actual==set(manifest['files'])
for n,v in manifest['files'].items():
 b=(p/n).read_bytes();assert len(b)==v['bytes'] and H(b)==v['sha256']
print(json.dumps({'result':'pass','files':len(files),'directories':len(dirs),'qualification':'Corrected identity verification only; no product, personal-display, global privacy, or queue-closure claim.'}))
