#!/usr/bin/env python3
# Evidence-only verifier. It never executes repository product code.
import pathlib,hashlib,json,argparse,stat,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;C=P/'central/0';H=lambda b:hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--private',type=pathlib.Path);a.add_argument('--anchors',type=pathlib.Path);a.add_argument('--delegate',type=pathlib.Path);a.add_argument('--skip-manifest',action='store_true');args=a.parse_args()
if (args.anchors or args.delegate) and not args.private:raise SystemExit('Optional external inputs require --private')
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);assert z+21<=len(b);n=b[a+1:z].decode();assert n not in out;out[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def prove(root,path,data):
 parts=path.split('/')
 for i,part in enumerate(parts):
  t=(C/'trees'/(root+'.tree')).read_bytes();assert oid('tree',t)==root;mode,root=tree(t)[part];assert (mode in ('40000','040000')) if i<len(parts)-1 else mode=='100644'
 assert oid('blob',data)==root
cap=json.loads((C/'CAPTURE.json').read_bytes());reg=json.loads((C/'REGISTRATION.json').read_bytes());rows={x['path']:x for x in cap['rows']};assert len(rows)==6 and set(rows)=={v['path'] for v in reg['views']}
for x in rows.values():
 b=(C/x['file']).read_bytes();assert (len(b),H(b),len(b.splitlines()))==(x['bytes'],x['sha256'],x['eof']);prove(cap['root_tree'],x['path'],b)
def show(v):
 lines=(C/rows[v['path']]['file']).read_text().splitlines();r=[]
 for a,b in v['ranges']:
  assert 0<a<=b<=len(lines);r.append(f'--- {v["path"]}:{a}-{b} ---');r.extend(f'{i:4d} {lines[i-1]}' for i in range(a,b+1))
 return ('\n'.join(r)+'\n').encode()
for ixfile,folder,registration in [('DISPLAY-INDEX.json','',reg),('SUPPLEMENT-DISPLAY-INDEX.json','supplement-displays',json.loads((C/'SUPPLEMENT-REGISTRATION.json').read_bytes()))]:
 ix=json.loads((C/ixfile).read_bytes())['views'];assert len(ix)==len(registration['views'])
 for v,x in zip(registration['views'],ix):
  assert v['path']==x['path'];data=(C/folder/x['file']).read_bytes();assert data==show(v) and H(data)==x['sha256']
for receipt,index,key in [('DISPLAY-RECEIPT.json','DISPLAY-INDEX.json','display_index_sha256'),('SUPPLEMENT-DISPLAY-RECEIPT.json','SUPPLEMENT-DISPLAY-INDEX.json','index_sha256')]:assert json.loads((C/receipt).read_bytes())[key]==H((C/index).read_bytes())
own=json.loads((P/'REVIEW-010-SOURCE-REG.json').read_bytes());res=json.loads((P/'REVIEW-010-SOURCE-RESULT.json').read_bytes());assert [(v['path'],r) for v in own['views'] for r in v['ranges']]==[(x['path'],x['range']) for x in res]
for x in res:
 a,b=x['range'];lines=(C/rows[x['path']]['file']).read_text().splitlines();data=('\n'.join(f'{i:4d} {lines[i-1]}' for i in range(a,b+1))+'\n').encode();assert (P/x['file']).read_bytes()==data and H(data)==x['sha256']
draft=json.loads((C/'DRAFT.json').read_bytes());expected=[(3447,1),(3448,2),(3450,5),(3451,6)];assert len(draft['partial_queue_assessments'])==4 and len(draft['ledger_relationships'])==1 and draft['counts']['semantic_queue_closures']==0
for entry,(i,l) in zip(draft['partial_queue_assessments'],expected):
 r=entry['record'];assert (r['queue_index'],r['historical_lens'],r['historical_contract_id'])==(i,l,f'OBLIGATION-ROOT-L3-EXT-0057-LENS-{l:02d}')
cross=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes());assert cross['private_manifest_sha256']=='b92f54787632afc6239fece112a708820a5568087d8d12f26586f7db611ddbde'
assert any(x['private_relative']=='central/0/DRAFT.json' and x['private_sha256']=='4b6bb7f8cb921a0715bdf120d73550a241b839502c900ec95c93cd27a5ff5570' for x in cross['files'])
for x in cross['files']:
 for k in ('private_relative','public_relative'):
  path=pathlib.PurePosixPath(x[k]);assert not path.is_absolute() and '..' not in path.parts
 out=(P/x['public_relative']).read_bytes();assert len(out)==x['public_bytes'] and H(out)==x['public_sha256']
 if args.private:
  raw=(args.private/x['private_relative']).read_bytes();assert len(raw)==x['private_bytes'] and H(raw)==x['private_sha256'];pos=0;made=bytearray()
  for r in x['replacements']:
   off=r['offset'];end=off+r['length'];assert pos<=off<=end<=len(raw);made+=raw[pos:off]+r['replacement'].encode();pos=end
  made+=raw[pos:];assert bytes(made)==out
if not args.skip_manifest:
 m=json.loads((P/'MANIFEST.json').read_bytes());fs={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and not x.is_symlink()};ds={str(x.relative_to(P)) for x in P.rglob('*') if x.is_dir() and not x.is_symlink()};assert not any(x.is_symlink() for x in P.rglob('*'));assert fs==set(m['files'])|{'MANIFEST.json'} and ds==set(m['directories'])
 for name,x in m['files'].items():
  p=P/name;b=p.read_bytes();assert (len(b),H(b),stat.S_IMODE(p.stat().st_mode))==(x['bytes'],x['sha256'],x['mode'])
 for name,mode in m['directories'].items():assert stat.S_IMODE((P/name).stat().st_mode)==mode
 print('Public manifest, files and modes: pass')
else:print('Public manifest skipped for preseal only')
print('Public source root-tree to blobs, registered transcripts, own selected views, draft mappings and projected file identities: pass')
print('Public-only limits: commit to root binding, queue positions, private replaced bytes and original delegate require separately held evidence.')
if args.private:
 assert H((args.private/'MANIFEST.json').read_bytes())==cross['private_manifest_sha256'];cmd=[sys.executable,str(args.private/'verify-review.py')]
 if args.anchors:cmd+=['--anchors',str(args.anchors)]
 if args.delegate:cmd+=['--delegate',str(args.delegate)]
 subprocess.run(cmd,check=True);print('Restricted evidence replay and byte/offset crosswalk: pass')
else:print('Private byte/offset crosswalk comparison: not requested')
print('Display events are attestations; no product execution or validation.')
