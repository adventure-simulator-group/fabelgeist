#!/usr/bin/env python3
"""Read-only q10 evidence identity replay; never run product code."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
if sys.flags.optimize:raise RuntimeError('assertions required')
p=pathlib.Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--repo',type=pathlib.Path);ap.add_argument('--restricted',type=pathlib.Path);a=ap.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();J=lambda x:json.loads(x.read_bytes());m=J(p/'MANIFEST.json');r=J(p/'REPORT.json');o=J(p/'SOURCE-OBJECTS.json');receipt=J(p/'READ-RECEIPT.json');hist=J(p/'HISTORY-SUMMARY.json')
assert not any(x.is_symlink() for x in p.rglob('*'));files={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'};assert files==set(m['files'])
for n,v in m['files'].items():
 b=(p/n).read_bytes();assert len(b)==v['bytes'] and h(b)==v['sha256'] and (p/n).stat().st_mode&0o777==v['mode']
assert r['historical_contract_id']=='LENS13-DURABILITY-TIER-INTERMEDIATE-OVERFLOW' and r['historical_lens']==13 and r['source_revision']==o['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and o['source_tree']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
index={}
for row in o['objects']:
 b=(p/row['object']).read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'] and len(b.splitlines())==row['eof_lines'];assert hashlib.sha1(('blob %d\0'%len(b)).encode()+b).hexdigest()==row['git_blob'];index[(row['group'],row['id'])]=row
for view in receipt['views']:
 row=index[(view['group'],view['source_id'])];assert all(view[k]==row[k] for k in ['revision','path','source_sha256'] if k!='source_sha256') and view['source_sha256']==row['sha256'] and view['git_blob']==row['git_blob'];start,end=view['lines'];assert 1<=start<=end<=row['eof_lines'];lines=(p/row['object']).read_text().splitlines();expected=('\n'.join(f'{i:4d} {lines[i-1]}' for i in range(start,end+1))+'\n').encode();body=(p/view['view_file']).read_bytes();assert body==expected and h(body)==view['view_sha256'];reg=J(p/view['registration']);assert any(x['path']==view['path'] and x['revision']==view['revision'] and x['sha256']==view['source_sha256'] and x['lines']==view['lines'] for x in reg['views'])
assert len(receipt['views'])==32 and hist['reconstructed_selected_equal_as_parsed'] is True and all(x['located'] and x['match'] and x['sha256']==x['expected_sha256'] for x in hist['references'])
if a.repo:
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');tree=subprocess.check_output(['git','-C',str(a.repo),'rev-parse',r['source_revision']+'^{tree}'],env=env).decode().strip();assert tree==o['source_tree']
 for row in o['objects']:
  got=subprocess.check_output(['git','-C',str(a.repo),'rev-parse',row['revision']+':'+row['path']],env=env).decode().strip();assert got==row['git_blob']
if a.restricted:
 z=a.restricted;old=(z/'queue-original.json').read_bytes();reconstructed=(z/'queue-reconstructed.json').read_bytes();ledger=(z/'ledger-original.json').read_bytes();assert h(old)==hist['original_queue_sha256'] and h(reconstructed)==hist['reconstructed_supplier_sha256'] and old!=reconstructed and h(ledger)==hist['original_ledger_sha256'];q=json.loads(old)['entries'][10];assert q==json.loads(reconstructed)['entries'][10];serialized=(json.dumps(q,indent=2,ensure_ascii=False)+'\n').encode();assert h(serialized)==hist['original_selected_normalized_sha256'];v=json.loads(ledger)['discovery_findings_and_dependencies'][r['historical_contract_id']];serialized=(json.dumps(v,indent=2)+'\n').encode();assert h(serialized)==hist['original_ledger_selected_normalized_sha256'];assert json.loads((z/'queue-reconciliation.json').read_bytes())['entries'][10]['current_reconciliation']=='unassessed';assert json.loads((z/'published/RECONCILIATION-059.json').read_bytes())['entries'][10]['current_reconciliation']=='unassessed'
 for reg,folder,prefix in [('HISTORICAL-REFS-CAPTURE.json','historical',''),('HISTORICAL-SUPPLEMENT-CAPTURE.json','historical','supplement-')]:
  for x in J(z/reg):
   assert x['located'] and x['match'];b=(z/folder/(prefix+str(x['id'])+'.json')).read_bytes();assert h(b)==x['sha256']==x['expected_sha256']
print(json.dumps({'result':'pass','source_objects':len(o['objects']),'personally_displayed_windows':len(receipt['views']),'git_revision_proof_checked':bool(a.repo),'restricted_historical_checked':bool(a.restricted),'qualification':'Evidence identities, registered windows and selected record equality only. Not validation of personal display acts, product behavior, input reachability, repair, global privacy, alias count or queue/lens closure.'}))
