#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,sys
if sys.flags.optimize:raise RuntimeError('assertions required')
p=pathlib.Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--public',type=pathlib.Path,required=True);x=a.parse_args();H=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());r=json.loads((p/'REPORT.json').read_bytes());assert {f.name for f in p.iterdir() if f.is_file() and f.name!='MANIFEST.json'}==set(m['files'])
for n,v in m['files'].items():
 b=(p/n).read_bytes();assert len(b)==v['bytes'] and H(b)==v['sha256']
assert H((x.public/'MANIFEST.json').read_bytes())==r['public_manifest_sha256'];g=json.loads((p/'gpu-scan.json').read_bytes());assert g['forbidden_digest_total']==0 and not g['exceptions'] and not g['other_candidate_counts']
for n in ('q2332-scan.json','059-scan.json'):
 z=json.loads((p/n).read_bytes());assert z['matching_occurrences']==0 and not z['exceptions']
print('Verified bounded privacy-scan receipt and public manifest; no global privacy or ciphertext claim.')
