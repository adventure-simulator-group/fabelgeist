#!/usr/bin/env python3
"""Check receipt identity and recorded outcomes, not a repeated privacy scan."""
import pathlib,json,hashlib,sys,argparse
if sys.flags.optimize:raise RuntimeError('Assertions required')
p=pathlib.Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--public',required=True,type=pathlib.Path);a=ap.parse_args();J=lambda f:json.loads(f.read_bytes());h=lambda b:hashlib.sha256(b).hexdigest();m=J(p/'MANIFEST.json');files={f.relative_to(p).as_posix() for f in p.rglob('*') if f.is_file() and f!=p/'MANIFEST.json'};assert not any(f.is_symlink() for f in p.rglob('*')) and files==set(m['files'])
for n,x in m['files'].items():
 f=p/n;b=f.read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'] and f.stat().st_mode&0o777==x['mode']
r=J(p/'replay/RESULT.json');pr=J(p/'privacy/REPORT.json');g=J(p/'privacy/gpu.json');q=J(p/'privacy/q2332.json');z=J(p/'privacy/059.json');assert h((a.public/'MANIFEST.json').read_bytes())==r['public_manifest_sha256']==pr['public_manifest_sha256'];assert r['exit']==0 and J(p/'replay/stdout.json')['result']=='pass';assert not g['forbidden_digest_total'] and not g['other_candidate_counts'] and not g['exceptions'] and not q['matching_occurrences'] and not q['exceptions'] and not z['matching_occurrences'] and not z['exceptions'];print(json.dumps({'result':'pass','scope':'Receipt identities and recorded outcomes only; scans are not repeated and global privacy is not established.'}))
