#!/usr/bin/env python3
# Evidence-only comparison; no product or draft-builder code is executed.
import pathlib,json,hashlib,stat,argparse,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--prior',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);ap.add_argument('--delegate',type=pathlib.Path);ap.add_argument('--skip-manifest',action='store_true');args=ap.parse_args()
if (args.prior or args.anchors or args.delegate) and not args.private:raise SystemExit('Optional inputs require --private')
if (args.anchors or args.delegate) and not args.prior:raise SystemExit('Optional anchors require --prior')
a=json.loads((P/'DRAFT-v1.json').read_bytes());b=json.loads((P/'DRAFT-v2.json').read_bytes());diff=[]
def walk(x,y,path):
 if type(x)!=type(y):diff.append({'pointer':path,'old':x,'new':y});return
 if isinstance(x,dict):
  for k in sorted(x.keys()|y.keys()):
   n=path+'/'+k.replace('~','~0').replace('/','~1')
   if k not in x:diff.append({'pointer':n,'old_missing':True,'new':y[k]})
   elif k not in y:diff.append({'pointer':n,'old':x[k],'new_missing':True})
   else:walk(x[k],y[k],n)
 elif isinstance(x,list):
  if len(x)!=len(y):diff.append({'pointer':path+'/length','old':len(x),'new':len(y)})
  for i,(o,n) in enumerate(zip(x,y)):walk(o,n,path+'/'+str(i))
 elif x!=y:diff.append({'pointer':path,'old':x,'new':y})
walk(a,b,'');assert diff==json.loads((P/'STRUCTURAL-DIFF.json').read_bytes()) and len(diff)==14
side=json.loads((P/'CORRECTION.json').read_bytes());assert side['changed_json_pointers']==[x['pointer'] for x in diff] and side['predecessor_sha256']=='4b6bb7f8cb921a0715bdf120d73550a241b839502c900ec95c93cd27a5ff5570' and side['successor_sha256']=='4c2af605bc69bd669f05d41a9dc1db3eac6b945ac9927fdaee63fdb0d338b0af'
expected=[(3447,1),(3448,2),(3450,5),(3451,6)];assert len(b['partial_queue_assessments'])==len(expected) and len(a['ledger_relationships'])==len(b['ledger_relationships'])==1
for x,(i,l) in zip(b['partial_queue_assessments'],expected):
 r=x['record'];assert (r['queue_index'],r['historical_lens'],r['historical_contract_id'])==(i,l,f'OBLIGATION-ROOT-L3-EXT-0057-LENS-{l:02d}')
assert a['counts']==b['counts'] and a['repair']==b['repair']=='not started' and a['product_validation']==b['product_validation']=='not performed'
assert a['ledger_relationships'][0]['record']['repair']==b['ledger_relationships'][0]['record']['repair']=='not started' and a['ledger_relationships'][0]['record']['validation']==b['ledger_relationships'][0]['record']['validation']=='not performed'
h=json.loads((P/'HISTORICAL-READ-RECEIPT.json').read_bytes());e=json.loads((P/'E275-SELECTED-ROW.json').read_bytes());assert 'subsequent q542 full selected display and 774 combined display also truncated' in h['display_limitation'] and e['frozen_source_adoption_pending'] is True and e['fresh_personal_ranges']==[] and e['qualified_reuse_ranges']==[[1,633]]
cross=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes());assert cross['private_manifest_sha256']=='0bd32906416a3c00a133b066fa738d4578c00aca83f1db1e0f0a29c579072fb3'
for x in cross['files']:
 for k in ('private_relative','public_relative'):
  rel=pathlib.PurePosixPath(x[k]);assert not rel.is_absolute() and '..' not in rel.parts
 out=(P/x['public_relative']).read_bytes();assert len(out)==x['public_bytes'] and H(out)==x['public_sha256']
 if args.private:
  raw=(args.private/x['private_relative']).read_bytes();assert len(raw)==x['private_bytes'] and H(raw)==x['private_sha256'];pos=0;made=bytearray()
  for r in x['replacements']:
   off=r['offset'];end=off+r['length'];assert pos<=off<=end<=len(raw);made+=raw[pos:off]+r['replacement'].encode();pos=end
  made+=raw[pos:];assert bytes(made)==out
if not args.skip_manifest:
 m=json.loads((P/'MANIFEST.json').read_bytes());fs={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and not x.is_symlink()};ds={str(x.relative_to(P)) for x in P.rglob('*') if x.is_dir() and not x.is_symlink()};assert not any(x.is_symlink() for x in P.rglob('*'));assert fs==set(m['files'])|{'MANIFEST.json'} and ds==set(m['directories'])
 for n,x in m['files'].items():
  f=P/n;data=f.read_bytes();assert (len(data),H(data),stat.S_IMODE(f.stat().st_mode))==(x['bytes'],x['sha256'],x['mode'])
 for n,mode in m['directories'].items():assert stat.S_IMODE((P/n).stat().st_mode)==mode
 print('Public manifest, bytes and modes: pass')
else:print('Public manifest skipped only for preseal')
print('Redacted structural diff, four queue identities and unchanged count/repair controls: pass')
if args.private:
 assert H((args.private/'MANIFEST.json').read_bytes())==cross['private_manifest_sha256'];cmd=[sys.executable,str(args.private/'VERIFY.py')]
 if args.prior:cmd+=['--prior',str(args.prior)]
 if args.anchors:cmd+=['--anchors',str(args.anchors)]
 if args.delegate:cmd+=['--delegate',str(args.delegate)]
 subprocess.run(cmd,check=True);print('Exact private originals and crosswalk replay: pass')
else:print('Exact unredacted originals, prior source bindings and complete queues are separately held and not verified here')
print('Semantic findings and reader attention are not machine-proved; draft is unadopted.')
