# Independent review of the q10 central draft

The reviewed q10 arithmetic and selected admission chain support the draft's
conditional assessment. No source-level correction to that assessment was
found. This review covers q10 only, not q13 or either entire audit lens. It
makes no semantic closure, new unique count, repair, or validation claim.

The exact coordinator draft has SHA-256
`d78774d4c9bb446ca83d0ae2e410af71653539bff56b5dfdbe0bde91404ef6ba`.
The independently read product source is pinned to
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The q10 delegate's v2 packet and
its reads remain attributed to `/root/mhr_character`; the coordinator's views
remain attributed to `/root`. This reviewer's eight current-source windows
were separately registered and displayed under the raw-primitives lens.

## Conditional arithmetic and supported path

At `crates/adventuresim-core/src/durability.rs:196–265`, quality 1 selects
0.65. The authored buckler's fracture threshold is 100
(`content/items/catalog.yaml:1124–1188`). With stress 10,000, the adjusted
threshold is approximately 65, the overload exceeds 152, and twice that
exceeds 255. The float-to-`u8` cast saturates at 255; adding 3 then overflows
before `.min(5)`. An installed Rust reference and book snapshot support the
cast and conditional overflow semantics; that snapshot does not identify the
compiler or flags of a deployment. The conclusion is symbolic source
reasoning, with no product calculation or execution.

With overflow checks enabled this addition can fail before a `DamageEvent` is
returned. Under wrapping arithmetic the quality term is zero and the resulting
tier is 2. In the selected consumer
`crates/adventuresim-stdb-module/src/repair.rs:558–600`, item quality is
clamped and the event tier is then capped to that quality. For this quality-1
witness, both tier 2 and a tier 5 would be capped to tier 1; that witness alone
does not establish a changed stored damage bin. Transaction effects and
higher-quality witnesses remain unproved.

The local durability validator accepts the displayed buckler fields under its
selected predicates (`item_catalog_validation.rs:1148–1215`). The numeric
receipt bound is finite 0 through 10,000 (`mission.rs:9–15`,
`tactical.rs:1142–1183`). The selected receipt validation additionally
requires an authorized participant, item custody and quantity, matching
installed equipment and held/worn role; application needs a matching stored
item definition and condition (`tactical.rs:1037–1129, 1190–1223`,
`repair.rs:558–600`). These static checks do not establish a deployed catalog,
actual contact generation, the required stored state, live reachability, or
transaction and player outcomes. No build, fixture, test or probe was run.

## Historical and recovery relationships

Original 059 q10 and its original ledger finding identify the same pre-cap
addition. The historical PL13-163 canonical-alias qualification compares that
first operation and records zero new unique count. The recovered physical-p16
source is a dirty snapshot, not a clean a120 tree; its reader, the distinct
pr-working and e275 receipts, and the current delegate and coordinator retain
their own revision and reader attributions. The original zero-credit premature
read, subsequent registered reread, and EOF prose correction remain intact.
The nested historical pending-root-adoption wording is preserved rather than
promoted into a later checkpoint.

Immutable a422 ledger row 390, `REVIEW-TACTICAL-CONTACT-FIRST-ROLE-001`, is a
related but distinct first-role-retention question. It is not automatically an
alias of the overflow operation. Original and reconstructed full 059 queue
streams differ; selected q10 objects compare equal as parsed. The 6533, e275
and 95e durability file bytes match, which is single-file evidence only.

The draft binds the delegate's public manifest but does not itself enumerate
all custody corrections. When incorporating it, preserve and link the
separate correction with manifest SHA-256
`15c0150f1690cd72ab06baf25cc5d41ce141294160d29d9bb7af22f6c29f6a6f`.
The earlier public preflight failed on a transcribed ledger hash; a separate
private verifier failed on a transcribed replay-manifest hash. Each has its
own preserved correction; neither first traceback was separately captured
verbatim. The delegate's two truncated historical-record displays confer no
credit for hidden output and were followed by bounded displays.

The normalized recovered 774 catalog is not its missing pre-export original;
SOURCE004 and 73 nontext/no-positive-EOF qualifications remain. Missing
checkpoint 3821 is neither reconstructed nor supplemented with earlier
records. One local directory listing and one Rust-document navigation output
in this review were truncated; both were navigation only, and their original
emitted transcripts were not captured separately byte-for-byte. Registered
source and document windows were displayed without reported truncation.

The verifier checks the q10 draft, selected coordinator and delegate receipts,
source windows, Git object membership, 059 records and a422 row 390. It does
not prove personal attention or product behavior. The separately replayed full
delegate verifier requires its complete public and restricted packets and a
pinned Git store; this packet retains a bound subset. Restricted evidence and
Git objects are same-machine copies, not independent custody or public-only
recovery. The public privacy scan is bounded and cannot rule out every
sensitive value.
