#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='1959509e1dced395151cb0732fcace4e1cbc328edc500486ba1a1648b9cf91ce';verify_manifest(root,'MANIFEST-PRIVATE.json')
 src=proof(root,'SOURCE-GIT-PROOF.json','source-git-objects',True);older=proof(root,'SOURCE-HISTORICAL-PROOF.json','historical-source-git-objects',True);hist=proof(root,'historical-git-proof-reference.json','historical-git-objects',False);assert (len(src),len(older),len(hist))==(9,2,3)
 rev='95e63628f9d70b8dd6e6fede64334696c6995009';path='crates/adventuresim-core/src/durability.rs';digest='7e08e94102b0e097fdb309ad3f5caaf54c6d5c313979a3c5186bb671bb231afd';assert sha(src[(rev,path)])==digest
 for old in ('6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f'):assert older[(old,path)]==src[(rev,path)]
 obj=json.loads((root/'SOURCE-GIT-PROOF.json').read_bytes())['objects'];kind,commit=decode_object(root/'source-git-objects',rev,obj[rev]);assert kind=='commit' and commit.split(b'\n',1)[0]==b'tree 1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
 r1='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';r2='dac7d0055716053f245139971eb67ddfd87fa462';hp='baseline-059/queue.json';assert sha(hist[(r1,hp)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(hist[(r2,hp)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173';a10=exact_selections(hist[(r1,hp)],[10])[10][0];b10=exact_selections(hist[(r2,hp)],[10])[10][0];assert a10==b10==json.loads((root/'delegate/selected-original.json').read_bytes())==json.loads((root/'delegate/selected-reconstructed.json').read_bytes());assert a10['contract_id']=='LENS13-DURABILITY-TIER-INTERMEDIATE-OVERFLOW' and a10['lens']==13 and a10['status']=='open-granular-reconciliation'
 ledger=json.loads(src[(r1,'baseline-059/ledger.json')]);finding=ledger['discovery_findings_and_dependencies'][a10['contract_id']];assert finding==json.loads((root/'delegate/ledger-original-q10.json').read_bytes())
 cp='a4223bf23487b5872bc5efe5b272d40f859456f2';base=json.loads(src[(cp,'BASELINE-95E-20261110.json')]);rq=json.loads(src[(cp,'RECONCILIATION-059.json')]);assert rq['entries'][10]['current_reconciliation']=='unassessed';row=base['newly_assessed_ledger']['entries'][390];assert row==json.loads((root/'delegate/ledger-current-390.json').read_bytes()) and row['id']=='REVIEW-TACTICAL-CONTACT-FIRST-ROLE-001'
 draft=(root/'coordinator-DRAFT.json').read_bytes();assert sha(draft)=='d78774d4c9bb446ca83d0ae2e410af71653539bff56b5dfdbe0bde91404ef6ba';d=json.loads(draft);q=d['partial_queue_assessments'][0];assert d['source_revision']==rev and d['parent_checkpoint']==cp and q['queue_index']==10 and q['historical_lens']==13 and q['historical_contract_id']==a10['contract_id'];assert d['ledger_relationships'][0]['id']=='relationship-durability-tier-intermediate-95e' and d['counts']['accepted_unique_defect_increment']==d['counts']['semantic_queue_closures']==d['counts']['lens_completions']==0
 coord=root/'coordinator';
 for file,key in [('REGISTRATION.json','central_registration_sha256'),('SUPPLEMENT-REGISTRATION.json','central_supplement_registration_sha256'),('READ-RECEIPT.json','central_read_receipt_sha256')]:assert sha((coord/file).read_bytes())==d[key]
 receipt=json.loads((coord/'READ-RECEIPT.json').read_bytes());count=0
 for cap,part,folder in [('CAPTURE.json','original_views','views'),('SUPPLEMENT-CAPTURE.json','supplement_views','supplement-views')]:
  rows=[x for x in json.loads((coord/cap).read_bytes())['rows'] if x['queue']==10];assert rows==[x for x in receipt[part] if x['queue']==10]
  for x in rows:
   assert x['lens']==13;raw=src[(rev,x['path'])];assert sha(raw)==x['object_sha256'];lines=raw.decode().splitlines(keepends=True);lo,hi=x['range'];data=''.join(f'{i:5d} '+lines[i-1] for i in range(lo,hi+1)).encode();assert sha(data)==x['view_sha256'] and data==(coord/folder/x['view']).read_bytes();count+=1
 assert count==9
 for item in json.loads((root/'SOURCE-IDENTITIES-002.json').read_bytes()):
  assert src[(rev,item['path'])]==(root/item['capture']).read_bytes()
  for x in item['views']:window(root,item['capture'],x['capture'],x['lo'],x['hi'])
 for raw,out,lo,hi in [('rust-reference-operators.html','rust-reference-overflow.txt',332,348),('rust-reference-operators.html','rust-reference-cast.txt',1908,1918),('rust-book-data-types.html','rust-book-overflow.txt',280,306)]:window(root,raw,out,lo,hi)
 de=root/'delegate';assert sha((de/'MANIFEST.json').read_bytes())=='2d13f6380ece1a5d580bb05056d79bf0c8c7e35d9173cdff1203075686042cd6'==q['delegate_public_manifest_sha256'];m=json.loads((de/'MANIFEST.json').read_bytes())
 for name in ['REPORT.json','REPORT.md','HISTORY-SUMMARY.json','READ-RECEIPT.json','CORRECTION.json','HISTORY-TRUNCATION.json','HISTORY-TRUNCATION-2.json']:
  data=(de/name).read_bytes();assert sha(data)==m['files'][name]['sha256'] and len(data)==m['files'][name]['bytes']
 assert sha((de/'PRIVATE-MANIFEST.json').read_bytes())=='7c7ec9f6e0dddf6054e1390d372097b125bce298790370190b0c26eb68c02e28';pm=json.loads((de/'PRIVATE-MANIFEST.json').read_bytes())
 for n in ['0.json','2.json','7.json','8.json','supplement-0.json','supplement-1.json','supplement-2.json']:
  data=(root/'history'/n).read_bytes();assert sha(data)==pm['files']['historical/'+n]['sha256'] and len(data)==pm['files']['historical/'+n]['bytes']
 assert sha((de/'custody-MANIFEST.json').read_bytes())=='15c0150f1690cd72ab06baf25cc5d41ce141294160d29d9bb7af22f6c29f6a6f';cm=json.loads((de/'custody-MANIFEST.json').read_bytes());
 for name in ['CORRECTION.json','VERIFY.py']:assert sha((de/('custody-'+name)).read_bytes())==cm['files'][name]['sha256']
 c=json.loads((de/'custody-CORRECTION.json').read_bytes());assert c['private_manifest_sha256']==sha((de/'PRIVATE-MANIFEST.json').read_bytes()) and c['recorded_transcription']!=c['corrected_replay_whole_manifest_sha256']
 alias=json.loads((root/'history/7.json').read_bytes());exception=json.loads((root/'history/supplement-1.json').read_bytes());eof=json.loads((root/'history/supplement-2.json').read_bytes());assert alias['canonical_id']==a10['contract_id'] and alias['exact_function']=='damage_from_impact' and alias['accepted_unique_count_change']==0;assert exception['unregistered_display_credit']==0 and eof['actual_eof']==102 and eof['nonexistent_tail_credit']==0
 runs=json.loads((root/'DELEGATE-REPLAY.json').read_bytes());assert len(runs)==2 and all(x['status']==0 for x in runs)
 print('q10 draft, current/historical Git bindings, a422 ledger and original/reconstructed 059: PASS')
 print('independent windows, nine coordinator views, delegate historical subset and custody correction: PASS')
 print('Scope: source/evidence identities only. Full delegate replay needs its separate intact public and restricted packets and Git store; no product behavior, closure, independent custody or checkpoint 3821 claim.')
if __name__=='__main__':main()
