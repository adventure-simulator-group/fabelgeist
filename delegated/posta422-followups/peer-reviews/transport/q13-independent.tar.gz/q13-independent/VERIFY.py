#!/usr/bin/env python3
"""Read-only identity replay for q13; no product execution."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
if sys.flags.optimize:raise RuntimeError('Assertions required')
p=pathlib.Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--repo',type=pathlib.Path);ap.add_argument('--restricted',type=pathlib.Path);a=ap.parse_args();J=lambda f:json.loads(f.read_bytes());h=lambda b:hashlib.sha256(b).hexdigest();m=J(p/'MANIFEST.json');o=J(p/'SOURCE-OBJECTS.json');rr=J(p/'READ-RECEIPT.json');draft=J(p/'DRAFT-Q13.json');hist=J(p/'HISTORY-SUMMARY.json');rel=J(p/'RELATED-RECORDS.json');central=J(p/'CENTRAL-Q13.json')
assert not any(x.is_symlink() for x in p.rglob('*'));files={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'};assert files==set(m['files'])
for n,x in m['files'].items():
 f=p/n;b=f.read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'] and f.stat().st_mode&0o777==x['mode']
assert draft['partial_queue_assessment']['queue_index']==13 and draft['partial_queue_assessment']['historical_lens']==12 and draft['source_revision']==o['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and o['source_tree']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f';assert draft['parent_checkpoint']=='a4223bf23487b5872bc5efe5b272d40f859456f2'
dm=J(p/'DELEGATE-MANIFEST.json');assert h((p/'DELEGATE-MANIFEST.json').read_bytes())==draft['partial_queue_assessment']['delegate_public_manifest_sha256'] and h((p/'DELEGATE-REPORT.md').read_bytes())==dm['files']['REPORT.md']['sha256'];assert len(central['views'])==14 and all(x['queue']==13 and x['lens']==12 for x in central['views'])
idx={}
for x in o['objects']:
 b=(p/x['object']).read_bytes();assert h(b)==x['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof'];assert hashlib.sha1(('blob %d\0'%len(b)).encode()+b).hexdigest()==x['git_blob'];idx[x['id']]=x
for x in rr['views']:
 row=idx[x['source_id']];assert x['path']==row['path'] and x['revision']==row['revision'] and x['sha256']==row['sha256'] and x['git_blob']==row['git_blob'];lo,hi=x['lines'];assert 1<=lo<=hi<=row['eof'];s=(p/row['object']).read_text().splitlines();b=('\n'.join(f'{i:4d} {s[i-1]}' for i in range(lo,hi+1))+'\n').encode();assert b==(p/x['view_file']).read_bytes() and h(b)==x['view_sha256'];assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['sha256']==x['sha256'] and y['lines']==x['lines'] for y in J(p/x['registration'])['views'])
assert len(rr['views'])==30 and hist['historical_contract_id']=='LENS12-PROJECTILE-ID-SUBSTRING' and hist['lens']==12 and not hist['queue_row_records_source_identity'] and not hist['queue_row_records_historical_receipt'] and hist['selected_queue_and_ledger_equal_as_parsed'] and not hist['whole_queue_streams_equal'] and not hist['whole_ledger_streams_equal'];assert rel['historical_queue']['13']['current_reconciliation']=='unassessed'
if a.repo:
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');g=lambda *v:subprocess.check_output(['git','-C',str(a.repo),*v],env=env);assert g('rev-parse',o['source_revision']+'^{tree}').decode().strip()==o['source_tree']
 for x in o['objects']:assert g('rev-parse',x['revision']+':'+x['path']).decode().strip()==x['git_blob']
 historical=J(p/'HISTORICAL-GIT-REGISTRATION.json');assert g('rev-parse',historical['revision']+':'+historical['path']).decode().strip()==hist['historical_transport']['git_blob']
 for x in hist['parent_a422']:assert g('rev-parse',draft['parent_checkpoint']+':'+x['path']).decode().strip()==x['git_blob'] and h(g('show',draft['parent_checkpoint']+':'+x['path']))==x['sha256']
 for x in J(p/'SOURCE-CAPTURE.json'):
  if x['exit']!=0:
   z=subprocess.run(['git','-C',str(a.repo),'cat-file','-e',x['revision']+':'+x['path']],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=env);assert z.returncode!=0
if a.restricted:
 z=a.restricted;D=J(z/'DRAFT.json');assert h((z/'DRAFT.json').read_bytes())==draft['full_draft_sha256'] and D['partial_queue_assessments'][1]==draft['partial_queue_assessment'] and D['ledger_relationships'][1]==draft['ledger_relationship'];assert h((z/'HISTORIC-RECEIPT.json').read_bytes())==hist['receipt_observed_sha256'] and J(z/'HISTORIC-RECEIPT.json')['sources'][4]==hist['receipt_source']
 for x in hist['whole_stream_identities']:assert h((z/x['file']).read_bytes())==x['sha256'] and (z/x['file']).stat().st_size==x['bytes']
 qo=J(z/'FULL-QUEUE-ORIGINAL.json');qr=J(z/'FULL-QUEUE-RECONSTRUCTED.json');lo=J(z/'FULL-LEDGER-ORIGINAL.json');lr=J(z/'FULL-LEDGER-RECONSTRUCTED.json');key='LENS12-PROJECTILE-ID-SUBSTRING';assert qo['entries'][13]==qr['entries'][13]==J(p/'HISTORIC-Q13-ORIGINAL.json') and lo['discovery_findings_and_dependencies'][key]==lr['discovery_findings_and_dependencies'][key]==J(p/'HISTORIC-LEDGER.json')
 A=J(z/'CENTRAL-INPUT-REGISTRATION.json');B=J(z/'CENTRAL-INPUT-SUPPLEMENT-REGISTRATION.json');C=J(z/'CENTRAL-INPUT-READ-RECEIPT.json');assert [x for x in A['registrations'] if x['queue_index']==13]==central['registration'] and [x for x in B['registrations'] if x['queue_index']==13]==central['supplement_registration'] and [x for k in ['original_views','supplement_views'] for x in C[k] if x['queue']==13]==central['views']
 for x in J(p/'CENTRAL-CAPTURE.json'):assert h((z/x['file']).read_bytes())==x['sha256']
print(json.dumps({'result':'pass','registered_personal_views':len(rr['views']),'pinned_source_objects':len(o['objects']),'git_anchors_checked':bool(a.repo),'restricted_inputs_checked':bool(a.restricted),'scope':'Evidence identity, recorded displays and selected history only. Does not prove reader attention, source reasoning, reachability, product behavior, global privacy, alias counts or audit closure.'}))
