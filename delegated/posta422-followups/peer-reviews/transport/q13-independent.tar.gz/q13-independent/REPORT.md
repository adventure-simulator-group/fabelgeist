# Independent review of q13 projectile classification

The q13 portion of the fixed coordinator draft is supported by the independent
source windows in this packet. The selected ranged weapon’s open item ID is
checked for the case-sensitive substring `arquebus` to choose Ball or
Arrowhead; the two displayed stock arquebus IDs match. No wrong stock outcome,
supported alternative, runtime event, alias or unique count is established.

A ranged battle log can carry the selected kind. The inspected random and
mission producers use item-backed party combatants as allies and construct
enemies separately. Generic allied injury commitment accepts a logged kind, but
this review does not establish that the particular item-derived kind reaches
an allied retained projectile. The selected `post_combat_body` mapping records
only whether a projectile was present. Add the source citations listed in
`REPORT.json`, and name that selected mapping instead of all corpse projection.

Exact `arrow` count and consumption are separate operations. The shown count
excludes fireplace-rooted or lookup-error rows while the displayed consumption
query has no such location predicate. A supported rooted row in that index, its
iteration order, intended custody behavior and any resulting effect remain
open; this is not an alias or counted defect.

Original and reconstructed whole 059 queue and ledger streams differ; their
selected q13 records agree. The original queue row names no reader or source;
the ledger names a separate historical receipt without a digest. Historical,
delegate and independent current reads retain their own revision and reviewer.
This review does not assess q10, close q13, claim checkpoint3821, or run product
code, builds, tests, fixtures, macros, probes or repairs.
