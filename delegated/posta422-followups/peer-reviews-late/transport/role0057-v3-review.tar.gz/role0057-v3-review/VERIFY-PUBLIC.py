#!/usr/bin/env python3
# Evidence-only comparison; no product or correction-builder code is executed.
import pathlib,json,hashlib,stat,argparse,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--previous',type=pathlib.Path);ap.add_argument('--earlier',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);ap.add_argument('--delegate',type=pathlib.Path);ap.add_argument('--skip-manifest',action='store_true');args=ap.parse_args()
if (args.previous or args.earlier or args.anchors or args.delegate) and not args.private:raise SystemExit('Optional inputs require --private')
if (args.earlier or args.anchors or args.delegate) and not args.previous:raise SystemExit('Further anchors require --previous')
if (args.anchors or args.delegate) and not args.earlier:raise SystemExit('Historical anchors require --earlier')
a=json.loads((P/'DRAFT-v2.json').read_bytes());b=json.loads((P/'DRAFT-v3.json').read_bytes());diff=[]
def walk(x,y,path):
 if type(x)!=type(y):diff.append({'pointer':path,'old':x,'new':y});return
 if isinstance(x,dict):
  for k in sorted(x.keys()|y.keys()):
   n=path+'/'+k.replace('~','~0').replace('/','~1')
   if k not in x:diff.append({'pointer':n,'old_missing':True,'new':y[k]})
   elif k not in y:diff.append({'pointer':n,'old':x[k],'new_missing':True})
   else:walk(x[k],y[k],n)
 elif isinstance(x,list):
  if len(x)!=len(y):diff.append({'pointer':path+'/length','old':len(x),'new':len(y)})
  for i,(o,n) in enumerate(zip(x,y)):walk(o,n,path+'/'+str(i))
 elif x!=y:diff.append({'pointer':path,'old':x,'new':y})
walk(a,b,'');assert diff==json.loads((P/'STRUCTURAL-DIFF.json').read_bytes()) and len(diff)==8
side=json.loads((P/'CORRECTION.json').read_bytes());assert side['changed_json_pointers']==[x['pointer'] for x in diff] and side['predecessor_sha256']=='4c2af605bc69bd669f05d41a9dc1db3eac6b945ac9927fdaee63fdb0d338b0af' and side['successor_sha256']=='7526a7280d08ebddcca91471961dc1604e627b655f3cce8526524e7c5d277bab'
old='later truncated q542 and older-774 combined displays';new='a subsequent truncated q542 full-selected display and a separate truncated older-774 combined display';expected=[(3447,1),(3448,2),(3450,5),(3451,6)];assert len(a['partial_queue_assessments'])==len(b['partial_queue_assessments'])==4
for before,after,(i,l) in zip(a['partial_queue_assessments'],b['partial_queue_assessments'],expected):
 x=before['record'];y=after['record'];assert set(x)==set(y) and all(x[k]==y[k] for k in x if k!='history') and x['history'].count(old)==1 and y['history']==x['history'].replace(old,new);assert (y['queue_index'],y['historical_lens'],y['historical_contract_id'])==(i,l,f'OBLIGATION-ROOT-L3-EXT-0057-LENS-{l:02d}')
assert a['ledger_relationships']==b['ledger_relationships'] and len(b['ledger_relationships'])==1 and a['counts']==b['counts'] and a['repair']==b['repair']=='not started' and a['product_validation']==b['product_validation']=='not performed'
vc=json.loads((P/'VERIFY-CORRECTION.json').read_bytes());assert vc['predecessor_sha256']==H((P/'COORDINATOR-VERIFY.py').read_bytes()) and vc['successor_sha256']==H((P/'VERIFY-v2.py').read_bytes())
ac=json.loads((P/'REVIEW-007-A422-CAPTURE.json').read_bytes());assert ac['revision']=='a4223bf23487b5872bc5efe5b272d40f859456f2' and ac['tree']=='86ca312a55790c3cfcc315c09d6f9c62f5dc39ff' and [(x['index'],x['lens'],x['status']) for x in ac['rows']]==[(i,l,'unassessed') for i,l in expected]
cross=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes());assert cross['private_manifest_sha256']=='6906ed6ae235b07ffc596097217819f88eb92c7d1275584f45db42bc71b03f38'
for x in cross['files']:
 for k in ('private_relative','public_relative'):
  rel=pathlib.PurePosixPath(x[k]);assert not rel.is_absolute() and '..' not in rel.parts
 out=(P/x['public_relative']).read_bytes();assert len(out)==x['public_bytes'] and H(out)==x['public_sha256']
 if args.private:
  raw=(args.private/x['private_relative']).read_bytes();assert len(raw)==x['private_bytes'] and H(raw)==x['private_sha256'];pos=0;made=bytearray()
  for r in x['replacements']:
   off=r['offset'];end=off+r['length'];assert pos<=off<=end<=len(raw);made+=raw[pos:off]+r['replacement'].encode();pos=end
  made+=raw[pos:];assert bytes(made)==out
if not args.skip_manifest:
 m=json.loads((P/'MANIFEST.json').read_bytes());fs={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and not x.is_symlink()};ds={str(x.relative_to(P)) for x in P.rglob('*') if x.is_dir() and not x.is_symlink()};assert not any(x.is_symlink() for x in P.rglob('*'));assert fs==set(m['files'])|{'MANIFEST.json'} and ds==set(m['directories'])
 for n,x in m['files'].items():
  f=P/n;data=f.read_bytes();assert (len(data),H(data),stat.S_IMODE(f.stat().st_mode))==(x['bytes'],x['sha256'],x['mode'])
 for n,mode in m['directories'].items():assert stat.S_IMODE((P/n).stat().st_mode)==mode
 print('Public manifest, bytes and modes: pass')
else:print('Public manifest skipped only for preseal')
print('Redacted diff, four separate wording fixes, queue/count controls and verifier version identities: pass')
if args.private:
 assert H((args.private/'MANIFEST.json').read_bytes())==cross['private_manifest_sha256'];cmd=[sys.executable,str(args.private/'VERIFY-REVIEW.py')]
 if args.previous:cmd+=['--previous',str(args.previous)]
 if args.earlier:cmd+=['--earlier',str(args.earlier)]
 if args.anchors:cmd+=['--anchors',str(args.anchors)]
 if args.delegate:cmd+=['--delegate',str(args.delegate)]
 subprocess.run(cmd,check=True);print('Exact private originals, a422 proof and byte crosswalk replay: pass')
else:print('Exact unredacted originals, a422 objects and earlier historical evidence are separately held and not verified here')
print('Semantic findings and reader attention are not machine-proved; draft is unadopted.')
