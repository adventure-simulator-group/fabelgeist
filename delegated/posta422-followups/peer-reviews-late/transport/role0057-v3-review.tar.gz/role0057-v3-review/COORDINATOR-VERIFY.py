#!/usr/bin/env python3
"""Bind role0057 v3 correction and check queue identities, not prose semantics."""
from pathlib import Path
import json,hashlib,argparse,sys
if sys.flags.optimize:raise RuntimeError('Assertions required')
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--publication',type=Path,required=True);ap.add_argument('--v2',type=Path,required=True);ap.add_argument('--review-v1',type=Path,required=True);ap.add_argument('--review-v2',type=Path,required=True);a=ap.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();old=a.v2.read_bytes();new=(p/'DRAFT-v3.json').read_bytes();x=json.loads(old);y=json.loads(new);c=json.loads((p/'CORRECTION.json').read_bytes());assert h(old)==c['predecessor_sha256']==y['prior_successor_sha256'] and h(new)==c['successor_sha256'] and h((a.review_v1/'MANIFEST.json').read_bytes())=='0bf5b237c83556b0675d059c57104fef5e3c9cf70484df5e5d40fe46dc2f8d05' and h((a.review_v2/'MANIFEST.json').read_bytes())==c['independent_v2_review_manifest_sha256']
assert set(y)-set(x)=={'prior_successor_sha256','v3_created_utc'}
for k in x:
 if k not in ('partial_queue_assessments','review_qualification','timestamp_qualification'):assert x[k]==y[k]
needle='later truncated q542 and older-774 combined displays';replacement='a subsequent truncated q542 full-selected display and a separate truncated older-774 combined display'
for before,after in zip(x['partial_queue_assessments'],y['partial_queue_assessments']):
 b=before['record'];d=after['record'];assert set(b)==set(d) and all(b[k]==d[k] for k in b if k!='history') and b['history'].count(needle)==1 and d['history']==b['history'].replace(needle,replacement)
assert len(y['partial_queue_assessments'])==4 and y['timestamp_qualification']==x['timestamp_qualification']+' The v2 corrected_created_utc is retained as v2 metadata, not the creation time of v3.'
q=json.loads((a.publication/'RECONCILIATION-059.json').read_bytes())['entries'];expected=[(3447,1),(3448,2),(3450,5),(3451,6)]
for item,(i,lens) in zip(y['partial_queue_assessments'],expected):
 r=item['record'];assert r['queue_index']==i and r['historical_lens']==lens and r['historical_contract_id']==q[i]['contract_id'] and q[i]['historical_lens']==lens and q[i]['current_reconciliation']=='unassessed'
assert len(y['ledger_relationships'])==1 and y['counts']==x['counts'] and y['repair']=='not started' and y['product_validation']=='not performed'
print('Verified exact role0057 v2/v3 structural correction, peer manifest identities and four current queue IDs/lenses; factual prose, historical anchors and semantic correctness remain separate.')
