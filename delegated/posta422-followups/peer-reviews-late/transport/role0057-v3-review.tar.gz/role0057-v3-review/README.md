# Independent check of role0057 v3

Read ASSESSMENT-v2.md; ASSESSMENT.md is its preserved predecessor and the
correction file records the reason for the successor. These are path-safe
reconstructions. Public replay checks the structural comparison and recorded
object identities; exact unredacted drafts, the a422 commit/tree/reconciliation
and earlier source/historical evidence are separately held.

Run `python3 VERIFY-PUBLIC.py`; add `--private DIR` for exact original and a422
replay, optionally `--previous DIR --earlier DIR --anchors DIR --delegate DIR`
for the full separately held review chain. The offset crosswalk cannot recover
removed private values without the originals. Privacy scans are finite, and
reader displays are attestations. The draft remains unadopted; no product
execution, repair, build, test, runtime probe or checkpoint 3821 recovery is
claimed.
