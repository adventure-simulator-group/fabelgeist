#!/usr/bin/env python3
"""Read-only q13 successor review identity and range replay."""
import pathlib,json,hashlib,re,sys,argparse
if sys.flags.optimize:raise RuntimeError('Assertions required')
p=pathlib.Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--restricted',type=pathlib.Path);a=ap.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();J=lambda f:json.loads(f.read_bytes());m=J(p/'MANIFEST.json');assert not any(x.is_symlink() for x in p.rglob('*'));files={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'};assert files==set(m['files'])
for n,x in m['files'].items():
 f=p/n;b=f.read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'] and f.stat().st_mode&0o777==x['mode']
prior=p/'prior';assert h((prior/'MANIFEST.json').read_bytes())=='39876fffbc93003e31f3195da96286b9570b324f1fa6cf1de520e698336bce1c';pm=J(prior/'MANIFEST.json');pfiles={x.relative_to(prior).as_posix() for x in prior.rglob('*') if x.is_file() and x!=prior/'MANIFEST.json'};assert pfiles==set(pm['files'])
for n,x in pm['files'].items():
 f=prior/n;b=f.read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'] and f.stat().st_mode&0o777==x['mode']
rows=J(p/'WINDOW-BYTECHECK.json');registration=J(p/'WINDOW-BYTECHECK-REGISTRATION.json')['items'];own=J(prior/'READ-RECEIPT.json')['views'];assert len(rows)==len(registration)==7
for row,x in zip(rows,registration):
 assert row['view']==x['raw']+'-'+str(x['range'][0])+'-'+str(x['range'][1])+'.txt' and row['delegate_range']==x['range'] and row['cited_range']==x['cited'];v=(p/'delegate-views'/row['view']).read_bytes();assert h(v)==row['view_sha256'];source=(prior/'objects'/row['source_sha256']).read_bytes();assert h(source)==row['source_sha256'];lo,hi=x['range'];lines=source.decode().splitlines();actual=v.decode().splitlines();assert len(actual)==hi-lo+1
 for j,line in enumerate(actual,lo):
  t=re.match(r'^\s*(\d+) (.*)$',line);assert t and int(t.group(1))==j and t.group(2)==lines[j-1]
 reg=J(p/'delegate-registrations'/x['registration']);assert any(isinstance(t,dict) and t.get('file')==x['raw'] and x['range'] in t.get('ranges',[]) for k in ('source_windows','windows','display_windows') for t in reg.get(k,[]));covered=set()
 for t in own:
  if t['source_id']==x['own_id']:covered.update(range(t['lines'][0],t['lines'][1]+1))
 assert set(range(x['cited'][0],x['cited'][1]+1)).issubset(covered)
c=J(p/'CORRECTION.json');check=J(p/'CHECK.json');ex=J(p/'Q13-DRAFT-EXCERPTS.json');assert check['changed_pointers']==c['changed_json_pointers'] and c['predecessor_sha256']==ex['predecessor_sha256']==check['predecessor_sha256'] and c['successor_sha256']==ex['successor_sha256']==check['successor_sha256'];assert ex['v1_ledger_relationship']==ex['v2_ledger_relationship']
if a.restricted:
 z=a.restricted;v1=J(z/'V1.json');v2=J(z/'V2.json');assert h((z/'V1.json').read_bytes())==ex['predecessor_sha256'] and h((z/'V2.json').read_bytes())==ex['successor_sha256'];assert v1['partial_queue_assessments'][1]==ex['v1_assessment'] and v2['partial_queue_assessments'][1]==ex['v2_assessment'];assert v1['ledger_relationships'][1]==ex['v1_ledger_relationship'] and v2['ledger_relationships'][1]==ex['v2_ledger_relationship']
 def esc(x):return str(x).replace('~','~0').replace('/','~1')
 def diff(x,y,path=''):
  if isinstance(x,dict) and isinstance(y,dict):
   return sum(([path+'/'+esc(k)] if k not in x or k not in y else diff(x[k],y[k],path+'/'+esc(k)) for k in sorted(set(x)|set(y))),[])
  if isinstance(x,list) and isinstance(y,list) and len(x)==len(y):return sum((diff(t,u,path+'/'+str(i)) for i,(t,u) in enumerate(zip(x,y))),[])
  return [] if x==y else [path]
 assert diff(v1,v2)==c['changed_json_pointers'] and v1['counts']==v2['counts'] and v1['repair']==v2['repair'] and v1['product_validation']==v2['product_validation']
print(json.dumps({'result':'pass','delegate_windows_checked':len(rows),'restricted_draft_checked':bool(a.restricted),'scope':'Evidence identities, recorded windows and q13 draft structure only; no proof of personal attention, runtime behavior, global privacy, aliases, counts or closure.'}))
