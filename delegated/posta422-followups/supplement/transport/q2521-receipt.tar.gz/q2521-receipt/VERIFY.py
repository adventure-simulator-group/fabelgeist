#!/usr/bin/env python3
"""Read-only check of q2521 evidence receipt identities, not a repeated scan."""
import argparse,pathlib,json,hashlib,sys
if sys.flags.optimize:raise RuntimeError('Assertions required')
p=pathlib.Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--public',type=pathlib.Path,required=True);a=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();J=lambda q:json.loads(q.read_bytes());m=J(p/'MANIFEST.json');files={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'};assert not any(x.is_symlink() for x in p.rglob('*')) and files==set(m['files'])
for n,v in m['files'].items():
 f=p/n;b=f.read_bytes();assert len(b)==v['bytes'] and h(b)==v['sha256'] and f.stat().st_mode&0o777==v['mode']
r=J(p/'replay/RESULT.json');pr=J(p/'privacy/REPORT.json');g=J(p/'privacy/gpu.json');q=J(p/'privacy/q2332.json');z=J(p/'privacy/059.json');assert h((a.public/'MANIFEST.json').read_bytes())==r['public_manifest_sha256']==pr['public_manifest_sha256'];assert r['exit']==0 and J(p/'replay/stdout.json')['result']=='pass';assert not g['forbidden_digest_total'] and not g['other_candidate_counts'] and not g['exceptions'] and not q['matching_occurrences'] and not q['exceptions'] and not z['matching_occurrences'] and not z['exceptions'];print(json.dumps({'result':'pass','scope':'Receipt identity and recorded outcomes only. This does not independently repeat scans, validate source interpretation or establish global privacy.'}))
