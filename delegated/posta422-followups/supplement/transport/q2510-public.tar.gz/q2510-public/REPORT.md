# q2510: personality-axis invariant operations

This is a bounded, independently read Lens 4 source assessment for the
historical q2510 obligation. It does not close the queue entry, identify a new
unique defect, modify the ledger, or establish behavior at runtime.

## Scope and provenance

Original 059 queue entry 2510 is `EXTENSION-L4-ROOT-L2-EXT-0056`, with status
`pending-independent-lens-qualification` and no recorded Lens 4 ranges. The
f2ec reconciliation marks it `unassessed`. Its original source is
`crates/adventuresim-core/src/social.rs`, revision
`6533e444fa37552927070cc8d8190907fd3b413e`, lines 1–329 of 1,909. The
original and reconstructed 059 streams differ as whole files; their selected
q2510 and related records compare equal as parsed values.

The full social source file is byte-identical at 6533, historical e275, and
pinned 95e, SHA-256
`bb53725a73f48ae6fbd9f4ff3e2e744aaaea403fa2fd0a9381c6766ce0ad1b6d`.
This is single-file equality, not tree equality or transferred reading credit.
The reviewer independently registered and displayed 6533 and 95e lines 1–329,
then registered and displayed the support windows cited below. The e275 body
was captured for identity, not separately credited as a personal display.

The old registration and Lens 2 receipt name Camera as the inherited supplier
and separately report Root's reinspection. The qualified selection is 1–329;
its underlying supplier metadata reports a 1–1,909 Lens 2 read. A recovered
same-machine copy matches the recorded metadata hash and row 264 matches the
receipt; the initially attempted f82 Git pathname was unavailable. These
records do not grant anyone new Lens 4 credit. The selected 95e support reads
below do not make the historical complement 330–1,909 a q2510 assigned read.

## Source findings

* In `social.rs:162–328`, `PersonalityAxis` is a closed enum. Its legal
  value-code slices contain three or four axis-local codes. `value_label`
  returns `None` for other `i8` values; `is_neutral_code` is a comparison,
  not an admission check. These axis methods perform table selection rather
  than mutation or arithmetic on the stored code.
* The connected `social.rs:999–1040` public `diagnosed_axis` takes a raw
  `i8` and checks membership only with `debug_assert!`. If debug assertions
  are disabled, a directly supplied illegal code can take the correct branch
  and be returned: for example, Nerve with value -1 and finite zero insight,
  deception, and roll. This is a representable API input, not an established
  supported gameplay path. The relevant policy question is whether this API
  should require a legal axis/code pair at admission or document a narrower
  caller obligation. No repair or unique finding is decided here.
* For a legal truth and finite float inputs, the selected legal-code slices
  have at least three values, filtering the truth leaves at least two, and the
  clamped chance stays between 0.05 and 0.95. The displayed failed-branch
  calculation therefore has a nonzero divisor and a nonempty alternatives
  array; its final index is capped. Inputs are not explicitly checked for
  finiteness in this function, and the policy and reach of non-finite values
  remain open. This is source reasoning, not a numerical or runtime probe.
* The selected `adventuresim-stdb-module/src/social.rs:2327–2411` producer
  maps each displayed typed personality variant to a code legal for that
  axis. Lines 2857–2875 pass this truth into `diagnosed_axis`; lines 2481–2513
  reject an illegal perceived code before a belief write. The table at
  1303–1317 stores a raw `i8` next to its axis; the view at 1352–1364 filters
  illegal values. This supports only the displayed path, not every producer,
  direct caller, storage state, feature configuration, or native boundary.
  The web consumer at `templates/settlement/social.rs:118–124` substitutes an
  uncertain label when the axis/value pair has no label.
* A separate calculation appears within the assigned range at
  `social.rs:44–107`: `resolve_permission_petition` rejects non-finite float
  inputs, clamps the specified score terms, converts bounded `i16` reputation,
  and compares the resulting finite score to finite difficulty. It has no
  mutation. The selected `adventuresim-stdb-module/src/corpse.rs:1690–1747`
  supplies one caller and records its Boolean result. Whether the current
  clamps and difficulty/reputation ranges express the intended policy remains
  open; other callers and admission chains were not exhausted.

## Relationships and limits

Original 059 q541 and f2ec ledger row 843 concern a separately attributed
Lens 12 axis-to-slug-to-hint operation; they are related by axis ownership,
not established aliases of the conditional operation above. Original q2508,
q2509, q2511, and q2512 are independent other-lens obligations for the same
registered source scope. A bounded search of the original queue and f2ec
ledger for the specified diagnosis, belief, and petition names returned no
matches; this does not establish global alias absence.

An initial oversized related-record display was truncated; the exact selected
JSON was saved before display and a subsequent bounded summary was read. The
initial emitted transcript was not captured separately byte-for-byte. Four
initial searches failed because the working checkout lacked the pinned Git
object; their outputs and the successful registered retry are retained. The
failed f82 metadata locator is also retained. The verifier checks registered
windows and immutable evidence identities; it cannot prove human attention,
semantic equivalence, or product behavior.

The recovered 774 catalog remains normalized; its pre-export originals are
missing. SOURCE004 and the 73 nontext/no-positive-EOF qualifications remain.
No checkpoint 3821 state is reconstructed or promoted. This public packet
requires the separately preserved restricted originals and Git proofs for
full replay. Those copies are same-machine custody, not independent public
recovery. The bounded privacy scan is a candidate scan, not an assurance that
all sensitive data is absent.
