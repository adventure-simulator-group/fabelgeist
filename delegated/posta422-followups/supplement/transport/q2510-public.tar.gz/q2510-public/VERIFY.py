#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent
 verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();assert sha((root/'MANIFEST-PRIVATE.json').read_bytes())=='4767239cd71c2d14c63e0d172276e933c9d7df3824b9d96ff8ee5e1dd23eb7ef';verify_manifest(root,'MANIFEST-PRIVATE.json')
 src=proof(root,'SOURCE-GIT-PROOF.json','source-git-objects',True);cp=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);hist=proof(root,'historical-git-proof-reference.json','historical-git-objects',False)
 assert (len(src),len(cp),len(hist))==(6,2,3)
 revs=['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','95e63628f9d70b8dd6e6fede64334696c6995009'];path='crates/adventuresim-core/src/social.rs';expected='bb53725a73f48ae6fbd9f4ff3e2e744aaaea403fa2fd0a9381c6766ce0ad1b6d'
 assert all(src[(r,path)]==src[(revs[0],path)] and sha(src[(r,path)])==expected for r in revs);assert len(src[(revs[0],path)].decode().splitlines())==1909
 objmeta=json.loads((root/'SOURCE-GIT-PROOF.json').read_bytes())['objects'];kind,commit=decode_object(root/'source-git-objects',revs[2],objmeta[revs[2]]);assert kind=='commit' and commit.split(b'\n',1)[0]==b'tree 1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
 old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';rec='dac7d0055716053f245139971eb67ddfd87fa462';hpath='baseline-059/queue.json';indices=[2510,541,1891,1892,1895,1896,2508,2509,2511,2512]
 assert sha(hist[(old,hpath)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert sha(hist[(rec,hpath)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 s=exact_selections(hist[(old,hpath)],indices);t=exact_selections(hist[(rec,hpath)],indices);assert all(s[i][0]==t[i][0] for i in indices)
 for label,sel in [('original',s),('reconstructed',t)]:assert (root/(label+'-q2510-exact.json')).read_bytes()==sel[2510][1]
 q=s[2510][0];x=q['exact_source_identities_and_assessed_ranges'][0];assert q['contract_id']=='EXTENSION-L4-ROOT-L2-EXT-0056' and q['lens']==4 and q['status']=='pending-independent-lens-qualification' and q['new_source_or_original_or_unique_credit']==0;assert x['revision']==revs[0] and x['required_ranges']==[[1,329]] and x['this_lens_assessed_ranges']==[]
 related=json.loads((root/'RELATED-SELECTED-004.json').read_bytes())
 for i in indices[1:]:assert related['original'][str(i)]==s[i][0] and related['reconstructed'][str(i)]==t[i][0]
 f='f2ec8cbad7becbcc9a8e9da22ba512f52975768f';base=cp[(f,'BASELINE-95E-20261110.json')];rq=cp[(f,'RECONCILIATION-059.json')];assert sha(base)=='03139868163e3fb86b50956a6c33b5eab9812d1b42f528b3a7a17c0a397cf041' and sha(rq)=='73bc3864944276b88944163257e3cfc67dde6141b2dc3f82588af66621003945';r=json.loads(rq)['entries'][2510];assert r['current_reconciliation']=='unassessed' and r['contract_id']==q['contract_id'];rows=json.loads(base)['newly_assessed_ledger']['entries'];assert len(rows)==1101 and rows[843]==related['f2ec_row_843'] and rows[843]['id']=='SEGOVB-L12-SOCIAL-PERSONALITY-AXIS-SLUG-ROUNDTRIP'
 for name,digest in [('REGISTRATION-ROOT-L2-EXT-055-063.json','80050300f1444900b4e83feaa34cd9fff15e8e42d08d94240bc4600ab66109fd'),('READ-ROOT-L2-EXT-055-066.json','b7fe7d69310e522f8ae05bdbeded0b382a244466b8b203a3e467f55f10ee418a'),('QUALIFIED-INHERITED-L2-EXT-055-058-060-061-001.json','bd94d9ee48850460d399a43ad162a05de0601918d3f4431e50417b63d4e408d6')]:assert sha((root/('receipt-'+name)).read_bytes())==digest
 l2=json.loads((root/'receipt-READ-ROOT-L2-EXT-055-066.json').read_bytes())['rows'][1];inh=json.loads((root/'receipt-QUALIFIED-INHERITED-L2-EXT-055-058-060-061-001.json').read_bytes())['rows'][1];assert l2['fresh_personal_ranges']==[] and l2['qualified_inherited_same_lens_ranges']==[[1,329]] and inh['supplier']=='camera' and inh['prior_assessed_ranges']==[[1,1909]] and inh['qualified_selected_same_lens_ranges']==[[1,329]]
 sm=(root/'supplier-metadata-copy.raw').read_bytes();assert sha(sm)=='8bac3b686c14c75a8d92192e8c3b3622a95173ffe4dfae710597baa15c6ab36b';assert json.loads(sm.splitlines()[264])==inh['raw_row']==json.loads((root/'supplier-row-264.json').read_bytes());assert json.loads((root/'SUPPLIER-008.json').read_bytes())['status']==128
 for label in ['historical','current']:
  for lo,hi in [(1,110),(111,220),(221,329)]:window(root,label+'-social.raw',f'{label}-social-{lo:04}-{hi:04}.txt',lo,hi)
 support=json.loads((root/'SUPPORT-IDENTITIES-007.json').read_bytes());assert len(support)==4
 for item in support:
  assert item['revision']==revs[2] and src[(revs[2],item['path'])]==(root/item['capture']).read_bytes()
  for w in item['windows']:window(root,item['capture'],w['capture'],w['lo'],w['hi'])
 assert sum(len(x['windows']) for x in support)==8
 terms=json.loads((root/'REGISTRATION-010.json').read_bytes())['terms'];saved=json.loads((root/'RELATED-SEARCH-010.json').read_bytes());assert saved=={'queue':[],'ledger':[]}
 for collection in (json.loads(hist[(old,hpath)])['entries'],rows):
  for row in collection:
   text=json.dumps(row,ensure_ascii=False).lower();assert not any(t.lower() in text for t in terms)
 print('restricted manifest, six source bindings, three revision file identity, pinned root, queue and checkpoint proofs: PASS')
 print('historical receipt and supplier row, 14 registered source windows, bounded relationship search: PASS')
 print('Scope: evidence bytes and registered displays; no semantic closure, product execution, validation, independent custody or checkpoint 3821 claim.')
if __name__=='__main__':main()
