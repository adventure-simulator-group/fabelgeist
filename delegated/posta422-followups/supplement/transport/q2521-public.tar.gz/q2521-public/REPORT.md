# q2521: dialogue admission and participant identity

This is a bounded independent Lens 3 source assessment at 95e, not a queue or
whole-lens closure. The assigned `dialogue_schema.rs` range 1–703 was displayed;
704–781 was not. Captured full bodies and same-file equality do not transfer
reader credit or imply a complete historical or current tree review.

The selected web request parses an NPC ID numerically but forwards its original
string. The native reducer stores NPC IDs as canonical decimals, then compares
the stored ID to the original spelling when a rumor delivery is processed. If
`0007` reaches that point for actor 7, an accepted numeric spelling cannot
match the retained `7`. This conclusion is conditional on all earlier session,
presence, delivery and referral-authority checks; no actual request, persistent
state, rollback, or product outcome was observed. The producer can insert a
delivery under additional guards; their joint reach remains open.

The selected start path includes gateway, catalog, character, conversation and
presence checks; prompt answering checks role, revision, choice uniqueness and
membership. The historic q232/session-reuse and ledger 773/referral-shape
records have different first operations. No alias or unique count is decided.

The original 059 record and the reconstructed selected record agree as parsed,
while their whole streams differ. Historical supplier camera and Root Lens 2
scopes remain separately attributed. The actual preceding core and strategic-web
support views occurred before discovery of their nested AGENTS files; those
rules were then read and their chronology is retained. Full details, registered
views, source references, historic identities and replay limits are in the
JSON files.
