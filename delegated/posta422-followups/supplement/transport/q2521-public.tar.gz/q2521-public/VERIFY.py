#!/usr/bin/env python3
"""Read-only evidence identity replay; no product execution."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
if sys.flags.optimize: raise RuntimeError('Do not disable evidence assertions')
p=pathlib.Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=pathlib.Path);ap.add_argument('--restricted',type=pathlib.Path);args=ap.parse_args()
h=lambda b:hashlib.sha256(b).hexdigest();J=lambda x:json.loads(x.read_bytes())
m=J(p/'MANIFEST.json');r=J(p/'REPORT.json');o=J(p/'SOURCE-OBJECTS.json');rr=J(p/'READ-RECEIPT.json');hist=J(p/'HISTORY-SUMMARY.json')
assert not any(x.is_symlink() for x in p.rglob('*'))
files={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'};assert files==set(m['files'])
for n,v in m['files'].items():
 q=p/n;b=q.read_bytes();assert len(b)==v['bytes'] and h(b)==v['sha256'] and q.stat().st_mode&0o777==v['mode']
assert r['historical_contract_id']=='EXTENSION-L3-ROOT-L2-EXT-0057' and r['assigned_range']==[1,703] and r['unread_assigned_file_complement']==[[704,781]]
assert r['source_revision']==o['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and r['source_tree']==o['source_tree']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
index={}
for row in o['objects']:
 b=(p/row['object']).read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'] and len(b.splitlines())==row['eof_lines'];assert hashlib.sha1(('blob %d\0'%len(b)).encode()+b).hexdigest()==row['git_blob'];index[(row['group'],row['id'])]=row
for view in rr['views']:
 row=index[(view['group'],view['source_id'])];assert row['revision']==view['revision'] and row['path']==view['path'] and row['sha256']==view['source_sha256'] and row['git_blob']==view['git_blob'];lo,hi=view['lines'];assert 1<=lo<=hi<=row['eof_lines'];s=(p/row['object']).read_text().splitlines();sep=': ' if view['format']=='colon' else ' ';expected=('\n'.join(f'{i:4d}{sep}{s[i-1]}' for i in range(lo,hi+1))+'\n').encode();body=(p/view['view_file']).read_bytes();assert body==expected and h(body)==view['view_sha256'];reg=J(p/view['registration']);assert any(x['path']==view['path'] and x['revision']==view['revision'] and x['sha256']==view['source_sha256'] and x['lines']==view['lines'] for x in reg['views'])
assert len(rr['views'])==34 and hist['selected_records_equal_as_parsed'] and h((p/'selected-queue-original.json').read_bytes())==hist['selected_normalized_sha256']
for x in hist['references']:
 assert x['located'] and x['match'] and h((p/'historical'/f"{x['id']}.json").read_bytes())==x['sha256']==x['expected_sha256']
assert J(p/'historical/2.json')['rows'][2]['supplier']=='camera' and J(p/'historical/1.json')['rows'][2]['fresh_personal_ranges']==[]
if args.repo:
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');g=lambda *v:subprocess.check_output(['git','-C',str(args.repo),*v],env=env)
 assert g('rev-parse',r['source_revision']+'^{tree}').decode().strip()==o['source_tree']
 for row in o['objects']:assert g('rev-parse',row['revision']+':'+row['path']).decode().strip()==row['git_blob']
 for row in hist['published_identity']:
  assert h(g('show',hist['published_revision']+':'+row['git_path']))==row['sha256'] and g('rev-parse',hist['published_revision']+':'+row['git_path']).decode().strip()==row['git_blob']
if args.restricted:
 z=args.restricted;old=(z/'queue-original.json').read_bytes();rec=(z/'queue-reconstructed.json').read_bytes();pub=(z/'queue-published.json').read_bytes();assert h(old)==hist['original_queue_sha256'] and h(rec)==hist['reconstructed_queue_sha256'] and h(pub)==hist['published_queue_sha256'] and old!=rec and rec==pub
 assert J(z/'selected-queue-original.json')==json.loads(old)['entries'][2521]==json.loads(rec)['entries'][2521]==json.loads(pub)['entries'][2521]==J(p/'selected-queue-original.json')
 assert J(z/'reconciliation-working.json')['entries'][2521]['current_reconciliation']=='unassessed'
 for row in hist['published_identity']:assert h((z/row['local_capture']).read_bytes())==row['sha256'] and row['equal']
print(json.dumps({'result':'pass','source_identity_rows':len(o['objects']),'personally_displayed_windows':len(rr['views']),'git_revision_binding_checked':bool(args.repo),'restricted_original_checked':bool(args.restricted),'limits':'Hash and extraction replay only; personal display, source reasoning, input reachability, runtime behavior, global privacy, aliases, counts and closure are not validated.'}))
