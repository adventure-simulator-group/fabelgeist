#!/usr/bin/env python3
# Source and evidence verification only; does not execute product or dependency code.
import pathlib,json,hashlib,stat,argparse,tomllib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--anchors',type=pathlib.Path);ap.add_argument('--skip-manifest',action='store_true');args=ap.parse_args()
if args.anchors and not args.private:raise SystemExit('--anchors requires --private')
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 x={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);assert z+21<=len(b);n=b[a+1:z].decode();assert n not in x;x[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return x
def proof(root,path,source,trees):
 cur=root;parts=path.split('/')
 for i,part in enumerate(parts):
  b=(P/trees/(cur+'.tree')).read_bytes();assert oid('tree',b)==cur;mode,cur=tree(b)[part];assert (mode in ('40000','040000')) if i<len(parts)-1 else mode=='100644'
 b=(P/source).read_bytes();assert oid('blob',b)==cur;return b
root='1eec97de340d9b7debbb30ca0c0fb2240a73b93f';path='crates/adventuresim-core/src/organization.rs';b=proof(root,path,'current/organization.source','current/trees');assert H(b)=='cb410372fbb5a1f8b61fad2bf447bcd93512725560fb69338ec024ed3135b0e1' and len(b.splitlines())==1251
hist=json.loads((P/'SOURCE-002-CAPTURE.json').read_bytes());assert hist['status']=='failed' and len(hist['rows'])==2
for x in hist['rows']:assert proof(x['root_tree'],path,'current/organization.source','git/trees')==b and x['source_sha256']==H(b)
support=json.loads((P/'SUPPORT-004-CAPTURE.json').read_bytes());seven=json.loads((P/'SUPPORT-007-CAPTURE.json').read_bytes())
for x in support['sources']:
 data=proof(root,x['path'],x['file'],'support/trees');assert H(data)==x['sha256'] and len(data.splitlines())==x['eof']
for x in seven['product_sources']:
 data=proof(root,x['path'],x['file'],'support7/trees');assert H(data)==x['sha256'] and len(data.splitlines())==x['eof']
rootdata=(P/'current/trees'/(root+'.tree')).read_bytes();assert oid('tree',rootdata)==root;lock=(P/'dependency/Cargo.lock').read_bytes();assert tree(rootdata)['Cargo.lock']==('100644',oid('blob',lock));assert H(lock)=='cb227fddbf85f10ea6d3bf929827ea395f240eae2d948a2c4c590ae526ba1f73'
packs=tomllib.loads(lock.decode())['package'];archives=json.loads((P/'DEPENDENCY-006-RESULT.json').read_bytes())['archives'];z=json.loads((P/'DEPENDENCY-010-RESULT.json').read_bytes())['formatter_archives']
for x in archives:
 pkg=next(y for y in packs if y['name']==x['name'] and y['version']==x['version']);assert x['expected_sha256']==pkg['checksum']
assert len(z)==1 and z[0]['package'] in packs
def view(x,source=None):
 data=(P/x['file']).read_bytes();assert H(data)==x['sha256'];assert 'bytes' not in x or len(data)==x['bytes']
 if source is not None:
  a,e=x['range'];lines=source.decode().splitlines();assert 0<a<=e<=len(lines);assert data==('\n'.join(f'{i:4d} {lines[i-1]}' for i in range(a,e+1))+'\n').encode()
main=json.loads((P/'SOURCE-003-CAPTURE.json').read_bytes());assert [x['range'] for x in main['views']]==[[1,100],[101,200],[201,300],[301,400],[401,498]]
for x in main['views']:view(x,b)
for x in support['views']:
 row=next(s for s in support['sources'] if s['path']==x['path']);view(x,(P/row['file']).read_bytes())
for x in seven['views']:
 source=next((s for s in seven['product_sources'] if s['path']==x['path']),None);view(x,(P/source['file']).read_bytes() if source else None)
for record in ['SUPPORT-009-CAPTURE.json','SUPPORT-012-CAPTURE.json']:
 for x in json.loads((P/record).read_bytes())['views']:view(x)
for x in json.loads((P/'SUPPORT-014-CAPTURE.json').read_bytes()):view(x)
q=json.loads((P/'HISTORY-PROJECTION.json').read_bytes());assert q['queue_index']==2497 and q['lens']==3 and q['status_at_f2ec']=='unassessed' and q['historical_L2_qualification_sha256']=='bd94d9ee48850460d399a43ad162a05de0601918d3f4431e50417b63d4e408d6'
assert json.loads((P/'SUPPORT-011-FAILURE.json').read_bytes())['actual_eof']==42
cross=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes());assert cross['private_manifest_sha256']=='2e5c46b420a88f8d0a91ba6a6b044b664d008d468aa6d6236c3b19e6940e3774'
for x in cross['files']:
 for k in ('private_relative','public_relative'):
  rel=pathlib.PurePosixPath(x[k]);assert not rel.is_absolute() and '..' not in rel.parts
 out=(P/x['public_relative']).read_bytes();assert len(out)==x['public_bytes'] and H(out)==x['public_sha256']
 if args.private:
  raw=(args.private/x['private_relative']).read_bytes();assert len(raw)==x['private_bytes'] and H(raw)==x['private_sha256'];pos=0;made=bytearray()
  for r in x['replacements']:
   off=r['offset'];end=off+r['length'];assert pos<=off<=end<=len(raw);made+=raw[pos:off]+r['replacement'].encode();pos=end
  made+=raw[pos:];assert bytes(made)==out
if not args.skip_manifest:
 m=json.loads((P/'MANIFEST.json').read_bytes());fs={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and not x.is_symlink()};ds={str(x.relative_to(P)) for x in P.rglob('*') if x.is_dir() and not x.is_symlink()};assert not any(x.is_symlink() for x in P.rglob('*'));assert fs==set(m['files'])|{'MANIFEST.json'} and ds==set(m['directories'])
 for n,x in m['files'].items():
  f=P/n;data=f.read_bytes();assert (len(data),H(data),stat.S_IMODE(f.stat().st_mode))==(x['bytes'],x['sha256'],x['mode'])
 for n,mode in m['directories'].items():assert stat.S_IMODE((P/n).stat().st_mode)==mode
 print('Public manifest, bytes and modes: pass')
else:print('Public manifest skipped only for preseal')
print('Root trees to selected product blobs, lockfile, product views and native-view recorded hashes: pass')
print('Public-only limits: commit-to-tree binding, whole historical queues, recovered original and native archive membership require separately held originals.')
if args.private:
 assert H((args.private/'MANIFEST.json').read_bytes())==cross['private_manifest_sha256'];cmd=[sys.executable,str(args.private/'VERIFY.py')]
 if args.anchors:cmd+=['--anchors',str(args.anchors)]
 subprocess.run(cmd,check=True);print('Restricted evidence replay and private-to-public byte crosswalk: pass')
else:print('Private replay and redaction byte comparison: not requested')
print('Display events are attestations; no product execution, builds, tests or probes.')
