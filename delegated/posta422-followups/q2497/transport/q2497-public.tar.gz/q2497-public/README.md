# q2497 admission-contract evidence

Read ASSESSMENT.md. This is a path-safe reconstructed public successor;
the exact private originals, raw historical queue selections, f2ec ledger,
Git commits and native crate archives remain separately held. The public
packet includes pinned root-tree-to-product-blob proofs, exact selected source
windows and native source displays with their recorded hashes. It does not
by itself bind the root tree to its commit, prove the f2ec queue position, or
bind native excerpts to locked crate archives. The optional private replay
performs those checks; the original/reconstructed whole 059 queue positions
also require the separately held queues.

Run `python3 VERIFY-PUBLIC.py`, optionally adding `--private DIR` and, with
that option, `--anchors DIR` for full historical queue replay. The redaction
crosswalk records whole-file identities, original byte offsets/lengths and
aliases, not individual removed path values or their digests. Public evidence
cannot reconstruct replaced private bytes. Display events remain reader
attestations. Finite privacy scans cannot prove absence of all sensitive
values. No product code, builds, tests or runtime probes run in this packet.
The separate 73 nontext/no-positive-EOF obligations and missing checkpoint
3821 remain open.
