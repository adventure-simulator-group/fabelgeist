import datetime,gzip,hashlib,json,pathlib,subprocess,difflib
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());supports=json.loads((p/'support-registration.json').read_text())['sources'];role_versions=[{'path':r['path'],**v} for r in reg['roles'] for v in r['versions']];present=[x for x in role_versions+supports if x['present']];absent=[x for x in role_versions if not x['present']];objdir=p/'git-objects';objdir.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=objdir/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in present:
 rev=x['revision'];tree=get('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['local_path']).read_bytes();assert tree==x['git_blob'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree;proof.append({'revision':rev,'path':x['path'],'archive':x['local_path'],'commit_tree':root,'chain':chain,'blob':tree})
absences=[]
for x in absent:
 rev=x['revision'];tree=get('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[];parts=x['path'].split('/')
 for name in parts[:-1]:
  mode,child=entries(get('tree',tree))[name];assert mode in ('40000','040000');chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 assert parts[-1] not in entries(get('tree',tree));absences.append({'revision':rev,'path':x['path'],'commit_tree':root,'parent_chain':chain,'parent_tree':tree,'missing_name':parts[-1]})
(p/'git-absence-proofs.json').write_text(json.dumps({'qualification':'Raw Git tree nonmembership; absence does not imply feature absent.','proofs':absences},indent=2)+'\n');(p/'git-proofs.json').write_text(json.dumps({'qualification':'Git commit/tree and source bytes verify identity only, never reading credit.','objects':objects,'proofs':proof},indent=2)+'\n')
a=(p/'source/2464-90a4.rs').read_text().splitlines(keepends=True);b=(p/'source/2464-95e6.rs').read_text().splitlines(keepends=True);(p/'2464-p17-to-current.diff').write_text(''.join(difflib.unified_diff(a,b,fromfile='report-p17:90a:2464',tofile='current:95e:2464')))
ranges={0:[[655,692]],1:[],2:[[85,110]],3:[[1,35]],4:[[1,64]],5:[[35,123]],6:[[45,125]],7:[[45,70],[280,298]],8:[[47,72],[320,340]],9:[[527,590],[675,695],[760,805]],10:[[8,18],[55,70]],11:[[1,25]],12:[[1,30]],13:[]};reads=[]
for i,x in enumerate(supports):reads.append({'path':x['path'],'revision':x['revision'],'archive':x['local_path'],'sha256':x['sha256'],'eof':x['registered_range'][1],'actual_body_display_ranges':ranges[i]})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registration':{'path':'support-registration.json','sha256':hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest()},'reads':reads,'qualification':'Fresh support only; only explicit body windows confer credit. Archived bytes and navigation do not confer any additional body or ordered-role credit; one HTML display was truncated and only 1–25 counts.'},indent=2)+'\n')
roles=[{'original_index':2463,'p17_actual_display_ranges':[[1,70],[71,140],[141,203]],'current_actual_display_ranges':[],'pr_working_actual_display_ranges':[],'p17_unread_ranges':[],'current_unread_ranges':'path absent at 95e','qualification':'Exact path absent at 6533 and 95e; source presence preserved only in 90a.'},{'original_index':2464,'p17_actual_display_ranges':[[1,70],[71,140],[141,210],[211,280],[281,350],[351,420],[421,490],[491,560],[561,618]],'current_actual_display_ranges':[[1,70],[71,140],[141,210],[211,280],[281,350],[351,420],[421,490],[491,560],[561,630],[631,700],[701,770],[771,792]],'pr_working_actual_display_ranges':[],'p17_unread_ranges':[],'current_unread_ranges':[],'qualification':'Fresh complete 90a and 95e displays, test source text only; 6533 is byte-identical to 95e but not separately displayed.'}]
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registration':{'path':'registration.json','sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest()},'roles':roles,'qualification':'Distinct exact fresh role displays after registration; prior bounded supports and other authors remain separate; no product tests or executions.'},indent=2)+'\n');print('proofs',len(proof),'absences',len(absences),'supports',len(supports))
