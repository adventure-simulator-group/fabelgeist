# Delegated physical-p16 body-response source evidence

This packet covers original roles 2486–2487 by `/root/hair_ops`. `report.json`
contains the bounded assessment, old/current relationships and thirteen lens
perspectives. `registration.json` and `read-receipt.json` record prospective
source identities and personal displays; support registrations and receipts
record the separate current and historical context.

The recovered physical-p16 snapshot is a dirty delta based at
`a120390947c89b703dc74c4255a13c035d054c50`. Its registry records patch SHA256
`fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7` and dirty
status. The full patch bytes were not recovered in this packet, so the hash and
status are preserved as historical assertions. Both assigned objects match the
original registry, older source catalog and f82 hash-named archive; each is also
byte-identical to the corresponding a120, 039, 6533 and current 95e source.
This path-specific equality neither restores the full dirty delta nor establishes
that its other files equal clean base.

The agent separately displayed the complete P16 and 95e versions of each
assigned source. The a120, 039 and 6533 counterparts were archived and checked
for equality, but not separately displayed. Original 059/774 and prior central
reviews retain their own reviewers, revisions and narrower or different source
ranges; no record is promoted to checkpoint 3821.

`git-proofs.json` and `git-objects/` contain source and archived-object Git
membership evidence. `historical-manifest.json`, `reference/older-selection.json`
and `reference/prior-selection.json` preserve original evidence and earlier
assessment source bytes. `evidence-verification.json` records identity and
accounting checks only. No viewer, product, build, test, probe, simulated fixture,
implementation, repair or product validation was performed.
