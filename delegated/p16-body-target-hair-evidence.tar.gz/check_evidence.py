import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());unzip=lambda n:gzip.decompress((p/n).read_bytes());reg=load('registration.json');orig=json.loads(unzip('reference/registry.json.gz'));cat=json.loads(unzip('reference/older-source-catalog.json.gz'));gp=load('git-proofs.json');checks=[]
s=next(x for x in orig['snapshots'] if x['id']=='physical-p16');assert s['base']==s['head']=='a120390947c89b703dc74c4255a13c035d054c50' and s['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and s['status_porcelain'] and s['changed_variants']==159;assert reg['snapshot_authority']['status_porcelain']==s['status_porcelain'];checks.append('059 historical P16 dirty/base/status/recorded patch hash matched; patch bytes not claimed recovered')
for role in reg['roles']:
 i=role['original_index'];o=orig['files'][i];c=cat['rows'][i];assert role['source_id']==o['source_id']==c['source_id'] and role['requested_historical_material_ranges']==o['material_ranges'];v=role['versions'][0];b=(p/v['local_path']).read_bytes();assert (len(b),sha(b),blob(b),len(b.splitlines()))==(v['bytes'],o['sha256'],v['git_blob'],v['registered_range'][1]);assert pathlib.Path(role['recovered_object_path']).read_bytes()==b and c['expected_sha256']==sha(b);assert subprocess.check_output(['git','-C',repo,'show',role['evidence_archive_revision']+':'+role['evidence_archive_path']])==b
 for x in role['versions'][1:]:
  t=(p/x['local_path']).read_bytes();assert t==subprocess.check_output(['git','-C',repo,'show',x['revision']+':'+x['path']]) and (len(t),sha(t),blob(t),len(t.splitlines()))==(x['bytes'],x['sha256'],x['git_blob'],x['registered_range'][1]);assert t==b
checks.append('both dirty-P16 registry/catalog/f82 archived objects equal exact P16 bodies and path-specific a120/039/95e bodies; equality not generalized')
names=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json'];sup=[x for n in names for x in load(n)['sources']]
for x in sup:
 b=(p/x['local_path']).read_bytes();assert (len(b),sha(b),blob(b),len(b.splitlines()))==(x['bytes'],x['sha256'],x['git_blob'],x['registered_range'][1]);assert b==subprocess.check_output(['git','-C',repo,'show',x['revision']+':'+x['path']])
assert len(sup)==16 and (p/sup[7]['local_path']).read_bytes()==(p/reg['roles'][0]['versions'][0]['local_path']).read_bytes() and (p/sup[8]['local_path']).read_bytes()==(p/reg['roles'][1]['versions'][0]['local_path']).read_bytes();checks.append('16 registered support bodies including 6533 exact counterparts match Git bytes; no support read credit inferred')
def tree_entries(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);z=b.index(b'\0',j);d[b[j+1:z].decode()]=(b[i:j].decode(),b[z+1:z+21].hex());i=z+21
 return d
def obj(oid):
 v=gp['objects'][oid];b=unzip(v['archive']);t=v['type'];assert (len(b),sha(b))==(v['bytes'],v['sha256']) and hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;return b
for oid in gp['objects']:obj(oid)
for x in gp['proofs']:
 tree=obj(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for e in x['chain']:assert e['tree']==tree and tree_entries(obj(tree))[e['name']]==(e['mode'],e['object']);tree=e['object']
 assert tree==x['blob']==blob((p/x['archive']).read_bytes())
assert len(gp['proofs'])==24;checks.append('24 archived Git commit/tree/blob chains independently verified; f82 only proves archived object transport')
rr=load('read-receipt.json');assert sha((p/'registration.json').read_bytes())==rr['prospective_registration']['sha256']
for x in rr['reads']:
 for label in ['p16','current']:
  cover=set()
  for a,b in x[label+'_actual_display_ranges']:assert 1<=a<=b;cover.update(range(a,b+1))
  eof=next(z for z in reg['roles'] if z['original_index']==x['original_index'])['versions'][0]['registered_range'][1];assert len(cover)==eof and not x[label+'_unread_ranges']
 assert not x['base_actual_display_ranges'] and not x['older_origin_actual_display_ranges']
sr=load('support-read-receipt.json');assert len(sr['reads'])==16 and not sr['reads'][7]['actual_display_ranges'] and not sr['reads'][8]['actual_display_ranges']
for x in sr['reads']:
 for a,b in x['actual_display_ranges']:assert 1<=a<=b<=x['eof']
for x in sr['prospective_registrations']:assert sha((p/x['path']).read_bytes())==x['sha256']
checks.append('separately displayed full P16/current scopes and exact bounded support scopes verified; a120/039/6533 display credit explicitly absent')
trans={x['path']:x for x in json.loads(unzip('reference/original-transport-manifest.json.gz'))['entries']};h=load('historical-manifest.json');assert not h['unavailable']
for x in h['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
checks.append(f"{len(h['records'])} recovered 059 originals match transport sizes, SHA256 and Git blobs")
old=load('reference/older-selection.json');oldix={x['path']:x for x in json.loads(unzip('reference/older-774-handoff-manifest.json.gz'))['files']};b=unzip(old['copy']);assert (len(b),sha(b))==(old['bytes'],old['sha256'])==(oldix[old['path']]['bytes'],oldix[old['path']]['sha256']);lines=b.splitlines()
for i,role,n in [(188,2487,490),(530,2487,490),(189,2486,140),(531,2486,140)]:
 row=json.loads(lines[i]);target=next(x for x in reg['roles'] if x['original_index']==role);assert row['source_id']=='pr-working:'+target['path'] and row['observed_sha256']==target['original_registry_sha256'] and row['read_ranges']==[[1,n]] and row['read_complete']
checks.append('774 exact native supplier initial/closure rows match original pr-working hashes, read scopes and preserved authorship')
for x in load('reference/prior-selection.json')['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
 for y in x['source_records']:
  z=(p/y['copy']).read_bytes();body=gzip.decompress(z);assert sha(z)==y['compressed_sha256'] and sha(body)==y['sha256'] and body==subprocess.check_output(['git','-C',repo,'show',y['revision']+':'+y['path']])
checks.append('3 earlier central assessments and 29 exact associated 95e source payloads verified; prior ranges not transferred')
for x in load('reference/rules.json')['rules']:assert sha((p/x['copy']).read_bytes())==x['sha256']
q=json.loads(unzip('reference/queue-059.json.gz'))['entries'];r=load('report.json');assert len(r['lenses'])==13 and {x['number'] for x in r['lenses']}==set(range(1,14));assert all(q[x['zero_based_index']]['contract_id']==x['contract_id'] and q[x['zero_based_index']]['status']==x['status'] for x in r['historical_queue']);assert r['connections'][0]['id']==q[39]['contract_id'];checks.append('13 bounded lens views and original queue identities/status preserved, including q39 alias')
out={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','checks':checks,'qualification':'Evidence identity/accounting only. No product or viewer execution, build, test, probe, simulated fixture, implementation, repair, or product validation.'};(p/'evidence-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
