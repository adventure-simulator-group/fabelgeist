import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());names=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json'];sup=[x for n in names for x in json.loads((p/n).read_bytes())['sources']];(p/'git-objects').mkdir(exist_ok=True);objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for r in reg['roles']:
 members.extend(r['versions'][1:]);v=r['versions'][0];members.append({'revision':r['evidence_archive_revision'],'path':r['evidence_archive_path'],'local_path':v['local_path'],'sha256':v['sha256'],'git_blob':v['git_blob']})
members+=sup
for s in members:
 rev=s['revision'];tree=obj('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local_path']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();proofs.append({'revision':rev,'path':s['path'],'archive':s['local_path'],'commit_tree':root,'chain':chain,'blob':tree})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Git membership proves clean versions and f82 archive object bytes only; dirty P16 is separately bound by recorded registry, status, catalog and source hash. No whole patch reconstruction or read credit.','objects':objects,'proofs':proofs},indent=2)+'\n')
ranges={2486:[[1,70],[71,140]],2487:[[1,100],[101,200],[201,300],[301,400],[401,490]]};reads=[]
for r in reg['roles']:
 reads.append({'original_index':r['original_index'],'p16_actual_display_ranges':ranges[r['original_index']],'current_actual_display_ranges':ranges[r['original_index']],'base_actual_display_ranges':[],'older_origin_actual_display_ranges':[],'p16_unread_ranges':[],'current_unread_ranges':[],'base_unread_ranges':[[1,r['versions'][1]['registered_range'][1]]],'older_origin_unread_ranges':[[1,r['versions'][3]['registered_range'][1]]],'qualification':'P16 and 95e bodies separately personally displayed, including test text where present. Base and older-origin copies are independently byte-compared only.'})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration':{'path':'registration.json','sha256':sha((p/'registration.json').read_bytes())},'reads':reads,'qualification':'Only stated exact revision display windows count; all code and test text inspection only.'},indent=2)+'\n')
ranges=[[[1,73]],[[1,110],[111,211]],[[1,36]],[[1,66]],[[1,98]],[[75,130]],[[235,270]],[],[],[[345,425],[418,475]],[[1,126]],[[1,58]],[[435,490]],[[140,175]],[[1,125]],[[75,107]]];assert len(ranges)==len(sup);reads=[]
for s,rr in zip(sup,ranges):reads.append({'path':s['path'],'revision':s['revision'],'archive':s['local_path'],'sha256':s['sha256'],'eof':s['registered_range'][1],'actual_display_ranges':rr})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in names],'reads':reads,'qualification':'Only bounded displayed support windows count; earlier 6533 copies are not personally displayed; test source not executed; no ordered-role credit.'},indent=2)+'\n');print('proofs',len(proofs),'support',len(sup))
