import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
c=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()))
items=[('current','crates/adventuresim-tactical-core/src/scene_coordinates/spatial.rs',[[130,202],[210,258]]),('p16','crates/adventuresim-tactical-core/src/scene_coordinates/spatial.rs',[[130,202],[210,258]]),('current','crates/adventuresim-tactical-core/src/scene_input/compounds.rs',[[1,110],[200,245]]),('current','crates/adventuresim-tactical-client/src/tactical_scene_viewer/building_review/openings.rs',[[100,217]]),('current','crates/adventuresim-tactical-client/src/tactical_scene_viewer.rs',[[1230,1350]]),('current','crates/adventuresim-tactical-client/src/tactical_scene_viewer/building_review.rs',[[160,186]]),('current','crates/adventuresim-tactical-core/src/city_layout/compound/boundary.rs',[[181,266]])]
sources=[]
for index,(kind,path,win) in enumerate(items):
 if kind=='current':
  r=rev;b=subprocess.check_output(['git','-C',repo,'show',r+':'+path]);git_path=path
 else:
  row=c['rows'][2526];assert row['source_id']=='physical-p16:'+path;r='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';git_path='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['expected_sha256'];b=subprocess.check_output(['git','-C',repo,'show',r+':'+git_path]);assert hashlib.sha256(b).hexdigest()==row['expected_sha256'];assert pathlib.Path(row['object']).read_bytes()==b
 eof=len(b.splitlines());assert all(1<=lo<=hi<=eof for lo,hi in win),(path,eof,win)
 f=f'support/{index}-{kind}.rs';(p/f).write_bytes(b)
 sources.append({'index':index,'kind':kind,'revision':r,'git_path':git_path,'path':path,'local':f,'bytes':len(b),'eof':eof,'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'prospective_ranges':win,'qualification':'Separate bounded support; no original ordered-role credit. P16 is archive transport only.' if kind=='p16' else 'Separate bounded support; no original ordered-role credit.'})
f=p/'support-registration.json';f.write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':sources},indent=2)+'\n');print('sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(sources,indent=2))
