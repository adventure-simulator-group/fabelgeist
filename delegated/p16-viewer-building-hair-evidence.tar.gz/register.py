import datetime,hashlib,json,pathlib,shutil,subprocess
p=pathlib.Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
ref=pathlib.Path('<LOCAL_PATH_1>')
cat=json.loads(pathlib.Path('<LOCAL_PATH_2>').read_bytes())
revs=['039329518e264f19206cf5b0b98d177433f40c17','a120390947c89b703dc74c4255a13c035d054c50','6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']
i=2521;path='crates/adventuresim-tactical-client/src/tactical_scene_viewer/buildings.rs';c=cat['rows'][i];assert c['source_id']=='physical-p16:'+path
b=pathlib.Path(c['object']).read_bytes();h=hashlib.sha256(b).hexdigest();assert h==c['expected_sha256'];local=f'source/{i}-p16.rs';(p/local).write_bytes(b)
archive='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+h;assert subprocess.check_output(['git','-C',repo,'show','f82adcabd9d89c4fa2dd7f99253a45297a0681ee:'+archive])==b
versions=[]
for rev in revs:
 x=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True)
 if x.returncode:
  t=subprocess.check_output(['git','-C',repo,'ls-tree','-r','--name-only',rev,'--',path]).decode().splitlines();assert path not in t;versions.append({'revision':rev,'present':False,'tree_exact_lookup':t});continue
 v=x.stdout;l=f'source/{i}-{rev[:4]}.rs';(p/l).write_bytes(v);versions.append({'revision':rev,'local':l,'present':True,'bytes':len(v),'prospective_range':[1,len(v.splitlines())],'sha256':hashlib.sha256(v).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(v)).encode()+b'\0'+v).hexdigest(),'equals_p16':b==v})
for f in ['registry.json.gz','older-source-catalog.json.gz','rule-AGENTS.md','rule-crates__AGENTS.md']:shutil.copyfile(ref/f,p/'reference'/f)
role={'original_index':i,'path':path,'p16':{'local':local,'bytes':len(b),'prospective_range':[1,len(b.splitlines())],'sha256':h,'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'catalog_origin':c['origin'],'catalog_object':c['object'],'archive_revision':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','archive_path':archive},'versions':versions}
r={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','scope':'Prospectively register complete original role2521 dirty P16 and 0393, a120, 6533, pinned 95e bodies. Only personally displayed ranges confer current reviewer read credit.','qualification':'P16 registry records 159-path dirty snapshot based at a120; f82 is archive transport, 0393 catalog per-file origin, and patch SHA fc9002ab... is registry assertion; full patch not recovered. Equality of a file never reconstructs whole delta. Earlier records retain their author, snapshot, role, and range; no checkpoint3821 promotion.','constraint':'Source/evidence inspection only; no product, viewer, builds, tests, probes, simulation, or repair.','roles':[role]}
f=p/'registration.json';f.write_text(json.dumps(r,indent=2)+'\n');print('registration_sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(role,indent=2))
