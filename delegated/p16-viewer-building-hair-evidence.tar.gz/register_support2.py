import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';cur='95e63628f9d70b8dd6e6fede64334696c6995009';cat=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()));
items=[('current','crates/adventuresim-tactical-core/src/scene_coordinates/spatial.rs',[[259,266]],None),('current','crates/adventuresim-tactical-core/src/scene_input/buildings.rs',[[105,155],[210,280]],None),('current','crates/adventuresim-tactical-core/src/scene_input/urban.rs',[[1,20]],None),('current','crates/adventuresim-tactical-core/src/city_layout/grounding.rs',[[60,115]],None),('p16','crates/adventuresim-tactical-core/src/city_layout/grounding.rs',[[60,115]],2524)]
sources=[]
for i,(kind,path,win,idx) in enumerate(items):
 if kind=='current':r=cur;git_path=path;b=subprocess.check_output(['git','-C',repo,'show',r+':'+path])
 else:
  row=cat['rows'][idx];assert row['source_id']=='physical-p16:'+path;r='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';git_path='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['expected_sha256'];b=subprocess.check_output(['git','-C',repo,'show',r+':'+git_path]);assert hashlib.sha256(b).hexdigest()==row['expected_sha256']
 eof=len(b.splitlines());assert all(1<=lo<=hi<=eof for lo,hi in win),(path,eof,win);f=f'support/{i+7}-{kind}.rs';(p/f).write_bytes(b)
 sources.append({'index':i+7,'kind':kind,'revision':r,'git_path':git_path,'path':path,'local':f,'bytes':len(b),'eof':eof,'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'prospective_ranges':win,'qualification':'Separate bounded support, not ordered-role credit; f82 is P16 archive transport.'})
f=p/'support-registration-02.json';f.write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':sources},indent=2)+'\n');print('sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(sources,indent=2))
