from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent
chunks={'body-trait':[[1,35],[36,70]],'equipment-trait':[[532,558],[559,585],[610,650]],'combat-armor':[[1,45],[46,89]],'autoresolve':[[250,285]],'auto-model':[[105,150],[240,270],[300,331],[332,363]],'tactical-inventory':[[400,430],[431,460],[560,592],[593,625]],'tactical-player':[[195,235]],'stdb-capability':[[150,185],[570,597],[598,625]],'equipment-location':[[300,335],[336,370]],'attribute-owner':[[1,40],[41,75],[76,110]],'melee-evidence':[[270,315]],'tactical-ingress':[[145,170],[171,195]],'tactical-facts':[[130,175]],'iteration-builder':[[1,27],[28,55],[185,225],[230,265],[266,300]],'iteration-evidence-entry':[[150,190],[191,230]],'combat-model-types':[[1,20],[75,100]],'stdb-projection':[[475,510],[511,545]],'armor-helper-current':[[40,67],[68,94]],'equipment-part':[[275,302]],'equipment-default':[[220,239]]}
out={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':[],'entries':[]}
for fname in ['support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json']:
 raw=(b/fname).read_bytes();reg=json.loads(raw);out['registrations'].append({'path':fname,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for e in reg['entries']:
  ch=chunks[e['id']];covers={i for a,z in ch for i in range(a,z+1)};missing=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covers and start is None:start=i
   elif (i>e['eof'] or i in covers) and start is not None:missing.append([start,i-1]);start=None
  out['entries'].append({'registration':fname,'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':missing,'qualification':'Personally displayed current support only; no historic role credit; any test text merely read, not run.'})
(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('recorded',len(out['entries']),'support reads')
