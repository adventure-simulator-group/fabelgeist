# Combat capability, armor and loadout source evidence

This source-only packet by `/root/rig_identity` covers original roles
2775–2779. The first role belongs to the dirty physical-p16 snapshot; the
remaining four belong to the distinct pr-working snapshot. The pinned current
revision is `95e63628f9d70b8dd6e6fede64334696c6995009`. Individual matching
source objects do not establish a clean historical worktree or transfer credit.

`REPORT.json` gives source findings, conditions, relationships, open questions
and thirteen bounded lens perspectives. `registration.json` and
`read-receipt.json` retain independently displayed historical/current ranges.
Each support registration and `support-read-receipt.json` describe separate
95e support reads, including armor helper lines 40–94; they do not expand the
original role2776 historical range. Archived full source bytes alone confer no
credit for unread complements.

`history/` retains the recovered registry, original transport manifest,
manifest-matched 059 records, f82-transported 774 records and the 059 queue
and ledger historical summaries. Selected registry and queue rows are
mechanically reconstructed from retained originals. `historical-attribution`
records prior authors and the discrepancy between registry-recorded and actual
f82 whole-registration hashes despite exact equality of selected parsed rows.
The original 059 payload Git path was unavailable in inspected stores; selected
extracted records match its original manifest by size, SHA-256 and Git blob.
`git-proofs.json` and `git-objects/` preserve raw commit/tree source paths.

The later P16 tracked patch reproduces the recorded digest; it excludes seven
untracked paths and does not establish original invocation or uninterrupted
custody. Historical evidence and these new assessments do not reconstruct the
missing checkpoint 3821. Prior current assessments retain their own authors,
source scopes and status.

For evidence integrity only, run `python3 verify-evidence.py` and
`python3 verify-manifest.py`. These do not validate product behavior. No repair,
product build, test, macro, code generation, fixture or product execution,
simulation, or runtime probe was performed. Central owns cross-lens ledger,
aliases, counts and publication.
