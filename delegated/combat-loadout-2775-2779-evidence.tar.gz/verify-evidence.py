from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile
b=Path(__file__).resolve().parent
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest()
load=lambda p:json.loads((b/p).read_bytes())
gun=lambda p:gzip.decompress((b/p).read_bytes())
history=load('historical-attribution.json');report=load('REPORT.json');names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json'];groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2775,2776,2777,2778,2779]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
p16=next(x for x in registry['snapshots'] if x['id']=='physical-p16');pr=next(x for x in registry['snapshots'] if x['id']=='pr-working')
assert p16['base']==p16['head']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(p16['status_porcelain'])==159 and sha((b/'history/p16-tracked.patch').read_bytes())==p16['patch_sha256']
assert pr['base']=='3a50b708381ad00c116445c2c999a49c3943088b' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
for x in regs.values():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
for role,ranges in [(2775,[[1,45]]),(2776,[[1,39]]),(2777,[[1,26]]),(2778,[[1,18]]),(2779,[[1,39]])]:
 old=regs[('registration.json',f'{role}-historical')];cur=regs[('registration.json',f'{role}-current')]
 assert old['sha256']==registry['files'][role]['sha256'] and old['prospective_personal_read_ranges']==registry['files'][role]['material_ranges']==ranges
 assert old['comparison_metadata']['pr_head']['equal_to_historical'] and old['comparison_metadata']['p16_base']['equal_to_historical'] and old['comparison_metadata']['current']['equal_to_historical']
 assert old['sha256']==cur['sha256'] and (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes()
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in sel['entries']]==[1768]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[1768]['contract_id']=='Q-L12-eab37babfedc890849b1'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
r=load('history/059/segovb/READ-L11-453.json')
for role,ranges in [(2775,[[1,45]]),(2776,[[1,39]]),(2777,[[1,26]]),(2778,[[1,18]]),(2779,[[1,39]])]:
 e=next(x for x in r['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==ranges and e['sha256']==registry['files'][role]['sha256']
r=load('history/059/segovb/READ-L11-481.json');e=next(x for x in r['rows'] if x['overlay_index']==202);assert e['fresh_personal_body_reads']==[[40,94]] and e['reused_ranges']==[[1,39]] and e['source_id']==registry['files'][2776]['source_id']
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
for role in range(2775,2780):
 record=registry['files'][role]
 for x in record['parallel_reached_registrations']:
  p='history/774/'+x['record'].removeprefix('continuation/')+'.gz';raw=gun(p);rows=[json.loads(z) for z in raw.splitlines()];assert sha(raw)!=x['sha256'] and rows[x['row_1based']-1]==x['original_record']
for kind in ['camera','rig']:
 path='history/774/'+('camera/initial07-redundant-authority/' if kind=='camera' else 'rig/initial06-type-ownership/')+'source-range-registration.jsonl.gz';assert sha(gun(path))==history['registration_file_hash_mismatch'][kind]['f82_actual']
for path,ids in [('camera/initial07-redundant-authority/contracts.jsonl.gz',['CAMERA-INITIAL07-CONTRACT-043','CAMERA-INITIAL07-CONTRACT-053']),('rig/initial06-type-ownership/findings.jsonl.gz',['RIG-INITIAL06-F009'])]:
 rows=[json.loads(z) for z in gun('history/774/'+path).splitlines()];assert all(any(x.get('id')==id for x in rows) for id in ids)
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==55
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
coverage={}
def record(regname,id,chunks,unread,when,recorded_sha):
 x=regs[(regname,id)];assert datetime.fromisoformat(groups[regname]['at_utc'])<datetime.fromisoformat(when);assert recorded_sha==x['sha256']
 actual={i for a,z in chunks for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in unread for i in range(a,z+1)}
 assert actual<=planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage.setdefault(id,set()).update(actual)
assigned=load('read-receipt.json');assert assigned['registration_sha256']==sha((b/'registration.json').read_bytes())
for e in assigned['entries']:record('registration.json',e['registration_id'],e['actual_display_chunks'],e['unread_complement'],assigned['at_utc'],e['sha256'])
s=load('support-read-receipt.json')
for x in s['registrations']:assert x['sha256']==sha((b/x['path']).read_bytes())
for e in s['entries']:record(e['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
assert len(regs)==30 and len(coverage)==30
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   possible=[e for (n,id),e in regs.items() if id==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive']];assert possible
   assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','registered_personal_scopes':len(regs),'assigned_historical_material':{'2775':[[1,45]],'2776':[[1,39]],'2777':[[1,26]],'2778':[[1,18]],'2779':[[1,39]]},'059_records_manifest_matched':len(history['records_059']),'774_records_git_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'bounded_lenses':13,'p16_tracked_patch_digest_verified':True,'059_original_payload_git_path':'unavailable in inspected stores; exact selected bytes match original manifest','product_build_test_fixture_execution_probe_validation':'not performed'},indent=2))
