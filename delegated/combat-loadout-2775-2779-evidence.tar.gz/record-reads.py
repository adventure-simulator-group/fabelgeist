from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;raw=(b/'registration.json').read_bytes();reg=json.loads(raw);out=[]
for e in reg['entries']:
 end=e['prospective_personal_read_ranges'][0][1];out.append({'registration_id':e['id'],'sha256':e['sha256'],'actual_display_chunks':[[1,end]],'unread_complement':[[end+1,e['eof']]] if end<e['eof'] else [],'qualification':'Separate prospectively registered historical/current body display. Stored bytes do not credit unread complement.'})
(b/'read-receipt.json').write_text(json.dumps({'schema':'726-personal-read-receipt-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(raw).hexdigest(),'entries':out},indent=2)+'\n');print('recorded',len(out),'separate personal displays')
