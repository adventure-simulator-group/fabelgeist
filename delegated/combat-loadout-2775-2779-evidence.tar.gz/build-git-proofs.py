from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';base='a120390947c89b703dc74c4255a13c035d054c50';pr='6533e444fa37552927070cc8d8190907fd3b413e';origin='039329518e264f19206cf5b0b98d177433f40c17';cur='95e63628f9d70b8dd6e6fede64334696c6995009';e275='e2755a732c84e67296b5e3441a4259a84f461b2f';regs=json.loads((b/'registration.json').read_bytes())['entries']
for role in (2775,2776,2777,2778,2779):
 h=next(x for x in regs if x['id']==f'{role}-historical');c=next(x for x in regs if x['id']==f'{role}-current')
 proof(f82,h['git_path'],h['archive'],'f82 transport of recovered dirty P16 or pr-working object; not project revision')
 for r,k in [(base,'P16 individual base file only'),(pr,'pr-working 6533 individual head file only'),(cur,'pinned current 95e source')]:proof(r,h['source_path'],h['archive'] if r!=cur else c['archive'],k)
seen=set()
for name in ['support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json']:
 for x in json.loads((b/name).read_bytes())['entries']:
  if x['git_path'] not in seen:proof(cur,x['git_path'],x['archive'],'independently registered current support; exact scopes in receipt');seen.add(x['git_path'])
for path,local in [('AGENTS.md', 'rules/root-AGENTS.md'), ('crates/AGENTS.md', 'rules/crates-AGENTS.md'), ('crates/adventuresim-core/AGENTS.md', 'rules/core-AGENTS.md'), ('crates/adventuresim-tactical-core/AGENTS.md', 'rules/tactical-core-AGENTS.md'), ('crates/adventuresim-tactical-server/src/combat/AGENTS.md', 'rules/tactical-server-combat-AGENTS.md')]:proof(cur,path,local,'applicable pinned source guide')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(x['revision'],x['transport_path'],x['preserved'],'exact historical 774 reviewer record at f82')
out={'schema':'726-combat-loadout-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Individual file identities only. f82 is evidence transport, 6533 pr-working head, a120 P16 base, 95e pinned current; no snapshot cleanliness or resolved features implied.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('git paths',len(proofs),'objects',len(objects))
