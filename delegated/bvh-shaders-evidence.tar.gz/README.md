# BVH shader source: evidence-only audit packet

This packet independently assesses original role 2660 at current pinned 95e
and recorded historical 6533 pr-working per-file identities. `report.json`
contains source references, qualified findings, historical attribution and
thirteen scoped lens perspectives.

The assigned 490-line source was separately registered and displayed at each
revision. Support registrations and receipts cover only their specified windows;
preserved whole bytes do not imply whole-file personal reads. The historical
059/774 material scope was only 391–490. In 059 Lens12, batch 920 reused the
same delegate's earlier connected read, with zero fresh rereads in that batch.

`git-proofs.json` and `git-objects/` preserve raw Git membership proofs;
`historical-index.json` lists exact recovered evidence. The queue extract is
reconstructed rather than an original standalone document. Verification uses
the publication directory containing the hash-linked registry, original
transport manifest, queue and previously published packets:

```
python3 verify-evidence.py /path/to/target/726-audit-baseline/publication
```

`verification.json` records evidence-integrity checks only. All WGSL was read
strictly as source text; no GPU, shader, product, test, build, simulation,
fixture, probe, implementation or repair ran. There is no checkpoint3821 or
whole-lens completion claim.
