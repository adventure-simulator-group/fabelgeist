import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
regraw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(regraw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(regraw);trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue);select=load('queue-selection-reconstructed.json');assert all(q['entries'][int(k)]==v for k,v in select['entries'].items());selection=load('registry-selection-reconstructed.json');assert all(registry['files'][int(k)]==v for k,v in selection['roles'].items());assert sha((p/'reference/p16-tracked.patch').read_bytes())=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for n in ['reference-index.json','rules.json','skills.json']:
 for e in load(n)['records']:
  b=(p/e['file']).read_bytes();assert sha(b)==e['sha256'],e['file']
for n in ['','support','support2','support3','support4']:
 rf=(n+'-registration.json') if n else 'registration.json';tf=(n+'-read-receipt.json') if n else 'personal-read-receipt.json';r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries']);
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'] and blob(body)==a['git_blob'];assert len(body.splitlines())==a['EOF'] and a['archive']==b['archive']; planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[n or 'assigned']=len(r['entries'])
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
for prefix,expected in [('prior-terrain','e398e4751aa4221b354d14dfdd95e5c52e646197e53aea7518f05cd6f9d281ed'),('prior-coordinates','2b32168f9d662f35970f7cff749859e152b7282660fafae9e11149e449f2111d')]:
 mb=(p/prefix/'BUNDLE-MANIFEST.json').read_bytes();assert sha(mb)==expected;m={x['path']:x for x in json.loads(mb)['files']}
 for f in ['report.json','registration.json','personal-read-receipt.json']:
  b=(p/prefix/f).read_bytes();assert (len(b),sha(b))==(m[f]['bytes'],m[f]['sha256'])
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==48
report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','scope':'offline evidence hashes, raw Git commit/tree path chains, exact original records, registry/queue, P16 tracked patch, own read receipts and historical qualifications; not product validation','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
