# Bounded P16 web route source evidence, roles 2729–2733

This packet contains independent static source inspection by
`/root/mhr_character` against pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009` and the exact original
physical-p16 archived objects. `report.json` is the human/machine review;
`registration.json`, personal and support receipts, and
`read-scope-summary.json` distinguish intended ranges from actual displays.
Archived full file bytes do not imply whole-file personal review. Tests appear
only as source text; no product, test, build, fixture, generator, macro or probe
was run.

All five per-file archived P16 objects equal the same Git path at the a120
recorded base, 6533 and 95e; raw commit/tree proofs and exact source bytes are
provided. The P16 snapshot is dirty, and equality of these files does not make
it clean. The original P16 tracked patch was later recovered and is included
with its qualifications; it does not prove the original diff command or all
untracked contents. `f82` transports historical evidence rather than claiming
an original project revision. Initial wrong-object-store claims of five absent
95e paths were withdrawn; the registered identity and path proofs show all
five present.

Historical 059 records and 774 source/qualification/finding records retain
original authors, source identities and line scopes. Lens12 proposals require
root adoption; an exact-name local search is bounded, not global absence.
`queue-selection-reconstructed.json` is a reconstructed selection of the
preserved original queue, not an original historical record. Prior reports and
receipts remain separate, with their original nested manifests verified.
Checkpoint 3821 is not inferred.

Review highlights are the existing conditional seam-interpolation queue
contract, historical conditional raw-route-point `expect` concern, historical
SATS adapter format qualifications, and scoped current planned-route
validation that rejects invalid point axes. Actual antimeridian route support,
other storage writers, native wire policy, authorization and redirect parsing
remain open; see the report. No unique-count, repair ledger or whole-lens
closure is asserted. Central coordination owns those decisions.

Run `python3 verify-evidence.py` to verify evidence identities and raw Git
object proofs offline. Run `python3 verify-manifest.py` to verify every member
including both nested prior manifests. These are evidence integrity checks,
not product validation.
