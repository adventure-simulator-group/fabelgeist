from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','purpose':'Prospective match-only navigation to find changed YAML consumers, loading and build-time producer contracts; matches are not full body or ordered-role credit.','patterns':['zero_speed_step_distance_metres','dive_airborne_root_handoff_end_fraction','combat.yaml','CombatConfig','validate','from_yaml'],'paths':['crates/adventuresim-core','crates/adventuresim-tactical-core','crates/adventuresim-tactical-client','crates/adventuresim-tactical-server']}
Path('navigation-registration.json').write_text(json.dumps(x,indent=2)+'\n')
