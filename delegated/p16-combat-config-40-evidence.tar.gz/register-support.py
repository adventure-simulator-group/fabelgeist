from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path.cwd();repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
plans=[('defaults','crates/adventuresim-tactical-core/src/combat_config/defaults.rs',[[1,100]]),('config-locomotion','crates/adventuresim-tactical-core/src/combat_config/locomotion.rs',[[1,110]]),('config-transitions','crates/adventuresim-tactical-core/src/combat_config/state_transitions.rs',[[1,80]]),('locomotion','crates/adventuresim-tactical-core/src/animation/locomotion.rs',[[130,200]]),('posture-transition','crates/adventuresim-tactical-core/src/animation/state/posture_transition.rs',[[1,120]]),('combat-build','crates/adventuresim-core/build/combat_resolution.rs',[[1,150]]),('server-startup','crates/adventuresim-tactical-server/src/startup.rs',[[1,110]]),('config-owner','crates/adventuresim-tactical-core/src/combat_config.rs',[[350,430],[600,665]])]
entries=[];pending=[]
for name,path,ranges in plans:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc='support/'+name+'.rs';eof=len(raw.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':eof,'ranges':ranges,'local':loc});pending.append((loc,raw))
(b/'support-registration.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective pinned current text-only loader, schema and changed-field consumer windows. Any build source is inspected as text and never run; no historical or ordered-role credit.','entries':entries},indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
