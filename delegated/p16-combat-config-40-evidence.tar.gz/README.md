# Bounded P16 combat-configuration evidence: role 40

`REPORT.json` records `/root/hair_ops`'s static review of the exact dirty P16
`content/tactical/combat.yaml` and the pinned current
`95e63628f9d70b8dd6e6fede64334696c6995009` source. Historical 344-line and
current 346-line YAML were separately registered and displayed as text. The
text diff records two current additions; a120, 6533 and 039 historical object
copies and the earlier e275 current copy were mechanically identity-checked,
not separately displayed. Dirty P16 remains distinct from its clean base.

`read-receipt.json` records full assigned displays, separately registered
current support, match-only navigation and unread complements. An initial
truncated navigation output was redisplayed completely in bounded chunks.
Build scripts and test bodies were inspected only as text. No product, build,
code generation, fixture, test, gameplay or runtime probe was executed and no
YAML parser was run.

The historical Camera and SEGO records and prior `/root/mhr_character` and
`/root/hair_ops` support reads retain their original attribution and revision.
After registration and the fresh displays, the 059 queue led to Root Segovb's
full e275 read of the current-identical YAML. The additive
`prior-reader-qualification.json` preserves that chronology, without claiming
the earlier reader assessed 95e or changing the original registration. Neither
history nor the later P16 tracked-patch recovery is promoted to checkpoint
3821; seven untracked entries and recovery-custody qualifications remain.

The report reconnects q688's conditional duplicate-authority concern and
narrows q1463's current typed handoff checks. Actual supported divergent
configuration, message delivery and native root behavior remain unproved.
`git-proofs.json` preserves independent commit/tree/blob chains.
`historical-selections-reconstructed.json` is explicitly a reconstructed
selection; original records are preserved separately. `MANIFEST.json`
inventories all packet files except itself, including nested manifests.

Verify evidence integrity only with:

```sh
python3 verify-evidence.py
```

This verifier checks hashes, text diff, object identities, historical
attribution links and recorded scope partitions. It does not parse YAML or
independently prove a personal display; display is the reader's receipt.
