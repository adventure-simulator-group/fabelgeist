from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path.cwd();h=lambda x:hashlib.sha256(x).hexdigest();L=lambda n:json.loads((b/n).read_bytes());reg=L('registration.json');nav={};navigation=[]
navfiles={'navigation-changed.txt':'navigation-registration.json','navigation-runtime.txt':'navigation-registration-runtime.json','navigation-sync.txt':'navigation-registration-sync.json','navigation-snapshot.txt':'navigation-registration-snapshot.json','navigation-send.txt':'navigation-registration-send.json','navigation-authority.txt':'navigation-registration-authority.json','navigation-autoresolve.txt':'navigation-registration-autoresolve.json','navigation-types.txt':'navigation-registration-types.json'}
for name,rn in navfiles.items():
 raw=(b/name).read_bytes();lines=raw.decode().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m,(name,line);nav.setdefault(m.group(1),set()).add(int(m.group(2)))
 chunks=[[1,100],[101,201]] if name=='navigation-sync.txt' else [[1,55],[56,111]] if name=='navigation-autoresolve.txt' else [[1,len(lines)]] if lines else []
 navigation.append({'output':name,'sha256':h(raw),'saved_output_lines':len(lines),'personally_displayed_output_lines':chunks,'unread_saved_output_lines':[],'registration':rn,'ordered_role_credit':0,'qualification':'Initial autoresolve output was truncated; complete bounded redisplays 1–55 and 56–111 are recorded. Match lines are navigation only; test source matches not executed.' if name=='navigation-autoresolve.txt' else 'Match-only source navigation, no body/role credit; test-source matches not executed.'})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=[[1,90],[91,180],[181,270],[271,344 if not j else 346]];used=nums(d);extra=sorted(nav.get(row['path'],set())-used) if j else [];assigned.append({'original_index':40,'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if not j else v['revision'],'local':v['local'],'sha256':v['sha256'],'eof':v['eof'],'actual_display_chunks':d,'original_registry_material_ranges':row['original_material_ranges'] if not j else None,'navigation_only_lines_at_assigned_scope':extra,'unread_complement':comp(v['eof'],used|set(extra)),'qualification':'Old/current YAML separately displayed in full, text only; no YAML parser, fixture or product execution; comparison versions mechanically verified not displayed.'})
support=[];files=['support-registration.json','support-registration-runtime.json','support-registration-network.json','support-registration-authority.json','support-registration-validation.json','support-registration-types.json','support-registration-speed-extra.json']
for rn in files:
 for x in L(rn)['entries']:
  d=x['ranges'];used=nums(d);navonly=sorted(nav.get(x['path'],set())-used)
  support.append({'name':x['name'],'registration':rn,'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'navigation_only_lines':navonly,'unread_complement':comp(x['eof'],used|set(navonly)),'ordered_role_credit':0,'qualification':'Current support only. Same-path overlapping support windows remain separate; startup test text 76–110 was read, not executed. Build source only, never executed.'})
names=['registration.json',*files,*dict.fromkeys(navfiles.values())];d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Reconstructed actual source displays and match-only navigation after prospective registrations.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':L(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{k:sorted(v) for k,v in sorted(nav.items())},'prior_readers':'registration.json/previous_personal_support and additive prior-reader-qualification.json; no transfer of historical/ordered-role credit.','limits':'No product, YAML parsing, generated code, gameplay, fixtures, tests, builds, probes, repairs or publication edits.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt sha256',h((b/'read-receipt.json').read_bytes()))
