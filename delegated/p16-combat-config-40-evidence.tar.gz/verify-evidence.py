'''Offline evidence integrity, text comparison and Git identity only; no product or YAML parsing.'''
from pathlib import Path
from datetime import datetime
import difflib,gzip,hashlib,json,re,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();L=lambda n:json.loads((b/n).read_bytes())
reg=L('registration.json');rec=L('read-receipt.json');hist=L('historical-manifest.json');sel=L('historical-selections-reconstructed.json');proof=L('git-proofs.json');report=L('REPORT.json');ids=[40]
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
arch=L('recovered/MANIFEST.json');rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256']==arch['registry_sha256'];assert h((b/'recovered/registry.json.gz').read_bytes())==arch['registry_gzip_sha256'];assert h((b/'recovered/objects.tar.gz').read_bytes())==arch['objects_archive_sha256'];r=json.loads(rbytes);original=r['files'];assert original[40]==sel['registry_rows']['40'];assert sel['snapshot_rows']==[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')]
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];q=json.loads(qbytes);assert all(q['entries'][int(i)]==x for i,x in sel['queue_rows'].items());cv=L('prior/COVERAGE-L01-ROLES.json');assert h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes())==sel['prior_coverage_sha256'];assert next(x for x in cv['roles'] if x['original_index']==40)==sel['prior_coverage_roles']['40']
snap=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=L('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['live_comparison']['status_counts']['??']==7
catalog=L('recovered/catalog-774.json')['rows'];row=reg['rows'][0];old,cur=row['versions'];raw=(b/old['local']).read_bytes();now=(b/cur['local']).read_bytes();assert row['original_index']==40 and row['fresh_display_plan']==[[1,344]] and row['original_material_ranges']==original[40].get('material_ranges')
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:assert t.extractfile(old['sha256']).read()==raw
assert h(raw)==old['sha256']==original[40]['sha256']==catalog[40]['expected_sha256'] and h(now)==cur['sha256'] and now!=raw and not cur['equals_historical_object'];assert catalog[40]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path']
for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==raw and c['equals_historical_object'] and not c['display_planned']
diff=''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),now.decode().splitlines(keepends=True),fromfile='physical-p16',tofile='95e'));assert diff==(b/'source-diff.patch').read_text();added=[line[1:].strip() for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++')];removed=[line for line in diff.splitlines() if line.startswith('-') and not line.startswith('---')];assert added==['zero_speed_step_distance_metres: 0.9','dive_airborne_root_handoff_end_fraction: 0.92'] and removed==[]
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(x['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(rr):return [i for a,z in rr for i in range(a,z+1)]
def part(n,rr,extra=[]):
 v=nums(rr)+extra;return len(v)==n and set(v)==set(range(1,n+1))
for j,v in enumerate(row['versions']):
 x=next(x for x in rec['assigned'] if x['local']==v['local']);body=(b/x['local']).read_bytes();assert h(body)==v['sha256']==x['sha256'] and len(body.splitlines())==v['eof']==x['eof'];assert part(v['eof'],x['actual_display_chunks']+x['unread_complement'],x['navigation_only_lines_at_assigned_scope']) and set(nums(x['actual_display_chunks']))==set(range(1,v['eof']+1))
plans={x['name']:x for n in ['support-registration.json','support-registration-runtime.json','support-registration-network.json','support-registration-authority.json','support-registration-validation.json','support-registration-types.json','support-registration-speed-extra.json'] for x in L(n)['entries']};assert len(plans)==len(rec['support'])
for x in rec['support']:
 p=plans[x['name']];body=(b/x['local']).read_bytes();assert h(body)==x['sha256']==p['sha256'] and len(body.splitlines())==x['eof'] and x['ordered_role_credit']==0;assert set(nums(x['full_line_body_displays']))==set(nums(p['ranges'])) and part(x['eof'],x['full_line_body_displays']+x['unread_complement'],x['navigation_only_lines'])
nav={}
for x in rec['navigation_output_receipts']:
 raw0=(b/x['output']).read_bytes();lines=raw0.decode().splitlines();assert h(raw0)==x['sha256'] and len(lines)==x['saved_output_lines'];displayed=nums(x['personally_displayed_output_lines']);unread=nums(x['unread_saved_output_lines']);assert set(displayed+unread)==set(range(1,len(lines)+1)) and len(displayed)+len(unread)==len(lines)
 for j in displayed:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):(.*)$',lines[j-1]);assert m;path,num,body=m.group(1),int(m.group(2)),m.group(3);nav.setdefault(path,set()).add(num)
  for p in rec['support']:
   if p['path']==path:assert (b/p['local']).read_text().splitlines()[num-1]==body
assert {k:sorted(v) for k,v in nav.items()}==rec['navigation_actual_source_lines']
objs={}
for key,x in proof['objects'].items():
 data=gzip.decompress((b/x['preserved']).read_bytes());assert h(data)==x['sha256'] and len(data)==x['bytes'] and oid(x['type'],data)==key;objs[key]=data
def lookup(data,n):
 i=0
 while i<len(data):
  z=data.index(b'\0',i);mode,name=data[i:z].split(b' ',1);child=data[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 data=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',data) and h(data)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
cam=readjsonl('historical/774/00-additional-sources.jsonl');source=readjsonl('historical/774/01-sources.jsonl');o=original[40]['owner_contract_proofs'][0];r0=cam[o['row']];assert r0['source_id']==original[40]['source_id'] and r0['sha256']==original[40]['sha256'] and r0['read_ranges']==o['read_ranges']==[[1,344]];o=original[40]['producer_reached_contract_observations'][0];assert next(x for x in source if x.get('id')==o['receipt'])==o['source_context']
coverage=readjsonl('historical/059/evidence/audit11/inherited-coverage.jsonl');z=next(x for x in coverage if x.get('scope_index')==40);assert z['sha256']==original[40]['sha256'] and z['ranges']==[[1,344]];assert h((b/'historical/059/segovb/INHERITED-L11-CONTRACT-010.json').read_bytes())=='228e4d70930617c6be2f1e654ccc92a9240ba3e2f8b75ecb24986b2c87a11191'
e=L('historical/059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-010.json');y=next(x for x in e['rows'] if x.get('git_path')=='content/tactical/combat.yaml');assert y['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and y['sha256']==h(now) and y['fresh_personal_body_ranges']==[[1,346]] and y['git_blob']==cur['git_blob'];assert h((b/'historical/059/root-l1-current-e275-20261029/REGISTRATION-ROOT-L1-CURRENT-010.json').read_bytes())==e['registration_sha256']
r12=L('historical/059/segovb/READ-L12-578.json');v=next(x for x in r12['rows'] if x['original_index']==1786);assert v['fresh_personal_body_reads']==[[1,158]] and h((b/'historical/059/segovb/REGISTRATION-SEGOVB-L12-693.json').read_bytes())==v['registration_sha256'];assert h((b/'historical/059/segovb/PLAN-L12-578.json').read_bytes())==r12['plan_sha256']
p=L('prior-reader-qualification.json');assert datetime.fromisoformat(p['created_utc'])>datetime.fromisoformat(reg['created_utc']) and p['earlier_full_read']['receipt_sha256']==h((b/p['earlier_full_read']['receipt']).read_bytes());assert p['earlier_full_read']['actual_ranges']==[[1,346]] and p['earlier_full_read']['revision']==y['revision'];assert all(h((b/x['path']).read_bytes())==x['sha256'] for x in p['other_prior_read_receipts'])
assert len(proof['proofs'])==37 and len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and report['support_personal_displays']==rec['support'];assert all(h((b/x['path']).read_bytes())==x['sha256'] for x in report['related_evidence'])
if (b/'MANIFEST.json').exists():
 seen=set()
 for x in L('MANIFEST.json')['files']:
  data=(b/x['path']).read_bytes();assert h(data)==x['sha256'] and len(data)==x['bytes'],x['path'];seen.add(x['path'])
 assert seen=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p!=b/'MANIFEST.json'}
print('PASS: role 40 old/current separate text displays, two-line revision diff, original/reconstructed records, e275 prior reader qualification, 37 Git proofs and 13 bounded lenses. Evidence integrity only; no YAML parsing or product execution.')
