from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile,difflib
b=Path(__file__).resolve().parent
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest()
load=lambda p:json.loads((b/p).read_bytes())
gun=lambda p:gzip.decompress((b/p).read_bytes())
history=load('historical-attribution.json');report=load('REPORT.json')
names=['registration.json','lib-compare-registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json','historical-support-registration.json']
groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json')
assert [x['original_index'] for x in sel['rows']]==[332,2316,2317,2318,2319,2320,2321,2322,2748,2749,2750,2751]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
p16=next(x for x in registry['snapshots'] if x['id']=='physical-p16');pr=next(x for x in registry['snapshots'] if x['id']=='pr-working')
assert p16['base']==p16['head']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(p16['status_porcelain'])==159 and sha((b/'history/p16-tracked.patch').read_bytes())==p16['patch_sha256']
assert pr['base']=='3a50b708381ad00c116445c2c999a49c3943088b' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
for x in regs.values():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
for role,ranges in [(2748,[[1,50]]),(2749,[[1,76]]),(2750,[[31,43]]),(2751,[[1,110]])]:
 old=regs[('registration.json',f'{role}-historical')];cur=regs[('registration.json',f'{role}-current')]
 assert old['sha256']==registry['files'][role]['sha256'] and old['prospective_personal_read_ranges']==registry['files'][role]['material_ranges']==ranges
 assert old['comparison_metadata']['pr_head']['equal_to_historical']
 if role==2750:assert old['sha256']!=cur['sha256']
 else:assert old['sha256']==cur['sha256'] and (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes()
p=regs[('historical-support-registration.json','p16-visuals')];assert p['sha256']==registry['files'][332]['sha256']
assert (b/p['archive']).read_bytes().splitlines()[:50]==(b/'sources/2748-historical.source').read_bytes().splitlines()[:50]
a=(b/'sources/2750-historical.source').read_text().splitlines(keepends=True);c=(b/'sources/2750-current.source').read_text().splitlines(keepends=True)
assert ''.join(difflib.unified_diff(a,c,fromfile='historical-pr-working',tofile='95e',n=3))==(b/'lib-historical-to-current.diff').read_text()
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json')
assert [x['original_index_zero_based'] for x in sel['entries']]==[165,166,167,168,169,170,171,1201,1202,1203,1204]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[171]['contract_id']=='ADLER-L11-MHR-BIND-TRANSFORM-ADMISSION' and q[1204]['contract_id']=='Q-L12-4d5057d03d6c602d2348'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']]
 assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
rr=load('history/059/segovb/READ-L11-450.json')
for role,ranges in [(2748,[[1,50]]),(2749,[[1,76]]),(2750,[[31,43]]),(2751,[[1,110]])]:
 e=next(x for x in rr['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==ranges
r=load('history/059/parallel-l11-20261029/READ-185.json');e=next(x for x in r['rows'] if x['registration']=='PL11-1174')
assert e['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and e['fresh_personal_body_ranges']==[[1,43]] and e['sha256']==regs[('registration.json','2750-current')]['sha256']
r=load('history/059/segovb/READ-L11-721.json');e=next(x for x in r['adopted_registration_mapping'] if x['registration']=='PL11-1174');assert e['adopted_continuation_number']==3368 and 'no root reread' in e['qualification'] and not r['new_target_reconciliation_complete']
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d)
 assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
for supplier,roles in [('camera',[2748,2749]),('rig',[2750,2751])]:
 p='history/774/'+('camera/initial07-redundant-authority/' if supplier=='camera' else 'rig/initial06-type-ownership/')+'source-range-registration.jsonl.gz'
 raw=gun(p);rows=[json.loads(z) for z in raw.splitlines()]
 for role in roles:
  x=registry['files'][role]['parallel_reached_registration'];assert sha(raw)!=x['sha256'] and rows[x['row_1based']-1]==x['original_record']
assert history['registration_file_hash_mismatch']['camera_registry_recorded']=='63b443ce4e9b3873b45f5ca97518fc6965a323b2b52eede501655d1a861b2308' and history['registration_file_hash_mismatch']['camera_f82_original_actual']==sha(gun('history/774/camera/initial07-redundant-authority/source-range-registration.jsonl.gz'))
assert history['registration_file_hash_mismatch']['rig_registry_recorded']=='3c030ef626adf1034e7a71d9ae2ceb50a484632aac09222d67fe75046cfbebb0' and history['registration_file_hash_mismatch']['rig_f82_original_actual']==sha(gun('history/774/rig/initial06-type-ownership/source-range-registration.jsonl.gz'))
for i,j in [(814,2748),(815,2749),(816,2750),(817,2751)]:
 rr=load(f'history/059/parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json');qq=load(f'history/059/parallel-l12-20261029/QUALIFICATION-PAR-L12-{i}-ORIGINAL{j}.json');assert rr['original_index']==j and rr['prospective_body_status']=='not read at registration' and qq['no_body_credit']
rigquals=[json.loads(z) for z in gun('history/774/rig/initial06-type-ownership/qualifications.jsonl.gz').splitlines()]
assert 'no credit' in next(x['correction'] for x in rigquals if x['id']=='RIG-INITIAL06-QUAL-001')
camfind=[json.loads(z) for z in gun('history/774/camera/initial07-redundant-authority/findings.jsonl.gz').splitlines()]
assert all(any(x['id']==id for x in camfind) for id in ['CAMERA-INITIAL07-F001','CAMERA-INITIAL07-F003','CAMERA-INITIAL07-F004'])
for x in history['prior_packets']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
  members={m.name for m in t.getmembers() if m.isfile()};mraw=t.extractfile(x['manifest_name']).read();assert sha(mraw)==x['manifest_sha256'];m=json.loads(mraw)
  assert {f['path'] for f in m['files']}|{x['manifest_name']}<=members
  for f in m['files']:
   raw=t.extractfile(f['path']).read();assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
  assert sha(t.extractfile(x['report_name']).read())==x['report_sha256']
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==51
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes()
 assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
coverage={}
def record(regname,id,chunks,unread,when,recorded_sha):
 x=regs[(regname,id)];assert datetime.fromisoformat(groups[regname]['at_utc'])<datetime.fromisoformat(when)
 assert recorded_sha==x['sha256']
 actual={i for a,z in chunks for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in unread for i in range(a,z+1)}
 assert actual<=planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1))
 coverage.setdefault(id,set()).update(actual)
assigned=load('read-receipt.json');assert assigned['registration_sha256']==sha((b/'registration.json').read_bytes())
for e in assigned['entries']:record('registration.json',e['registration_id'],e['actual_display_chunks'],e['unread_complement'],assigned['at_utc'],e['sha256'])
s=load('lib-compare-read-receipt.json');assert s['registration_sha256']==sha((b/'lib-compare-registration.json').read_bytes())
for e in s['entries']:record('lib-compare-registration.json',e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
s=load('support-read-receipt.json')
for x in s['registrations']:assert x['sha256']==sha((b/x['path']).read_bytes())
for e in s['entries']:record(e['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
s=load('historical-support-read-receipt.json');assert s['registration_sha256']==sha((b/s['registration']).read_bytes())
for e in s['entries']:record(s['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
assert len(regs)==31 and len(coverage)==29
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   possible=[e for (n,id),e in regs.items() if id==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive']];assert possible
   assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','registered_personal_scopes':len(regs),'assigned_historical_material':{'2748':[[1,50]],'2749':[[1,76]],'2750':[[31,43]],'2751':[[1,110]]},'059_records_manifest_matched':len(history['records_059']),'774_records_git_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'prior_exact_packets_verified':len(history['prior_packets']),'bounded_lenses':13,'p16_tracked_patch_digest_verified':True,'059_original_payload_git_path':'unavailable in inspected stores; exact selected bytes match original manifest','product_build_test_fixture_execution_probe_validation':'not performed'},indent=2))
