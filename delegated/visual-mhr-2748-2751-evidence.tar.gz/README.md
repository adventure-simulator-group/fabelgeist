# Bounded equipment-visual, MHR and transform evidence

Original roles 2748–2751 are frozen pr-working source objects transported by
f82; 6533 is the recorded pr-working head and does not make the overall dirty
snapshot clean. Three assigned source files individually match current 95e.
MHR library role2750 differs; its complete source comparison and registered
personal context reads are retained. The P16 equipment-visual sibling is a
separate dirty-snapshot object with a different full hash.

Start with REPORT.json, the role and support registrations, read receipts and
historical-attribution.json. Full source bytes do not confer full-read credit.
Original 059 queue and ledger are historical summaries; selected registry and
queue rows are marked mechanical reconstructions. Checkpoint 3821 is missing.

The original registry cites whole-file Camera and Rig registration hashes
63b443... and 3c030e..., while the f82 registration files hash 046842... and
8770f5.... Selected parsed rows match exactly, but the whole-file variants
specified in the registry were not found in the inspected local collections;
the cause is unknown. Root visual-pipeline-role-083 does match its recorded
whole-file hash. Do not treat selected-row equality as whole-file identity.

The P16 tracked patch was later reproduced with the original digest; seven
untracked paths are separate and the original command and uninterrupted
custody remain unproved. Exact selected 059 records match the original
transport manifest, although their original payload Git paths were unavailable
in the inspected stores.

Run python3 verify-evidence.py and python3 verify-manifest.py to verify retained
evidence and packet integrity only. These do not execute product code. Earlier
peer evidence is included with original authors and manifests; any public copy
with redacted paths is a separately hashed reconstruction.
