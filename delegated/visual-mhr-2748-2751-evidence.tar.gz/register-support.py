from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();(b/'support').mkdir(exist_ok=True)
spec=[('mhr-math','crates/fabelgeist-mhr/src/math.rs',[[125,200]]),('generic-transform-extra','crates/fabelgeist-math/src/transform.rs',[[111,178]]),('matrix-owner','crates/fabelgeist-math/src/matrix/mat4.rs',[[1,20],[170,255]]),('vec3-normalize','crates/fabelgeist-math/src/vector/vec3.rs',[[60,102]]),('morph-plugin','crates/adventuresim-tactical-client/src/animation/presentation/plugin.rs',[[1,75]]),('rig-loading','crates/adventuresim-tactical-client/src/animation/loading.rs',[[150,225]]),('skeletal-owner','crates/adventuresim-tactical-client/src/animation/skeletal_proportions.rs',[[1,140]]),('vertex-count','crates/fabelgeist-mhr/src/character/vertices.rs',[[1,100]]),('corrective-archive','crates/fabelgeist-mhr/src/correctives/archive.rs',[[1,80]]),('corrective-input','crates/fabelgeist-mhr/src/correctives/input.rs',[[1,90]])]
rows=[]
for tag,path,ranges in spec:
 r=subprocess.run(['git','-C',repo,'show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if r.returncode!=0:print('UNAVAILABLE',path);continue
 d=r.stdout;eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/'+tag+'.source';(b/dest).write_bytes(d);rows.append({'id':tag,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Independently registered bounded current support only; no transfer from previous reviews and no ordered-role, product execution or validation credit.'})
out={'schema':'726-prospective-visual-mhr-support-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
