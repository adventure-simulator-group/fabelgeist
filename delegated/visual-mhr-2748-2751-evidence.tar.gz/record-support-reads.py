from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent
chunks={'mhr-math':[[125,162],[163,200]],'generic-transform-extra':[[111,144],[145,178]],'matrix-owner':[[1,20],[170,212],[213,255]],'vec3-normalize':[[60,102]],'morph-plugin':[[1,38],[39,75]],'rig-loading':[[150,187],[188,225]],'skeletal-owner':[[1,47],[48,94],[95,140]],'vertex-count':[[1,50],[51,100]],'corrective-archive':[[1,40],[41,80]],'corrective-input':[[1,45],[46,90]],'matrix-identity':[[21,45]],'mhr-math-aliases':[[1,25]],'animation-transform-caller':[[1,35],[36,70]],'auto-rigger-caller':[[1,45],[46,90],[330,370]],'matrix-identity-tail':[[46,55]],'mhr-manifest':[[1,31]],'animation-manifest':[[1,18]],'math-manifest':[[1,17]],'equipment-spawn':[[428,472],[473,516]],'placeholder-visual':[[1,32],[33,63]]}
out={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':[],'entries':[]}
for fname in ['support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json']:
 raw=(b/fname).read_bytes();reg=json.loads(raw);out['registrations'].append({'path':fname,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for e in reg['entries']:
  ch=chunks[e['id']];covers={i for a,z in ch for i in range(a,z+1)};missing=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covers and start is None:start=i
   elif (i>e['eof'] or i in covers) and start is not None:missing.append([start,i-1]);start=None
  out['entries'].append({'registration':fname,'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':missing,'qualification':'Personally displayed current support only; no historic role credit; any test text merely read, not run.'})
(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('recorded',len(out['entries']),'support reads')
