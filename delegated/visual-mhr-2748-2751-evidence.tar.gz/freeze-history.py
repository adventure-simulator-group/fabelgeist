from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
ex=Path('<LOCAL_PATH_1>')
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d)
 return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[]
for src,dest,kind in [
 ('recovered/original-registry-source-archive/registry.json.gz','history/original-registry.json.gz','original recovered registry'),
 ('recovered/original-transport-manifest.json.gz','history/original-transport-manifest.json.gz','original 059 transport manifest'),
 ('RECOVERY-PHYSICAL-P16-PATCH-20261111.json','history/p16-patch-recovery.json','later independently reproduced tracked patch report'),
 ('recovered/physical-p16-patch-recovery/tracked.patch','history/p16-tracked.patch','matching P16 tracked patch; seven untracked paths excluded'),
 ('ASSESSMENT-PROPORTION-ROUTE-CONNECTIONS-95E.json','history/assessment-proportion-route-95e.json','previous current proportion and shared-reference findings'),
 ('ASSESSMENT-EQUIPMENT-PRESENTATION-95E.json','history/assessment-equipment-presentation-95e.json','previous current equipment presentation observation'),
 ('ASSESSMENT-EQUIPMENT-HARNESS-BOUNDARIES-95E.json','history/assessment-equipment-harness-95e.json','previous current equipment harness support'),
 ('ASSESSMENT-L01-HISTORICAL-331-332.json','history/assessment-historical-331-332.json','separate earlier P16 historical role332 source read')]:
 refs.append({'kind':kind,'original':src,**save((pub/src).read_bytes(),dest)})
for src,dest in [('baseline-059/queue.json','history/baseline-059-queue.json.gz'),('baseline-059/ledger.json','history/baseline-059-ledger.json.gz')]:
 raw=(pub/src).read_bytes();refs.append({'kind':'059 historical summary mechanically compressed; not final 3821','original':src,'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(gzip.compress(raw,mtime=0),dest)})
registry=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()));idx={v['path']:v for v in json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()))['entries']}
inds=[332,2316,2317,2318,2319,2320,2321,2322,2748,2749,2750,2751]
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanically selected rows from retained original registry. Roles332 and2316–2322 are historical context, not newly assigned role credit. No checkpoint3821 promotion.','rows':[{'original_index':i,**registry['files'][i]} for i in inds],'snapshots':[x for x in registry['snapshots'] if x['id'] in ('physical-p16','pr-working')]},indent=2)+'\n')
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries'];qi=[165,166,167,168,169,170,171,1201,1202,1203,1204]
(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-059-queue-reconstruction-v1','qualification':'Mechanically selected historical queue rows, no new status/count or assumed alias.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in qi]},indent=2)+'\n')
paths=['segovb/READ-L11-450.json','segovb/REGISTRATION-SEGOVB-1667.json','segovb/REGISTRATION-SEGOVB-1668.json','segovb/REGISTRATION-SEGOVB-1669.json','segovb/REGISTRATION-SEGOVB-1670.json','segovb/STATE-L11-450.json','segovb/VERIFY-L11-450.json','segovb/READ-L11-721.json','parallel-l11-20261029/READ-185.json','parallel-l11-20261029/VERIFY-185.json','parallel-l11-20261029/PLAN-203.json','parallel-l11-20261029/PROPOSAL-BUNDLE-L11-SOURCE-010.json']
paths += [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json' for i in range(814,818)] + [f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{i}-ORIGINAL{j}.json' for i,j in [(814,2748),(815,2749),(816,2750),(817,2751)]] + ['parallel-l12-20261029/PARTIAL-PAR-L12-957-001.json','parallel-l12-20261029/PARTIAL-PAR-L12-957-002.json']
records=[]
for p in paths:
 raw=(ex/p).read_bytes();m=idx[p];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob']
 records.append({'original_path':p,'git_blob':m['git_blob'],**save(raw,'history/059/'+p)})
old=[];prefix='handoff/774/adler-original/audit/continuation/'
for p in ['camera/initial07-redundant-authority/source-range-registration.jsonl','camera/initial07-redundant-authority/additional-sources.jsonl','camera/initial07-redundant-authority/contracts.jsonl','camera/initial07-redundant-authority/findings.jsonl','camera/initial07-redundant-authority/qualifications.jsonl','camera/initial07-redundant-authority/coverage.jsonl','root/admission03/new-visual-pipeline-role-083.json','rig/initial06-type-ownership/source-range-registration.jsonl','rig/initial06-type-ownership/additional-sources.jsonl','rig/initial06-type-ownership/qualifications.jsonl','rig/initial06-type-ownership/contracts-005.json','rig/initial06-type-ownership/contracts-006.json','rig/initial06-type-ownership/coverage.jsonl']:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+prefix+p])
 old.append({'revision':rev,'transport_path':prefix+p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+p+'.gz')})
prior=[]
for directory,manifest,report,author in [('<LOCAL_PATH_2>','BUNDLE-MANIFEST.json','report.json','/root/mhr_character'),('<LOCAL_PATH_3>','BUNDLE-MANIFEST.json','report.json','/root/mhr_character')]:
 d=Path(directory);mraw=(d/manifest).read_bytes();m=json.loads(mraw)
 for f in m['files']:
  raw=(d/f['path']).read_bytes();assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
 archive=b/('history/'+d.name+'-exact-local.tar.gz')
 with tarfile.open(archive,'w:gz') as t:
  for f in sorted(d.rglob('*')):
   if f.is_file():t.add(f,arcname=str(f.relative_to(d)),recursive=False)
 prior.append({'original_directory':directory,'author':author,'manifest_name':manifest,'manifest_sha256':sha(mraw),'report_name':report,'report_sha256':sha((d/report).read_bytes()),'qualification':'Exact prior local packet preserved with original reviewer and read scope. Public path redaction produces reconstructed bytes and separate hashes.','preserved':str(archive.relative_to(b)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size})
out={'schema':'726-visual-mhr-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_059':records,'records_774':old,'registration_file_hash_mismatch':{'camera_registry_recorded':'63b443ce4e9b3873b45f5ca97518fc6965a323b2b52eede501655d1a861b2308','camera_f82_original_actual':'0468421dafdd1987a398ee9c63762859be9544a5b012ccb8bc7d6833d7dffddf','rig_registry_recorded':'3c030ef626adf1034e7a71d9ae2ceb50a484632aac09222d67fe75046cfbebb0','rig_f82_original_actual':'8770f5b2d71c63d66c9fb8035fd73c4dab9c7a8a1bf67063bbe55831b1c7187b','qualification':'The selected parsed rows of both f82 files exactly equal registry embedded original_record fields; the whole-file hashes differ. The registry-hash whole-file variants were not found in the inspected local collections, and the cause of the mismatch is unknown. Neither selected-row equivalence nor Git provenance proves whole-file identity.'},'prior_packets':prior,'qualification':'059 extracted bytes match original transport manifest size/SHA/Git blob; original payload Git path unavailable in inspected stores. f82 is evidence transport only. Matching P16 tracked patch does not prove original command or uninterrupted custody; seven untracked paths excluded. Do not promote historical records into missing checkpoint3821.'}
(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n')
print('references',len(refs),'059',len(records),'774',len(old),'prior archive bytes',[x['bytes'] for x in prior])
