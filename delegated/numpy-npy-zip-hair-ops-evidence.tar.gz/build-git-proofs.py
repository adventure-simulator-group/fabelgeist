'''Store commit/tree membership evidence without execution of product code.'''
import gzip,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());objects={};proofs=[];(p/'git-objects').mkdir(exist_ok=True)
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f=f'git-objects/{oid}.{t}.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':h(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for x in reg['rows']:
 members.extend([{'revision':x['f82_transport_revision'],'path':x['f82_transport_path'],'local':x['old_archive'],'qualification':'Historical pr-working source transport only.'},{'revision':reg['comparison_revision'],'path':x['path'],'local':x['old_archive'],'qualification':'6533 per-file identity; no separate historical body display.'},{'revision':reg['current_revision'],'path':x['path'],'local':f"source/{x['role']}-95e6.rs",'qualification':'Current 95e separately displayed.'}])
for n in ['support-registration.json']:
 for s in json.loads((p/n).read_bytes())['sources']:members.append({'revision':s['revision'],'path':s['path'],'local':s['saved'],'qualification':'Prospectively registered bounded current support; see personal receipt.'})
for x in reg['rows']:
 members.append({'revision':'e2755a732c84e67296b5e3441a4259a84f461b2f','path':x['path'],'local':f"source/{x['role']}-95e6.rs",'qualification':'Earlier e275 comparison only; no fresh personal e275 body display.'})
members.append({'revision':reg['current_revision'],'path':'crates/fabelgeist-numpy-storage/Cargo.lock','local':'support/child-Cargo.lock','qualification':'Current child lock provenance; native package is not project Git source.'})
for s in members:
 root=obj('commit',s['revision']).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for name in s['path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert tree==blob(b);proofs.append({**s,'commit_tree':root,'chain':chain,'blob':tree,'sha256':h(b)})
(p/'git-proofs.json').write_text(json.dumps({'objects':objects,'proofs':proofs,'qualification':'f82 transport, 6533 original comparison, and 95e working source are distinct. Archived bytes are not personal read credit.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects))
