'''Prospective bounded current NPY admission support; source text only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/fabelgeist-numpy-storage/src/npy/header.rs',[[1,250]]),('crates/fabelgeist-numpy-storage/src/npy/header/frame.rs',[[1,130]]),('crates/fabelgeist-numpy-storage/src/npy/metadata.rs',[[1,200]]),('crates/fabelgeist-numpy-storage/src/npy/tensor.rs',[[1,120]]),('crates/fabelgeist-numpy-storage/src/npy/values.rs',[[1,180]]),('crates/fabelgeist-numpy-storage/src/zip/member_count.rs',[[1,50]]),('crates/fabelgeist-numpy-storage/src/zip/extent.rs',[[1,44]])];a=[]
for i,(path,ranges) in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);ranges=[[x,min(y,eof)] for x,y in ranges if x<=eof];a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Fresh current bounded support only, no prior or ordered-role credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest());print([(x['path'],x['eof'],x['prospective_ranges']) for x in a])
