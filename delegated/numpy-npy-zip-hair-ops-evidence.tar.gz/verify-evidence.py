'''Evidence-integrity verification only; no product execution or validation.'''
import gzip,hashlib,json,tarfile,tomllib
from datetime import datetime
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');report=load('REPORT.json')
for x in hist['hash_links']:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
for x in hist['exact_original_files']:
 b=(p/x['local']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'] and Path(x['source_path']).read_bytes()==b,x['local']
for x in rec['registrations']:
 assert h((p/x['path']).read_bytes())==x['sha256'];assert datetime.fromisoformat(load(x['path'])['registered_utc'])<=datetime.fromisoformat(rec['recorded_utc'])
registry=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/registry.json.gz')));rb=gzip.decompress(registry.read_bytes());assert h(rb)==reg['registry_uncompressed_sha256'];original=json.loads(rb)['files']
archive=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/objects.tar.gz')));assert h(archive.read_bytes())==reg['source_archive_sha256']
with tarfile.open(archive,'r:gz') as t:
 for x in reg['rows']:
  old=(p/x['old_archive']).read_bytes();prev=(p/f"source/{x['role']}-6533.rs").read_bytes();new=(p/f"source/{x['role']}-95e6.rs").read_bytes()
  assert original[x['role']]==x['original_registry_record'] and h(old)==x['old_sha256'] and old==prev==t.extractfile(x['old_sha256']).read() and old!=new
  assert len(old.splitlines())==x['old_lines'] and h(new)==x['git_comparisons'][reg['current_revision']]['sha256']
  rr=next(v for v in rec['assigned'] if v['role']==x['role']);assert rr['unread_old_and_current']==[]
  for key,pk,n in [('pr_working_actual_display','pr_working',len(old.splitlines())),('current_95e_actual_display','current95e',len(new.splitlines()))]:
   assert [i for a,z in rr[key] for i in range(a,z+1)]==list(range(1,n+1))
   for a,z in rr[key]:assert any(c<=a<=z<=d for c,d in x['prospective_display'][pk])
planned={}
for n in [v['path'] for v in rec['registrations'] if v['path'].startswith('support-registration')]:
 for x in load(n)['sources']:
  if x['saved'] not in planned: planned[x['saved']]=dict(x)
  else: planned[x['saved']]['prospective_ranges']+=x['prospective_ranges']
for x in rec['support']:
 s=planned[x['saved']];b=(p/x['saved']).read_bytes();assert h(b)==x['sha256']==s['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==x['eof']==s['eof'];used=[]
 for a,z in x['displayed']+x['unread_complement']:assert 1<=a<=z<=x['eof'];used.extend(range(a,z+1))
 assert len(used)==x['eof'] and set(used)==set(range(1,x['eof']+1))
 for a,z in x['displayed']:assert any(c<=a<=z<=d for c,d in s['prospective_ranges'])
objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 raise ValueError(name)
for x in proof['proofs']:
 current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for s in x['chain']:
  assert current==s['tree'] and lookup(objects[current],s['name'])==(s['mode'],s['object']);current=s['object']
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and h(b)==x['sha256']
with tarfile.open(hist['prior_774_records_in_published_archive']['archive'],'r:gz') as t:
 rr=[json.loads(v) for v in t.extractfile('historical/774-rig-source-range-registration.jsonl').read().splitlines()];add=[json.loads(v) for v in t.extractfile('historical/774-rig-additional-contracts.jsonl').read().splitlines()]
 for x,num,ranges in zip(reg['rows'],[129,130],[[[1,186]],[[1,232]]]):
  for ob in x['original_registry_record']['admission03_scope_observations']:assert rr[ob['row_1based']-1]==ob['original_record']
  a=next(v for v in add if v['id']==f'RIG-ADMISSION03-ADDITIONAL-{num:03}');assert a['sha256']==x['old_sha256'] and a['actual_source_ranges']==ranges and not a['later_lens_credit'] and a['repair']=='not_started'
l11=load('historical/059--segovb--READ-L11-436.json')
for role,ranges in [(2666,[[1,186]]),(2667,[[1,232]])]:
 r=next(v for v in l11['sources'] if v['original_index']==role);assert r['fresh_personal_body_reads']==ranges
for n,role,ranges in [(922,2666,[[1,186]]),(923,2667,[[1,232]])]:
 l12=load(f'historical/059--segovb--READ-L12-{n}.json');r=next(v for v in l12['rows'] if v['original_index']==role);assert r['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in r['attribution'] and l12['root_personal_rereads']==[]
for n,role in [(706,2666),(707,2667)]:
 earlier=load(f'historical/059--segovb--READ-L11-{n}.json');x=next(v for v in reg['rows'] if v['role']==role);r=next(v for v in earlier['rows'] if v.get('path')==x['path']);b=(p/f'source/{role}-95e6.rs').read_bytes();assert r['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and r['fresh_personal_body_ranges']==[[1,len(b.splitlines())]] and r['sha256']==h(b) and 'Own Lens11 agent' in r['attribution']
more=load('additional-revision.json')['files']
for v in more:assert v['byte_equal_current'] and v['sha256']==h((p/f"source/{v['role']}-95e6.rs").read_bytes()) and any(x['revision']==v['revision'] and x['blob']==v['git_blob'] for x in proof['proofs'])
f=load('historical/774-F091-reconstructed-from-059.json');gb=(p/f['retained_gzip']).read_bytes();b=gzip.decompress(gb);assert h(gb)==f['retained_gzip_sha256'] and h(b)==f['source_sha256'] and json.loads(b)[f['source_index_zero_based']]==f['selection'] and f['selection']['record']['id']=='RIG-ADMISSION03-F091' and f['selection']['record_index']==99
n=load('native-support-registration.json')['sources'][0];r=rec['native_support'];b=(p/n['saved']).read_bytes();assert h(b)==n['sha256']==r['sha256'] and len(b)==n['bytes'] and len(b.splitlines())==n['eof']==r['eof'];used=[]
for a,z in r['displayed']+r['unread_complement']:assert 1<=a<=z<=r['eof'];used.extend(range(a,z+1))
assert len(used)==r['eof'] and set(used)==set(range(1,r['eof']+1))
for a,z in r['displayed']:assert any(c<=a<=z<=d for c,d in n['prospective_ranges'])
extra=load('additional-evidence.json');cr=(p/extra['native_archive']).read_bytes();assert h(cr)==extra['native_archive_sha256']==n['archive_sha256'];lock=(p/n['lock_saved']).read_bytes();assert h(lock)==n['lock_sha256'];entry=next(x for x in tomllib.loads(lock.decode())['package'] if x['name']=='rawzip' and x['version']=='0.5.2');assert entry['checksum']==h(cr)
with tarfile.open(p/extra['native_archive'],'r:gz') as t:assert t.extractfile(n['archive_member']).read()==b
assert any(x['revision']==reg['current_revision'] and x['path']==n['lock_path'] and x['local']==n['lock_saved'] for x in proof['proofs'])
prior=extra['prior_npy_npz_scope'];manifest=load('historical/prior-npz-MANIFEST.json');assert h((p/'historical/prior-npz-MANIFEST.json').read_bytes())==prior['manifest_sha256'] and h((p/'historical/prior-npz-REPORT.json').read_bytes())==prior['report_sha256']
for x in prior['retained_small_exact_records']:
 b=(p/x['local']).read_bytes();assert h(b)==x['sha256']
 if x['original']!='MANIFEST.json':assert any(v['path']==x['original'] and v['sha256']==x['sha256'] for v in manifest['files'])
oldrec=load('historical/prior-npz-read-receipt.json');assert any(x['path']=='crates/fabelgeist-numpy-storage/src/zip.rs' and x['displayed']==[[1,100],[101,184]] for x in oldrec['support']);assert any(x['path']=='crates/fabelgeist-numpy-storage/src/npy.rs' and x['displayed']==[[1,130]] for x in oldrec['support'])
sel=load(hist['reconstructed_selection']);qb=Path(sel['queue_path']).read_bytes();assert h(qb)==sel['queue_sha256'];q=json.loads(qb)['entries']
for x in sel['queue_rows']:assert q[x['index']]==x['entry']
for fn in ['/delegated/mhr-model-report.json','/delegated/mhr-metadata-report.json']:
 prior=json.loads(Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith(fn))).read_bytes());assert prior['agent']=='/root/mhr_character'
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==[{k:v for k,v in x.items() if k!='qualification'} for x in rec['assigned']]
if (p/'MANIFEST.json').exists():
 for x in load('MANIFEST.json')['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
print(f"PASS: two separately displayed full historical/current source pairs; {len(proof['proofs'])} Git membership proofs; {len(rec['support'])} current support partitions and one native support partition; original 774/059 receipts and reconstructed queue links. Evidence integrity only; no product archive processing, native execution or validation.")
