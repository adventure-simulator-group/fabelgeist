# Bounded NPY and ZIP source evidence

`REPORT.json` records `/root/hair_ops` review of original roles 2666–2667,
registered current support and bounded pinned rawzip source, with historical
relationships and thirteen partial perspectives. This packet is not whole-audit
completion, a repair, product validation, or a substitute for the unrecovered
checkpoint 3821.

`registration.json` prospectively registered full pr-working and current 95e
bodies; the two support registrations separately registered current first-party
and native package windows before display. `read-receipt.json` records actual
reads and unread complements. Original pr-working files equal 6533 and differ
from 95e; earlier e275 files equal 95e by per-file comparison. None of these
comparisons establishes whole-tree equality or transfers reviewer credit.

`git-proofs.json` and `git-objects/` bind source and child lock to their Git
objects. `native/rawzip-0.5.2.crate` is the exact evidence package archive;
its checksum matches the pinned child lock, and the saved source member is
verified against it. Package verification is not a build or execution.
`historical/` retains exact selected 059 receipts, compressed 059 adoption,
reconstructed F091 and queue selections, and small exact prior NPZ packet
records. `historical-manifest.json` hashes additional prior published evidence.
`MANIFEST.json` fixes the packet bytes.

Run `python3 verify-evidence.py` for evidence-integrity verification only. It
checks file identities and displayed partitions, earlier 059 and 774 records,
Git membership, package archive and lock, prior receipts and manifest hashes.
No product archive, native parser, fixture, test, solver or repair code runs.
