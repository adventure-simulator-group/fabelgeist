import datetime,gzip,hashlib,json,pathlib,subprocess,difflib
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());names=['support-registration.json','support-registration-02.json','support-registration-03.json'];supports=[x for n in names for x in json.loads((p/n).read_text())['sources']];allroles=[{'path':role['path'],**v} for role in reg['roles'] for v in role['versions']];present=[x for x in allroles+supports if x['present']];absent=[x for x in allroles+supports if not x['present']];objdir=p/'git-objects';objdir.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=objdir/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in present:
 rev=x['revision'];tree=get('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['local_path']).read_bytes();assert tree==x['git_blob'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'revision':rev,'path':x['path'],'archive':x['local_path'],'commit_tree':root,'chain':chain,'blob':tree})
absences=[]
for x in absent:
 rev=x['revision'];tree=get('commit',rev).splitlines()[0].split()[1].decode();root=tree;chain=[];parts=x['path'].split('/');missing=None
 for i,name in enumerate(parts):
  d=entries(get('tree',tree))
  if name not in d:missing=name;break
  mode,child=d[name];assert mode in ('40000','040000'),(x['path'],name,mode);chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 assert missing is not None
 absences.append({'revision':rev,'path':x['path'],'commit_tree':root,'parent_chain':chain,'parent_tree':tree,'missing_name':missing,'remaining_components':parts[i+1:]})
(p/'git-absence-proofs.json').write_text(json.dumps({'qualification':'Raw Git tree nonmembership for exact role and support paths; missing file does not imply missing behavior.','proofs':absences},indent=2)+'\n');(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw Git commit/tree and retained bytes establish identity only, not reading credit.','objects':objects,'proofs':proof},indent=2)+'\n')
a=(p/'source/2458-90a4.rs').read_text().splitlines(keepends=True);b=(p/'source/2458-95e6.rs').read_text().splitlines(keepends=True);(p/'2458-p17-to-current.diff').write_text(''.join(difflib.unified_diff(a,b,fromfile='report-p17:90a:2458',tofile='current:95e:2458')))
ranges={'support/00-95e6-metrics.rs':[[110,140],[185,205],[215,250],[270,285],[400,535],[690,720],[730,805],[1210,1255],[1260,1283]],'support/01-90a4-metrics.rs':[[80,115],[390,409]],'support/03-90a4-height.rs':[[1,34],[110,132],[165,215],[217,235]],'support/06-95e6-capture.rs':[[65,105]],'support/07-95e6-validation.rs':[[1,35],[115,148],[435,485]],'support/10-95e6-model.rs':[[283,305]],'support/extra-0-authored_policy.rs':[[1,55]],'support/extra-1-review_scenarios.rs':[[145,180]],'support/extra-2-metadata.rs':[[15,40]],'support/extra-3-scenarios.rs':[[65,95]],'support/extra-4-acceptance_limits.rs':[[100,135],[150,180]],'support/extra-5-report-mod.rs':[[90,135]]};reads=[]
for x in supports:
 if x['present']:reads.append({'path':x['path'],'revision':x['revision'],'archive':x['local_path'],'sha256':x['sha256'],'eof':x['registered_range'][1],'actual_body_display_ranges':ranges.get(x['local_path'],[])})
f=p/'support-read-receipt.json';f.write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in names],'reads':reads,'qualification':'Fresh support only; body credit exclusively explicit displayed windows; grep lines, archived bytes and prior agents do not confer additional credit.'},indent=2)+'\n')
reads=[{'original_index':2458,'p17_actual_display_ranges':[[1,65]],'current_actual_display_ranges':[[1,50]],'pr_working_actual_display_ranges':[],'qualification':'95e personally displayed. 6533 copy proved identical but not separately displayed.'},{'original_index':2459,'p17_actual_display_ranges':[[1,65],[66,125],[126,188]],'current_actual_display_ranges':[],'pr_working_actual_display_ranges':[],'qualification':'Path absent in 6533 and 95e; current implementation lives in metrics.rs support.'}];f=p/'read-receipt.json';f.write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registration_sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest(),'reads':reads,'qualification':'Registration and displays originally occurred in <LOCAL_PATH_2> before discovering that an existing unrelated prior packet occupied it; our exact bytes/registration were then copied to this unique path. Original unrelated overwritten records have since been restored byte-identically by /root/mhr_character and verified against their frozen manifest. No prior reading credit transferred.'},indent=2)+'\n');print('proofs',len(proof),'nonmembership',len(absences),'objects',len(objects),'supports',len([x for x in supports if x['present']]))
