import datetime,gzip,hashlib,json,pathlib,subprocess,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def checkref(x):
 b=(p/x['path']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256']),x['path']
def entries(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);out[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
report=json.loads((p/'report.json').read_text());reg=json.loads((p/'registration.json').read_text());receipt=json.loads((p/'read-receipt.json').read_text());support=json.loads((p/'support-read-receipt.json').read_text());registry=json.loads(gzip.decompress((p/'reference/registry.json.gz').read_bytes()));catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()));assert registry['snapshots'][2]['head']==report['p17_revision'];assert len(report['thirteen_lens_perspectives'])==13 and len({x['lens'] for x in report['thirteen_lens_perspectives']})==13
for key in ['registration','role_read_receipt','support_read_receipt','historical_manifest','reference_archives','older_774_selection','prior_current_selection']:checkref(report[key])
for z in report['support_registrations']+report['navigation_receipts']:checkref(z)
assert datetime.datetime.fromisoformat(reg['registered_utc'])<datetime.datetime.fromisoformat(receipt['recorded_utc'])
for row in reg['roles']:
 for v in row['versions']:
  z=subprocess.run(['git','-C',repo,'show',v['revision']+':'+row['path']],capture_output=True)
  if not v['present']:assert z.returncode and not subprocess.check_output(['git','-C',repo,'ls-tree','-r','--name-only',v['revision'],'--',row['path']]);continue
  b=(p/v['local_path']).read_bytes();assert z.stdout==b and (len(b),len(b.splitlines()),sha(b),blob(b))==(v['bytes'],v['lines'][1],v['sha256'],v['git_blob'])
  if v['revision']==report['p17_revision']:
   c=catalog['rows'][row['original_index']];assert c['origin']=='git:'+v['revision']+':'+row['path'] and c['expected_sha256']==sha(b) and registry['files'][row['original_index']]['sha256']==sha(b);assert b==pathlib.Path(v['frozen_catalog_object']).read_bytes()==pathlib.Path(v['archive_local']).read_bytes()==pathlib.Path(v['handoff_archive']).read_bytes()
supports=[x for z in report['support_registrations'] for x in json.loads((p/z['path']).read_text())['sources']];real=[x for x in supports if x['present']];assert len(real)==len(support['reads'])
for s,a in zip(real,support['reads']):
 b=(p/s['local_path']).read_bytes();assert b==subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['path']]);assert (len(b),len(b.splitlines()),sha(b),blob(b))==(s['bytes'],s['registered_range'][1],s['sha256'],s['git_blob']);assert (a['path'],a['revision'],a['sha256'])==(s['path'],s['revision'],s['sha256']);assert all(1<=i<=j<=s['registered_range'][1] for i,j in a['actual_body_display_ranges'])
for z in report['support_registrations']:assert datetime.datetime.fromisoformat(json.loads((p/z['path']).read_text())['registered_utc'])<datetime.datetime.fromisoformat(support['recorded_utc'])
objects=json.loads((p/'git-proofs.json').read_text());raw={}
for oid,x in objects['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b))==(x['bytes'],x['sha256']);assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;raw[oid]=b
for x in objects['proofs']:
 tree=raw[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for c in x['chain']:assert c['tree']==tree and entries(raw[tree])[c['name']]==(c['mode'],c['object']);tree=c['object']
 assert tree==x['blob'] and blob((p/x['archive']).read_bytes())==tree
for x in json.loads((p/'git-absence-proofs.json').read_text())['proofs']:
 tree=raw[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for c in x['parent_chain']:assert c['tree']==tree and entries(raw[tree])[c['name']]==(c['mode'],c['object']);tree=c['object']
 assert tree==x['parent_tree'] and x['missing_name'] not in entries(raw[tree])
h=json.loads((p/'historical-manifest.json').read_text());assert not h['unavailable'];transport={e['path']:e for e in json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()))['entries']}
for x in h['records']:
 b=(p/x['copy_path']).read_bytes();e=transport[x['original_transport_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
refs=json.loads((p/'reference/manifest.json').read_text())
for x in refs['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256']);assert 'uncompressed_sha256' not in x or sha(gzip.decompress(b))==x['uncompressed_sha256']
old=json.loads((p/'reference/older-774-selection.json').read_text());mb=gzip.decompress((p/old['manifest_compressed']).read_bytes());assert sha(mb)==old['manifest_uncompressed_sha256'];ix={e['path']:e for e in json.loads(mb)['files']}
for x in old['records']:
 b=gzip.decompress((p/x['compressed_copy']).read_bytes());e=ix[x['manifest_path']];assert (len(b),sha(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256']);assert x['merged_copy'] is None or b==pathlib.Path(x['merged_copy']).read_bytes()
coverage=next(x for x in old['records'] if x['manifest_path'].endswith('native/coverage.jsonl'));lines=[json.loads(x) for x in gzip.decompress((p/coverage['compressed_copy']).read_bytes()).splitlines()]
for row,ii in zip(reg['roles'],[[295,634],[296,635]]):
 for i in ii:
  x=lines[i];assert x['source_id']=='report-p17:'+row['path'] and x['observed_sha256']==row['versions'][0]['sha256'] and x['read_ranges']==[row['versions'][0]['lines']]
prior=json.loads((p/'reference/prior-current-selection.json').read_text());assert refs['prior_selection_sha256']==sha((p/'reference/prior-current-selection.json').read_bytes())
for x in prior['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
 for s in x['source_records']:
  z=(p/s['copy']).read_bytes();b=gzip.decompress(z);assert sha(z)==s['compressed_sha256'] and sha(b)==s['sha256'] and b==subprocess.check_output(['git','-C',repo,'show',s['revision_as_recorded']+':'+s['path']])
queue=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()))['entries']
for x in report['historical_queue']:assert (queue[x['index']]['contract_id'],queue[x['index']]['status'])==(x['id'],x['status_as_recovered'])
counts=[]
for rec,root,name in zip(report['prior_packets'],['726-delegate-p17-continuity/','726-delegate-p17-metrics/'],['MANIFEST.json','BUNDLE-MANIFEST.json']):
 checkref(rec['archive'])
 with tarfile.open(p/rec['archive']['path'],'r:gz') as t:
  mb=t.extractfile(root+name).read();assert sha(mb)==rec['prior_manifest_sha256'];m=json.loads(mb)
  for x in m['files']:
   b=t.extractfile(root+x['path']).read();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
  counts.append(len(m['files']))
  if 'prior_report_sha256' in rec:assert sha(t.extractfile(root+'REPORT.json').read())==rec['prior_report_sha256']
proof={'result':'passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revision_path_memberships':len(objects['proofs']),'raw_git_commit_tree_objects':len(raw),'nonmembership_proofs':len(json.loads((p/'git-absence-proofs.json').read_text())['proofs']),'historic_059_records':len(h['records']),'older_774_manifest_records':len(old['records']),'prior_current_assessments':len(prior['records']),'prior_peer_packet_files_verified':counts,'bounded_lenses':13,'qualification':'Evidence-integrity verification only. No product, builds, tests, probes, simulations or repairs.'};(p/'evidence-verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
