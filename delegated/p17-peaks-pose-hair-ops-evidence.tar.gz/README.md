# P17 height peaks and pose metrics audit

`report.json` records the bounded audit of original P17 roles 2458–2459 against
snapshot 90a and pinned current 95e. The report includes thirteen partial lens
perspectives, old reviewer attribution, the separate prior phase-warmup finding,
a conditional knee-axis observation, nonfindings and open questions.

`registration.json` and `read-receipt.json` preserve the exact assigned source
identities and actual personal displays. The three support registrations and
`support-read-receipt.json` cover only connected windows actually read. Raw Git
commit/tree objects verify both membership and nonmembership; full source byte
archives do not grant extra read credit. The peer packets in `prior-packets/`
retain their original authors and manifests. Older 059 and 774 records retain
their original authors, revisions and source ranges.

The report records the temporary directory collision and subsequent byte-exact
restoration of the earlier packet. No earlier state is promoted to checkpoint
3821. Evidence checks inspected hashes, Git trees and archives only: no product,
viewer, browser, tests, builds, runtime probes, simulations or repairs ran.
