import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;r=json.loads((p/'registration.json').read_bytes());rows=[]
def comp(n,rs):
 unseen=set(range(1,n+1))-{i for a,b in rs for i in range(a,b+1)};out=[]
 for i in sorted(unseen):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for e in r['entries']:
 chunks=e['registered_ranges']
 if e['tag'] in ('pr-working-2610','current-2610'):chunks=[[1,140],[141,280],[281,414]]
 rows.append({'tag':e['tag'],'kind':e['kind'],'role':e.get('role'),'archive':e['archive'],'sha256':e['sha256'],'EOF':e['EOF'],'displayed_chunks':chunks,'unread_complement':comp(e['EOF'],chunks)})
o={'author':'/root/mhr_character','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration':'registration.json','registration_sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest(),'entries':rows,'display_qualification':'Numbered bounded source displays occurred after registration. The initial combined tool return truncated a section of historical helmets 281–414; that entire segment was independently displayed again untruncated, before this receipt. No earlier reader credit transferred. Full stored support bodies are not full personal reads.','execution':'No product, fixture, test, build, renderer, shader, macro or probe run.'};(p/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n')
