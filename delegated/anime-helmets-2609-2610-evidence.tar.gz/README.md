# Bounded checkpoint 17 reconciliation proposal

This additive packet concerns original roles 2609 and 2610 and current revision
95e63628f9d70b8dd6e6fede64334696c6995009. Start with `report.json` for source
relationships, safeguards, open questions and the proposed ledger connections.
This is source-only evidence, with no repair, product validation or lens closure.

`registration.json` was written before the independently displayed sources;
`read-receipt.json` records actual bounded display ranges and unread complements.
The packet preserves full bytes for support, but only the receipt's windows were
personally read. The receipt also records a truncated combined output that was
repeated untruncated. `git-proofs.json` and compressed Git objects prove exact
per-file membership. f82 is transport, while 6533 is the recorded historical
pr-working HEAD with unrelated changes; equal blobs do not prove a clean tree.

`reference/` contains exact archived baseline materials and earlier reconstructed
059 queue and ledger compressed for recoverability. `059-selection-reconstructed.json`
and `registry-selection-reconstructed.json` are newly reconstructed selections,
not original historical documents. `history-059/` preserves verified original
receipts against the original transport manifest; `history-774/` preserves exact
f82 record bytes and Git path proofs. `historical-index.json` records two
historical rig registration-prefix digest mismatches and the separately matching
qualification records, without attributing a cause.

`prior/` is a verified selection of `/root/hair_ops` original frozen evidence;
`public-prior-members.json` and checkpoint 17 metadata distinguish original
members from the redacted publication copy. Earlier reviewer reads and records
are not transferred to this review or to checkpoint 3821. The P16 tracked patch
is separate background only and excludes seven untracked files; the original
patch invocation remains unknown.

`verification.json` is the output of this packet's read-only evidence verifier,
not product validation. `BUNDLE-MANIFEST.json` hashes every packet file except
itself, including nested manifests. Run `python3 verify-manifest.py` only against
this packet; no older verifier was run or changed.
