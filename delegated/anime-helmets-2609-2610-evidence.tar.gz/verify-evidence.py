import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes())
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(v==reg['files'][int(k)] for k,v in sel['roles'].items());assert all(reg['files'][i]['snapshot']=='pr-working' for i in (2609,2610))
for name in ('reference-index.json','rules.json','rules-local.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256']
patch=(p/'reference/tracked.patch').read_bytes();recovery=load('reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert sha(patch)==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(patch)==recovery['recovered_patch']['bytes'] and recovery['live_comparison']['status_counts']['??']==7
r=load('registration.json');t=load('read-receipt.json');assert t['registration_sha256']==sha((p/'registration.json').read_bytes()) and len(r['entries'])==len(t['entries'])==18 and datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(r['registered_utc'])
def nums(rs):return {i for lo,hi in rs for i in range(lo,hi+1)}
for e,v in zip(r['entries'],t['entries']):
 b=(p/e['archive']).read_bytes();assert e['tag']==v['tag'] and sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'];seen=nums(v['displayed_chunks']);unseen=nums(v['unread_complement']);assert nums(e['registered_ranges'])==seen and seen|unseen==set(range(1,e['EOF']+1)) and not seen&unseen
 if e['kind']=='historical-pr-working':assert e['sha256']==reg['files'][e['role']]['sha256']
for role in (2609,2610):assert (p/f'source/pr-working-{role}.rs').read_bytes()==(p/f'source/current-{role}.rs').read_bytes()
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());lraw=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());q=json.loads(qraw);l=json.loads(lraw);x=load('059-selection-reconstructed.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for path,v in x['journal_entries'].items():
 z=l
 for part in path.strip('/').split('/'):z=z[int(part)] if isinstance(z,list) else z[part]
 assert z==v
for i in (608,641,1813):assert not q['entries'][i]['exact_source_identities_and_assessed_ranges'] and not q['entries'][i]['source_receipt_contexts']
assert q['entries'][2478]['granular_contract_views'] and q['entries'][3141]['exact_source_identities_and_assessed_ranges']
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for suffix in ('L11-427','L11-445','L12-891','L12-CONNECTED-TEAM-022'):
 v=load('history-059/segovb/VERIFY-'+suffix+'.json');assert v['receipt_sha256']==sha((p/('history-059/segovb/READ-'+suffix+'.json')).read_bytes()) and v['state_sha256']==sha((p/('history-059/segovb/STATE-'+suffix+'.json')).read_bytes())
read=load('history-059/segovb/READ-L11-427.json');l11=[]
for e in read['sources']:
 if e['original_index'] not in (2609,2610):continue
 rel=e['registration'].split('target/726-audit-adler-20261027/',1)[1];assert e['registration_sha256']==sha((p/'history-059'/rel).read_bytes()) and e['sha256']==reg['files'][e['original_index']]['sha256'];l11.append(e)
assert len(l11)==3 and l11[0]['fresh_personal_body_reads']==[[1,56]] and l11[1]['fresh_personal_body_reads']==[[1,221],[249,275],[295,380],[385,385],[392,414]] and l11[2]['fresh_personal_body_reads']==[[222,248],[276,294],[381,384],[386,391]]
read=load('history-059/segovb/READ-L12-891.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes())
for e in read['rows']:
 if e['original_index'] not in (2609,2610):continue
 assert e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes()) and e['source_sha256']==reg['files'][e['original_index']]['sha256']
 if e['original_index']==2609:assert e['fresh_personal_body_reads']==[[1,56]]
 else:
  assert e['fresh_personal_body_reads']==[] and len(e['qualified_same_lens_reuse_ranges_and_exact_proofs'])==1
  z=e['qualified_same_lens_reuse_ranges_and_exact_proofs'][0];assert z['sha256']==sha((p/'history-059'/z['path']).read_bytes())
refs=[]
def walk(o,path=''):
 if isinstance(o,dict):
  if isinstance(o.get('path'),str) and o['path'] in idx and isinstance(o.get('sha256'),str):
   actual=sha((p/'history-059'/o['path']).read_bytes());refs.append({'pointer':path,'path':o['path'],'recorded_sha256':o['sha256'],'actual_sha256':actual,'match':o['sha256']==actual})
  if isinstance(o.get('verification'),str) and o['verification'] in idx and isinstance(o.get('verification_sha256'),str):
   actual=sha((p/'history-059'/o['verification']).read_bytes());refs.append({'pointer':path+'/verification','path':o['verification'],'recorded_sha256':o['verification_sha256'],'actual_sha256':actual,'match':o['verification_sha256']==actual})
  for k,v in o.items():walk(v,path+'/'+k)
 elif isinstance(o,list):
  for i,v in enumerate(o):walk(v,path+'/'+str(i))
for i in (2478,3141):walk(q['entries'][i],'/entries/'+str(i))
assert all(e['match'] for e in refs),[e for e in refs if not e['match']]
prior=load('prior-index.json');m=(p/'prior/MANIFEST.json').read_bytes();assert sha(m)==prior['original_manifest_sha256']=='d79e2f326f3a5c90ef70a14454c608d60f64f75f6f92e233ad3ab5f8a40b369e';idxprior={e['path']:e for e in json.loads(m)['files']}
for e in prior['selected_files']:
 b=(p/'prior'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(idxprior[e['path']]['bytes'],idxprior[e['path']]['sha256'])
pub=load('reference/DELEGATED-EVIDENCE-CHECKPOINT-17.json');entry=next(z for z in pub['bundles'] if z['bundle_id']=='armor-anime-helmets-hair-ops');assert entry['archive_sha256']==prior['published_archive_sha256'];members=load('public-prior-members.json');assert members['archive_sha256']==entry['archive_sha256']
for v in members['members']:
 z=next(z for z in entry['members'] if z['path']==v['path']);assert (v['original_sha256'],v['published_sha256'],v['changed'])==(z['original_sha256'],z['published_sha256'],z['changed']) and v['original_sha256']==sha((p/'prior'/v['path']).read_bytes()) and v['published_sha256']==sha((p/v['file']).read_bytes())
assert next(v for v in members['members'] if v['path']=='historical-manifest.json')['changed'] and not next(v for v in members['members'] if v['path']=='REPORT.json')['changed'] and sha((p/'reference/published-prior-report.json').read_bytes())==sha((p/'prior/REPORT.json').read_bytes())
pin=hist['rig_registration_pin_qualification'];a=json.loads(gzip.decompress((p/'history-774/continuation/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));b=json.loads(gzip.decompress((p/'history-774/continuation/root/admission03-scope-reconciliation-050.json.gz').read_bytes()));rr=gzip.decompress((p/'history-774/continuation/rig/admission03/source-range-registration.jsonl.gz').read_bytes());rq=gzip.decompress((p/'history-774/continuation/rig/admission03/source-qualifications.jsonl.gz').read_bytes());assert a['input_pins'][3]==pin['root046_registration_pin'] and b['input_pins'][2]==pin['root050_registration_pin'];assert a['input_pins'][3]['sha256']!=sha(b''.join(rr.splitlines(keepends=True)[:35]))==pin['later_registration_first35_sha256'];assert b['input_pins'][2]['sha256']!=sha(b''.join(rr.splitlines(keepends=True)[:139]))==pin['later_registration_first139_sha256'];assert a['input_pins'][4]['sha256']==sha(b''.join(rq.splitlines(keepends=True)[:31])) and b['input_pins'][3]['sha256']==sha(b''.join(rq.splitlines(keepends=True)[:45]))
for role,n in ((2609,52),(2610,55)):
 row=json.loads(rr.splitlines()[n-1]);obs=reg['files'][role]['admission03_scope_observations'][0];assert row==obs['original_record']==pin['row'+str(n)] and datetime.datetime.fromisoformat(a['at'])<datetime.datetime.fromisoformat(row['at'])<datetime.datetime.fromisoformat(b['at'])
qual=json.loads(rq.splitlines()[37]);assert qual['id']=='RIG-ADMISSION03-SOURCE-QUALIFICATION-016' and qual['excluded_incidental_display']==[[391,391]] and qual==reg['files'][2610]['admission03_scope_observations'][0]['local_qualifications'][0] and any(v.get('original_record')==qual for v in b['role_qualifications'])
findings=gzip.decompress((p/'history-774/continuation/rig/admission03/findings.jsonl.gz').read_bytes()).splitlines()
f049=json.loads(findings[48]);assert f049['id']=='RIG-ADMISSION03-F049' and f049['source_id']==reg['files'][2609]['source_id'] and 'RIG-ADMISSION03-REGISTER-052' in f049['registration_refs']
adds=gzip.decompress((p/'history-774/continuation/rig/admission03/additional-contracts.jsonl.gz').read_bytes()).splitlines()
d52=json.loads(adds[37]);d55=json.loads(adds[40]);assert d52['id']=='RIG-ADMISSION03-ADDITIONAL-052' and d52['actual_source_ranges']==[[1,56]] and d55['id']=='RIG-ADMISSION03-ADDITIONAL-055' and d55['actual_source_ranges']==qual['material_ranges']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 bts=gzip.decompress((p/e['archive']).read_bytes());assert len(bts)==e['bytes'] and sha(bts)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(bts)).encode()+b'\0'+bts).hexdigest()==oid;objs[oid]=(e['type'],bts)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,body=objs[tree];assert typ=='tree';mode,tree=entries(body)[name];assert mode==link['mode'] and tree==link['object']
 body=(p/x['archive']).read_bytes();body=gzip.decompress(body) if x.get('encoding')=='gzip' else body;assert sha(body)==x['sha256'] and blob(body)==x['blob']==tree
report=load('report.json');baseline=load('reference/BASELINE-95E-20261110.json');assert len(proof['proofs'])==29 and len(report['lens_perspectives'])==13 and [z['index'] for z in report['historical_relations']['selected_059_queue']]==[608,641,1813,2478,3141];assert baseline['newly_assessed_ledger']['entries'][471]['id']=='REVIEW-L3-HELMET-CARRIER-TOPOLOGY-ADMISSION' and baseline['newly_assessed_ledger']['entries'][472]['id']=='REVIEW-BUFFE-BREATH-COURSE-CONTEXT-95E'
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_source_entries':len(r['entries']),'git_membership_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(hist['records']),'selected_queue_entries':5,'qualified_queue_reference_hashes':len(refs),'lens_perspectives':13,'rig_registration_mismatches_retained':2,'public_historical_manifest_redacted':True,'qualification':'Evidence integrity only. Original and current reads separately registered; old 059/774 chronology, two rig prefix mismatches, seven P16 exclusions, original/public member identities and scoped source coverage preserved. No product, renderer, fixture, build, test or runtime execution.'},indent=2))
