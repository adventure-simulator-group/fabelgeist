# Bounded roles 2712–2714 terrain-feature evidence

This packet records independent source inspection of the original pr-working
terrain-feature validator and shared feature/window schema at recorded HEAD
`6533e444fa37552927070cc8d8190907fd3b413e` and pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. All three files individually match
at those revisions and the archived original objects. The pr-working snapshot
has unrelated dirty changes; per-file equality is not a clean-tree claim.

Start with `report.json` and `read-scope-summary.json`. Each old and current
assigned body was displayed in full after registration. Eleven current support
bodies were read only in the indicated bounded windows; complements are
explicit. A planned geology-source support window turned out to be test text,
and two other registered windows also included test text; the receipts and
amendment preserve that deviation. No tests or fixtures were executed.

The historical evidence includes Native 774 registrations and qualifications,
Camera's P16 registration without awarded coverage, original 774 F007, original
059 Segovb and Lens12 frontier records, the distinct adopted P16 role 2580
proposal, and the later role 2712–2714 proposal requiring adoption. A published
Lens13 partial is retained under `reference/l13-711/` with its own nested
manifest and its unrecovered-packet qualifications. P16 is a separate dirty
snapshot even where role 2580 bytes equal role 2712. Its recovered tracked patch
excludes seven untracked files and does not prove original invocation or
uninterrupted custody.

`python3 verify-evidence.py` checks evidence identity, offline Git proofs and
source-read accounting only; `python3 verify-manifest.py` checks the frozen
packet, including the nested prior manifest. Neither runs product code. No
terrain, product, build, test, fixture, probe, simulation, repair, validation,
checkpoint 3821 promotion or complete-lens closure is claimed.
