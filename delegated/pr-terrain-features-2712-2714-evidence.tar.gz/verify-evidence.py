#!/usr/bin/env python3
"""Evidence identities, exact source read scopes and Git proofs only."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
def vals(r):return {i for lo,hi in r for i in range(lo,hi+1)}
scope=load('read-scope-summary.json')
for regfile,receipt,section in [('registration.json','personal-read-receipt.json','assigned'),('support-registration.json','support-read-receipt.json','support'),('support2-registration.json','support2-read-receipt.json','support'),('support3-registration.json','support3-read-receipt.json','support'),('support4-registration.json','support4-read-receipt.json','support')]:
 reg=load(regfile);rc=load(receipt);assert sha((p/regfile).read_bytes())==rc['registration_sha256'] and reg['registered_utc']<rc['recorded_utc'] and len(reg['entries'])==len(rc['actual_displays'])
 for e,x in zip(reg['entries'],rc['actual_displays']):
  d=(p/e['source_archive']).read_bytes();assert (sha(d),blob(d),len(d),len(d.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['EOF']) and x['source_archive']==e['source_archive'] and e['planned_chunks']==x['displayed_chunks'] and vals(e['planned_chunks'])==vals(e['registered_ranges']);s=scope[section][e['source_archive']];assert s['displayed_ranges']==e['registered_ranges'] and s['unread_complement']==x['unread_complement'] and not vals(s['displayed_ranges'])&vals(s['unread_complement']) and vals(s['displayed_ranges'])|vals(s['unread_complement'])==set(range(1,e['EOF']+1))
reg=load('registration.json');assert len(reg['entries'])==6 and len(scope['support'])==11
for i,n in [(2712,51),(2713,43),(2714,36)]:
 old,cur=[e for e in reg['entries'] if e['original_index']==i];assert old['original_material_ranges']==[[1,n]] and old['registered_ranges']==cur['registered_ranges']==[[1,n]] and (p/old['source_archive']).read_bytes()==(p/cur['source_archive']).read_bytes();cmp=next(x for x in reg['comparisons'] if x['original_index']==i);assert cmp['historical_equals_6533_individual_file'] and not cmp['status_porcelain'] and cmp['base_sha256']==old['sha256']
assert 'test text' in scope['qualification'] and 'actual producer' in scope['qualification'];checks.append('Three historical/current full assigned displays and eleven bounded current supports; exact unread complements and test-source deviation')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';j=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert all(sel['roles'][str(i)]==j['files'][i] for i in [2580,2712,2713,2714]);snap={x['id']:x for x in j['snapshots']};assert sel['snapshots']==[x for x in j['snapshots'] if x['id'] in ('pr-working','physical-p16')] and snap['pr-working']['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(snap['pr-working']['status_porcelain'])==4 and snap['physical-p16']['base']=='a120390947c89b703dc74c4255a13c035d054c50' and len(snap['physical-p16']['status_porcelain'])==159 and sha((p/'reference/p16-tracked.patch').read_bytes())==snap['physical-p16']['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and j['files'][2580]['sha256']==j['files'][2712]['sha256']
raw=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(raw)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';entries={x['path']:x for x in json.loads(gzip.decompress(raw))['entries']};hist=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hist['records'])==24 and sum(x['kind']=='historical-774' for x in hist['records'])==6
for x in hist['records']:
 d=(p/x['file']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (len(d),sha(d),blob(d))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
search=load('recovery-search.json');assert len(search['roots'])==2 and len(search['filenames'])==3 and not search['results'] and not search['errors'] and not search['transport_manifest_matches'] and not any(pathlib.PurePosixPath(x).name in search['filenames'] for x in entries);checks.append('Original 059 registry, dirty pr-working/P16, recovered tracked patch, 24 exact 059 and six 774 records; bounded 944 adoption search')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];d=gzip.decompress((p/x['archive']).read_bytes());assert (len(d),sha(d),hashlib.sha1(x['type'].encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest())==(x['bytes'],x['sha256'],oid);return d
def trees(d):
 out={};i=0
 while i<len(d):
  s=d.index(b' ',i);z=d.index(b'\0',s);out[d[s+1:z].decode()]=(d[i:s].decode(),d[z+1:z+21].hex());i=z+21
 return out
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==27
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 d=(p/x['archive']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (sha(d),blob(d),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Twenty-seven offline Git membership proofs across f82, 6533, 95e, individual P16 base and current support')
reg774=[json.loads(x) for x in gzip.decompress((p/'history-774/native/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines()];qs=[json.loads(x) for x in gzip.decompress((p/'history-774/native/admission03/root-support-batch2/source-qualifications-008.jsonl.gz').read_bytes()).splitlines()]
for number,role,n in [(65,2712,51),(66,2713,43),(67,2714,36)]:
 id=f'NATIVE-ADMISSION03-REG-{number:03d}';x=next(x for x in reg774 if x['id']==id);z=next(x for x in qs if x['registration_id']==id);assert x['material_ranges']==z['qualified_material_ranges']==[[1,n]] and x['sha256']==j['files'][role]['sha256']
cam=[json.loads(x) for x in gzip.decompress((p/'history-774/camera/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines()];assert next(x for x in cam if x['id']=='CAMERA-ADM03-REG-007')['source_coverage_awarded'] is False;f=json.loads(gzip.decompress((p/'history-774/root/admission03/world-route-admission-030.json.gz').read_bytes()));assert f['finding']['id']=='ROOT-ADM-F007';l11=load('history-059/segovb/READ-L11-442.json')
for role,n in [(2712,51),(2713,43),(2714,36)]:assert next(x for x in l11['sources'] if x['original_index']==role)['fresh_personal_body_reads']==[[1,n]]
for i,role,n in [(1,2712,51),(2,2713,43),(3,2714,36)]:
 row=next(x for x in load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-944-{i:03d}.json')['rows'] if x['original_index']==role);assert row['fresh_personal_body_reads']==[[1,n]] and '/root/lens12_frontier' in row['attribution']
assert 'root adoption required' in load('history-059/parallel-l12-20261029/PROPOSAL-L12-944.json')['kind'];l11p=next(x for x in load('history-059/segovb/READ-L11-424.json')['sources'] if x['original_index']==2580);assert l11p['fresh_personal_body_reads']==[[1,51]];a=load('history-059/segovb/READ-L12-875.json');assert 'Root adoption' in a['kind'] and next(x for x in a['rows'] if x['original_index']==2580)['fresh_personal_body_reads']==[[1,51]];prior=next(x for x in load('reference/l13-prior-row-extracts.json') if x['source']['original']==2580);assert prior['author']=='/root' and prior['assessed_ranges']==[[1,51]] and 'transport' in prior['source']['revision_qualification'].lower();checks.append('Original 774 Native and Camera scopes and F007; distinct 059 Segovb/Frontier P16 adopted and PR proposed scopes')
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert e==queue['entries'][int(n)]
for x in load('reference-index.json')['records']:
 d=(p/x['file']).read_bytes();assert (sha(d),len(d))==(x['sha256'],x['bytes'])
for file in ['rules.json','skills.json']:
 for x in load(file)['records']:assert sha((p/x['file']).read_bytes())==x['sha256']
amend=load('support-read-receipt-amendment.json');assert amend['original_receipt_sha256']==sha((p/'support-read-receipt.json').read_bytes()) and 'compiler_windows' in amend['clarification']
for x in load('prior-l13-index.json')['records']:
 d=(p/x['file']).read_bytes();assert (len(d),sha(d))==(x['bytes'],x['sha256'])
manifest=load('reference/l13-711/MANIFEST.json');assert sha((p/'reference/l13-711/prior-row-extracts.json').read_bytes())==manifest['prior_row_extracts_sha256'] and sha((p/'reference/l13-711/fresh-display.txt').read_bytes())==manifest['fresh_display_sha256'] and sha((p/'reference/l13-711/PROPOSAL-LITERAL-ASSESSMENTS.json').read_bytes())==manifest['proposal_literal_evidence']['sha256'] and sha((p/'reference/l13-711'/manifest['registration_sha256']).read_bytes())==manifest['registration_sha256']
l13=load('reference/l13-literal-proposal.json');assert 'historical claims' in l13['qualification'] and {x['original'] for x in l13['source_assessments']} >= {2712,2713,2714};report=load('report.json');assert report['scope']['roles']==[2712,2713,2714] and {x['number'] for x in report['lenses']}==set(range(1,14));checks.append('Original reconstructed queue, historical literal-only L13 summary, prior assessments and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and source-read accounting only; no terrain, product, test, fixture, build, probe, simulation, repair, validation, checkpoint3821 promotion, 944 adoption or whole-lens closure.'},indent=2))
