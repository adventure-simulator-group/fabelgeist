import datetime,hashlib,io,json,pathlib,tarfile
p=pathlib.Path('<LOCAL_PATH_0>');hist=p/'historical-059';H=lambda b:hashlib.sha256(b).hexdigest()
def check(path,h):
 path=path.removeprefix('target/726-audit-adler-20261027/');b=(hist/path).read_bytes();assert H(b)==h,(path,H(b),h)
x=json.loads((hist/'segovb/READ-L11-415.json').read_text());rows=[r for r in x['sources'] if r['original_index'] in [2500,2501]];assert len(rows)==2
for r in rows:
 assert r['fresh_personal_body_reads']==[];check(r['registration'],r['registration_sha256']);check(r['same_lens_prior']['receipt'],r['same_lens_prior']['receipt_sha256'])
x=json.loads((hist/'segovb/READ-L12-850.json').read_text());check(x['proposal'],x['proposal_sha256']);assert not x['root_personal_rereads'];rows=[r for r in x['rows'] if r['original_index'] in [2500,2501]];assert len(rows)==2
for r in rows:
 check(r['registration'],r['registration_sha256']);q=r['identity_specific_windows_qualification'];check(q['path'],q['sha256'])
x=json.loads((hist/'segovb/READ-L12-CONNECTED-TEAM-017.json').read_text());check(x['manifest']['path'],x['manifest']['sha256']);assert not x['root_personal_rereads']
for z in x['evidence_refs']:check(z['path'],z['sha256'])
for r in x['checked_rows']:
 if r.get('original_index')==2501:check(r['registration'],r['registration_sha256']);check(r['receipt']['path'],r['receipt']['sha256'])
idx=json.loads((p/'prior-packets-index.json').read_text());count=0
for a in idx['packets']:
 b=(p/a['archive']).read_bytes();assert H(b)==a['sha256'] and len(b)==a['bytes'];assert a['upstream_manifest_verified']
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:
  rows={x['path']:x for x in a['entries']};assert set(t.getnames())==set(rows)
  for n,x in rows.items():
   v=t.extractfile(n).read();assert len(v)==x['bytes'] and H(v)==x['sha256'];count+=1
nav=json.loads((p/'discovery-navigation.json').read_text());assert H((p/nav['archive']).read_bytes())==nav['reconstruction_sha256']
result={'schema':'726-evidence-link-verification-v1','status':'passed','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'059 same-lens adopted registrations and original receipts, delegated L12 proposal, registration, qualification, connected adoption and complementary receipt hashes; full prior packet archive inventory and bytes; disclosure navigation reconstruction hash.','prior_packet_members':count,'scope':'Evidence integrity only; historical attribution/qualifications remain in the reports; no product or runtime verification.'};(p/'evidence-links-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
