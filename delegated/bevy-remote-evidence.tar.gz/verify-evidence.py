from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,sys,tarfile,tomllib
b=Path(__file__).resolve().parent;args=[x for x in sys.argv[1:] if x!='--record'];pub=Path(args[0]) if args else Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();refs=json.loads((b/'published-references.json').read_bytes())
for x in refs['entries']:
 f=pub/x['path'] if 'path' in x else b/x['preserved_bytes'];raw=f.read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],str(f)
prior=b/'prior-delegate/bevy-reflect-derive-hair-ops';pm=json.loads((prior/'packet-manifest.json').read_bytes());mi={x['path']:x for x in pm['files']}
for n in ['report.json','support-read-receipt.json']:
 raw=(prior/n).read_bytes();assert len(raw)==mi[n]['bytes'] and sha(raw)==mi[n]['sha256']
reg=json.loads((b/'registration.json').read_bytes());receipt=json.loads((b/'personal-read-receipt.json').read_bytes());registry=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));transport=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));tidx={x['path']:x for x in transport['entries']};report=json.loads((b/'REPORT.json').read_bytes());original=json.loads((b/'original-attribution.json').read_bytes());assert not original['missing_originals'];archive=b/reg['archive']['source_archive'];assert len(archive.read_bytes())==reg['archive']['bytes'] and sha(archive.read_bytes())==reg['archive']['sha256'];assert [x['original_index'] for x in reg['roles']]==[2567,2568]
def package_source(x):
 raw=(b/x['source_archive']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and len(raw.splitlines())==x['actual_EOF']
 with tarfile.open(archive,'r:gz') as t:assert t.extractfile(x['archive_member']).read()==raw
for x in reg['roles']:
 package_source(x);o=registry['files'][x['original_index']];assert x['source_id']==o['source_id'] and x['sha256']==o['sha256'] and x['historical_material_ranges']==o['material_ranges'] and x['actual_EOF']==o['actual_line_count'] and x['registered_personal_display_ranges']==[[1,x['actual_EOF']]]
for x in json.loads((b/'native-support-registration.json').read_bytes())['sources']:package_source(x)
for rev,x in reg['locks'].items():
 raw=gzip.decompress((b/x['archive']).read_bytes());assert sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob'];pk=[p for p in tomllib.loads(raw.decode())['package'] if p['name']=='bevy_reflect_derive' and p['version']=='0.19.1'];assert len(pk)==1 and pk[0]==x['package'] and pk[0]['checksum']==reg['archive']['sha256']
for x in json.loads((b/'project-support-registration.json').read_bytes())['sources']:
 raw=(b/x['source_archive']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob'] and len(raw.splitlines())==x['actual_EOF']
sel=json.loads((b/'registry-selection-reconstructed.json').read_bytes())
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());qs=json.loads((b/'queue-selection-reconstructed.json').read_bytes());assert not qs['missing']
for x in qs['entries']:assert {k:v for k,v in x.items() if k!='original_queue_index'}==queue['entries'][x['original_queue_index']]
for x in original['original_059_records']:
 raw=(b/x['preserved_bytes']).read_bytes();o=tidx[x['original_path']];assert len(raw)==x['bytes']==o['bytes'] and sha(raw)==x['sha256']==o['sha256'] and oid('blob',raw)==x['git_blob']==o['git_blob']
for x in original['older_774_receipts']:
 raw=(b/x['preserved_bytes']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob']
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
proof=json.loads((b/'git-proofs.json').read_bytes());objects={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved_bytes']).read_bytes());assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==key;objects[key]=raw
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,step in zip(parts,x['path_chain']):
  assert step['tree']==cur and step['name']==name;mode,child=entries(objects[cur])[name];assert mode==step['mode'] and child==step['object'];cur=child
 raw=(b/x['preserved_bytes']).read_bytes();raw=gzip.decompress(raw) if x['compression']=='gzip' else raw;assert oid('blob',raw)==cur==x['git_blob'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']
assert len(proof['paths'])==14
scopes={};times=[]
for row in receipt['read_entries']:
 local=row['source'];raw=(b/local).read_bytes();raw=gzip.decompress(raw) if row.get('compression')=='gzip' else raw;assert sha(raw)==row['sha256'] and len(raw.splitlines())==row['actual_EOF'];d=json.loads((b/row['registration']).read_bytes());times.append(datetime.fromisoformat(d['registered_utc']));eof=row['actual_EOF'];assert all(1<=a<=z<=eof for a,z in row['displayed_chunks']);displayed={i for a,z in row['displayed_chunks'] for i in range(a,z+1)};scopes.setdefault(local,set()).update(displayed)
 def registered(obj):
  result=[]
  if isinstance(obj,dict):
   if local in (obj.get('source_archive'),obj.get('archive')):
    for key in ('registered_ranges','registered_personal_display_ranges'):
     if key in obj:result.extend(obj[key])
   for v in obj.values():result.extend(registered(v))
  elif isinstance(obj,list):
   for v in obj:result.extend(registered(v))
  return result
 allowed={i for a,z in registered(d) for i in range(a,z+1)};assert displayed<=allowed,(row['registration'],local)
 if local.startswith('source/'):
  source=next(x for x in reg['roles'] if x['source_archive']==local);assert row['displayed_chunks']==source['planned_chunks'] and row['unread_complement']==[] and displayed==set(range(1,eof+1))
assert max(times)<datetime.fromisoformat(receipt['recorded_utc']) and receipt['registration_sha256']==sha((b/'registration.json').read_bytes())
for x in report['observations']:
 for e in x['evidence']:
  assert e['file'] in scopes
  for a,z in e['lines']:assert set(range(a,z+1))<=scopes[e['file']],(e['file'],a,z)
names=['magic-strings','magic-numbers','type-ownership','existing-type-owners','type-granularity','invariant-operations','aggregate-states','admission-contracts','enum-shapes','redundant-authority','behavior-preservation','producer-propagation','derivability'];assert [x['lens'] for x in report['lenses']]==names
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Both original package roles match 059 registry hashes, preserved 0.19.1 archive members and f82 source objects; archive checksum matches both 6533 and 95e locks.','Raw Git commit/tree paths prove exact per-revision locks, bounded 95e source support and f82 historical transport; f82 is not the native package or project revision.','Original 059 records match transport manifest; 774 records match f82 Git trees; selected registry/queue entries are labelled reconstructions.','Full assigned personal displays, separately registered support citations and thirteen bounded lenses are checked.','Prior /root/hair_ops report and support receipt match their preserved manifest; reader attribution is not transferred.'],'scope':'Evidence identity and source scopes only, no macro expansion, execution, product build, test, runtime probe, fixture, repair or product validation.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw) if '--record' in sys.argv else None;print('PASS',sha(raw),'Git proofs',len(proof['paths']),'059 records',len(original['original_059_records']),'read entries',len(receipt['read_entries']))
