from pathlib import Path
import datetime,hashlib,json,tarfile
p=Path(__file__).resolve().parent;arch=p/'archives/bevy_reflect_derive-0.19.1.crate';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
with tarfile.open(arch,'r:gz') as t:
 for i,(path,ranges) in enumerate([('lib.rs',[[50,95]]),('impls/assertions.rs',[[1,13]])]):
  member='bevy_reflect_derive-0.19.1/src/'+path;b=t.extractfile(member).read();local=f'support/native-{i}.rs';(p/local).write_bytes(b);rows.append({'package':'bevy_reflect_derive','version':'0.19.1','archive_member':member,'source_archive':local,'sha256':sha(b),'bytes':len(b),'actual_EOF':len(b.splitlines()),'registered_ranges':ranges,'purpose':'bounded assertion-call routing support, no ordered role credit'})
r={'schema':'726-bevy-remote-native-support-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','archive_sha256':sha(arch.read_bytes()),'sources':rows,'qualification':'Support read only, other agent and historical role authorship unchanged.'};(p/'native-support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((p/'native-support-registration.json').read_bytes()));print([(x['source_archive'],x['registered_ranges']) for x in rows])
