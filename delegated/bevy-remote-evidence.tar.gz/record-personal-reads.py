from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'registration.json').read_text());out=[]
for row in r['roles']:
 out.append({'source':row['source_archive'],'package':row['package'],'version':row['version'],'sha256':row['sha256'],'actual_EOF':row['actual_EOF'],'registration':'registration.json','displayed_chunks':row['planned_chunks'],'unread_complement':[],'role_credit':'Personal full body display; only original material ranges count for historical role scope.'})
for rev,x in r['locks'].items():out.append({'source':x['archive'],'compression':'gzip','revision':rev,'sha256':x['sha256'],'actual_EOF':x['actual_EOF'],'registration':'registration.json','displayed_chunks':x['registered_ranges'],'role_credit':'Package lock support only.'})
for filename in ['project-support-registration.json','native-support-registration.json']:
 d=json.loads((p/filename).read_text())
 for x in d['sources']:
  chunks=x['registered_ranges']
  if x['source_archive']=='support/project-2.rs':chunks=[[1,120],[121,131]]
  out.append({'source':x['source_archive'],'revision':x.get('revision'),'package':x.get('package'),'sha256':x['sha256'],'actual_EOF':x['actual_EOF'],'registration':filename,'displayed_chunks':chunks,'role_credit':'Independently displayed bounded support only, no earlier author credit.'})
r={'schema':'726-bevy-remote-personal-read-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','registration_sha256':sha((p/'registration.json').read_bytes()),'read_entries':out,'qualification':'All source displays occurred after registration and returned untruncated. Whole archived support bytes do not imply reading other lines. No macro expansion, product execution, test, build, runtime probe, repair, or product validation.'};(p/'personal-read-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('entries',len(out),'receipt',sha((p/'personal-read-receipt.json').read_bytes()))
