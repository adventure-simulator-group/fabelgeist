# Delegated MHR layout and skeleton-state audit

The central audit owns the baseline, reconciliation, role statuses, ledger and
publication. This packet covers original roles 2323–2325 and separately
registered support. Start with `report.json`.

`registration.json` and `read-receipt.json` distinguish the historical and
current full personal reads. Support registrations and receipts record exact
bounded support ranges, with no ordered-role credit. Prior current support
reads are preserved independently under `prior-support/` and are not relabeled.
Registration clock values are sampled before writing; filesystem write times
are recorded separately before the subsequent displays.

`git-proofs.json` and `git-objects/` preserve commit and tree membership for
all 13 exact source bodies. `historical-059/` preserves original extraction
records checked against the 059 transport manifest. `older-774/` separately
preserves five exact older original records and two different path-normalized
exports. No earlier evidence substitutes for a missing checkpoint 3821 ledger
or queue.

`evidence-verification.json` describes evidence-only checks. Test source was
read but not run; no product build, repair, fixture, probe or validation ran.
Original records can contain local paths and require reviewed, documented
redaction before publication, preserving original and export hashes.
