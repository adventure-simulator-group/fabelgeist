import hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());sreg=json.loads((p/'support-registration.json').read_text());entries=reg['sources']+sreg['sources']
for e in entries:
 b=(p/e['source_file']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob_sha1'],e['bytes'],e['lines'])
allowed={e['path']:e['planned_display_ranges'] for e in reg['sources'] if e['kind']=='current'};receipt=json.loads((p/'support-read-receipt.json').read_text())
for e in receipt['personal_reads']:allowed[e['path']]=e['ranges']
report=json.loads((p/'report.json').read_text());refs=[]
def walk(v):
 if isinstance(v,dict):
  if {'revision','path','lines'}<=v.keys() and isinstance(v['lines'],list):refs.append(v)
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(report)
for r in refs:
 assert r['revision']==report['current_revision'] and r['path'] in allowed,r
 for a,b in r['lines']:assert any(x<=a<=b<=y for x,y in allowed[r['path']]),r
proof=json.loads((p/'git-proofs.json').read_text());cache={}
for f in (p/'git-objects').iterdir():
 oid,typ=f.name.split('.');b=f.read_bytes();assert hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid;cache[(oid,typ)]=b
for e in proof['proofs']:
 assert b'tree '+e['commit_tree'].encode()+b'\n' in cache[(e['revision'],'commit')];tree=e['commit_tree']
 for item in e['membership']:
  assert item['parent_tree']==tree;expected=item['mode'].encode()+b' '+item['entry'].encode()+b'\0'+bytes.fromhex(item['object']);assert expected in cache[(tree,'tree')];tree=item['object']
 assert tree==e['blob_sha1']==blob((p/e['source_file']).read_bytes())
h=json.loads((p/'historical-059-index.json').read_text())
for e in h['records']:
 b=(p/e['copy']).read_bytes();assert (sha(b),blob(b),len(b))==(e['sha256'],e['git_blob'],e['bytes'])
o=json.loads((p/'older-774/INDEX.json').read_text());assert sha((p/o['export_manifest_copy']).read_bytes())==o['export_manifest_sha256']
for e in o['records']:
 assert sha((p/e['original_copy']).read_bytes())==e['original_sha256']==e['manifest_entry']['original_record_sha256']
 if e['export_differs']:assert sha((p/e['normalized_copy']).read_bytes())==e['normalized_sha256']==e['manifest_entry']['published_export_sha256']
prior=json.loads((p/'prior-support-index.json').read_text())
for e in prior['records']:
 b=(p/e['copy']).read_bytes();assert sha(b)==e['sha256'] and len(b)==e['bytes']
sel=json.loads((p/'registry-selected-reconstructed.json').read_text())
for e in reg['sources']:
 if e['kind']=='historical':assert sel['rows'][e['original_role_index']-2323]['sha256']==e['sha256']
r={'kind':'Evidence-only consistency verification','status':'passed','ordered_bodies':len(reg['sources']),'support_bodies':len(sreg['sources']),'report_source_refs_within_displayed_ranges':len(refs),'git_membership_proofs':len(proof['proofs']),'git_commit_tree_objects':len(cache),'original_059_exact_records':len(h['records']),'older_774_originals':len(o['records']),'separate_normalized_exports':sum(e['export_differs'] for e in o['records']),'prior_support_records':len(prior['records']),'qualification':'Evidence verification only. No product implementation, build, tests, fixtures, runtime probes or product validation.'};(p/'evidence-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
