from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
orig=Path('<LOCAL_PATH_1>')
prev=Path('<LOCAL_PATH_2>')
workspace=Path('<LOCAL_PATH_3>')
h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/n,'recovered/'+n,'Original registry/archive/059 where applicable; reconstructed catalog and later independently reproduced tracked patch remain labelled.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-tactical-core/AGENTS.md','crates/adventuresim-tactical-client/src/animation/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Applicable current rules; last is context for client animation only, not a blanket player rule. User source-only prohibition governs.')
for n in ['ASSESSMENT-ACTION-STATE-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Prior published assessment or later recovery, preserve source/reviewer/range qualifications.')
names=['segovb/READ-L11-457.json','segovb/STATE-L11-457.json','segovb/VERIFY-L11-457.json','adler/READ-L11-213.json']+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in range(1727,1731)]
for n in names:copy(orig/n,'historical/059/'+n,'Exact original 059 receipt/registration; preserve attribution, no personal read transfer.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for owner,folder,names in [
 ('camera','initial07-redundant-authority',['source-range-registration.jsonl','contracts.jsonl','findings.jsonl','progress.jsonl']),
 ('root','initial04-invariant-operations',['source-range-registration.jsonl','source-qualifications.jsonl','contract-groups-097.json','contract-groups-098.json','contract-groups-099.json','coverage.jsonl'])]:
 for n in names:
  gp=f'handoff/774/adler-original/audit/continuation/{owner}/{folder}/{n}'
  raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{owner}-{n}','git:'+rev+':'+gp,'Exact original 774 supplier record via f82 evidence transport.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw)
qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw)
selection={'kind':'Newly reconstructed selected rows from exact historical records; not an original standalone record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in range(2806,2810)},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')],'queue_uncompressed_sha256':h(qraw),'queue_entries':{str(i):q['entries'][i] for i in [63,64,826,1457]},'qualification':'Preserve distinct P16 and PR, old reviewer scopes and original 059/774 historical evidence. No checkpoint3821 promotion.'}
(b/'historical-selections-reconstructed.json').write_text(json.dumps(selection,indent=2)+'\n')
(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'No prior reviewer/lens credit transfer; f82 transports evidence only.'},indent=2)+'\n')
print('records',len(records),'sha256',h((b/'historical-manifest.json').read_bytes()))
