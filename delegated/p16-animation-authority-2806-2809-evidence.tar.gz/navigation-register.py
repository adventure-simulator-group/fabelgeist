from pathlib import Path
from datetime import datetime,timezone
import json
b=Path(__file__).resolve().parent
out={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','kind':'Current navigation match lines only, not full source bodies or old role credit; displayed output lines recorded separately. Additional support requires a separate registration.','queries':[
 {'name':'animation-owners','path':'crates/adventuresim-tactical-core/src/animation','pattern':'IncomingAttackTangent|from_arithmetic|fn action_admission|struct ActionTimeline|fn with_recovery'},
 {'name':'attack-caller','path':'crates/adventuresim-tactical-client/src','pattern':'begin_attack_timed|select_main_attack|select_offhand_attack'},
 {'name':'resident','path':'crates/adventuresim-stdb-module/src','pattern':'fn resolve_settlement_resident|fn conception_parents|fn effective_age_years|fn character_alive_at'},
 {'name':'personality','path':'crates/adventuresim-stdb-module/src','pattern':'fn project_personality|fn set_score|fn refresh_personality|fn apply_personality'}
]}
(b/'navigation-registration.json').write_text(json.dumps(out,indent=2)+'\n')
