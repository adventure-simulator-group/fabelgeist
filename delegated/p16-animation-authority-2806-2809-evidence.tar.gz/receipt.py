from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');nav={};navigation=[]
for name in ['navigation-animation.txt','navigation-curve.txt','navigation-animation-owners.txt','navigation-attack-caller.txt','navigation-resident.txt','navigation-personality.txt']:
 lines=(b/name).read_text().splitlines()
 for line in lines:
  if name in ['navigation-animation.txt','navigation-curve.txt']:
   m=re.match(r'^(\d+):',line);assert m;path='crates/adventuresim-tactical-core/src/animation/state.rs';num=int(m.group(1))
  else:
   m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m;path,num=m.group(1),int(m.group(2))
  nav.setdefault(path,set()).add(num)
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'ordered_role_credit':0,'registration':'registration.json planned full current 2806 source' if name in ['navigation-animation.txt','navigation-curve.txt'] else 'navigation-registration.json'})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
old={2806:[[1707,1752],[1895,1988]],2807:[[1,75]],2808:[[249,303]],2809:[[249,303]]}
current={2806:[[1666,1711],[1854,1947],[1948,1958]],2807:[[1,75]],2808:[[249,303]],2809:[[249,303]]}
assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=(current if j else old)[row['original_index']];shown=nums(d);navonly=sorted(nav.get(row['path'],set())-shown) if j else []
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':navonly,'unread_after_assigned_and_navigation':comp(v['eof'],shown|set(navonly)),'qualification':'Exact current body ranges differ for role2806; 1957–1958 show next signature only. Support displays recorded separately below. P16 1989 blank and character fixture 1–248 are excluded from old role.'})
body={'continuation':[[1,95]],'timeline':[[1,89]],'pose':[[1,45]],'state-admission':[[1795,1823]],'attack-start':[[145,185],[200,270],[350,445]],'resident':[[73,125]],'chronology':[[1,52]],'family':[[90,120]],'reproduction':[[81,145]]}
support=[]
for x in load('support-registration.json')['entries']:
 d=body[x['name']];shown=nums(d);prior=[]
 for row in reg['rows']:
  if row['path']==x['path']:prior=current[row['original_index']]
 prior_set=nums(prior);navonly=sorted(nav.get(x['path'],set())-shown-prior_set)
 support.append({'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement_after_this_support_and_assigned':comp(x['eof'],shown|prior_set|set(navonly)),'qualification':'Other current support on same path separately recorded; this complement does not union other support entries.','ordered_role_credit':0})
x=load('curve-support-registration.json');shown=nums(x['ranges']);prior=current[2806];prev=nums(prior);navonly=sorted(nav.get(x['path'],set())-shown-prev);eof=reg['rows'][0]['versions'][1]['eof']
support.append({'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':eof,'full_line_body_displays':x['ranges'],'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement_after_this_support_and_assigned':comp(eof,shown|prev|set(navonly)),'qualification':'Independently registered current curve support, no P16 historical role credit. Other same-path support separate.','ordered_role_credit':0})
names=['registration.json','navigation-registration.json','support-registration.json','curve-support-registration.json']
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Newly reconstructed exact personal source displays and navigation after prospective registrations. Test and fixture text viewed only, never executed.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'limits':'No product, generated code, macro, test, fixture, build, probe, repair or publication edit.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('sha256',h((b/'read-receipt.json').read_bytes()))
