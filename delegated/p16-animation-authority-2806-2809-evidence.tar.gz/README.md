# Bounded source evidence: original roles 2806–2809

`REPORT.json` records thirteen partial lens perspectives, source references,
historical relationships, conditional findings and open questions.
Registrations and `read-receipt.json` distinguish actual old/current displays,
support, navigation and unread complements. Test and fixture text was inspected
as source only; no outcome was inferred or executed. Distinct P16 and PR
character-fixture identities were separately displayed despite identical bytes.

The P16 animation file differs from the pinned current and 6533 files and
matches a120 per file. The original P16 snapshot was dirty and based at a120.
A later independently reproduced tracked patch matches the historical digest;
seven untracked objects remain separately qualified. Original patch generation
and uninterrupted custody are unestablished. Pr-working is 6533-based with
unrelated modifications. File equality does not make either snapshot clean.
f82 transports original evidence, and 039 is a recorded per-file origin, not
the dirty P16 head.

`historical/` holds exact 059 receipts and 774 supplier records.
`recovered/` preserves the original registry archive and 059 queue/ledger;
the 774 catalog and historical selections are reconstructed records. The
later P16 patch recovery and prior current assessment retain their original
scope and qualifications. No checkpoint 3821 or whole-lens completion is
asserted. The top-level manifest includes nested manifests.

Run `python3 verify-evidence.py` for offline evidence integrity only. It does
not execute product, generated code, macro, fixture, builds or tests.
