'''Offline evidence-integrity verification only; no product, build, fixture or test execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,re,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');sel=load('historical-selections-reconstructed.json');proof=load('git-proofs.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
archive=load('recovered/MANIFEST.json');rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes())
assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256']==archive['registry_sha256']
assert h((b/'recovered/registry.json.gz').read_bytes())==archive['registry_gzip_sha256']
assert h((b/'recovered/objects.tar.gz').read_bytes())==archive['objects_archive_sha256']
registry=json.loads(rbytes);original=registry['files']
assert all(original[i]==sel['registry_rows'][str(i)] for i in range(2806,2810))
assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id'] in ('physical-p16','pr-working')]
qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qraw)==sel['queue_uncompressed_sha256'];q=json.loads(qraw)
assert all(q['entries'][int(k)]==v for k,v in sel['queue_entries'].items())
snapshot=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes()
assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['live_comparison']['status_counts']['??']==7
catalog=load('recovered/catalog-774.json')['rows'];oldranges={2806:[[1707,1752],[1895,1988]],2807:[[1,75]],2808:[[249,303]],2809:[[249,303]]}
current={2806:[[1666,1711],[1854,1947],[1948,1958]],2807:[[1,75]],2808:[[249,303]],2809:[[249,303]]}
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];raw=(b/old['local']).read_bytes()
  assert t.extractfile(old['sha256']).read()==raw and h(raw)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256']
  assert original[i]['material_ranges']==oldranges[i]==row['original_material_ranges']
  origin='039329518e264f19206cf5b0b98d177433f40c17' if row['snapshot']=='physical-p16' else '6533e444fa37552927070cc8d8190907fd3b413e'
  assert catalog[i]['origin']=='git:'+origin+':'+row['path']
  assert ((b/cur['local']).read_bytes()==raw)==cur['equals_historical_object']==(i!=2806)
  for c in row['comparison_git_paths']:assert ((b/c['local']).read_bytes()==raw)==c['equals_historical_object'] and not c['display_planned']
assert reg['rows'][0]['comparison_git_paths'][0]['equals_historical_object'] and not reg['rows'][0]['comparison_git_paths'][1]['equals_historical_object']
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(x['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(rr):return [i for a,z in rr for i in range(a,z+1)]
def part(n,rr,lines):
 v=nums(rr)+lines
 return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes()
  assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof']
  assert set(nums(p['actual_display_chunks']))==set(nums((current if j else oldranges)[row['original_index']]))
  assert part(v['eof'],p['actual_display_chunks']+p['unread_after_assigned_and_navigation'],p['navigation_only_lines_at_assigned_scope'])
  assert p['original_material_ranges']==(oldranges[row['original_index']] if j==0 else [])
planned={x['local']:x for x in load('support-registration.json')['entries']};curve=load('curve-support-registration.json')
for p in rec['support']:
 e=curve if p['local']==curve['local'] else planned[p['local']];raw=(b/p['local']).read_bytes()
 assert h(raw)==p['sha256']==e['sha256'] and len(raw.splitlines())==p['eof'] and p['ordered_role_credit']==0
 assert set(nums(p['full_line_body_displays']))==set(nums(e['ranges']))
 assert part(p['eof'],p['full_line_body_displays']+p['prior_assigned_displays_of_same_pinned_path']+p['unread_complement_after_this_support_and_assigned'],p['navigation_only_lines'])
nav={}
for x in rec['navigation_output_receipts']:
 raw=(b/x['output']).read_bytes();lines=raw.decode().splitlines();assert h(raw)==x['sha256'] and len(lines)==x['saved_output_lines']
 displayed=nums(x['personally_displayed_output_lines']);unread=nums(x['unread_saved_output_lines'])
 assert set(displayed+unread)==set(range(1,len(lines)+1)) and len(displayed)+len(unread)==len(lines)
 for j in displayed:
  if x['output'] in ['navigation-animation.txt','navigation-curve.txt']:
   m=re.match(r'^(\d+):(.*)$',lines[j-1]);assert m;path='crates/adventuresim-tactical-core/src/animation/state.rs';num=int(m.group(1));body=m.group(2)
  else:
   m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):(.*)$',lines[j-1]);assert m;path,num,body=m.group(1),int(m.group(2)),m.group(3)
  nav.setdefault(path,set()).add(num)
  for p in rec['support']:
   if p['path']==path:assert (b/p['local']).read_text().splitlines()[num-1]==body
  for row in reg['rows']:
   if row['path']==path:assert (b/row['versions'][1]['local']).read_text().splitlines()[num-1]==body
assert {k:sorted(v) for k,v in nav.items()}==rec['navigation_actual_source_lines']
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
camera=readjsonl('historical/774/camera-source-range-registration.jsonl');root=readjsonl('historical/774/root-source-range-registration.jsonl')
for i in range(2806,2810):
 ob=original[i]['scope_registration'][0];rows=root if i==2806 else camera
 assert rows[ob['row_1based']-1]==ob['original_record']
qual=readjsonl('historical/774/root-source-qualifications.jsonl')
assert next(x for x in qual if x.get('id')=='ROOT-INITIAL04-REG015-EFFECTIVE-RANGES')['effective_material_ranges']==oldranges[2806]
contracts=readjsonl('historical/774/camera-contracts.jsonl');assert any(x.get('id')=='CAMERA-INITIAL07-CONTRACT-154' for x in contracts)
r=load('historical/059/segovb/READ-L11-457.json')
for i in range(2806,2810):
 x=next(x for x in r['sources'] if x['original_index']==i);raw=(b/f'historical/059/segovb/REGISTRATION-SEGOVB-{i-1079}.json').read_bytes()
 assert x['fresh_personal_body_reads']==oldranges[i] and h(raw)==x['registration_sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and len(proof['proofs'])==37
if (b/'MANIFEST.json').exists():
 seen=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert h(raw)==x['sha256'] and len(raw)==x['bytes'],x['path'];seen.add(x['path'])
 assert seen=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p!=b/'MANIFEST.json'}
print('PASS: distinct P16/PR role identities 2806–2809, old/current display scopes, 059/774 qualifications, registry/archive/P16 patch and 37 Git proofs; thirteen bounded perspectives; evidence only.')
