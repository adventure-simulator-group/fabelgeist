from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[
('continuation','crates/adventuresim-tactical-core/src/animation/continuation_parameters.rs',[[1,95]]),
('timeline','crates/adventuresim-tactical-core/src/animation/state/action_timeline.rs',[[1,89]]),
('pose','crates/adventuresim-tactical-core/src/animation/pose_coordinates.rs',[[1,45]]),
('state-admission','crates/adventuresim-tactical-core/src/animation/state.rs',[[1795,1823]]),
('attack-start','crates/adventuresim-tactical-client/src/player/attack_start.rs',[[145,185],[200,270],[350,445]]),
('resident','crates/adventuresim-stdb-module/src/settlement_population.rs',[[73,125]]),
('chronology','crates/adventuresim-stdb-module/src/relationship/chronology.rs',[[1,52]]),
('family','crates/adventuresim-stdb-module/src/relationship/family.rs',[[90,120]]),
('reproduction','crates/adventuresim-stdb-module/src/relationship/reproduction.rs',[[81,145]])
]
entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 assert max(z for a,z in ranges)<=len(raw.splitlines())
 entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':'support/'+name+'.rs'});pending.append((name,raw))
out={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively registered current connected production support only, not ordered-role credit; archived full bytes do not establish full source reads.','entries':entries}
(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n')
for name,raw in pending:
 p=b/('support/'+name+'.rs');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(out,indent=2))
