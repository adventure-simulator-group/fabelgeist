#!/usr/bin/env python3
"""Read-only evidence verification; no product code is executed."""
import gzip,hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes());assert r['registered_utc']<receipt['at'];assert len(receipt['reads'])==4
for x in receipt['reads']:
 b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof'];covered=set()
 for a,z in x['actual_display_ranges']:covered.update(range(a,z+1))
 assert covered==set(range(1,x['eof']+1)) and not x['unread_ranges']
for x in r['rows']:
 assert x['objects'][0]['sha256']==x['registry_entry']['sha256'];assert x['objects'][0]['sha256']!=x['objects'][1]['sha256']
checks.append('prospective old/current registration, four full personally displayed bodies and historical/current changed hashes')
s=load('support-read-receipt.json');regs={x['file']:load(x['file']) for x in s['registrations']}
for x in s['registrations']:assert sha((p/x['file']).read_bytes())==x['sha256'] and regs[x['file']]['at']<s['at']
for x in s['reads']:
 b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof'];assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['prospective_ranges']==x['actual_ranges'] for d in regs.values() for y in d['rows'])
checks.append('all bounded support reads match prospective revision-specific registrations')
arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==r['registry_uncompressed_sha256'];registry=json.loads(orig)
 trans=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in trans['entries']}
for x in r['rows']:assert x['registry_entry']==registry['files'][x['original_index']]
for x in load('historical-index.json')['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('original registry and 17 exact 059 records against transport; four exact 774 records')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==20
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('20 raw Git membership chains for 6533, 95e, historical e275 and f82 evidence transport')
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14));queue=json.loads((pub/'baseline-059/queue.json').read_bytes());assert queue['entries'][607]['contract_id']=='Q-L11-01dcab8eb13355a19aeb' and queue['entries'][1332]['contract_id']=='Q-L12-8983b8d31c660057035c'
checks.append('13 bounded lens perspectives and original queue identities with no transferred credit')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence identity/accountancy only; no product execution, testing, build, probes, simulation, rendering, implementation, publication edit, all-lens closure or checkpoint3821 promotion.'},indent=2))
