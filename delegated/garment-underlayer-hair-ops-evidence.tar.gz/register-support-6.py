import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda b:hashlib.sha256(b).hexdigest();base='crates/adventuresim-character-creator/src/';specs=[('garment_material/rings.rs',[[1,95]]),('main.rs',[[290,345]]),('inventory.rs',[[345,370]])];sources=[]
for i,(path,ranges) in enumerate(specs,31):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+base+path]);n=len(b.splitlines());ranges=[[a,min(z,n)] for a,z in ranges if a<=n];loc=f'support/{i:02d}.rs';(p/loc).write_bytes(b);sources.append({'path':base+path,'revision':rev,'sha256':h(b),'bytes':len(b),'eof':n,'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+base+path],text=True).strip(),'saved':loc,'prospective_ranges':ranges,'scope':'separately registered support only'})
(p/'support-registration-6.json').write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':sources},indent=2)+'\n');print('registration',h((p/'support-registration-6.json').read_bytes()));
for s in sources:print(s['saved'],s['path'],s['eof'],s['prospective_ranges'])
