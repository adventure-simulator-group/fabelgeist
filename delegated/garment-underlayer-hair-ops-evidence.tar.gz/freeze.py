import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();r=subprocess.run(['python3',str(p/'verify-evidence.py')],capture_output=True,text=True,check=True);(p/'evidence-verification.json').write_text(json.dumps({'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'python3 verify-evidence.py','exit_code':r.returncode,'stdout':r.stdout,'qualification':'Evidence integrity only; no product execution, build, test, probe or validation.'},indent=2)+'\n');files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='MANIFEST.json':
  b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':h(b)})
(p/'MANIFEST.json').write_text(json.dumps({'qualification':'Frozen bounded packet. Exact linked evidence is in historical-manifest; no product execution or validation.','files':files},indent=2)+'\n');r=subprocess.run(['python3',str(p/'verify-evidence.py')],capture_output=True,text=True,check=True);print(r.stdout.strip());print('report sha256',h((p/'REPORT.json').read_bytes()));print('manifest sha256',h((p/'MANIFEST.json').read_bytes()));print('files',len(files),'local_bytes',sum(x['bytes'] for x in files))
