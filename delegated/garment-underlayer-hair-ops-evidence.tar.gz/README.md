# Garment selection and underlayer: roles 2597–2598

`REPORT.json` is a bounded source assessment for central reconciliation. Its
new conditional mail-preview candidate requires a previously generated mesh and
an invalid later programmatic mutation; no ordinary UI reachability or observed
failure is claimed. The fitted-coif/fabric policy is an earlier Segovb question
with a new, separately attributed current source trace. The coif validation
error is an earlier 059 finding, not a new historical count.

`registration.json` predates separately displayed original pr-working and
current 95e bodies. `read-receipt.json` records their exact display ranges and
all bounded current support windows and unread complements. Equal 6533 source
bytes were checked but not separately displayed. `git-proofs.json` plus
`git-objects/` bind per-file revision and transport identities; f82 is historical
source transport, not a product snapshot. The overall pr-working state had
unrelated recorded modifications.

`historical/` retains exact copied 774 and 059 records alongside a clearly
labeled reconstructed selection of original queue entries. The original
source archive, full 059 queue and prior published assessments are hash-linked
in `historical-manifest.json`; preserve or relink those exact dependencies for
standalone publication. Original source ranges, agents and qualifications remain
separate; no evidence is promoted into checkpoint 3821.

`python3 verify-evidence.py` checks evidence identity and recorded partitions.
No product source or publication edits, builds, tests, product execution,
viewer, rendering, browser, simulated fixtures, runtime probes, repair or
product validation were performed. The manifest hashes packet files except
itself.
