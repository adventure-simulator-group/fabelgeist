import datetime,hashlib,json
from pathlib import Path
p=Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest(); names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json','support-registration-6.json','support-registration-7.json'];w={0:[[1,110]],1:[[1,70]],2:[[120,199]],3:[[40,125]],4:[[1,120],[121,240]],5:[[1,70]],6:[[1,120]],7:[[1,90]],8:[[1,99]],9:[[1,125]],10:[[1,130]],11:[[100,210]],12:[[1,160]],13:[[1,55]],14:[[1,82]],15:[[1,110],[160,220]],16:[[1,150]],17:[[1,145]],18:[[215,250],[320,410]],19:[[1,110]],20:[[131,175]],21:[[1,119]],22:[[1,120],[121,180]],23:[[195,230]],24:[[285,319]],25:[[90,168]],26:[[1,120],[121,220]],27:[[1,85]],28:[[170,260]],29:[[250,312]],30:[[176,250]],31:[[1,95]],32:[[290,345]],33:[[345,370]],34:[[1,35]]}
def complement(n,rs):
 used=set();[(used.update(range(a,z+1))) for a,z in rs];r=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):r.append([start,i-1]);start=None
 return r
reads=[]
for n in names[1:]:
 for x in json.loads((p/n).read_bytes())['sources']:
  i=int(Path(x['saved']).stem);ranges=w[i]
  for a,b in ranges:assert any(q<=a<=b<=z for q,z in x['prospective_ranges'])
  reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['eof'],'displayed':ranges,'unread_complement':complement(x['eof'],ranges),'qualification':'bounded support only; stored body and other reviewer scopes do not confer ordered-role credit'})
obj={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in names],'assigned':[{'role':2597,'pr_working_actual_display':[[1,140],[141,271]],'current_95e_actual_display':[[1,140],[141,271]],'unread_old_and_current':[]},{'role':2598,'pr_working_actual_display':[[1,137]],'current_95e_actual_display':[[1,137]],'unread_old_and_current':[]}],'other_revision':'6533 copies were verified by byte/Git identity only, not separately displayed. pr-working and 95e bodies personally displayed separately.','support':reads,'constraints':'Source and historical evidence only. Tests in source were not run.'};(p/'read-receipt.json').write_text(json.dumps(obj,indent=2)+'\n');print('receipt sha',h((p/'read-receipt.json').read_bytes()),'supports',len(reads))
