import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);selection=load('registry-selection-reconstructed.json');assert all(registry['files'][int(k)]==v for k,v in selection['roles'].items());assert selection['snapshot']==[x for x in registry['snapshots'] if x['id'] in ('pr-working','physical-p16')];assert [registry['files'][i]['material_ranges'] for i in (2834,2835)]==[[[1,382]],[[1,358]]];assert [registry['files'][i]['snapshot'] for i in (1061,1064,2834,2835)]==['pr-working','pr-working','physical-p16','physical-p16'];assert registry['files'][1061]['sha256']==registry['files'][2834]['sha256'] and registry['files'][1064]['sha256']==registry['files'][2835]['sha256']
trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue);assert all(q['entries'][int(k)]==v for k,v in load('queue-selection-reconstructed.json')['entries'].items())
for n in ('reference-index.json','rules.json','skills.json'):
 for e in load(n)['records']:assert sha((p/e['file']).read_bytes())==e['sha256'],e['file']
patch=(p/'reference/p16-tracked.patch').read_bytes();snap=[x for x in registry['snapshots'] if x['id']=='physical-p16'][0];assert sha(patch)==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';x=load('p16-per-file-qualification.json');assert x['status_rows']==len(snap['status_porcelain'])==159
for e in x['files']:
 path=e['path'];assert e['snapshot_status_matches']==[a for a in snap['status_porcelain'] if a[3:]==path];assert e['tracked_patch_contains_diff_header']==(f'diff --git a/{path} b/{path}\n'.encode() in patch)
groups=[('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('support2','support2-registration.json','support2-read-receipt.json'),('support3','support3-registration.json','support3-read-receipt.json')]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'] and blob(body)==a['git_blob'] and len(body.splitlines())==a['EOF'] and a['archive']==b['archive'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[name]=len(r['entries'])
r=load('registration.json')
for e in r['entries']:
 row=registry['files'][e['original_index']];assert (e['source_id'],e['snapshot'],e['sha256'],e['EOF'],e['registered_ranges'])==(row['source_id'],row['snapshot'],row['sha256'],row['actual_line_count'],row['material_ranges'])
assert all(v['equals_archived'] for c in r['comparisons'] for v in c['versions'].values())
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
hist=p/'history-059/segovb';receipt=json.loads((hist/'READ-L11-460.json').read_bytes());state=json.loads((hist/'STATE-L11-460.json').read_bytes());v=json.loads((hist/'VERIFY-L11-460.json').read_bytes());assert receipt['current_reconciled'] is False and receipt['accepted_unique_count_change']==0 and state['accepted_unique_count_change']==0 and v['gate'] is False;assert state['receipt_sha256']==sha((hist/'READ-L11-460.json').read_bytes())==v['receipt_sha256'];assert v['state_sha256']==sha((hist/'STATE-L11-460.json').read_bytes())
for role,num,scope in [(2834,1755,[[1,382]]),(2835,1756,[[1,358]])]:
 f=hist/f'REGISTRATION-SEGOVB-{num}.json';x=json.loads(f.read_bytes());src=[s for s in receipt['sources'] if s['original_index']==role];assert len(src)==1 and src[0]['registration_sha256']==sha(f.read_bytes()) and src[0]['assessed_ranges']==src[0]['fresh_personal_body_reads']==x['ranges']==scope and x['sha256']==registry['files'][role]['sha256'] and x['prospective']
l3=p/'history-059/root-l3-extension-20261030';receipt=json.loads((l3/'READ-ROOT-L3-EXT-016-017.json').read_bytes());row=receipt['rows'][0];f=l3/'REGISTRATION-ROOT-L3-EXT-016-017.json';assert row['registration_ref']['sha256']==sha(f.read_bytes()) and row['source_sha256']==registry['files'][2834]['sha256'] and row['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and row['fresh_personal_ranges']==[[1,383]] and row['body_output_truncated'] is False
for e in load('registration-version-qualification.json')['records']:
 rec=registry['files'][e['role']]['scope_registration'][0];raw=gzip.decompress((p/e['f82_file']).read_bytes());lines=raw.splitlines();assert sha(raw)==e['transported_uncompressed_sha256']!=rec['sha256']==e['registry_recorded_whole_file_sha256'];assert json.loads(lines[rec['row_1based']-1])==rec['original_record'] and e['row_matches'] and not e['simple_prefix_matches']
 for i in range(1,len(lines)+1):
  for sep in (b'\n',b'\r\n'):
   for end in (sep,b''):assert sha(sep.join(lines[:i])+end)!=rec['sha256']
x=json.loads(gzip.decompress((p/'history-774/root/admission03/new-parallel-admission-206.json.gz').read_bytes()))
for role,scope in [(2834,[[1,382]]),(2835,[[1,358]])]:assert [z['actual_compared_ranges'] for z in x['source_roles'] if z['source_id']==registry['files'][role]['source_id']]==[scope]
quals=[json.loads(z) for z in gzip.decompress((p/'history-774/native/initial05-aggregate-states/source-qualifications.jsonl.gz').read_bytes()).splitlines()]
for key,scope in [('NATIVE-INITIAL05-REG044',[[1,382]]),('NATIVE-INITIAL05-REG045',[[1,358]])]:assert [z['qualified_material_ranges'] for z in quals if z.get('registration_id')==key]==[scope]
findings=[json.loads(z) for z in gzip.decompress((p/'history-774/native/initial05-aggregate-states/findings.jsonl.gz').read_bytes()).splitlines()];assert {'NATIVE-INITIAL05-F045','NATIVE-INITIAL05-F046'}<={x.get('id') for x in findings}
x=load('prior-index.json');m=json.loads((p/x['manifest']).read_bytes());assert sha((p/x['manifest']).read_bytes())==x['manifest_sha256'];directory=(p/x['manifest']).parent;d={z['path']:z for z in m['files']}
for s in x['subset']:
 f=directory/s;assert (len(f.read_bytes()),sha(f.read_bytes()))==(d[s]['bytes'],d[s]['sha256'])
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==22;report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13;assert len(load('read-scope-summary.json')['scopes'])==sum(counts.values())
print(json.dumps({'status':'pass','scope':'Offline historical source and registration rows, P16 patch identity, original 059/774 records, prior packet subset bindings, exact personal read receipts/unread complements, and raw Git tree proofs; no product validation.','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
