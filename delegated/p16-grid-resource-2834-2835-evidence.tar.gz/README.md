# P16 logic grid and resource allocation evidence

This packet records /root/mhr_character's independent source-only assessment
of historical physical-p16 roles 2834 and 2835 against project revision
95e63628f9d70b8dd6e6fede64334696c6995009. Exact assigned historical objects
individually match a120, 6533 and 95e Git paths. The P16 snapshot remains dirty;
the later recovered tracked patch matches the recorded hash and excludes seven
untracked paths. The f82 revision transports evidence, not the product source.

`report.json` records conditional findings, nonfindings, historical links, open
questions and thirteen bounded perspectives. `read-scope-summary.json` derives
personal display scopes from prospective registrations and receipts. Both
historical and current grid lines 383–407 and resource lines 359–373 remain
unread. Full archived bytes prove identity, not personal coverage. The prior
packet subset is separately attributed and does not transfer source or role
credit, including neighboring roles 2828–2833 assigned to another reviewer.

`history-059/` records match the recovered original transport manifest;
`history-774/` records are bound to the f82 tree. Original native registration
rows match the transported JSONL, while the earlier registry-recorded
whole-file hash differs; `registration-version-qualification.json` preserves
the discrepancy. Registry and queue selections are reconstructed, not original
records. All previous author, revision, range and qualification limits remain.
No checkpoint 3821 restoration or complete lens is claimed.

`git-proofs.json` and `git-objects/` preserve raw commit and tree proofs. Run
`python3 verify-evidence.py` and `python3 verify-manifest.py` only for offline
evidence integrity; no product, fixture, test, or runtime validation occurs.
The central coordinator owns reconciliation, publication and finding counts.
