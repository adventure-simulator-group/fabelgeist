#!/usr/bin/env python3
"""Read-only, evidence-only review replay; never executes product source."""
import argparse,hashlib,json,os,re,stat,sys,tarfile,zlib
from pathlib import Path
if sys.flags.optimize:raise RuntimeError('assertions required')
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(root):
 d={}
 for x in sorted(root.rglob('*')):
  if x.is_symlink():raise AssertionError('symlink')
  if x.is_file() and x.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   b=x.read_bytes();d[x.relative_to(root).as_posix()]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(x.stat().st_mode),'04o')}
 return d
def check_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert inventory(root)==m['files'];assert all(x['mode']=='0600' for x in m['files'].values())
def child(data,name):
 i=0
 while i<len(data):
  s=data.index(b' ',i);n=data.index(b'\0',s);mode=data[i:s].decode();entry=data[s+1:n].decode();oid=data[n+1:n+21].hex();i=n+21
  if entry==name:return mode,oid
 raise AssertionError('tree member absent')
def git_proof(root):
 p=json.loads((root/'EDE-GIT-PROOF.json').read_bytes());objects={}
 for oid,m in p['objects'].items():
  packed=(root/'git-objects'/(oid+'.zlib')).read_bytes();assert sha(packed)==m['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid;h,b=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert kind==m['type'] and len(b)==int(size)==m['size'] and sha(b)==m['sha256'];objects[oid]=(kind,b)
 found={}
 for x in p['proofs']:
  rev=x['revision'];assert rev=='ede12d3f9f19d284abbc669b5ae38b814a585f77' and objects[rev][0]=='commit';tree=objects[rev][1].split(b'\n',1)[0][5:].decode()
  for i,name in enumerate(x['path'].split('/')):
   mode,oid=child(objects[tree][1],name)
   if i<len(x['path'].split('/'))-1:assert mode in ('40000','040000');tree=oid
   else:assert mode in ('100644','100755') and oid==x['blob'] and objects[oid][0]=='blob';body=objects[oid][1]
  assert body==(root/x['capture']).read_bytes() and sha(body)==x['sha256'];found[x['path']]=body
 assert len(found)==5;return found
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();pub=Path(__file__).resolve().parent;check_manifest(pub,'MANIFEST.json');print('public review manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 p=args.private.resolve();check_manifest(p,'MANIFEST-PRIVATE.json');g=git_proof(p);record=json.loads((p/'input-RECORD.json').read_bytes());raw=(p/'input-APPLICATION-EVIDENCE.tar.gz').read_bytes();assert sha(raw)==record['archive_sha256']=='8258beca64c44bfc8358ed304aa8f905a8db03b57a9c0a000534e4905dd0b653' and len(raw)==record['archive_bytes'];wanted={x['path']:x for x in record['members']};data={}
 with tarfile.open(p/'input-APPLICATION-EVIDENCE.tar.gz','r:gz') as t:
  for x in t.getmembers():
   assert x.isfile() and x.name in wanted and x.name not in data and not x.name.startswith('/') and '..' not in x.name.split('/');b=t.extractfile(x).read();m=wanted[x.name];assert (len(b),sha(b),oct(x.mode))==(m['bytes'],m['sha256'],m['mode']);assert b==(p/'members'/x.name).read_bytes();data[x.name]=b
 assert len(data)==len(wanted)==12
 for n in ['BASELINE-95E-20261110.json','CONTINUATION-PROGRESS-95E.json','CONTINUATION.md','RECONCILIATION-059.json']:assert data['before/'+n]==g[n]
 assert (p/'input-PREDECESSOR-WRAPPER.py').read_bytes()==g['verify_postd7a5_application.py'] and sha(g['verify_postd7a5_application.py'])=='98a48f4e231d278ed9c5885401cbcf979f10531067256e6f33de7da5d1d73f36'
 draft=json.loads(data['inputs/draft-v2.json']);report=json.loads(data['inputs/report.json']);assert data['inputs/draft-v2.json']==(p/'input-DRAFT-v2.json').read_bytes() and sha(data['inputs/draft-v2.json'])=='51f6948e954ed9caf794e342631a74491366b60a1202fe4556f8ddb37e38f269';assert all(report[k]==draft[k] for k in draft if k!='status');assert set(report)-set(draft)=={'adopted_from_draft_sha256','combined_independent_review','adoption_qualification'} and report['adopted_from_draft_sha256']==sha(data['inputs/draft-v2.json'])
 for k in ('semantic_queue_closures','accepted_unique_defect_increment','lens_completions'):assert report['counts'][k]==0
 assert report['repair']=='not started' and report['product_validation']=='not performed' and 'not independent-author' in report['independent_review_qualification']
 b=json.loads(data['before/BASELINE-95E-20261110.json']);a=json.loads(data['after/BASELINE-95E-20261110.json']);old=b['newly_assessed_ledger']['entries'];new=a['newly_assessed_ledger']['entries'];assert len(old)==1099 and len(new)==1101 and new[:1099]==old;expected=[]
 for row in report['ledger_relationships']:
  x=dict(row['record']);x['record']='ASSESSMENT-CENTRAL-FOLLOWUPS-18-95E.json';expected.append(x)
 assert new[1099:]==expected and len(set(x['id'] for x in new))==1101 and all(x['repair']=='not started' and x['validation']=='not performed' for x in expected)
 assert {k for k in b if b[k]!=a[k]}=={'newly_assessed_ledger','latest_main_recheck'}
 q0=json.loads(data['before/RECONCILIATION-059.json']);q1=json.loads(data['after/RECONCILIATION-059.json']);assert len(q0['entries'])==len(q1['entries'])==3713 and [i for i,(x,y) in enumerate(zip(q0['entries'],q1['entries'])) if x!=y]==[3064,3207];assert {k:v for k,v in q0.items() if k!='entries'}=={k:v for k,v in q1.items() if k!='entries'}
 for i in [3064,3207]:
  x,y=q0['entries'][i],q1['entries'][i];assert x['current_reconciliation']=='unassessed' and y['current_reconciliation'].startswith('partial') and 'no semantic queue or lens closure' in y['current_reconciliation'];assert {k:v for k,v in x.items() if k not in ('current_reconciliation','further_current_evidence')}=={k:v for k,v in y.items() if k not in ('current_reconciliation','further_current_evidence')}
 pending=json.loads(data['inputs/pending.json']);ids=[x['queue_index'] for x in pending['packets']];assert ids==[3231,3232,3234,3235,3243,3244,3246,3247,3255,3256,3258,3259,3267,3268,3270,3271,3305,3306,3308,3309,3317,3318,3320,3321,3329,3330,3332,3333]
 for x in pending['packets']:
  i=x['queue_index'];y=q1['entries'][i];assert q0['entries'][i]==y and y['current_reconciliation']=='unassessed' and y['contract_id']==x['historical_contract_id'] and y['historical_lens']==x['historical_lens']
 previous=json.loads((p/'stage-PENDING-DELEGATES-v1.json').read_bytes());assert len(previous['packets'])==24 and previous['packets']==pending['packets'][:24]
 for src,name in [('report.json','ASSESSMENT-CENTRAL-FOLLOWUPS-18-95E.json'),('pending.json','PENDING-DELEGATES.json'),('main-observation.json','MAIN-RECHECK-20261113-0140.json')]:assert data['inputs/'+src]==(p/'stage-inputs'/name).read_bytes()
 groups=['transport','late-transport','late2-transport'];count=0
 for group in groups:
  root=p/'pending-transport'/group;man=json.loads((root/'MANIFEST.json').read_bytes());lookup={x['file']:x for x in man['bundles']}
  for name in sorted(set(Path(x['source_packet']).name for x in pending['packets'] if x['source_packet'].startswith(group+'/'))):
   x=lookup[name];raw=(root/name).read_bytes();assert len(raw)==x['archive_bytes'] and sha(raw)==x['archive_sha256'];expected={z['path']:z for z in x['members']};seen=set()
   with tarfile.open(root/name,'r:gz') as t:
    for item in t.getmembers():
     assert item.isfile() and item.name in expected and item.name not in seen;seen.add(item.name);bb=t.extractfile(item).read();e=expected[item.name];assert (len(bb),sha(bb),oct(item.mode))==(e['bytes'],e['sha256'],e['mode'])
     if group=='late2-transport' and item.name.endswith('/MANIFEST.json'):assert sha(bb)=='133ee6e1a063c2cc1486901dd5dfdfb3baaa7715b0861a3793e899ecf43e9016'
   assert seen==set(expected);count+=1
 assert count==7
 p0=json.loads(data['before/CONTINUATION-PROGRESS-95E.json']);p1=json.loads(data['after/CONTINUATION-PROGRESS-95E.json']);changed={k for k in set(p0)|set(p1) if p0.get(k)!=p1.get(k)};assert changed=={'central_postede12_bounded_reconciliations','checkpoint_ede12_same_machine_recovery','current_main_qualification','main_recheck_20261113_0140','new_current_ledger_candidates','postede12_pending_delegated_packets','postede12_private_recovery'};assert (p0['new_current_ledger_candidates'],p1['new_current_ledger_candidates'])==(1099,1101)
 d0=data['before/CONTINUATION.md'];d1=data['after/CONTINUATION.md'];marker=b'product validation is authorized here.\n\n';assert d0.count(marker)==1;pos=d0.index(marker)+len(marker);suffix=d0[pos:];assert d1.startswith(d0[:pos]) and d1.endswith(suffix);insert=d1[pos:len(d1)-len(suffix)].decode();assert [len(x) for x in insert.splitlines() if len(x)>80]==[91];idx=(p/'stage-INDEX.md').read_text().splitlines();assert [len(x) for x in idx if len(x)>80]==[132,89]
 assert json.loads((p/'shadow-replay/RECEIPT.json').read_bytes())['exit']==0
 print('restricted manifest, ede Git path proofs, archived draft, queue/ledger changes, 28 pending, seven transports and stage snapshots: PASS')
 print('Markdown prose over 80 columns: continuation 91; index 132, 89. Same-author role0048 and hair qualifications apply; no product validation or independent-custody claim.')
if __name__=='__main__':main()
