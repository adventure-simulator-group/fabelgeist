#!/usr/bin/env python3
"""Evidence-only wrapping review; never executes product source."""
import argparse,ast,collections,hashlib,json,os,stat,subprocess,sys,tarfile
from pathlib import Path
if sys.flags.optimize:raise RuntimeError('assertions required')
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(root):
 d={}
 for x in sorted(root.rglob('*')):
  if x.is_symlink():raise AssertionError('symlink')
  if x.is_file() and x.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   b=x.read_bytes();d[x.relative_to(root).as_posix()]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(x.stat().st_mode),'04o')}
 return d
def check_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert inventory(root)==m['files'];assert all(x['mode']=='0600' for x in m['files'].values())
def archive(root):
 r=json.loads((root/'RECORD.json').read_bytes());raw=(root/r['archive']).read_bytes();assert (len(raw),sha(raw))==(r['archive_bytes'],r['archive_sha256']);wanted={x['path']:x for x in r['members']};data={}
 with tarfile.open(root/r['archive'],'r:gz') as t:
  for x in t.getmembers():
   assert x.isfile() and x.name in wanted and x.name not in data and not x.name.startswith('/') and '..' not in x.name.split('/');b=t.extractfile(x).read();v=wanted[x.name];assert (len(b),sha(b),oct(x.mode))==(v['bytes'],v['sha256'],v['mode']);data[x.name]=b
 assert set(data)==set(wanted) and len(data)==12;return data
def paragraphs(s):return [p.split() for p in s.split('\n\n')]
def ast_except_insert(text):
 tree=ast.parse(text);seen=0
 for node in ast.walk(tree):
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='insert' for t in node.targets):node.value=ast.Constant(value='WRAPPING-PARAGRAPH');seen+=1
 assert seen==1;return ast.dump(tree,include_attributes=False)
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();pub=Path(__file__).resolve().parent;check_manifest(pub,'MANIFEST.json');print('public review manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 p=args.private.resolve();check_manifest(p,'MANIFEST-PRIVATE.json');old=p/'application';new=p/'application-v2';o=archive(old);n=archive(new)
 assert sha((old/'APPLICATION-EVIDENCE.tar.gz').read_bytes())=='8258beca64c44bfc8358ed304aa8f905a8db03b57a9c0a000534e4905dd0b653';assert sha((new/'APPLICATION-EVIDENCE.tar.gz').read_bytes())=='615f93bf1959b1db337bd418f6938480fb8046026de67cbc2f0459c6e2618838'
 assert set(o)==set(n) and [k for k in sorted(o) if o[k]!=n[k]]==['after/CONTINUATION.md'];x=o['after/CONTINUATION.md'].decode();y=n['after/CONTINUATION.md'].decode();assert paragraphs(x)==paragraphs(y)
 oldlong=collections.Counter(s for s in x.splitlines() if len(s)>80);newlong=collections.Counter(s for s in y.splitlines() if len(s)>80);assert [len(s) for s in (oldlong-newlong)]==[91] and not (newlong-oldlong) and sorted(len(s) for s in newlong.elements())==[81,81,81,87,90,132]
 index0=(p/'stage-INDEX-v3.md').read_text();index1=(p/'stage-INDEX.md').read_text();assert sha(index0.encode())=='d51124c4d7e96334f82788c684cac22d3c0e71855fac65c729fd31f4558cd38a' and sha(index1.encode())=='4b442f025d3684a85adaff4c402bd75c7fb372b4a7b536a2494c8a246f62f2bc';assert paragraphs(index0)==paragraphs(index1) and all(len(s)<=80 for s in index1.splitlines())
 for name in ['TRANSFORM-v1.py','PREDECESSOR-WRAPPER.py','VERIFY.py']:assert (old/name).read_bytes()==(new/name).read_bytes()
 assert ast_except_insert((old/'TRANSFORM.py').read_text())==ast_except_insert((new/'TRANSFORM.py').read_text())
 prior=p/'prior-review';assert sha((prior/'public/MANIFEST.json').read_bytes())=='e8d4811095c9cf501076466ee31e24f9d467939de373f2bf847750f50cb0f78a' and sha((prior/'private/MANIFEST-PRIVATE.json').read_bytes())=='14ba743d161a366110e9321e5bc1fec5f0d556c48da9f3fff3a00710c76b1ada'
 for name in ['TRANSFORM-v1.py','PREDECESSOR-WRAPPER.py','TRANSFORM.py','VERIFY.py','RECORD.json','APPLICATION-EVIDENCE.tar.gz']:assert (old/name).read_bytes()==(prior/'private'/('input-'+name)).read_bytes()
 wording=json.loads((p/'wording-review/RECORD.json').read_bytes());assert sha((p/'wording-review/RECORD.json').read_bytes())=='37ed8a2848511d5dc090cb3996a76a5f4c66d627dbae34da7debb1fff135a548'
 for path,h in wording['identities'].items():
  file=p/('stage-'+path) if path.startswith('INDEX') else p/path;assert sha(file.read_bytes())==h
 assert sha((p/'stage-verify_postede12_application.py').read_bytes())=='50436647a21b8f2014f1ba63ac09b23809f04804c6df525fb5b68d30e7ad3eea';assert sha((p/'stage-verify_postd7a5_application.py').read_bytes())=='2be34a7a0fa839046eeee3ec66e8993b9b8b19ac781d96dacfe3dbb521a39ffd'
 pending=json.loads((p/'stage-PENDING-DELEGATES.json').read_bytes());assert o['inputs/pending.json']==n['inputs/pending.json']==(p/'stage-PENDING-DELEGATES.json').read_bytes();assert pending==json.loads((prior/'private/members/inputs/pending.json').read_bytes());ids=[v['queue_index'] for v in pending['packets']];assert ids==[3231,3232,3234,3235,3243,3244,3246,3247,3255,3256,3258,3259,3267,3268,3270,3271,3305,3306,3308,3309,3317,3318,3320,3321,3329,3330,3332,3333]
 q=json.loads(n['after/RECONCILIATION-059.json'])['entries'];assert len(q)==3713
 for v in pending['packets']:
  r=q[v['queue_index']];assert r['contract_id']==v['historical_contract_id'] and r['historical_lens']==v['historical_lens'] and r['current_reconciliation']=='unassessed'
 assert json.loads((p/'wording-shadow-receipt/RECEIPT.json').read_bytes())['exit']==0 and json.loads((p/'earlier-review-replay/RECEIPT.json').read_bytes())['exit']==0
 r=subprocess.run([sys.executable,'-B',str(prior/'public/VERIFY.py'),'--private',str(prior/'private')],capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'));assert r.returncode==0,(r.returncode,r.stderr.decode())
 print('wrapping-only archives and paragraph boundaries, corrected widths, preserved prior application review and 28 unassessed pending records: PASS')
 print('Evidence-only replay; same-machine custody and same-author qualifications remain; no runtime or closure claim.')
if __name__=='__main__':main()
