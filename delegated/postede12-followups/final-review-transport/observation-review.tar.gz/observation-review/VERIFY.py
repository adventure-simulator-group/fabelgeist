#!/usr/bin/env python3
"""Evidence-only observation-correction review; never executes product source."""
import argparse,hashlib,json,os,stat,subprocess,sys,tarfile,urllib.parse,zlib
from pathlib import Path
if sys.flags.optimize:raise RuntimeError('assertions required')
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(root):
 d={}
 for x in sorted(root.rglob('*')):
  if x.is_symlink():raise AssertionError('symlink')
  if x.is_file() and x.relative_to(root).as_posix() not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   b=x.read_bytes();d[x.relative_to(root).as_posix()]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(x.stat().st_mode),'04o')}
 return d
def check_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert inventory(root)==m['files'];assert all(x['mode']=='0600' for x in m['files'].values())
def archive(root):
 r=json.loads((root/'RECORD.json').read_bytes());raw=(root/r['archive']).read_bytes();assert (len(raw),sha(raw))==(r['archive_bytes'],r['archive_sha256']);want={v['path']:v for v in r['members']};data={}
 with tarfile.open(root/r['archive'],'r:gz') as t:
  for x in t.getmembers():
   assert x.isfile() and x.name in want and x.name not in data and not x.name.startswith('/') and '..' not in x.name.split('/');b=t.extractfile(x).read();v=want[x.name];assert (len(b),sha(b),oct(x.mode))==(v['bytes'],v['sha256'],v['mode']);data[x.name]=b
 assert len(data)==len(want)==12;return data
def git_proof(root):
 p=json.loads((root/'CHECKER-GIT-PROOF.json').read_bytes());objects={}
 for oid,m in p['objects'].items():
  packed=(root/'git-objects'/(oid+'.zlib')).read_bytes();assert sha(packed)==m['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid;h,b=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert kind==m['type'] and len(b)==int(size)==m['size'] and sha(b)==m['sha256'];objects[oid]=(kind,b)
 assert len(p['proofs'])==1;x=p['proofs'][0];rev=x['revision'];assert rev=='ede12d3f9f19d284abbc669b5ae38b814a585f77' and x['path']=='verify_artillery_route_trace.py' and objects[rev][0]=='commit';tree=objects[rev][1].split(b'\n',1)[0][5:].decode();raw=objects[tree][1];i=0;found=None
 while i<len(raw):
  s=raw.index(b' ',i);n=raw.index(b'\0',s);mode=raw[i:s].decode();name=raw[s+1:n].decode();oid=raw[n+1:n+21].hex();i=n+21
  if name==x['path']:found=(mode,oid);break
 assert found is not None and found[0] in ('100644','100755') and found[1]==x['blob'];body=objects[found[1]][1];assert body==(root/'checker-git.py').read_bytes()==(root/'checker-working.py').read_bytes() and sha(body)=='c30494bb1ab968db514ee46276cfa27b210a222eb66739f57a7ce401f3b6cc0a';return body
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();pub=Path(__file__).resolve().parent;check_manifest(pub,'MANIFEST.json');print('public review manifest: PASS')
 if args.private is None:print('restricted replay: NOT REQUESTED');return
 p=args.private.resolve();check_manifest(p,'MANIFEST-PRIVATE.json');o=archive(p/'application-v2');n=archive(p/'application-v3');assert sha((p/'application-v2/APPLICATION-EVIDENCE.tar.gz').read_bytes())=='615f93bf1959b1db337bd418f6938480fb8046026de67cbc2f0459c6e2618838' and sha((p/'application-v3/APPLICATION-EVIDENCE.tar.gz').read_bytes())=='24d42a0419c135e15e413f2b009207a7b424425fe9d5f92302fa31553e0fa1a9';assert set(o)==set(n) and [k for k in sorted(o) if o[k]!=n[k]]==['inputs/main-observation.json']
 old=json.loads(o['inputs/main-observation.json']);new=json.loads(n['inputs/main-observation.json']);assert 'method' not in old and new==dict(old,method='GitHub connector fetch branches/main API');assert o['inputs/main-observation.json']==(p/'observation-review/MAIN-RECHECK-v1.json').read_bytes() and n['inputs/main-observation.json']==(p/'observation-review/MAIN-RECHECK-v2.json').read_bytes()==(p/'public-MAIN-RECHECK-20261113-0140.json').read_bytes()
 for name in ['TRANSFORM-v1.py','PREDECESSOR-WRAPPER.py','TRANSFORM.py','VERIFY.py']:assert (p/'application-v2'/name).read_bytes()==(p/'application-v3'/name).read_bytes()
 record=json.loads((p/'observation-review/RECORD.json').read_bytes())
 for path,h in record['identities'].items():assert sha((p/path).read_bytes())==h
 raw=(p/'private-MAIN-OBSERVATION.json').read_bytes();assert sha(raw)==old['raw_connector_capture_sha256']=='2c259fa5b4cc597247aefc7853ae4de7082ef37d76710b701f62582473dfab40';cap=json.loads(raw);assert cap['before']==old['before_utc'] and cap['after']==old['after_utc'] and cap['response']['isError'] is False;response=cap['response']['structuredContent'];assert urllib.parse.urlsplit(response['url']).path.endswith('/branches/main');body=json.loads(response['content']);assert body['name']=='main' and body['commit']['sha']==old['observed_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and body['commit']['commit']['tree']['sha']==old['observed_tree']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
 log=(p/'failed-evidence.log').read_bytes();res=json.loads((p/'failed-RESULT.json').read_bytes());fail=json.loads((p/'public-FAILED-STAGED-REPLAY.json').read_bytes());assert res['exit']==fail['exit']==1 and len(log)==res['transcript_bytes']==fail['transcript_bytes']==4796 and len(log.decode().splitlines())==res['transcript_lines']==fail['transcript_lines']==51 and sha(log)==res['transcript_sha256']==fail['transcript_sha256']=='dc55443add8145060fdc5f74b2464012ff171cdf5fdec7d77523a07c4836017e';lines=log.decode().splitlines();assert lines[39]=='CHECK verify_artillery_route_trace.py' and lines[40].startswith('Traceback') and lines[44]=="KeyError: 'method'";assert fail['first_failing_evidence_check']=='verify_artillery_route_trace.py' and fail['first_failure']=="KeyError: 'method'"
 checker=git_proof(p);clines=checker.decode().splitlines();assert len(clines)==110 and "observation['method']" in clines[108] and new['method'] in clines[108];assert json.loads((p/'CHECKER-DISPLAY-FAILURE.json').read_bytes())['no_personal_read_credit_from_failed_display'];expected='\n'.join(f'{i:4} {clines[i-1]}' for i in range(101,111))+'\n';assert expected.encode()==(p/'checker-method-display-v2.txt').read_bytes()
 prev=p/'earlier-wrap-review';assert sha((prev/'public/MANIFEST.json').read_bytes())=='c7c5d2063127f5f81b63be3d484a85df7527ff3ce1e2e0d6f469ef4f89c91ed3' and sha((prev/'private/MANIFEST-PRIVATE.json').read_bytes())=='d241ebed006668ff7c4cfb5da73f1edfd779071fadc030b31736498a11a8b8c0';
 for name in ['TRANSFORM-v1.py','PREDECESSOR-WRAPPER.py','TRANSFORM.py','VERIFY.py','RECORD.json','APPLICATION-EVIDENCE.tar.gz']:assert (p/'application-v2'/name).read_bytes()==(prev/'private/application-v2'/name).read_bytes()
 for a,b in [('verify_postede12_application.py.v2','stage-verify_postede12_application.py'),('verify_postd7a5_application.py.v2','stage-verify_postd7a5_application.py')]:assert (p/'observation-review'/a).read_bytes()==(prev/'private'/b).read_bytes()
 assert sha((p/'public-verify_postede12_application.py').read_bytes())=='8036e6d7d9d5599ce50f97b095c34ae5219a4fa3302c30ceb2c4e7c198f93bfb' and sha((p/'public-verify_postd7a5_application.py').read_bytes())=='be494f7a75ca6a0c88b9c6342e8505356c899d70cf7c8ede2cde64ddc415c549'
 assert json.loads((p/'observation-shadow-receipt/RECEIPT.json').read_bytes())['exit']==0
 r=subprocess.run([sys.executable,'-B',str(prev/'public/VERIFY.py'),'--private',str(prev/'private')],capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'));assert r.returncode==0,(r.returncode,r.stderr.decode())
 print('method-only archives, connector response identities, failed log, checker Git binding and preserved wrapping review: PASS')
 print('Evidence-only replay; invocation and HTTP verb not separately captured, full-driver rerun and independent custody remain open.')
if __name__=='__main__':main()
