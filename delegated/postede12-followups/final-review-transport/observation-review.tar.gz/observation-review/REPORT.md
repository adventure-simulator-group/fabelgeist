# Review of the main-observation correction

The correction changes only the `method` field of the point-in-time main
observation. The application-v2 and application-v3 archives each pass their
member identities; their only different member is
`inputs/main-observation.json`. All four after-images, queue and ledger bytes,
other inputs and application scripts are identical. The staged main-observation
file equals the successor. The earlier wrapping-reviewed application-v2 and its
captured wrappers remain unchanged.

The restricted connector capture matches the observation's whole-file SHA-256.
It records a successful response for a branches/main API URL, branch `main`,
commit `95e63628f9d70b8dd6e6fede64334696c6995009` and tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`, within the stated time bracket.
That supports the added branch-API description. The captured JSON is a response;
it does not separately record the connector invocation or an HTTP request verb.
The observation remains point-in-time, and main may have advanced.

The original restricted evidence-driver transcript is 4,796 bytes and 51
lines, with SHA-256
`dc55443add8145060fdc5f74b2464012ff171cdf5fdec7d77523a07c4836017e`.
Its exit, size, line count and hash agree with both the private result and
`FAILED-STAGED-REPLAY.json`. The first traceback follows
`verify_artillery_route_trace.py` and raises `KeyError: 'method'`. The checker
bytes match the ede12 Git source; its displayed line 109 reads that key and
accepts the successor's branch-API label. The failed run is evidence-only and
is not a product-behavior finding. A copied-shadow run of both application
verifiers and the observation verifier passed; this does not establish that the
full real-checkout evidence driver subsequently passed.

The current evidence wrappers add the v3 and observation verifiers, bind the
published observation to v3, and point the predecessor bridge to v3. Their v2
predecessors are byte-identical to the earlier wrapping-review captures. The
complete earlier public/restricted/replay review is preserved in this review's
restricted packet. This reviewer authored that review, the earlier application
review, the underlying hair packet and the pending role 0048 packet; repeating
those checks is not independent-author corroboration.

One process qualification is preserved: an initial prospective checker display
requested lines 101–111 when EOF is 110 and raised before displaying any source.
Its traceback was tool-visible but not separately captured byte-for-byte. A
corrected 101–110 display was separately registered and captured. The prior
wrapping review's qualification about a separately reported candidate-driver
failure also remains; this review did not inspect that earlier transcript.

Original checkpoint 3821 remains missing. Recovered 059 originals,
reconstructed queues and 440 state, historical summaries, normalized 774 records
versus missing pre-export originals, SOURCE004, the 73 nontext/no-positive-EOF
contracts and newly assessed work retain their earlier attribution and recovery
limits. Restricted originals and keys remain same-machine dependencies; this
review establishes neither independent custody nor external publication.
No repair, product validation, semantic queue closure or lens completion is
claimed.
