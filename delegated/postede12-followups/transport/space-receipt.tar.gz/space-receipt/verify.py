#!/usr/bin/env python3
"""Check public receipt and its public source packet without writes."""
import argparse,hashlib,json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent
try:
 a=argparse.ArgumentParser();a.add_argument('--public',required=True,type=pathlib.Path);a=a.parse_args();m=json.loads((p/'MANIFEST.json').read_bytes());fs={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'}
 if fs!=set(m['files']) or any(x.is_symlink() for x in p.rglob('*')):raise ValueError('receipt file set')
 for n,x in m['files'].items():
  q=pathlib.PurePosixPath(n)
  if q.is_absolute() or '..' in q.parts:raise ValueError('unsafe name')
  b=(p/q).read_bytes()
  if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256']:raise ValueError('receipt identity')
 report=json.loads((p/'REPORT.json').read_bytes());manifest=(a.public/'MANIFEST.json').read_bytes()
 if hashlib.sha256(manifest).hexdigest()!=report['public_manifest_sha256']:raise ValueError('public binding')
 data=json.loads(manifest);files={x.relative_to(a.public).as_posix() for x in a.public.rglob('*') if x.is_file() and x!=a.public/'MANIFEST.json'}
 if files!=set(data['files']):raise ValueError('public file set')
 for n,x in data['files'].items():
  q=pathlib.PurePosixPath(n)
  if q.is_absolute() or '..' in q.parts:raise ValueError('unsafe public name')
  b=(a.public/q).read_bytes()
  if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256']:raise ValueError('public identity')
 print(json.dumps({'result':'pass','receipt_files':len(fs),'public_files':len(files),'qualification':'Identity only; this does not itself rerun privacy scans or inspect product behavior.'}))
except Exception as e:print('receipt verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
