# Independent pixel-format four-lens review

q3267, q3268, q3270 and q3271 are separate source-only assessments against pinned 95e. Read the individual reports, exact source and historical proofs, registrations, and READ-LIMITS.json. Central coordinator retains ledger and publication.
