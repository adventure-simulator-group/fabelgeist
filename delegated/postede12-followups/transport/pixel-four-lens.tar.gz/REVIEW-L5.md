# q3270 — Lens 5 aggregate states

Reader: [independent reviewer; identity separately held]. The independently registered full target source
read is new work; Root's 6533 Lens3 and e275 reuse are historical and separate.
Do not promote either to missing checkpoint 3821.

The full `PixelFormat` enum establishes each named format atomically, but
`pixel.rs:234–425,428–483` exposes multiple independent coarse views. NV12 and
NV21 map to the same `SemiPlanar420` and I420/YV12 to the same `Planar420`
(`:215–223,288–289`), so the layout alone cannot distinguish UV or plane
order. `Uyvy`/`Yuy2` store a four-byte pair of pixels (`:228–231`) while
`bytes_per_pixel` returns `Some(2)` as an effective average (`:433–435,
479–480`). This does not establish an independent two-byte representation per
pixel or odd-width allocation policy. No current use of that result for a
bad allocation was shown.

`BitDepth::nominal_bits` says per-component or packed average (`:110–123`),
yet `Packed10_10_10_2` returns 10 for a named 10/10/10/2 layout whose mean is
8. This source-level documentation/meaning mismatch does not prove data loss;
the intended nominal convention and nonliteral/external callers remain open.
`Depth24PlusStencil8` similarly reports a single `Bits32`, `Float` and
`Some(4)` (`:210–213,285–286,344–355,416–425,462–469`) although the name has
separate depth/stencil aspects. The ability to describe and size both aspects,
and actual native storage semantics, need a separate policy/consumer trace;
no device defect or physical byte size is inferred.

For actual aggregate use, `convert_pixels:166–181` permits same-format
success after copying min lengths, without requiring the declared extent.
For I420 it computes floor chroma plane length (`:215–245`) while its called
source indexes ceil-width chroma (`yuv.rs:201–223`). These are separate prior
q147 and q3145 first operations; q3146 separately asks oversized suffix policy.
No conversion, fixture or runtime probe ran, and supported callers/odd/zero
policies remain open. A later connected repair ledger must relate accepted
format, dimensions, plane layout and buffer extents atomically without erasing
valid planar formats or assuming a single bytes-per-pixel policy.
