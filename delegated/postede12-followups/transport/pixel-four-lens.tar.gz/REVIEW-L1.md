# q3267 — Lens 1 producer propagation

Reader: [independent reviewer; identity separately held]. The full target was independently registered and
read at 6533, e275 and pinned 95e for this lens. Root's earlier Lens3 read and
e275 reuse, and the same reader's separately sealed conversion review, do not
supply this new lens credit. Recovery limits remain in READ-LIMITS.json.

`pixel.rs:143–232,234–293,296–425` owns a `PixelFormat` variant and derives
channel layout, bit depth and component interpretation. Selected real GPU
producer `texture/format.rs:17–47,84–115` retains `TextureFormat` then
converts it to `PixelFormat`; the reverse conversion at 119–153 is fallible
because the GPU owner is a narrower set. `Texture2d` retains the GPU owner
(`texture_2d/mod.rs:14–20,51–62,150–155`) until wgpu/native view construction.
An external enum at that real framework boundary is not a primitive escape.
No producer in the selected path was shown stripping an already migrated
format to a raw primitive and reconstructing it later; broader producers and
external callers remain open.

`ChannelLayout::channels` and `BitDepth::nominal_bits` return primitive counts
(`pixel.rs:47–62,110–123`), and `bytes_per_pixel` returns an optional packed
size (433–483). Those summaries do not encode component ordering, subsampled
plane extents or paired 4:2:2 blocks; a future propagation decision must trace
actual recipients before treating a getter as either a defect or a native
boundary. The precise registered crates-tree `.nominal_bits(`/associated-call
search found no literal matches; it excludes other syntax and external users.
The initial premature claim and its corrected sequence are retained separately.

`convert_pixels` accepts typed source/destination formats plus untyped extent
and separate slices (`conversion.rs:166–182`). Literal call navigation found
only its definition and test-source call in the selected crates tree; this
proves no ordinary caller or global absence. Prior q147 identity admission,
q3145 odd chroma and q3146 suffix policy are distinct connected records, not
newly counted or closed by this review.
