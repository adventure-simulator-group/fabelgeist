# q3271 — Lens 6 type ownership

Reader: [independent reviewer; identity separately held]. Historical Root Lens3 attribution and the prior
conversion multi-lens review are separate, not transferred to this assessment.
No individual prior same-lens target receipt was located in the bounded source
path search; that does not prove historical absence.

`fabelgeist-color::PixelFormat` is the broader CPU/video/depth format owner
(`pixel.rs:143–232`); `fabelgeist-gpu::TextureFormat` is a GPU-oriented subset
retained by `Texture2d` (`texture/format.rs:17–47`,
`texture_2d/mod.rs:14–20`) and converted in both directions, with failure for
unsupported CPU formats (`texture/format.rs:84–153`). The GPU crate depends on
color with the wgpu feature (`gpu/Cargo.toml:8–10`); color's direct wgpu
adapter is feature-gated (`color/Cargo.toml:8–11,17–22`, `color/wgpu.rs:4–71`).
There is a real overlap of names and metadata, but the two domains are not
identical and the native adapter is an actual boundary.

A concrete reason not to mechanically substitute one owner: for
`Rgba8UnormSrgb`, color `PixelFormat::srgb_counterpart` returns the same sRGB
variant (`pixel.rs:519–526`), while GPU `TextureFormat::srgb_counterpart`
returns the linear counterpart (`texture/format.rs:374–381`). The latter is
used as an opposite-format candidate by compute-pass view matching
(`compute/pass/mod.rs:262–275,321–331,362–388`) and texture creation first
normalizes to linear (`texture_2d/mod.rs:100–110`). The selected static paths
show deliberate different operations; they do not establish device success.
Similarly GPU `is_float` includes normalized formats (`format.rs:321–340`)
because `ResourceDescriptor::base_type_str` selects f32 sampled values
(`compute/mod.rs:105–115`), whereas pixel `is_float` denotes stored component
classification (`pixel.rs:126–140,361–425,494–497`). Same spelling is not
proof of the same semantic question.

If owners or projections are unified later, retain the GPU-supported subset,
paired-view toggle, sample type and native capability/error distinctions while
sharing genuinely identical layout facts. No claim that every duplicated match
is defective, that optional wgpu support is universal, or that this bounded
search found all consumers; q346's format-mismatch error remains separate.
