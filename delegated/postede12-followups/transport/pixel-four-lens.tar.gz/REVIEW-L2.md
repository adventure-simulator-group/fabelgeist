# q3268 — Lens 2 existing type owners

Reader: [independent reviewer; identity separately held]. Full registered target read independently at all
three revisions; no prior lens or reader credit is transferred. See
READ-LIMITS.json for historical provenance and missing recovery qualifications.

`PixelFormat` already owns complete format identity while its
`ChannelLayout`, `BitDepth` and `ComponentType` are coarser facts
(`pixel.rs:4–45,87–146,234–425`). NV12/NV21 and I420/YV12 separately retain
UV/VU or plane order in their variants (`:215–223`), although each pair has the
same coarse layout (`:288–289`). A replacement with the layout alone would
lose order. Likewise `BitDepth::Packed10_10_10_2` carries the unequal channel
widths before `nominal_bits()` collapses them. A whole-format owner is needed
where exact layout matters; raw count replacement alone is not the fix.

`yuv.rs:54–93` already owns subsampling and ceil-divided 4:2:0 dimensions;
`convert_pixels:215–245` instead derives each I420 chroma plane as floor total
pixels / 4, then `yuv.rs:201–223` indexes using ceil width. Existing q3145
records the conditional public 1×1 mismatch and leaves caller/odd policy open.
The existing subsampling dimensions are a useful leaf, not by themselves a
complete plane order, interleaved NV12 stride, overflow or zero-size contract.
Preserve those roles before reusing or extending an owner.

The independent `fabelgeist-gpu::TextureFormat` is a subset with actual GPU
resource and capability roles; it maps exhaustively to `PixelFormat` and has a
fallible reverse (`texture/format.rs:17–47,84–153`). `PixelFormat` also has
CPU/video formats and feature-gated wgpu conversions (`color/wgpu.rs:4–71,
126–132`); semantically equivalent names alone do not prove identical APIs or
a safe blanket replacement. Follow the distinct sampling and counterpart
semantics in q3271. No repository-wide existing-owner completeness is claimed.
