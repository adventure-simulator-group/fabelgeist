# Four independent pixel-format lens assessments

This public-safe reconstructed successor contains the four separately assessed source-only reports and exact source/tree/display bytes. It is not a complete 059 queue, historic receipt archive, or recovery of missing checkpoint 3821. Full restricted originals and their manifest must be held separately. Review READ-LIMITS.json, including the corrected interim search claim.

Run `python3 verify-public.py` for public content, tree-to-blob and transcript checks. `--private DIRECTORY` additionally verifies the exact separately held restricted manifest and reconstruction crosswalk, then runs its evidence-only verifier. Add `--anchors DIRECTORY` to verify separately held full original/reconstructed 059 queues. Without these dependencies commit-to-root binding, original full queue membership, historic receipt linkage and private reconstruction are not checked. No product, shader, macro, fixture, build or runtime execution is part of replay.
