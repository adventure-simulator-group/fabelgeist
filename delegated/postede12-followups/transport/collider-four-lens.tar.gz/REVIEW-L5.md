# q3234 — Lens 5 aggregate states

Reader: [independent reviewer; identity separately held]. The separately attributed Adler
`ADLER-RESUMED05-GROUP-285 /source_members/4` records a personal 6533 read of
collider 1–218 and identifies F007; its e275 own-lens fresh read is not shown.
Root's Lens3 and Lens2 reads/reuse are separate evidence. Missing checkpoint
3821 is not reconstructed from any of them.

`collider.rs:15–40` couples variant and shape-specific fields, and
`pack:100–132` emits each entire record in the layout separately seen at
`wgsl.rs:11–16`; a variant cannot carry another variant's payload through this
host match. However, public `Shape::Box` accepts four arbitrary rotation
components although its documented contract is a unit quaternion. For example,
four individually finite zero components have norm zero; `collider.rs:177,
200–208` and `wgsl.rs:25–31,77–98` apply conjugate and rotation without
admission. The public plane normal likewise lacks a demonstrated unit condition
for a distance/normal result (`collider.rs:18–22,64–65,140–142`). These are
representable API states; no selected actual bad producer or device behavior is
proved. Prior Rig F081 already concerns that admission family. Preserve valid
zero friction/thickness and the zero-length capsule sphere behavior; do not
infer zero radius or all extent policies without a decision.

`contact.rs:71–89` assigns a newly computed capacity before a fallible buffer
construction, while old list/buffer persist on returned error. The actual
wrapper (`buffer/mod.rs:23–37`) explicitly returns Err for zero bytes only;
`count.rs:33–44` can produce zero when a 64-bit host count in
(2^31, 2^32) rounds to 2^32 then casts to u32, provided fit requests growth.
The resulting stored capacity is zero, not a larger capacity. Such a huge list,
allocation feasibility, device failure and caller continuation are unproved;
same-count retry still requests growth, so no ordinary retry misallocation is
asserted. `write:127–129` forwards upload, while `write_at:132–150` has a
separate explicit bounds check; native behavior is outside this review.

Historical q480 posed the earlier capacity/error-state question and left native
failure open; q479 and Rig F073 supplement concern count conversion. Adler F007
and 059 q174 concern a valid box-center host/shader normal mismatch, distinct
from malformed-quaternion admission. We inspected shader text but did not
establish runtime reach or native builtin behavior independently. No alias,
unique count or repair status is asserted. Future reconciliation should specify
coherent capacity/buffer/list publication and accepted shape invariants while
preserving legitimate degenerate inputs and checking native representability.
