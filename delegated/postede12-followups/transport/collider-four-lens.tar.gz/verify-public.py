#!/usr/bin/env python3
"""Evidence-only replay. Does not run product, shader, macro, fixture or test code."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);d[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return d
def prove(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/f'{t}.tree').read_bytes();assert oid('tree',b)==t;mode,t=tree(b)[part]
 assert mode=='100644' and oid('blob',data)==t
def manifest(d):
 m=json.loads((d/'MANIFEST.json').read_bytes());found={str(f.relative_to(d)) for f in d.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};assert found==set(m['files'])
 for n,v in m['files'].items():
  f=d/n;b=f.read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode']
ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: public packet manifest (--skip-manifest)')
else:manifest(P);print('public file set, sizes, modes and hashes: pass')
roots={'6533':'849ec1e8faca2236c7021893cda7a3f7cb5c72e8','e275':'7737c903f98397669c12da05475f759aa7fcfe73','95e':'1eec97de340d9b7debbb30ca0c0fb2240a73b93f'}
for row in json.loads((P/'SOURCE-002-RESULT.json').read_bytes())['rows']:
 label=row['label'];assert row['chain'][0]['tree']==roots[label];b=(P/'source'/f'{label}.rs').read_bytes();assert H(b)=='296038416d7eb39fb2a5e71bbce613acc621b6ad99e7b4e12f540d45a27fb34c' and len(b.splitlines())==218 and b.endswith(b'\n');prove(roots[label],'crates/fabelgeist-physics/src/collider.rs',b);ls=b.decode().splitlines(keepends=True)
 for lo,hi in [(1,109),(110,218)]:assert (P/'displays'/f'{label}-{lo}-{hi}.txt').read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
for regname,resname,displays in [('ADJ-009-DISPLAY-REG.json','ADJ-007-CAPTURE-RESULT.json','adj-displays'),('BOUNDARY-012-REG.json','BOUNDARY-011-CAPTURE-RESULT.json','boundary-displays'),('NATIVE-016-REG.json','NATIVE-015-CAPTURE-RESULT.json','native-displays')]:
 reg=json.loads((P/regname).read_bytes());rows=json.loads((P/resname).read_bytes());by={x['path']:x for x in rows}
 for row in rows:
  b=(P/row['file']).read_bytes();assert H(b)==row['sha256'] and oid('blob',b)==row['blob'] and len(b.splitlines())==row['EOF'];prove(roots['95e'],row['path'],b)
 for row in reg['windows']:
  ls=(P/by[row['path']]['file']).read_text().splitlines(keepends=True)
  for lo,hi in row['ranges']:
   n=f"{row['path'].replace('/','__')}-{lo}-{hi}.txt";assert (P/displays/n).read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
names={1:'producer-propagation',2:'existing-type-owners',5:'aggregate-states',6:'type-ownership'}
for r in json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows']:assert r['name']==names[r['number']] and H((P/f"SKILL-L{r['number']}.md").read_bytes())==r['skill']['sha256']
b=(P/'HIST-L5-GROUP-285.json').read_bytes();assert H(b)=='219318aa3487b7473fb3673b91e39b2e27d65779d98fb2b2e2d1244c18f3767c';g=json.loads(b);assert g['id']=='ADLER-RESUMED05-GROUP-285' and g['source_members'][4]['scope_index']==2482 and g['source_members'][4]['personally_read_ranges']==[[1,218]]
print('selected root-tree/blob proofs, complete target/adjacent displays, four skills and exact Adler group: pass')
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if not a.private:print('NOT CHECKED: commit-to-root binding, original handoff map, full queue membership, historical receipt linkage, private reconstruction and dac7d ledger membership; separately held restricted packet required')
else:
 assert H((a.private/'MANIFEST.json').read_bytes())=='e39ef46884409c3b9961a8d81fe3a45fcb94130a067b1c0484938b9c61d85266';manifest(a.private)
 c=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes())
 for item in c['files']:
  old=(a.private/item['original_file']).read_bytes();assert H(old)==item['original_whole_file_sha256'];out=bytearray();last=0
  for r in item['replacements']:
   i=r['original_byte_offset'];n=r['original_byte_length'];assert i>=last;out+=old[last:i]+r['replacement'].encode();last=i+n
  out+=old[last:];assert bytes(out)==(P/item['successor']).read_bytes() and H(out)==item['successor_whole_file_sha256']
 m=json.loads((a.private/'PRIVATE-HANDOFF-LENS-MAP.json').read_bytes());assert json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows']==[m['lenses'][i-1] for i in [1,2,5,6]]
 h=json.loads((P/'HISTORY-SUMMARY.json').read_bytes())
 for row in h['obligations']+h['relationships']:
  b=(a.private/f"PRIVATE-Q{row['index']}-original.json").read_bytes();q=json.loads(b);assert H(b)==row['selected_record_sha256'] and q['contract_id']==row['contract_id'] and q['lens']==row['lens'] and q['status']==row['status']
  if 'first_question_as_recorded' in row:assert q['first_failed_contract_or_unresolved_question']==row['first_question_as_recorded']
 print('restricted manifest, reconstruction crosswalk, selected handoff map and selected queue summary: pass')
 cmd=[sys.executable,str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,end='')
 if r.returncode:print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
print('Integrity replay does not prove semantic conclusions, recover 3821 or validate product behavior.')
