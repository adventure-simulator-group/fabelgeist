# q3232 — Lens 2 existing type owners

Reader: [independent reviewer; identity separately held]. Independently read all 218 target lines at each
registered revision. Earlier Root's own-Lens2 6533 full read is recorded in
`READ-ROOT-L2-EXT-034-044.json /rows/7`; e275's
`READ-ROOT-L2-CURRENT-009.json /rows/7` qualifies that prior identical-body
proof with no fresh e275 read. Neither is this reviewer's read. Reconstructed
059 q2408 remains an open current/alias owner-fit question.

`collider.rs:15–52,64–88,135–140` uses raw scalar offset, radius, friction,
thickness, signed distance and a four-component rotation. In
`fabelgeist-math/src/units.rs:10–20,52–69`, `Metres` is signed and `Ratio`
is dimensionless; both accept raw f32 without numeric policy. Physics already
depends on math (`fabelgeist-physics/Cargo.toml:8–13`). They are plausible
shared leaves for metre-valued signed distance/offset and Coulomb ratio once
units and role compatibility are demonstrated, not proof of admission or a
blanket substitution for every raw scalar. Friction zero is explicitly valid.

`fabelgeist-geometry/src/length.rs:9–38` instead requires finite strictly
positive metres; physics does not directly depend on geometry in the inspected
manifest. It cannot directly represent signed plane offsets or zero optional
thickness; applicability to radius and extents needs an explicit geometry and
degeneracy policy. Quaternion norm is an aggregate constraint, not guaranteed by
four independent scalar wrappers. No compatible existing unit-quaternion owner
has been established by the bounded search. Do not infer one is absent globally.

`Shape` couples variant payloads and `pack` is a WGSL projection; native f32
arrays and bitcast kind at that boundary are not themselves a duplicate host
owner. Establish actual API producer/consumer requirements and connected policy
before proposing any owner reuse; framework numerical representations remain
appropriate at the real boundary. Native/device behavior and global aliases are
unproved, and no repair has been made.
