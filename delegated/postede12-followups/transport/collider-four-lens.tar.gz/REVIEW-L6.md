# q3235 — Lens 6 type ownership

Reader: [independent reviewer; identity separately held]. Historical Root Lens2 and Adler Lens5 source
receipts are separately attributed; they are not Lens6 credit. No direct
historical own-Lens6 exact receipt was located in the bounded evidence search,
which is not proof that no other receipt exists.

The host concept owner is `collider.rs:15–53`: `Shape` carries each analytic
shape's payload and `Collider` adds surface properties. `contact.rs:23–42,
63–89` stores `Vec<Collider>` as the selected host authority, while
`collider.rs:100–132,211–218` projects native elements; `wgsl.rs:11–16,39–98`
uses a layout-specific shader representation. Those two representations have
different execution roles, and their coexistence alone is not evidence of
competing first-party host authorities. The selected `Fit::new` producer uses
this host owner (`garment-fit/src/lib.rs:389–407`).

`fabelgeist-math/src/units.rs:1–20,52–69` already owns unit-only `Metres` and
`Ratio`; `geometry/src/length.rs:9–35` owns a checked positive length with a
narrower contract. Physics directly uses math but not geometry in its inspected
manifest. A shared numeric leaf and a shape/role-specific validation policy may
coexist: neither equal f32 representation nor shared physical units justifies
merging signed plane offsets, positive dimensions, optional zero thickness,
coefficients, world coordinates or unit rotations. Which exact boundary should
own these invariants, and whether other reusable or duplicate quaternion owners
exist, remain open. q2408 and Rig F081 are relationships, not automatic aliases.

No repository-wide duplicate-owner or complete dependency search is claimed.
Any future coherent owner placement must consider producer propagation,
shader packing and the count/buffer transaction together without erasing the
separate representation and admission roles. No product execution or repair.
