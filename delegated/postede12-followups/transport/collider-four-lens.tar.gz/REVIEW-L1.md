# q3231 — Lens 1 producer propagation

Reader: [independent reviewer; identity separately held]. New source-only assessment against 95e; the
6533/e275 source was also independently read after registration. Historical
reads below retain their own attribution; no other lens grants this read.

`collider.rs:15–88` passes raw world-space vectors, plane offsets, radii,
quaternion components, friction and thickness through public variants,
constructors and setters. `garment-fit/src/lib.rs:389–407` provides one
selected actual producer, `ground(-1.0).with_friction(0.5)`, and passes the
whole Collider to `contact.rs:71–89`. That path does not strip an observed
already-typed producer, so it is an owner-propagation opportunity rather than a
proved unfinished migration. All other producers and any application-specific
contracts remain open.

`contact.rs:71–89,94–115,123–142` retains the host objects, serializes them
with `pack_colliders`, uploads with `BufferUpload`, and supplies the buffer to
the analytic pass. `collider.rs:91–132,211–218` is an explicit 16-float
framework projection; `wgsl.rs:11–16,39–98,142–193` is the receiving source
contract (text only). This is a real native representation boundary; do not
flag the final scalar extraction merely for being scalar. The public
`signed_distance` result at 135–197 remains a raw return; bounded literal
navigation found only test-source call syntax in the selected crates tree,
which does not establish all callers or make the public API a final boundary.

`fabelgeist-math/src/units.rs:10–20,52–69` defines signed `Metres` and
policy-free dimensionless `Ratio`, but this selected producer does not already
carry them. Confirm world units, semantics and zero policy before considering
propagation through producer, host API and native adapter. Preserve signed
plane offsets, frictionless zero and the existing degenerate-capsule case.
No replacement or compatibility strategy is assumed. q2408's historical
Lens2 owner question is related, not transferred; q479/q480 retain distinct
count and state first operations. Repairs and acceptance are future ledger work.
