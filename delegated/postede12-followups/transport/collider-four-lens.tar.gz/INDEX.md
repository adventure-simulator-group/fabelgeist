# Independent four-lens collider evidence

Four separately assessed q3231, q3232, q3234 and q3235 reports; central coordinator retains ledger and publication. See READ-LIMITS.json, registration/results, exact source captures, historic originals and verify-evidence.py. Pinned 95e; historical 6533/e275 and reconstructed 059 remain separately qualified. No 3821 promotion or product execution.
