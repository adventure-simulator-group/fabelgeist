#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-terminal-review-public-v1';assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for name,row in m['files'].items():
 b=(p/name).read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
r=json.loads((p/'REVIEW.json').read_bytes());assert r['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and r['queue_index']==3064 and r['registered_display_ranges']==14 and r['displayed_line_ranges_sum']==661 and r['d7_bounded_ledger_matches']==115
print('Verified public review packet only; restricted sources, Git proof and queue inputs remain separate.')
