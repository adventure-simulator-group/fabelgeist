# YUV source: four bounded lens assessments

The recovered 059 obligations q3243 (Lens 1), q3244 (Lens 2), q3246
(Lens 5), and q3247 (Lens 6) register `fabelgeist-color/src/yuv.rs`
lines 1–503. I freshly preregistered and personally displayed that entire
file at 6533, e275 and pinned 95e, then assessed the shared read under each
named lens. The three Git blobs match. This is not proof that the historical
working tree was clean, and earlier reviewers retain their own read credit.

The current `convert_pixels` wrapper computes subsampled plane lengths from
`width * height` with floor division; the low-level I420 conversion uses
ceiling-divided chroma dimensions. For a hypothetical 3×3 NV12 image, a
13-byte source or destination passes the wrapper's displayed length check,
but its UV suffix has only four bytes while the low-level code reaches index
4 after earlier writes. This is static source arithmetic and is related to
the existing q3145 and ledger entry 495, which already record the extent
family and different 1×1 and 2×1 examples.

A further conditional 3×3 observation is that the last V byte of chroma row
zero and first U byte of row one both use UV offset 3: the code strides by
`width` even though two bytes are used per ceiling-divided chroma sample.
Whether odd widths are supported, padded or rejected, and whether real
producers reach them, remain open. The same-format early-success issue in
q147/ledger entry 493 has a different first operation.

The types `YuvStandard`, `YuvRange`, `ChromaSubsampling`, `PixelFormat` and
`ChannelLayout` own related but distinct meanings. The displayed unchecked
RGBA `Color` does not by itself own normalized YCbCr triplets or plane
layout. The wrapper fixes BT.709/full range; real caller metadata and its
intended policy remain unproved. See `ASSESSMENTS.json` for the four separate
perspectives, exact source references, safeguards, questions and repair
planning directions.

Original 059 and reconstructed streams have different whole-file identities;
the four selected parsed entries match. Root's earlier 6533 Lens 3 display
and the e275 same-lens reuse with no fresh reread retain their attribution;
none becomes checkpoint 3821. Two metadata locator failures were preserved
and bounded follow-up reads recorded. No product, conversion, fixture, test,
build, macro, shader, runtime probe or repair was performed.
