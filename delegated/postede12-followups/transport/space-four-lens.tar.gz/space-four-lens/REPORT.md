# Color-space source: four bounded lens assessments

The recovered 059 entries q3255 (Lens 1), q3256 (Lens 2), q3258 (Lens 5)
and q3259 (Lens 6) register `fabelgeist-color/src/space.rs` lines 1–356.
I independently registered and displayed the full file at 6533, e275 and
pinned 95e, then assessed the shared reads under all four named lenses. The
file bodies are identical; this does not establish a clean historical tree.

The public `ColorPrimaries` aggregate can represent identical finite,
nonzero-y primaries. Their basis is singular, and the shown operations use
identity fallback when inversion returns `None`. This connects to existing
q148 and ledger entry 494. Nonfinite and near-singular input policy, supported
custom callers and error propagation remain open; the listed ACES2065-1
standard includes a negative blue y coordinate.

The source maps `Bt709` to `LinearSrgb`, and that value's `to_gamma_space`
returns `Srgb`, not `Bt709`. If a caller requires encoded identity to survive
that composition, the original choice is no longer retained. This is a
conditional policy question related to ledger entry 496, whose existing
finding concerns DCI-P3 and Adobe RGB remaining encoded. No exact alias,
actual caller or runtime outcome is established.

`Ratio` is an existing unchecked f32 dimensionless wrapper; the inspected
chromaticity coordinates are f64, and its policy and dependency fit are not
proved. `YuvStandard`, `ColorSpace`, `ColorPrimaries`, `WhitePoint` and
`TransferFunction` serve related but distinct roles. See `ASSESSMENTS.json`
for each lens, source references, safeguards and questions.

Root's historical 6533 Lens 3 read and e275 same-lens reuse with no fresh
reread, Adler's historical receipt and our earlier 95e support-only read are
separately attributed. The observed working and committed baseline streams
differ; only selected records were compared. No older work is promoted to
checkpoint 3821. Source tests were read as text; no product, example, macro,
fixture, test, build, shader, runtime probe or repair was performed.
