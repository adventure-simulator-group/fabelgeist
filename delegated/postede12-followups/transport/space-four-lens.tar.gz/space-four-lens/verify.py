#!/usr/bin/env python3
"""Read-only verification for four-lens color-space source evidence."""
import argparse,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent

def load(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(v,msg):
 if not v:raise ValueError(msg)
def safe(root,n):
 p=pathlib.PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return root.joinpath(*p.parts)
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'truncated tree');n=b[a+1:z].decode();need(n not in out,'duplicate tree entry');out[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def runs(s):
 out=[]
 for i in sorted(s):
  if out and out[-1][1]+1==i:out[-1][1]=i
  else:out.append([i,i])
 return out

def main():
 a=argparse.ArgumentParser();a.add_argument('--restricted',type=pathlib.Path);a.add_argument('--repository');a=a.parse_args();m=load(P/'MANIFEST.json');files={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(files==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest file set')
 for n,v in m['files'].items():
  b=safe(P,n).read_bytes();need(len(b)==v['bytes'] and sha(b)==v['sha256'],'manifest identity '+n)
 for e in load(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(e['name']+'.md')).read_bytes();need(sha(b)==e['sha256'] and len(b.splitlines())==e['lines'],'skill '+e['name'])
 reg=load(P/'SOURCE-REGISTRATION.json');need([(x['queue'],x['lens']) for x in reg['assigned_own_lenses']]==[(3255,1),(3256,2),(3258,5),(3259,6)],'lens registration')
 rr=load(P/'READ-RECEIPT.json');unions={};nviews=0
 for r in rr['rows']:
  e=next(x for x in load(P/r['registration'])['sources'] if x['label']==r['label']);data=safe(P,r['source_file']).read_bytes();lines=data.decode().splitlines();need(sha(data)==r['source_sha256']==e['sha256'] and oid(b'blob',data)==r['git_blob'] and len(lines)==r['eof']==e['eof'],'source identity '+r['label']);need(r['revision']==e['revision'] and r['path']==e['path'] and [v['range'] for v in r['views']]==e['planned_ranges'],'registered source windows')
  k=(r['revision'],r['path']);unions.setdefault(k,{'eof':len(lines),'seen':set()})
  for v in r['views']:
   first,last=v['range'];need(1<=first<=last<=len(lines),'view bounds');b=safe(P,v['file']).read_bytes();need(sha(b)==v['sha256'] and b.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(first,last+1)],'view contents');unions[k]['seen'].update(range(first,last+1));nviews+=1
 for c in rr['coverage']:
  u=unions[(c['revision'],c['path'])];need(runs(u['seen'])==c['displayed_union'] and runs(set(range(1,u['eof']+1))-u['seen'])==c['unread_complement'],'coverage')
 need(len(unions)==len(rr['coverage'])==9,'source pair count')
 for r in rr['coverage'][:3]:need(r['displayed_union']==[[1,356]] and r['unread_complement']==[],'primary full scope')
 proofs=load(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==11,'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree chain length')
  for j,(part,step) in enumerate(zip(parts,x['tree_chain'])):
   need(step['tree']==cur and step['entry']==part,'tree chain');b=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',b)==cur,'tree oid');mode,nxt=tree(b)[part];need(mode==step['mode'] and nxt==step['object'],'tree entry');cur=nxt
   if j+1<len(parts):need(mode in ('40000','040000'),'tree mode')
  need(cur==x['blob'],'target blob')
  if x['role']=='source':need(oid(b'blob',safe(P,x['source_file']).read_bytes())==cur,'source bytes')
  elif a.restricted:
   b=safe(a.restricted,x['source_file']).read_bytes();need(sha(b)==x['sha256'] and oid(b'blob',b)==cur,'restricted previous evidence bytes')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository revision binding')
 hc=load(P/'HISTORY-CAPTURE.json');selections=[]
 for s in hc['streams']:
  group=[]
  for r in s['rows']:
   b=(P/'queue'/('q'+str(r['index'])+'-'+s['name'])).read_bytes();need(len(b)==r['bytes'] and sha(b)==r['selected_normalized_sha256'],'queue selection');group.append(json.loads(b))
  selections.append(group)
 need(selections[0]==selections[1] and [x['lens'] for x in selections[0]]==[1,2,5,6],'selected queue parsed equality')
 checks=load(P/'PRIOR-RECEIPT-REGISTRATION.json')['records'];prior=P/'prior-receipts'
 for n,h in checks.items():need(sha((prior/pathlib.PurePosixPath(n).name).read_bytes())==h,'prior receipt identity')
 old=load(prior/'READ-ROOT-L3-EXT-043-044.json')['rows'][1];now=load(prior/'READ-ROOT-L3-CURRENT-005.json')['rows'][10];need(old['fresh_personal_ranges']==[[1,356]] and now['fresh_personal_ranges']==[] and now['qualified_reuse_ranges']==[[1,356]] and old['source_sha256']==now['source_sha256'],'prior Root versus reused attribution')
 report=load(P/'ASSESSMENTS.json');need([(x['queue'],x['lens']) for x in report['assessments']]==[(3255,1),(3256,2),(3258,5),(3259,6)],'report mapping')
 restricted=False
 if a.restricted:
  d=a.restricted;h=d/'historical';prior_manifest=(h/'prior-059-capture-manifest.json').read_bytes();need(sha(prior_manifest)=='1aa3ac942d6e0fb92cfcde9c8bdd60a3f0cd81fe0df6b8bd8ca564a3e4f6b0c2','earlier manifest anchor');prior_files=json.loads(prior_manifest)['files'];originals=[]
  for s in hc['streams']:
   b=(h/s['name']).read_bytes();need(len(b)==s['bytes'] and sha(b)==s['sha256']==prior_files['historical/'+s['name']]['sha256'],'whole queue');q=json.loads(b);originals.append(q)
   for r in s['rows']:
    part=(json.dumps(q['entries'][r['index']],indent=2,ensure_ascii=False)+'\n').encode();need(sha(part)==r['selected_normalized_sha256'] and part==(P/'queue'/('q'+str(r['index'])+'-'+s['name'])).read_bytes(),'selection extraction')
  for i in (148,3143):
   for q,name in zip(originals,['original-56f','reconstructed-dac7d']):need((json.dumps(q['entries'][i],indent=2,ensure_ascii=False)+'\n').encode()==(h/f'q{i}-{name}.json').read_bytes(),'related historical selection')
  roots={}
  for x in load(d/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(d/'private-commits'/(x['revision']+'.commit')).read_bytes();need(sha(b)==x['whole_commit_payload_sha256'] and oid(b'commit',b)==x['revision'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit anchor');roots[x['revision']]=x['root_tree']
  for x in proofs:need(roots[x['revision']]==x['root_tree'],'offline revision binding')
  for n in checks:need((h/'prior-receipts'/pathlib.PurePosixPath(n).name).read_bytes()==(prior/pathlib.PurePosixPath(n).name).read_bytes(),'prior receipt custody')
  ba=(h/'baseline-committed.json').read_bytes();bw=(h/'baseline-working-observed.json').read_bytes();aa=(h/'assessment-color-committed.json').read_bytes();aw=(h/'assessment-color-working-observed.json').read_bytes();need(ba!=bw and aa==aw,'observed evidence identities');ledger=json.loads(ba)['newly_assessed_ledger']['entries'];observed=json.loads(bw)['newly_assessed_ledger']['entries'];need(ledger[494]['id']=='ADLER-L11-COLOR-PRIMARY-INVERSION-ADMISSION' and ledger[496]['id']=='REVIEW-COLOR-SPACE-LINEAR-CONVERSION-95E' and all(ledger[i]==observed[i] for i in (494,496,903)),'selected ledger relationships');pa=h/'prior-adjacent';pm=(pa/'MANIFEST.json').read_bytes();need(sha(pm)=='7deb2ac6eab786aa7963a437b6c837e8919867159893073108b8b4500a0c0af0','prior adjacent manifest');pf=json.loads(pm)['files'];need(all(sha((pa/n).read_bytes())==pf[n]['sha256'] for n in ('READ-RECEIPT.json','SUPPORT-REGISTRATION.json','REPORT.md')),'prior adjacent copies');prior_row=next(x for x in load(pa/'READ-RECEIPT.json')['rows'] if x['path'].endswith('/space.rs'));need(prior_row['read_role']=='support only' and [v['range'] for v in prior_row['views']]==[[1,100]],'prior adjacent scope')
  restricted=True
 print(json.dumps({'result':'pass','public_files':len(files),'registered_views':nviews,'source_revision_pairs':len(unions),'tree_path_proofs':len(proofs),'restricted_historical_streams_and_commit_anchors_checked':restricted,'repository_revision_binding_checked':bool(a.repository),'qualification':'Evidence integrity and recorded views only; public-only mode checks prior-evidence path blobs but requires restricted bytes for full provenance. No product, runtime, alias, count or lens closure assertion.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
