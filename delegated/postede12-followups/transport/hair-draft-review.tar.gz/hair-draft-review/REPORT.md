# q3207 hair-seed draft review

The v4 draft is supported within its registered source scope. `Look::guides`
casts the signed `HairSeed` word to `u64` before calling `Hairdo::guides`.
The optional GPU host stores the same cast in `Guides::Hairdo` and separately
reaches `guide_key` through `record_guide_roots`. For a negative signed word,
that widening has an all-one high half; `HairSeed::from_word` stores the low
32-bit pattern zero-extended in its canonical `Seed`. The shared key function
uses both halves, so replacing the cast changes a hash input. This is symbolic
source reasoning, not an executed or observed output difference. Public
`Hairdo::guides` accepts the wider `u64` domain. Other callers, adapter policy,
GPU behavior and exact aliases remain open.

The coordinator's 14 registered views, totaling 653 displayed lines, match the
authenticated q3207 source captures; this reviewer separately read those ranges.
The packet's offline Git path proofs and restricted inventory replay passed
after authenticated restoration. The coordinator and packet author are
separate readers. This reviewer also authored the q3207 delegate packet, so this
is a fresh review of the coordinator's draft, not independent-author
corroboration of that packet. The facade example and one GPU test-module window
were source text only.

Original and reconstructed selected q161, q2407, q3144 and q3207 values match,
while their full queue streams differ. q2407 and q3144 retain their own Lens 2
and Lens 3 historical reads; those do not transfer Lens 1 credit. q161 and
ledger rows 646–647 concern a different signed seed-offset first operation;
row 669 records a related retained-operation owner question. Neither a shared
alias nor a new unique-defect count is established.

The original coordinator history registration mislabeled the staged successor
baseline as d7. It is preserved. The correction and this review compare selected
rows 633, 645, 646, 647 and 669 across the authenticated dac7 evidence, exact
dac7 and d7 Git blobs and the staged successor: their parsed row values match,
but the three complete baselines have different hashes. v3 distinguishes the
CPU and GPU host routes; v4 adds direct relationship source references. Both
predecessors and corrections remain intact. A broad historical metadata display
was tool-truncated before a targeted reread; no extra read credit is inferred.

Original checkpoint 3821 remains missing. Original 059 selections, reconstructed
queue and 440 state, historical summaries, normalized recovered 774 versus
missing pre-export originals, SOURCE004 and newly assessed work retain their
separate qualifications. The 73 nontext/no-positive-EOF contracts and thirteen
lenses remain open. Full replay requires the separately held encrypted packet,
private proof, same-machine key and evidence tooling. Same-machine custody is
not independent custody. No product code, GPU shader, macro, test, fixture,
build, repair or runtime probe ran.
