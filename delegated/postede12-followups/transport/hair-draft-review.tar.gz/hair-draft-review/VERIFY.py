#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-hair-review-public-v1';assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for name,row in m['files'].items():
 b=(p/name).read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
r=json.loads((p/'REVIEW.json').read_bytes());assert r['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and r['queue_index']==3207 and r['coordinator_source_views']==14 and r['displayed_lines_sum']==653 and r['reviewer_is_delegate_packet_author']
print('Verified public review only; authenticated sources, key and private proofs remain separate.')
