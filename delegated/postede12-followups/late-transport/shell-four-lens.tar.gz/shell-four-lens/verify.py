#!/usr/bin/env python3
"""Read-only verification of shell-topology source and historical evidence."""
import argparse,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(cond,msg):
 if not cond:raise ValueError(msg)
def safe(root,n):
 t=pathlib.PurePosixPath(n);need(not t.is_absolute() and '..' not in t.parts,'unsafe relative path');return root.joinpath(*t.parts)
def tree(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'short tree');n=b[a+1:z].decode();need(n not in d,'duplicate tree entry');d[n]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
def runs(s):
 out=[]
 for n in sorted(s):
  if out and out[-1][1]+1==n:out[-1][1]=n
  else:out.append([n,n])
 return out
def main():
 arg=argparse.ArgumentParser();arg.add_argument('--restricted',type=pathlib.Path);arg.add_argument('--repository');a=arg.parse_args();m=read(P/'MANIFEST.json');actual={p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_file() and p!=P/'MANIFEST.json'};need(actual==set(m['files']) and not any(p.is_symlink() for p in P.rglob('*')),'manifest file set')
 for n,v in m['files'].items():
  p=safe(P,n);b=p.read_bytes();need(sh(b)==v['sha256'] and len(b)==v['bytes'] and (p.stat().st_mode & 0o777)==v['mode'],'manifest identity '+n)
 for x in read(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(x['name']+'.md')).read_bytes();need(sh(b)==x['sha256'] and len(b.splitlines())==x['lines'],'skill')
 need([(x['queue'],x['lens']) for x in read(P/'SOURCE-REGISTRATION.json')['assigned_own_lenses']]==[(3305,1),(3306,2),(3308,5),(3309,6)],'queue and lens selection')
 regs={n:read(P/n) for n in ('SOURCE-REGISTRATION.json','SUPPORT-REGISTRATION.json','SUPPORT-REGISTRATION-2.json')};receipt=read(P/'READ-RECEIPT.json');unions={};views=0
 for r in receipt['rows']:
  b=safe(P,r['source_file']).read_bytes();lines=b.decode().splitlines();need(sh(b)==r['sha256'] and oid(b'blob',b)==r['git_blob'] and len(lines)==r['EOF'],'source identity '+r['label'])
  if r['role']=='assigned':
   row=next(x for x in regs[r['registration']]['sources'] if x['label']==r['label']);need(row['revision']==r['revision'] and row['path']==r['path'] and row['sha256']==r['sha256'] and row['planned_ranges']==r['registered_ranges'],'assigned scope')
  else:
   row=next(x for x in regs[r['registration']]['rows'] if 'support-'+x['label']==r['label']);path=row.get('git_path',row.get('path'));rev=row.get('revision',row.get('rev'));scope=row.get('registered_ranges',row.get('ranges'));need(path==r['path'] and rev==r['revision'] and scope==r['registered_ranges'],'support scope')
  allowed=set()
  for lo,hi in r['registered_ranges']:allowed.update(range(lo,hi+1))
  seen=set()
  for v in r['views']:
   lo,hi=v['range'];need(1<=lo<=hi<=len(lines),'view bounds');data=safe(P,v['file']).read_bytes();expected=''.join((f'{i}: {lines[i-1]}\n' if r['role']=='assigned' else f'{i:4d} {lines[i-1]}\n') for i in range(lo,hi+1)).encode();need(data==expected and sh(data)==v['sha256'],'display bytes');seen.update(range(lo,hi+1));views+=1
  need(seen==allowed,'registered/display range mismatch');key=(r['revision'],r['path']);u=unions.setdefault(key,{'eof':len(lines),'seen':set()});u['seen'].update(seen)
 for c in receipt['coverage']:
  u=unions[(c['revision'],c['path'])];need(runs(u['seen'])==c['displayed_union'] and runs(set(range(1,u['eof']+1))-u['seen'])==c['unread_complement'],'display coverage')
 need(len(unions)==len(receipt['coverage'])==10,'coverage pair count');need(all(c['displayed_union']==[[1,427]] and c['unread_complement']==[] for c in receipt['coverage'][:3]),'primary complete scopes')
 need(all(x['registration_precedes_view'] and x['registration_mtime_ns']<=x['source_view_mtime_ns'] for x in read(P/'READ-CHRONOLOGY.json')['rows']),'chronology metadata')
 proofs=read(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==11,'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree length')
  for part,step in zip(parts,x['tree_chain']):
   need(step['tree']==cur and step['entry']==part,'tree sequence');raw=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',raw)==cur,'tree identity');mode,cur=tree(raw)[part];need(mode==step['mode'] and cur==step['object'],'tree entry')
  need(cur==x['blob'],'target blob')
  if x['role']=='source':need(oid(b'blob',safe(P,x['source_file']).read_bytes())==cur,'source blob')
  elif a.restricted:
   raw=safe(a.restricted,x['source_file']).read_bytes();need(sh(raw)==x['sha256'] and oid(b'blob',raw)==cur,'restricted evidence blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository revision')
 selections=read(P/'HISTORY-SELECTION.json')['records'];need([x['index'] for x in selections[:8]]==[3279,3280,3282,3283,3305,3306,3308,3309],'history indices');need([x['lens'] for x in selections[4:8]]==[1,2,5,6] and all(x['original_reconstructed_selected_parsed_equal'] for x in selections),'history lenses/equality')
 need([(x['queue'],x['lens']) for x in read(P/'ASSESSMENTS.json')['assessments']]==[(3305,1),(3306,2),(3308,5),(3309,6)],'assessment mapping')
 restricted=False
 if a.restricted:
  h=a.restricted/'historical';prior=(h/'prior-059-capture-manifest.json').read_bytes();need(sh(prior)=='51e55a2e99b5951e915e32243e5a2b011e73580e5873fae2eb05443aea379a45','prior manifest');old=read(h/'prior-059-capture-manifest.json')['files'];qs=[]
  for n in ('queue-original-56f.json','queue-reconstructed-dac7d.json'):
   b=(h/n).read_bytes();need(sh(b)==old['historical/'+n]['sha256'],'full queue custody');qs.append(json.loads(b))
  for x in selections:
   a0=qs[0]['entries'][x['index']];b0=qs[1]['entries'][x['index']];need(a0==b0 and x['contract_id']==a0.get('contract_id') and x['lens']==a0.get('lens'),'selected queue entry');need(sh((json.dumps(a0,indent=2,ensure_ascii=False)+'\n').encode())==x['original_normalized_sha256'] and sh((json.dumps(b0,indent=2,ensure_ascii=False)+'\n').encode())==x['reconstructed_normalized_sha256'],'normalized selections')
  for x in read(P/'RECEIPT-CAPTURE.json'):
   b=(h/('receipt-'+pathlib.PurePosixPath(x['relative']).name)).read_bytes();need(sh(b)==x['sha256'] and len(b)==x['bytes'],'historical receipt identity')
  old3=read(h/'receipt-READ-ROOT-L3-EXT-046-055.json')['rows'][0];now3=read(h/'receipt-READ-ROOT-L3-CURRENT-006.json')['rows'][1];need(old3['fresh_personal_ranges']==[[1,427]] and now3['fresh_personal_ranges']==[] and now3['qualified_reuse_ranges']==[[1,427]],'prior L3 attribution')
  old2=read(h/'receipt-READ-ROOT-L2-EXT-045-051.json')['rows'][0];now2=read(h/'receipt-READ-ROOT-L2-CURRENT-010.json')['rows'][0];need(old2['fresh_personal_ranges']==[[236,427]] and old2['qualified_inherited_same_lens_ranges']==[[1,235]] and now2['fresh_personal_ranges']==[] and now2['qualified_same_lens_reuse_ranges']==[[1,427]],'prior L2 attribution')
  obj=(h/'recovered-98444936697b73035be3e07e0464a3e4a031ad0b1f28084275206b1b8ae7eb91').read_bytes();need(obj==(P/'sources/old-6533.rs').read_bytes(),'recovered source object')
  supplier=(h/'recovered-INHERITED-L2-RIG-additional-sources.jsonl').read_bytes();need(sh(supplier)=='89cdd99753ed0a48b1539e2509f3aeaa5c878ac54205077cf02a74fc6bab580a','rig supplier bytes');need(json.loads(supplier.splitlines()[228])['read_ranges']==[[1,235]],'rig supplier range')
  pm=(h/'prior-solver-BUNDLE-MANIFEST.json').read_bytes();need(sh(pm)=='131510648c4ce9d6191a5ea736c2dbf925347e225c098443ff82c405e767427d','earlier packet anchor');entries={x['path']:x for x in json.loads(pm)['files']}
  for n in ('report.json','read-receipt.json','registration.json'):need(sh((h/('prior-solver-'+n)).read_bytes())==entries[n]['sha256'],'earlier packet '+n)
  committed=(h/'baseline-committed.json').read_bytes();working=(h/'baseline-working-observed.json').read_bytes();need(sh(committed)=='a44137624c56f7567ff936137294289f762228408bada87be81476877a6d595e' and sh(working)=='a402d49eb6dab3cd9182e16db92d2ea91896c761d02c87b2fcdad9d50efa7276' and committed!=working,'ledger snapshots');aa=json.loads(committed)['newly_assessed_ledger']['entries'];bb=json.loads(working)['newly_assessed_ledger']['entries'];need(all(aa[i]==bb[i] for i in (713,731,737,1029)),'selected ledger entries')
  roots={}
  for x in read(a.restricted/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(a.restricted/'private-commits'/(x['revision']+'.commit')).read_bytes();need(sh(b)==x['whole_commit_payload_sha256'] and oid(b'commit',b)==x['revision'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'commit identity');roots[x['revision']]=x['root_tree']
  need(all(roots[x['revision']]==x['root_tree'] for x in proofs),'commit to tree binding');restricted=True
 print(json.dumps({'result':'pass','public_files':len(actual),'registered_display_chunks':views,'source_revision_pairs':len(unions),'git_tree_path_proofs':len(proofs),'restricted_historical_and_commit_inputs_checked':restricted,'repository_revision_checked':bool(a.repository),'limits':'Evidence integrity, not product behavior, alias, count, or lens closure.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
