# Shell topology: four bounded source-lens assessments

Reviewer: `/root/mhr_character`. Corrected queue obligations 3305, 3306, 3308
and 3309 correspond to historical lenses 1, 2, 5 and 6. Originally supplied
3279, 3280, 3282 and 3283 are different Lens 11 continuation entries. The
selection was checked and reported before source display; no source was read
under those mistaken assignments.

`crates/fabelgeist-shell/src/topology.rs` is 427 lines and has SHA-256
`98444936697b73035be3e07e0464a3e4a031ad0b1f28084275206b1b8ae7eb91` in the
recovered 6533 file, e275 file, and pinned 95e file; source Git blob is
`ec610976d22165a3bd7f5e527311c30e0ee65ce3`. The recovered original source
object also has that hash. Equality is per file only: the recorded historical
working snapshot had unrelated changes, and the working snapshot is not
claimed clean. One independently preregistered, complete, personally displayed
source body per revision was assessed through all four explicit lenses.

## Lens 1: producer propagation (q3305)

The geometry path uses triangle corner ordinals to derive edges, boundary
edges and bends (`topology.rs:41–92`), while density is already represented
by `ParticleArealDensity`, accumulated as `ParticleMass`, and mapped to
`ParticleInverseMass` (`topology.rs:100–125`; `dynamics/mass.rs:77–111,
136–157`). `ShellMesh::new` checks positive finite density, finite positions,
and triangle membership before deriving or indexing them (`mesh.rs:33–73`).
`Shell::new` validates a mesh and converts edge and bend ordinals to the
solver's `ConstraintEdges` and `ParticleIndex` roles (`shell.rs:75–119`); it
reorders corresponding weights together (`shell.rs:132–137`). This is a
meaningful consumer boundary. It does not establish that all upstream geometry
ordinals should already be solver particle IDs.

The separately inspected garment producer accepts a typed density, constructs
triangle lists and invokes `vertex_masses` (`garment/mod.rs:218–229, 271–296,
341–343`); the displayed entrance does not itself test density validity.
`From<f32>` preserves input and `validity` is a separate method
(`dynamics/mass.rs:136–157`). Whether supported callers admit that input
earlier and whether any unvalidated result reaches a relevant consumer remain
open. No runtime outcome or new unique defect is established.

## Lens 2: existing owners (q3306)

The source already separates areal density, mass, and inverse mass, including
the intentional prescribed-particle zero (`mass.rs:22–58, 77–103, 136–157`).
The existing solver `ParticleIndex` assigns a particle address role but
explicitly does not establish membership in a particular buffer
(`incidence.rs:6–14`); the selected Shell boundary converts to it. The
`fabelgeist-mesh` `PrimitiveTopology` enum describes draw primitive shapes
(`topology.rs` in that crate, lines 17–35), whereas shell `Topology` describes
derived edge/bend adjacency. Neither is a demonstrated interchangeable owner
for the other. The signed coefficients and padded native weight record have a
different purpose from mass (`shell/mesh.rs:61–70`; `shell.rs:132–137`).
No blanket raw-index replacement or exhaustive owner inventory is justified.

## Lens 5: aggregate states (q3308)

`Topology` and `BendQuad` have public fields (`topology.rs:10–38`); `build`
sorts edge keys, classifies one incident triangle as boundary, two as a bend,
and intentionally suppresses bends for non-manifold edges (`:45–92`). The
normal shell constructor derives coherent arrays, and `ShellMesh::validate`
checks particle and associated-array lengths, index membership, and finite
rest values (`mesh.rs:38–53, 61–83, 85–127`). Validation does not recompute
edges/bends from triangles or prove weight/hinge semantic correspondence for
a directly constructed or subsequently mutated public mesh. A caller can
therefore represent mismatched but individually in-range fields; the existence
of a supported such caller and any solver outcome remain open. Treat the
first pre-admission aggregate question as related to, but not automatically
identical with, the existing post-admission retained-topology and particle
membership records.

## Lens 6: type ownership (q3309)

The reviewed source supports a distinction between shell adjacency, the mesh
primitive-shape enum and the solver particle-address role; it does not prove a
duplicate or misplaced owner. The particle type documents that it does not
perform receiving-buffer membership, and public native/aggregate boundaries
still require separate assessment. Ownership across uninspected callers and
whether coherent construction or a narrower API is preferred remain policy
questions.

## Historical and current relationships

Original 059 q3296 records Root's independent Lens 3 6533 full-body read; its
e275 revisit is a qualified reuse of identical bytes, with no new personal
read. Q2449 records the separate Lens 2 split: rig-supplier 1–235 and Root
fresh 236–427 at 6533; its e275 evidence is same-lens qualified reuse, not a
fresh e275 reread. Q442 retains `/root/lens12_frontier`'s 6533 lines 1–235
and concerns a separate retained surface-extent contract. The 059 q records
are recovered historical records, not checkpoint 3821. Exact receipts and
queues are retained restricted; safe selected fields and hashes are public.

The earlier separate role 2345 packet by this reviewer read 6533 and 95e
1–427 and recorded a conditional nondegenerate-hinge cutoff. The existing
current ledger `REVIEW-SHELL-NONDEGENERATE-BEND-CUTOFF-95E` preserves this
question and its unsupported ordinary-scale reachability; no new count is
claimed. `REVIEW-SHELL-POST-ADMISSION-TOPOLOGY-95E`,
`REVIEW-XPBD-CONSTRAINT-PARTICLE-MEMBERSHIP-95E`, and `RIG-ADMISSION03-F082`
are related but have their own first operations and attributions. Exact global
aliases and repair ownership remain for central reconciliation.

The committed baseline snapshot and the observed working snapshot have
different whole-file hashes. Selected related rows were equal in the captured
versions, which says nothing about other entries or the cleanliness of the
working tree. All tests and examples were text only. This packet is source and
evidence inspection, not product validation, a unique finding count, ledger
closure, or a whole-lens verdict.
