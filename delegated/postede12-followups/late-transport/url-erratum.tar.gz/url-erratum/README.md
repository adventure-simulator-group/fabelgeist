# Correction to the four-lens location URL assessment

The predecessor packet is unchanged. CORRECTION.json replaces one overbroad statement about route-pattern checking and clarifies the merchant form branch. The previously registered 95e source transcript, not this later spot-check, supplies the original reading. The follow-up receipt preserves additional unregistered reads and two empty selections; its exact restricted copy is held separately. No product or validation code ran.

Run `python3 verify-correction.py` for this packet's manifest. Add `--predecessor DIRECTORY` to check the fixed predecessor manifest and verify the old sentence occurs there. This does not establish the semantic conclusion or recover missing private evidence.
