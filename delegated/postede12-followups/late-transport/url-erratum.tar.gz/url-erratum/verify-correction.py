#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--predecessor',type=Path);a=a.parse_args()
m=json.loads((p/'MANIFEST.json').read_bytes());assert {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f.name!='MANIFEST.json'}==set(m['files'])
for n,v in m['files'].items():
 f=p/n;b=f.read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode']
print('correction manifest: pass')
c=json.loads((p/'CORRECTION.json').read_bytes())
if a.predecessor:
 b=(a.predecessor/'MANIFEST.json').read_bytes();assert H(b)==c['predecessor_public_manifest_sha256'];m=json.loads(b);f=a.predecessor/c['predecessor_file'];assert H(f.read_bytes())==m['files'][c['predecessor_file']]['sha256'];assert c['old_exact'] in f.read_text();print('predecessor manifest, report hash and original sentence: pass')
else:print('NOT CHECKED: separately held predecessor manifest and old wording')
print('No product execution or semantic validation.')
