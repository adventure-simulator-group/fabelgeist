#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-postede-combined-review-public-v1';assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for name,row in m['files'].items():
 b=(p/name).read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
r=json.loads((p/'REVIEW.json').read_bytes());assert r['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and r['selected_queue_indices']==[3064,3207,3127,3128] and r['ledger_prefix_rows']==1093 and r['parent_ledger_rows']==1099 and r['new_ids_absent_exact_only'] and r['hair_reviewer_is_packet_author']
print('Verified public review packet only; draft inputs, Git blobs and private proofs remain separate.')
