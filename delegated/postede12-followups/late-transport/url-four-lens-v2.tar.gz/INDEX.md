# Scope

Review REVIEW-L1.md, REVIEW-L2.md, REVIEW-L5.md, REVIEW-L6.md, READ-LIMITS.json and historical summaries. Integrity replay does not establish semantic conclusions or product behavior.
