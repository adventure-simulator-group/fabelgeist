#!/usr/bin/env python3
"""Evidence-only replay; never executes product, tests, fixtures, shaders or macros."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);d[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return d
def prove(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/f'{t}.tree').read_bytes();assert oid('tree',b)==t;mode,t=tree(b)[part]
 assert mode=='100644' and oid('blob',data)==t
def manifest(d):
 m=json.loads((d/'MANIFEST.json').read_bytes());found={str(f.relative_to(d)) for f in d.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};assert found==set(m['files'])
 for n,v in m['files'].items():
  f=d/n;b=f.read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes'] and (f.stat().st_mode&0o777)==v['mode']
def windows(rows,by,folder):
 for row in rows:
  if row['path']=='crates/strategic-web/src/main.rs':continue
  ls=(P/by[row['path']]['file']).read_text().splitlines(keepends=True)
  for lo,hi in row['ranges']:
   name=f"{row['path'].replace('/','__')}-{lo}-{hi}.txt";assert (P/folder/name).read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: public packet manifest (--skip-manifest)')
else:manifest(P);print('public file set, sizes, modes and hashes: pass')
roots={'6533':'849ec1e8faca2236c7021893cda7a3f7cb5c72e8','e275':'7737c903f98397669c12da05475f759aa7fcfe73','95e':'1eec97de340d9b7debbb30ca0c0fb2240a73b93f'}
for row in json.loads((P/'SOURCE-002-RESULT.json').read_bytes())['rows']:
 label=row['label'];assert row['chain'][0]['tree']==roots[label];b=(P/'source'/f'{label}.rs').read_bytes();assert H(b)=='4cdfe5103f103f2628c55f1f8d3f9dd407342458647215a44b5add07c03dcb14' and len(b.splitlines())==208 and b.endswith(b'\n');prove(roots[label],'crates/strategic-web/src/location_urls.rs',b);ls=b.decode().splitlines(keepends=True)
 for lo,hi in [(1,104),(105,208)]:assert (P/'displays'/f'{label}-{lo}-{hi}.txt').read_text()==''.join(f'{i:4d} '+ls[i-1] for i in range(lo,hi+1))
by={}
for name in ['ADJ-007-CAPTURE-RESULT.json','SERVICE-012-CAPTURE-RESULT.json']:
 for row in json.loads((P/name).read_bytes()):
  if row['path']=='crates/strategic-web/src/main.rs':continue
  b=(P/row['file']).read_bytes();assert H(b)==row['sha256'] and oid('blob',b)==row['blob'] and len(b.splitlines())==row['EOF'];prove(roots['95e'],row['path'],b);by[row['path']]=row
windows(json.loads((P/'ADJ-009-DISPLAY-REG.json').read_bytes())['windows'],by,'adj-displays')
windows([json.loads((P/'PATTERNS-010-REG.json').read_bytes())],by,'adj-displays')
windows(json.loads((P/'SERVICE-013-REG.json').read_bytes())['windows'],by,'service-displays')
names={1:'producer-propagation',2:'existing-type-owners',5:'aggregate-states',6:'type-ownership'}
for r in json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows']:assert r['name']==names[r['number']] and H((P/f"SKILL-L{r['number']}.md").read_bytes())==r['skill']['sha256']
print('selected root-tree/blob proofs, target/available adjacent transcripts and four skill hashes: pass')
print('NOT CHECKED in public packet: main.rs whole blob and two windows, deliberately omitted; available only with restricted packet')
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if not a.private:print('NOT CHECKED: commit-to-root binding, original handoff map, full queue membership, historical receipt linkage, private reconstruction and dac7d ledger membership; separately held restricted packet required')
else:
 assert H((a.private/'MANIFEST.json').read_bytes())=='b23acd70c13370c9932e6d937ec73369c2a10ea277b4e528f64989e727c3501c';manifest(a.private)
 for item in json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes())['files']:
  old=(a.private/item['original_file']).read_bytes();assert H(old)==item['original_whole_file_sha256'];out=bytearray();last=0
  for r in item['replacements']:
   i=r['original_byte_offset'];n=r['original_byte_length'];assert i>=last;out+=old[last:i]+r['replacement'].encode();last=i+n
  out+=old[last:];assert bytes(out)==(P/item['successor']).read_bytes() and H(out)==item['successor_whole_file_sha256']
 m=json.loads((a.private/'PRIVATE-HANDOFF-LENS-MAP.json').read_bytes());assert json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows']==[m['lenses'][i-1] for i in [1,2,5,6]]
 h=json.loads((P/'HISTORY-SUMMARY.json').read_bytes())
 for row in h['obligations']+h['relationships']:
  b=(a.private/f"PRIVATE-Q{row['index']}-original.json").read_bytes();q=json.loads(b);assert H(b)==row['selected_record_sha256'] and q['contract_id']==row['contract_id'] and q['lens']==row['lens'] and q.get('status')==row['status']
 print('restricted manifest, reconstruction crosswalk, selected handoff map and queue summary: pass')
 cmd=[sys.executable,str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,end='')
 if r.returncode:print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
print('Integrity replay does not prove semantic conclusions, recover 3821 or validate product behavior.')
