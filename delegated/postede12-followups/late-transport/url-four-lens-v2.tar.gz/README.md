# Four independently assessed location URL lenses

This public-safe reconstructed successor contains separately assessed source-only reports and exact source/tree/display bytes. It is not the complete 059 queue, historic receipt archive, or missing checkpoint 3821. Restricted originals and their manifest must be held separately. Read READ-LIMITS.json and HISTORICAL-ATTRIBUTION.json.

Run `python3 verify-public.py` for public content, root-tree/blob and transcript checks. `--private DIRECTORY` additionally verifies the exact separately held restricted manifest and reconstruction crosswalk, then runs the evidence-only verifier. Add `--anchors DIRECTORY` for separately held full original/reconstructed 059 queue membership. Without these dependencies commit-to-root binding, full queue membership, historical receipt linkage and private reconstruction are not checked. No product, build, test, shader, macro, fixture or runtime execution is part of replay.

`PUBLIC-OMISSION.json` identifies one adjacent source blob and two windows held only in the restricted packet. The initial unsealed candidate and its privacy scan remain separately held.
