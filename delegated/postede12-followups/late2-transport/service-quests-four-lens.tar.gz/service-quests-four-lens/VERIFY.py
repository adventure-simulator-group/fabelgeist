#!/usr/bin/env python3
"""Evidence-only offline verifier; never loads or executes product source."""
import argparse,hashlib,json,os,re,stat,zlib
from pathlib import Path
if not __debug__: raise SystemExit('do not run under Python optimization')
def sha(b): return hashlib.sha256(b).hexdigest()
def files(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise AssertionError('symlink in evidence')
  if p.is_file() and p.name not in ('MANIFEST.json','MANIFEST-PRIVATE.json'):
   out[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')}
 return out
def verify_manifest(root,name):
 m=json.loads((root/name).read_bytes());assert files(root)==m['files'],name
 assert all(v['mode']=='0600' for v in m['files'].values())
def decode_object(root,oid,meta):
 packed=(root/(oid+'.zlib')).read_bytes();assert sha(packed)==meta['stored_sha256'];raw=zlib.decompress(packed);assert hashlib.sha1(raw).hexdigest()==oid
 h,body=raw.split(b'\0',1);kind,size=h.decode().split(' ');assert len(body)==int(size);assert kind==meta['type'];assert len(body)==meta.get('size',meta.get('bytes'));assert sha(body)==meta['sha256'];return kind,body
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();entry=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if entry==name:return mode,oid
 raise AssertionError('missing tree entry '+name)
def proof(base,manifest_name,objdir,captures):
 info=json.loads((base/manifest_name).read_bytes());objs={k:decode_object(base/objdir,k,v) for k,v in info['objects'].items()};found={}
 for q in info['proofs']:
  rev=q['revision'];assert objs[rev][0]=='commit';commit=objs[rev][1];assert commit.startswith(b'tree ');tree=commit.split(b'\n',1)[0][5:].decode();treeids=[];components=q['path'].split('/')
  for index,name in enumerate(components):
   treeids.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],name)
   if index<len(components)-1: assert mode in ('40000','040000');tree=oid
   else: assert mode in ('100644','100755');assert oid==q['blob'];assert objs[oid][0]=='blob';body=objs[oid][1]
  assert sha(body)==q['sha256'] and len(body)==q['bytes']
  if 'trees' in q: assert treeids==q['trees']
  if 'chain' in q: assert [x['tree'] for x in q['chain']]==treeids and [x['child'] for x in q['chain']][-1]==oid
  if captures: assert body==(base/q['capture']).read_bytes()
  found[(rev,q['path'])]=body
 return found
def exact_selections(raw,indices):
 text=raw.decode('utf8');m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \n\r\t,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
def window(root,raw,name,lo,hi):
 lines=(root/raw).read_bytes().decode('utf8').splitlines();assert 1<=lo<=hi<=len(lines)
 s='\n'.join(f'{i:4} {lines[i-1]}' for i in range(lo,hi+1))+'\n';assert s.encode()==(root/name).read_bytes()
def main():
 a=argparse.ArgumentParser();a.add_argument('--private',type=Path);args=a.parse_args();public=Path(__file__).resolve().parent;verify_manifest(public,'MANIFEST.json');print('public manifest: PASS')
 if args.private is None: print('restricted replay: NOT REQUESTED');return
 root=args.private.resolve();verify_manifest(root,'MANIFEST-PRIVATE.json')
 source=proof(root,'SOURCE-GIT-PROOF.json','git-objects',True);extra=proof(root,'ADDITIONAL-GIT-PROOF.json','additional-git-objects',True);checkpoint=proof(root,'CHECKPOINT-GIT-PROOF.json','checkpoint-git-objects',True);history=proof(root,'historical-git-proof-reference.json','historical-git-objects',False)
 revs=['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f','95e63628f9d70b8dd6e6fede64334696c6995009'];path='crates/strategic-web/src/routes/settlements/service_quests.rs';expected='94a890ee2893205a08de7ba3635a88574f23aab5a628f88a0a08bfc5d74c55d5'
 assert len(source)==12 and len(extra)==3 and len(checkpoint)==2 and len(history)==3
 assert all(sha(source[(r,path)])==expected for r in revs);assert all(source[(r,path)]==source[(revs[0],path)] for r in revs)
 old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';rec='dac7d0055716053f245139971eb67ddfd87fa462';hpath='baseline-059/queue.json';assert sha(history[(old,hpath)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert sha(history[(rec,hpath)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 indices=[2452,3329,3330,3332,3333];oldsel=exact_selections(history[(old,hpath)],indices);newsel=exact_selections(history[(rec,hpath)],indices)
 for i in indices:
  assert oldsel[i][0]==newsel[i][0]
  for label,sel in [('original',oldsel),('reconstructed',newsel)]:
   filename=f'q2452-{label}.json' if i==2452 else f'{label}-q{i}.json';assert sel[i][1]==(root/filename).read_bytes()
 assert oldsel[2452][1]==newsel[2452][1]
 assert oldsel[2452][0]['contract_id']=='L2-SERVICE-QUEST-LIVING-PARTY-NATIVE-DTO'
 for i,lens in [(3329,1),(3330,2),(3332,5),(3333,6)]:
  v=oldsel[i][0];assert v['lens']==lens and v['body_or_population_credit']==0 and v['status']=='own-lens-proof-qualification-or-read-pending';assert v['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,44]]
 ede='ede12d3f9f19d284abbc669b5ae38b814a585f77';base=checkpoint[(ede,'BASELINE-95E-20261110.json')];recbytes=checkpoint[(ede,'RECONCILIATION-059.json')];assert sha(base)=='a402d49eb6dab3cd9182e16db92d2ea91896c761d02c87b2fcdad9d50efa7276';assert sha(recbytes)=='be6acb889cb51b645d03e861715895c9efcf0f47e970cc8fa12f1d03404a9f94';q=json.loads(recbytes)['entries'];assert len(q)==3713
 for i in indices:assert q[i]['current_reconciliation']=='unassessed' and q[i]['contract_id']==oldsel[i][0]['contract_id']
 rows=json.loads(base)['newly_assessed_ledger']['entries'];assert len(rows)==1099
 for i,id in [(746,'REVIEW-LIFE-ONLY-CASE-SITE-DEPENDENCY-95E'),(818,'REVIEW-RECRUITMENT-MULTIPLE-COMPANIES-95E'),(819,'REVIEW-RECRUITMENT-SEPARATOR-ENCODING-95E'),(823,'REVIEW-RECRUITMENT-COLLECTION-AVAILABILITY-95E')]:assert rows[i]['id']==id
 for n,h in [('l2-read.json','ccf6822ca663a5db56dd1a452880d81c0ee2e0dff7bd3c0cb6a16bc8e97bd289'),('l2-current-read.json','f145b107d970abd65a6ce35e01cdcaec888c4adc5d6bb32c73b0a5fd26df6a71'),('root-l3-read.json','32d8a9c8a5c59c9b023cf3a1fc7bb1a7d27f35ff9ddc4ba2e5e0e1af0f959440')]:assert sha((root/n).read_bytes())==h
 l2=json.loads((root/'l2-read.json').read_bytes())['rows'][3];l2cur=json.loads((root/'l2-current-read.json').read_bytes())['rows'][3];assert l2['fresh_personal_ranges']==[[1,44]] and l2cur['fresh_personal_ranges']==[] and l2cur['qualified_same_lens_reuse_ranges']==[[1,44]]
 windows=[('source-6533.raw','display-6533-001-044.txt',1,44),('source-e275.raw','display-e275-001-044.txt',1,44),('source-95e.raw','display-95e-001-044.txt',1,44),('source-95e.raw','service-context-045-166.txt',45,166),('source-95e.raw','service-context-200-420.txt',200,420),('source-95e.raw','service-context-468-550.txt',468,550),('source-95e.raw','service-role-match.txt',533,590),('context-offers.raw','context-offers-display-v2.txt',1,93),('context-overview.raw','context-overview-display-v2.txt',125,210),('context-types.raw','context-types-display.txt',100,255),('context-types.raw','types-character-conversion.txt',450,500),('context-authority.raw','context-authority-display.txt',475,545),('context-router.raw','context-router-display.txt',390,405),('context-offer-birth.raw','context-offer-birth-display.txt',1290,1355),('context-offer-birth.raw','context-offer-presence.txt',1180,1290),('context-js.raw','context-js-display-v2.txt',1,63),('context-encumbrance.raw','context-party-producer.txt',356,415),('context-encumbrance.raw','context-party-producer-tail.txt',415,440),('context-encumbrance.raw','context-party-final-display.txt',441,484),('context-project-alive.raw','context-project-alive-display.txt',85,145),('context-project-alive.raw','context-project-alive-tail.txt',144,155),('context-recruitment-template.raw','context-recruitment-template-display.txt',40,83),('context-party-routes.raw','context-party-join-display.txt',260,350),('context-governance.raw','context-governance-join-display.txt',1240,1375)]
 for x in windows:window(root,*x)
 print('restricted manifest, 15 source paths/revisions, checkpoint, prior queue proofs, 5 exact selections, 24 displayed windows: PASS')
 print('Scope: evidence bytes and registered displays only; no product execution, semantic closure, runtime validation, independent custody, or checkpoint 3821 claim.')
if __name__=='__main__':main()
