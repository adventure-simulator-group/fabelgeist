# Role 0048: service response and observed party members

This is a bounded source-only assessment by `verifier_scope` after the published
ede checkpoint. The assigned original 059 queue obligations are q3329 (Lens 1,
producer propagation), q3330 (Lens 2, existing type owners), q3332 (Lens 5,
aggregate states), and q3333 (Lens 6, type ownership). The recorded required
range is `crates/strategic-web/src/routes/settlements/service_quests.rs:1-44`;
this report does not claim full-file, whole-role, native, runtime, or lens
completion. Every assigned entry, and related q2452, is unassessed in immutable
ede reconciliation. The current ledger and queue are centrally owned.

The source blob at 6533, e275, and authoritative 95e has Git blob
`38a158fc16ee5def5dab4e763f18bff77541a7b5`, SHA-256
`94a890ee2893205a08de7ba3635a88574f23aab5a628f88a0a08bfc5d74c55d5`, and
725 lines. Each revision's 1-44 was displayed by this reviewer after
registration. Whole-file bytes were captured for identity and selected
connected ranges below were also personally displayed; capture is not
unlimited read credit. Git membership proofs cover the selected paths only.

## Four lens dispositions

* **Producer propagation (q3329):** `ServiceQuestRecruitment.offer_id` is a
  `String` in a serialized response (`service_quests.rs:15-24,388-396`) even
  though the stored row has both string primary key `id_key` and a
  `RecruitmentOfferId { value: String }` (`authority_model.rs:497-535`). One
  inspected creation sets both from the same `offer_key`
  (`mission_bootstrap.rs:1329-1342`); this does not prove equality across every
  mutation or imported row. The named JavaScript consumer uses service and
  leader fields and role markup, but does not consume `offer_id`
  (`service-quests.js:1-63`). Whether to propagate the typed identity internally
  before the JSON scalar boundary and what other consumers require remain
  questions, not an established defect or automatic repair.
* **Existing type owners (q3330):** the role and party views keep a numeric role
  ID and string party ID, while the final DTO emits presentation values
  (`types.rs:108-123,160-169,228-237`; `service_quests.rs:27-37,345-395`).
  The existing recruitment-offer ID wrapper is a concrete related owner, but
  its record shape and the independently indexed string key mean that replacing
  the JSON scalar is not automatically correct. The existing `CharacterView`
  supplies the life flag; its meaning on the traced path is qualified below.
  Other identity owners and all clients were not exhaustively inspected.
* **Aggregate states (q3332):** the inspected producer retains only roles with
  positive computed remaining count and emits a company only when at least one
  role remains (`service_quests.rs:345-396`). Several input query failures
  select empty defaults (`service_quests.rs:209-227,267-296`), and the client
  maps a non-success response to empty arrays (`service-quests.js:8-14`): this
  is related to, not automatically an alias of, ede ledger row 823,
  `REVIEW-RECRUITMENT-COLLECTION-AVAILABILITY-95E`. The producer's multiple
  eligible companies versus the client's first match and the misencoded
  multi-label separator relate separately to ledger rows 818 and 819. No
  execution, policy decision, reachability, global alias, or new count follows.
* **Type ownership (q3333):** these private `Serialize` response records are
  presentation projections, and `ServiceQuestOffer` separately owns a typed
  display-state enum (`service_quest_offers.rs:10-38`). Their raw fields alone
  do not establish a misplaced domain owner. The shown join button receives a
  shared `can_accept` projection (`service_quests.rs:258-263,359-369`;
  `templates/recruitment.rs:44-79`); the inspected native
  `request_to_join_party` independently rejects an active contract and imposes
  additional conditions (`governance.rs:1267-1340`). The HTTP route ignores its
  call result and redirects (`parties.rs:277-335`). Whether missing rejection
  feedback or any other path needs work is not settled by this bounded read.

A cross-lens source condition needs separate policy reconciliation. The helper
`living_party_members` filters the `CharacterView.alive` value it receives
(`service_quests.rs:38-44`); an inspected overview caller sends that result to
travel forecasts (`overview.rs:136-157,179-204`). On this path, the upstream
producer projects life at the selected observer's personal time
(`encumbrance.rs:356-417`; `data.rs:94-149`). If the observer chronology is
unavailable, absent, or a death observation fails, the displayed branches can
set a currently false life flag to true without retaining an uncertainty state.
This supports only an observer-relative/policy question: it does not establish a
wrong current death, product failure, action authorization, reachable failure,
or that the privacy-preserving fallback should be removed. The distinct ede
row 746 concerns a life-only projection's private case-site dependency; it is a
related failure-policy question, not an automatic alias.

## Historical relationship and limits

Original 059 q2452, `L2-SERVICE-QUEST-LIVING-PARTY-NATIVE-DTO`, records Root's
fresh Lens 2 6533 read of lines 1-44; the separate e275 receipt records
same-lens reuse and zero fresh current reread. Its scoped disposition and
remaining current/alias qualification must be retained. This review's fresh
reads are separate. Historical Lens 3 Root read the same 6533 range personally;
e275 was qualified by exact same-lens reuse. Earlier Lens 11 original-index
2382 recorded fresh 1-43 and a separately registered 44-only extension; it did
not read unrelated lines 45-725. These records are not evidence of a fresh
other-lens read or a new count.

The original 059 queue bytes are bound to evidence commit 56f; the later dac7d
queue is reconstructed and remains separately identified. Selected parsed
records agree, which does not make the full streams identical. The 774 catalog
is normalized recovery material, while pre-export originals are missing;
SOURCE004 and the 73 nontext/no-positive-EOF obligations retain their existing
limits. No evidence is promoted to missing checkpoint 3821. Old historical
summaries, recovered originals, reconstructed records, and the present personal
reads have distinct attribution. This packet makes no independent custody or
public external-hosting claim.

Restricted evidence retains the out-of-EOF offer and JavaScript attempts, their
corrected registrations, truncated historical displays and targeted successors,
and the initial unavailable product-worktree Git locator. The tracebacks were
visible but not captured byte-for-byte. Raw Git commit objects and original
records stay in restricted same-machine custody. The evidence-only verifier
checks selected Git object membership, captured bytes, read-window rendering,
queue selections, and ede status; it cannot verify semantic correctness,
privacy beyond its bounded scan, product behavior, or independent custody.
