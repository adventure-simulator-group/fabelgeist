from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,sys,tarfile,tomllib
b=Path(__file__).resolve().parent;args=[x for x in sys.argv[1:] if x!='--record'];pub=Path(args[0]) if args else Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();refs=json.loads((b/'published-references.json').read_bytes())
for x in refs['entries']:
 f=pub/x['path'] if 'path' in x else b/x['preserved_bytes'];raw=f.read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],str(f)
for dirname,manifest,names in [('bevy-reflect-derive-hair-ops','packet-manifest.json',['report.json','support-read-receipt.json']),('bevy-remote','MANIFEST.json',['REPORT.json','personal-read-receipt.json'])]:
 root=b/'prior-delegate'/dirname;pm=json.loads((root/manifest).read_bytes());mi={x['path']:x for x in pm['files']}
 for n in names:
  raw=(root/n).read_bytes();assert len(raw)==mi[n]['bytes'] and sha(raw)==mi[n]['sha256']
reg=json.loads((b/'registration.json').read_bytes());receipt=json.loads((b/'personal-read-receipt.json').read_bytes());registry=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));transport=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));tidx={x['path']:x for x in transport['entries']};report=json.loads((b/'REPORT.json').read_bytes());original=json.loads((b/'original-attribution.json').read_bytes());assert not original['missing_originals'];native=json.loads((b/'native-support-registration.json').read_bytes());archives={x['package']:b/x['preserved_bytes'] for x in native['archives']};checks={}
for x in native['archives']:
 raw=archives[x['package']].read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'];checks[x['package']]=x['sha256']
assert checks['bevy_reflect_derive']==reg['archive']['sha256'];assert [x['original_index'] for x in reg['roles']]==[2569,2570]
def package_source(x):
 raw=(b/x['source_archive']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and len(raw.splitlines())==x['actual_EOF']
 with tarfile.open(archives[x['package']],'r:gz') as t:assert t.extractfile(x['archive_member']).read()==raw
for x in reg['roles']:
 package_source(x);o=registry['files'][x['original_index']];assert x['source_id']==o['source_id'] and x['sha256']==o['sha256'] and x['historical_material_ranges']==o['material_ranges'] and x['actual_EOF']==o['actual_line_count']
for name in ['native-support-registration.json','hash-routing-registration.json']:
 for x in json.loads((b/name).read_bytes())['sources']:package_source(x)
for rev,x in reg['locks'].items():
 raw=gzip.decompress((b/x['archive']).read_bytes());assert sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob'];packages={p['name']:p for p in tomllib.loads(raw.decode())['package'] if p['name'] in checks};assert len(packages)==2
 for name in checks:assert packages[name]['version']=='0.19.1' and packages[name]['checksum']==checks[name] and packages[name]['source']=='registry+https://github.com/rust-lang/crates.io-index'
for x in json.loads((b/'project-support-registration.json').read_bytes())['sources']:
 raw=(b/x['source_archive']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob'] and len(raw.splitlines())==x['actual_EOF']
sel=json.loads((b/'registry-selection-reconstructed.json').read_bytes())
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());qs=json.loads((b/'queue-selection-reconstructed.json').read_bytes());assert not qs['missing']
for x in qs['entries']:assert {k:v for k,v in x.items() if k!='original_queue_index'}==queue['entries'][x['original_queue_index']]
for x in original['original_059_records']:
 raw=(b/x['preserved_bytes']).read_bytes();o=tidx[x['original_path']];assert len(raw)==x['bytes']==o['bytes'] and sha(raw)==x['sha256']==o['sha256'] and oid('blob',raw)==x['git_blob']==o['git_blob']
for x in original['older_774_receipts']:
 raw=(b/x['preserved_bytes']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid('blob',raw)==x['git_blob']
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
proof=json.loads((b/'git-proofs.json').read_bytes());objects={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved_bytes']).read_bytes());assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==key;objects[key]=raw
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,step in zip(parts,x['path_chain']):
  assert step['tree']==cur and step['name']==name;mode,child=entries(objects[cur])[name];assert mode==step['mode'] and child==step['object'];cur=child
 raw=(b/x['preserved_bytes']).read_bytes();raw=gzip.decompress(raw) if x['compression']=='gzip' else raw;assert oid('blob',raw)==cur==x['git_blob'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']
assert len(proof['paths'])==14
scopes={};times=[]
for row in receipt['read_entries']:
 local=row['source'];raw=(b/local).read_bytes();raw=gzip.decompress(raw) if row.get('compression')=='gzip' else raw;assert sha(raw)==row['sha256'] and len(raw.splitlines())==row['actual_EOF'];d=json.loads((b/row['registration']).read_bytes());times.append(datetime.fromisoformat(d['registered_utc']));eof=row['actual_EOF'];assert all(1<=a<=z<=eof for a,z in row['displayed_chunks']);displayed={i for a,z in row['displayed_chunks'] for i in range(a,z+1)};scopes.setdefault(local,set()).update(displayed)
 def registered(obj):
  result=[]
  if isinstance(obj,dict):
   if local in (obj.get('source_archive'),obj.get('archive')):
    for key in ('registered_ranges','registered_personal_display_ranges'):
     if key in obj:result.extend(obj[key])
   for v in obj.values():result.extend(registered(v))
  elif isinstance(obj,list):
   for v in obj:result.extend(registered(v))
  return result
 allowed={i for a,z in registered(d) for i in range(a,z+1)};assert displayed<=allowed,(row['registration'],local)
 if local.startswith('source/') and row['registration']=='registration.json':
  source=next(x for x in reg['roles'] if x['source_archive']==local);assert row['displayed_chunks']==source['planned_chunks']
assert max(times)<datetime.fromisoformat(receipt['recorded_utc']) and receipt['registration_sha256']==sha((b/'registration.json').read_bytes())
for c in receipt['actual_assigned_coverage']:
 x=next(x for x in reg['roles'] if x['original_index']==c['original_role']);displayed=scopes[x['source_archive']];wanted={i for a,z in c['personal_display_union'] for i in range(a,z+1)};unread={i for a,z in c['personal_unread_complement'] for i in range(a,z+1)};assert displayed==wanted and displayed.isdisjoint(unread) and displayed|unread==set(range(1,x['actual_EOF']+1))
for x in report['findings']:
 for e in x['evidence']:
  assert e['file'] in scopes
  for a,z in e['lines']:assert set(range(a,z+1))<=scopes[e['file']],(e['file'],a,z)
names=['magic-strings','magic-numbers','type-ownership','existing-type-owners','type-granularity','invariant-operations','aggregate-states','admission-contracts','enum-shapes','redundant-authority','behavior-preservation','producer-propagation','derivability'];assert [x['lens'] for x in report['lenses']]==names
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Assigned pinned package objects match 059 registry, archive members and f82 source transport; both native archive checksums match 6533/95e lock entries.','Raw commit/tree chains prove project locks and bounded 95e support plus historical f82 records; transport is not project or package revision.','Original 059 records match transport manifest; selected historical registry and queue are labelled reconstructions; prior two delegate reports and receipts match their manifests.','Every personal source display and report citation is within its prospective registration; assigned readable unions and exact unread complements are checked, with thirteen bounded lenses.'],'scope':'Evidence and source scope only; no macro expansion, product execution, builds, tests, probes, simulations, repair or product validation.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw) if '--record' in sys.argv else None;print('PASS',sha(raw),'Git proofs',len(proof['paths']),'059 records',len(original['original_059_records']),'read entries',len(receipt['read_entries']))
