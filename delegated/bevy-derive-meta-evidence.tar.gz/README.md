# Bounded Bevy derive metadata source audit

This packet records a source-only audit of pinned registry roles 2569–2570:
`bevy_reflect_derive` 0.19.1 `derive_data.rs` and `container_attributes.rs`.
The preserved native archives are identified by registry checksums; their
package identity is distinct from project Git revision
`95e63628f9d70b8dd6e6fede64334696c6995009`.

`REPORT.json` describes scoped findings, thirteen lens perspectives, prior
record relationships, and open questions. Prospective registrations and
`personal-read-receipt.json` identify exact personal displays and unread
complements. Whole archived source bytes do not imply complete personal reads.
The original 774 and 059 records retain their authors and limitations; the
registry and queue selections are reconstructions. None is promoted to
checkpoint 3821. `git-proofs.json` contains raw commit/tree paths; f82 is
historical evidence transport, not a product or package revision.

Existing published baseline records are hash-linked in
`published-references.json`. The relevant selected prior delegate reports,
read receipts and manifests are preserved without duplicating their full
packets. Verify the evidence with:

```text
python3 verify-manifest.py
python3 verify-evidence.py /path/to/audit-baseline/publication
```

These checks cover evidence identity and source scopes only. No macro
expansion, compilation, product build, test, fixture, execution, runtime
probe, simulation, repair or product validation was performed.
