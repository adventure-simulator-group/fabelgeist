from pathlib import Path
import datetime,hashlib,json,tarfile
p=Path(__file__).resolve().parent;arch=p/'archives/bevy_reflect_derive-0.19.1.crate';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
with tarfile.open(arch,'r:gz') as t:
 for i,(path,ranges) in enumerate([('impls/common.rs',[[82,135]]),('impls/opaque.rs',[[20,50]])]):
  member='bevy_reflect_derive-0.19.1/src/'+path;b=t.extractfile(member).read();local=f'support/hash-route-{i}.rs';(p/local).write_bytes(b);rows.append({'package':'bevy_reflect_derive','version':'0.19.1','archive_member':member,'source_archive':local,'sha256':sha(b),'bytes':len(b),'actual_EOF':len(b.splitlines()),'registered_ranges':ranges,'purpose':'Bounded hash getter routing only, not assigned historical role credit.'})
r={'schema':'726-bevy-hash-routing-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','archive_sha256':sha(arch.read_bytes()),'sources':rows,'qualification':'Bounded native support, prior reviewers retain their personal reading and original roles.'};(p/'hash-routing-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((p/'hash-routing-registration.json').read_bytes()))
