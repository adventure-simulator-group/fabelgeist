use adventuresim_core::prelude::*;
use bevy::{ecs::system::SystemParam, prelude::*};
use bevy_enhanced_input::prelude::Actions;
use fabelgeist_determinism::StreamId;
use serde::{Deserialize, Serialize};

use crate::combat_config::AttackCurveConfig;
use crate::{
    animation::{AttackCurve, AttackHand, AttackSpec},
    inventory::{InventoryView, InventoryViewer},
};

pub use attack_timing::{attack_preparation_secs, attack_recovery_secs};
pub use combat_state::*;
pub use input_tick::PlayerInputTick;

mod attack_timing;
mod combat_state;
mod input_tick;

/// BEI Component alias to mark players that are controlled by the present client.
pub type ControlledPlayer = Actions<Player>;

/// Component for a player entity, for both client-controlled
/// active player and other players.
#[derive(Component, Serialize, Deserialize, Debug, Reflect, Clone, PartialEq, Eq)]
#[reflect(Component)]
#[require(
    CharacterId,
    CharacterDimensions,
    Limbs,
    Skills,
    TacticalAttributes,
    Stats,
    crate::animation::SkeletonState
)]
#[component(immutable)]
pub struct Player {
    pub name: String,
}

/// Anatomical measurements that affect authoritative tactical movement.
///
/// These values live beside the transient tactical character rather than in
/// presentation state so server physics and client prediction use the same
/// proportions. The default is measured from the current humanoid rig.
#[derive(Component, Serialize, Deserialize, Debug, Reflect, Clone, Copy, PartialEq)]
#[reflect(Component)]
pub struct CharacterDimensions {
    pub leg_length_metres: f32,
    pub body_height_metres: f32,
    /// Fully extended shoulder-to-hand length. The reference value is the
    /// `uparm -> lowarm -> wrist` chain measured from the authoritative MHR rig.
    pub arm_reach_metres: f32,
}

impl Default for CharacterDimensions {
    fn default() -> Self {
        Self {
            leg_length_metres: 0.840_348,
            body_height_metres: 1.9,
            arm_reach_metres: adventuresim_core::combat::HUMANOID_REFERENCE_ARM_REACH_METRES,
        }
    }
}

/// Transient tactical allegiance. This is authoritative on the tactical
/// server and replicated so clients can present enemy-only combat UI without
/// inferring allegiance from connectivity or local control.
#[derive(Component, Serialize, Deserialize, Debug, Reflect, Clone, Copy, PartialEq, Eq)]
#[reflect(Component)]
#[component(immutable)]
pub enum TacticalCombatSide {
    Party,
    Enemy,
}

pub fn default_tactical_character_id() -> u64 {
    adventuresim_core::starting_character::default_character("tactical").id
}

impl Default for Player {
    fn default() -> Self {
        Self {
            name: adventuresim_core::starting_character::default_character_name(),
        }
    }
}

/// Strategic character identity projected into the transient tactical world.
/// Network client identity remains a separate transport concern.
#[derive(
    Component,
    Serialize,
    Deserialize,
    Default,
    Debug,
    Reflect,
    Clone,
    Copy,
    PartialEq,
    Eq,
    PartialOrd,
    Ord,
    Hash,
)]
#[reflect(Component)]
#[component(immutable)]
pub struct CharacterId(pub u64);

impl CharacterId {
    /// Get associated color of this player.
    pub fn color(&self) -> Color {
        let mut random = StreamId::new("character.display-color").rng(self.0.into(), &[]);
        let hue = random.index(360) as f32;
        let saturation = 0.28 + random.inclusive_unit_f32() * 0.18;
        let value = 0.90 + random.inclusive_unit_f32() * 0.08;

        Color::hsv(hue, saturation, value)
    }
}

/// Creature families used to select the attacker's anatomical lore.
///
/// Current tactical characters are Human by default. Multi-category enemies
/// can provide every applicable category without changing combat resolution.
#[derive(Component, Serialize, Deserialize, Debug, Clone, PartialEq, Eq)]
#[component(immutable)]
pub struct BestiaryCategories(pub Vec<BestiaryCategory>);

impl Default for BestiaryCategories {
    fn default() -> Self {
        Self(vec![BestiaryCategory::Human])
    }
}

/// General player stats.
#[derive(Component, Serialize, Deserialize, Debug, Reflect, Clone, PartialEq)]
#[reflect(Component)]
pub struct Stats {
    pub calories_used: f32,
    pub focus: f32,
}

impl Default for Stats {
    fn default() -> Self {
        Self {
            calories_used: 0.0,
            focus: 1.0,
        }
    }
}

impl PlayerEssentials for Stats {
    // Fatigue and burden are already part of live combat incapacitation.
    fn physical_skill_condition_by_parts(
        &self,
        _attr: &impl PlayerAttributes,
        _body: &impl PlayerBody,
        _equipment: &impl PlayerEquipment,
    ) -> f32 {
        1.0
    }

    fn calories_used_today(&self) -> f32 {
        self.calories_used
    }

    fn focus_level(&self) -> f32 {
        self.focus
    }
}

/// Limb health status.
#[derive(Component, Serialize, Deserialize, Debug, Reflect, Clone, PartialEq)]
#[reflect(Component)]
pub struct Limbs {
    pub body_weight_kg: f32,
    pub left_arm: f32,
    pub right_arm: f32,
    pub left_leg: f32,
    pub right_leg: f32,
    pub chest: f32,
    pub stomach: f32,
    pub head: f32,
}

impl Default for Limbs {
    fn default() -> Self {
        Self {
            body_weight_kg: 70.0,
            left_arm: 1.0,
            right_arm: 1.0,
            left_leg: 1.0,
            right_leg: 1.0,
            chest: 1.0,
            stomach: 1.0,
            head: 1.0,
        }
    }
}

impl Limbs {
    pub fn health_mut(&mut self, part: BodyPart) -> &mut f32 {
        match part {
            BodyPart::LeftArm => &mut self.left_arm,
            BodyPart::RightArm => &mut self.right_arm,
            BodyPart::LeftLeg => &mut self.left_leg,
            BodyPart::RightLeg => &mut self.right_leg,
            BodyPart::Chest => &mut self.chest,
            BodyPart::Stomach => &mut self.stomach,
            BodyPart::Head => &mut self.head,
        }
    }
}

impl PlayerBody for Limbs {
    fn body_part_health(&self, part: BodyPart) -> f32 {
        match part {
            BodyPart::LeftArm => self.left_arm,
            BodyPart::RightArm => self.right_arm,
            BodyPart::LeftLeg => self.left_leg,
            BodyPart::RightLeg => self.right_leg,
            BodyPart::Chest => self.chest,
            BodyPart::Stomach => self.stomach,
            BodyPart::Head => self.head,
        }
    }

    fn body_weight(&self) -> f32 {
        self.body_weight_kg
    }

    fn primary_side(&self) -> BodySide {
        // TODO: this should be stored in DB ?
        BodySide::Right
    }
}

impl Limbs {
    /// Applies up to `damage` (0-1 scale) to `part`'s health, clamped to what
    /// remains, and returns how much was actually applied. Mirrors
    /// `CombatBody::apply_damage` in `adventuresim_core::autoresolve`.
    pub fn apply_damage(&mut self, part: BodyPart, damage: f32) -> f32 {
        let health = match part {
            BodyPart::LeftArm => &mut self.left_arm,
            BodyPart::RightArm => &mut self.right_arm,
            BodyPart::LeftLeg => &mut self.left_leg,
            BodyPart::RightLeg => &mut self.right_leg,
            BodyPart::Chest => &mut self.chest,
            BodyPart::Stomach => &mut self.stomach,
            BodyPart::Head => &mut self.head,
        };
        let applied = damage.max(0.0).min(health.max(0.0));
        *health = (*health - applied).max(0.0);
        applied
    }

    /// Aggregate health deficit across all body parts, used as the `pain`
    /// input to [`TacticalCombatState::incapacitation_sources`].
    pub fn total_damage(&self) -> f32 {
        [
            self.left_arm,
            self.right_arm,
            self.left_leg,
            self.right_leg,
            self.chest,
            self.stomach,
            self.head,
        ]
        .into_iter()
        .map(|health| (1.0 - health).max(0.0))
        .sum()
    }
}

/// Physical and mental skills of a [`Player`].
#[derive(Component, Serialize, Deserialize, Debug, Reflect, Clone, PartialEq)]
#[reflect(Component)]
#[component(immutable)]
pub struct Skills {
    pub polearm_hours: f32,
    pub axe_hours: f32,
    pub bludgeon_hours: f32,
    pub sword_hours: f32,
    pub knife_hours: f32,
    pub dodge_hours: f32,
    pub block_hours: f32,
    pub bow_hours: f32,
    pub crossbow_hours: f32,
    pub firearm_hours: f32,
    pub throw_hours: f32,
    pub will_hours: f32,
    pub insight_hours: f32,
    pub charm_hours: f32,
    pub command_hours: f32,
    pub deception_hours: f32,
    pub physiology_hours: f32,
    pub religion_hours: f32,
    pub bestiary_beast_hours: f32,
    pub bestiary_undead_hours: f32,
    pub bestiary_human_hours: f32,
    pub bestiary_werekin_hours: f32,
    pub bestiary_elf_hours: f32,
    pub bestiary_dwarf_hours: f32,
    pub bestiary_fey_hours: f32,
    pub bestiary_spirit_hours: f32,
    pub bestiary_greenskin_hours: f32,
    pub bestiary_insectoid_hours: f32,
    pub bestiary_draconid_hours: f32,
    pub bestiary_construct_hours: f32,
    pub bestiary_wildmen_hours: f32,
    pub surgery_hours: f32,
    pub stealth_hours: f32,
    pub balance_hours: f32,
    pub tailoring_hours: f32,
    pub smithing_hours: f32,
}

impl Default for Skills {
    fn default() -> Self {
        let default = adventuresim_core::starting_character::default_character("tactical");
        let skills = default.skills;
        Self {
            polearm_hours: skills.polearm,
            axe_hours: skills.axe,
            bludgeon_hours: skills.bludgeon,
            sword_hours: skills.sword,
            knife_hours: skills.knife,
            dodge_hours: skills.dodge,
            block_hours: skills.block,
            bow_hours: skills.bow,
            crossbow_hours: skills.crossbow,
            firearm_hours: skills.firearm,
            throw_hours: skills.throw,
            will_hours: skills.will,
            insight_hours: skills.insight,
            charm_hours: skills.charm,
            command_hours: skills.command,
            deception_hours: skills.deception,
            physiology_hours: skills.physiology,
            religion_hours: [
                skills.religion.roman_catholic,
                skills.religion.lutheran,
                skills.religion.reformed,
                skills.religion.anglican,
                skills.religion.eastern_orthodox,
                skills.religion.islamic,
                skills.religion.judaism,
            ]
            .into_iter()
            .sum(),
            bestiary_beast_hours: skills.bestiary.beast,
            bestiary_undead_hours: skills.bestiary.undead,
            bestiary_human_hours: skills.bestiary.human,
            bestiary_werekin_hours: skills.bestiary.werekin,
            bestiary_elf_hours: skills.bestiary.elf,
            bestiary_dwarf_hours: skills.bestiary.dwarf,
            bestiary_fey_hours: skills.bestiary.fey,
            bestiary_spirit_hours: skills.bestiary.spirit,
            bestiary_greenskin_hours: skills.bestiary.greenskin,
            bestiary_insectoid_hours: skills.bestiary.insectoid,
            bestiary_draconid_hours: skills.bestiary.draconid,
            bestiary_construct_hours: skills.bestiary.construct,
            bestiary_wildmen_hours: skills.bestiary.wildmen,
            surgery_hours: skills.surgery,
            stealth_hours: skills.stealth,
            balance_hours: skills.balance,
            tailoring_hours: skills.tailoring,
            smithing_hours: skills.smithing,
        }
    }
}

impl Skills {
    fn bestiary_hours(&self) -> BestiaryHours {
        BestiaryHours {
            beast: self.bestiary_beast_hours,
            undead: self.bestiary_undead_hours,
            human: self.bestiary_human_hours,
            werekin: self.bestiary_werekin_hours,
            elf: self.bestiary_elf_hours,
            dwarf: self.bestiary_dwarf_hours,
            fey: self.bestiary_fey_hours,
            spirit: self.bestiary_spirit_hours,
            greenskin: self.bestiary_greenskin_hours,
            insectoid: self.bestiary_insectoid_hours,
            draconid: self.bestiary_draconid_hours,
            construct: self.bestiary_construct_hours,
            wildmen: self.bestiary_wildmen_hours,
        }
    }
}

impl PlayerSkills for Skills {
    fn skill_hours_trained(&self, skill: Skill) -> f32 {
        match skill {
            Skill::Polearm => self.polearm_hours,
            Skill::Axe => self.axe_hours,
            Skill::Bludgeon => self.bludgeon_hours,
            Skill::Sword => self.sword_hours,
            Skill::Knife => self.knife_hours,
            Skill::Block => self.block_hours,
            Skill::Dodge => self.dodge_hours,
            Skill::Bow => self.bow_hours,
            Skill::Crossbow => self.crossbow_hours,
            Skill::Firearm => self.firearm_hours,
            Skill::Throw => self.throw_hours,
            Skill::Will => self.will_hours,
            Skill::Insight => self.insight_hours,
            Skill::Charm => self.charm_hours,
            Skill::Command => self.command_hours,
            Skill::Deception => self.deception_hours,
            Skill::Physiology => self.physiology_hours,
            Skill::Cooking => 0.0,
            Skill::Herbalism => 0.0,
            Skill::Religion => self.religion_hours,
            Skill::Bestiary => self.bestiary_hours().aggregate_effective(),
            Skill::Surgery => self.surgery_hours,
            Skill::Stealth => self.stealth_hours,
            Skill::Balance => self.balance_hours,
            Skill::TerrainPlains
            | Skill::TerrainForest
            | Skill::TerrainHills
            | Skill::TerrainWetlands
            | Skill::TerrainUrban
            | Skill::TerrainSnow => 0.0,
            Skill::Tailoring => self.tailoring_hours,
            Skill::Smithing => self.smithing_hours,
        }
    }

    fn bestiary_hours_for(&self, category: BestiaryCategory) -> f32 {
        self.bestiary_hours().effective(category)
    }
}

/// Genetic attributes of a [`Player`].
#[derive(Component, Serialize, Deserialize, Debug, Reflect, Clone, PartialEq, Deref, DerefMut)]
#[serde(transparent)]
#[reflect(opaque)]
#[reflect(Component, PartialEq, Clone, Serialize, Deserialize)]
#[component(immutable)]
pub struct TacticalAttributes(pub PlayerAttributeValues);

impl Default for TacticalAttributes {
    fn default() -> Self {
        let default = adventuresim_core::starting_character::default_character("tactical");
        let attributes = default.attributes;
        Self(PlayerAttributeValues {
            endurance: attributes.endurance,
            immunity: attributes.immunity,
            gut: attributes.gut,
            intelligence: attributes.intelligence,
            instinct: attributes.instinct,
            eyesight: attributes.eyesight,
            hearing: attributes.hearing,
            left_arm_strength: attributes.strength,
            right_arm_strength: attributes.strength,
            left_leg_strength: attributes.strength,
            right_leg_strength: attributes.strength,
            left_arm_agility: attributes.agility,
            right_arm_agility: attributes.agility,
            left_leg_agility: attributes.agility,
            right_leg_agility: attributes.agility,
        })
    }
}

impl From<PlayerAttributeValues> for TacticalAttributes {
    fn from(attributes: PlayerAttributeValues) -> Self {
        Self(attributes)
    }
}

impl PlayerAttributes for TacticalAttributes {
    fn raw_limb_attr(&self, attr: LimbAttribute, limb: BodyPart) -> f32 {
        self.0.raw_limb_attr(attr, limb)
    }

    fn raw_single_body_part_attr(&self, attr: SimpleAttribute) -> f32 {
        self.0.raw_single_body_part_attr(attr)
    }
}

pub type TacticalPlayerView<'v, 'w, 's> =
    PlayerInfo<&'v TacticalAttributes, &'v Limbs, &'v Stats, InventoryView<'v, 'w, 's>, &'v Skills>;

#[derive(SystemParam)]
pub struct TacticalPlayerViewer<'w, 's> {
    pub inventory: InventoryViewer<'w, 's>,
    pub q_player: Query<
        'w,
        's,
        (
            &'static Limbs,
            &'static Skills,
            &'static Stats,
            &'static TacticalAttributes,
        ),
    >,
}

impl TacticalPlayerViewer<'_, '_> {
    pub fn get(&self, entity: Entity) -> Result<TacticalPlayerView<'_, '_, '_>> {
        let (limbs, skills, stats, attributes) = self.q_player.get(entity)?;
        let inventory = self.inventory.get(entity);
        Ok(PlayerInfo::empty()
            .with_attributes(attributes)
            .with_body(limbs)
            .with_essentials(stats)
            .with_equipment(inventory)
            .with_skills(skills))
    }

    pub fn get_for_attack(
        &self,
        entity: Entity,
        hand: AttackHand,
    ) -> Result<TacticalPlayerView<'_, '_, '_>> {
        let (limbs, skills, stats, attributes) = self.q_player.get(entity)?;
        let inventory = self.inventory.get_for_attack(entity, hand);
        Ok(PlayerInfo::empty()
            .with_attributes(attributes)
            .with_body(limbs)
            .with_essentials(stats)
            .with_equipment(inventory)
            .with_skills(skills))
    }
}

/// Effective leaf-skill check used by attack handling. The weapon's authored
/// skill distribution is the single selector, including the shared unarmed
/// bludgeon fallback.
pub fn effective_weapon_handling_skill(view: &TacticalPlayerView<'_, '_, '_>) -> f32 {
    view.weapon_skill_distribution()
        .weighted_check(|skill| view.skill_check(skill, LimbWeights::all_equal()))
}

/// Applies the attacker's current equipment and skill to the replicated pose
/// curve. Player input and NPC behavior call this same function.
pub fn configure_attack_curve(
    mut spec: AttackSpec,
    view: &TacticalPlayerView<'_, '_, '_>,
    config: &AttackCurveConfig,
) -> AttackSpec {
    spec.curve = AttackCurve::from_handling_with_config(
        view.weapon_moment_of_inertia(),
        effective_weapon_handling_skill(view),
        config,
    );
    spec
}

#[cfg(test)]
mod tactical_combat_state_tests {
    use super::*;

    #[test]
    fn component_defaults_project_the_shared_historical_default() {
        let player = Player::default();
        let attributes = TacticalAttributes::default();
        let skills = Skills::default();
        assert_eq!(
            player.name,
            adventuresim_core::starting_character::default_character_name()
        );
        assert_eq!(attributes.endurance, 4.0);
        assert_eq!(attributes.left_arm_strength, 4.0);
        assert_eq!(attributes.right_leg_agility, 4.0);
        assert_eq!(attributes.intelligence, 3.0);
        assert_eq!(attributes.instinct, 3.0);
        assert_eq!(
            Skill::Insight.capped_training_rank(skills.insight_hours, &attributes),
            3.0
        );
        assert_eq!(
            Skill::Command.capped_training_rank(skills.command_hours, &attributes),
            3.0
        );
    }

    #[test]
    fn tactical_attributes_keep_the_flat_shared_boundary_shape() {
        let attributes = TacticalAttributes(PlayerAttributeValues {
            endurance: 1.0,
            hearing: 4.5,
            ..PlayerAttributeValues::default()
        });
        let wire = serde_json::to_value(&attributes).unwrap();
        assert_eq!(wire["endurance"], 1.0);
        assert_eq!(wire["hearing"], 4.5);
        assert!(wire.get("0").is_none());
        assert_eq!(
            serde_json::from_value::<TacticalAttributes>(wire).unwrap(),
            attributes
        );
    }

    #[test]
    fn wheel_sources_preserve_strategic_breakdown_and_recompute_live_values() {
        let state = TacticalCombatState {
            starting_incapacitation: 0.3,
            starting_blood_fraction: 0.85,
            starting_fear: 0.1,
            fatigue: 0.45,
            starting_hunger: 0.08,
            starting_thirst: 0.07,
            starting_thermal: 0.05,
            blood_loss_fraction: 0.15,
            imbalance: 0.2,
            ..default()
        };

        let sources = state.incapacitation_sources(0.0, 4.0);
        assert_eq!(sources.pain, 0.0);
        assert!((sources.blood_loss - 1.0).abs() < 0.0001);
        assert_eq!(sources.fear, 0.1);
        assert_eq!(sources.fatigue, 0.45);
        assert_eq!(sources.hunger, 0.08);
        assert_eq!(sources.thirst, 0.07);
        assert_eq!(sources.thermal, 0.05);
        assert_eq!(sources.imbalance, 0.2);
        assert!((sources.total() - 1.95).abs() < 0.0001);
        assert!(
            (sources.total()
                - combat_incapacitation(
                    state.starting_incapacitation,
                    state.starting_blood_fraction,
                    state.blood_loss_fraction,
                    0.0,
                    4.0,
                    state.imbalance,
                )
                - sources.fatigue)
                .abs()
                < 0.0001
        );
    }
}
