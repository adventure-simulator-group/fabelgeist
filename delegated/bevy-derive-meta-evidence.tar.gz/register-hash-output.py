from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for local,ranges in [('support/hash-route-0.rs',[[150,172]]),('support/hash-route-1.rs',[[112,131]])]:
 raw=(p/local).read_bytes();rows.append({'package':'bevy_reflect_derive','version':'0.19.1','source_archive':local,'sha256':sha(raw),'actual_EOF':len(raw.splitlines()),'registered_ranges':ranges})
r={'schema':'726-bevy-hash-output-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity','sources':rows,'qualification':'Separate bounded support confirming generated method injection; no product macro execution or role credit.'};(p/'hash-output-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((p/'hash-output-registration.json').read_bytes()))
