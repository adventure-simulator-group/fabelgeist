# Delegated shell solver audit

The central audit owns the authoritative baseline, reconciliation, role
statuses, ledger, review and publication. This packet covers original roles
2343–2346 and separately registered current support. Start with `report.json`.
The source assessment is bounded; it does not complete a lens or authorize
repairs.

`registration.json` and `read-receipt.json` distinguish the complete
historical and current personal reads. Exact bodies are archived separately
where byte-identical. Support registration and receipt record current bounded
support reads with no ordered-role credit. The earlier broad-phase and solve
views are separately preserved under `prior-support/`; they were support reads,
not retroactive ordered-role reads. Registration clocks were sampled before
writing, and actual registration file times were recorded before displays.
Git commit/tree objects and `git-proofs.json` prove each archived body's exact
membership in its stated revision.

`historical-059/` preserves original recovered records with their attribution,
ranges and revisions, checked against the original transport manifest. The
complete original registry and transport manifest are preserved compressed.
The complete 059 queue is retained as a separate compressed transport of its
original bytes; decompression restores the recorded SHA-256. Registry and queue
subset JSON files are derived navigation aids, not original records. The older
774 folder holds exact original and distinct path-normalized records, separately
verified against the export manifest. Historical topology prefix and tail reads
remain attributed to the people and scopes actually recorded. Nothing here
substitutes for the missing original checkpoint 3821 ledger or queue.

`check-evidence.py` verifies archived evidence only; its result is recorded in
`evidence-verification.json`. Test and shader source was read but never run. No
product repair, build, test, fixture, runtime probe, simulation, shader
compilation or execution, or product validation occurred. Some original records
contain local paths and require reviewed, documented redaction before
publication; preserve original and normalized hashes and provenance.
