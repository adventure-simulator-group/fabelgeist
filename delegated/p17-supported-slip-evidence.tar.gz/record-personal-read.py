import json,pathlib,datetime,hashlib
b=pathlib.Path('<LOCAL_PATH_0>');cur='95e63628f9d70b8dd6e6fede64334696c6995009';old='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696';a='crates/adventuresim-tactical-client/src/animation_viewer/';z='crates/adventuresim-tactical-client/src/animation/';core='crates/adventuresim-tactical-core/src/animation/'
scopes={
(old,a+'report/metrics/continuity.rs'):([[14,62]],[]),
(old,a+'report/observation.rs'):([[45,80],[160,176]],[]),
(old,a+'report/biomechanics_validation.rs'):([[29,44]],[]),
(old,core+'authored_angle.rs'):([[1,14],[90,107]],[]),
(old,core+'measurement.rs'):([[19,44],[99,110]],[]),
(cur,a+'capture.rs'):([[525,553],[624,658],[700,717],[727,743]],[]),
(cur,a+'capture/admission.rs'):([[67,115]],[]),
(cur,a+'capture/root_motion.rs'):([[18,48]],[]),
(cur,a+'report/metrics.rs'):([[119,153],[176,198],[245,258],[950,990],[1003,1041],[1058,1100],[1125,1145]],[300,302,312,313,314,315,320,321,322,323,802,803,824,832,951,952,975,1026,1028,1063,1079,1080,1133,1195,1197,1291,1334,1335,1345,1346,1509,1510,1520,1521,1759,1779,1780,1821,1830,1841,1849,1855,1885,1890,1895,1896]),
(cur,a+'report/validation.rs'):([[1,24],[456,466],[595,605],[640,686]],[]),
(cur,a+'report/model.rs'):([[125,155],[158,168],[200,240],[245,253],[285,298]],[164,218,229,248]),
(cur,a+'report/mod.rs'):([[85,111]],[]),
(cur,a+'report/bones.rs'):([[1,24]],[]),
(cur,core+'measurement.rs'):([[17,44],[96,107]],[]),
(cur,core+'authored_angle.rs'):([[1,14],[75,96]],[]),
(cur,z+'procedural.rs'):([[88,114]],[103]),
(cur,z+'procedural/ik/state.rs'):([[190,210],[440,465]],[84,85,195,203,204,269,270,358,363,416,417,444,461,462]),
(cur,z+'procedural/ik/locomotion.rs'):([[66,118],[285,314]],[87,308,309]),
(cur,z+'procedural/ik/raised_footwork.rs'):([[14,34],[66,81],[124,144],[168,186]],[22,25,26,76,138,139,179]),
(cur,'crates/AGENTS.md'):([[21,86],[123,153],[182,192]],[]),
(cur,z+'AGENTS.md'):([[1,19],[76,88]],[]),
(cur,'crates/adventuresim-tactical-core/AGENTS.md'):([[1,17]],[]),
}
entries=[]
for name in ['support-registration.json','support2-registration.json','support3-registration.json','rules-registration.json']:
 for e in json.load(open(b/name))['entries']:
  displayed,snips=scopes[(e['revision'],e['path'])];n=e['actual_line_count'];covered={j for lo,hi in displayed for j in range(lo,hi+1)};missing=[];start=None
  for i in range(1,n+2):
   if i<=n and i not in covered:
    if start is None:start=i
   elif start is not None:missing.append([start,i-1]);start=None
  entries.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'actual_eof':n,'contiguously_displayed_body_ranges':displayed,'search_result_lines_outside_body_ranges':sorted(set(snips)-covered),'not_contiguously_displayed_ranges':missing,'scope':'Bounded support/rule only; search-result lines do not expand full body coverage. Every listed unread range includes possible search snippets.'})
r={'schema':'726-p17-supported-slip-personal-display-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','assigned_personal_reads':[{'revision':old,'role':2460,'ranges':[[1,47]],'basis':'old-registration.json before display'},{'revision':cur,'role':2460,'ranges':[[1,55]],'basis':'current-registration.json before display'}],'support_personal_reads':entries,'prior_personal_scope':'Prior-facing packet is separately retained; old/current role bodies were then support only, not prior assigned-role credit.','historical_reviewers':'Original attribution and related 059 receipts retain original revision, reader and scope.','execution':'Source display/search and evidence verification only. No product execution, build, test, viewer, probe, fixture or repair.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'personal-read-receipt.json').write_bytes(raw);print('receipt',hashlib.sha256(raw).hexdigest(),'support',len(entries))
