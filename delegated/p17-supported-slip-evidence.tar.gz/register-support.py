from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');p='crates/adventuresim-tactical-client/src/animation_viewer/';core='crates/adventuresim-tactical-core/src/animation/';old='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696';cur='95e63628f9d70b8dd6e6fede64334696c6995009';plan={old:[p+'report/metrics/continuity.rs',p+'report/observation.rs',p+'report/biomechanics_validation.rs',core+'authored_angle.rs',core+'measurement.rs'],cur:[p+'capture.rs',p+'capture/admission.rs',p+'capture/root_motion.rs',p+'report/metrics.rs',p+'report/validation.rs',p+'report/model.rs',p+'report/mod.rs',p+'report/bones.rs',core+'measurement.rs']};entries=[];pending=[]
for rev,paths in plan.items():
 for path in paths:
  raw=subprocess.check_output(['git','show',rev+':'+path]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+path],text=True).strip();entries.append({'revision':rev,'path':path,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_maximum_range':[1,len(raw.splitlines())],'scope':'bounded connected producer/report/checked-value support only; no original role credit'});pending.append((rev,path,raw))
r={'schema':'726-p17-supported-slip-prospective-support-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','purpose':'Trace support-weight authority, bone/source/rotation admission and final consumers in distinct revisions; no source or product mutation.','entries':entries};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for rev,path,raw in pending:
 d=b/'support'/rev[:4]/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support SHA',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
