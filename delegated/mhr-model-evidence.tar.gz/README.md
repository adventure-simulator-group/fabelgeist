# Delegated MHR model and corrective source audit

The central audit owns baseline, reconciliation, the repair ledger, role
statuses, and publication. This bundle covers original roles 2319–2322 and
separately registered support. Start with `report.json`.

`registration.json` and `read-receipt.json` distinguish the prospectively
registered personal reads of 95e and 6533. Support registrations and receipts
show the bounded source reads and grant no original ordered-role credit. The
registration time is a UTC clock sample before the write; filesystem write
completion is separately recorded before each subsequent display.

`git-proofs.json` and `git-objects/` preserve commit and tree membership for
all exact source bodies. `historical-059/` contains original extraction records
verified against the 059 transport manifest. `older-774/` contains historical
original supplier records verified against their earlier export manifest;
two path-normalized exports are separately preserved and labeled. Their
revision and provenance must not be promoted into checkpoint 3821.

`evidence-verification.json` records evidence-only checks. No product source
was changed, and no product builds, tests, probes, fixtures or validation ran.
Original records may include local paths and require reviewed, documented
redaction before publication while preserving original and export hashes.
