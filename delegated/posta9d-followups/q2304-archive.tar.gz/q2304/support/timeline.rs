//! Action timing coordinates and nonnegative phase intervals.

use super::*;

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub(super) struct ActionTimeline {
    pub(super) start_tick: AnimationSampleTick,
    pub(super) preparation_ticks: AnimationSampleSpan,
    pub(super) recovery_ticks: AnimationSampleSpan,
    #[serde(deserialize_with = "crate::animation::pose_coordinates::deserialize_progress")]
    pub(super) phase: UnitInterval,
}

pub(super) enum ActionTimelineSample {
    Complete,
    Active(UnitInterval),
}

impl ActionTimeline {
    pub(super) fn new(start_tick: AnimationSampleTick, contact_tick: AnimationSampleTick) -> Self {
        let preparation_ticks = contact_tick
            .saturating_sub(start_tick)
            .max(AnimationSampleSpan::ONE);
        Self {
            start_tick,
            preparation_ticks,
            recovery_ticks: preparation_ticks,
            phase: UnitInterval::ZERO,
        }
    }

    pub(super) fn with_recovery(
        start_tick: AnimationSampleTick,
        contact_tick: AnimationSampleTick,
        end_tick: AnimationSampleTick,
    ) -> Self {
        Self {
            start_tick,
            preparation_ticks: contact_tick
                .saturating_sub(start_tick)
                .max(AnimationSampleSpan::ONE),
            recovery_ticks: end_tick
                .saturating_sub(contact_tick)
                .max(AnimationSampleSpan::ONE),
            phase: UnitInterval::ZERO,
        }
    }

    pub(super) fn normalized(mut self) -> Self {
        self.preparation_ticks = self.preparation_ticks.max(AnimationSampleSpan::ONE);
        self.recovery_ticks = self.recovery_ticks.max(AnimationSampleSpan::ONE);
        self
    }

    pub(super) fn contact_tick(self) -> AnimationSampleTick {
        self.start_tick.saturating_add(self.preparation_ticks)
    }

    pub(super) fn end_tick(self) -> AnimationSampleTick {
        self.contact_tick().saturating_add(self.recovery_ticks)
    }
    /// Keep the existing saturated deadlines and integer-before-float ratios.
    pub(super) fn sample(
        self,
        current_tick: AnimationSampleTick,
    ) -> AnimationValueResult<ActionTimelineSample> {
        let preparation = self.preparation_ticks.max(AnimationSampleSpan::ONE);
        let recovery = self.recovery_ticks.max(AnimationSampleSpan::ONE);
        let contact_tick = self.start_tick.saturating_add(preparation);
        let end_tick = contact_tick.saturating_add(recovery);
        if current_tick >= end_tick {
            return Ok(
                if current_tick > end_tick || end_tick == AnimationSampleTick::MAX {
                    ActionTimelineSample::Complete
                } else {
                    ActionTimelineSample::Active(UnitInterval::ONE)
                },
            );
        }
        let phase = UnitInterval::from_fraction(if current_tick <= contact_tick {
            0.5 * current_tick.saturating_sub(self.start_tick).samples() as f32
                / preparation.samples() as f32
        } else {
            0.5 + 0.5 * current_tick.saturating_sub(contact_tick).samples() as f32
                / recovery.samples() as f32
        })?;
        Ok(ActionTimelineSample::Active(phase))
    }
}
