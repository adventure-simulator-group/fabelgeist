import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=p/'historical-059';H=lambda b:hashlib.sha256(b).hexdigest()
def check(n,sha):
 n=n.replace('\\','/').removeprefix('target/726-audit-adler-20261027/');assert H((h/n).read_bytes())==sha,n
x=json.loads((h/'segovb/READ-L11-420.json').read_text());rows=[r for r in x['sources'] if r['original_index'] in [2540,2541]];assert len(rows)==2
for r in rows:check(r['registration'],r['registration_sha256'])
x=json.loads((h/'segovb/READ-L12-862.json').read_text());check(x['proposal'],x['proposal_sha256']);assert not x['root_personal_rereads'];rows=[r for r in x['rows'] if r.get('original_index') in [2540,2541]];assert len(rows)==2
for r in rows:check(r['registration'],r['registration_sha256'])
adopt=json.loads((h/'segovb/READ-L12-CONNECTED-TEAM-019.json').read_text());check(adopt['bundle']['path'],adopt['bundle']['sha256'])
for entry in adopt['immutable_delegated_receipts']:
 check(entry['path'],entry['sha256'])
 receipt=json.loads((h/entry['path']).read_text())
 for row in receipt.get('rows',[]):check(row['registration'],row['registration_sha256'])
verify=json.loads((h/'segovb/VERIFY-L12-CONNECTED-TEAM-019.json').read_text());check('segovb/READ-L12-CONNECTED-TEAM-019.json',verify['receipt_sha256'])
prior=json.loads((p/'prior-references.json').read_text());count=0
for x in prior['packets']:
 a=pathlib.Path(x['prior_location']);m=a/'BUNDLE-MANIFEST.json';assert H(m.read_bytes())==x['manifest_sha256'];rows={v['path']:v for v in json.loads(m.read_text())['files']}
 for y in x['copies']:
  q=p/y['path'];assert H(q.read_bytes())==y['sha256'];name=q.name
  if name!='BUNDLE-MANIFEST.json':assert rows[name]['sha256']==y['sha256']
  count+=1
result={'schema':'726-evidence-link-verification-v1','status':'passed','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'059 L11 fresh personal and L12 delegated registration, proposal, all six connected receipts, each referenced registration, connected root adoption/verification hashes, plus exact copied report/manifest links to prior packets.','prior_record_copies':count,'qualification':'Prior full packets not embedded and must remain available or be separately published. Evidence-only verification, no product/runtime validation.'};(p/'evidence-links-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
