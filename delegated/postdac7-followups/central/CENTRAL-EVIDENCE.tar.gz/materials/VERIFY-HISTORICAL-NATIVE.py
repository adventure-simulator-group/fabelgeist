from pathlib import Path
import hashlib,io,json,subprocess,tarfile,tomllib
p=Path(__file__).resolve().parent
reg=json.loads((p/"HISTORICAL-REGISTRATION.json").read_bytes());cap=json.loads((p/"HISTORICAL-CAPTURE.json").read_bytes());raw=(p/"historical-materials.source").read_bytes();lines=raw.decode().splitlines(keepends=True)
assert len(lines)==35 and hashlib.sha256(raw).hexdigest()==cap["source_sha256"]
for rev in [reg["revision"],"e2755a732c84e67296b5e3441a4259a84f461b2f"]:
 oid=subprocess.check_output(["git","rev-parse",rev+":"+reg["path"]],text=True).strip();assert oid==cap["git_blob_6533_and_e275"] and subprocess.check_output(["git","cat-file","blob",oid])==raw
display=(p/"historical-materials-1-35.txt").read_bytes();assert display=="".join(f"{i}: {s}" for i,s in enumerate(lines,1)).encode() and hashlib.sha256(display).hexdigest()==cap["display_sha256"]
nreg=json.loads((p/"NATIVE-REGISTRATION.json").read_bytes());ncap=json.loads((p/"NATIVE-CAPTURE.json").read_bytes());lock=subprocess.check_output(["git","show",nreg["revision"]+":Cargo.lock"]);assert hashlib.sha256(lock).hexdigest()==ncap["lockfile_sha256"];packages=tomllib.loads(lock.decode())["package"]
with tarfile.open(nreg["outer_public_packet"],"r:gz") as outer:
 for row,plan in zip(ncap["rows"],nreg["planned"]):
  assert (row["label"],row["crate"],row["source"])==(plan["label"],plan["crate"],plan["source"])
  pkg=[x for x in packages if x["name"]==row["crate"] and x["version"]==row["version"]];assert len(pkg)==1
  archive=outer.extractfile("NATIVE-"+row["crate"]+".crate").read();assert hashlib.sha256(archive).hexdigest()==pkg[0]["checksum"]==row["archive_sha256"]
  with tarfile.open(fileobj=io.BytesIO(archive),mode="r:gz") as inner:raw=inner.extractfile(row["crate"]+"-"+row["version"]+"/"+row["source"]).read()
  assert raw==outer.extractfile(plan["outer_source"]).read()==(p/(row["label"]+".source")).read_bytes() and hashlib.sha256(raw).hexdigest()==row["source_sha256"]
  lines=raw.decode().splitlines(keepends=True);assert len(lines)==row["source_lines"]
  for d in row["displays"]:
   actual=(p/d["file"]).read_bytes();assert actual=="".join(f"{i}: {lines[i-1]}" for i in range(d["start"],d["end"]+1)).encode() and hashlib.sha256(actual).hexdigest()==d["sha256"]
print("Verified historical per-file Git identities and three Cargo.lock-matched native source displays; no runtime behavior inferred.")
