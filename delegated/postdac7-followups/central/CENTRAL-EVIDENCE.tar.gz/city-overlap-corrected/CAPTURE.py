from pathlib import Path
import subprocess,hashlib,json,datetime
p=Path(__file__).resolve().parent
revision="95e63628f9d70b8dd6e6fede64334696c6995009"
plan=[('request', 'crates/strategic-web/static/regional-city-request.js', [(1, 99)]), ('wasm', 'crates/adventuresim-tactical-client/src/presentation/generation/wasm.rs', [(20, 46)]), ('ownership', 'crates/adventuresim-tactical-client/src/presentation/generation/ownership.rs', [(195, 225), (240, 275)])]
reg={"revision":revision,"reviewer":"/root","purpose":"Selected central corroboration of q2773 conditional cross-request city attribution; no foreign lens credit","registered_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"planned":[{"label":n,"path":s,"ranges":r} for n,s,r in plan]}
with (p/"REGISTRATION.json").open("x") as f:json.dump(reg,f,indent=2);f.write("\n")
rows=[]
for n,path,ranges in plan:
 oid=subprocess.check_output(["git","rev-parse",revision+":"+path],text=True).strip();body=subprocess.check_output(["git","cat-file","blob",oid]);lines=body.decode("utf-8").splitlines(keepends=True)
 with (p/(n+".source")).open("xb") as f:f.write(body)
 ds=[]
 for start,end in ranges:
  assert 1<=start<=end<=len(lines)
  name=f"{n}-{start}-{end}.txt";data="".join(f"{i}: {lines[i-1]}" for i in range(start,end+1)).encode()
  with (p/name).open("xb") as f:f.write(data)
  ds.append({"file":name,"start":start,"end":end,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)})
 rows.append({"label":n,"path":path,"git_blob":oid,"source_sha256":hashlib.sha256(body).hexdigest(),"source_bytes":len(body),"line_count":len(lines),"displays":ds})
with (p/"CAPTURE.json").open("x") as f:json.dump({"revision":revision,"rows":rows,"qualification":"Prospective source capture and numbered displays; unread captured complements do not establish personal reading. No product execution."},f,indent=2);f.write("\n")
print("Registered",len(rows),"files and",sum(len(x["displays"]) for x in rows),"ranges")
