from pathlib import Path
import json,hashlib,subprocess
p=Path(__file__).resolve().parent;r=json.loads((p/"GUIDE-REGISTRATION.json").read_bytes());c=json.loads((p/"GUIDE-CAPTURE.json").read_bytes());body=(p/"guide.source").read_bytes()
assert hashlib.sha256(body).hexdigest()==c["source_sha256"]
assert subprocess.check_output(["git","rev-parse",r["revision"]+":"+r["path"]],text=True).strip()==c["git_blob"]
assert subprocess.check_output(["git","cat-file","blob",c["git_blob"]])==body
lines=body.decode().splitlines(keepends=True);d=(p/"guide-112-127.txt").read_bytes()
assert d=="".join(f"{i}: {lines[i-1]}" for i in range(112,128)).encode() and hashlib.sha256(d).hexdigest()==c["display_sha256"]
print("Guide blob and selected display verified; no product execution.")
