from pathlib import Path
import subprocess,hashlib,json,datetime
p=Path(__file__).resolve().parent
revision="95e63628f9d70b8dd6e6fede64334696c6995009"
plan=[('prepared', 'crates/adventuresim-tactical-client/src/presentation/buildings/prepared.rs', [(1, 54)]), ('buildings', 'crates/adventuresim-tactical-client/src/presentation/buildings.rs', [(145, 192), (230, 275)]), ('venue', 'crates/adventuresim-tactical-client/src/presentation/generation/venue.rs', [(51, 161)]), ('installation', 'crates/adventuresim-tactical-client/src/presentation/generation/installation.rs', [(20, 31)]), ('worker', 'crates/adventuresim-tactical-client/src/presentation/generation/worker_products.rs', [(24, 65)]), ('stream', 'crates/adventuresim-tactical-client/src/presentation/buildings/streaming.rs', [(1, 96), (97, 175), (176, 272)]), ('demo', 'crates/adventuresim-tactical-client/src/art_demo.rs', [(244, 307)]), ('city', 'crates/adventuresim-tactical-client/src/presentation/regional_map/city.rs', [(25, 81), (234, 283)]), ('city-install', 'crates/adventuresim-tactical-client/src/presentation/regional_map/city/installation.rs', [(11, 41), (81, 114)]), ('status', 'crates/adventuresim-tactical-client/src/presentation/regional_map/status.rs', [(20, 43), (160, 176)]), ('browser', 'crates/strategic-web/static/regional-city-installation.js', [(1, 35)])]
reg={"revision":revision,"reviewer":"/root","purpose":"Selected central corroboration of q2760 and q2773 prepared and streaming relationships; no foreign lens credit","registered_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"planned":[{"label":n,"path":s,"ranges":r} for n,s,r in plan]}
with (p/"REGISTRATION.json").open("x") as f:json.dump(reg,f,indent=2);f.write("\n")
rows=[]
for n,path,ranges in plan:
 oid=subprocess.check_output(["git","rev-parse",revision+":"+path],text=True).strip();body=subprocess.check_output(["git","cat-file","blob",oid]);lines=body.decode("utf-8").splitlines(keepends=True)
 with (p/(n+".source")).open("xb") as f:f.write(body)
 ds=[]
 for start,end in ranges:
  assert 1<=start<=end<=len(lines)
  name=f"{n}-{start}-{end}.txt";data="".join(f"{i}: {lines[i-1]}" for i in range(start,end+1)).encode()
  with (p/name).open("xb") as f:f.write(data)
  ds.append({"file":name,"start":start,"end":end,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)})
 rows.append({"label":n,"path":path,"git_blob":oid,"source_sha256":hashlib.sha256(body).hexdigest(),"source_bytes":len(body),"line_count":len(lines),"displays":ds})
with (p/"CAPTURE.json").open("x") as f:json.dump({"revision":revision,"rows":rows,"qualification":"Prospective source capture and numbered displays; unread captured complements do not establish personal reading. No product execution."},f,indent=2);f.write("\n")
print("Registered",len(rows),"files and",sum(len(x["displays"]) for x in rows),"ranges")
