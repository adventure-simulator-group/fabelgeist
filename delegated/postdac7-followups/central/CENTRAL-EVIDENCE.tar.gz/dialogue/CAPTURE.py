from pathlib import Path
import subprocess,hashlib,json,datetime
p=Path(__file__).resolve().parent
revision="95e63628f9d70b8dd6e6fede64334696c6995009"
plan=[("bindings","crates/adventuresim-stdb-module/src/strategic/dialogue_bindings.rs",[(75,213),(216,267),(852,940)]),("prompts","crates/adventuresim-stdb-module/src/strategic/dialogue_prompts.rs",[(115,148),(222,245),(430,535)]),("social","crates/adventuresim-stdb-module/src/social.rs",[(911,960)]),("web","crates/strategic-web/src/routes/dialogue.rs",[(1366,1418)]),("claims","crates/strategic-web/src/routes/dialogue/claims.rs",[(1,26)]),("lib","crates/adventuresim-dialogue/src/lib.rs",[(663,686),(711,735)]),("build","crates/adventuresim-dialogue/build.rs",[(348,375)]),("effects","crates/adventuresim-stdb-module/src/strategic/dialogue_effects.rs",[(300,397),(404,535)])]
reg={"revision":revision,"reviewer":"/root","purpose":"Selected central corroboration of q2721 aggregate relationships; no foreign lens credit","registered_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"planned":[{"label":n,"path":s,"ranges":r} for n,s,r in plan]}
with (p/"REGISTRATION.json").open("x") as f:json.dump(reg,f,indent=2);f.write("\n")
rows=[]
for n,path,ranges in plan:
 oid=subprocess.check_output(["git","rev-parse",revision+":"+path],text=True).strip();body=subprocess.check_output(["git","cat-file","blob",oid]);lines=body.decode("utf-8").splitlines(keepends=True)
 with (p/(n+".source")).open("xb") as f:f.write(body)
 ds=[]
 for start,end in ranges:
  assert 1<=start<=end<=len(lines)
  name=f"{n}-{start}-{end}.txt";data="".join(f"{i}: {lines[i-1]}" for i in range(start,end+1)).encode()
  with (p/name).open("xb") as f:f.write(data)
  ds.append({"file":name,"start":start,"end":end,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)})
 rows.append({"label":n,"path":path,"git_blob":oid,"source_sha256":hashlib.sha256(body).hexdigest(),"source_bytes":len(body),"line_count":len(lines),"displays":ds})
with (p/"CAPTURE.json").open("x") as f:json.dump({"revision":revision,"rows":rows,"qualification":"Prospective source capture and numbered displays; unread captured complements do not establish personal reading. No product execution."},f,indent=2);f.write("\n")
print("Registered",len(rows),"files and",sum(len(x["displays"]) for x in rows),"ranges")
