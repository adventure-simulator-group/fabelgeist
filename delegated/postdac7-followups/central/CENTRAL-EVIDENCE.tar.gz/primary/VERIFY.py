from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent
c=json.loads((p/"CAPTURE.json").read_bytes());r=json.loads((p/"REGISTRATION.json").read_bytes());v=json.loads((p/"READ-RECEIPT.json").read_bytes())
assert c["revision"]==r["revision"]==v["revision"]=="95e63628f9d70b8dd6e6fede64334696c6995009"
assert len(c["rows"])==len(r["planned"])==10
for a,b in zip(c["rows"],r["planned"]):
 assert (a["label"],a["path"])==(b["label"],b["path"])
 raw=(p/(a["label"]+".source")).read_bytes();lines=raw.decode().splitlines(keepends=True)
 assert len(raw)==a["source_bytes"] and len(lines)==a["line_count"] and hashlib.sha256(raw).hexdigest()==a["source_sha256"]
 assert subprocess.check_output(["git","rev-parse",c["revision"]+":"+a["path"]],text=True).strip()==a["git_blob"]
 assert subprocess.check_output(["git","cat-file","blob",a["git_blob"]])==raw
 assert [(d["start"],d["end"]) for d in a["displays"]]==[tuple(x) for x in b["ranges"]]
 for d in a["displays"]:
  expected="".join(f"{i}: {lines[i-1]}" for i in range(d["start"],d["end"]+1)).encode();actual=(p/d["file"]).read_bytes()
  assert actual==expected and len(actual)==d["bytes"] and hashlib.sha256(actual).hexdigest()==d["sha256"]
assert v["displayed_ranges"]==sum(len(a["displays"]) for a in c["rows"])
assert v["displayed_lines"]==sum(d["end"]-d["start"]+1 for a in c["rows"] for d in a["displays"])
print("Verified",len(c["rows"]),"pinned files,",v["displayed_ranges"],"displays,",v["displayed_lines"],"lines; source evidence only.")
