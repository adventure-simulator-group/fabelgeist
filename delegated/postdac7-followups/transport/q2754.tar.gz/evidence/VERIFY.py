#!/usr/bin/env python3
"""Evidence-only q2754 verification; does not execute product code or tests."""
import argparse,hashlib,io,json,os,pathlib,subprocess,tarfile
P=pathlib.Path(__file__).resolve().parent
A=argparse.ArgumentParser();A.add_argument('--git-checkout',help='Read-only evidence checkout holding pinned Git objects');A.add_argument('--key-file',help='Optional privately held original-evidence AES-GCM key');a=A.parse_args()
def need(x,msg):
 if not x:raise SystemExit('FAIL '+msg)
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((P/'PUBLIC-MANIFEST.json').read_text())
for row in m['files']:
 f=P/row['name'];need(f.is_file() and not f.is_symlink(),'missing artifact '+row['name']);d=f.read_bytes();need(len(d)==row['bytes'] and sha(d)==row['sha256'],'artifact identity '+row['name'])
main=(P/'SOURCE-95e6.dat').read_bytes();need(sha(main)=='93f6d71ef4483adfa946c8c19da9692b9843eb84629a32210c1652a3978b3e4d','assigned source sha')
need(main==(P/'SOURCE-6533.dat').read_bytes()==(P/'SOURCE-e275.dat').read_bytes(),'captured historical source equality')
for i in (2754,2760):need(json.loads((P/('Q'+str(i)+'-OBJECT.json')).read_text())==json.loads((P/('Q'+str(i)+'-56F-RESERIALIZED.json')).read_text()),'selected historical/reconstructed queue equality')
print('PASS public packet byte identities and captured source/selected-record equality')
if a.git_checkout:
 env=dict(os.environ,GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
 def git(*args):return subprocess.run(['git','-C',a.git_checkout,*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,check=True).stdout
 rev='95e63628f9d70b8dd6e6fede64334696c6995009';source='crates/adventuresim-tactical-client/src/presentation/buildings/prepared.rs'
 need(git('rev-parse',rev+'^{tree}').decode().strip()=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','95e tree')
 for version,name in [('6533e444fa37552927070cc8d8190907fd3b413e','SOURCE-6533.dat'),('e2755a732c84e67296b5e3441a4259a84f461b2f','SOURCE-e275.dat'),(rev,'SOURCE-95e6.dat')]:need(git('show',version+':'+source)==(P/name).read_bytes(),'assigned Git blob')
 for row in json.loads((P/'CONNECTED-SOURCE-CAPTURES.json').read_text()):
  if row['status']=='captured':need(git('show',rev+':'+row['path'])==(P/row['artifact']).read_bytes(),'connected Git blob')
 for i,row in enumerate(json.loads((P/'DOMAIN-OWNERS-CAPTURES.json').read_text())):need(git('show',rev+':'+row['path'])==(P/('DOMAIN-OWNER-'+str(i)+'.dat')).read_bytes(),'domain Git blob')
 for i,row in enumerate(json.loads((P/'IDENTITY-CONSUMERS-CAPTURE.json').read_text())):need(git('show',rev+':'+row['path'])==(P/('IDENTITY-CONSUMER-'+str(i)+'.dat')).read_bytes(),'identity Git blob')
 old=git('show','56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e:baseline-059/queue.json');new=git('show','0a2466a7485388575ef272e0a8355b9714204a37:baseline-059/queue.json')
 need(sha(old)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(new)=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173','whole 059 queue identities')
 x=json.loads(old)['entries'];y=json.loads(new)['entries']
 for i in (2357,2703,2754,2760):need(x[i]==y[i],'selected 059 record equality')
 for i in (2754,2760):need(x[i]==json.loads((P/('Q'+str(i)+'-56F-RESERIALIZED.json')).read_text()),'selected record provenance')
 head='dac7d0055716053f245139971eb67ddfd87fa462';base=git('show',head+':BASELINE-95E-20261110.json');need(sha(base)=='842c3eabfaa1811441dc48461f21157e3f0e3ffc6df2f939e55ba6baa42cfa98','newer ledger identity')
 need(json.loads(base)['newly_assessed_ledger']['entries'][1080]==json.loads((P/'HEAD-DAC-RELATED-RESULT.json').read_text())['ledger_entry'],'related ledger row')
 q=git('show',head+':delegated/post0a24-followups/transport/q2760/q2760-evidence.tar.gz');need(sha(q)=='f22bc4586aea886bfddf0a62a8ac1a6c4098ae36bf8782022dd66f0dd0f71805','q2760 published transport')
 with tarfile.open(fileobj=io.BytesIO(q),mode='r:gz') as tar:
  need(tar.extractfile('REPORT.json').read()==(P/'Q2760-REPORT-0.dat').read_bytes(),'q2760 prior report');need(tar.extractfile('PRIOR-Q2357-REPORT.json').read()==(P/'Q2760-REPORT-1.dat').read_bytes(),'q2357 prior report')
 print('PASS Git-bound 95e source, distinct 56f/0a queues, dac7d ledger and prior transport')
else:print('NOT CHECKED: external Git commit binding, original/reconstructed queues and current ledger')
if a.key_file:
 from cryptography.hazmat.primitives.ciphers.aead import AESGCM
 key=pathlib.Path(a.key_file).read_bytes();blob=(P/'PRIVATE-ORIGINALS.aesgcm').read_bytes();magic=b'Q2754-AESGCM-1\0';need(blob.startswith(magic),'encrypted evidence format');off=len(magic);plain=AESGCM(key).decrypt(blob[off:off+12],blob[off+12:],b'q2754-private-evidence-v1')
 with tarfile.open(fileobj=io.BytesIO(plain),mode='r:') as tar:
  inv=json.loads(tar.extractfile('PRIVATE-MANIFEST.json').read())
  for row in inv['files']:
   d=tar.extractfile(row['name']).read();need(len(d)==row['bytes'] and sha(d)==row['sha256'],'private original identity')
  expected={'HISTORY-ORIGINAL-0.dat':'2be9d1af44d30dfc41a774c64ca4264d069911f690a7fed59be34216e9ccf3a4','HISTORY-ORIGINAL-1.dat':'13a4d7bf9ed68e216a1fa8cb3cb0204738e60a072031b00b116475c412c32a59','HISTORY-ORIGINAL-2.dat':'63ae82897ddd07946ba1ff8210b42ca49b45a01886bdcdc5c0656bcb0408d1a0','L11-HISTORY-0.dat':'513cc320bbeb295c27f33805d41133a3ae70fd569d6241bbddbdddc87410ea19','L11-HISTORY-1.dat':'79af28f93aa97f541d149b9f7f806ae6692316ad9abb364c4390223c7f8431ac','L3-REUSE-ORIGINAL.dat':'bad4c06bc33b7b9bb7d376dc631b69d98d8ec44035fde622866b9af07097a0f8'}
  for name,expected_sha in expected.items():need(sha(tar.extractfile(name).read())==expected_sha,'historical receipt identity')
 print('PASS decrypted private-original inventory and six exact historical receipt identities')
else:print('NOT CHECKED: encrypted original recovery and historical receipt identities')
print('Evidence-only verification; no product code, tests, builds or runtime probes executed.')
