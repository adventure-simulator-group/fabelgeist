#!/usr/bin/env python3
"""Read-only evidence verification; no product execution."""
import argparse,difflib,gzip,hashlib,json,os,stat,subprocess,sys,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--repo');ap.add_argument('--private-queue',type=Path);a=ap.parse_args()
if sys.flags.optimize:raise SystemExit('disable Python optimization')
def need(x,m):
 if not x:raise SystemExit('FAIL: '+m)
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(t,b):return hashlib.sha1(f'{t} {len(b)}\0'.encode()+b).hexdigest()
def j(p):return json.loads((R/p).read_text())
m=j('MANIFEST.json');exp={x['path']:x for x in m['files']};fs=set();ds=set()
for p in R.rglob('*'):
 need(not p.is_symlink(),'symlink');r=p.relative_to(R).as_posix()
 if p.is_file():
  if r!='MANIFEST.json':fs.add(r)
 elif p.is_dir():ds.add(r)
 else:raise SystemExit('FAIL: special file')
need(fs==set(exp),'file inventory');need(ds==set(x['path'] for x in m['directories']),'directory inventory')
for r,x in exp.items():
 p=R/r;b=p.read_bytes();need(len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(p.stat().st_mode),'04o')==x['mode'],'file '+r)
for x in m['directories']:need(format(stat.S_IMODE((R/x['path']).stat().st_mode),'04o')==x['mode'],'directory mode')
def view(path,lo,hi):
 lines=(R/path).read_bytes().splitlines(keepends=True);need(1<=lo<=hi<=len(lines),'bounds');return b''.join(f'{i:6}\t'.encode()+lines[i-1] for i in range(lo,hi+1))
sreg=j('SOURCE-REGISTRATION.json');assigned=j('SOURCE-DISPLAY-RECEIPT.json')['displays'];need(len(assigned)==6,'assigned display count')
for x in assigned:
 s=next(z for z in sreg['source'] if z['revision']==x['revision']);lo,hi=x['range'];need(s['registered_ranges'][0][0]<=lo<=hi<=s['registered_ranges'][0][1] and sha((R/s['file']).read_bytes())==s['sha256'] and not x['truncated'],'assigned registration');b=view(s['file'],lo,hi);need(b==(R/x['view']).read_bytes() and sha(b)==x['view_sha256'],'assigned view')
for s in sreg['source']:
 rs=sorted(x['range'] for x in assigned if x['revision']==s['revision']);need(rs==[[1,77],[78,154]],'assigned complete scope')
support=j('SUPPORT-DISPLAY-RECEIPT.json')['displays']+j('SUPPORT-DISPLAY-RECEIPT-3.json')['displays'];need(len(support)==28,'support display count')
for x in support:
 reg=j(x['registration']);rows=[z for z in reg['sources'] if z['file']==x['source'] and x['range'] in z['registered_ranges']];need(len(rows)==1,'support registration');need(sha((R/x['source']).read_bytes())==x['source_sha256'] and not x['truncated'],'support source');lo,hi=x['range'];b=view(x['source'],lo,hi);need(b==(R/x['view']).read_bytes() and sha(b)==x['view_sha256'],'support view')
need((R/'source/wire-6533e4.rs').read_bytes()==(R/'source/wire-e2755a.rs').read_bytes()==(R/'source/wire-95e636.rs').read_bytes()==(R/'history/original-wire-object.rs').read_bytes(),'wire identity')
for name,suf in [('WIRE','rs'),('RUNTIME','rs'),('MANIFEST','toml')]:
 if name=='WIRE':old=R/'source/wire-6533e4.rs';new=R/'source/wire-95e636.rs';tag='wire.rs'
 else:old=R/f'support/{name.lower()}-6533e4.{suf}';new=R/f'support/{name.lower()}-95e636.{suf}';tag=name.lower()
 diff=''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),new.read_text().splitlines(keepends=True),fromfile='6533/'+tag,tofile='95e/'+tag));need((R/(name+'-DIFF.patch')).read_text()==diff,'source diff '+name)
g=j('GIT-PROOFS.json');extra=j('GIT-PROOFS-ADDITIVE.json');proofs=g['proofs']+extra['proofs']
def tree(o):
 m=g['trees'][o];b=(R/m['file']).read_bytes();need(len(b)==m['bytes'] and sha(b)==m['sha256'] and oid('tree',b)==o,'tree');return b
def entries(b):
 i=0;out={}
 while i<len(b):
  z=b.find(b'\0',i);need(z>=0 and z+21<=len(b),'tree framing');mode,name=b[i:z].split(b' ',1);need(name not in out,'tree names');out[name]=(mode.decode(),b[z+1:z+21].hex());i=z+21
 return out
for o in g['trees']:tree(o)
for x in proofs:
 cur=x['root_tree'];parts=x['path'].split('/');need([z['component'] for z in x['chain']]==parts[:len(x['chain'])],'chain path')
 for z in x['chain']:
  need(z['tree_oid']==cur,'chain continuity');e=entries(tree(cur)).get(z['component'].encode());need(e is not None and int(e[0],8)==int(z['mode'],8) and e[1]==z['child_oid'],'tree entry');cur=z['child_oid']
 if x['expected']=='absent':
  z=x['missing'];need(cur==z['tree_oid'] and z['component']==parts[len(x['chain'])] and z['component'].encode() not in entries(tree(cur)),'absence')
 elif x['expected']=='tree':need(cur==x['directory_oid'] and int(x['chain'][-1]['mode'],8)==0o40000,'directory tree')
 else:
  b=(R/x['file']).read_bytes();need(cur==x['blob_oid'] and sha(b)==x['sha256'] and oid('blob',b)==cur,'blob identity')
assets=[x['directory_oid'] for x in proofs if x['expected']=='tree'];need(len(assets)==2 and assets[0]==assets[1],'asset directory identity')
locks=[tomllib.loads((R/'support'/n).read_text()) for n in ['LOCK-6533e4','LOCK-95e636']]
for name in ['bevy','bevy_image','flate2','serde_json']:
 pairs=[]
 for lock in locks:
  v=[p for p in lock['package'] if p['name']==name];need(len(v)==1,'lock package uniqueness');pairs.append(tuple(v[0].get(k) for k in ('version','source','checksum')))
 need(pairs[0]==pairs[1],'lock package identity')
q=j('history/queue-q2904.json');need(q['contract_id']=='OBLIGATION-ROOT-L3-EXT-0017-LENS-08' and q['lens']==8,'queue identity');r=q['exact_source_identities_and_assessed_ranges'][0];need(sha((R/'history/REGISTRATION-ROOT-L3-EXT-016-017.json').read_bytes())==r['prospective_registration']['sha256'],'historic registration');need(sha((R/'history/READ-ROOT-L3-EXT-016-017.json').read_bytes())==r['discovering_lens_receipt']['sha256'],'historic receipt');need(sha((R/'history/REGISTRATION-ROOT-L3-CURRENT-001.json').read_bytes())==q['exact_current_revision_revisit_requirements'][0]['current_registration']['sha256'],'e275 registration')
queue_path=a.private_queue or R/'private/original-queue.json.gz';original=None;queue_bound=False;commits_bound=False;diff_bound=False
if queue_path.is_file():original=gzip.decompress(queue_path.read_bytes());need(sha(original)==sreg['historical_original_queue_sha256'],'private queue sha');queue_bound=True
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1'})
if a.repo:
 def git(*x):return subprocess.check_output(['git','-C',a.repo,*x],env=env)
 for x in proofs:need(git('rev-parse',x['revision']+'^{tree}').decode().strip()==x['root_tree'],'commit/tree binding')
 qb=git('show','56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e:baseline-059/queue.json');need(sha(qb)==sreg['historical_original_queue_sha256'] and (original is None or original==qb),'original queue binding');original=qb;queue_bound=True;commits_bound=True
 old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009'
 for path,name in [('crates/adventuresim-procedural-textures','CRATE-DIFF-NAME-STATUS.txt'),('crates/adventuresim-tactical-client/src/loading_screen/sources.rs','LOADING-DIFF-NAME-STATUS.txt')]:need(git('diff','--name-status',old,cur,'--',path)==(R/name).read_bytes(),'path status diff')
 diff_bound=True
if original is not None:
 arr=json.loads(original)['entries'];need(arr[2904]==q,'q2904 original selected')
 for i in [49,2701]:need(arr[i]==j('history/queue-q'+str(i)+'.json'),'related queue')
 for i in [2355,2934]:need(arr[i]==j('history/queue-q'+str(i)+'-original.json')==j('history/queue-q'+str(i)+'-public.json'),'related original/public')
print(json.dumps({'result':'PASS','manifest_files':len(fs),'assigned_displays':len(assigned),'support_displays':len(support),'tree_objects':len(g['trees']),'path_proofs':len(proofs),'old_path_absences':sum('missing'in x for x in proofs),'equal_asset_git_directory':True,'selected_lock_package_pairs':4,'original_queue_bound':queue_bound,'source_commit_roots_bound':commits_bound,'full_crate_name_status_bound':diff_bound,'qualification':'Evidence integrity only; without private queue or --repo, original 059 inclusion and exact commit/root bindings remain unverified. No product behavior, test, fixture, runtime or feature resolution.'},indent=2))
