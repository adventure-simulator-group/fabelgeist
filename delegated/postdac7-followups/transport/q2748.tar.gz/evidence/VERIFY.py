#!/usr/bin/env python3
"""Evidence-only integrity and selected Git-binding checks; never executes product code."""
import argparse,datetime,difflib,gzip,hashlib,io,json,os,stat,subprocess,sys,tarfile,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--repo',help='Git repo containing the pinned source and original queue commits');ap.add_argument('--private-queue',type=Path,help='Optional gzip capture of exact original 059 queue');a=ap.parse_args()
if sys.flags.optimize:raise SystemExit('Run without Python optimization')
def need(x,m):
 if not x:raise SystemExit('FAIL: '+m)
def sha(x):return hashlib.sha256(x).hexdigest()
def oid(kind,b):return hashlib.sha1(f'{kind} {len(b)}\0'.encode()+b).hexdigest()
def j(name):return json.loads((R/name).read_text())
manifest=j('MANIFEST.json');expected={x['path']:x for x in manifest['files']};files=set();dirs=set()
for p in R.rglob('*'):
 need(not p.is_symlink(),'symlink');rel=p.relative_to(R).as_posix()
 if p.is_file():
  if rel!='MANIFEST.json':files.add(rel)
 elif p.is_dir():dirs.add(rel)
 else:raise SystemExit('FAIL: special file')
need(files==set(expected),'file inventory')
for rel,x in expected.items():
 p=R/rel;b=p.read_bytes();need(len(b)==x['bytes'] and sha(b)==x['sha256'],'file identity '+rel);need(format(stat.S_IMODE(p.stat().st_mode),'04o')==x['mode'],'file mode '+rel)
need(dirs==set(x['path'] for x in manifest['directories']),'directory inventory')
for d in manifest['directories']:need(format(stat.S_IMODE((R/d['path']).stat().st_mode),'04o')==d['mode'],'directory mode')
def lines_view(path,lo,hi):
 lines=(R/path).read_bytes().splitlines(keepends=True);need(1<=lo<=hi<=len(lines),'view bounds')
 return b''.join(f'{i:6}\t'.encode()+lines[i-1] for i in range(lo,hi+1))
src=j('SOURCE-REGISTRATION.json');assigned=j('SOURCE-DISPLAY-RECEIPT.json');need(len(assigned['records'])==3,'assigned count')
for x in assigned['records']:
 s=next(v for v in src['source_reads'] if v['revision']==x['revision']);need(s['registered_ranges']==x['actual_displayed_ranges'] and sha((R/s['destination']).read_bytes())==s['sha256'] and x['displayed_after_registration'] and not x['truncated'],'assigned receipt')
 lo,hi=x['actual_displayed_ranges'][0];v=lines_view(s['destination'],lo,hi);need(v==(R/x['display_copy']).read_bytes() and sha(v)==x['display_copy_sha256'],'assigned display')
main=j('SUPPORT-REGISTRATION.json');extra=j('SUPPORT-REGISTRATION-2.json');reads=j('SUPPORT-DISPLAY-RECEIPT.json')['displays'];need(len(reads)==12,'support count')
for x in reads:
 reg=extra['source_scopes'] if x['registration']=='SUPPORT-REGISTRATION-2.json' else main['source_scopes']+main['native_scopes']
 rows=[z for z in reg if (z.get('name')==x['name'] or z.get('package')==x['name']) and x['range'] in z['registered_ranges']];need(len(rows)==1,'support range registration')
 need(sha((R/x['source']).read_bytes())==x['source_sha256'],'support source');lo,hi=x['range'];v=lines_view(x['source'],lo,hi);need(v==(R/x['view']).read_bytes() and sha(v)==x['view_sha256'] and not x['display_truncated'],'support view')
old=(R/'source/materials-6533e4.rs').read_text().splitlines(keepends=True);new=(R/'source/materials-95e636.rs').read_text().splitlines(keepends=True);diff=''.join(difflib.unified_diff(old,new,fromfile='6533/materials.rs',tofile='95e/materials.rs'));need(diff==(R/'SOURCE-DIFF.patch').read_text(),'source diff')
g=j('prior-proofs/GIT-TREE-PROOFS.json');plan=j('GIT-PROOF-PLAN.json');need(sha((R/'prior-proofs/GIT-TREE-PROOFS.json').read_bytes())==plan['proof_bytes_sha256'],'prior proof identity')
def readtree(o):
 x=g['tree_objects'][o];b=(R/'prior-proofs'/x['file']).read_bytes();need(sha(b)==x['sha256'] and len(b)==x['bytes'] and oid('tree',b)==o,'tree object');return b
def entries(b):
 i=0;out={}
 while i<len(b):
  z=b.find(b'\0',i);need(z>=0 and z+21<=len(b),'tree encoding');h=b[i:z];need(b' ' in h,'tree header');mode,name=h.split(b' ',1);need(name not in out,'duplicate entry');out[name]=(mode.decode(),b[z+1:z+21].hex());i=z+21
 return out
for o in g['tree_objects']:readtree(o)
for idx,file in plan['selected_proof_index_to_current_evidence'].items():
 x=g['proofs'][int(idx)];cur=x['root_tree'];parts=x['path'].split('/');need([z['component'] for z in x['chain']]==parts[:len(x['chain'])],'chain path')
 for z in x['chain']:
  need(z['tree_oid']==cur,'chain continuity');e=entries(readtree(cur)).get(z['component'].encode());need(e is not None and int(e[0],8)==int(z['entry_mode'],8) and e[1]==z['child_oid'],'tree entry');cur=z['child_oid']
 if file is None:
  z=x['missing'];need(cur==z['tree_oid'] and z['component']==parts[len(x['chain'])] and z['component'].encode() not in entries(readtree(cur)),'path absence')
 else:
  b=(R/file).read_bytes();need(cur==x['blob_oid'] and sha(b)==x['sha256'] and oid('blob',b)==cur and len(x['chain'])==len(parts),'source blob')
locks=[tomllib.loads((R/'support'/n).read_text()) for n in ['CARGO-LOCK-6533','CARGO-LOCK-95E']]
for p in main['native_scopes']:
 b=(R/p['archive_file']).read_bytes();need(sha(b)==p['checksum_sha256'],'native archive')
 for lock in locks:
  rows=[x for x in lock['package'] if x['name']==p['package'] and x['version']==p['version']];need(len(rows)==1 and rows[0]['checksum']==sha(b),'lock package checksum')
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:need(t.extractfile(p['source_member']).read()==(R/p['source_file']).read_bytes(),'native member')
q=j('published-queue-q2748.json');need(q['contract_id']=='OBLIGATION-ROOT-L3-EXT-0004-LENS-08' and q['lens']==8,'q2748 identity');need(sha((R/'history/HISTORY-0.json').read_bytes())==q['dependencies'][0]['sha256'],'historical registration');need(sha((R/'history/HISTORY-1.json').read_bytes())==q['exact_source_identities_and_assessed_ranges'][0]['discovering_lens_receipt']['sha256'],'historical receipt');need(sha((R/'history/HISTORY-2.json').read_bytes())==q['exact_current_revision_revisit_requirements'][0]['current_registration']['sha256'],'e275 registration')
queue_path=a.private_queue or R/'private/queue-original.json.gz';queue_bound=False;queue=None
if queue_path.is_file():
 queue=gzip.decompress(queue_path.read_bytes());need(sha(queue)==src['original_queue']['sha256'],'private original queue digest');queue_bound=True
commit_bound=False
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1'})
if a.repo:
 def git(*args):return subprocess.check_output(['git','-C',a.repo,*args],env=env)
 for row in src['source_reads']:need(git('rev-parse',row['revision']+'^{tree}').decode().strip()==row['git_root_tree'],'commit/root binding')
 original=git('show',src['original_queue']['commit']+':'+src['original_queue']['path']);need(sha(original)==src['original_queue']['sha256'],'original queue Git binding');need(queue is None or queue==original,'original queue equality');queue=original;queue_bound=True;commit_bound=True
if queue is not None:
 entries059=json.loads(queue)['entries'];need(entries059[2748]==q,'q2748 selected object')
 for i in [49,2701]:need(entries059[i]==j('history/queue-'+str(i)+'-selected-record.json'),'related historical selected object')
print(json.dumps({'result':'PASS','manifest_files':len(files),'assigned_personal_displays':len(assigned['records']),'support_personal_displays':len(reads),'selected_tree_chains':len(plan['selected_proof_index_to_current_evidence']),'selected_old_path_absences':1,'native_archive_lock_checks':4,'original_queue_bound':queue_bound,'source_commit_roots_bound':commit_bound,'qualification':'Evidence integrity only; public transport without a private queue or --repo does not establish original 059 queue inclusion or commit-root binding. No runtime, full support complements, feature resolution, 3821 promotion, count or lens closure.'},indent=2))
