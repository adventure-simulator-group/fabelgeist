#!/usr/bin/env python3
"""Evidence-only replay. Optional inputs are independently held restricted artifacts."""
import argparse,json
from pathlib import Path
from hashlib import sha1,sha256
S=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--commits',type=Path);ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true',help='pre-seal only');args=ap.parse_args()
def read(p): return (S/p).read_bytes()
def load(p): return json.loads(read(p))
def gh(k,b):return sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);ze=b.index(b'\0',sp+1);d[b[sp+1:ze].decode()]=(b[i:sp].decode(),b[ze+1:ze+21].hex());i=ze+21
 return d
if not args.skip_manifest:
 m=load('MANIFEST.json');actual={p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};assert actual=={r['path'] for r in m['files']},'file set'
 for r in m['files']:
  b=read(r['path']);assert len(b)==r['bytes'] and sha256(b).hexdigest()==r['sha256'],r['path']
proof=load('SOURCE-PROOF.json')
for row in proof['paths']:
 b=read(row['source']);assert sha256(b).hexdigest()==row['blob_sha256'] and gh('blob',b)==row['blob_git_sha1'];oid=proof['commit_roots'][row['revision']]
 for step in row['chain']:
  assert step['tree']==oid;tb=read('trees/'+oid+'.tree');assert gh('tree',tb)==oid;mode,oid=entries(tb)[step['component']];assert mode==step['mode'] and oid==step['oid']
 assert oid==row['blob_git_sha1']
for row in load('DISPLAY-MAP.json')['displays']:
 lines=read(row['source']).decode().splitlines();lo,hi=row['range'];assert 1<=lo<=hi<=len(lines);out=''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert read(row['display'])==out
if args.commits:
 mapping={'6533.commit':'6533e444fa37552927070cc8d8190907fd3b413e','e275.commit':'e2755a732c84e67296b5e3441a4259a84f461b2f','95e.commit':'95e63628f9d70b8dd6e6fede64334696c6995009'}
 for name,oid in mapping.items():
  b=(args.commits/name).read_bytes();assert gh('commit',b)==oid;assert b.split(b'\n',1)[0].split(b' ')[1].decode()==proof['commit_roots'][oid]
if args.anchors and not args.private:ap.error('--anchors requires --private')
if args.private:
 pm=(args.private/'MANIFEST.json').read_bytes();assert sha256(pm).hexdigest()=='dcd820322604cccada65714a11f74fc4fb6cf85bf08998d086a8c07f9ff5e701';m=json.loads(pm)
 actual={p.relative_to(args.private).as_posix() for p in args.private.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};assert actual=={r['path'] for r in m['files']}
 for r in m['files']:
  f=args.private/r['path'];b=f.read_bytes();assert len(b)==r['bytes'] and sha256(b).hexdigest()==r['sha256'] and f.stat().st_mode & 0o777==r['mode']
 for index,contract in [(2896,'OBLIGATION-ROOT-L3-EXT-0016-LENS-12'),(2700,'REVIEW-L3-LOGIC-GRID-PROJECTION-AND-ANSWER-ADMISSION')]:
  x=json.loads((args.private/f'PRIVATE-Q{index}-RAW-0.json').read_bytes());y=json.loads((args.private/f'PRIVATE-Q{index}-RAW-1.json').read_bytes());assert x==y and x['contract_id']==contract
 if args.anchors:
  spans=json.loads((args.private/'QUEUE-SPAN-RECEIPT-018.json').read_bytes())['spans']
  for row in spans:
   whole=(args.anchors/row['queue']).read_bytes();raw=(args.private/row['captured_as']).read_bytes();assert sha256(whole).hexdigest()==row['queue_sha256'];assert whole[row['byte_offset']:row['byte_offset']+row['byte_length']]==raw;assert json.loads(whole)['entries'][row['index']]==json.loads(raw)
print('PASS: '+('pre-seal source/tree consistency and line displays; manifest not checked.' if args.skip_manifest else 'public manifest, exact source/tree consistency, and line displays.'))
print('Commit-to-root authentication: '+('PASS' if args.commits else 'NOT CHECKED; provide separately held --commits.'))
print('Restricted packet identity: '+('PASS' if args.private else 'NOT CHECKED; provide separately held --private.'))
print('Full-queue span membership: '+('PASS' if args.anchors else 'NOT CHECKED; provide --private and separately held --anchors.'))
print('No product code, product parser, fixtures, tests, builds or runtime probes executed.')
