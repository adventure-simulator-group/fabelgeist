#!/usr/bin/env python3
"""Evidence-only q2708 v7 successor verifier."""
import argparse,hashlib,io,json,pathlib,tarfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(x,m):
 if not x:raise SystemExit('FAIL: '+m)
def obj(b):return json.loads(b)
a=argparse.ArgumentParser();a.add_argument('--key');a=a.parse_args();here=pathlib.Path(__file__).resolve().parent;m=obj((here/'MANIFEST.json').read_bytes())
for r in m['files']:
 n=r['path'];need('/' not in n and '\\' not in n and n not in ('.','..'),'unsafe name');b=(here/n).read_bytes();need(sha(b)==r['sha256'] and len(b)==r['bytes'],'public '+n)
print('Public integrity:',len(m['files']),'files')
if not a.key:print('Private inputs were not checked; separate same-machine key is required.');raise SystemExit(0)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
key=pathlib.Path(a.key).read_bytes();need(len(key)==32,'key length');c=(here/'PRIVATE-INPUTS.aesgcm').read_bytes();magic=b'726Q2708v7\0';need(c.startswith(magic),'header');nonce=c[len(magic):len(magic)+12];d=AESGCM(key).decrypt(nonce,c[len(magic)+12:],b'726-q2708-v7-followup-v1');t=tarfile.open(fileobj=io.BytesIO(d),mode='r:gz');members=t.getmembers();need(all(x.isfile() and not x.name.startswith('/') and '..' not in pathlib.PurePosixPath(x.name).parts for x in members),'members');need(len({x.name for x in members})==len(members),'duplicates');fs={x.name:t.extractfile(x).read() for x in members};pm=obj(fs['PRIVATE-MANIFEST.json']);rows={x['path']:x for x in pm['files']};need(set(fs)-{'PRIVATE-MANIFEST.json'}==set(rows),'member set')
for n,r in rows.items():need(sha(fs[n])==r['sha256'] and len(fs[n])==r['bytes'],'private '+n)
old=obj(fs['PRIOR-0.dat']);oldfix=obj(fs['PRIOR-1.dat']);prior=obj(fs['PRIOR-2.dat']);new=obj(fs['NEW-0.dat']);fix=obj(fs['NEW-1.dat']);need(sha(fs['PRIOR-0.dat'])==fix['old_draft_sha256'] and sha(fs['NEW-0.dat'])==fix['new_draft_sha256'] and new['supersedes_draft_sha256']==fix['old_draft_sha256'],'predecessor chain');need(fix['old_assessment']==old['assessments'][0]['assessment'] and fix['new_assessment']==new['assessments'][0]['assessment'],'scope correction exact assessments');need(oldfix['new_assessment']==old['assessments'][0]['assessment'] and oldfix['new_draft_sha256']==sha(fs['PRIOR-0.dat']),'previous overflow correction');need(prior['revised_draft_sha256']==sha(fs['PRIOR-0.dat']),'previous report binding')
def changes(a,b,path=''):
 if type(a)!=type(b):return {path}
 if isinstance(a,dict):
  out=set()
  for k in set(a)|set(b):out|=({path+'/'+k} if k not in a or k not in b else changes(a[k],b[k],path+'/'+k))
  return out
 if isinstance(a,list):
  out={path+'/length'} if len(a)!=len(b) else set()
  for i,(x,y) in enumerate(zip(a,b)):out|=changes(x,y,path+'/'+str(i))
  return out
 return {path} if a!=b else set()
need(changes(old,new)=={'/assessments/0/assessment','/corrected_utc','/supersedes_draft_sha256'},'complete difference set');need(old['assessments'][0]['assessment'].replace('; that setting is not determined solely by build profile.','.')==new['assessments'][0]['assessment'],'exact clause removal');print('Authenticated v6/v7, both correction records, predecessor chain and exact clause removal: verified');print('No new product source, runtime, build or test assessed.')
