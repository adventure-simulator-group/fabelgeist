# q2708 v7 scope-correction follow-up

REPORT.json records the bounded result. Authenticated encrypted inputs preserve exact v6 and v7 bytes, both relevant correction records and the prior follow-up report. The previously held same-machine key is required; this is not independent public recoverability.

`python3 VERIFY.py` checks public identities. Add `--key KEY_PATH` for authenticated private replay and exact draft comparison. This is evidence-only verification; it runs no product, builds or tests. Prior source evidence and Git objects remain separate provenance dependencies.
