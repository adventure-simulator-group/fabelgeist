#!/usr/bin/env python3
import argparse,hashlib,json,os,pathlib,stat,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
arg=argparse.ArgumentParser();arg.add_argument('--skip-manifest',action='store_true');arg.add_argument('--prior');arg.add_argument('--v3');arg.add_argument('--anchors');a=arg.parse_args()
sha256=lambda b:hashlib.sha256(b).hexdigest()
def objid(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def manifest(d,expected=None):
 raw=(d/'MANIFEST.json').read_bytes()
 if expected:assert sha256(raw)==expected,'external manifest identity mismatch'
 m=json.loads(raw);listed={x['path'] for x in m['files']};actual={str(x.relative_to(d)) for x in d.rglob('*') if x.is_file()}-{'MANIFEST.json'}
 assert listed==actual,('inventory mismatch',sorted(listed-actual),sorted(actual-listed))
 for x in m['files']:
  q=d/x['path'];data=q.read_bytes();assert len(data)==x['bytes'] and sha256(data)==x['sha256'] and stat.S_IMODE(q.stat().st_mode)==x['mode'],x['path']
 return len(listed)
if a.skip_manifest:print('NOT CHECKED: package manifest (--skip-manifest)')
else:print('package manifest and file modes checked:',manifest(root))
proof=json.loads((root/'SOURCE-PROVENANCE.json').read_bytes())
assert proof['current_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009'
def tree(oid):
 data=(root/'source-trees'/(oid+'.tree')).read_bytes();assert objid('tree',data)==oid;result={};i=0
 while i<len(data):
  j=data.index(b' ',i);k=data.index(b'\0',j+1);mode=data[i:j].decode('ascii');name=data[j+1:k].decode('utf-8');v=data[k+1:k+21];assert len(v)==20 and name not in result;result[name]=(mode,v.hex());i=k+21
 assert i==len(data);return result
def chain(row,start,path):
 steps=row['chain'];assert steps and steps[0]['tree']==start and '/'.join(s['component'] for s in steps)==path
 for i,s in enumerate(steps):
  assert tree(s['tree'])[s['component']]==(s['mode'],s['oid'])
  if i+1<len(steps):assert s['mode']=='40000' and s['oid']==steps[i+1]['tree']
 assert steps[-1]['oid']==row['blob']
def rendered(blob,start,end,style):
 lines=blob.splitlines(keepends=True);assert 1<=start<=end<=len(lines)
 if style=='coordinator':return b''.join(str(i).encode()+b': '+lines[i-1] for i in range(start,end+1))
 return b''.join(('%5d\t'%i).encode()+lines[i-1] for i in range(start,end+1))
count=0
for row in proof['source_rows']:
 data=(root/'captured-source'/(row['label']+'.source')).read_bytes();assert sha256(data)==row['sha256'] and objid('blob',data)==row['blob'];chain(row,proof['current_root'],row['path'])
 for d in row['displays']:
  got=(root/'captured-source'/d['file']).read_bytes();assert sha256(got)==d['sha256'] and got==rendered(data,*d['range'],'coordinator');count+=1
for row in proof['helper_rows']:
 data=(root/'helper-source'/(row['label']+'.source')).read_bytes();assert sha256(data)==row['sha256'] and objid('blob',data)==row['blob'];chain(row,proof['current_root'],row['path'])
hreg=json.loads((root/'HELPER-DISPLAY-REGISTRATION-017.json').read_bytes());hreceipt={x['name']:x for x in json.loads((root/'HELPER-DISPLAY-RECEIPT-017.json').read_bytes())}
for d in hreg['ranges']:
 data=(root/'helper-source'/d['source']).read_bytes();got=(root/'helper-displays'/(d['name']+'.txt')).read_bytes();rec=hreceipt[d['name']];assert rec['range']==[d['start'],d['end']] and len(got)==rec['bytes'] and sha256(got)==rec['sha256'] and got==rendered(data,d['start'],d['end'],'coordinator');count+=1
assert count==11
prepared=(root/'captured-source/prepared.source').read_bytes();path='crates/adventuresim-tactical-client/src/presentation/buildings/prepared.rs'
for row in proof['historical_target_proofs']:
 assert row['blob']==objid('blob',prepared);chain(row,row['chain'][0]['tree'],path)
assert len(proof['historical_target_proofs'])==2
for d in proof['delegate_displays']:
 got=(root/'delegate-displays'/d['file']).read_bytes();assert sha256(got)==d['sha256'] and got==rendered(prepared,*d['range'],'delegate')
print('9 source blobs, Git tree paths, 11 independent displays, 3 delegate transcripts and per-file historical identity checked')
if any([a.prior,a.v3,a.anchors]):
 if not all([a.prior,a.v3,a.anchors]):raise SystemExit('all --prior, --v3 and --anchors are required for full replay')
 v3=pathlib.Path(a.v3);manifest(v3,'ecd8279ba238a2bc6d4e2a0cc3372440818ed334a0c8980c0231cb1f47b7b210')
 cmd=[sys.executable,str(v3/'verify.py'),'--prior',a.prior,'--anchors',a.anchors];r=subprocess.run(cmd,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});assert r.returncode==0,('restricted evidence replay failed',r.returncode)
 print('separately held restricted packets checked: commit/root, delegate transport, ledger, exact v3 correction, and full-queue membership')
else:print('NOT CHECKED: commit-to-root binding, delegated transport, exact v3 correction, ledger provenance, and full-queue membership; restricted packets and anchors required')
print('Source/evidence replay only; no product code or runtime behavior executed')
