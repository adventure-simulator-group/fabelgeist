# q2760 source-only spot-check evidence

This successor presents the bounded independent q2760 review and exact selected
source displays. REVIEW.md retains the original v2 finding; V3-SUMMARY.json
records its subsequent correction. Source files outside the 629 explicitly
registered lines are included for byte verification, not claimed as read.

`python3 verify.py` verifies this package manifest, source blobs, raw Git tree
chains, and selected displays. It does not establish commits bind to roots,
verify the exact shared draft or the ledger/queue membership, or recover
private originals. For those checks supply `--prior DIR --v3 DIR --anchors
DIR` using the separately held restricted review, v3 packet and full-queue
anchors. Those originals contain unredacted outside-scope material, paths and
metadata and are not included here. Full replay does not execute product code.

The 6533/e275/95e selected prepared-file blob identity is per-file; it does not
prove tree equivalence. Recovered historical, reconstructed and newly assessed
records are distinct. The missing 3821 checkpoint is not reconstructed by the
059 streams. Other qualifications and attribution appear in REVIEW.md.

The bounded privacy scan is finite; it checks a derived local-path corpus and
common markers, not every possible sensitive value.
