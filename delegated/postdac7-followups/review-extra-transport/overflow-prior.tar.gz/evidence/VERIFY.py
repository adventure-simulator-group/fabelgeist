#!/usr/bin/env python3
"""Evidence-only q2708 correction verifier; optional authenticated recovery."""
import argparse,hashlib,io,json,os,pathlib,subprocess,tarfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(x,m):
 if not x:raise SystemExit('FAIL: '+m)
def obj(b):return json.loads(b)
a=argparse.ArgumentParser();a.add_argument('--key');a.add_argument('--git');a=a.parse_args();here=pathlib.Path(__file__).resolve().parent
m=obj((here/'MANIFEST.json').read_bytes())
for r in m['files']:
 n=r['path'];need('/' not in n and '\\' not in n and n not in ('.','..'),'unsafe name');b=(here/n).read_bytes();need(sha(b)==r['sha256'] and len(b)==r['bytes'],'public '+n)
print('Public integrity:',len(m['files']),'files')
need(not a.git or a.key,'--git requires --key')
if not a.key:print('Private input and Git binding not checked; same-machine key is separately held.');raise SystemExit(0)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
key=pathlib.Path(a.key).read_bytes();need(len(key)==32,'key length');c=(here/'PRIVATE-INPUTS.aesgcm').read_bytes();magic=b'726Q2708v1\0';need(c.startswith(magic),'header');nonce=c[len(magic):len(magic)+12];d=AESGCM(key).decrypt(nonce,c[len(magic)+12:],b'726-q2708-overflow-followup-v1');t=tarfile.open(fileobj=io.BytesIO(d),mode='r:gz');members=t.getmembers();need(all(x.isfile() and not x.name.startswith('/') and '..' not in pathlib.PurePosixPath(x.name).parts for x in members),'members');need(len({x.name for x in members})==len(members),'duplicates');fs={x.name:t.extractfile(x).read() for x in members};pm=obj(fs['PRIVATE-MANIFEST.json']);rows={x['path']:x for x in pm['files']};need(set(fs)-{'PRIVATE-MANIFEST.json'}==set(rows),'members match manifest')
for n,r in rows.items():need(sha(fs[n])==r['sha256'] and len(fs[n])==r['bytes'],'private '+n)
old=obj(fs['SEALED-0.dat']);historical_fix=obj(fs['SEALED-1.dat']);delegate=obj(fs['SEALED-2.dat']);source=fs['SEALED-3.dat'].decode().splitlines();new=obj(fs['SUCCESSOR-0.dat']);fix=obj(fs['SUCCESSOR-1.dat'])
need(sha(fs['SEALED-0.dat'])==fix['old_draft_sha256'] and sha(fs['SUCCESSOR-0.dat'])==fix['new_draft_sha256'] and new['supersedes_draft_sha256']==fix['old_draft_sha256'],'draft chain');need(fix['old_assessment']==old['assessments'][0]['assessment'] and fix['new_assessment']==new['assessments'][0]['assessment'],'correction exact assessments');need(historical_fix['new_history']==old['assessments'][0]['history'],'previous historical correction')
def changes(a,b,path=''):
 if type(a)!=type(b):return {path}
 if isinstance(a,dict):
  out=set()
  for k in set(a)|set(b):out|=({path+'/'+k} if k not in a or k not in b else changes(a[k],b[k],path+'/'+k))
  return out
 if isinstance(a,list):
  out={path+'/length'} if len(a)!=len(b) else set()
  for i,(x,y) in enumerate(zip(a,b)):out|=changes(x,y,path+'/'+str(i))
  return out
 return {path} if a!=b else set()
need(changes(old,new)=={'/assessments/0/assessment','/corrected_utc','/supersedes_draft_sha256'},'complete difference set');need('position + 1' in source[59] and 'position + 1' in source[75],'selected source lines');need('255 overflow with checks enabled or wrap with checks disabled' in delegate['finding']['analysis'],'delegate condition');need('when overflow checks are enabled and wraps when they are disabled' in new['assessments'][0]['assessment'],'v6 condition');need(sha(fs['SEALED-3.dat'])=='663ef1d62d85a2b952a6be5d496949ae0b71d293110c14d6d7d123319559ee6b','antecedent source identity');print('Authenticated predecessor, both corrections, exact change set, source and delegate condition: verified')
if a.git:
 env=dict(os.environ,GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');blob=subprocess.check_output(['git','-C',a.git,'show','95e63628f9d70b8dd6e6fede64334696c6995009:crates/adventuresim-puzzles/src/ordered_sigils.rs'],env=env);need(blob==fs['SEALED-3.dat'],'Git source binding');print('External Git source content binding: verified')
else:print('External Git source content binding not checked.')
print('Toolchain setting/profile relation, supported ingress and product behavior not verified.')
