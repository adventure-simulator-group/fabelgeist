# q2708 overflow follow-up

REPORT.json records the bounded result and qualifications. The encrypted inputs retain exact v5 and v6 draft bytes, both corrections, the previously sealed delegate report, selected source and read records. The separately held same-machine key is required; it does not give independent public recoverability.

Run `python3 VERIFY.py` for public identities. Add `--key KEY_PATH` to authenticate and replay the draft chain and selected evidence; `--git GIT_CHECKOUT` additionally binds the captured source to its named product revision. These are evidence-only checks, not product tests or runtime validation. The original full encrypted antecedent and independently retained Git objects remain separate provenance dependencies.
