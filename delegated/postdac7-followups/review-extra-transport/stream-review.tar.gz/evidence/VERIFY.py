#!/usr/bin/env python3
"""Read-only evidence verification, no product execution."""
import argparse,hashlib,json,os,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent

def require(x,msg):
    if not x: raise SystemExit('FAIL: '+msg)
def digest(b): return hashlib.sha256(b).hexdigest()
def blobid(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def treeid(b): return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
def js(path): return json.loads((R/path).read_text())
def tree_entries(b):
    entries=[];i=0
    while i<len(b):
        sp=b.find(b' ',i);end=b.find(b'\0',sp+1)
        require(sp>=i and end>sp and end+21<=len(b),'malformed tree')
        entries.append((b[i:sp].decode(),b[sp+1:end].decode(),b[end+1:end+21].hex()));i=end+21
    return entries
ap=argparse.ArgumentParser();ap.add_argument('--repo');ap.add_argument('--draft-dir');ap.add_argument('--coordinator-dir');a=ap.parse_args()
m=js('MANIFEST.json'); expected=m['files']; actual=[]
for p in R.rglob('*'):
    require(not p.is_symlink(),'symlink in transport')
    if p.is_file() and p != R/'MANIFEST.json': actual.append(p.relative_to(R).as_posix())
require(set(actual)==set(expected),'manifest file set mismatch')
for n,v in expected.items():
    b=(R/n).read_bytes();require(len(b)==v['bytes'] and digest(b)==v['sha256'],'manifest member mismatch')
proof=js('GIT-PROOFS.json'); trees={}
for t in proof['trees']:
    b=(R/t['file']).read_bytes();require(digest(b)==t['sha256'] and treeid(b)==t['oid'],'tree identity mismatch');trees[t['oid']]=tree_entries(b)
for p in proof['proofs']:
    cur=p['root_tree'];parts=p['path'].split('/');require(len(parts)==len(p['chain']),'path chain length')
    for i,(part,c) in enumerate(zip(parts,p['chain'])):
        require(cur==c['parent_tree'] and c['name']==part and cur in trees,'chain parent')
        hits=[x for x in trees[cur] if x[1]==part]
        require(len(hits)==1 and hits[0]==(c['mode'],part,c['object']),'tree entry mismatch')
        if i<len(parts)-1: require(c['mode'] in ('40000','040000'),'non-tree parent');cur=c['object']
        else: require(c['object']==p['blob'],'leaf mismatch')
    require(blobid((R/p['source_capture']).read_bytes())==p['blob'],'source blob mismatch')
receipts=js('MY-SOURCE-READ-RECEIPT.json'); proofmap={(p['revision'],p['path']):p for p in proof['proofs']}
for d in receipts['displays']:
    pr=proofmap[(d['revision'],d['path'])];lines=(R/pr['source_capture']).read_bytes().splitlines(keepends=True);start,end=d['range'];require(1<=start<=end<=len(lines),'invalid source window')
    expected_view=b''.join(f'{i:6}\t'.encode()+lines[i-1] for i in range(start,end+1));view=(R/d['file']).read_bytes();require(view==expected_view and digest(view)==d['sha256'],'own displayed window mismatch')
    reg=js(d['registered_by']);
    if d['registered_by']=='MY-SOURCE-REGISTRATION.json': ranges=next(x['prospective_ranges'] for x in reg['inputs'] if x['path']==d['path'])
    else: ranges=reg.get('planned_ranges',reg.get('prospective_ranges',[]))
    require(d['range'] in ranges,'display was not in registered window')
cap=js('coordinator/SELECTED-CAPTURE.json');coord=0
for c in cap['rows']:
    source=(R/'inputs/source'/(c['label']+'.source')).read_bytes();require(digest(source)==c['source_sha256'],'coordinator source hash');lines=source.splitlines(keepends=True)
    for v in c['displays']:
        view=(R/'coordinator/views'/v['file']).read_bytes();expect=b''.join(f'{i}: '.encode()+lines[i-1] for i in range(v['start'],v['end']+1));require(view==expect and digest(view)==v['sha256'],'coordinator view mismatch');coord+=1
lines=(R/'inputs/source/guide.source').read_bytes().splitlines(keepends=True);g=(R/'coordinator/guide-112-127.txt').read_bytes();require(g==b''.join(f'{i}: '.encode()+lines[i-1] for i in range(112,128)) and digest(g)==js('coordinator/GUIDE-CAPTURE.json')['display_sha256'],'guide view')
dm=js('delegate/MANIFEST.json')['files'];dcount=0
for f in (R/'delegate').iterdir():
    if f.name=='MANIFEST.json':continue
    require(f.name in dm,'delegate member absent from manifest');b=f.read_bytes();require(len(b)==dm[f.name]['bytes'] and digest(b)==dm[f.name]['sha256'],'delegate selected member');dcount+=1
require(digest((R/'delegate/MANIFEST.json').read_bytes())=='b4946e97501df3c4a1eb64bc97bbcdc28e4702d4dde9f5e20f68194293342a9c','delegate manifest identity')
for n in ['STREAM-DRAFT.json','STREAM-DRAFT-v3.json','STREAM-DRAFT-v4.json','STREAM-DRAFT-v5.json']:
    d=js('draft/'+n);require(d['q2773_reserialized_assessment']['historical_contract_id']=='OBLIGATION-ROOT-L3-EXT-0006-LENS-09','wrong q2773 draft selection')
bindings={'source_commit_roots':False,'delegate_archive':False,'historical_queue_slices':False,'published_ledger':False,'restricted_drafts':False,'full_coordinator_capture':False}
def git(repo,*args):
    env=dict(os.environ,GIT_NO_REPLACE_OBJECTS='1',GIT_OPTIONAL_LOCKS='0')
    cp=subprocess.run(['git','-C',repo,*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    require(cp.returncode==0,'external Git evidence lookup failed');return cp.stdout
if a.repo:
    for p in proof['proofs']:
        require(git(a.repo,'rev-parse',p['revision']+'^{tree}').decode().strip()==p['root_tree'],'commit root mismatch')
        require(git(a.repo,'rev-parse',p['revision']+':'+p['path']).decode().strip()==p['blob'],'commit path mismatch')
    bindings['source_commit_roots']=True
    ar=git(a.repo,'show','dac7d0055716053f245139971eb67ddfd87fa462:delegated/post0a24-followups/transport/q2773-packet.tar.gz');require(digest(ar)=='3a16e5c4f686e6f7fae7f1027768014c2d5424195434ad1ab322911b690042c5','delegate archive mismatch');bindings['delegate_archive']=True
    ledger=js('ledger/SELECTED-RECORDS.json');base=git(a.repo,'show',ledger['revision']+':BASELINE-95E-20261110.json');rc=git(a.repo,'show',ledger['revision']+':RECONCILIATION-059.json');require(digest(base)==ledger['baseline_sha256'] and digest(rc)==ledger['reconciliation_sha256'],'published ledger stream');parsed=json.loads(base)['newly_assessed_ledger']['entries'];require(all(parsed[int(i)]==v for i,v in ledger['ledger'].items()),'ledger selection');require(json.loads(rc)['entries'][2773]==ledger['queue_reconciliation_2773'],'reconciliation selection');bindings['published_ledger']=True
    rows=js('HISTORY-SLICE-VERIFICATION.json')['rows'];streams={}
    for row in rows:
        rev=row['revision']
        if rev not in streams:streams[rev]=git(a.repo,'show',rev+':baseline-059/queue.json')
        raw=streams[rev];require(len(raw)==row['stream_bytes'] and digest(raw)==row['stream_sha256'],'historical stream mismatch');piece=raw[row['start']:row['end_exclusive']];i=int(row['pointer'].split('/')[-1]);require(digest(piece)==row['exact_slice_sha256'] and json.loads(piece)==json.loads(raw)['entries'][i],'historical exact slice mismatch')
    bindings['historical_queue_slices']=True
if a.draft_dir:
    d=Path(a.draft_dir)
    for n in ['STREAM-DRAFT.json','STREAM-DRAFT-v3.json','STREAM-DRAFT-v4.json','STREAM-DRAFT-v5.json']:
        b=(d/n).read_bytes();v=js('draft/'+n);require(digest(b)==v['whole_draft_sha256'] and len(b)==v['whole_draft_bytes'] and json.loads(b)['assessments'][1]==v['q2773_reserialized_assessment'],'restricted draft binding')
    bindings['restricted_drafts']=True
if a.coordinator_dir:
    d=Path(a.coordinator_dir)
    for x in js('coordinator/ORIGINAL-CAPTURE-IDENTITIES.json')['original_files']:
        b=(d/x['file']).read_bytes();require(len(b)==x['bytes'] and digest(b)==x['sha256'],'coordinator original identity')
    full=json.loads((d/'CAPTURE.json').read_text());count=0
    for c in full['rows']:
        b=(d/(c['label']+'.source')).read_bytes();require(digest(b)==c['source_sha256'],'full coordinator source');lines=b.splitlines(keepends=True)
        for v in c['displays']:
            z=(d/v['file']).read_bytes();require(digest(z)==v['sha256'] and z==b''.join(f'{i}: '.encode()+lines[i-1] for i in range(v['start'],v['end']+1)),'full coordinator view');count+=1
    require(count==17,'coordinator display count');bindings['full_coordinator_capture']=True
print(json.dumps({'result':'PASS','manifest_files':len(expected),'tree_objects':len(trees),'git_path_proofs':len(proof['proofs']),'independent_displays':len(receipts['displays']),'coordinator_selected_displays':coord,'guide_views':1,'selected_delegate_members':dcount,'external_bindings':bindings,'qualification':'Evidence integrity only. False external bindings are not verified. No product behavior, fixture, build, test, or runtime validation.'},indent=2))
