# Coordinator draft v5 spot-check

The q2773-only v5 delta retains the v4 conditional source analysis and now
explicitly distinguishes the first-contract operations while leaving global
aliases and unique counts unresolved. The complete restricted v5 draft has
SHA-256 `077426117c02580d5d8614d3aa8c0b1df4c58d03c32dc4042601473d2eb06206`.
The selected object is reserialized and binds to that whole draft only when the
private original is supplied to the evidence verifier.
