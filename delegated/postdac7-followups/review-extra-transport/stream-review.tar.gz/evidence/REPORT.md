# Independent review of q2773 coordinator draft

Reviewer: `/root/mhr_character`. This review is source and evidence inspection
only. It concerns the Lens 9 q2773 portion of the coordinator draft, not the
neighboring q2760 assessment. The q2773 draft v3 (complete original SHA-256
`ab134f0a1eefe7e7892e1543576f8e7b666c7198915330fffafdae0e6cbce013`)
correctly incorporates the phase/error and non-exhaustive rule refinements below.
The extracted draft objects and ledger rows in this packet are reserializations,
not exact byte slices. The full draft and queue originals remain restricted.

## Conclusions

- At 95e, `presentation/buildings/streaming.rs:16–59,79–96` retains a queue,
  original total, optional sorting focus and first formatted failure. Success
  and error remove an entry; false requeues it. A failed removal therefore
  contributes to `completed()` and `finished()` means only that the queue is
  empty. The equality `completed = removed entries` assumes the maintained
  total/queue invariant; the `pub(crate)` total's full writer population is not
  established. The selected production callback at `:179–231,253–260`
  returns `Ok(true)` or propagates an error. The explicit `Ok(false)` example
  is test source (`:117–142`), which was read but not run. It does not prove a
  production waiting path. First failure ownership and later continuation remain
  separate contract/policy questions.
- The loop at `streaming.rs:79–94` takes its range from the initial queue
  length. Each completed iteration removes at most one outstanding element;
  requeue preserves the count, and the deadline only breaks the pass. Thus the
  selected internal transitions do not themselves empty the queue before the
  next bounded pop. The `expect` at `:84` nevertheless textually conflicts
  with pinned `crates/AGENTS.md:126–127`; a reachable pop panic is not shown.
  The separate status-lock `expect` at `art_demo.rs:307` also conflicts with
  that source rule; a poisoned mutex or its reachable panic is not established.
  These two selected operations are not an exhaustive rule inventory: the
  independently displayed `art_demo.rs:207,215,219` has other expects. No
  uniqueness or alias count is assigned.
- In `art_demo.rs:263–275`, an unfinished queue yields Loading and a drained
  queue's retained failure yields Unavailable. The following independent scene
  asset branch (`:277–303`) can replace that choice with a scene error or
  Loading for unloaded dependencies. Failure visibility, phase precedence,
  readiness and degraded-mode policy must not be inferred from queue drain.
- `regional_map/city.rs:48–81` has a ticket plus separate phase and optional
  error: the shape permits incompatible combinations. The selected admission
  constructors (`city/installation.rs:19–40`) initialize Ready/Preparing with
  None and Failed with Some. The settle operation (`city.rs:234–249`) changes
  Preparing to Ready in place, preserving `error`, so it depends on its incoming
  invariant. The selected transitions do not demonstrate an invalid combination.
  Current `regional_map/status.rs:20–43,160–176` serializes this status, and
  `strategic-web/static/regional-city-installation.js:25–34` compares both
  ticket owner and sequence before interpreting Ready, Failed and error. Old
  installed city, pending candidate and independent render readiness should not
  be collapsed into this one phase.
- A distinct conditional attribution issue remains open. If candidate P1 is
  already pending, a later P2 admission fails, and P1 then gets an assembly
  failure, `city/installation.rs:28–40` leaves P1 pending while publishing
  P2's failure; `city.rs:256–266` then replaces the *current* status using its
  P2 ticket and the old candidate's Assembly failure. No invalid phase/error
  pair is needed. `regional-city-request.js:27–49,78–95` serializes preparation,
  aborts a superseded browser request and warns that an already queued native
  replacement may outlive cancellation. Its `wasm_cancel_generation` reaches
  `generation/wasm.rs:33–35` and `generation/ownership.rs:205–219`, which clear
  matching preparing/staged or completed generation state; activation consumes
  completed into active at `:246–275`. The selected cancellation function does
  not remove `CityResidency.pending`. This establishes a source-conditional
  ordering, not actual task scheduling, reachability of both failures, observed
  wrong user-facing error, or desired retry/failure policy. The prior delegate
  already left authority and identity across requests open; relationship to
  other records requires central reconciliation, without assuming an alias or
  adding a unique count.

## Attribution and evidence limits

The independently attributed published delegate is `/root/verifier_scope`'s
q2773 packet at `dac7d0055716053f245139971eb67ddfd87fa462`,
`delegated/post0a24-followups/transport/q2773-packet.tar.gz`, archive SHA-256
`3a16e5c4f686e6f7fae7f1027768014c2d5424195434ad1ab322911b690042c5`,
manifest SHA-256 `b4946e97501df3c4a1eb64bc97bbcdc28e4702d4dde9f5e20f68194293342a9c`.
Its 161 manifest entries match the archive's 161 other members. It records its
own untruncated 1–272 Lens 9 read; historical root Lens 3, Adler Lens 11 and
Segovb Lens 12 work remain their own. The Adler receipt cited by name lacked a
historical expected whole-file hash; its later measured hash does not supply
retroactive authentication. Same-machine transport is not independent custody.

The original 6533, e275 and pinned 95e versions share the streaming *path blob*
`9aaf45ca388bbd233c1251e26f8e108cc847dbf2`; their tree roots differ. The
separately attributed e275→95e diffs for regional city/status and presentation/
strategic status were independently reproduced byte-for-byte. No whole-tree
identity, runtime equivalence, historical global alias or checkpoint 3821
promotion follows. Historical 059 q67 concerns owned streaming failure, q1299
retains streaming/readiness and Segovb support qualifications, and q2703
qualifies the internal subtraction invariant while leaving total writers open.
The respective exact selected original 56f and reconstructed 26e q2773, q67,
q1299 and q2703 bytes match, but the full streams differ. The published dac7d
ledger retains rows 231 and 232 as related failure ownership/readiness records;
rows 228–230, 239 and 1079 have distinct GPU, material, identity or focus
scopes. The selected q2773 reconciliation at that checkpoint remained
unassessed; the current draft is proposed later work.

The coordinator's 17 numbered source displays and guide view matched their
captured source bytes and recorded hashes. This public packet includes the 12
q2773-relevant coordinator displays and guide, and retains the full capture in
the restricted original. My 26 independently registered displays and unread
complements appear in `MY-SOURCE-READ-RECEIPT.json`; copied complete bytes do
not credit unread lines. Initial filename/metadata locators were truncated; no
source-body credit was based on them. An initial Git lookup used the unrelated
outer repository, failed with status 128, and was corrected using the evidence
repository; the failure is not evidence of source absence. No product, browser,
fixture, build, test, renderer or runtime probe was executed.

Portable verification checks local files, path-tree/blob chains, own displays
and the selected coordinator views. `--repo` additionally binds Git commit
roots, historical queue slices and the published delegate archive to an
external evidence repository. `--draft-dir` optionally binds the reserialized
q2773 selections to their restricted complete drafts. Without these external
inputs those bindings are explicitly unverified. Raw 059 queue material is
excluded from this public reconstruction; exact private custody is separate.
The bounded privacy scan and its limitations are recorded outside this report.
