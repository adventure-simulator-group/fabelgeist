# q2773: independent Lens 9 streaming state-shape review

This is a fresh, bounded source-only review by `/root/verifier_scope` of
`OBLIGATION-ROOT-L3-EXT-0006-LENS-09`. The coordinator owns obligation
resolution, cross-lens reconciliation, any unique count, the connected repair
ledger and checkpoint publication. This packet does not claim a whole lens,
all consumers, runtime behavior, repair or product validation is complete.
No product code, tests, fixtures, macros, shaders, build scripts or runtime
probes were executed.

## Baseline and original attribution

The original 059 queue object at
`56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e`, `/entries/2773`, retains status
`own-lens-proof-qualification-or-read-pending`, zero foreign/body/population
credit and a false implementation gate. It requires independently qualified
Lens 9 evidence for all 272 lines of
`crates/adventuresim-tactical-client/src/presentation/buildings/streaming.rs`
at frozen `6533e444fa37552927070cc8d8190907fd3b413e` and at e275
`e2755a732c84e67296b5e3441a4259a84f461b2f`. That file and pinned authoritative
`95e63628f9d70b8dd6e6fede64334696c6995009` (95e) are byte-identical, with
SHA-256 `b8091bd1fe336c7162f6fcc4729bdd1e16cadf288fafe8ad4092029e2ea1fcc4`,
Git blob `9aaf45ca388bbd233c1251e26f8e108cc847dbf2`, 9,404 bytes and EOF
272. This identity is for the file, not the whole tree. Four of the 19
captured supporting files differ between e275 and 95e: both selected diffs
are captured and displayed in `SUPPORT-DELTA.diff` and
`REGIONAL-DELTA.diff`. The review uses 95e behavior, not an assumption of
whole-tree equality.

The full original and reconstructed 059 queue streams differ; the q2773
selected byte slices match. The root's earlier prospective and personal
untruncated 6533 Lens 3 read and the e275 same-Lens 3 reuse registration have
their original attribution. The earlier Adler Lens 11 registration also
covers 1–272, and the recovered Segovb Lens 12 record credits its own full
6533 read; none transfers a verdict or personal reading credit to Lens 9.
Three directly hash-cited root records, the hash-cited Adler registration,
and two hash-cited Segovb records were recovered exactly. Adler's
`READ-L11-216.json` is cited by relative name without an expected full-file
hash in the selected source: its newly measured hash and same-machine
transport match do not retroactively authenticate that citation. These seven
records match same-machine transport metadata 7/7; that is not independent
custody and does not establish complete transitive recovery. The original
status is historical and nothing is promoted into checkpoint 3821.

The fresh own-Lens 9 registration precedes two numbered displays covering
1–272. Thirty-one recorded displays cover 2,780 distinct lines across 20
captured files, leaving 1,615 support lines unread; precise display windows are
all covered. Overlaps count once. `SOURCE-READ-RECEIPT.json` preserves exact
source/range/registration identities and timestamps. Hashes and file times
support integrity and order, not comprehension. Source test bodies were read
as text only; they were not run.

## State shapes, transitions and consumers

1. **Queue attempt outcome.** `streaming.rs:10–22,24–96` retains placements,
   original total, optional last sorting focus and the first optional failure.
   `advance` pops each outstanding entry at most once per pass:
   `Ok(true)` drops it as processed, `Ok(false)` requeues it, and `Err`
   records the first formatted failure and drops that placement while visiting
   other work. Its private semantic callback is `Result<bool>`, where the
   Boolean selects ready versus waiting rather than serving as an ordinary
   predicate. A future named `Ready`/`Waiting` outcome inside the fallible
   boundary would state that role. But `CityBuildingAssets::spawn` currently
   reaches `Ok(true)` or `Err` only (`:179–231`), and the `Ok(false)` example is
   source test text (`:117–142`), not a demonstrated production retry path.
   It is an unresolved contract choice whether future delayed preparation is
   required; if it is not, removing the unused Boolean and using a simpler
   fallible success result may fit better. Do not invent a reachable wait or
   claim an implementation direction is settled.

2. **Failure is an independent retained observation.** `completed()` is
   `total - remaining` and therefore counts removed failures as processed;
   `finished()` means the queue is empty, not that every placement succeeded.
   A prior failure can coexist with pending placements and with a drained
   queue; a single mutually exclusive loading/failed phase that erases that
   observation would change behavior. The first `Display`-formatted error
   loses owned native cause and the failed placement at `:57–60,79–90`.
   That is the already retained Adler 059 q67 failure-ownership contract,
   independently re-examined as 31e ledger row 231. The 059 ledger and
   hash-cited Segovb Lens 12 records already explicitly note that actual
   frozen production spawn has no `Ok(false)`, so this packet does not claim
   that observation as a new historical finding. The focus `Option<Vec2>` is
   a real optional last-prioritization history, not paired with a redundant
   initialization Boolean; its native frame/finite owner remains the
   separately attributed q2356 question. Optional establishment/sign inputs
   and `BuildingDetail`/`PlacementAppearance` have separate meanings; do not
   mechanically merge them into queue failure state.

3. **Loading and GPU publication are distinct axes.** `buildings.rs:195–227`
   and `buildings/strategic.rs:4–24` construct the queue on separate paths;
   `buildings/signs.rs:12–21` schedules its producer, and
   `demo_lifecycle.rs:19–27` removes the scene resource. The selected
   `art_demo.rs:244–307` maps unfinished work to `Loading` and, once drained,
   a retained failure to `Unavailable`; later scene asset loading can override
   this status. Delaying a known error while other work continues and the
   precedence between independent asset phases remain policy questions, not
   an observed incident. Earlier Segovb support expressly rejected the
   narrower claim that this exact frozen branch certifies Ready solely because
   a failed queue drained; the current selected file is byte-identical.
   `strategic_scene/status.rs:125–190,194–206` computes installation/complete
   from queue drain and independent scene, equipment, GPU and pipeline
   conditions while exporting the city error separately. Thus a conditional
   `ready` and error combination is representable if the other conditions
   become true; it is not evidence of a live incident or proof that degraded
   readiness is forbidden. Current 31e row 232 retains that separate Lens 8
   policy/reachability question.

   The GPU queue already uses `PlacementAppearance::Primary(id)` and
   `::Distant(placement)` to own appearance payloads
   (`gpu/assembly/input.rs:11–33,52–83`). Candidate-root publication and
   candidate-root failure are separate ECS components
   (`gpu/assembly.rs:70–88,264–325`); the regional consumer waits for the
   exact root's published marker and owner readiness, or handles its failure
   (`regional_map/city.rs:256–283`). Failure inserts its marker without a
   general syntactic guarantee that a published marker cannot coexist; the
   selected normal replacement constructs a fresh root
   (`regional_map/city/installation.rs:81–114`), so no supported coexistence
   is demonstrated. GPU `READY` is another independent render-stage observation:
   the selected compute path sets it after recording dispatches
   (`gpu/compute.rs:340–404`), not a proof of device execution or success.
   Existing 31e rows 228–229 retain source, native, scheduling and readiness
   questions; no automatic alias or unique count is assigned.

4. **Connected regional installation state/payload shape.** The same assembler's
   regional candidate consumer stores `InstallationStatus { preparation,
   phase, error }` with `phase = Preparing | Ready | Failed` and
   `error: Option<InstallationFailure>` (`regional_map/city.rs:25–81`). The
   type can express `Failed` with no error or `Ready`/`Preparing` with one.
   In the selected producers, a resident or replacement status initializes
   `error: None`, the failure constructor pairs `Failed` with `Some(error)`,
   and the settle transition changes `Preparing` to `Ready`
   (`city/installation.rs:11–41`; `city.rs:234–249,256–266`). No selected
   transition produces an invalid pair; no supported invalid runtime state is
   established. This is a representable state-shape gap, connected to but
   distinct from the streaming failure-ownership operation. A concrete future
   direction is a state enum such as `Preparing`, `Ready`, and
   `Failed(InstallationFailure)`, retaining the preparation ticket alongside
   it. `Option<InstallationStatus>` can still express no installation request;
   the old installed city, candidate and visible/settled observations remain
   independent because a new candidate can be pending or fail while an old
   city remains resident. The actual status serializer
   (`regional_map/status.rs:20–43,160–176`) and browser consumer
   (`regional-city-installation.js:5–35`) use the ticket, `phase`, and failure
   `error`. Any later change must deliberately implement the final wire shape
   and update its actual consumers together, rather than assume enum serialization
   preserves the existing fields. This is a design recommendation, not a repair
   or a finding-count decision.

## Historical relationships and remaining work

The packet preserves original and reconstructed exact queue slices for q67,
q1293, q1295, q1297, q1299, q2356, q2359 and q2703; each selected slice
matches while whole streams differ. The related 059 failure-ledger objects
are structurally equal reserializations, not raw byte slices. q2703 retains
an earlier Lens 3 observation that the queue's internal constructor/advance
make subtraction safe, but its public(crate) `total` writers and broader
admission remain open; this review does not assert a global writer census.
q2359 is a distinct GPU native-identity field classification, not proof of
native rendering or error propagation.

The six selected ledger rows are from the exact published 31e checkpoint
`31e130bfa8f8914f759c7d5cddc3db92962704c7`, SHA-256
`b10132337fad5f1cf91fbd23c01a3ed4330793e79aac65ec4921aece591d1c50`;
they are reserialized selected objects, not raw slices. Row 239 is a
separate regional city graphics identity question, not automatically the
phase/error shape above. A bounded 31e metadata/body search for exact
`InstallationStatus`, `InstallationPhase`, `city_installation` and the
regional city source path returned no matches; this does not rule out an
indirectly named record, other checkpoint or semantic alias.

Open scope includes all unexamined supporting lines and producers, native GPU
and framework semantics, error reachability, authority/identity across
requests, rollback/scheduling, downstream status consumers and intended
partial-failure, retry and wire policy. A later acceptance decision should
require (a) an explicit outcome and failure ownership preserving intentional
continuation, (b) failure-bearing installation state that cannot pair an
incompatible phase and payload, and (c) agreed, coherent status projection
through the actual browser boundary, while retaining old-city and independent
GPU/scene readiness semantics. These are audit requirements for later work,
not authorization to implement or validate a product.

`VERIFY-EVIDENCE.py` verifies this packet and optionally checks exact Git,
transport and 31e anchor inputs. The separate seal binds bounded private-input
and pattern scans; it cannot prove privacy or independent public custody.
