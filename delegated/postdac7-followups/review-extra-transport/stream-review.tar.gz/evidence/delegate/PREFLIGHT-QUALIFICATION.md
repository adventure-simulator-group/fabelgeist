# Preflight qualification

Before `MANIFEST.json` existed, an in-memory preflight of
`VERIFY-EVIDENCE.py` replaced only `check_manifest()` with a no-op. Its first
generic PASS line still mentioned the manifest and did not verify it during
that preflight. Only the separately sealed unmodified standalone and full runs
after manifest creation assert packet-manifest integrity. The checks execute
evidence verification only and do not run product code.
