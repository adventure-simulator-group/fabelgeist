# Bounded independent review evidence

REPORT.json records the assessed claims, corrections, source references, chronology, and limitations. PRIVATE-EVIDENCE.aesgcm contains authenticated exact originals and a byte/mode inventory. The separately held key is required and is same-machine restricted custody, not independent public recovery.

Run `python3 VERIFY-EVIDENCE.py` for public file identities. With the separately held AES key and `cryptography`, add `--key KEY_PATH`; add `--git GIT_CHECKOUT` to verify independently retained Git revision/path content. This executes only evidence-verification code; it does not execute product, tests, fixtures, macros, shaders or runtime probes. Full commit ancestry/provenance, user reachability and active native features remain external or unproved.

The q2748 packet was staged after dac7d. The original q2748/q2750 reads share an author despite separate lens readings. Do not transfer historical lens credit, infer global aliases or claim checkpoint 3821 recovery.
