#!/usr/bin/env python3
"""Evidence-only verifier: public integrity; optional private recovery and Git binding."""
import argparse, hashlib, io, json, os, pathlib, re, subprocess, tarfile

def sha(b): return hashlib.sha256(b).hexdigest()
def need(x, m):
    if not x: raise SystemExit('FAIL: '+m)
def obj(b): return json.loads(b)
parser=argparse.ArgumentParser()
parser.add_argument('--key',help='separately held AES key')
parser.add_argument('--git',help='separately held Git checkout holding all named revisions; requires --key')
a=parser.parse_args(); here=pathlib.Path(__file__).resolve().parent
manifest=obj((here/'PUBLIC-MANIFEST.json').read_bytes())
for row in manifest['files']:
    name=row['path']; need('/' not in name and '\\' not in name and name not in ('.','..'),'unsafe public name')
    b=(here/name).read_bytes(); need(len(b)==row['bytes'] and sha(b)==row['sha256'],'public integrity '+name)
print('public integrity:',len(manifest['files']),'files')
need(not a.git or a.key, '--git requires --key')
if not a.key:
    print('Private originals, semantic evidence checks, archive and Git bindings not checked; key is separate same-machine custody.')
    raise SystemExit(0)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
key=pathlib.Path(a.key).read_bytes();need(len(key)==32,'AES key length')
c=(here/'PRIVATE-EVIDENCE.aesgcm').read_bytes(); magic=b'726CENTRALv1\0';need(c.startswith(magic),'cipher header')
nonce=c[len(magic):len(magic)+12]; payload=AESGCM(key).decrypt(nonce,c[len(magic)+12:],b'726-central-four-review-v1')
t=tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz'); members=t.getmembers();names=[m.name for m in members]
need(len(names)==len(set(names)) and all(m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts for m in members),'private tar members')
files={m.name:t.extractfile(m).read() for m in members};pm=obj(files['PRIVATE-MANIFEST.json']); expected={x['path']:x for x in pm['files']};need(set(files)-{'PRIVATE-MANIFEST.json'}==set(expected),'private member set')
for name,row in expected.items():
    data=files[name];need(len(data)==row['bytes'] and sha(data)==row['sha256'],'private integrity '+name)
print('authenticated private files:',len(expected))
p=lambda n:files['review/'+n]
q1=obj(files['git/56f-queue.json']);q2=obj(files['git/0a-queue.json'])
wanted=(2697,2701,2708,2734,2747,2750,2934)
def spans(raw):
    text=raw.decode(); match=re.search(r'"entries"\s*:\s*\[',text);need(match is not None,'queue entries locator')
    pos=match.end(); dec=json.JSONDecoder(); result={}
    for i in range(max(wanted)+1):
        while text[pos].isspace() or text[pos]==',':pos+=1
        start=pos; _,pos=dec.raw_decode(text,pos)
        if i in wanted:result[i]=text[start:pos].encode()
    return result
span1=spans(files['git/56f-queue.json']);span2=spans(files['git/0a-queue.json'])
for i in wanted:need(q1['entries'][i]==q2['entries'][i] and span1[i]==span2[i],'exact queue object equality '+str(i))
q=q1['entries'][2701];need(q['named_scope_discovery_complete'] is True and q['frozen_named_scope_discovery_complete'] is False and q['current_reconciled'] is False and q['canonical_finding_id']=='SEGOVB-L3-TEXTURE-RECIPE-CHANNEL-ADMISSION','q2701 flags')
for i in (2701,2934):need(obj(p('HIST-original-q'+str(i)+'.json'))==q1['entries'][i] and p('HIST-original-q'+str(i)+'.json')==p('HIST-reconstructed-q'+str(i)+'.json') and p('HIST-original-q'+str(i)+'.json').strip()==span1[i],'historical selection '+str(i))
def changed(a,b,path=''):
    if type(a)!=type(b):return {path}
    if isinstance(a,dict):
        out=set()
        for k in set(a)|set(b):
            child=path+'/'+k
            out |= {child} if k not in a or k not in b else changed(a[k],b[k],child)
        return out
    if isinstance(a,list):
        out={path+'/length'} if len(a)!=len(b) else set()
        for i,(x,y) in enumerate(zip(a,b)):out |= changed(x,y,path+'/'+str(i))
        return out
    return {path} if a!=b else set()
for n,old,new,paths in [('V4-COMPARISON.json','DRAFT-0.dat','V4-0.dat',{'/assessments/1/history','/corrected_utc','/supersedes_draft_sha256'}),('V5-COMPARISON.json','V4-0.dat','V5-0.dat',{'/assessments/0/history','/corrected_utc','/supersedes_draft_sha256'}),('MATERIAL-V2-COMPARISON.json','DRAFT-1.dat','MATERIAL-V2.dat',{'/assessments/1/delta_and_conditional','/assessments/1/relations','/corrected_utc','/supersedes_draft_sha256'})]:
    need({x[0] for x in obj(p(n))['differences']}==paths and changed(obj(p(old)),obj(p(new)))==paths,'successor differences '+n)
    need(obj(p(new))['supersedes_draft_sha256']==sha(p(old)),'successor predecessor '+n)
qmanifest=obj(p('Q2748-MANIFEST.dat'));qr=p('Q2748-REPORT.dat');r=next(x for x in qmanifest['files'] if x['path']=='REPORT.json');need(sha(qr)==r['sha256'] and len(qr)==r['bytes'],'q2748 report manifest')
for group,capture in [('primary','META-primary-CAPTURE.json'),('material','META-material-CAPTURE.json'),('native','META-material-NATIVE-CAPTURE.json')]:
    cat='coordinator-primary/' if group=='primary' else 'coordinator-material/'
    for row in obj(p(capture))['rows']:
        lines=files[cat+row['label']+'.source'].decode().splitlines()
        for d in row['displays']:
            data=files[cat+d['file']]; want=''.join(f'{i}: {lines[i-1]}\n' for i in range(d['start'],d['end']+1)).encode()
            need(data==want and sha(data)==d['sha256'],'display '+d['file'])
print('selected queues, q2701 flags, successor receipts, q2748 manifest and registered display bytes: verified')
# Archive bytes must match the pinned lock, and selected members must match captures.
import tomllib
lock=tomllib.loads(files['git/95e-Cargo.lock'].decode()); packages={x['name']:x for x in lock['package'] if x['name'] in ('bevy_app','bevy_pbr') and x['version']=='0.19.1'}
for crate in ('bevy_app','bevy_pbr'):
    b=files['native/'+crate+'-0.19.1.crate'];need(sha(b)==packages[crate]['checksum'],'locked archive '+crate)
    ar=tarfile.open(fileobj=io.BytesIO(b),mode='r:gz')
    members={'bevy_app':{'app':'src/app.rs','plugin':'src/plugin.rs'},'bevy_pbr':{'material':'src/material.rs'}}[crate]
    for label,path in members.items():need(ar.extractfile(crate+'-0.19.1/'+path).read()==p('NATIVE-bevy-'+label+'.dat'),'archive member '+path)
print('locked Bevy archive and member identities: verified; activated features and runtime are not checked')
if a.git:
    env=dict(os.environ,GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
    def git(rev,path):return subprocess.check_output(['git','-C',a.git,'show',rev+':'+path],env=env,stderr=subprocess.DEVNULL)
    for row in pm['files']:
        if row.get('git_revision'):need(git(row['git_revision'],row['git_path'])==files[row['path']],'git binding '+row['path'])
    for row in obj(p('PERSONAL-SOURCE-CAPTURES.json'))['source_rows']:
        need(git('95e63628f9d70b8dd6e6fede64334696c6995009',row['path'])==p(row['artifact']),'current source Git binding '+row['label'])
    for rev in ('6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f'):
        need(git(rev,'crates/adventuresim-procedural-textures/src/runtime.rs')==p('SRC-historical-runtime.dat'),'historical runtime '+rev[:4])
        need(git(rev,'crates/adventuresim-tactical-client/src/presentation/materials.rs')==p('SRC-historical-materials.dat'),'historical materials '+rev[:4])
    print('external Git content bindings: verified; no global tree equality or checkpoint3821 claim')
else: print('external Git content bindings not checked (supply --git and retain immutable objects).')
