#!/usr/bin/env python3
"""Replay q2721 evidence only; no product code or product parser."""
import argparse,json
from pathlib import Path
from hashlib import sha1,sha256
S=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--prior',type=Path);ap.add_argument('--v4',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');args=ap.parse_args()
def read(p):return (S/p).read_bytes()
def load(p):return json.loads(read(p))
def gh(k,b):return sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def ents(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);ze=b.index(b'\0',sp+1);d[b[sp+1:ze].decode()]=(b[i:sp].decode(),b[ze+1:ze+21].hex());i=ze+21
 return d
def diff(a,b,p=''):
 if isinstance(a,dict) and isinstance(b,dict):
  for k in set(a)|set(b):
   q=p+'/'+k.replace('~','~0').replace('/','~1')
   if k not in a or k not in b:yield q
   else:yield from diff(a[k],b[k],q)
 elif isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):yield p
  for i,(x,y) in enumerate(zip(a,b)):yield from diff(x,y,p+'/'+str(i))
 elif type(a)!=type(b) or a!=b:yield p
def check_manifest(root,expected):
 raw=(root/'MANIFEST.json').read_bytes();assert sha256(raw).hexdigest()==expected;m=json.loads(raw);actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};assert actual=={r['path'] for r in m['files']}
 for r in m['files']:
  p=root/r['path'];b=p.read_bytes();assert len(b)==r['bytes'] and sha256(b).hexdigest()==r['sha256'] and p.stat().st_mode & 0o777==r['mode']
if not args.skip_manifest:
 m=load('MANIFEST.json');actual={p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};assert actual=={r['path'] for r in m['files']}
 for r in m['files']:
  b=read(r['path']);assert len(b)==r['bytes'] and sha256(b).hexdigest()==r['sha256']
proof=load('SOURCE-PROOF.json')
for row in proof['paths']:
 raw=read(row['source']);assert sha256(raw).hexdigest()==row['sha256'] and gh('blob',raw)==row['blob'];oid=proof['commit_roots'][row['revision']]
 for step in row['chain']:
  assert step['tree']==oid;b=read('trees/'+oid+'.tree');assert gh('tree',b)==oid;mode,oid=ents(b)[step['component']];assert mode==step['mode'] and oid==step['oid']
 assert oid==row['blob']
for row in load('DISPLAY-MAP.json')['displays']:
 lines=read(row['source']).decode().splitlines();lo,hi=row['range'];out=''.join(f'{i}: {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert read(row['file'])==out
cat=load('CATALOG-CHECK-011.json');raw=read('trees/'+cat['tree_oid']+'.tree');assert gh('tree',raw)==cat['tree_oid'];actual=[{'name':k,'mode':v[0],'oid':v[1]} for k,v in sorted(ents(raw).items())];assert actual==cat['all_immediate_tree_entries'];assert [x for x in actual if x['name'].endswith('.yaml')]==cat['selected_yaml']
prompts=[]
def walk(obj):
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k=='prompt' and isinstance(v,dict):prompts.append(v.get('mode','<missing>'))
   walk(v)
 elif isinstance(obj,list):
  for x in obj:walk(x)
for n in ('AUTHORED-000.dat','AUTHORED-001.dat','AUTHORED-002.dat'):walk(load('source/'+n))
assert len(prompts)==8 and prompts.count('single')==1 and prompts.count('yes_no')==7
summary=load('V4-SUMMARY.json')
if args.anchors and not args.prior:ap.error('--anchors requires --prior')
if args.prior:
 check_manifest(args.prior,summary['restricted_review_manifest_sha256'])
 oldb=(args.prior/'PRIVATE-draft.bin').read_bytes();newb=(args.prior/'PRIVATE-draft-v3.json').read_bytes();corr=json.loads((args.prior/'PRIVATE-draft-correction.json').read_bytes());assert sha256(oldb).hexdigest()==summary['draft_v2_sha256']==corr['old_draft_sha256'] and sha256(newb).hexdigest()==summary['draft_v3_sha256']==corr['new_draft_sha256'];old=json.loads(oldb);new=json.loads(newb)
 for i,key in [(1,'ballot_observation'),(2,'claim_observation')]:assert old['assessments'][i]['observation']==corr['old'][key] and new['assessments'][i]['observation']==corr['new'][key]
 assert set(diff(old,new))=={'/assessments/1/observation','/assessments/2/observation','/corrected_utc','/supersedes_draft_sha256'}
 for label,oid in [('95e','95e63628f9d70b8dd6e6fede64334696c6995009'),('6533','6533e444fa37552927070cc8d8190907fd3b413e'),('e275','e2755a732c84e67296b5e3441a4259a84f461b2f')]:
  b=(args.prior/('PRIVATE-'+label+'.commit')).read_bytes();assert gh('commit',b)==oid and b.split(b'\n',1)[0].split(b' ')[1].decode()==proof['commit_roots'][oid]
 b=(args.prior/'PRIVATE-git-commit.stdout').read_bytes();assert gh('commit',b)==summary['current_ledger_commit'];root=b.split(b'\n',1)[0].split(b' ')[1].decode();tree=(args.prior/'PRIVATE-git-root-tree.stdout').read_bytes();assert gh('tree',tree)==root;mode,oid=ents(tree)['BASELINE-95E-20261110.json'];ledger=(args.prior/'PRIVATE-git-ledger.stdout').read_bytes();assert mode=='100644' and gh('blob',ledger)==oid and sha256(ledger).hexdigest()==summary['current_ledger_sha256'];rows=json.loads(ledger)['newly_assessed_ledger']['entries']
 for i in (14,104):assert rows[i]==load('ledger/ROW-'+str(i)+'.json')
 hist=(args.prior/'PRIVATE-hist-e275-read.json').read_bytes();assert sha256(hist).hexdigest()==summary['separate_historical_receipt_sha256'];row=json.loads(hist)['rows'][1];assert row['fresh_personal_ranges']==[] and row['qualified_reuse_ranges']==[[1,1095]]
 if args.anchors:
  e=args.prior/'delegated-packet/evidence';history=json.loads((e/'HISTORY-IDENTITIES.json').read_bytes())
  for r in history:
   n='original-059-queue.json' if r['role']=='original' else 'reconstructed-059-queue.json';whole=(args.anchors/n).read_bytes();span=(e/r['capture']).read_bytes();assert sha256(whole).hexdigest()==r['stream_sha256'];assert whole[r['entry_start_byte']:r['entry_end_byte_exclusive']]==span;assert json.loads(whole)['entries'][2721]==json.loads(span)
if args.v4:
 check_manifest(args.v4,summary['restricted_v4_manifest_sha256']);v3=(args.v4/'PRIVATE-v3.json').read_bytes();v4=(args.v4/'PRIVATE-v4.json').read_bytes();corr=(args.v4/'PRIVATE-correction.json').read_bytes();assert sha256(v3).hexdigest()==summary['draft_v3_sha256'] and sha256(v4).hexdigest()==summary['draft_v4_sha256'] and sha256(corr).hexdigest()==summary['v4_correction_sha256'];old=json.loads(v3);new=json.loads(v4);c=json.loads(corr)
 for key,ov,nv in [('historical_qualification',old['historical_qualification'],new['historical_qualification']),('ballot_observation',old['assessments'][1]['observation'],new['assessments'][1]['observation'])]:assert ov==c['old'][key] and nv==c['new'][key]
 assert set(diff(old,new))=={'/assessments/1/observation','/historical_qualification','/corrected_utc','/supersedes_draft_sha256'}
print('PASS: '+('pre-seal source/tree/display/catalog checks; manifest not checked' if args.skip_manifest else 'public manifest, source/tree/display/catalog checks'))
print('Commit, ledger and historical originals: '+('PASS' if args.prior else 'NOT CHECKED; provide separately held --prior.'))
print('V4 exact draft correction: '+('PASS' if args.v4 else 'NOT CHECKED; provide separately held --v4.'))
print('Full queue membership: '+('PASS' if args.anchors else 'NOT CHECKED; provide --prior and separately held --anchors.'))
print('No product code, tests, fixtures, builds or runtime probes executed.')
