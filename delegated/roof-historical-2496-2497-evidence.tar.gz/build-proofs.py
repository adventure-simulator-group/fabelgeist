from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objects={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind):
 raw=(r/local).read_bytes();root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw)})
reg=json.loads((r/'registration.json').read_bytes())
for x in reg['rows']:
 old,cur=x['versions'];proof(old['comparison_revision'],old['path'],old['local'],'6533 per-file membership only, not whole pr-working snapshot cleanliness');proof(cur['comparison_revision'],cur['path'],cur['local'],'pinned 95e body');proof(x['transport_revision'],x['transport_path'],old['local'],'exact original registry object via f82 evidence transport')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-roof-historical-2496-2497-git-proofs-v1','objects':objects,'proofs':proofs,'qualification':'Six commit/tree paths prove exact named files and f82 transported evidence; no whole-tree cleanliness or checkpoint3821 claim.'},indent=2)+'\n');print('chains',len(proofs),'objects',len(objects),'sha256',h((r/'git-proofs.json').read_bytes()))
