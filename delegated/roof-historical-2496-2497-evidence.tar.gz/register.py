from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');recovered=Path('<LOCAL_PATH_1>');cur='95e63628f9d70b8dd6e6fede64334696c6995009';base='6533e444fa37552927070cc8d8190907fd3b413e';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';h=lambda b:hashlib.sha256(b).hexdigest();raw=gzip.decompress((recovered/'registry.json.gz').read_bytes());assert h(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);rows=[];contents={}
with tarfile.open(recovered/'objects.tar.gz','r:gz') as tar:
 for i in (2496,2497):
  row=reg['files'][i];path=row['source_id'].split(':',1)[1];old=tar.extractfile(row['sha256']).read();assert h(old)==row['sha256'];op='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];assert old==subprocess.check_output(['git','-C',str(pub),'show',f82+':'+op]);versions=[]
  for rev,tag in [(base,'historical'),(cur,'current')]:
   b=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+path],text=True).strip();local=f'source/{i}-{tag}.rs';contents[local]=old if tag=='historical' else b;assert b==old
   versions.append({'revision':('recovered pr-working object; per-file equals '+base if tag=='historical' else rev),'comparison_revision':rev,'path':path,'local':local,'sha256':h(contents[local]),'git_blob':blob,'bytes':len(b),'eof':len(b.splitlines()),'prospective_ranges':[[1,len(b.splitlines())]],'qualification':('Old 6533-based pr-working snapshot has unrelated modifications; equality is per-file only and f82 is transport.' if tag=='historical' else 'Pinned current project source. Separate display required despite byte equality.')})
  rows.append({'original_index':i,'source_id':row['source_id'],'snapshot':row['snapshot'],'registry_row':row,'transport_revision':f82,'transport_path':op,'versions':versions})
d={'schema':'726-roof-historical-repeat-prospective-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','baseline':cur,'rows':rows,'prior_same_agent':'Prior 2496/2497 packet 95e fully displayed but historical copies archived without display; preserve that receipt unchanged, do not transfer its historical credit.','qualification':'Prospectively register independent displays of exact recovered historical and pinned current byte-identical copies. Source and evidence only; test source text never run.'}
with (r/'registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for path,b in contents.items():(r/path).parent.mkdir(parents=True,exist_ok=True);(r/path).write_bytes(b)
print('registered',d['registered_utc'],'sha256',h((r/'registration.json').read_bytes()))
for x in rows:print(x['original_index'],[(v['local'],v['sha256'],v['eof'],v['git_blob']) for v in x['versions']])
