'''Offline evidence-integrity checks only; no geometry or product execution.'''
from pathlib import Path
import gzip,hashlib,json,tarfile
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((r/'registration.json').read_bytes());hist=json.loads((r/'historical-manifest.json').read_bytes());sel=json.loads((r/'historical-selections-reconstructed.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());proof=json.loads((r/'git-proofs.json').read_bytes());report=json.loads((r/'REPORT.json').read_bytes())
assert h((r/'registration.json').read_bytes())==rec['registration_sha256']
for x in hist['records']:
 b=(r/x['local']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
p=r/hist['prior_packet']['local'];prior=json.loads((p/'packet-manifest.json').read_bytes());assert h((p/'packet-manifest.json').read_bytes())==hist['prior_packet']['manifest_sha256'] and len(prior['files'])==hist['prior_packet']['files_verified']
for x in prior['files']:
 b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
assert h((p/'report.json').read_bytes())==hist['prior_packet']['report_sha256'] and h((p/'read-receipt.json').read_bytes())==hist['prior_packet']['receipt_sha256']
previous=json.loads((p/'read-receipt.json').read_bytes());assert all(not x['historical_displayed_windows'] and x['byte_equality_verified'] for x in previous['roles'])
rr=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());registry=json.loads(rr);assert h(rr)==sel['registry_uncompressed_sha256'];m=json.loads((r/'recovered/MANIFEST.json').read_bytes());assert h((r/'recovered/objects.tar.gz').read_bytes())==m['objects_archive_sha256'] and h((r/'recovered/registry.json.gz').read_bytes())==m['registry_gzip_sha256'];qr=gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qr);assert h(qr)==sel['queue_uncompressed_sha256']
for i,row in sel['registry_rows'].items():assert row==registry['files'][int(i)]
for i,row in sel['queue_rows'].items():assert row==q['entries'][int(i)]
with tarfile.open(r/'recovered/objects.tar.gz','r:gz') as tar:
 for row in reg['rows']:
  old,cur=row['versions'];b=(r/old['local']).read_bytes();assert b==(r/cur['local']).read_bytes()==tar.extractfile(registry['files'][row['original_index']]['sha256']).read() and h(b)==old['sha256']==cur['sha256'];assert len(b.splitlines())==old['eof']==cur['eof']
for x in rec['reads']:
 b=(r/x['source']).read_bytes();assert h(b)==x['sha256'] and len(b.splitlines())==x['eof'];occ=[]
 for lo,hi in x['display_union']+x['unread_complement']:
  assert 1<=lo<=hi<=x['eof'];occ.extend(range(lo,hi+1))
 assert len(occ)==x['eof'] and set(occ)==set(range(1,x['eof']+1));row=next(y for y in reg['rows'] if y['original_index']==x['original_index']);v=next(y for y in row['versions'] if y['local']==x['source']);assert x['display_union']==v['prospective_ranges']
assert len(rec['reads'])==4
cont=json.loads((p/'historical/774/audit/reconcile-adler-20261023/audit-continuation/redundant-authority/contract-578.json').read_bytes())
for i in (2496,2497):
 s=next(x for x in cont['sources'] if x['scope_index']==i);v=next(x for x in reg['rows'] if x['original_index']==i)['versions'][0];assert s['sha256']==v['sha256'] and s['ranges']==[[1,v['eof']]]
l11=json.loads((p/'historical/059/segovb/READ-L11-414.json').read_bytes())
for i in (2496,2497):
 s=next(x for x in l11['sources'] if x['original_index']==i);v=next(x for x in reg['rows'] if x['original_index']==i)['versions'][0];assert s['sha256']==v['sha256'] and s['assessed_ranges']==[[1,v['eof']]]
objs={}
for k,x in proof['objects'].items():
 b=gzip.decompress((r/x['preserved']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'] and oid(x['type'],b)==k;objs[k]=b
def lookup(b,name):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,n=b[i:z].split(b' ',1);child=b[z+1:z+21].hex();i=z+21
  if n.decode()==name:return mode.decode(),child
 raise KeyError(name)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for node in x['chain']:
  assert tree==node['tree'];mode,child=lookup(objs[tree],node['name']);assert mode==node['mode'] and child==node['object'];tree=child
 b=(r/x['local']).read_bytes();assert oid('blob',b)==tree==x['blob'] and h(b)==x['sha256']
assert len(report['lens_perspectives'])==13 and report['implementation']=='not started'
if (r/'MANIFEST.json').exists():
 manifest=json.loads((r/'MANIFEST.json').read_bytes());files={str(x.relative_to(r)) for x in r.rglob('*') if x.is_file() and x!=r/'MANIFEST.json'};assert files=={x['path'] for x in manifest['files']}
 for x in manifest['files']:
  b=(r/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
print('PASS: 4 separate full source display partitions, exact registry/transport objects, prior packet 230-file manifest, preserved 774/059 scopes, 6 offline Git chains, 13 bounded prior perspectives, current packet manifest if present. No product or geometry execution.')
