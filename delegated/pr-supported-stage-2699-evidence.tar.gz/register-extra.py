from pathlib import Path
import datetime,hashlib,json,subprocess
p=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda b:hashlib.sha256(b).hexdigest();base='crates/adventuresim-tactical-core/src/'
spec=[('scene_input',base+'scene_input.rs',[[140,200]]),('settlement',base+'city_layout/grounding/foundations/settlement.rs',[[150,240]])];entries=[]
for name,path,rr in spec:
 b=git('show',rev+':'+path);n=len(b.splitlines());fn='support/'+name+'.rs';(p/fn).write_bytes(b);entries.append({'name':name,'path':path,'revision':rev,'sha256':sha(b),'git_blob':git('rev-parse',rev+':'+path).decode().strip(),'bytes':len(b),'actual_EOF':n,'registered_ranges':[[a,min(z,n)] for a,z in rr if a<=n],'source_archive':fn})
x={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/mhr_character','kind':'Prospective independent current connected support; no original-role credit','entries':entries};(p/'extra-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(sha((p/'extra-registration.json').read_bytes()),[(e['name'],e['actual_EOF'],e['registered_ranges']) for e in entries])
