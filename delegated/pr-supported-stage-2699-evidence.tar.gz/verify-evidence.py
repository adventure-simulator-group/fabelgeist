#!/usr/bin/env python3
"""Verify preserved evidence and scoped read receipts; no product execution."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');rc=load('personal-read-receipt.json');assert rc['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<rc['recorded_utc'] and len(rc['actual_displays'])==len(r['entries'])==2
for e,x in zip(r['entries'],rc['actual_displays']):
 b=(p/e['source_archive']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['source_archive']==e['source_archive'] and x['revision']==e['revision'] and x['chunks']==e['planned_chunks']==[[1,56]] and not x['unread_complement']
a,b=r['entries'];assert a['original_material_ranges']==[[1,56]] and a['sha256']==b['sha256'] and a['git_blob']==b['git_blob'] and a['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and b['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009';checks.append('Separate prospectively registered full historic and current assigned displays')
scopes={}
for stem in ['support','extra','surface']:
 sr=load(stem+'-registration.json');rc=load(stem+'-read-receipt.json');assert rc['registration_sha256']==sha((p/(stem+'-registration.json')).read_bytes()) and sr['registered_utc']<rc['recorded_utc'] and len(sr['entries'])==len(rc['actual_displays'])
 for e,x in zip(sr['entries'],rc['actual_displays']):
  b=(p/e['source_archive']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['displayed_chunks']==e['registered_ranges'] and x['source_archive']==e['source_archive'];d=scopes.setdefault(e['source_archive'],set())
  for a,z in e['registered_ranges']:d.update(range(a,z+1))
for file,e in load('read-scope-summary.json')['support'].items():
 actual={i for a,z in e['displayed_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert actual==scopes[file] and not actual&unread and actual|unread==set(range(1,e['EOF']+1))
checks.append('Eleven independent current support bodies and exact displayed/unread ranges')
assigned=r['entries'][0]
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['original_registry_sha256_uncompressed']==sha(raw) and sel['rows'][0]['entry']==reg['files'][2699];snap=next(x for x in reg['snapshots'] if x['id']=='pr-working');assert sel['pr_working_snapshot']==snap==r['pr_working'] and snap['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(snap['status_porcelain'])==4 and not any(s[3:]==assigned['path'] for s in snap['status_porcelain']) and reg['files'][2699]['sha256']==assigned['sha256']
assert sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));entries={x['path']:x for x in manifest['entries']};hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==15 and sum(x['kind']=='historical-774' for x in hi['records'])==5
for x in hi['records']:
 d=(p/x['file']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (len(d),sha(d),blob(d))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
assert not any('segovb/'+t+'-L12-937.json' in entries for t in ['READ','VERIFY','STATE']) and len(load('recovery-search.json')['roots'])==2
checks.append('Dirty pr-working registry, 059 transport manifest and five 774 records; 937 adoption not inferred')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];d=gzip.decompress((p/x['archive']).read_bytes());assert (len(d),sha(d),hashlib.sha1(x['type'].encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest())==(x['bytes'],x['sha256'],oid);return d
def trees(d):
 v={};i=0
 while i<len(d):
  s=d.index(b' ',i);z=d.index(b'\0',s);v[d[s+1:z].decode()]=(d[i:s].decode(),d[z+1:z+21].hex());i=z+21
 return v
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==25
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 d=(p/x['archive']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (sha(d),blob(d),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Twenty-five raw Git tree proofs including separately attributed e275 and prior 95e bodies')
rawreg=gzip.decompress((p/'history-774/root/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines();cov=gzip.decompress((p/'history-774/root/admission03/coverage.jsonl.gz').read_bytes()).splitlines();assert json.loads(rawreg[32])['id']=='ROOT-ADM-REG-033' and json.loads(cov[328])['id']=='ROOT-ADM-COVERAGE-329' and json.loads(gzip.decompress((p/'history-774/root/admission03/supported-stage-admission-048.json.gz').read_bytes()))['id']=='ROOT-ADM-G048'
adler=load('history-059/adler/READ-L11-297.json');assert next(x for x in adler['connected_reinspection'] if x['original_index']==2699)['fresh_reads']==[[1,56]];l11=load('history-059/segovb/READ-L11-440.json');row=next(x for x in l11['sources'] if x['original_index']==2699);assert row['fresh_personal_body_reads']==[] and row['same_lens_prior']['entry']['fresh_reads']==[[1,56]]
s12=load('history-059/segovb/READ-CONNECTED-L12-672-POPULATIONS.json');assert next(x for x in s12['rows'] if x.get('population_index')==2699)['fresh_personal_body_reads']==[[1,56]];partial=load('history-059/parallel-l12-20261029/PARTIAL-PAR-L12-937-003.json');row=next(x for x in partial['rows'] if x['original_index']==2699);assert row['fresh_personal_body_reads']==[[1,56]] and '/root/lens12_frontier' in row['attribution'] and 'root adoption required' in load('history-059/parallel-l12-20261029/PROPOSAL-L12-937.json')['kind'];prior=load('history-059/root-l1-current-e275-20261029/PARTIAL-ROOT-L1-CURRENT-082-001.json')['rows'][0];assert prior['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and prior['fresh_personal_body_ranges']==[[1,56]]
checks.append('774 G048/REG033; Adler personal → Segovb Lens11 reuse; independent Lens12 and e275 root historical attribution')
prior=load('prior-grounding-index.json');m=(p/'prior-grounding/BUNDLE-MANIFEST.json').read_bytes();assert sha(m)==prior['manifest_sha256']=='fb97fcfb97dfaf1da72585b46d23b9634c978543fdaf81ff7b06e1fbe6bfe21c';idx={x['path']:x for x in json.loads(m)['files']}
for x in prior['selected_records']:
 d=(p/x['file']).read_bytes();e=idx[x['prior_member']];assert (sha(d),len(d))==(x['sha256'],x['bytes'])==(e['sha256'],e['bytes'])
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert queue['entries'][int(n)]==e
for x in load('prior-evidence-index.json')['records']:
 d=(p/x['preserved_bytes']).read_bytes();assert (sha(d),len(d))==(x['sha256'],x['bytes'])
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
assert {x['number'] for x in load('report.json')['lenses']}==set(range(1,14));checks.append('Prior grounding manifest-selected members, reconstructed queue, prior 95e report, rules and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and source-read accounting only; no product validation, test, runtime probe, execution, implementation, checkpoint3821 promotion or inferred 937 adoption.'},indent=2))
