#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,subprocess
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();a=argparse.ArgumentParser()
for n in ['repo','private-manifest','replay-manifest','original-stream-manifest','original-queue','private-report']:a.add_argument('--'+n,type=Path)
args=a.parse_args();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q3000-l10-public-v1';assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
x=json.loads((p/'BINDING.json').read_bytes());s=json.loads((p/'SOURCE.json').read_bytes());b=(p/'CURRENT-SOURCE.rs').read_bytes();assert h(b)==s['sha256'] and len(b.decode().splitlines())==s['eof']==320;ls=b.decode().splitlines()
for v in s['views']:
 a,c=v['range'];expected=''.join(f'{i:4d}  {ls[i-1]}\n' for i in range(a,c+1)).encode();assert h(expected)==v['sha256'] and expected==(p/v['name']).read_bytes()
y=json.loads((p/'HISTORY.json').read_bytes());assert y['index']==3000 and y['lens']==10 and y['current_status']=='unassessed' and y['selected_equal_as_parsed'] and y['full_streams_equal'] is False;r=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert len(r['checks'])==2 and all(z['exit']==0 and z['stderr_bytes']==0 for z in r['checks']);projection=json.loads((p/'REPORT-PROJECTION.json').read_bytes());assert h((p/'REPORT.md').read_bytes())==projection['public_report_sha256']
checks=['public member identities, three current source views and recorded selection/replay'];not_checked=[]
for n,k in [('private_manifest','private_manifest_sha256'),('replay_manifest','replay_manifest_sha256'),('original_stream_manifest','original_stream_manifest_sha256'),('original_queue','original_queue_sha256')]:
 q=getattr(args,n)
 if q is None:not_checked.append(n+' not supplied')
 else:assert h(q.read_bytes())==x[k];checks.append(n+' identity')
if args.private_report is None:not_checked.append('private report projection not supplied')
else:
 raw=args.private_report.read_bytes();assert h(raw)==projection['private_report_sha256'];safe,n=re.subn(rb'/[^/\s`]+/(lens12_frontier)',rb'\1',raw);assert n==1 and safe==(p/'REPORT.md').read_bytes();checks.append('private report alias projection')
if args.repo is None:not_checked.append('Git object identities not supplied')
else:
 def git(*cmd):
  r=subprocess.run(['git','-C',str(args.repo),*cmd],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert not r.returncode and not r.stderr;return r.stdout
 for z in s['historical_objects']:
  assert git('rev-parse',z['revision']+'^{tree}').decode().strip()==z['tree'];assert git('rev-parse',z['revision']+':'+s['path']).decode().strip()==z['blob'];assert git('show',z['revision']+':'+s['path'])==b
 checks.append('three historical/current per-file Git identities')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence-only identities, not independent custody, display telemetry, runtime behavior or historical recovery.'}))
