# q3000: mission systems, Lens 10 derivability

The bounded 95e source review found no handwritten trait or custom
serialization implementation in the assigned `mission/systems.rs` file to
replace with a derive. It therefore identifies no derivability repair in this
file. This is a source-level nonfinding, not a closure of Lens 10, a defect
count, or a claim about implementations in imported types and dependencies.

The assessed product revision is
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The reviewer independently
displayed the whole registered
`crates/adventuresim-tactical-server/src/mission/systems.rs:1–320` and EOF at
95e. The file declares two aliases for Bevy query types at lines 29–50 and
free system/helper functions at 52–276. It contains no source-level `impl`,
`#[derive]`, local struct/enum/trait declaration, or custom
serialization/deserialization implementation. The existing query aliases and
functions are not handwritten trait boilerplate, so no candidate derive or
replacement dependency is asserted. A separate lexical inventory supports the
full personal read; it is not a Rust parser, macro expansion, build, or claim
about behavior generated elsewhere.

The required full-file view included the `#[cfg(test)]` module at 279–320 and
timing/receipt references elsewhere. They were read only as source in the
assigned file. No test, fixture, product code, build, repair or runtime probe
was run, and this inspection grants no timing, receipt, or other-lens coverage.
Imported mission-state, result, receipt and networking owners are outside the
bounded derivability conclusion; their contracts and any implementations in
their own files remain open.

The original 059 q3000 is
`OBLIGATION-ROOT-L3-EXT-0024-LENS-10`, with status
`own-lens-proof-qualification-or-read-pending` and no assessed Lens 10 range.
It registers 6533 lines 1–320 and an e275 revisit of the same lines. The 8b
wrapper is `unassessed`. The original and reconstructed selected objects match
as parsed, while the full queue streams differ. Source content at 6533, e275
and 95e has the same Git blob
`7bf1a2d2e98e212a0589e67f266b6d771a6de253` and SHA-256
`cc4bc873f502d3a08fc30a6f3d40d1d0752a81dfdee70651fb2c04737b64d6b8`;
their trees differ. That is per-file identity, not whole-tree equivalence or a
fresh personal historical display.

The recovered original records attribute a fresh 6533 Lens 3 read of 1–320 to
Root; the e275 Lens 3 receipt records qualified same-lens reuse of 1–320, no
fresh current reread, and requires adoption of the frozen source in the same
transaction before reuse is accepted. The earlier Lens 2 receipt separately
attributes a fresh 6533 1–320 read to Root. The Lens 12 receipt separately
attributes 6533 lines 52–320 to `lens12_frontier`. These records, and
this reviewer’s earlier q3083 Lens 9 peer window at 95e lines 45–100, do not
transfer credit to this new Lens 10 full-file reading.

Historical q2371 concerns mission clock/count owners, q3127 terminal-receipt
lifecycle admission, q3134 zero-grace enrollment and q1776 a broader Lens 12
frontier. Their original first questions, readers and current qualifications
remain separate. The prior q3083 Lens 9 receipt assessment was authored by
`mhr_character` and independently peer-reviewed by `wrapped_scope`; q3083 is
unassessed at 8b. The separate q2990/q3062 Lens 12 mission/enrollment report
was authored by `final_guard_peer`, and this reviewer previously authored the
q3059 Lens 9 enrollment review. None supplies q3000 Lens 10 body credit.
Related historical q1712 and ledger row 390 record a distinct mixed-contact
role question with reach and policy open. These relationships do not establish
an alias or new count; the current review makes no receipt or timing finding.

The initial q3083 public-manifest lookup assumed a map where the author’s file
list is a list; its retained error was corrected by a separate checker. A q3059
lookup initially requested `REPORT.md` where that packet uses `REVIEW.md`; the
retained error and successor are also preserved. Earlier Lens 10 filename
navigation was a finite lexical search, including false-positive filenames,
not a complete historical absence proof. Some metadata previews were capped;
full selected records are retained privately. The registered current display
was untruncated and its exact bytes are retained, but the display event is
reviewer-attested rather than independently signed.

The missing checkpoint 3821 is not reconstructed. SOURCE004, the 73
nontext/no-positive-EOF obligations, reconstructed 440, and the 774 normalized
versus missing pre-export originals qualification remain open or qualified as
recorded. Strongest evidence-only replay depends on separately held original
059, the protected read-only extraction, selected prior reports and a Git
object store with the named commits. The public packet cannot reconstruct those
unprovided originals or establish independent custody. No queue or ledger was
changed.
