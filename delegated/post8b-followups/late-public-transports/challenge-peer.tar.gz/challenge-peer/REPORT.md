# Independent peer review: q2818 and q2830, Lens 6

The author’s bounded presenter-ownership and puzzle-shape claims are supported
by the selected 95e source. They remain ownership and conditional type-shape
questions: no wrong owner, reachable malformed projection, actual panic, repair,
new defect count, alias or closure is established. One additive source-map
qualification is needed for receipt-adjacent fields, as described below.

The author of the reviewed challenge packet is `final_guard_peer`; this peer
review is by `wrapped_scope`. The peer previously authored q2812 ordered
sigils and q2896 logic-grid source reviews under Lens 12. Those separate reads
do not confer Lens 6 credit. The peer independently displayed 23 prospectively
registered current windows, including two later-quarantined subranges. This
review is independent of the challenge packet’s author, not independent of all
related puzzle-family work.

The pinned product revision is `95e63628f9d70b8dd6e6fede64334696c6995009`,
tree `1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The selected database schema
defines `ChallengePresenterCatalogId::LadyBeneathThornV1`
(`crates/adventuresim-stdb-module/src/strategic/challenges.rs:8–11`). The
generated database client has the corresponding variant
(`crates/adventuresim-stdb-client/src/challenge_presenter_catalog_id_type.rs:1–16`),
and the selected web route maps that variant to the core presenter identity
(`crates/strategic-web/src/routes/challenges.rs:83–86`). The generated binding
is an adapter, not an independently authored owner. The right authority,
derive constraints, web re-export provenance and other consumers remain open;
the mapping alone does not prove an owner is misplaced.

The puzzle crate exposes separate authority, projection and submission enum
variants (`crates/adventuresim-puzzles/src/puzzles.rs:91–108,123–140`). Its
selected projection, validation and answer-check dispatch go to the matching
variant owner (`puzzles.rs:233–256,280–305`). The selected database view
validates its deserialized authority before projection
(`strategic/challenges.rs:405–408`). The logic-grid specification validates
sizes 3–4 and the answer validator checks length, permutations and traveler
order (`crates/adventuresim-puzzles/src/logic_grid.rs:35–46,198–203,235–237,
319–349`). The route’s form has four token and four road inputs and the parser
indexes them as it enumerates projected travelers (`routes/challenges.rs:107–124,
173–195`). Thus the selected validated size fits this form; a future valid
larger grid would require the adapter to change. No current supported larger
grid or ordinary form failure is established.

`LogicGridProjection` exposes label vectors and `LogicGridAssignment` exposes
three `u8` indices (`logic_grid.rs:88–110`); the selected template formatting
helper directly indexes all three vectors for a same-variant submission
(`crates/strategic-web/src/templates/challenge.rs:183–212`). The route builds a
typed answer from projected labels and serializes it (`routes/challenges.rs:
173–195,224–229,249–256`). A malformed projection/assignment combination can
be represented by the public fields, but the selected source does not establish
that a supported producer admits one into this formatter. Its caller, direct
API policy, all producers and consumers, and the resulting runtime behavior
remain open. This review does not inspect retained-submission or receipt
internals, and makes no claim that a malformed value was stored or a panic
occurred.

## Exposure and chronology

The author’s original seven corrections are retained and distinct:

1. Registered support windows exposed receipt lookup/retry and adjacent names;
   those spans are excluded from findings and coverage.
2. The exposure also included travel/time portions; those receive no credit.
3. A bounded errantry window was displayed after an initial go-ahead but before
   the coordinator’s later hold; the display cannot be relabeled unread.
4. The entire errantry window was quarantined as process-only because overlap
   with earlier travel work remained unresolved.
5. The schema-enum window exposed adjacent rest/travel names and a rest-delay
   constant; only the presenter enum is used.
6. Selected template and route views also exposed retained-submission
   references; those receive no receipt credit or behavior claim.
7. After the hold, a filtered citation check re-displayed route lines 74–90,
   including excluded retained-submission lines. The first public packet omitted
   that event. Its original tool output was visible but not separately captured;
   the saved successor is expressly a reconstruction.

The seven correction files, v1 and v2 public packets, and exact source-view
registrations were inspected as evidence. The v1-to-v2 public assessment
changes only its process qualification; the report adds the later re-display
and the source map adds that process-only qualification. All 256 v1 private
file bytes and modes match their preserved counterparts in v2; v2 and its
same-machine replay each have 273 checked manifest members. The receipt has
22 checked members. The reconstructed nine-window output matches its prior
stored views byte-for-byte, with 17 lines in the final route window. That check
did not display excluded lines; it cannot prove the independently uncaptured
original tool output, its chronology, or an independent display witness.

The author’s v2 source map lists `strategic/challenges.rs:356–375` as usable,
although that range also contains last-attempt status at 371 and the retained-
submission field at 372. Its `templates/challenge.rs:13–20` range includes a
last-attempt status parameter at 20. The author’s substantive presenter and
shape claims do not depend on those fields. An additive correction should
quarantine those three lines from usable coverage; the existing packet and
seven corrections should remain unchanged. This is a scope/attribution
correction, not a demonstrated product defect.

The peer’s own prospectively registered views independently included the same
schema lines 371–372 and template line 20. That incidental exposure is a
separate event, recorded in `OWN-SCOPE-CORRECTION.json`; those lines are
process-only and confer no receipt, retained-submission or last-attempt
behavior coverage. No later excluded source view was displayed. Full exact
windows remain restricted for process recovery.

## Historical relationships and custody

At committed 8b, q2818 and q2830 are unassessed and their original Lens 6
records remain proof/read-pending. Their selected original/reconstructed 059
objects match as parsed; the complete queue streams differ. Root’s recovered
Lens 3 receipts record fresh 6533 reads of the template 1–483 and route 1–279;
the e275 receipts record qualified same-lens reuse and no fresh current
reread. The selected template and route blobs match across 6533, e275 and 95e,
while those trees differ. This is per-file identity, not whole-tree equality
or fresh historical Lens 6 credit.

Historical q2700’s rejected ordinary native suspicion and open public admission
policy, q2697’s distinct ordered-position question, and q2823’s partial Lens 11
assessment retain their own original first operations and readers. Ledger 1126
is a planning relationship linking q2700/q2823 and the normalized 774 F045
context, without a new accepted count or repair. No receipt-scope claim or
cross-lens alias follows from those historical summaries.

The original read and verification records, seven scope corrections,
registrations, personal display bytes, initial and corrected author public
packets and identity checks are retained in restricted evidence. Replay using
the separately held full original 059 stream, protected read-only extraction,
author packets and Git objects is same-machine evidence verification, not
independent custody. The missing checkpoint 3821, SOURCE004 and 73 nontext or
no-positive-EOF obligations remain unresolved or qualified as recorded. No
product code, test, fixture, build, repair or runtime probe was run; the central
queue, ledger and checkpoint were not changed.
