#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,subprocess
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();a=argparse.ArgumentParser()
for n in ['repo','private-manifest','replay-manifest','author-private-manifest','author-public-manifest','original-queue']:a.add_argument('--'+n,type=Path)
args=a.parse_args();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-challenge-l6-peer-public-v1';assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
x=json.loads((p/'BINDING.json').read_bytes());views=json.loads((p/'VIEW-SUMMARY.json').read_bytes());assert len(views['views'])==23 and len(views['excluded_from_usable_coverage'])==2;hist=json.loads((p/'HISTORY.json').read_bytes());assert [z['index'] for z in hist['selected']]==[2818,2830] and all(z['checkpoint_status']=='unassessed' and z['original_reconstructed_equal_as_parsed'] for z in hist['selected']) and hist['full_streams_equal'] is False
c=json.loads((p/'CHRONOLOGY.json').read_bytes());assert c['manifest_member_checks']=={'v1':256,'v2':273,'replay':273,'receipt':22} and c['registered_selected_views']==8 and c['registered_support_views']==17 and c['last_window_line_count']==17 and c['reconstruction_matches_prior_stored_views'];r=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert len(r['checks'])==2 and all(z['exit']==0 and z['stderr_bytes']==0 for z in r['checks'])
checks=['public file identities, selected statuses and recorded process checks'];not_checked=[]
for n,k in [('private_manifest','private_manifest_sha256'),('replay_manifest','replay_manifest_sha256'),('author_private_manifest','author_private_manifest_sha256'),('author_public_manifest','author_public_manifest_sha256'),('original_queue','original_queue_sha256')]:
 q=getattr(args,n)
 if q is None:not_checked.append(n+' not supplied')
 else:assert h(q.read_bytes())==x[k];checks.append(n+' identity')
if args.repo is None:not_checked.append('Git file identities not supplied')
else:
 def git(*c):
  z=subprocess.run(['git','-C',str(args.repo),*c],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert z.returncode==0 and not z.stderr;return z.stdout
 q=json.loads((p/'SOURCE-IDENTITIES.json').read_bytes());rev=q['revision'];assert git('rev-parse',rev+'^{tree}').decode().strip()==q['tree']
 for s in q['sources']:
  path=s['path'];assert path.startswith('crates/') and '..' not in PurePosixPath(path).parts;b=git('show',rev+':'+path);assert h(b)==s['sha256'] and len(b.decode().splitlines())==s['eof'] and git('rev-parse',rev+':'+path).decode().strip()==s['blob']
 for t in q['selected_file_trees']:
  assert git('rev-parse',t['revision']+'^{tree}').decode().strip()==t['tree']
  for path,blob in t.get('blobs',{}).items():assert git('rev-parse',t['revision']+':'+path).decode().strip()==blob
 checks.append('six current Git file identities and historical per-file blob/tree metadata')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence-only identity replay; no excluded-source credit, product validation, independently witnessed display, full historical recovery or independent custody is certified.'}))
