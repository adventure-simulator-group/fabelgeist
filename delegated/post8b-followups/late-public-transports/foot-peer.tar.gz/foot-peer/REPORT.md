# Peer review: foot-clearance type granularity

Reviewer `final_guard_peer` independently checked the bounded q1944, q1964,
q1994 and q2002 Lens 11 assessment by `wrapped_scope`. The selected evidence
supports the author's distinctions and conditional questions. No semantic
blocker or new defect count is established. One provenance refinement is
recommended for later synthesis: q1179's original status and its current
partial wrapper should be stated separately.

The product authority is `95e63628f9d70b8dd6e6fede64334696c6995009` (tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`). The committed queue snapshot is
`8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b` (tree
`552bb7853c70fea3c124eb0096d53e3e99b9439a`, parent
`8caeb2003d10d08320566206817aa0c694231778`). This is a partial peer review,
not adoption, a complete lens pass, repair, runtime validation, or closure.

## Source assessment

- `FootClearanceFloor::Minimum` carries a completed scene elevation;
  `Terrain` carries a support elevation and signed clearance and resolves
  their sum with the ankle/sole offset. `FootDescent::RaiseOnly` applies a
  maximum, whereas `FollowFloor` follows the required height
  (`crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:7`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:30`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:44`). The selected run consumer chooses a descent mode and applies
  the floor (`crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts.rs:438`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/mod.rs:1945`).
  The selected flight projection uses the resolved floor as a lower bound
  (`crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/flight_projection.rs:5`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/flight_projection.rs:98`). These are useful distinct roles; they do not prove every supported
  terrain or rendering path.
- Four separate retained `Option<Vec3>` ankle and toe fields are declared in
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/state.rs:64`.
  The selected producer locally zips ankle then toe, with the same order in its
  snapshot fallback (`crates/adventuresim-tactical-client/src/animation/procedural/ik/mod.rs:1265`).
  The selected consumers unpack and pass that order
  (`crates/adventuresim-tactical-client/src/animation/procedural/ik/mod.rs:2194`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/mod.rs:2479`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:151`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:192`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:240`). This is a local pair assembled from separate retained
  options, not a retained tuple. Swapping equal-typed inputs changes the
  symbolic flat-surface result: for ankle Y about 0.10 m, toe Y 0 m and
  clearance 0.02 m, the floor is about 0.12 m; the swapped arguments yield
  about -0.08 m. That example shows why roles matter, not that a supported
  producer actually swaps them. Whether a paired record or stronger role types
  improve the boundary remains open; names alone cannot prevent a swap.
- `SettleProgress::from_progress` admits finite negative values and caps the
  upper side; `UnitInterval` admits only finite values in [0, 1]
  (`crates/adventuresim-tactical-core/src/animation/ik_parameters.rs:11`,
  `crates/adventuresim-tactical-core/src/animation/ik_parameters.rs:33`,
  `crates/adventuresim-core/src/unit_interval.rs:23`). At symbolic
  progress -1, the swing target clamps local progress to zero, whereas the
  terrain expression uses `1 - progress` and therefore doubles its raw swing
  clearance term before a later maximum and blend
  (`crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:119`,
  `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs:151`). The later maximum can mask the difference. The selected ordinary
  plan initializes progress at zero
  (`crates/adventuresim-tactical-client/src/animation/procedural/ik/settle/planning.rs:100`),
  and the state update delegates to a timing helper
  (`crates/adventuresim-tactical-client/src/animation/procedural/ik/settle.rs:47`).
  The helper was not inspected in this review. Supported reach of negative
  retained progress, visible effect, and intended bounds remain unresolved;
  no positivity rule or repair is asserted.

The supporting scene point, optional support elevation, finite framed elevation
and signed-length admission were separately inspected at their registered 95e
windows. Identical scalar representation does not make these roles equivalent.
The symbolic examples are source reasoning only, with no product execution.

## Historical and ledger relationships

The four original selected records have `open-scope-qualification` status;
their 8b wrappers are `unassessed`. Each original/reconstructed selected object
matches as parsed, while the complete original and reconstructed streams have
different bytes. q1944 and q2002 refer to 7a9d `PL11-0013`, and q1964 and
q1994 to e275 `PL11-0127`; their recorded unread ranges and exact receipt
identities remain in the author's packet and the restricted peer evidence.

The historical `parallel lens11_reconcile` reader recorded a fresh 7a9d
1–130 read, qualified e275 reuse of that range without a fresh reread, and a
fresh e275 131–395 read. Root's separate adoption records do not claim Root's
personal reread. `READ-L11-561` records both cumulative full-file evidence and
its own unread/open qualification; preserve both rather than closing a queue
row. `READ-L11-566` records 7a9d reuse of e275 131–395, not a fresh old-source
read. The selected source blob is identical at 7a9d, e275 and 95e, but those
commit trees differ; this neither proves tree equality nor transfers reader
credit. None of these records is recovered checkpoint 3821 evidence.

q1179's original Lens 12 record has `open-evidence-or-disposition` status;
its 8b wrapper is partial and leaves supported owner/scene, native application
and exact-alias questions open. Its connected search question concerns the
first missing floor in the off-chord search. The selected 95e search returns
`None` at that operation
(`crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/flight_projection.rs:134`);
this bounded peer check does not personally establish the full search or
fallback trace. Ledger 269 concerns terrain-contact interpolation; ledger 270
concerns the encoding span. They are distinct Lens 8 first questions, each
partial with repair not started and validation not performed. No global alias,
unique-defect increment or shared-repair decision follows from this review.

## Process and recovery qualifications

The reviewer prospectively registered and personally displayed 22 bounded 95e
windows. Two state windows did not establish the retained field declarations;
the field locations were then found by line-number-only navigation and a
separate declaration window was registered. Complete source blobs were captured
for identity only. Displays are reviewer-attested, not independent telemetry.

One registered owner window also displayed two `compile_fail` documentation
examples, contrary to this reviewer's stated no-test-source-display scope. The
examples were read as text only and not executed or used as validation. The
first correction command wrote a valid JSON record and then failed while adding
a newline; the unchanged record, additive correction, and a marked
reconstruction of the tool-visible-only traceback are retained. The author's
own packet separately discloses a test-source-text view, its earlier unavailable
`python` invocation and clipped metadata preview. Its timing-helper file was
captured for navigation but not personally displayed or assessed. None of these
facts proves product behavior.

This reviewer did not author the foot assessment. The author is independently
reviewing this reviewer's separate challenge packet, and both have collaborated
on other audit work. This reviewer earlier reviewed a separate q2962 grounding
synthesis, including a coordinates-file window at historical revision 58ea;
the present 95e window was separately registered and read, with no inherited
reader credit. The reviewer also handled earlier same-machine evidence custody.

Evidence replay uses same-machine Git objects and separately held historical
records; it is not an independent backup. The original 059 queue, reconstructed
records, historical summaries and new assessments remain distinct. Missing
checkpoint 3821, SOURCE004, earlier nontext/no-positive-EOF obligations and the
other recovery qualifications remain open. No product repair, build, test,
fixture, runtime probe, queue edit or ledger edit was performed.
