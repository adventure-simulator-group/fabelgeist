# Additive correction: challenge source-map scope

The q2818/q2830 Lens 6 source map included three receipt-adjacent lines in
usable ranges. The corrected map excludes
`crates/adventuresim-stdb-module/src/strategic/challenges.rs:371–372` and
`crates/strategic-web/src/templates/challenge.rs:20`. They were displayed in
the author's original registered windows and are retained as process evidence
only. They provide no receipt, retained-submission or last-attempt coverage,
finding, or closure. The seven earlier exposure and chronology corrections
remain applicable.

The corrected map narrows template range 13–20 to 13–19 and splits schema
range 356–375 into 356–370 and 373–375. All other substantive ranges remain
unchanged. The author's narrative findings do not cite or depend on the three
excluded lines: the presenter question uses the schema enum, generated client
and route mapping; the conditional puzzle-shape question uses the puzzle
owners, the selected authority-to-projection view, the form and formatter.
The historical q2700 receipt statement remains a separately attributed
historical summary, not a new receipt-source assessment. No semantic change,
new defect count, supported malformed state, repair or closure follows.

`wrapped_scope` independently reviewed the v2 packet and identified these
source-map omissions. That reviewer also displayed the same three lines in its
own separately registered windows, and preserved a separate correction. Those
peer exposures and the author's earlier exposures are distinct events with
separate readers; neither confers excluded-scope credit. The v2 packet was
sealed before the peer feedback. This additive correction follows the peer
review and coordinator direction; neither sealed predecessor was changed. No
new excluded source lines were displayed while preparing it. The finite
literal check in the restricted evidence does not establish absence of other
excluded semantics.

The source authority remains `95e63628f9d70b8dd6e6fede64334696c6995009` and
the queue snapshot `8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. The original
q2818/q2830 records remain pending and their 8b wrappers unassessed. The
6533 Lens 3 fresh reads, e275 qualified reuse with no fresh reread, same-file
identity across different trees and distinct historical readers retain the
qualifications in the predecessor. Missing checkpoint 3821, SOURCE004 and the
73 nontext/no-positive-EOF obligations remain unresolved. The public predecessor
and peer manifest identities are bound in `BINDING.json`; strongest replay
uses same-machine private records and Git objects and is not independent
custody. No queue or ledger was edited, and no product repair, build, test,
fixture, runtime probe or validation was performed.
