# Bounded Lens 6 assessment: challenge presentation and admission

Reader: `final_guard_peer`. This is a newly assessed, partial type-ownership
review of q2818 and q2830, not an adoption, defect count, repair or closure.
The source authority is commit `95e63628f9d70b8dd6e6fede64334696c6995009`
(tree `1eec97de340d9b7debbb30ca0c0fb2240a73b93f`). The queue snapshot is
commit `8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b` (tree
`552bb7853c70fea3c124eb0096d53e3e99b9439a`, parent
`8caeb2003d10d08320566206817aa0c694231778`). The 8b wrappers say unassessed;
the original records say `own-lens-proof-qualification-or-read-pending`.
Original and reconstructed selected objects match as parsed; their complete
queue streams do not have identical bytes. None is checkpoint 3821.

## Findings and open questions

1. The challenge schema defines `ChallengePresenterCatalogId` and the
   generated client has the corresponding variant. The route maps the web
   database-facing variant to `adventuresim_core::errantry::FeyPresenterCatalogId`
   (`crates/adventuresim-stdb-module/src/strategic/challenges.rs:8`,
   `crates/adventuresim-stdb-client/src/challenge_presenter_catalog_id_type.rs:1`,
   `crates/strategic-web/src/routes/challenges.rs:83`). This establishes a
   boundary and an explicit mapping, not that either type has the wrong owner.
   Which representation should own the contract, what the database derive
   requires, and how other consumers map the same concept remain open. The
   generated client is generated evidence, not a separately authored bespoke
   owner. Its exact web re-export provenance was not established here.

2. Puzzle authority, projection and submission are owned by the puzzle crate;
   projection and checking dispatch to the variant owners
   (`crates/adventuresim-puzzles/src/puzzles.rs:91`,
   `crates/adventuresim-puzzles/src/puzzles.rs:233`,
   `crates/adventuresim-puzzles/src/puzzles.rs:249`,
   `crates/adventuresim-puzzles/src/puzzles.rs:280`).
   The selected logic-grid authority validates its specification and answer,
   and the selected database view validates authority before projection
   (`crates/adventuresim-puzzles/src/logic_grid.rs:16`,
   `crates/adventuresim-puzzles/src/logic_grid.rs:184`,
   `crates/adventuresim-puzzles/src/logic_grid.rs:235`,
   `crates/adventuresim-puzzles/src/logic_grid.rs:319`,
   `crates/adventuresim-stdb-module/src/strategic/challenges.rs:405`). Its
   selected authority accepts sizes three through four; the native form has
   four grid positions (`crates/adventuresim-puzzles/src/logic_grid.rs:10`,
   `crates/strategic-web/src/routes/challenges.rs:107`,
   `crates/strategic-web/src/routes/challenges.rs:173`). This is a
   coupling to revisit if the valid domain expands, not a current failure.

   The public grid projection contains vectors and the assignment fields are
   plain indices (`crates/adventuresim-puzzles/src/logic_grid.rs:88`); the template's formatting function uses
   indices from a same-variant assignment directly against those vectors
   (`crates/strategic-web/src/templates/challenge.rs:183`). The web parser
   constructs typed submissions from the projection and serializes them
   (`crates/strategic-web/src/routes/challenges.rs:173`,
   `crates/strategic-web/src/routes/challenges.rs:224`,
   `crates/strategic-web/src/routes/challenges.rs:245`). A
   directly constructed or admitted malformed combination is representable at
   the type surface, but its supported reach and policy are not established.
   No ordinary native mismatch, malformed retained value, observed panic or
   product defect is established. The ownership question is whether the public
   projection/submission contract or the consuming adapter should guarantee
   their structural relationship; policy and all producers/consumers remain
   open. Receipt and retained-submission internals are not analyzed here.

## Connected historical records

Historical q2700 rejected the ordinary native malformed-answer / oversized
projection suspicion on its separately attributed validated path, while leaving
public projection/clue admission policy open. Its receipt-related statements
are historical attribution only and were not independently reviewed here.
Historical q2697 concerns ordered-clue position admission, a distinct first
operation and policy question. Neither original record has a `status` member;
the 8b wrappers are unassessed. Their old statements are not current source
reads. q2823's original Lens 11 status was pending; its 8b wrapper is partial
and points to the separately attributed `puzzle-author` and `puzzle-peer`
assessment. Existing ledger entry 1126 is a planning relationship for puzzle
projection/submission, not an accepted unique defect, repair, or validation.
This Lens 6 review offers bounded context for that relationship only; it does
not establish a global alias or new count.

The recovered 6533 Lens 3 records attribute fresh reads of the selected
original ranges to their historical reader, Root. The e275 Lens 3 records explicitly
qualify reuse of those ranges and claim no fresh personal reread. The selected
files have identical Git blob identities across 6533, e275 and 95e; the trees
are different. This file identity neither transfers their reader credit to
Lens 6 nor proves whole-tree identity. The new reads are at 95e only.

## Process and recovery limits

Exact source windows were prospectively registered and the selected records
reserved before display. Eight selected windows and 17 support windows were
displayed, including quarantined exposure; the counts do not imply usable
coverage. The template includes test source read as text only, and route test
source was not selected. Display is the reader's attestation, not independent
telemetry. Full source blobs in the restricted record establish identity and
replay bytes; they are not a claim of full personal reading.

Overbroad support displays exposed receipt, travel/time and adjacent rest
material despite the assigned exclusions. The originally selected web windows
also showed retained-submission references. The coordinator initially allowed a
bounded shared errantry presenter view; that view was displayed before a later
hold because overlap with the earlier travel review could not be ruled out.
All of that errantry window, the excluded spans, and the retained-submission
references are preserved as process evidence only and confer no source
coverage, findings, or closure for those scopes. Seven additive corrections and
the exact original displays remain in the restricted packet. Earlier travel
readers retain their attribution. After the no-further-inspection instruction,
a citation check re-displayed already captured route lines 74–90, including
retained-submission lines 76–80; a later metadata-only search identified the
other references. The first packet omitted that re-display. Its exact tool
output was not independently captured; a marked reconstruction and the original
view are retained. The excluded lines confer no receipt credit or finding.

The recorded verification and replay use the same machine and its Git objects;
they are neither independent custody nor proof of the missing checkpoint 3821.
The pending SOURCE004 issue and 73 nontext/no-positive-EOF obligations remain
unresolved. No product repair, build, test, fixture, runtime probe or validation
was performed. The central queue, ledger and checkpoint were not changed.
