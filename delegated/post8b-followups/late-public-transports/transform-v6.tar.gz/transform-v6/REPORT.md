# Static review of the unrun post-8b transform v6

The four declared substitutions reproduce the exact v6 text from v5. V6
addresses the v5 raw-byte qualification: it accepts raw proposal, report and
observation inputs, requires each to equal its canonical rendering, and hashes
the actual supplied bytes. I found no additional substantive defect in this
bounded comparison. The transform was not executed and this review does not
establish an installed candidate or product behavior.

At `TRANSFORM-v6.py:50–65`, the raw proposal must hash to the fixed proposal
identity. The previously captured proposal does equal its canonical rendering
and has SHA-256
`145555a6f5ad092174f4214b04e255660e5903dcb18bbef293baaca8b8500d44`.
The supplied report must equal the prescribed projection of that proposal and
its raw hash must equal the caller's binding. The supplied observation must
also be canonical and its raw hash must equal the caller's binding. The caller
still supplies those bindings, so they do not authenticate external origin.

The four before-image identity pins, independent assembly-review manifest
identities, checkpoint-3821 correction, count checks and remaining transform
body are unchanged from v5. The separately sealed v5 review checked those
pins against committed 8b, compared the review manifest/member chains and
preserved the original/reconstructed history limits. The v6 comparison does
not transfer prior source or lens credit.

The separate candidate and installer must bind the actual report, observation,
review archive members and raw connector response, validate the observation
interval and check that the files and links are present. The old exact-root
8b guard must be replayed from a separate clean 8b checkout; a clean 8ca
predecessor must also be provided when nested replay is required. The new
successor guard must independently bind the changed roots and installation.
These later checks are not demonstrated by caller-supplied strings or this
static review.

The reviewer authored q2743 and q2744 source assessments, the q2545 draft peer
review and the v4 and v5 transform reviews. This is an additive evidence-tool
review, not independent product-source credit. The original v5 packet remains
unchanged. No transform, guard, product, build, test, fixture, repair or runtime
probe was executed and no central queue, ledger or publication was changed.
