#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,subprocess
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();a=argparse.ArgumentParser()
for n in ['repo','private-manifest','replay-manifest','original-stream-manifest','original-queue']:a.add_argument('--'+n,type=Path)
args=a.parse_args();m=json.loads((p/'MANIFEST.json').read_bytes());files=m['files'];assert m['schema']=='726-foot-clearance-l11-public-v1';assert {x.name for x in p.iterdir()}==set(files)|{'MANIFEST.json'}
for n,row in files.items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
b=json.loads((p/'BINDING.json').read_bytes());r=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert len(r['checks'])==2 and all(z['exit']==0 and z['stderr_bytes']==0 for z in r['checks']);v=json.loads((p/'PUBLIC-VIEWS.json').read_bytes());assert len(v['views'])==32 and len({x['id'] for x in v['views']})==32
for x in v['views']:assert h((p/('VIEW-'+x['id']+'.txt')).read_bytes())==x['sha256']
history=json.loads((p/'HISTORY.json').read_bytes());assert [x['index'] for x in history['selected']]==[1944,1964,1994,2002] and all(x['checkpoint_status']=='unassessed' and x['original_reconstructed_selected_equal_as_parsed'] for x in history['selected']) and history['full_streams_equal'] is False
checks=['public member set and byte hashes','recorded replay identities and selected history projection'];optional=[]
for name,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','replay_manifest_sha256'),('original_stream_manifest','original_stream_manifest_sha256'),('original_queue','original_queue_sha256')]:
 q=getattr(args,name)
 if q is None:optional.append(name+' not supplied')
 else:assert h(q.read_bytes())==b[key];checks.append(name+' identity')
if args.repo is None:optional.append('Git source-window replay not supplied')
else:
 def git(*argv):
  q=subprocess.run(['git','-C',str(args.repo),*argv],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert q.returncode==0 and not q.stderr;return q.stdout
 rev=b['source_revision'];assert git('rev-parse',rev+'^{tree}').decode().strip()==b['source_tree'];cache={}
 for x in v['views']:
  path=x['source'];assert path.startswith('crates/') and '..' not in PurePosixPath(path).parts
  if path not in cache:cache[path]=git('show',rev+':'+path).decode().splitlines()
  ls=cache[path];a,c=x['range'];assert 1<=a<=c<=len(ls);head='' if x['format']=='main' else f"SOURCE: {path} VIEW: {x['id']} RANGE: {a} {c}\n";expected=(head+''.join(f'{i:4d}  {ls[i-1]}\n' for i in range(a,c+1))).encode();assert expected==(p/('VIEW-'+x['id']+'.txt')).read_bytes()
 for rev in ['7a9d92ad7357779e9280146c521bd8588b86fcdb','e2755a732c84e67296b5e3441a4259a84f461b2f',b['source_revision']]:assert git('rev-parse',rev+':'+v['views'][0]['source']).decode().strip()==b['source_blob']
 assert h((p/'CURRENT-FOOT-CLEARANCE.rs').read_bytes())==b['source_sha256'];checks.append('32 source windows and three historical/current per-file Git identities')
print(json.dumps({'checks':checks,'not_checked':optional,'qualification':'Evidence-only identity replay; no product behavior, full historical custody, independently signed display or recovery of missing originals is certified.'}))
