# Foot-clearance type granularity: q1944, q1964, q1994 and q2002

The selected current source preserves several distinctions that matter to its
actual callers. The bounded review found no observed ankle/toe reversal or
established granularity defect. It leaves two conditional questions about a
same-typed ankle/toe pair and signed settle progress for central reconciliation.
These questions do not establish a new defect count, an alias, or closure.

The assessed product authority is commit
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The reviewer personally displayed
all of `crates/adventuresim-tactical-client/src/animation/procedural/ik/terrain_contacts/foot_clearance.rs`,
current lines 1–395 and EOF, under Lens 11. Current registered support windows
were separately read; the complete registrations and exact displayed bytes are
in the restricted packet. The Git file blob is
`9ae2765389e755e5a3f30d47d3c2a58eb9f2a35c`, and its SHA-256 is
`fbee9961d5150f7a221c942cab5c5288e3efdca4d36e920ab5476a2ed9be3b82`.

`FootClearanceFloor::Minimum` contains a completed `Elevation<Scene>`, while
`Terrain` contains a `SupportElevation` and a `SignedLength`; resolving the
latter adds the measured ankle/sole offset and clearance before admitting the
completed elevation (`foot_clearance.rs:7–16,30–42`). The existing separation
helps avoid treating a support surface as an already completed ankle floor or
adding that offset again to a completed floor. `FootDescent` separates raise-only
from follow-floor operations (`foot_clearance.rs:18–27,44–56`); the selected run
path produces and applies those distinct modes (`terrain_contacts.rs:438–458`,
`ik/mod.rs:1945–1974`). Selected sphere-search callers use the resolved floor
as a lower bound (`flight_projection.rs:5–28,98–103,128–143`). This supports
retaining those distinct roles; it is not a proof of all terrain, search,
rendering or reach behavior.

The quantity owners also differ in meaning: `ScenePlanPoint` admits finite
scene-plan points (`scene_coordinates.rs:20–38`); terrain `height_at` returns
an optional `SupportElevation` (`scene/queries.rs:86–89`); `Elevation<Scene>`
is a finite signed elevation in a declared frame (`coordinates.rs:41–49,
113–126`); and `SignedLength` represents a finite signed distance
(`measurement.rs:11–21,35–45`). `UnitInterval` admits finite fractions in
[0, 1] (`unit_interval.rs:9–11,23–34`), whereas `SettleProgress` admits finite
signed progress and its public constructor caps only the upper end
(`ik_parameters.rs:11–13,33–50`). Similar scalar storage is not evidence that
these roles are interchangeable or that a new bound is justified.

The current ankle/toe path retains separate `Option<Vec3>` fields and locally
constructs `Option<(Vec3, Vec3)>` in ankle-then-toe order, with a snapshot
fallback in that same order (`ik/mod.rs:1265–1283`). The selected consumers
unpack or pass that pair in the same order (`ik/mod.rs:2194–2202,2479–2485`;
`foot_clearance.rs:151–158,178–185,192–216,240–245,253–278`). The function
parameters themselves use the same `Vec3` type. A purely symbolic, flat-surface
example with ankle Y approximately 0.10 m, toe Y 0 m and 0.02 m requested
clearance gives an ankle floor approximately 0.12 m; swapping those inputs
gives approximately -0.08 m. The optional observations and signed elevation
constructor permit this algebraic comparison; it is not a claim that such a
swap occurs in a supported call. The concrete design question is whether this
boundary merits explicit ankle/toe role owners or a clearer paired record,
after weighing the local producer and actual consumers. A named record alone
would not make two `Vec3` values impossible to swap. No supported erroneous
producer, visible effect, runtime outcome or required repair is established.

A separate conditional progress question exists at the same selected source.
For an admitted `SettleProgress` of -1, `settle_swing_target` clamps its local
progress to 0 (`foot_clearance.rs:119–129`), while the settle terrain expression
uses raw progress in `1.0 - progress` (`foot_clearance.rs:151–176`). Its raw
swing-clearance term is consequently `2 * C` rather than `C`, before the
subsequent maximum and blend; the final floor need not differ when the other
maximum wins. The selected normal plan initializes progress to zero
(`settle/planning.rs:80–106`), and the state update delegates to a timing
helper (`ik/settle.rs:47–55`). That helper was not displayed under this bounded
scope, and supported reach of a negative retained value, final effect and
intended policy remain open. No new positivity policy or repair is asserted.

## Historical and current relationships

The original and reconstructed 059 objects for all four selected rows match as
parsed. The full original and reconstructed queue streams differ. All four
are `unassessed` at committed checkpoint
`8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`; each original record retains its
own historical scope and remains an open-scope qualification:

| Row | Historical revision and registration | Recorded unread range |
| --- | --- | --- |
| q1944 | 7a9d, PL11-0013 | 131–395 |
| q1964 | e275, PL11-0127 | 131–395 |
| q1994 | e275, PL11-0127 | 1–130 |
| q2002 | 7a9d, PL11-0013 | 1–130 |

Historical PLAN-002 and PLAN-021 register the full file at their respective
revisions. The recovered earlier `parallel lens11_reconcile` READ-001 records
its personal 7a9d 1–130 read; READ-007 records e275 1–130 as qualified reuse,
not a fresh reread; READ-025 records a fresh e275 131–395 read and its prior
qualified proof. Their corresponding Root receipts READ-L11-537, -543, -561
and -566 preserve different fresh/reuse ranges and adoption qualifications.
In particular, READ-L11-561 includes a cumulative full-file statement while
also retaining a per-record unread-range/open qualification; those statements
are reported as recorded, not used to close any 059 row. READ-L11-566 records
qualified 7a9d reuse of 131–395 rather than a fresh old-revision read. The
historical author is not this reviewer; Root's adoption is not a personal
reread. Source/plan/receipt hashes and actual ranges are in the restricted
packet.

The same Git blob occurs at 7a9d, e275 and 95e; the three commit trees differ.
This proves the selected per-file identity, not equality of those trees or a
fresh historical personal display. The prior delegated same-lens
`P06-P19-P20-L11-CURRENT-CLEARANCE-EVALUATION` is a historical summary of
specified e275 typed routes, optional modes and remaining native/caller work;
it did not give this reviewer personal source credit. Its `P19-L11-CURRENT-FOOT-INFLUENCE`
summary addresses checked left/right influences and is likewise separately
attributed. Neither is promoted to missing checkpoint 3821.

A bounded lexical search also found historical q1179, a partial Lens 12 terrain
search/clearance record, and current ledger rows 269 and 270, Lens 8 terrain
interpolation and encoding questions. They have separate first questions and
reader attribution. A second ledger search for ankle plus toe or the exact
selected pair/floor identifiers found no match under those literal criteria;
this is not a global alias search. No alias or count follows.

## Evidence and limits

One support view (`flight_projection.rs:185–250`) included test-source text.
It was inspected as source only; no test or fixture was executed or used as
runtime evidence. An additional timing-helper file was captured for
line-number navigation but not personally displayed or assessed, to avoid the
active timing scope. Source-window outputs were complete when returned and are
retained; the display event is reviewer-attested rather than independently
signed. The initial metadata navigator failed because `python` was absent;
the retained stderr and exit 127 precede the successful `python3` successor.
One candidate metadata preview was intentionally clipped, and full selected
metadata was retained privately. Exact process qualifications are preserved.

The missing checkpoint 3821 is not reconstructed. Earlier nontext/no-positive-
EOF obligations, SOURCE004, reconstructed 440 and the 774 normalized versus
missing pre-export originals qualification remain open or qualified as recorded.
Strongest evidence-only replay requires the separately held original 059 queue,
the protected read-only extraction, and a Git object store with the named 8b,
7a9d, e275 and 95e objects. The public report alone cannot reconstruct those
private originals or prove independent custody. No product code, test, fixture,
shader, build, repair or runtime probe was run.
