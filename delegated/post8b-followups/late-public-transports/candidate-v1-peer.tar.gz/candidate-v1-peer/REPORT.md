# Independent review of the uninstalled five-row candidate

The candidate data matches the recorded five-row application, but the v1
public verifier has two anchoring gaps. Both were reproduced with isolated
synthetic copies. Correct the verifier and review its successor before relying
on it for a later installation; the observed gaps are not evidence that an
installed checkpoint was compromised.

At `application-candidate/VERIFY.py:67–69`, the candidate checks three
expected review-manifest strings in a sibling binding, then executes the
sibling verifier without first pinning that verifier or its package manifest.
In a scratch copy, replacing only the sibling verifier with a benign no-op
still produced exit 0. Pin the intended review-binding manifest and check its
complete declared members before invoking the exact verified script. The
captured intended binding manifest has SHA-256
`08eef34795e57d63f66df3bb711bbe8beb72b2895ec1f9fb93ea6fc3054c427f`.
This issue concerns the standalone verifier's enforcement. I separately checked
the captured intended three archives and all 18 manifest-declared file members.

At lines 70–81, `--publication` compares the installed root images, report,
observation and candidate manifest, while the executing verifier reads its own
candidate and sibling review package. It does not require that its directory
is the publication's candidate directory or compare all installed package
members. A scratch publication containing the expected root images and only
the candidate manifest passed even though all 16 manifest-declared candidate
members were absent. Bind the verifier's resolved location to the exact
publication candidate directory, or explicitly compare the installed package
and its review-binding members. A separate installer/full-stage comparison is
still required for the rest of the stage.

The captured v6 transform and proposal match their expected exact SHA-256
identities. The public and private candidate copies match. Independent data
checks verified all 14 declared 8b parent Git paths, including the four before
images and ten source packets. Of 3,713 queue rows, the other 3,708 are
unchanged; the five selected rows changed only in their scoped reconciliation
and evidence fields. The first 1,135 ledger entries are unchanged and four
specified planning links are appended. Prospective counts are 1,409 partial,
2,304 unassessed and 1,139 ledger entries; these do not imply a new defect count,
queue or lens closure, product validation, or checkpoint 3821 recovery.

The captured connector record has an ordered UTC bracket from 17:21:33 to
17:21:34 on 2026-11-13. It records main at source revision 95e and its tree,
and the handoff branch at 8b and its tree. The candidate's observation matches
that captured record. The raw record is retained restricted; this is a local
recorded response, not cryptographic proof of origin or current remote state.
Its separately authenticated custody and later observation remain separate.

The default evidence replay and the `--predecessor` replay passed in isolated
scratch. The latter checked the recorded 8b parent paths and clean porcelain
status, but explicitly skipped the old guard because no `--ancestor` was
supplied. Ignored files are outside porcelain status. The v1 verifier calls
the 8b guard with a separately supplied 8ca ancestor only when both options
are present; that nested replay was not run in this review. The installed
candidate, full stage, older guard, actual public anchors and custody therefore
need separate verification before installation or publication claims.

The original builder records explicitly say their outer tool envelopes were
not separately saved, and their Git command records include stdout hashes and
lengths rather than all stdout bytes. My independently registered Git check
captures exact stdout, stderr and exit status for those path reads; this does
not reconstruct the missing earlier envelope. Captured input bytes and modes
were rechecked after these evidence-only replays.

I authored the q2743 and q2744 source assessments and the v4, v5 and v6
transform reviews, and was the q2545 draft peer. This is independent review
of the candidate assembly and verifier, not independent credit for every
underlying source assessment. No product code, builds, tests, fixtures, repairs
or runtime probes were run; no central source, queue, ledger, candidate or
publication was changed.
