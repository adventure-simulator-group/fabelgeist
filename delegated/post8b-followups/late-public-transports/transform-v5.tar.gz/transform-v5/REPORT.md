# Static review of the unrun post-8b transform v5

The v5 successor addresses the v4 checkpoint-3821 wording issue and adds
specific input and report-projection checks. I found no additional substantive
transform defect within this bounded static review. The checks below do not
establish that any candidate has been installed or that product behavior was
validated.

The four replacements recorded in `TRANSFORM-DERIVATION-v5.json` each match
once in the captured v4 text and reproduce the exact v5 bytes. The v5 digest is
`0ade7614be7eaff50253c1b1eeb96eb5ba7e1ed382880acf32aeecfb0ef29c34`;
the derivation digest is
`a9060365a0ef4405c5748416e00cd723574fecc193c939d699768fdb640d3833`.
The corrected text says neither 059 stream restores or represents the missing
checkpoint 3821 authority. That remains a historical qualification, not a
finding that the missing checkpoint was recovered.

At lines 26 and 50–55, the four before-image size, SHA-256, and Git-blob pins
match bytes independently captured from committed 8b. The captured raw commit
and root-tree objects also bind those four root entries and their 100644 modes
in an offline check. This proves identity relative to those same-machine Git
objects, not a signed remote anchor or complete repository history.

At lines 38–63, v5 requires the supplied report to be the prescribed projection
of the proposal: the proposal is copied; status, schema, pending reviews,
qualification and per-assessment disposition are adjusted; and the explicitly
attributed assembly review and prospective-adoption qualification are added.
All other proposal fields are retained. Candidate adoption wording remains
qualified by the later installation step. This review did not make or inspect
an actual report or after-image.

The proposal pin at lines 23–27 and 56 hashes a canonical reserialization of
the parsed proposal. The captured original proposal bytes do match that
serialization and SHA-256
`145555a6f5ad092174f4214b04e255660e5903dcb18bbef293baaca8b8500d44`.
The transform itself cannot distinguish a differently serialized input that
parses to the same object. The candidate must separately bind exact raw proposal
bytes if raw-byte identity is required. Likewise, hashes supplied for the
report and observation are checked against reserialized in-memory objects,
and the three assembly-review manifest strings are compared with hard-coded
values; these are not self-authenticating external files.

The three referenced assembly-review manifests match wrapped_scope's captured
v3, v4 and v5 public packets, and every declared member in those separately
captured packets matches its declared size and SHA-256. Their reports preserve
the q3044 attribution correction and the later application/installation review
requirement. They do not transfer source credit. The three future review-archive
paths, new report, main observation and post-8b index are absent from committed
8b. Their later staging, actual archive members and exact paths must be checked
by the candidate guard.

The observation comparison at lines 64–71 checks schema, ref, revision, tree,
and lexical ordering of supplied timestamp strings. It neither authenticates
the raw connector response nor establishes a valid UTC interval or the actual
published observation file. A separate candidate/installer check must bind the
reviewed report, raw proposal, review archives and exact main-observation file
to their actual inputs and the raw connector response, validate the interval,
and establish installation only after it succeeds. The coordinator states
those checks will be separate; they were not examined here.

The committed 8b root verifier dispatches to its final guard, which verifies
exact old root bytes and modes. After a successor changes those files, replay
the old guard in a separate clean 8b checkout. Its optional predecessor must
identify a separate clean 8ca checkout if the nested 8ca replay is required;
omitting it skips that nested replay. A new successor guard must verify the new
root files, links, application and installation independently.

The prior v4 review and its source/history findings remain separate, including
its arithmetic, original/reconstructed stream and historical-reader limits.
I authored the q2743 and q2744 source packets, performed the q2545 draft peer
review, and authored the v4 transform review; this additive transform review
is not independent source credit. The transform, predecessor guard, product,
fixtures, builds, tests and runtime probes were not run. No queue, ledger,
publication, or product file was changed.
