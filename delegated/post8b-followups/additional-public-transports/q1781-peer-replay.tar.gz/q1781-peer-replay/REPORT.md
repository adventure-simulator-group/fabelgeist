# Independent q1781 Lens 12 peer review

The selected source supports `wrapped_scope`'s bounded connection to the
existing q279 / ledger 413 source-digest propagation record. The source package
has a checked string owner, while selected terrain feature and manifest state
retains digest strings and selected road, dispatcher and map paths construct
or retain the checked package owner. This does not establish a supported
runtime failure, a new defect count, an exact historical alias, or closure of
the broader q1781 terrain and TIFF obligations.

At pinned revision `95e63628f9d70b8dd6e6fede64334696c6995009`, the reviewer
independently registered and displayed the complete
`crates/adventuresim-world-schema/src/source_package.rs:1–53` and 18 bounded
support windows. `SourcePackageDigest::from_hex` checks exactly 64 ASCII bytes
of digits or lowercase `a`–`f`; its constructor establishes encoding shape,
not a match to source bytes. Its `as_str`, display implementation, transparent
serialization and source-level custom deserializer are distinct text or wire
boundaries. The authored deserializer calls that constructor; no serde, macro or
wire framework was executed. The error text is presentation, not a proved
machine classification or digest identity.

`crates/adventuresim-terrain/src/digest.rs:9–14` constructs the package owner
as a Boolean hex-shape predicate and separately formats hash output. The
selected feature record and terrain manifest retain source, package, content,
road geometry and decoded-chunk digests as strings. `validate_manifest` uses
the same shape helper on several of those fields. Equal lowercase-hex syntax
is not proof that their identities are interchangeable or that each should
carry `SourcePackageDigest`; the source-package documentation explicitly
separates geometry content and placement bindings. The identity and contract of
each retained field must be decided at its own boundary.

The selected loader validates textual shapes and source code compares a
recomputed manifest/package digest and pack content digest before retaining the
manifest. It does not by itself prove every upstream source input was
independently rehashed or every supported ingress was traced. `RoadManifest`
contains a typed source, compares it with the selected terrain digest and keeps
geometry and content checks separate; `RoadPack::write` reconstructs a typed
source from `terrain.digest()`. The selected dispatcher and map producer also
admit the terrain package digest into the owner. The selected HTTP route uses a
typed path extractor and compares that source to the loaded package, but this
source review establishes no actual request or framework rejection behavior.
Native filesystem paths, coordinate-system text, formatting tokens and human
diagnostics retain separate roles.

Source references and open boundaries are listed in `SOURCE-MAP.json`. The
selected source includes hashing code, but no product hash, decoder, TIFF,
fixture, test, build, runtime probe or repair was run. Other producers,
source-getter recipients, supported admission and identity policy remain open.

## Historical and process qualifications

Original 059 q1781, `Q-L12-de486d8c43b8eee412bb`, is
`open-evidence-or-disposition`; its published 8b wrapper is `unassessed`. The
selected original and reconstructed objects match as parsed, while the full
streams differ. Its source context spans more terrain, road, TIFF and hash
work; a shared source context does not prove contract identity. q279 / ledger
413 already records the related propagation question and is partial at 8b;
ledger 0 is an earlier partial owner-fit review. q280 / ledger 414 concerns
validation-message classification, and q281 / ledger 415 concerns TIFF error
erasure. The separate q121 TIFF record shares selected expressions but is not
an established alias. q1809's animation/naming question and the earlier road
geometry-kind question also remain distinct, with policy and reach open.

Recovered `segovb/READ-L12-700.json` binds a separately registered and
receipted 6533 full 1–53 source-package read to `lens12_frontier`; it is not a
Root-personal read or inherited physical-role read. The receipt's original
source-registry index 2171 is not asserted as a 059 queue index. Its later
ordered application requires the specified registration, approved receipt,
identity and attribution; this review applies no historical population count.
The 6533, e275 and 95e source-package file is one blob in three different
trees. The current author and current peer are separate readers; file identity
is not a whole-tree equality or a fresh historical read.

The author's first support capture requested 1–75 from a 64-line file and
failed before that support display; its partial bytes and tool-visible-only
traceback reconstruction remain alongside a separately registered 1–64
successor. Of five author match-line displays, three included test-source
text; the retained report successor corrects an earlier overstatement. The
author prepared the current numbered view before exact registration but
attests that it was not displayed until afterward. The author's public replay
with a repository anchor binds whole queue and wrapper hashes; it does not by
itself compare the extracted q1781 row. This peer's evidence verification
separately checks that row and its wrapper. This peer's first evidence verifier
failed on a case-sensitive process-metadata assertion; its original traceback
and case-corrected successful successor are retained. Both reviewers' personal
displays remain attestations, not independent telemetry. Adjacent unrelated
code is context only and earns no other-family credit.

The protected extraction was read without mutation. The original 059 stream,
Git objects and selected historical and prior current assessments remain
same-machine dependencies. Missing checkpoint 3821, SOURCE004, 73
nontext/no-positive-EOF obligations, reconstructed 440 and normalized 774
versus missing pre-export originals remain open or qualified. No independent
backup, full Git closure, audit-wide completion or product validation is
claimed.
