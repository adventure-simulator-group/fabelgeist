#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,subprocess
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();ap=argparse.ArgumentParser()
for n in ('repo','private-manifest','replay-manifest','original-stream-manifest','original-queue','private-selection','extraction'):ap.add_argument('--'+n,type=Path)
a=ap.parse_args();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q1781-l12-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
s=json.loads((p/'SOURCE.json').read_bytes());main=(p/'CURRENT-SOURCE.rs').read_bytes();assert s['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and h(main)==s['objects'][s['main_path']]['sha256'] and len(main.decode().splitlines())==53 and len(s['views'])==22
for v in s['views']:
 b=(p/v['name']).read_bytes();assert h(b)==v['sha256']
 if v['path']==s['main_path']:
  lo,hi=v['range'];lines=main.decode().splitlines();assert b==''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
sel=json.loads((p/'SELECTION.json').read_bytes());assert sel['index']==1781 and sel['original']['lens']==12 and sel['original']==sel['reconstructed'] and sel['selected_equal_as_parsed'] and not sel['full_streams_equal'] and sel['current']['current_reconciliation']=='unassessed';projection=json.loads((p/'SELECTION-PROJECTION.json').read_bytes());assert h((p/'SELECTION.json').read_bytes())==projection['public_selection_sha256'];rel=json.loads((p/'RELATIONSHIPS.json').read_bytes());assert [rel['ledger_entries'][str(i)]['id'] for i in (0,413,414,415)]==['REVIEW-TERRAIN-SOURCE-DIGEST-PROPAGATION-001','SEGOVB-L12-TERRAIN-SOURCE-DIGEST-PROPAGATION','SEGOVB-L12-TERRAIN-VALIDATION-TEXT-CLASSIFICATION','SEGOVB-L12-TERRAIN-TIFF-ERROR-ERASURE']
old=(p/'REPORT-ORIGINAL.md').read_text();new=(p/'REPORT.md').read_text();assert old.replace('Five registered matching-line displays included test\nsource text','Among five registered matching-line displays, three included test\nsource text')==new
bind=json.loads((p/'BINDING.json').read_bytes());hist=json.loads((p/'HISTORY.json').read_bytes());assert hist['historical_registry_index']==2171;r=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert len(r['checks'])==2 and all(x['exit']==0 and x['stderr_bytes']==0 for x in r['checks']);sealed=json.loads((p/'SEALED-CHECK.json').read_bytes());assert sealed['result']=='passed' and sealed['sealed_private_manifest_sha256']==bind['private_manifest_sha256']
checks=['public member identities, assigned source, view hashes, selected metadata and recorded replay'];not_checked=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','postseal_replay_manifest_sha256'),('original_stream_manifest','original_stream_manifest_sha256'),('original_queue','original_queue_sha256')]:
 q=getattr(a,attr)
 if q is None:not_checked.append(attr+' not supplied')
 else:assert h(q.read_bytes())==bind[key];checks.append(attr+' identity')
if a.private_selection is None:not_checked.append('private selection projection not supplied')
else:
 raw=a.private_selection.read_bytes();assert h(raw)==projection['private_selection_sha256'];safe,n=re.subn(rb'/[^/\s`]+/(lens12_frontier)',rb'\1',raw);assert n==8 and safe==(p/'SELECTION.json').read_bytes();checks.append('exact selected-record alias projection')
if a.extraction is None:not_checked.append('protected historical receipts not supplied')
else:
 x=hist['root_receipt'];assert h((a.extraction/x['locator']).read_bytes())==x['sha256']
 for x in hist['connected_records']:assert h((a.extraction/x['locator']).read_bytes())==x['sha256']
 checks.append('three historical record identities')
if a.repo is None:not_checked.append('Git identities, support views and 8b ledger not supplied')
else:
 def git(*cmd):
  r=subprocess.run(['git','-C',str(a.repo),*cmd],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0 and not r.stderr;return r.stdout
 for z in s['main_historical_objects']:assert git('rev-parse',z['revision']+'^{tree}').decode().strip()==z['tree'] and git('rev-parse',z['revision']+':'+s['main_path']).decode().strip()==z['blob'] and git('show',z['revision']+':'+s['main_path'])==main
 cache={}
 for path,z in s['objects'].items():
  b=git('show',s['revision']+':'+path);assert git('rev-parse',s['revision']+':'+path).decode().strip()==z['blob'] and h(b)==z['sha256'] and len(b.decode().splitlines())==z['lines'];cache[path]=b.decode().splitlines()
 for v in s['views']:
  lo,hi=v['range'];lines=cache[v['path']];assert (p/v['name']).read_bytes()==''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 for prefix,x in json.loads((p/'MATCH-REGISTRATIONS.json').read_bytes()).items():
  cmd=['git','-C',str(a.repo),'grep','-n','-F']
  for term in x['patterns']:cmd+=['-e',term]
  r=subprocess.run(cmd+[x['revision'],'--',*x['paths']],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode in (0,1) and not r.stderr and r.stdout==(p/(prefix+'-RESULT.txt')).read_bytes()
 rev=rel['checkpoint'];recon=git('show',rev+':baseline-059/queue.json');wrap=git('show',rev+':RECONCILIATION-059.json');ledger=git('show',rev+':BASELINE-95E-20261110.json');assert h(recon)==sel['reconstructed_sha256'] and h(wrap)==sel['reconciliation_sha256'] and h(ledger)==rel['ledger_sha256'];entries=json.loads(ledger)['newly_assessed_ledger']['entries'];assert all(entries[int(k)]==v for k,v in rel['ledger_entries'].items());assert h(git('show',rev+':ASSESSMENT-TERRAIN-ADMISSION-95E.json'))==bind['prior_assessment_sha256'] and h(git('show',rev+':ASSESSMENT-DELEGATED-RECONCILIATION-6-95E.json'))==bind['prior_delegated_assessment_sha256'];checks.append('three per-file identities, 22 views, five match sets, 8b ledger and prior reports')
if a.original_queue is not None:
 entries=json.loads(a.original_queue.read_bytes())['entries']
 def norm(x):
  if isinstance(x,str):return re.sub(r'/[^/\s`]+/(lens12_frontier)',r'\1',x)
  if isinstance(x,list):return [norm(z) for z in x]
  if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
  return x
 assert norm(entries[1781])==sel['original']
 for k,v in rel['rows'].items():
  row=entries[int(k)];assert row['contract_id']==v['contract_id'] and ('status' in row)==v['original_status_present'] and row.get('status')==v['original_status']
 checks.append('original selected queue metadata and alias projection')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence identities only; not independent display telemetry, supported reach, runtime behavior, global historical recovery or independent custody.'}))
