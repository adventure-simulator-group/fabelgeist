# q1781: source-package strings, bounded Lens 12 assessment

The selected 95e source has an existing checked owner for an imported source
package digest, but the related terrain manifest and feature state retain
several hashes as raw strings. The selected loader checks their text shape;
selected road, dispatcher and map paths then construct or retain the checked
source-package owner. This supports the already recorded q279/ledger 413
propagation question. It does not establish that geometry, content, decoded
chunks and imported source packages are the same identity, that every source
and consumer was traced, or that a supported runtime failure exists.

Reviewer `wrapped_scope` independently displayed
`crates/adventuresim-world-schema/src/source_package.rs:1–53`, the complete
current file, after registering Lens 12. Product revision is
95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. The current file and the two
historical revisions 6533 and e275 share one Git blob; their trees differ.
This is individual-file identity, not whole-tree equivalence or a fresh
personal historical read. Selected support views and literal-match displays
are separately registered. No product code, tests, fixtures, hash operation,
TIFF decoder, build, macro expansion or runtime probe was executed.

## Assigned-file string inventory

* The module comments at :1–5 are descriptive prose and explicitly separate
  source-package identity from geometry content and placement bindings. The
  authored `#[serde(transparent)]` attribute at :11–13 specifies a native wire
  representation; its macro expansion and runtime behavior were not run.
* `SourcePackageDigest` privately stores an owned `String` (:13). Its public
  `from_hex(&str)` constructor (:18–28) admits exactly 64 ASCII bytes composed
  of digits or lowercase `a` through `f`. Empty, uppercase and other text is
  rejected by the authored check. This is an encoding/shape contract; the
  constructor alone does not establish that the text matches any particular
  source bytes. No case-normalization defect is inferred.
* `as_str` and the `Display` implementation (:30–38) expose the checked value
  as text for native consumers. The custom deserializer (:41–44) receives a
  string and routes it through the same constructor in source. Whether every
  wire framework invokes that implementation, all feature configurations and
  all callers remain open; no serde implementation was executed.
* The diagnostic at :47–50 is human-facing error presentation. It is not
  shown to be an internal semantic identity or a machine-readable error code.
  Replacing every prose string, path, format token or external representation
  with a digest owner would erase their different roles.

## Selected producer and consumer chain

`adventuresim-terrain/src/digest.rs:9–14` constructs
`SourcePackageDigest` only to return `is_ok()` and separately formats native
SHA output as text. `builder/features.rs:4–10` carries wetland and cultivated
source hashes as raw strings. The selected world-import path supplies wetland
source text to that record and sets the cultivated source from another record
(`build-strategic-map.rs:136–150,201–208`,
`build-strategic-map/terrain_features.rs:24–64`); the same source contains a
named no-cultivation hash input. Its actual external data production and
cryptographic computations were not run.

`terrain/src/builder.rs:175–198` clones those feature strings into `Manifest`,
separately derives content and road-geometry digest strings, and constructs a
package digest; :198–208 shows the intended JSON/file-output boundary without
executing it. `terrain/src/lib.rs:268–288,300–311` retains source, content,
geometry, package and decoded-chunk fields as distinct raw strings.
`validate_manifest` checks their accepted textual shapes at :948–986, while
`TerrainPack::load` shows a selected manifest/content identity comparison and
retains the manifest (:322–395). Accessors :413–432 return raw `&str`. These
selected source checks do not prove all supported ingestion paths or that
source-data bytes are independently recomputed at this boundary.

`road_pack.rs:29–44,81–108,120–136,178–188` declares a typed
`RoadManifest.source`, reconstructs that owner from `terrain.digest()` for
selected output, and retains a typed road-pack source. Its geometry and content
digest fields remain different strings with distinct comparisons. A selected
regional-terrain capture and map producer re-admit `pack.digest()` as the
owner (`tactical-server-dispatcher/src/regional_terrain.rs:26–27` and
`strategic-web/src/strategic_map/producer.rs:65–79`). The selected HTTP route
uses a route-template string and `Path<SourcePackageDigest>` at
`strategic-web/src/routes/map_environment.rs:21,34–40,51–58`; that declaration
is a wire boundary, not evidence of a runtime request, framework error mapping,
or a reason to conflate URL paths with internal digest identity. Native
`&Path` inputs and output paths in the inspected loader/builder are filesystem
boundaries; diagnostic prose remains distinct. The `EPSG:3035` text in the
selected terrain metadata is a separate coordinate-system contract whose
complete owner and callers were not assessed here.

## Historical records and open work

Original 059 q1781 is `Q-L12-de486d8c43b8eee412bb`,
`open-evidence-or-disposition`; its 8b wrapper is unassessed. The selected
original and reconstructed records match as parsed, but the complete streams
differ. The q1781 record links 6533 terrain features, digest and the larger
terrain file as well as `source_package.rs`; it explicitly says the source
context link is not contract-identity proof. This packet covers the assigned
source-package file and selected cohesive support only. The remaining
source-getter recipients, native TIFF, hashes/current source and other lenses
in the broader historical question are not closed.

`segovb/READ-L12-700.json` and the separately hash-bound connected registration
and receipt preserve `lens12_frontier`'s personal 6533 source-package read of
1–53. It is not a Root-personal read or an inherited physical-role read. The
historical receipt records a later ordered application rule for original
registry index 2171, with exact qualification and no redundant reread; that
registry index is not asserted to be a 059 queue index and this review does
not apply a historical population count. The new 95e read and its reviewer are
separate. No evidence is promoted into the unrecovered checkpoint 3821.

q279/ledger 413 records the related raw source-digest propagation finding;
ledger 0 separately records an earlier partial propagation/owner-fit review.
q280/ledger 414 concerns validation-message classification and q281/ledger
415 concerns TIFF error erasure, with their original first operations and
readers retained. The q1809 source context has an animation/naming question,
so sharing a receipt context does not make it the same contract. A prior
`rig_identity` WEB-MAP-02 observation in
`ASSESSMENT-DELEGATED-RECONCILIATION-6-95E.json` separately asks whether road
geometry identity must include displayed kind; its assumptions, policy and
alias remain open. These relationships neither add a defect count nor close
q1781 or the lens.

The first support-3 capture requested lines 1–75 from a 64-line producer file
and failed before those windows were displayed. Its partial files and the
separately registered 1–64 successor are preserved; the original traceback was
tool-visible only. Among five registered matching-line displays, three included test
source text at terrain `lib.rs:2024,2029`, dispatcher `scene_input.rs:940,945`
and world-import `build-strategic-map.rs:1014,1019`; test-module marker lines
were subsequently checked. No test or fixture ran. Other adjacent support
content is context, not extra lens coverage. The current source was captured
for identity before its exact display registration, but its 1–53 view was not
displayed until after that registration. Display chronology is
reviewer-attested, not independently telemetered.

The protected extraction remained read-only. The original full 059 queue,
protected historical records, Git objects and prior assessment are separately
held same-machine dependencies for strongest replay. SOURCE004, 73
nontext/no-positive-EOF obligations, reconstructed 440, the 774 normalized
versus missing pre-export originals qualification, and missing 3821 remain
open or qualified. This work changes no queue, ledger or product file and
claims no repair, validation, unique count or lens closure.
