# Independent q3051 Lens 13 peer review

The selected source supports `wrapped_scope`'s bounded assessment. The
initializer accepts primitive profile leaves, a raw character key and an NPC
flag, while converting weights and indices at native sampling boundaries.
`UnitBasisPoints` is a candidate owner for an individual 0–10,000 value; it
does not by itself enforce either the three-weight total of 10,000 or the
narrower incidence maximum of 1,000. Construction, wire admission and
cross-crate identity ownership still require separate decisions. This peer
review proposes no defect count, repair, queue or ledger adoption, or lens
closure.

At source revision `95e63628f9d70b8dd6e6fede64334696c6995009`, the reviewer
independently registered and displayed the complete assigned
`crates/adventuresim-world-schema/src/language/initialization.rs:1–54` and
24 bounded support windows. The file passes `character_id: u64` through
`Seed::from` for two distinct deterministic streams with empty context. It
widens three `u16` weights to `u64`, obtains a native sampled index and uses
it in the matching three-variant array. Three maximal `u16` weights have a sum
far below `u64` capacity. The selected wrapper delegates distribution
construction and sampling to Rand, maps returned errors, and the initializer
uses `expect`; the external sampler's complete implementation was not
independently inspected here. The existing q3132/ledger 450 assessment records
the default-zero weighted-profile precondition; it is not counted again.

The incidence draw occurs only when the supplied `npc` flag is true. The
selected sampler source documents a half-open draw from zero to the nonzero
10,000 bound; comparison is against the widened incidence leaf. If a call
reaches that draw with incidence at least 10,000, every value in that stated
interval satisfies the comparison. This is conditional source reasoning, not
proof that such a profile is supported or reaches the call. The public profile
fields are `u16`; `is_valid` checks the German weight total and incidence cap,
but the initializer does not itself call it. The checked
`UnitBasisPoints::new` constructor handles one whole-unit bound; the authored
transparent `Deserialize` derive is a separate admission route, and neither
this review nor the constructor proves all wire or SATS ingress enforces the
bound.

The selected character-creation path projects `CharacterCreationMode::is_npc`
and passes the key and flag into initialization; a settlement reset forwards a
Boolean, and one selected mission bootstrap caller passes true. The nearby
strategic `CharacterId` wrapper is crate-private, whereas initialization lives
in shared schema. A shared owner, the seed identity, durable character key and
tactical identity must not be assumed interchangeable. The selected importer
checks profile validity and equality to geographic inference, then constructs a
settlement row and updates an existing row. The intervening source was examined
for this connection. This one path does not establish all constructors,
deserializers, stored data, callers, a committed transaction, or supported
reach.

The initializer's oral-hours assignments use the 5,000-hour and 0.8 authored
constants, selected correlations and a nonnegative zero floor; written hours
are defaulted separately. Existing oral and written records own their
aggregates; float admission, rounding, wire representation, NPC and literacy
policy remain open. Preserve deterministic stream identity, draw ordering and
supported modes before choosing any future change.

## Historical records and relationships

Original 059 q3051 is `own-lens-proof-qualification-or-read-pending`, with no
assessed own-lens range and zero body/population credit. Its 8b wrapper is
`unassessed`. The selected original and reconstructed rows match as parsed,
while full streams differ. The 6533, e275 and 95e assigned file has one Git
blob and three different trees. Root's 6533 Lens 3 receipt credits a fresh
1–54 read; its e275 record qualifies same-lens reuse with no fresh reread. The
selected frozen prior row was entirely fresh, even though the general reuse
basis preserves mixed attribution. None of those records confers Lens 13 credit.

The earlier q3044 Lens 6 source assessment was authored by `wrapped_scope` and
independently peer-reviewed by `mhr_character`. The peer registered and
personally attested assigned-file displays at 6533, e275 and 95e: two
historical revisions and one current revision. This reviewer previously
reviewed only q3044 central synthesis and did not personally display q3044
source then. That prior sealed synthesis-review report incorrectly called all
three assigned-file displays historical; this paragraph is an additive
correction and does not change the original packet or transfer reader credit.
The coordinator reports that the central q3044 draft and five-row proposal
already use the correct sequence; those central artifacts were not recaptured
in this review.

q3132 / ledger 450 concerns the weighted sampler's zero/default precondition;
q3132 had no original status key and the 8b wrapper is partial. q3040 / ledger
1095 concerns profile-leaf producer propagation; its original own-lens record
was pending and its wrapper partial. q131 separately concerns basis-point wire
admission, and q2374 a language owner complement. These distinct first
operations and their supported-ingress questions do not prove an alias, global
closure or additional unique count.

The q3051 author's first public candidate was left unsealed after a finite
privacy scan found four private-value or digest matches in one generated
verifier. The retained successor uses a generic alias projection and passed a
finite scan; the predecessor and diagnostic remain restricted. The author's
other captured process corrections and the later metadata-only scan-receipt
truncation remain separately attributed. This peer's first history-capture
checker failed on string-encoded modes; its v2 corrected that but failed on a
delivery manifest's `name` versus `path` field. Both scripts, tracebacks and
partial snapshots are retained, and a fresh v3 captured the selected records.
An earlier capped q3044 registration metadata preview is process-only. Exact
source displays are reviewer-attested, not independently telemetered.

Missing checkpoint 3821, SOURCE004, 73 nontext/no-positive-EOF obligations,
reconstructed 440, and normalized 774 versus missing pre-export originals
remain open or qualified. The strongest evidence replay needs same-machine Git
objects and the protected read-only extraction; the packet is not an
independent backup or full Git closure. No product code, test, fixture, build,
macro expansion, repair, or runtime probe was executed.
