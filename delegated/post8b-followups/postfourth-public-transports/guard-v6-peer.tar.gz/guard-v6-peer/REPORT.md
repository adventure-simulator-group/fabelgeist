# Independent static review: post-8b guard v6 and trial preparation v1

The v6 additions match the declared v5-to-v6 derivation and bind the reviewed
privacy driver and the fourth custody receipt. Two pre-execution concerns remain:
inherited Git environment variables weaken the optional predecessor claim, and
the v1 trial mode preparation can leave incompletely recorded mode changes. A
hard-link check is also needed before changing a trial file's mode.

The review did not build or run the guard, trial preparation, installer, or
product. The reviewer authored the separately held third and fourth custody
groups and reviewed earlier guard and candidate versions. This is an independent
comparison of the coordinator's v6 transformation, not independent authorship of
those underlying custody groups.

## Guard and staged evidence

- `BUILD.py:14-47` inventories the prospective stage and requires the index,
  application, and custody manifests. It pins the reviewed privacy driver SHA-256
  before copying it; `VERIFY-TEMPLATE.py:23-49` independently pins the installed
  driver and stage manifest. The root template is unchanged from v5.
- The v6 additions add the fourth no-key verifier and receipt checks. The stage
  observation found all 96 third and 32 fourth ciphertext bytes consistent with
  their manifests and unique within-group nonce prefixes, and both receipt member
  identities and recorded restore fields consistent. This independent metadata
  check did not execute the supplied verifiers, authenticate, or compare the
  separate prior nonce inventories. Git's executable bit is not full POSIX mode.
- Twenty-two no-argument curated verifier paths, the first custody receipt
  verifier, and the candidate verifier existed and were syntax-parsed. Selected
  verifier bodies and the candidate chain were inspected; this is not a complete
  semantic audit of every child verifier. Thirty-three selected index references
  existed in the 481-file, 34-directory stage observed at that time. Two later
  stage additions were announced afterward and are outside that observation.
- With no predecessor, the candidate does not check old root paths. With only a
  predecessor, it checks selected 8b parent paths but skips the old guard. With
  both predecessor and ancestor, it invokes the 8b wrapper, which routes to its
  final guard and passes the 8ca predecessor to its application replay. The
  wrapper and final guard matched their individual 8b Git blobs. Full object
  availability, correct checkout, and earlier independent replay remain separate.

`VERIFY-TEMPLATE.py:50-55` and candidate `VERIFY.py:65-66,98-118` retain ambient
`GIT_*` variables. `GIT_DIR`, `GIT_WORK_TREE`, or `GIT_INDEX_FILE` can redirect
Git's selected predecessor checks. The qualified chain therefore assumes a
controlled Git environment. Clear inherited overrides and validate checkout
roots; any necessary object alternate needs an explicit identity-bound input.
The coordinator is preparing a separately reviewed v7.

## Sparse trial preparation

`PREPARE.py:47-63` records the five initial modes in memory, performs each
`chmod`, and writes `RESULT.json` only after all changes. A failure may leave
some changed files without a durable per-file before/after journal. `RUN.py`
records child streams and discloses partial change, but does not inventory it.

`PREPARE.py:49-57` checks regular paths and rejects symlinks, but does not
reject hard links before `chmod`. Such a change affects every name for the same
inode. At the time of this review each of the five trial files had link count
one; no cross-checkout mutation was observed. Check the opened file's identity
and link count immediately around any descriptor-based mode change, while
retaining the limits of concurrent mutation and interrupted writes.

The root capture required by `PREPARE.py:18-24` was not yet present. The trial
is sparse and shares an object store; it cannot replace the full predecessor
checkout. A separately versioned successor is outside this review.

Two metadata locators failed: one guessed a nonexistent nested predecessor
path, and one misspelled a scratch filename. Neither displayed source. Their
tool-visible errors were not captured byte-for-byte; the corrected captures
and this process qualification are retained privately. Source displays are
reviewer-attested, and retained captures include undisplayed complements.
