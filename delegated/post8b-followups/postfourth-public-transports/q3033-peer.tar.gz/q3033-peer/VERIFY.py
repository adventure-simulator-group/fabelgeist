from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,subprocess
p=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((p/n).read_bytes())
a=argparse.ArgumentParser()
for n in ('repo','original','extraction','author-public','private-manifest','private-replay-manifest','private-report'):a.add_argument('--'+n,type=Path)
v=a.parse_args();m=J('MANIFEST.json');assert m['schema']=='q3033-l7-peer-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,x in m['files'].items():
 q=p/n;assert len(PurePosixPath(n).parts)==1 and q.is_file() and not q.is_symlink();b=q.read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
s=J('SELECTION.json');assert s['index']==3033 and s['original']==s['reconstructed'] and s['original']['lens']==7 and s['current']['current_reconciliation']=='unassessed' and not s['full_streams_equal'];q=s['original']['exact_source_identities_and_assessed_ranges'][0];assert q['required_ranges']==[[1,756]] and q['assessed_ranges']==[]
src=J('SOURCE.json');assert len(src['views'])==10 and len(src['identities'])==3 and len({x['tree'] for x in src['identities']})==3 and len({x['git_blob'] for x in src['identities']})==1
for x in src['views']:assert H((p/x['name']).read_bytes())==x['sha256']
r=J('RELATED-SUMMARY.json');assert all(x['raw_equal'] and x['equal_as_parsed'] for x in r['rows'].values()) and len(r['rows'])==7;assert [r['ledger_ids'][str(i)] for i in (450,451,452,1095)]==['REVIEW-L3-INITIAL-LANGUAGE-PROFILE-WEIGHTS','REVIEW-WRITTEN-LANGUAGE-NAN-GATE-95E','REVIEW-LANGUAGE-PARTY-DUPLICATE-IDENTITY-95E','relationship-language-profile-leaf-propagation-95e']
bind=J('BINDING.json');assert H((p/'AUTHOR-REPORT.md').read_bytes())==bind['author_report_sha256'] and H((p/'REPORT.md').read_bytes())==bind['report_sha256'];rr=J('RECORDED-REPLAY.json');assert len(rr['checks'])==2 and all(z['exit']==0 and z['stderr_bytes']==0 for z in rr['checks']) and rr['private_manifest_sha256']==bind['private_manifest_sha256'];e=J('EVIDENCE-IDENTITIES.json');checks=['public manifest, ten views, selected metadata and recorded private replay'];omitted=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('private_replay_manifest','private_replay_manifest_sha256'),('original','original_stream_sha256'),('private_report','report_sha256')]:
 f=getattr(v,attr)
 if f is None:omitted.append(attr+' not supplied')
 else:assert H(f.read_bytes())==bind[key];checks.append(attr+' identity')
if v.author_public:
 root=v.author_public;raw=(root/'MANIFEST.json').read_bytes();assert H(raw)==bind['author_manifest_sha256'];a=json.loads(raw);assert {x.name for x in root.iterdir()}==set(a['files'])|{'MANIFEST.json'}
 for n,z in a['files'].items():
  q=root/n;b=q.read_bytes();assert q.is_file() and not q.is_symlink() and len(b)==z['bytes'] and H(b)==z['sha256']
 assert (root/'REPORT.md').read_bytes()==(p/'AUTHOR-REPORT.md').read_bytes();checks.append('author public exact manifest and all members')
else:omitted.append('author public packet not supplied')
if v.original:
 original=json.loads(v.original.read_bytes());assert original['entries'][3033]==s['original'];checks.append('selected q3033 in original full stream')
if v.extraction:
 for x in e['historical_records']:
  z=(v.extraction/x['locator']).read_bytes();assert len(z)==x['bytes'] and H(z)==x['sha256']
 d=v.extraction/'root-l3-extension-20261030';part=json.loads((d/'PARTIAL-ROOT-L3-EXT-020-027-001.json').read_bytes());old=json.loads((d/'READ-ROOT-L3-EXT-020-027.json').read_bytes());cur=json.loads((d/'READ-ROOT-L3-CURRENT-004.json').read_bytes());ad=json.loads((v.extraction/'adler/READ-L11-339.json').read_bytes());assert any(x.get('registration')=='ROOT-L3-EXT-0027' and x['ranges']==[[1,756]] for x in part['registered_unread']);o=next(x for x in old['rows'] if x.get('registration')=='ROOT-L3-EXT-0027');c=next(x for x in cur['rows'] if x.get('registration')=='ROOT-L3-CURRENT-0030');z=next(x for x in ad['sources'] if x.get('original_index')==2163);assert o['fresh_personal_ranges']==[[1,756]] and c['fresh_personal_ranges']==[] and c['qualified_reuse_ranges']==[[1,756]] and 'adopted source receipt' in c['qualified_reuse_basis'] and z['fresh_reads']==[[1,756]] and 'revision' not in z;checks.append('seven receipt identities and selected historical fields')
else:omitted.append('protected history not supplied')
if v.repo:
 def git(*args):
  z=subprocess.run(['git','-C',str(v.repo),*args],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert z.returncode==0 and not z.stderr;return z.stdout
 rev=src['revision'];sources={}
 for x in src['identities']:
  path='crates/adventuresim-world-schema/src/language.rs';assert git('rev-parse',x['revision']+'^{tree}').decode().strip()==x['tree'] and git('rev-parse',x['revision']+':'+path).decode().strip()==x['git_blob'] and H(git('show',x['revision']+':'+path))==x['sha256']
 for x in src['views']:
  if x['path'] not in sources:
   b=git('show',rev+':'+x['path']);assert H(b)==x['source_sha256'] and git('rev-parse',rev+':'+x['path']).decode().strip()==x['git_blob'];sources[x['path']]=b.decode().splitlines()
  low,high=x['range'];lines=sources[x['path']];assert len(lines)==x['source_lines'] and (p/x['name']).read_bytes()==''.join(f'{i:4} {lines[i-1]}\n' for i in range(low,high+1)).encode()
 cp='8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b';assert git('rev-parse',cp+'^{tree}').decode().strip()=='552bb7853c70fea3c124eb0096d53e3e99b9439a';qb=git('show',cp+':baseline-059/queue.json');wb=git('show',cp+':RECONCILIATION-059.json');lb=git('show',cp+':BASELINE-95E-20261110.json');assert H(qb)==s['reconstructed_sha256'] and H(wb)==s['reconciliation_sha256'] and H(lb)==r['ledger_sha256'];queue=json.loads(qb)['entries'];wrap=json.loads(wb)['entries'];led=json.loads(lb)['newly_assessed_ledger']['entries'];assert queue[3033]==s['reconstructed'] and wrap[3033]==s['current'];assert all(queue[int(i)]['contract_id']==x['contract_id'] and wrap[int(i)]==x['current'] for i,x in r['rows'].items());assert all(led[int(i)]['id']==x for i,x in r['ledger_ids'].items());checks.append('git identities, ten exact views, 8b selected metadata')
else:omitted.append('Git sources and 8b records not supplied')
print(json.dumps({'result':'pass','checks':checks,'not_checked':omitted,'qualification':'Evidence-only verifier; no product execution. Source displays are reviewer-attested, whole-tree equivalence and independent custody are not claimed. Full restricted replay checks exact selected rows, all author private members and requires separately held same-machine anchors.'},indent=2))
