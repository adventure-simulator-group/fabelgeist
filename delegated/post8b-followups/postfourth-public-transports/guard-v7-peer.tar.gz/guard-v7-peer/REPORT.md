# Independent static review: post-8b guard v7

The unbuilt v7 successor addresses the v6 ambient-Git-environment concern for
the selected child checks. It removes inherited `GIT_*` values at both the root
and staged guard, applies controlled Git configuration, checks supplied
checkout roots, and permits a supplemental alternate only with an explicit
inventory and caller-supplied digest. The remaining stage-inclusion and
provenance conditions below need separate attention.

- `ROOT-TEMPLATE.py:12-36` requires all three alternate arguments together,
  forwards them only with a predecessor, and clears inherited Git variables.
- `VERIFY-TEMPLATE.py:55-95` clears inherited Git variables again, applies the
  controlled settings, verifies the inventory file hash, compares every file
  byte identity and directory name in the supplied alternate, and checks each
  supplied predecessor's Git top level before calling child verifiers. The
  candidate and nested predecessor inherit that controlled environment.
- The caller-supplied inventory digest binds the invocation to those bytes;
  it does not itself prove their origin. The guard checks file contents and
  directory names, not original full filesystem modes or entire Git closure.
  Its one comparison does not preclude concurrent replacement afterward.
- The independently inspected same-machine supplemental inventory matched
  eight files, ten directories and its separately recorded full modes. Its
  `info` directory was empty at that observation. Other Git object stores and
  on-disk alternates remain dependencies; a pointer file does not inventory the
  store it names. This is not independent custody.
- The additive `GUARD-REPLAY-COMMAND-CORRECTION.md` fixes the earlier note's
  non-executable script command and states both the concurrency and on-disk
  alternate limits. The earlier note is preserved.
- The v7 builder is byte-identical to v6. It snapshots and binds the replay
  note, correction, and inventory generator if present, but does not explicitly
  require those three files. Require their presence or separately review the
  final stage capture before installation.

The v6-to-v7 source differences are confined to the described argument,
environment, inventory and checkout-root handling. A predecessor alone checks
selected 8b paths without running the old guard; the ancestor option triggers
its nested 8ca replay, subject to separately retained objects. The stage and
its later documentation are prospective; no guard, inventory generator,
installer, or product was executed in this review. Earlier v6 review and the
third and fourth custody groups are by this reviewer and remain separately
attributed. A later build, full privacy scan, installation, fresh observation,
and independently anchored recovery remain separate.
