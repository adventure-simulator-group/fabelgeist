# Independent static review: trial preparation v5 and capture anchor v2

The unrun trial v5 wrapper addresses the v4 inventory-status finding: it
requires all five post-child files and all ten before/after journal records to
match the child's completed plan before returning success. Its preparation
program is byte-identical to v4, so the retained child result correctly keeps
its v4 schema and its descriptor-sync ordering remains unchanged.

`RUN.py:54-89` binds the reviewed preparation program and caller-supplied root
capture before and after the child. It checks each file's digest, mode, inode,
device and single-link state, then compares the complete journal entries with
the plan. A failed or unreadable post-child inventory no longer qualifies as a
successful wrapper result. The wrapper and capture digest still need separate
trusted identities at invocation; concurrency, interruption and storage
failures remain qualified, and no rollback is attempted.

The first root-capture anchor had three limitations: optional Git locks were
not disabled, its wrapper did not pin the reviewed child, and its stdout could
be read as claiming every source was unchanged. The separately preserved v2
anchor sets `GIT_OPTIONAL_LOCKS=0`, pins its child by whole-file hash, and
narrows that stdout field to the root capture. Its wrapper must itself be bound
at invocation. The v2 anchor compares the future capture with the exact 8b
parent and tree, the five existing before-images and modes, and the eight
candidate after-images; it remains unrun.

An independent point-in-time metadata check found eleven selected private and
staged candidate pairs byte-identical, including the two privacy-driver
before-images. The underlying candidate files are not copied into this review;
they and the Git object store remain separately held. The future root capture,
its provenance, the final stage and installed state require later verification.
The sparse trial is not a full predecessor checkout or independent backup.

No trial, anchor, wrapper, Git status, guard, installer, product, build, test,
or runtime probe was executed. The reviewer authored the separately sealed
v1, v3 and v4 trial reviews; their attribution and limitations remain distinct.
