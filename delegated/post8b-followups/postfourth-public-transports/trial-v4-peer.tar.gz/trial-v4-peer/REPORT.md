# Independent static review: sparse trial mode preparation v4

The unrun v4 successor addresses the v3 input-binding and file-sync ordering
findings in source. Its wrapper pins the reviewed preparation program and a
caller-supplied root-capture digest before and after the child; the preparation
script requests `fsync` on the changed descriptor before its completion journal.
The caller must still bind the eventual root-capture digest to an independent
retained capture. No trial or filesystem operation was executed here.

`PREPARE.py:98-118` retains the v3 plan, single-link and inode checks, before
journal, descriptor-based `fchmod`, and post-change checks. It now requests
file `fsync` before the fsynced after journal. Local Linux manual text describes
`fsync` as flushing file metadata and lists possible errors; no filesystem or
crash behavior was tested. Concurrent changes, interruption, and underlying
storage guarantees remain outside the claim.

`RUN.py:18-28,53-72` checks the hard-pinned program and caller-supplied capture
hash, records both again after the child, and requires the child's result to
refer to that capture. The wrapper itself and the supplied digest still need
separately retained identities. Pre-child assertion failures need an outer
invocation record; abrupt termination or storage failure may also prevent the
wrapper's own record.

`RUN.py:43-52,70` catches and records each post-child inventory error, but the
success predicate does not reject error or nonregular entries and does not
compare inventory values against the final plan. Thus exit zero alone proves
only child and input/result-binding conditions, not a complete matching
post-run inventory. An installer or operator relying on that inventory should
validate it separately or require a successor to do so.

The v3-to-v4 whole-file derivation hashes match and the earlier v3 review is
separately preserved. A broad local-manual locator output was truncated; the
relevant ranges were subsequently displayed in bounded windows and exact
manual captures remain restricted. No guard, trial, wrapper, product, build,
test or runtime probe was run. The sparse trial and its Git objects remain
same-machine dependencies, not an independent predecessor checkout.
