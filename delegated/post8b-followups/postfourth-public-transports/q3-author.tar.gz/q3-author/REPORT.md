# q3: bounded floor-interval behavior assessment

Reviewer: `wrapped_scope`. This fresh Lens 8 source review uses product commit
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`; queue and ledger context is the
published 8b checkpoint. It does not close the whole obligation or lens.

The recovered original q3 Lens 8 observation concerned an already existing
finite-elevation interval invariant, not an introduced behavior regression
in its named files. Its batch registration records identical base/head hashes
for `single/apron.rs` and `single/floor.rs`. Their 6533 Git blobs, normalized
f82 transport objects and current 95e blobs match per file. The receipt calls
the earlier base `3a50`, but that short prefix is ambiguous in this object
store; its full base commit is not established here. Thus historical base
file equality is retained as the original receipt's evidence, not a newly
bound base tree. Other dependencies and whole-program behavior may differ.

At current 95e, `crates/adventuresim-tactical-core/src/city_layout/grounding/single/apron.rs:128–148`
computes the usable run, crossfall, ramp and stair rise, then directly stores
both endpoints as `SupportElevation`. The owner at
`crates/adventuresim-tactical-core/src/city_layout/grounding.rs:73–83`
defines that type as finite and checks its public constructor. The selected
source-pair and range producers at
`grounding/single/apron.rs:197–227` and `grounding/foundations/source.rs:19–30,63–98,164–176`
return checked finite sample elevations. `grounding/single/floor.rs:37–64`
intersects the temporary endpoints with bearing bounds; `:82–112` chooses a
floor and checks the final elevation again. `grounding/single.rs:74–102`
prepares matching aprons, selects, assembles and performs later admission. A
nonfinite temporary endpoint therefore is not evidence that a nonfinite floor
or terrain is accepted, rendered or reaches gameplay.

The public policy path admits more than the selected standard values:
`grounding/stairs.rs:23–64` accepts `PositiveLength` fields whose constructor
at `crates/fabelgeist-geometry/src/length.rs:9–30` requires only finite and
strictly positive values; `crates/adventuresim-building-generator/src/spatial_geometry.rs:8–10`
reexports that type. Under ordinary IEEE binary32 arithmetic, the already
published source-level example in `ASSESSMENT-SUPPORT-INTERVAL-95E.json`—an
available run of 8, positive width, equal zero source heights, grade 1, riser
1 and minimum going 2^-126—makes the exact quotient 2^129 exceed the largest
finite binary32 number. In that conditional calculation, the stair rise can
be positive infinity and the unchecked typed endpoints negative and positive
infinity. This is integer/source reasoning, not an executed parser, geometry
operation, fixture, renderer or product test; it does not show that a valid
complete `PreparedApron` with those correlated operands is constructible or
reached. The selected `bounded_settlement` constants at
`compiled/support/policy.rs:14–27` instead use riser 0.19 and going 0.25;
`scene/grade.rs:8–20` supplies its 0.65 grade. Those ordinary constants do not
by themselves establish all geometry bounds or disprove other public policy
paths. Native floating behavior, other producers and supported reach remain
open. The earlier historical maximum-grade/powi witness retains the previous
report's platform/precision qualification and is not treated as observed.

## Relationships and historical limits

Original 059 q3 has `open-reconciliation` status; its 8b wrapper remains
unassessed. Six selected original and reconstructed entry bytes match, while
their full streams differ. The exact historical Lens 8 batch attests a
personal read of apron `1–281` and floor `1–115`; those facts and its original
attribution do not transfer to this current reader. The 059 discovery ledger
retains the same observation as that receipt and adds the origin proof.

The distinct original q260 Lens 12 record and 8b ledger 325 identify the same
first unchecked endpoint retention. Its separate `READ-L12-603` receipt records
fresh personal reads but the selected apron/floor rows have no standalone
revision, Git-path or reader fields; per-file identity does not fill them.
q1527/q1528 are Lens 12 interval follow-ups, q1533 concerns the separate
`CourtStairLimits::maximum_rise_metres` operation and q1539 preserves ordinary
fixture-source limitations. The published support-interval and fixture
assessments remain separately attributed; their reads supply no new Lens 8
credit here. The shared first operation is a relationship for central
reconciliation, not a declared global alias, new defect count or closure.

Further work should decide whether interval endpoints are explicitly unbounded
or overflow is rejected through the correct owner, then preserve the selected
ordering, feasibility checks, diagnostics and final admission; a supported
producer tuple and all connected consumers need separate evidence. These are
planning questions, not implemented repairs or completed product validation.

The 22 registered current windows are reviewer-attested, not independently
telemetered. Full source blobs were read internally for identity; an initially
registered apron window containing test text was withheld from display and a
production-only successor was displayed. A support window did display a
`compile_fail` documentation example and another a `cfg(test)` import as
source text only. No test, fixture, renderer, product code, build, repair or
runtime probe ran. A prior q0 filename listing was unregistered, tool-truncated
and uncaptured; later bounded q0 metadata inspection supplied no base commit.
The q260 receipt's initially capped excerpts were followed by a complete
selected-field rerender. The ambiguous base lookup and exact private stderr
are retained. Original queue, historical extraction and Git objects are
separately held same-machine replay dependencies; checkpoint 3821, SOURCE004,
the 73 nontext/no-positive-EOF items, 440 reconstruction qualifications and
the 774 pre-export-original distinction remain open.
