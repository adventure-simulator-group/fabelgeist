from pathlib import Path,PurePosixPath
import argparse,json,hashlib,subprocess,os,re
p=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((p/n).read_bytes());a=argparse.ArgumentParser()
for n in ('repo','original','extraction','q0','private-manifest','private-replay-manifest','private-report'):a.add_argument('--'+n,type=Path)
v=a.parse_args();m=J('MANIFEST.json');assert m['schema']=='q3-l8-floor-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,x in m['files'].items():
 q=p/n;assert len(PurePosixPath(n).parts)==1 and q.is_file() and not q.is_symlink();b=q.read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
s=J('SELECTION.json');assert s['index']==3 and s['original']==s['reconstructed'] and s['original']['lens']==8 and s['original']['status']=='open-reconciliation' and s['current']['current_reconciliation']=='unassessed' and not s['full_streams_equal']
src=J('SOURCE.json');assert len(src['views'])==22 and len(src['identities'])==2
for x in src['identities']:assert len(x['revisions'])==3 and len({z['tree'] for z in x['revisions']})==3 and len({z['blob'] for z in x['revisions']})==1
for x in src['views']:assert H((p/x['name']).read_bytes())==x['sha256']
r=J('RAW-SELECTION.json');assert len(r)==6 and all(x['raw_equal'] and x['equal_as_parsed'] for x in r.values());rel=J('RELATED-SUMMARY.json');assert rel['ledger']['325']['id']=='SEGOVB-L12-APRON-FLOOR-INTERVAL-ELEVATION-ADMISSION' and rel['queue']['3']['current']['current_reconciliation']=='unassessed';history=J('HISTORY-SUMMARY.json');assert history['q260_selected_receipt']['selected_rows'][0]['revision_present'] is False and history['q260_selected_receipt']['selected_rows'][0]['reader_field_present'] is False
witness=J('ARITHMETIC.json');assert witness['exact_quotient_integer']==1<<129 and witness['largest_finite_binary32_integer']==((1<<24)-1)*(1<<104) and witness['quotient_exceeds_finite_binary32'];binding=J('BINDING.json');rr=J('RECORDED-REPLAY.json');assert rr['private_manifest_sha256']==binding['private_manifest_sha256'] and len(rr['checks'])==2 and all(x['exit']==0 and x['stderr_bytes']==0 for x in rr['checks']) and H((p/'REPORT.md').read_bytes())==binding['report_sha256'];checks=['public member identities, 22 registered views, selected records and integer algebra'];omitted=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('private_replay_manifest','private_replay_manifest_sha256'),('private_report','report_sha256'),('original','original_stream_sha256')]:
 f=getattr(v,attr)
 if f is None:omitted.append(attr+' not supplied')
 else:assert H(f.read_bytes())==binding[key];checks.append(attr+' identity')
indices=sorted(map(int,r))
def slices(raw):
 text=raw.decode();z=re.search(r'"entries"\s*:\s*\[',text);assert z;pos=z.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \t\r\n,':pos+=1
  start=pos;x,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(x,text[start:pos].encode())
 return out
if v.original:
 x=slices(v.original.read_bytes());assert all(H(x[i][1])==r[str(i)]['original_sha256'] and len(x[i][1])==r[str(i)]['original_bytes'] for i in indices) and x[3][0]==s['original'];checks.append('six exact original queue slices')
e=J('EVIDENCE-IDENTITIES.json')
if v.extraction:
 for x in e['historical_records']:
  b=(v.extraction/x['locator']).read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
 batch=json.loads((v.extraction/'evidence/continuation-segovb/audit-resume-20261027/lens08/batch-011-originals1839-1848.json').read_bytes());reg=json.loads((v.extraction/'evidence/continuation-segovb/audit-resume-20261027/lens08/REGISTRATION-027.json').read_bytes());l12=json.loads((v.extraction/'segovb/READ-L12-603.json').read_bytes());old=J('HISTORICAL-LEDGER-Q3.json');assert batch['lens']==8 and all(old[k]==x for k,x in batch['qualified_source_observation'].items());assert all(x['base_equal'] and x['base_sha256']==x['head_sha256'] for x in reg['sources'] if x['original'] in (1840,1843));assert l12['lens']==12
 for i in (0,3):
  x=l12['rows'][i];assert x['fresh_personal_body_reads'] and 'revision' not in x and 'git_path' not in x and not any(k in x for k in ('reader','read_attribution','attribution'))
 checks.append('four old receipt identities, q3 ledger correspondence and q260 selected recorded fields')
else:omitted.append('protected historical extraction not supplied')
if v.q0:
 raw=(v.q0/'MANIFEST-PRIVATE.json').read_bytes();assert H(raw)==binding['q0_manifest_sha256'];q=json.loads(raw)
 for x in e['q0_selected_metadata']:
  b=(v.q0/x['name']).read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256'] and q['files'][x['name']]['sha256']==x['sha256']
 checks.append('q0 manifest and four metadata members only')
else:omitted.append('separate q0 metadata not supplied')
if v.repo:
 def git(*args):
  z=subprocess.run(['git','-C',str(v.repo),*args],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert z.returncode==0 and not z.stderr;return z.stdout
 for x in src['identities']:
  for z in x['revisions']:assert git('rev-parse',z['revision']+'^{tree}').decode().strip()==z['tree'] and git('rev-parse',z['revision']+':'+z['path']).decode().strip()==z['blob'] and H(git('show',z['revision']+':'+z['path']))==x['source_sha256']
 sources={}
 for x in src['views']:
  if x['path'] not in sources:
   b=git('show',src['revision']+':'+x['path']);assert H(b)==x['source_sha256'] and git('rev-parse',src['revision']+':'+x['path']).decode().strip()==x['git_blob'];sources[x['path']]=b.decode().splitlines()
  lo,hi=x['range'];lines=sources[x['path']];assert len(lines)==x['source_lines'] and (p/x['name']).read_bytes()==''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 cp='8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b';assert git('rev-parse',cp+'^{tree}').decode().strip()=='552bb7853c70fea3c124eb0096d53e3e99b9439a';qb=git('show',cp+':baseline-059/queue.json');wb=git('show',cp+':RECONCILIATION-059.json');lb=git('show',cp+':BASELINE-95E-20261110.json');assert H(qb)==s['reconstructed_sha256'] and H(wb)==s['reconciliation_sha256'] and H(lb)==rel['ledger_sha256'];qq=slices(qb);w=json.loads(wb)['entries'];l=json.loads(lb)['newly_assessed_ledger']['entries'];assert all(H(qq[i][1])==r[str(i)]['reconstructed_sha256'] for i in indices) and qq[3][0]==s['reconstructed'] and all(w[int(i)]==x['current'] for i,x in rel['queue'].items()) and l[325]['id']==rel['ledger']['325']['id'] and l[325]['classification']==rel['ledger']['325']['classification']
 for x in e['published_objects']:assert H(git('show',cp+':'+x['path']))==x['sha256']
 old=json.loads(git('show',cp+':baseline-059/ledger.json'))['discovery_findings_and_dependencies']['CONT08-SINGLE-FLOOR-INTERVAL-REPRESENTATION'];assert old==J('HISTORICAL-LEDGER-Q3.json');checks.append('historical/current file identities, 22 exact current views, 8b selected queue/ledger and report identities')
else:omitted.append('Git sources and 8b metadata not supplied')
print(json.dumps({'result':'pass','checks':checks,'not_checked':omitted,'qualification':'Evidence identities and integer algebra only; source displays are reviewer-attested, q0 option checks selected members only, base abbreviation is not resolved, and no native runtime, complete lens or independent custody claim is made.'},indent=2))
