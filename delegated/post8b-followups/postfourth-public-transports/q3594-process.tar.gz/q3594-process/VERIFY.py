from pathlib import Path,PurePosixPath
import argparse,json,hashlib,subprocess,os
p=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((p/n).read_bytes());a=argparse.ArgumentParser();a.add_argument('--main',type=Path);a.add_argument('--repo',type=Path);v=a.parse_args();m=J('MANIFEST.json');assert m['schema']=='q3594-l5-process-correction-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,x in m['files'].items():
 q=p/n;assert len(PurePosixPath(n).parts)==1 and q.is_file() and not q.is_symlink();b=q.read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
b=J('BINDING.json');r=J('MARKER.json');assert all(r[k] is True for k in ('line_476_is_test_attribute','line_477_is_tests_module','line_553_has_helper_name'));checks=['public correction member identities and recorded metadata-only successor'];omitted=[]
if v.main:
 raw=(v.main/'MANIFEST.json').read_bytes();assert H(raw)==b['main_manifest_sha256'];mm=json.loads(raw);assert {q.name for q in v.main.iterdir()}==set(mm['files'])|{'MANIFEST.json'}
 for n,x in mm['files'].items():
  q=v.main/n;z=q.read_bytes();assert q.is_file() and not q.is_symlink() and len(z)==x['bytes'] and H(z)==x['sha256']
 assert H((v.main/'REPORT.md').read_bytes())==b['main_report_sha256'];checks.append('original public packet all member identities')
else:omitted.append('original public packet not supplied')
if v.repo:
 z=subprocess.run(['git','-C',str(v.repo),'show','95e63628f9d70b8dd6e6fede64334696c6995009:crates/adventuresim-core/src/strategic_time.rs'],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert z.returncode==0 and not z.stderr and H(z.stdout)==r['source_sha256'];lines=z.stdout.decode().splitlines();assert lines[475].strip()=='#[cfg(test)]' and lines[476].strip().startswith('mod tests') and 'epoch_micros_for_official_minute' in lines[552];checks.append('Git source identity and three metadata-only predicates')
else:omitted.append('Git source not supplied')
print(json.dumps({'result':'pass','checks':checks,'not_checked':omitted,'qualification':'Metadata only; Git show reads source internally but no test body is displayed or executed. Earlier unregistered check was tool-visible only and is not retroactively registered.'},indent=2))
