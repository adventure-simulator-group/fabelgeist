# Independent static review: sparse trial mode preparation v3

The v3 successor addresses the v1 write-ahead and hard-link concerns for an
uncontended trial: it records a complete preflight plan, journals each intended
mode change before applying it, and changes the verified single-link inode via
its open descriptor. The wrapper records child streams and a post-child
inventory. The programs remain unrun.

The comparison retains two execution and durability qualifications. First, the
wrapper records the preparation program hash before and after, but does not pin
the reviewed hash; the future root capture is also hashed but not independently
pinned. Second, the completion journal is fsynced without an intervening fsync
of the mode-changed file descriptor. After power loss, the completion record
alone cannot prove that mode metadata persisted. Verify the inputs against
separately retained identities and re-inventory after interruption, or bind the
inputs and add file fsync in a separately reviewed successor.

- `PREPARE.py:44-57,83-97` requires a regular file opened with `O_NOFOLLOW`,
  checks its path, inode, device, and single link, and fsyncs a five-file plan
  before any mode change.
- `PREPARE.py:98-117` reopens the planned inode, checks its digest and mode,
  fsyncs a before record, rechecks inode and link count, then uses `fchmod`.
  It verifies the resulting bytes, mode and inode before fsyncing an after
  record. A concurrent mutation can still occur between checks and the mode
  operation; no protection against such races is claimed.
- `RUN.py:15-50` records child streams, program hashes, the five-file
  post-child inventory, and journal names. A wrapper crash, interruption, or
  storage failure can prevent or truncate this record; the operation is not
  transactional and no rollback occurs.
- The v3 derivation's v2 and v3 whole-file hashes match. Its wrapper differs
  from v2 only in the result schema. The v2 preflight/journal change is retained;
  v3 adds the single-link and descriptor checks.

The root capture was absent at the preceding review and must be produced and
bound separately. The isolated checkout is sparse and shares Git objects; it
is not an independent full predecessor checkout. The reviewer previously
reported the v1 concerns. This review does not execute a trial, installer,
guard, product, test, or probe, and no installed result is claimed.
