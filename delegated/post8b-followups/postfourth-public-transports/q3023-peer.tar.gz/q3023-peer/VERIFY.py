from pathlib import Path, PurePosixPath
import hashlib
import json

p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes())
assert m['schema']=='726-q3023-l9-peer-public-manifest-v1' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1
 f=p/n;assert f.is_file() and not f.is_symlink();raw=f.read_bytes();assert len(raw)==row['bytes'] and h(raw)==row['sha256']
b=json.loads((p/'BINDING.json').read_bytes());s=json.loads((p/'SOURCE-MAP.json').read_bytes())
assert b['queue_index']==3023 and b['lens']==9 and b['wrapper_status']=='unassessed' and len(s['registered_windows'])==13
assert b['author_public_manifest_sha256']=='c50e9b0bc0b403f9211d0e89ec707deb2878f3eca5a4c0072ad89d7d67fe9e3e'
print(json.dumps({'public_members':len(m['files']),'registered_windows':13,'result':'passed','qualification':'Public file identity and stated scope only; no source correctness, personal display telemetry, product validation or independent custody.'}))
