# Independent q3023 bestiary requirement-shape review

Reviewer: `final_guard_peer`. The selected source supports `wrapped_scope`'s
bounded Lens 9 assessment at product revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Queue and ledger status is from
published checkpoint `8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. This is a
partial source review; q3023's broader obligation and the lens remain open.

`BestiaryCategory` is a closed enum, while `BestiaryHours` retains simultaneous
hours for multiple categories (`crates/adventuresim-world-schema/src/bestiary.rs:15–29,154–220`).
The selected validity result and direct-study gate are computed rather than
stored flags. The exact gate at `:224–228` returns zero for a direct target
`<= 0.0`; it should not be paraphrased as proving a positive target when
nonfinite input is possible. Admission and nonfinite behavior remain separate
from the selected state-shape nonfinding.

`Requirement::SkillRating` carries a string skill and optional string leaf
(`crates/adventuresim-core/src/organization.rs:340–352`). It can represent a
directly constructed `bestiary` requirement with no leaf. The selected
authored validator requires a listed bestiary leaf and forbids leaves for
ordinary skills (`organization_catalog_validation.rs:47–61,132–174`); the
inspected build path passes paired documents and sources to that validator
(`crates/adventuresim-core/build.rs:389–429,449–455`). This supports the
author's qualification for that selected path, not a guarantee for all
constructors, decoding, native admission or supported inputs.

For the directly constructed missing-leaf case, the inspected starting
character lookup finds no bestiary value and its requirement check returns
false (`crates/adventuresim-core/src/starting_character.rs:789–882`). If a
character skills row exists, the native requirement check returns its unknown
skill-requirement error (`crates/adventuresim-stdb-module/src/organization.rs:145–167,195–220`).
The selected life-simulation conversion instead constructs a `FixedSkill`
target with the skill string (`crates/adventuresim-core/src/life_simulation.rs:274–299`).
Its later training and player-visible outcomes were not established. These
are conditional source traces, not a supported malformed input or runtime
witness.

The result corroborates the separately recorded q2503 / ledger 1110 requirement
shape question; the prior native error branch is not a new finding count.
Original q2373 / ledger 445 and q3021 concern related category and training
authority questions; q3016 / ledger 1096 concerns tactical propagation, and
q3019 and q3130 / ledger 444 concern aggregate and admission behavior. Their
first operations, supported reach and alias decisions remain distinct.

Original q3023 has status `own-lens-proof-qualification-or-read-pending` and
requires historical bestiary `1–330` with no own-Lens 9 assessed range. Its 8b
wrapper is `unassessed`. Eight selected original and reconstructed queue
slices match byte for byte, although the full streams differ. An earlier Root
Lens 3 partial record listed the bestiary range as unread; the later 6533
receipt records Root's fresh full-range Lens 3 read. The e275 row describes
qualified reuse based on the adopted prior receipt, has no fresh e275 read and
contains no pending-adoption field. A separate Adler Lens 11 `pr-working`
receipt reports a full-range read for original registry index 2157 without a
standalone revision field. None supplies Lens 9 credit or checkpoint 3821
recovery. The 6533, e275 and 95e file blob is the same while their trees
differ; historical source bodies were captured for identity but not personally
displayed in this peer review.

The author reports earlier q2503 authorship; the retained prior public report
uses an independent-reviewer alias. The author also peer-reviewed q3019 and
q3021 under other lenses. This reviewer authored q3019 and its gate wording
correction. Those earlier roles and `mhr_character`'s separately attributed
q3021 work do not transfer source or lens credit to this review.

Thirteen newly registered current-source windows were personally displayed;
their displays are reviewer-attested, not independently telemetered. The
author's 19 views were compared as bytes against Git; the author's bestiary
test-source window was read as text only and never executed. Adjacent
membership, unrelated skill, practice-cadence and written-language lines in
the peer's registered windows are process-only context, with no additional
assessment or coverage credit.

The author's v1 public verifier's recorded optional extraction check passed for
six receipt byte identities; v2 additionally reconstructs selected reader,
revision, range and reuse fields. An early author message incorrectly
conflated another task's failure, an adoption-pending qualifier and a delivery
path; the later corrections and both packet generations are retained. This
peer's first archive-member capture used an incorrect prefix and its second
used an incorrect path split; both tracebacks and partial outputs remain, with
a successful separately named third capture. The full member-name locator
output was saved even though its tool display was capped.

The original queue, protected extraction, prior reports and Git objects remain
same-machine dependencies. Missing checkpoint 3821, SOURCE004, 73
nontext/no-positive-EOF items, reconstructed 440 qualifications and the
normalized 774 / missing pre-export distinction remain open. No product code,
test, fixture, build, repair or runtime probe was executed, and no queue or
ledger was edited.
