from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent;m=json.loads((p/'MANIFEST.json').read_bytes());assert {f.name for f in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,x in m['files'].items():
 f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
print(json.dumps({'public_files':len(m['files'])+1,'qualification':'Public member identities only; source, historical anchors, personal-display attestations and independent custody require separately held evidence.'}))
