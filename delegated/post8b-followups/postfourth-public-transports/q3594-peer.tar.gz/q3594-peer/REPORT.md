# Independent peer review: q3594 calendar aggregate state

The separately registered source views support the author's two conditional
calendar observations. A pre-start target can violate an epoch helper's
documented exact-target promise, and the documented year cap can make two
distinct representable minutes share a displayed year and day. The supported
reach and intended policy for both remain open; neither is a newly counted
defect or a closure claim.

The reviewed source is commit `95e63628f9d70b8dd6e6fede64334696c6995009`,
tree `1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The queue and ledger context
is checkpoint `8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. This peer review
is independent of the q3594 author, `wrapped_scope`. The peer previously
reviewed that author's q3598 Lens 9 calendar slice and later displayed
environment-time expressions in a q6 reducer window. Those earlier reads are
separately attributed and provide no Lens 5 credit here.

## Exact-target helper

`StrategicMinute::new` admits zero, and `elapsed_since` uses saturating
subtraction (`crates/adventuresim-world-schema/src/calendar.rs:99–105,148–150`).
The helper documented as deriving an epoch for an exact target subtracts
`WORLD_START_MINUTE` with that operation
(`crates/adventuresim-core/src/strategic_time.rs:401–411`). For target zero it
therefore computes zero elapsed minutes and returns the supplied `now_micros`.
The selected official conversion at `strategic_time.rs:381–399` then returns
the world-start minute, 332,640, rather than zero. Whether pre-start targets
should be supported or rejected is a policy question. The author's bounded
literal-name lookup does not establish a supported production caller or rule
out aliases and external users.

## Capped calendar projection

The calendar year calculation caps at `i32::MAX`, while the day-of-year
calculation continues cycling (`calendar.rs:380–399`). Independent integer
algebra confirms that minutes 1,128,716,593,336,800 and
1,128,716,593,862,400 both fit `u64` and both project to year 2,147,483,647,
day 1. The selected wedding presenter formats those two fields together
(`crates/strategic-web/src/routes/settlements/residences.rs:28–31,229–240`).
The cap is documented, and alternate producers or a wedding date reaching
either value were not established; the example does not prove an unintended
product defect.

For the selected conversion of two `i64` wall-clock timestamps, saturating
subtraction limits elapsed microseconds to `i64::MAX`; the selected rate gives
an absolute upper bound of 8,015,549,840,859 minutes, below the first minute of
the maximum calendar year. This bound applies to that conversion only, not to
other `StrategicMinute` constructors or stored date ingress. The module alias
and selected clock call are visible at
`crates/adventuresim-stdb-module/src/time/mod.rs:8–10` and
`crates/adventuresim-stdb-module/src/time/clock.rs:2–30`.

The named non-leap start constants yield year 1544, one-based day 232 and a
non-Sunday day index (`calendar.rs:10–26,253–255,380–399`). The selected
Sunday consumer filters day indices through that predicate
(`crates/adventuresim-core/src/activity.rs:74–85`). The separate celestial
consumer uses the fractional calendar day without adding the start offset
again (`crates/adventuresim-core/src/celestial.rs:38–55`). External calendar
phase, all consumers and global conventions remain unassessed.

## History and relationships

Original q3594 has no `status` field, requires historical 6533
`calendar.rs:1–28`, and records no assessed Lens 5 ranges. Its 8b wrapper is
unassessed. The selected original and reconstructed raw objects are identical,
although the complete streams differ. Root's 6533 Lens 3 record credits a
fresh, untruncated personal read of :1–28. The e275 Lens 3 record instead
describes reuse with no fresh e275 read and frozen-source adoption still
pending. The calendar file is identical at 6533, e275 and 95e while their
Git trees differ. Same-file identity does not satisfy the pending condition,
transfer a reader's credit, or establish whole-tree identity.

q132 and ledger 28/446 address a separate extreme daily-share operation;
ledger 66 is a Sunday workload policy question. q192/ledger 781 and
q517/ledger 787 concern missing-clock zero projection; q2354 and q3304 concern
age eligibility and wedding countdown respectively. Ledger 12 and planning
relationship 1127 concern other clock saturation questions. Shared sources or
later repair planning do not establish aliases or unique-defect counts.

## Evidence and qualifications

Thirteen current windows were prospectively registered and personally displayed
for this review. Personal display is reviewer-attested, not independently
telemetered. Full source blobs, including unshown test text, were read
internally for identity; no test body was displayed or executed here. A small
preliminary integer calculation was tool-visible before the formal arithmetic
registration and had no separately saved transcript. A separately registered
successor reproduces the numbers without executing a product function. Housing
error text, activity morale, and pregnancy-related surrounding lines within
registered views are context only, with no separate coverage or finding.

The author retained an initial source-identity script that fetched unrelated
language blobs internally before its corrected calendar successor, a private
verifier label correction, and a failed correction-builder predecessor. The
additive process clarification states that full blobs containing test text were
read internally and records an unregistered test-marker metadata check followed
by a registered recheck. These do not transfer author reading credit. The peer
independently replayed the author and correction evidence verifiers; their
test-marker comparison did not display or execute test bodies.

All Git objects, extracted historical records and packet anchors are held on the
same machine. The peer's evidence checks are not product validation or an
independent backup. Missing checkpoint 3821, SOURCE004, the 73
nontext/no-positive-EOF items, reconstructed 440 qualifications and normalized
774's missing pre-export originals remain open. No product code, tests,
fixtures, builds, repairs or runtime probes were executed.
