from pathlib import Path,PurePosixPath
import argparse,json,hashlib,subprocess,os,re
p=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((p/n).read_bytes());a=argparse.ArgumentParser()
for n in ('repo','original','extraction','prior-author','prior-peer','private-manifest','private-replay-manifest','private-report'):a.add_argument('--'+n,type=Path)
v=a.parse_args();m=J('MANIFEST.json');assert m['schema']=='q3594-l5-calendar-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,x in m['files'].items():
 q=p/n;assert len(PurePosixPath(n).parts)==1 and q.is_file() and not q.is_symlink();b=q.read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
s=J('SELECTION.json');q=s['original']['exact_source_identities_and_assessed_ranges'][0];assert s['index']==3594 and s['original']==s['reconstructed'] and s['original']['lens']==5 and 'status' not in s['original'] and s['current']['current_reconciliation']=='unassessed' and not s['full_streams_equal'] and q['required_ranges']==[[1,28]] and q['assessed_ranges']==[]
src=J('SOURCE.json');assert len(src['views'])==13 and len(src['identities'])==3 and len({x['tree'] for x in src['identities']})==3 and all(x['git_blob']=='3bb463487d89fa1040b72d7708f7e641d5e61cec' and x['sha256']=='64e57270d86d0c5de29f25c63deb77421e1c0be5eb6ccb4b2e20f805ae9777bc' and x['lines']==698 for x in src['identities'])
for x in src['views']:assert H((p/x['name']).read_bytes())==x['sha256']
r=J('RAW-SELECTION.json');assert len(r)==8 and all(x['raw_equal'] and x['equal_as_parsed'] for x in r.values()) and not r['3594']['original_status_present'];h=J('HISTORY-SUMMARY.json');assert h['root_6533']['fresh_personal_ranges']==[[1,28]] and h['root_e275']['fresh_personal_ranges']==[] and h['root_e275']['qualified_reuse_ranges']==[[1,28]] and h['root_e275']['frozen_source_adoption_pending'] is True
rel=J('RELATED-SUMMARY.json');assert [rel['ledger'][str(i)]['id'] for i in (28,66,446,12,781,787,1127)]==['REVIEW-CALENDAR-RESTORATIVE-SHARE-001','OPEN-CANONICAL-SUNDAY-WORK-BUDGET-001','ADLER-L11-CALENDAR-DAILY-SHARE-ARITHMETIC','REVIEW-RESIDENCE-BILLING-CLOCK-EXHAUSTION-001','ADLER-L11-STRATEGIC-CLOCK-PROJECTION-ADMISSION','SEGOVB-L12-RESIDENCE-CLOCK-OBSERVATION-ZERO-DEFAULT','relationship-personal-clock-saturation-95e']
t=J('ARITHMETIC.json');delta=2**31-1-1544;mpy=365*1440;first=delta*mpy;second=first+mpy;bound=231*1440+((2**63-1)*mpy//(7*24*60*60*1000000));assert t['world_start_minute']==332640 and t['first_day_of_max_year']==first and t['one_year_later']==second and t['same_one_based_day']==[1,1] and second<=2**64-1 and t['selected_official_clock_upper_bound_for_i64_timestamps']==bound and bound<first
bind=J('BINDING.json');rr=J('RECORDED-REPLAY.json');assert rr['private_manifest_sha256']==bind['private_manifest_sha256'] and len(rr['checks'])==2 and all(x['exit']==0 and x['stderr_bytes']==0 for x in rr['checks']) and H((p/'REPORT.md').read_bytes())==bind['report_sha256'];checks=['public member identities, selected metadata, 13 views, source-algebra arithmetic and recorded private replay'];omitted=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('private_replay_manifest','private_replay_manifest_sha256'),('private_report','report_sha256'),('original','original_stream_sha256')]:
 f=getattr(v,attr)
 if f is None:omitted.append(attr+' not supplied')
 else:assert H(f.read_bytes())==bind[key];checks.append(attr+' identity')
for root,which,mname in [(v.prior_author,'author','PRIVATE-MANIFEST.json'),(v.prior_peer,'peer','MANIFEST.json')]:
 if root is None:omitted.append(which+' prior packet not supplied')
 else:assert H((root/mname).read_bytes())==bind['prior_'+which+'_manifest_sha256'] and H((root/'REPORT.md').read_bytes())==bind['prior_'+which+'_report_sha256'];checks.append(which+' prior manifest/report identity')
indices=sorted(map(int,r))
def slices(b):
 text=b.decode();z=re.search(r'"entries"\s*:\s*\[',text);assert z;pos=z.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \t\r\n,':pos+=1
  start=pos;x,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(x,text[start:pos].encode())
 return out
if v.original:
 x=slices(v.original.read_bytes());assert all(H(x[i][1])==r[str(i)]['original_sha256'] and len(x[i][1])==r[str(i)]['original_bytes'] for i in indices) and x[3594][0]==s['original'];checks.append('eight exact original queue slices')
if v.extraction:
 for x in h['historical_receipts']:
  raw=(v.extraction/x['locator']).read_bytes();assert len(raw)==x['bytes'] and H(raw)==x['sha256']
 old=json.loads((v.extraction/'root-l3-extension-20261030/READ-ROOT-L3-EXT-067-070.json').read_bytes());cur=json.loads((v.extraction/'root-l3-extension-20261030/READ-ROOT-L3-CURRENT-007.json').read_bytes());o=next(x for x in old['rows'] if x.get('registration')=='ROOT-L3-EXT-0069');c=next(x for x in cur['rows'] if x.get('registration')=='ROOT-L3-CURRENT-0068');assert o['revision']==h['root_6533']['revision'] and o['fresh_personal_ranges']==[[1,28]] and not o['body_output_truncated'] and c['revision']==h['root_e275']['revision'] and c['fresh_personal_ranges']==[] and c['qualified_reuse_ranges']==[[1,28]] and c['frozen_source_adoption_pending'] is True;checks.append('four historic identities and selected attribution fields')
else:omitted.append('old extraction not supplied')
if v.repo:
 def git(*args):
  x=subprocess.run(['git','-C',str(v.repo),*args],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert x.returncode==0 and not x.stderr;return x.stdout
 path='crates/adventuresim-world-schema/src/calendar.rs';rev=src['revision']
 for x in src['identities']:assert git('rev-parse',x['revision']+'^{tree}').decode().strip()==x['tree'] and git('rev-parse',x['revision']+':'+path).decode().strip()==x['git_blob'] and H(git('show',x['revision']+':'+path))==x['sha256']
 sources={}
 for x in src['views']:
  if x['path'] not in sources:
   b=git('show',rev+':'+x['path']);assert H(b)==x['source_sha256'] and git('rev-parse',rev+':'+x['path']).decode().strip()==x['git_blob'];sources[x['path']]=b.decode().splitlines()
  lo,hi=x['range'];lines=sources[x['path']];assert len(lines)==x['source_lines'] and (p/x['name']).read_bytes()==''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 cp='8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b';assert git('rev-parse',cp+'^{tree}').decode().strip()=='552bb7853c70fea3c124eb0096d53e3e99b9439a';qb=git('show',cp+':baseline-059/queue.json');wb=git('show',cp+':RECONCILIATION-059.json');lb=git('show',cp+':BASELINE-95E-20261110.json');assert H(qb)==s['reconstructed_sha256'] and H(wb)==s['reconciliation_sha256'] and H(lb)==rel['ledger_sha256'];qq=slices(qb);w=json.loads(wb)['entries'];l=json.loads(lb)['newly_assessed_ledger']['entries'];assert all(H(qq[i][1])==r[str(i)]['reconstructed_sha256'] for i in indices) and qq[3594][0]==s['reconstructed'] and all(w[int(i)]==x['current'] for i,x in rel['queue'].items()) and all(l[int(i)]['id']==x['id'] and l[int(i)]['classification']==x['classification'] for i,x in rel['ledger'].items());checks.append('three calendar identities, current views and 8b selected raw records/ledger metadata')
else:omitted.append('Git sources and 8b metadata not supplied')
print(json.dumps({'result':'pass','checks':checks,'not_checked':omitted,'qualification':'Evidence identities and independent integer arithmetic only. Personal displays are reviewer-attested; source equality is per-file. Prior packet options check manifest/report identity only. No runtime/product validation, global lens closure or independent backup.'},indent=2))
