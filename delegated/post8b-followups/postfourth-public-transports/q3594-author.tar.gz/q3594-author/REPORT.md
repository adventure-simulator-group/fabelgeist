# q3594: bounded calendar aggregate-state assessment

Reviewer: `wrapped_scope`. This is a fresh, independently registered Lens 5
assessment against product commit `95e63628f9d70b8dd6e6fede64334696c6995009`,
tree `1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. Queue/ledger context is 8b.
I authored the separate q3598 Lens 9 calendar review; `final_guard_peer`
independently reviewed that work. Neither provides Lens 5 credit here. This is
a bounded slice and connected trace, not closure of the full obligation/lens.

The named non-leap origin constants at
`crates/adventuresim-world-schema/src/calendar.rs:10–21` currently use 365 days,
1,440 minutes per day, start year 1544 and zero-based start day 231; the start
minute is derived from that day. Selected decomposition at `:253–255,380–399`
gives start year 1544 and one-based day 232, while the selected weekday rule at
`:23–26` makes day 231 non-Sunday. `crates/adventuresim-core/src/activity.rs:74–85`
uses that predicate for overlapping Sundays. The selected source gives no
basis to determine whether its weekday phase matches an external historical
calendar, or whether all users maintain the intended calendar convention.

## Conditional contract and aggregate questions

`CalendarYear` admits positive years and `StrategicMinute::new` accepts any
u64 (`calendar.rs:29–49,82–109`). The documented exact-target epoch helper at
`crates/adventuresim-core/src/strategic_time.rs:401–411` uses the saturating
`elapsed_since` at `calendar.rs:148–150`. For an admitted target
`StrategicMinute::ZERO`, its computed elapsed duration is zero and the helper
returns the supplied `now_micros`; the selected official-minute formula at
`strategic_time.rs:381–399` then yields `WORLD_START_MINUTE` (332,640), not
zero. This is a source-level mismatch with the helper's stated exact-target
contract for a pre-start target; whether that input should be rejected or
supported is a policy question. A tracked-repository literal-name locator
found only the declaration and an occurrence after the file's test-module
marker. This does not prove any supported production caller, alias, external
user or practical impact. No test body was read or executed.

Independently, `calendar.rs:380–399` caps the displayed calendar year at
`i32::MAX` while the day-of-year continues cycling. Two representable minutes,
1,128,716,593,336,800 and 1,128,716,593,862,400, therefore both project to
year 2,147,483,647, day 1. A selected wedding presentation formats those two
fields together in `crates/strategic-web/src/routes/settlements/residences.rs:28–31,229–240`.
The year cap is explicitly documented; this is a conditional loss of date
identity, not proof of an unintended product defect. The displayed example is
independent integer algebra, not product execution. The official conversion
shown at `strategic_time.rs:13–17,381–399`, for its two i64 timestamps, has an
algebraic upper bound of 8,015,549,840,859 minutes, below the first minute of
the maximum calendar year. That does not cover alternate constructors, stored
wedding-date ingress or all clock producers. Supported reach, intended
saturation/display policy and any transaction or user impact remain open.
`crates/adventuresim-stdb-module/src/time/mod.rs:8–10` links the selected
clock's conversion alias to that official formula; `time/clock.rs:2–30`
initializes and refreshes the selected clock. The separate celestial consumer
at `crates/adventuresim-core/src/celestial.rs:38–55` uses the fractional
calendar day without adding the start offset a second time.

## History, relationships and limits

The original 059 q3594 record has no `status` field, requires historical
6533 `calendar.rs:1–28` and has no assessed Lens 5 ranges; the 8b wrapper is
unassessed. Its selected original and reconstruction bytes match while the
full streams differ. Root's historical 6533 Lens 3 receipt records a fresh,
untruncated 1–28 personal read; the e275 Lens 3 row records qualified reuse
with frozen-source adoption still pending and no fresh e275 read. The same
calendar file blob occurs at 6533, e275 and 95e, whose trees differ. No
historical reader, reuse qualification, or other lens supplies this review's
read credit or becomes checkpoint 3821.

q132 and ledger 28/446 concern a separate extreme daily-share operation;
ledger 66 concerns the Sunday workload policy. q192/ledger 781 and
q517/ledger 787 concern missing-clock zero projection, rather than the
epoch-helper target contract; q2354 age eligibility and q3304 wedding
countdown are separately recorded questions. No aliases, unique-defect count,
repair authorization or supported reach follow from these relationships.

The 13 personal current-source views and their registrations are retained;
they are reviewer-attested, not independently telemetered. Full Git blobs
were captured for identity, not credited as complete reads. An initial copied
identity script mistakenly fetched three unregistered historical/current
`language.rs` Git blobs internally and printed their identities, not bodies;
its exact predecessor and logs are retained. The correctly registered calendar
source display remained valid, and a separately captured successor verified
the calendar identities. No Lens 5 credit is claimed for the unrelated
language blobs. No product execution, test, fixture, build, repair or runtime
probe was performed. The original queue, protected historic extraction,
prior packets and Git objects remain separately held same-machine replay
dependencies; missing 3821, SOURCE004, the 73 nontext/no-positive-EOF items,
440 reconstruction qualifications and normalized 774's missing pre-export
originals remain open.
