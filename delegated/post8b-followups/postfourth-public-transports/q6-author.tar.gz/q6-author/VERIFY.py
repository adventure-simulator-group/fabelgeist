from pathlib import Path
import hashlib,json,sys

p=Path(__file__).resolve().parent
m=json.loads((p/'MANIFEST.json').read_bytes())
expected=set(m['files'])|{'MANIFEST.json'}
assert {f.name for f in p.iterdir()}==expected
for name,meta in m['files'].items():
 f=p/name;assert f.is_file() and not f.is_symlink();v=f.read_bytes()
 assert len(v)==meta['bytes'] and hashlib.sha256(v).hexdigest()==meta['sha256']
print(json.dumps({'public_files':len(expected),'manifest_only':True,'qualification':'Public file identities only. Source, historical anchors, display attestations, modes, privacy and independent custody require separately held evidence.'}))
