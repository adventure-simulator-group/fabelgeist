# Independent review of the q2545 draft

Reviewer: /root/mhr_character. This review covers only q2545 Lens 3 and its
first planning relationship in the unadopted central draft at product commit
`95e63628f9d70b8dd6e6fede64334696c6995009`. The assessment author is
wrapped_scope; final_guard_peer supplied the earlier independent peer review.
I authored the separate q2743 and q2744 assessments and do not independently
review those portions here.

The selected source supports the draft’s admission distinctions. The public
`OrganizationAllocation::Scheduled` fields can combine a checked zero minute
value with an empty string, while `parse` rejects any organization paired with
zero and rejects a blank positive ID (`allocation.rs:7–75`). A zero duration
with no organization is a distinct valid `None` case. This is a representable
public API state, not evidence of a supported direct caller or saved row.
The web form calls `schedule::validate` before its reducer request
(`training_activity.rs:18–35,70–97`); the selected native update separately
validates numeric fields and organization pairs, checks membership/practice
permission and writes its rebuilt row (`stationary.rs:195–262`,
`time/schedule.rs:128–152`). Other callers, actual authorization and
transaction behavior remain open.

The selected simulation writer checks the aggregate day total before assigning
raw downtime, after owned-run, fresh-character and other guards, with further
fallible work after the update (`simulation.rs:253–263,349–493`). A symbolic
one-minute reading value with other fields zero is within that total but fails
the 15-minute numeric check (`allocation.rs:28–35,157–195`, `activity.rs:28`).
A committed row and a later `expect` require all other gates and transaction
conditions, a selected location and a relevant positive-time caller; none was
observed. The `Some(location)` web preview calls numeric validation, whereas
`None` returns a clone (`character_skills.rs:2103–2112`). Native stationary
handling uses the selected non-camp path before its numeric `expect`
(`stationary.rs:68–85`, `time/schedule.rs:71–89`).

The v4 draft did not explicitly say non-camp. In the JourneyCamp branch,
`camp_rest.rs:2–12` clears reading before the numeric validator. DRAFT-v5
correctly adds the non-camp qualification for this example; this does not
establish safety of other malformed camp fields. Its only parsed differences
from v4 are the q2545 finding, schema and predecessor hash, and the planning
relationship is unchanged. Both drafts remain unadopted.

The numeric `ValidatedSchedule` contract checks day and segment values, while
organization-pair validation is a separate saved-writer concern. The selected
stationary filter operates on a clone, can zero activity while leaving its ID,
and then uses numeric validation (`allocation.rs:177–195`,
`time/schedule.rs:155–192`); this temporary representation alone is not a
confirmed defect. `ScheduleAllocation` declares a default for its u16 and
optional fields (`time/model.rs:38–55`). The selected NPC initializer retains
its adult, uninitialized, unallocated guards and supplies no organization IDs
(`npc_causal.rs:195–250`); its producer and declared half-open sampler contract
show the bounded quarter-hour intent (`npc_policy.rs:123–135`,
`stream.rs:48–60`). No NPC execution or external sampler verification occurred.

The original q3301 first question names the `Some(location)` preview `expect`.
Its separately qualified later historical contract revisit names the
simulation total-only writer and leaves alternate writers and committed/runtime
outcomes open. The referenced proposal hash matches, and its selected contract view matches
the embedded view as parsed.
q2545’s 6533 Lens 3 source receipt, Root’s separate Lens 2 receipt and e275
same-lens reuse are separately attributed: the e275 receipt explicitly has no
fresh personal reread and requires frozen-source adoption, whose satisfaction
is unproved. The same web schedule file blob was verified at 6533, e275 and
95e; this does not equate whole trees or confer this reviewer’s historical read.

The original and reconstructed selected q2545, q628, q2494, q3301, q3444 and
q3462 rows match byte-for-byte while full queues differ. The first operations
remain distinct: q628 concerns the public organization variant, q2494 the
saved-schedule owner, q3444 organization identity, and q3462 the related
aggregate scope. Ledger 89 concerns independently supplied parallel activity
and organization durations; ledger 1120 is a planning relationship. Their 8ca
statuses and historical readers are not merged or promoted into the missing
checkpoint 3821, and no unique count or closure follows.

Twenty-three independently registered current windows are in the personal
receipt. An initially selected time/schedule 1–70 view described location
policy rather than the intended default; a separately registered time/model
view supplied the default field declaration. The route display included
test-annotated lines, read as text only. Prior peer display-receipt v2 corrects
five to six untruncated redisplay groups without changing its 17 windows. The
prior author’s clipped metadata view and peer’s initial truncated display,
relocation/replay and original-source qualifications remain separately held.
Display is reviewer-attested, not independent telemetry. All other writers,
raw ingress, rollback, selected location, supported effects, identity policy,
other camp fields and a global alias inventory remain open. No product code,
product parser, fixture, build, test or runtime probe ran; no repair or ledger
mutation was performed.
