# Independent q2801 Lens 13 review

The selected source supports the author’s bounded nonfinding for raw numeric
values in the assigned GPU-readiness file. Its numeric-looking `.0` accesses
project tuple-struct fields. The stored sets contain native `AssetId<Mesh>` and
`AssetId<Image>`; `contains` is a Boolean membership predicate. This result
covers only the independently displayed current source and does not close a
lens, establish runtime behavior, or transfer another reviewer’s credit.

At `crates/adventuresim-tactical-client/src/tactical_scene_viewer/`
`gpu_readiness.rs:14–50`, the installed shared observer replaces its mesh and
image sets from the render-world `RenderAssets` snapshot. `contains` requires
the requested mesh and every supplied texture ID. An empty texture iterator
therefore imposes no texture requirement, while the mesh is still required.
The Boolean does not establish that all material inputs, shader pipelines, a
rendered frame, synchronization, or terminal failures are covered. In the
selected building and furniture callers, the ordinary `StandardMaterial`
request explicitly collects only present base-color, normal-map, and
metallic-roughness textures (`building_review/readiness.rs:112–130`;
`furniture_readiness.rs:92–104`). Ground uses a separate texture-ID supplier
whose complete implementation was not reviewed here.

The bounded support agrees with the author’s separate questions:

* `building_review/readiness.rs:12,32–36,252–285` and
  `furniture_readiness.rs:11,37–42,109–134` each retain an `Option<f64>`
  timestamp from `Time<Real>::elapsed_secs_f64()` and a 120.0-second limit.
  Configure resets the timestamp; a ready observation does not. On a later
  non-ready observation, the strict `<` assertion is evaluated against the
  retained first time. Existing ledger 956 already records that policy
  relationship. A ready-to-pending sequence, desired continuous versus
  first-pending policy, and any actual failure remain unproved.
* `building_review/readiness.rs:169–187,287–294` requires exactly three
  distinct render-level discriminants for each counted building and emits 3.
  `presentation/buildings.rs:52–64` presently defines `Lod0`, `Lod1`, and
  `Lod2`; this establishes no current literal-versus-enum mismatch. Actual
  producer coverage and the ownership of the count and emitted evidence remain
  open. The selected generator enum at `lod.rs:48–56` is a different, two-case
  representation and must not be equated to `BuildingRenderLevel` by name.
* `building_review/readiness.rs:222–245` tests whether an active camera’s
  global translation lies at distance `< 35.0` from a sign’s global
  translation before requiring nearby lettering. Unit, intended threshold,
  existing owner, supported cases, and policy remain unproved.

The raw building key at `readiness.rs:169–182` is related to historical q2252
but is a distinct Lens 12 first question. Historical q49 addresses a terminal
asset failure versus pending; q67 concerns a failed placement’s cause. Ledger
957 separately records the selected production `expect`/`unwrap` rule issue,
and ledger 1081 distinguishes native asset identity from required coverage,
completion and failures. These are relationships, not proven global aliases,
new unique findings, or evidence of a runtime incident.

The original q2801 record is Lens 13, with status
`own-lens-proof-qualification-or-read-pending`. Its 6533 assigned file has
lines 1–50, an empty assessed range and zero foreign-lens credit. Its 8ca wrapper is `unassessed`. The six selected
original/reconstructed rows q49, q67, q2252, q2359, q2705 and q2801 match in
both raw selected bytes and parsed form; the full queue streams differ. The
original q2705 has no `status` member, while its 8ca wrapper has explicit null.
Checkpoint 3821 was not recovered or promoted.

The assigned path has the same Git blob at 6533, e275 and 95e, with different
recorded tree IDs. This is a same-file proof, not whole-tree equality or proof
of identical consumers. Root’s separate 6533 Lens 3 receipt records fresh
personal lines 1–13 and qualified inherited same-lens supplier lines 14–50;
Root did not personally reread the tail. The e275 Lens 3 receipt is qualified
reuse, with no fresh current read. The separate Adler 6533 Lens 11 receipt
records fresh lines 1–13 and a fresh tail reread 14–50. None transfers Lens 13
credit.

The author is `final_guard_peer`; this independent review is by
`mhr_character`. The author’s v2 public report additively discloses a
pre-registration Git path/mode/blob metadata locator, with no source-read
credit. Its predecessor is retained; the compared assessment changes only a
process-qualification field, and the compared report adds that disclosure.
The author’s queue-navigation failure and pre-registration historical proof
filename locators remain separate. This review’s own corrections and actual
ranges are recorded in its accompanying receipt. The independent source views
are reviewer-attested and are not signed display telemetry.

The 95e personal displays cover the complete assigned file (1–50), building
readiness 1–301, furniture readiness 1–148 of 160, and only the explicitly
registered owner windows. Furniture test-source lines 149–160 and other owner
complements remain unread by this reviewer. Full source blobs were retained for
identity and do not by themselves add read credit. Original queue streams,
protected historical inputs and Git evidence remain separately held on the
same machine for strongest replay; this packet is not independent custody.
No product code, fixture, build, test, shader, renderer or runtime probe was
run, and no ledger or publication changes were made.
