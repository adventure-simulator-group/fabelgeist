# Independent q2952 Lens 10 review

Reviewer: /root/mhr_character. This is a bounded independent review of the
assessment by wrapped_scope for historical q2952 at pinned product revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The earlier reviewer’s six
registered views and q2945 Lens 2 assessment remain separately attributed.
No source, queue or ledger was changed.

The reported nonfinding is supported in the selected scope. The file's
handwritten `TryFrom<BindingWire>` constructs the owner and calls `validate`
before returning (`binding.rs:51–72`). That check rejects a zero property ID,
member count other than two, an empty list, duplicate elements and reserved
owner/gate-landing elements (`binding.rs:109–124`). Replacing the checked
conversion with raw field construction or an unchecked deserialization would
remove those local checks. It does not itself prove the distinct scene or cell
relationships (`binding.rs:134–172`). Existing derives and the authored
`#[serde(try_from = "BindingWire")]` are present (`binding.rs:4–15,51–58`).
The pinned serde_derive 1.0.229 source selects a try-from branch and emits a
nested deserialization followed by `TryFrom` with error mapping
(`serde_derive/src/de.rs:306–312,434–440`). The exact archive matches the 95e
lock checksum. Workspace manifests declare serde derive, but this does not prove
resolved features, macro expansion or runtime outcomes.

`BoundaryDescriptorDigest::of` is handwritten descriptor construction, not a
manual serialization trait. It hashes a wall count, ordered wall scalars as
little-endian f32 bits, a hinge byte, then gate scalars including the yaw
adapter (`binding.rs:16–49`); the compared descriptor fields are shown in
`city_layout/compound.rs:27–73`. A generic serialization, floating comparison,
or derive has not been shown to reproduce that ordered byte contract. For
example, positive and negative zero compare numerically equal but have distinct
f32 bit encodings, so substituting numerical equality would not preserve the
same input bytes to the digest. This does not establish a supported signed-zero
rewrite, a changed digest in a particular run, or a product error; SHA-256
collisions and policy are not adjudicated here. The descriptor/cell geometric
and material correspondence question remains separate from this derivability
assessment and is not resolved by those checks.

At committed 8ca, q2952 remains unassessed. The selected original and
reconstructed q2952 and q2945 rows match byte-for-byte while their whole queue
streams differ. The 6533, e275 and 95e assigned source resolves to the same
file blob `05defe7da97ee80aecb4eb57602cbc4a7fba6541` (SHA-256
`9db0cfc4b4c3053884d835faaca49a404c9942f7f0599b3069b89729fd8d7ae3`);
that proves per-file identity only. Original Root Lens 3 and Lens 2 receipts
record separate 6533 personal reads and qualified same-lens e275 reuse without
an e275 reread. The author’s q2945 Lens 2 current work remains separate from
this Lens 10 peer review. q2945 is partially reconciled in the 8ca wrapper;
ledger row 1082 records the related descriptor/cell owner and geometry
question, with reach, policy and alias limits open. None supplies this
reviewer’s Lens 10 credit, a unique count or checkpoint 3821 recovery.

Seven independently registered source windows were personally displayed:
three 95e assigned-file chunks, enclosure parent 1–70, descriptor definitions
20–82, and the two native derive-source windows. Full source bytes and the
Cargo manifests/lock were captured or structurally parsed for identity and
dependency metadata only, not claimed as full personal reads. The two prior
registered author locator outputs were tool-visible but not separately
transcribed; the author later captured the relevant archive and q2945 metadata.
The unsealed author report predecessor and exact one-newline source-path
correction are preserved under that author’s attribution. Display receipts are
reviewer attestations, not independent telemetry. All-caller coverage,
validated derive alternatives, supported descriptor changes, intended equality
policy, runtime effects, complete alias inventory and independent custody are
open. No product code, product parser, macro expansion, build, test, fixture or runtime
probe was executed, and no repair or closure is implied.
