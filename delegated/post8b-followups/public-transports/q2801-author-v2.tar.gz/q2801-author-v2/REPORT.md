# q2801: GPU readiness, Lens 13 raw primitives

At the pinned 95e source, the assigned 50-line GPU-readiness file contains no
raw numeric domain value needing an owner in the inspected scope. Its `.0`
accesses project the sole field of a tuple struct; they are not numerical
quantities. The `bool` result is a residency predicate over typed Bevy mesh and
image asset identities. The selected render-world observer replaces the two
asset-ID sets; `contains` requires the mesh and every requested texture. An
empty texture iterator imposes no texture requirement while the mesh must still
be present. This is an observation of the selected source, not proof of
complete material coverage, current GPU success, pipeline completion or a
rendered frame.

The connected consumer windows expose three separate planning questions:

* Both building and furniture review code retain first-pending time in
  `Option<f64>`, use the framework's `Time<Real>` elapsed-seconds value, and
  independently declare a 120.0-second threshold. They clear the pending
  value during Configure, but the shown ready branch does not clear it. Ledger
  956 already records the ready-to-pending policy question; the Lens 13
  raw-time observation adds bounded support, not a new unique issue. Decide
  whether a typed deadline or elapsed value and a shared policy are justified,
  while preserving the intended clock, limit and Configure behavior. Actual
  oscillation, policy and failure remain unobserved.
* Building readiness checks for exactly three distinct render-level
  discriminants and emits the number 3 in its evidence. The selected
  `BuildingRenderLevel` declares Lod0, Lod1 and Lod2, so the current count
  agrees. A future owner/consistency decision should preserve those roles and
  the emitted contract; no present count mismatch is established.
* The nearby-lettering check compares active camera and sign transform
  positions with an inline `< 35.0` distance. Its intended unit, coordinate
  frame, capture policy and any existing shared owner remain open. No camera
  outcome or supported threshold error was observed.

The selected native query counts and raw building-ID map also need their
producer and boundary contracts. Historical q2252 already records the separate
`SceneBuildingId` key-erasure question. Ledger 957 separately records the
`unwrap`/`expect` rule issue, and ledger 1081 records typed GPU identity and
its limited readiness scope. Historical q49 concerns terminal asset failure
versus pending, and q67 concerns a distinct streaming failure owner. These are
connected first operations, not proven aliases or new unique counts.

The original q2801 row records status
`own-lens-proof-qualification-or-read-pending`; its 8ca wrapper is
`unassessed`. Selected original and reconstructed q2801 rows match as parsed,
while the complete streams differ. The same assigned file blob is recorded
at 6533, e275 and 95e; the three recorded tree identities differ. Under Lens
3, Root's 6533 receipt records a fresh personal read of 1–13 and inherited
same-lens supplier coverage of 14–50, with no Root personal tail reread. Its
e275 receipt records qualified reuse and no fresh e275 read. The separate
6533 Adler Lens 11 receipt records fresh 1–13 and a fresh reread of 14–50.
None transfers Lens 13 credit. Original q2705 lacks a status field while its
8ca wrapper records null; q2359 has a separate Root Lens 2 read and a partial
8ca relationship. Original q49/q67 source revision and attribution fields
remain null where their selected records say so. Checkpoint 3821 is not
recovered.

At 95e, this author personally displayed eleven prospectively registered
windows:

* `crates/adventuresim-tactical-client/src/tactical_scene_viewer/gpu_readiness.rs:1–50`;
* `crates/adventuresim-tactical-client/src/tactical_scene_viewer/building_review/readiness.rs:1–89,90–165,166–244,245–301`;
* `crates/adventuresim-tactical-client/src/tactical_scene_viewer/furniture_readiness.rs:1–49,50–110,109–160`;
* `crates/adventuresim-building-generator/src/lod.rs:40–85`;
* `crates/adventuresim-tactical-client/src/presentation/buildings.rs:40–70`;
* `crates/adventuresim-tactical-client/src/tactical_scene_viewer/building_review.rs:40–85`.

Furniture lines 149–160 contain test source; they were read only, not run.
Display is reviewer-attested, without
independent display telemetry. The surrounding numeric values and untraced
producer/framework contracts are not an exhaustive Lens 13 census.

An initial metadata-only queue navigation failed on a dictionary shape and
was corrected without product-source display; its original failure is saved.
A Git tree metadata entry for the candidate path, mode and blob was displayed
before selection registration; it contained no source text and gives no source
read credit. The four historical proof filenames were located before their
registration; that locator view gives no historical or source read credit.
Some unrelated
metadata projections and a bounded historical print were clipped; full
selected records and the qualified process account are retained separately.
The protected extraction was read without mutation. Original 059 full streams,
Git object closure and other evidence remain separately held on the same
machine; this is not an independent backup. No repair, product build, test,
fixture or runtime probe was performed. No queue or lens closure is claimed.
