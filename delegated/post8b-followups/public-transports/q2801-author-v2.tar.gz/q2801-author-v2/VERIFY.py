#!/usr/bin/env python3
"""Verify public evidence and, optionally, exact assigned source bytes."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--assigned-source',type=Path);args=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-l13-q2801-public-manifest-v2' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
a=json.loads((p/'ASSESSMENT.json').read_bytes());v=json.loads((p/'EVIDENCE-VERIFY.json').read_bytes());assert a['queue_index']==2801 and a['lens']==13 and a['personal_display_windows']==v['personal_source_windows']==11 and len(v['checks'])==13 and all(v['checks'].values());checked=False
if args.assigned_source is not None:assert args.assigned_source.is_file() and not args.assigned_source.is_symlink() and h(args.assigned_source.read_bytes())==a['assigned_source']['sha256'];checked=True
print(json.dumps({'public_members':len(m['files']),'assigned_source_identity_checked':checked,'qualification':'Public bytes and optional source identity only; no product execution, independent reading telemetry or runtime validation.'}))
