# Tactical mission enrollment strings: q2990 and q3062, Lens 12

In the selected current production windows, no raw string field or
string-valued admission identifier is exposed. The only string literal is
`unreachable!("begin transitions awaiting enrollment")` in
`crates/adventuresim-tactical-server/src/mission/enrollment.rs:59`. It is
fixed diagnostic prose for the branch following `begin`; the inspected
source does not establish a string producer, retained identity, or consumer
that needs a bespoke owner. This is a bounded source observation, not proof
that the assertion can never be reached in every execution.

`PartyEnrollment` retains `HashSet<CharacterId>`, a `NonZeroU32` expected
count, and `Duration` for the empty interval; `observe_loaded` and
`allows_join` use `CharacterId` membership. The selected mission root forwards
those typed identities and uses the typed tactical mission resolution. These
observations do not settle count, lifetime, zero-grace, terminal, or
cross-boundary behavior. A prose comment and module names are source text,
not a string-valued product identifier in these windows. No new repair-ledger
entry is proposed for the diagnostic.

At 95e the reviewer personally displayed five prospectively registered
windows:

* `crates/adventuresim-tactical-server/src/mission/mod.rs:1,3–110,111–213`;
* `crates/adventuresim-tactical-server/src/mission/enrollment.rs:1–65,66–125`.

Line 2 of the mission root and the test sections were excluded. The original
q2990 required range is 1–220; q3062 required 1–189. Thus neither original
scope is fully read here, and the receipt, systems, terminal, fixture,
producer and native-boundary complements remain open. Display is
reviewer-attested, without independent display telemetry. No queue or lens
closure is claimed.

The original q2990 and q3062 records both say
`own-lens-proof-qualification-or-read-pending`, with empty assessed ranges and
zero body credit. Their published 8b wrappers say `unassessed`. The selected
original and reconstructed records match as parsed; the complete streams
differ. Both selected file blobs are identical at 6533, e275 and 95e, while
the three whole-tree identities differ. The 6533 and e275 blobs were captured
only to check identity; the current reviewer did not personally display their
old-revision bodies. Missing checkpoint 3821 is not recovered or reconstructed.

The original 6533 Lens 3 read receipts attribute the root reader's fresh
personal reads of mission root 1–220 and enrollment 1–189. The e275 Lens 3
receipts record qualified reuse with no fresh personal ranges and require
frozen-source adoption before that authority accepts reuse. These are not
Lens 12 credits. Separately, q1776's historical Lens 12 receipt credits
`lens12_frontier` with a fresh 6533 mission-root read of 1–158 and a separately
registered connected read of 159–362; its original requested range was not
expanded. That receipt records no root personal reread and no current-source
reconciliation. q1776 remains `unassessed` at 8b, with its broader
player-projection, callback, receipt, enrollment and current-source
obligations open. Its historical reader's work and this reviewer's overlapping
95e read remain separately attributed.

Historical q2371 asks a different Lens 2 count-owner question. Historical
q3059 has the same enrollment file obligation under Lens 9; its 8b wrapper is
partial; its current Lens 9 review was authored by `wrapped_scope`, separately
credited. Ledger 1097 records the
conditional seal-versus-abandon effect-priority question, distinct from ledger
406 and q3134's zero-grace abandonment question. q3134's original record has
no status field; its 8b wrapper is partial. Ledger 1134 is a planning
relationship that keeps fixture admission, count propagation and zero-grace
as separate first operations. Their supported reach, policy, global aliases,
remaining source and product behavior remain open; these relationships do not
assert a unique-defect count.

The initial evidence verifier had a syntax error before any checks; its exact
failed script and traceback are retained, and a corrected verifier completed
nine evidence-only checks. A nonexistent server-specific guide lookup and an
unrelated clipped prior-packet metadata display are also recorded. The
protected extraction was read without mutation. Source captures and Git
objects remain same-machine dependencies, not independent backup or full Git
closure. No repair, product build, test, fixture execution, or runtime probe
was performed.
