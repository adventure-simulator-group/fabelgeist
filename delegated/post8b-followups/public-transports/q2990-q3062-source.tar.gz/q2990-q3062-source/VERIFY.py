#!/usr/bin/env python3
"""Check finite public members; optionally compare selected source identities."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--mission-source',type=Path);ap.add_argument('--enrollment-source',type=Path);args=ap.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-l12-mission-public-manifest-v1' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
a=json.loads((p/'ASSESSMENT.json').read_bytes());v=json.loads((p/'EVIDENCE-VERIFY.json').read_bytes());assert a['lens']==12 and [x['queue_index'] for x in a['selected']]==[2990,3062] and a['personal_display_windows']==v['personal_source_windows']==5 and len(v['checks'])==9 and all(v['checks'].values());checked=[]
for f,row in zip([args.mission_source,args.enrollment_source],a['selected']):
 if f is not None:assert f.is_file() and not f.is_symlink() and h(f.read_bytes())==row['source_sha256'];checked.append(row['queue_index'])
print(json.dumps({'public_members':len(m['files']),'optional_source_identities_checked':checked,'qualification':'Finite public bytes and optional selected file identities only; no independent reading telemetry, product execution or runtime validation.'}))
