#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--draft',type=Path);args=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q2743-v6-peer-public-manifest-v1' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
b=json.loads((p/'BINDING.json').read_bytes());c=json.loads((p/'CHECK.json').read_bytes());assert len(c['checks'])==7 and all(c['checks'].values()) and b['prior_q2744_peer_overlap'] and not b['new_product_source_display'];checked=False
if args.draft is not None:assert args.draft.is_file() and not args.draft.is_symlink() and h(args.draft.read_bytes())==b['draft_v6_sha256'];checked=True
print(json.dumps({'public_members':len(m['files']),'draft_identity_checked':checked,'qualification':'Public bytes and optional draft identity only; no source reread.'}))
