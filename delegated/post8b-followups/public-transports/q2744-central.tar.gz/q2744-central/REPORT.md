# Independent review of q2744 central draft v6

Reviewer: /root/wrapped_scope. This is a bounded review of the coordinator's
unadopted q2744 Lens 4 synthesis at product commit
`95e63628f9d70b8dd6e6fede64334696c6995009`, using the 8ca evidence checkpoint
and separately checked later 8b metadata. The source assessment was authored
by /root/mhr_character and independently source-reviewed by final_guard_peer.
I earlier independently peer-reviewed related q2743 under Lens 2; that overlap
is disclosed and supplies no q2744 Lens 4 credit. This review is independent
of the central synthesis, not of all related work.

The draft's scoped claims are supported by the selected source and historical
evidence. I found no source-semantic contradiction or established product
outcome. The draft needs the source-reference additions below and would be
clearer if it named the two examples it calls symbolic, as well as the exact
historical read/status qualifications. These are additive review corrections,
not a new queue disposition, accepted defect count or alias.

## Arithmetic and reachable-path limits

`presentation/materials.rs:1–40` is registration code and has no numerical
transformation. `chunk_instancing/instance.rs:48–55` sets the fade-in end to
the maximum of its supplied end and start plus `0.001_f32`, while retaining
the fade-out. For a representable f32 value 32768.0 = 2^15, the next larger
f32 is 2^-8 = 0.00390625 away; half that spacing is 0.001953125. Under
round-to-nearest f32 arithmetic, `0.001_f32` is smaller than half the upward
spacing, so adding it to 32768.0 rounds back to 32768.0. If the supplied end
is also 32768.0, this constructor can retain equal fade-in endpoints. This is
an analytical representable-input example, not an executed product or shader.

`presentation/config.rs:332–345` allows finite, nonnegative, nondecreasing
endpoints, including equality; `config.rs:347–373` and the rest of validation
add other requirements. Subject to decoding and all other checks, one example
is fade-in [0.0, 0.001] and fade-out [1.0, 1.0]; another is fade-in
[32768.0, 32768.0] and fade-out [32769.0, 32770.0]. The examples share one
conditional denominator question and are not asserted as distinct defects.
`chunk_instancing/chunk_instancing.wgsl:62–67` selects the fade-in pair when
camera distance is below fade-out start and the fade-out pair otherwise, then
divides by the selected width. For the two examples, the relevant branches
are respectively distance at least 1.0 and distance below 32769.0. The source
expression alone does not prove that an admitted configuration reaches a
nonempty drawable, visible grass instance and the branch on a real backend.
Decoding, remaining validation, scene reach, backend result and hard-cut versus
rejection policy remain open. Shader and test-annotated text were read only.

## Source-reference additions

The v6 `source_basis` omits the direct support for its fixed producer/value
claim and two parts of its connected grass-to-shader chain. Add these exact
repository-relative ranges:

* `crates/adventuresim-tactical-client/src/presentation/ground_scatter/loose_stone/batches.rs:20–22,100–115` and
  `crates/adventuresim-tactical-client/src/presentation/ground_scatter/loose_stone.rs:144–165`
  for pebble chunk size, band construction and fade-out values.
* `crates/adventuresim-tactical-client/src/presentation/vista/tree_cards.rs:32–35,118–160` and
  `crates/adventuresim-tactical-client/src/presentation/vista/details.rs:272–292`
  for vista chunk size, band use and fade-out values.
* `crates/adventuresim-tactical-client/src/presentation/ground_scatter/instanced_grass.rs:455–468`
  for the tier endpoints copied into `FadeBand::new`, and
  `crates/adventuresim-tactical-client/src/presentation/chunk_instancing/pipeline.rs:74–90`
  for the dither shader definition. `presentation/mod.rs:227–233` supports the
  separate grass-plugin installation; it does not establish render execution.

The reported 39 author and 29 peer registered display windows match their
separately captured receipts; those event claims are reviewer-attested. My own
23 registered 95e windows are limited to checking this draft and its cited
chain, not a fresh exhaustive q2744 source assessment.

## Historical and process qualifications

At 8ca, original q2744 records 6533 required 1–35 with no assessed Lens 4
range and status `own-lens-proof-qualification-or-read-pending`; its current
wrapper is unassessed. It is also unassessed in later 8b metadata. The selected
original and reconstructed records for q49, q2701, q2743, q2744, q2747, q2748
and q2750 match even as raw selected bytes, while complete queue streams differ.
q2701's original record has no status member; its 8ca wrapper projects null.
The four cited ledger rows retain their distinct texture-failure,
celestial-material, recipe/channel and RenderApp-startup questions.

The recovered historic materials file and 6533/e275 Git files match per file;
95e differs. Root's separate Lens 3 receipt records a fresh 6533 1–35 read;
the e275 receipt records qualified same-lens reuse with no fresh reread and the
file's `source_adoption_pending_for_frozen18_19` flag false. Its conditional
language about other sources does not establish their adoption. Adler's Lens 11
receipt is separately attributed. No prior read transfers to another lens or
reviewer; neither per-file equality nor these records establish clean whole-tree
equivalence or recovery of checkpoint 3821.

The author retained the failed metadata projection, early prior-report view and
later redisplay, and corrected ineffective copy-time manifest check. The source
peer retained the corrected status paraphrase, its 16-of-17 historical check
and 17-of-17 successor, and two tool-visible-only failed metadata locators. My
own early directory-only locator output was truncated and was not captured
separately. My first source-capture script stopped at a requested shader end
past the actual 68-line EOF, before any personal source display; the failed
script, traceback and partial captures are retained. A separately registered
50–68 successor supplied the current shader view and positive EOF.

The restricted packet retains exact draft inputs, selected recovered records,
source captures, registrations, Git-object witnesses and process corrections.
The strongest replay requires separately held full 059 streams, protected
read-only extraction and Git objects; public hashes do not recreate those
inputs or establish independent custody. No queue, ledger, central draft,
publication, product source, build, test, fixture or runtime was changed or
executed by this review.
