The final process statement in the review refers to product runtime, not the
standard-library Python and Git commands used for evidence capture and replay.
