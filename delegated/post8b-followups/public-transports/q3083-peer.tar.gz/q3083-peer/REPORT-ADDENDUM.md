# Evidence replay correction

The first strongest evidence-only replay failed because its verifier reused a
variable for the selected queue dictionary and then compared it with historical
receipt bytes. The independent receipt capture and direct comparison had
already succeeded. The original verifier, failing traceback and exit status
are retained. `VERIFY-EVIDENCE-v2.py` changes that comparison to read the
retained receipt explicitly; its self-contained and optional full replays both
passed. Those checks validate selected evidence identities and structure, not
product behavior, historical adoption, or independently signed display
claims.
