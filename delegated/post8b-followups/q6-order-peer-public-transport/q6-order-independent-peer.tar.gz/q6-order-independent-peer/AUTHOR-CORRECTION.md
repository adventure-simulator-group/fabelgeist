# q6 mission source-order clarification

The q6 review's wording that the reducer “creates its mission snapshot and
request after configuration” needs this qualification. After successful
fixture configuration, the reducer selects an existing mission if one is
present; only the other branch captures and inserts a new snapshot
(`crates/adventuresim-stdb-module/src/strategic/mission_bootstrap.rs:716–723`,
at source commit `95e63628f9d70b8dd6e6fede64334696c6995009`). Request insertion
at :758–783 is reached only if the intervening checks and fallible operations
succeed. Source order does not establish transaction or runtime effects.

Independent peer `wrapped_scope` identified this wording refinement after the
original review was sealed. It does not change the conditional grant-error
finding, supported-reach limits or q6's 8b unassessed status. The original
report and its evidence remain unchanged; this is an additive correction.
