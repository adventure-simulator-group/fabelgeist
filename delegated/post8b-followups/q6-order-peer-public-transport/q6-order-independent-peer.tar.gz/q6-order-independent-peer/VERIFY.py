import argparse,pathlib,json,hashlib,subprocess
p=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
def verify(d,name,digest):
 d=pathlib.Path(d);b=(d/name).read_bytes();assert H(b)==digest;m=json.loads(b);files={str(x.relative_to(d)) for x in d.rglob('*') if x.is_file() and not x.is_symlink()};assert files==set(m['files'])|{name} and not any(x.is_symlink() for x in d.rglob('*'))
 for n,v in m['files'].items():
  b=(d/n).read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes']
 return len(m['files'])
a=argparse.ArgumentParser();a.add_argument('--peer-public');a.add_argument('--repo');a.add_argument('--author-public');a.add_argument('--order-private-manifest');a.add_argument('--order-replay-manifest');a.add_argument('--author-private-manifest');z=a.parse_args()
m=json.loads((p/'MANIFEST.json').read_bytes());assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,v in m['files'].items():
 b=(p/n).read_bytes();assert H(b)==v['sha256'] and len(b)==v['bytes']
b=json.loads((p/'BINDING.json').read_bytes());c=(p/'AUTHOR-CORRECTION.md').read_text();assert 'only the other branch captures and inserts a new snapshot' in c and 'only if the intervening checks and fallible operations' in c
print('PASS additive correction, report and public member identities')
if z.author_public:
 assert verify(z.author_public,'MANIFEST.json',b['author_public_manifest_sha256'])==4;assert (pathlib.Path(z.author_public)/'CORRECTION.md').read_bytes()==(p/'AUTHOR-CORRECTION.md').read_bytes();print('PASS optional author public correction')
else:print('SKIP author public correction')
if z.peer_public:
 d=pathlib.Path(z.peer_public);print('PASS optional peer public members',verify(d,'MANIFEST.json',b['peer_public_manifest_sha256']));view=(d/'VIEW-C-reducer-snapshot.txt').read_bytes();assert b'if let Some(existing)' in view and b'let snapshot = MissionAuthority::capture' in view and b'.tactical_server_request_authority()' in view
 if z.repo:
  o=subprocess.check_output(['git','-C',z.repo,'show','95e63628f9d70b8dd6e6fede64334696c6995009:crates/adventuresim-stdb-module/src/strategic/mission_bootstrap.rs']);ls=o.splitlines(keepends=True);expected=b''.join((str(i).rjust(5)+' ').encode()+ls[i-1] for i in range(716,790));assert view==expected;print('PASS optional 95e source view bytes')
 else:print('SKIP Git source: --repo not supplied')
else:
 assert not z.repo,'--repo requires --peer-public';print('SKIP peer public packet and source comparison')
for val,label,key in [(z.order_private_manifest,'order private manifest','order_private_manifest_sha256'),(z.order_replay_manifest,'order replay manifest','order_replay_manifest_sha256'),(z.author_private_manifest,'author private manifest','author_private_manifest_sha256')]:
 if val:assert H(pathlib.Path(val).read_bytes())==b[key];print('PASS optional',label,'identity only')
 else:print('SKIP',label,'identity')
