# Static comparison of scanner and installer successors

The latest unrun successors address the identified scanner-input and runner
binding gaps in the reviewed evidence chain. The scanner's four selected
program and corpus files matched their recorded whole-file hashes and modes,
and the stored copies matched their predecessor sources at review time. The
review found no additional deterministic source blocker within this bounded
comparison. It did not run the scanner, its preparation or derivation tools,
the installer, or product code.

Scanner v3 records the two scanner programs and two corpus files and checks
their bytes and modes before and after the scanner children. Scanner v4 pins
the input manifest in the runner; scanner v5 retains that pin. Its invocation
wrapper checks the runner before and after execution and records child streams
and the result hash. The v4 installer template pins the scanner derivation,
checks the runner and wrapper bytes, input manifest, invocation receipt and
child streams, then separately checks the reported scan result. These are
same-machine evidence bindings, not independent proof of execution or an
attestation of the interpreter, libraries, connector origin or concurrent
filesystem activity. References: scanner v3 preparation 20–44, v5 runner
70–110, v5 wrapper 12–43, installer v4 70–133 and final deriver 18–42.

The earlier postfailure inventory gap is addressed for a normally returned
nonzero installer child: the successor observes all eight root targets, five
replacement temp names and recursively enumerates the partial stage, recording
file hashes and modes, kinds and read or traversal errors. The observation is
non-atomic, does not follow symlinks or record their targets, and can itself
be incomplete after interruption, launch or logging failure. Independent
outer streams and read-only follow-up remain necessary; no rollback is
implied. Installer v4 wrapper: 28–103.

The finite scan remains qualified: the pattern scanner omits gzip header
name/comment inspection, does not re-enter a gzip-inside-gzip view without a
tar traversal, and has no per-view expansion bound. The separate digest
scanner handles gzip metadata and recursion but has narrower credential
patterns. Unknown encodings, unsupported or opaque formats and unselected
history remain outside scope. The scan result describes these limits; no
exposure or scan failure is asserted.

The separately prepared sparse trial shares the publication object store and
contains only selected paths. A clean sparse status and a trial installation
would not establish a complete predecessor replay or independent custody. The
required run parent was absent at the first metadata check; after the
coordinator prepared it, a later read-only check found a real empty directory
with mode 0700. Future collision checks, exact target modes, connector
observation, actual scan, guard and complete predecessor replay remain separate.

Exact in-memory derivation comparisons matched the recorded scanner v3, v4
and v5, and installer v3 and v4 artifacts. One reviewer-created comparison
helper initially failed because it counted a reassignment as a second literal;
the failed stream and corrected passing check are retained. Twenty-two
registered files were personally displayed from exact captures; display
receipts are reviewer-attested, not telemetry. The prior installer review was
by the same reviewer and supplies no independent authorship. The large private
corpus archive remains separately held by whole-file identity. No ledger,
publication or source was changed, and no runtime behavior was validated.
