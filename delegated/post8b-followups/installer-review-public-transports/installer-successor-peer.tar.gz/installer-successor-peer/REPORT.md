# Static review of prospective installer successors

The confined successors address the earlier arbitrary-path and unrecorded
normal-child-output findings, subject to the limitations below. This review
examined captured source text only. No capture, scanner, derivation, installer,
product, build, test, or runtime probe was run. The reviewer authored the
earlier installer review and q2743/q2744 source assessments; this is not new
independent source credit.

The capture requires the designated real publication checkout, exact parent,
tree and branch, clean Git status, and eight named root outputs. It records
file bytes and full POSIX modes; Git preserves only executable-bit projection.
The v1 and v3 privacy-driver before-images named by capture and installer have
equal bytes. The installer confines trial and production to two fixed real
checkouts and fixed private run directories, clears inherited `GIT_*` settings
and child optimization, verifies Git's top level, and checks stage and root
images before the first checkout modification. It binds labeled scanner output,
stderr and exit records and checks observation timestamps and a 15-minute
end-time bound. Connector origin and actual contemporaneity remain separately
verified claims. Capture: 14–51, 53–105; installer: 16–33, 53–108,
123–155; deriver: 16–42.

Three remaining questions need explicit treatment before a stronger claim:

- Scanner identity: the scanner runner invokes two named external scripts
  without hashing their program bytes or binding corpus identity in its result.
  The installer binds reported outputs, not the scanner program used. A
  separately verified source/corpus capture or pinned successor is needed to
  attribute a result to particular scanner bytes. Runner: 68–94; installer:
  79–93; digest scanner: 9–14.
- Failure state: write-ahead records cover stage copying and root replacements,
  and a normal nonzero child return triggers a read-only follow-up. The wrapper
  inventories eight final names and counts stage files, but does not explicitly
  capture remaining replacement temp bytes/modes or the complete partial stage.
  Spawn, interruption, output-storage or follow-up exceptions can also prevent
  the wrapper result from being written. Retain outer streams and treat an
  incomplete result as potentially partial; do not infer rollback. Installer:
  151–179; wrapper: 24–69; capture wrapper: 13–24; deriver: 33–42.
- Scan bounds: the pattern scanner decompresses a gzip view once, does not
  inspect gzip name/comment metadata, and uses unbounded gzip/member reads. The
  separate digest scanner recursively handles gzip headers and nested views,
  but its generic credential patterns cover a narrower set. Consequently the
  combined finite scan does not clear every selected credential form in those
  positions; very large compressed input may exhaust resources. No exposure or
  scan failure is asserted. Pattern scanner: 9–15, 24–30; digest scanner:
  38–48, 66–77, 83–108.

The trial setup selects five root files and one delegated anchor in a sparse
checkout sharing the publication object store and alternates. Its earlier
record reports clean status and successful setup; that is not a full working
tree, independent custody, or predecessor-guard replay. Reconstruct full
recorded target modes before the planned trial, then separately run the old
guard against the correct complete predecessor checkout. Setup: 38–61;
installer: 123–150. No trial was performed in this review.

The review compared exact captured script bytes and recorded line windows;
source displays are reviewer-attested rather than telemetry. The earlier report
was displayed after registration but before its manifest binding was checked;
the later binding passed. A draft capture helper was not run because it used
nonexclusive writes; its replacement failed to parse before doing any work,
and a fresh corrected helper captured the inputs. Exact failure output remains
restricted. Actual observations, final captures, installation, predecessor
replay, publication, and later changes remain separate evidence.
