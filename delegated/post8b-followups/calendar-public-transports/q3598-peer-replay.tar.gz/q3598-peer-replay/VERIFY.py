from pathlib import Path, PurePosixPath
import hashlib
import json

p = Path(__file__).resolve().parent
h = lambda b: hashlib.sha256(b).hexdigest()
m = json.loads((p/'MANIFEST.json').read_bytes())
assert m['schema'] == '726-q3598-l9-peer-public-manifest-v1'
assert {x.name for x in p.iterdir()} == set(m['files']) | {'MANIFEST.json'}
for name, row in m['files'].items():
    assert len(PurePosixPath(name).parts) == 1
    f = p/name
    assert f.is_file() and not f.is_symlink()
    b = f.read_bytes()
    assert len(b) == row['bytes'] and h(b) == row['sha256']
b = json.loads((p/'BINDING.json').read_bytes())
assert b['queue_index'] == 3598 and b['lens'] == 9 and b['disposition'] == 'bounded_nonfinding_supported'
assert b['author_public_manifest_sha256'] == '1c700dbd961d79c60f275bac1e582dc661353839654b159bd6900a7c851e43a9'
s = json.loads((p/'SOURCE-MAP.json').read_bytes())
assert len(s['registered_displays']) == 4 and [x['range'] for x in s['registered_displays']] == [[1,28],[1,28],[1,125],[1,100]]
assert s['related_records'] == ['original q132','original q3301','ledger 28','ledger 66','ledger 446']
print(json.dumps({'public_members':len(m['files']), 'registered_windows':4, 'result':'passed', 'qualification':'Public file identity and stated scope only; source correctness, private evidence, personal display telemetry, product behavior and independent custody are not checked.'}))
