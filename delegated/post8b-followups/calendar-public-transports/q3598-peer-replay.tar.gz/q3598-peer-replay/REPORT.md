# Independent peer review: q3598 calendar state shape

Reviewer: `final_guard_peer`. This review is independent of the
`wrapped_scope` assessment and covers its selected Lens 9 calendar slice at
product revision `95e63628f9d70b8dd6e6fede64334696c6995009`, with queue and
ledger status at published checkpoint
`8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. No product, test, fixture, build,
repair or runtime probe was executed.

## Bounded result

The registered `crates/adventuresim-world-schema/src/calendar.rs:1–28` slice
does not show a carried semantic Boolean alongside a conditionally meaningful
payload. At `:23–26`, `is_sunday_day_index` calculates a Boolean from a day
index. The inspected `crates/adventuresim-core/src/activity.rs:74–85` caller
uses that predicate directly to filter a range into Sunday day indices. This
supports the author's bounded nonfinding; it does not establish that every
calendar state, caller or weekday representation has been reviewed.

The constants at `calendar.rs:10–21` include distinct `CalendarYear` and
`StrategicMinute` values. Bounded support at `:29–49` and `:82–109` shows
their separate owners and selected constructors/accessors. It does not clear
their admission, arithmetic, serialization, or other consumers. Other
activity location enums and fields in the support window are surrounding
context, not a new assessment of those types. Both current support windows end
within subsequent declarations, whose omitted bodies remain unassessed here.

## History and relationships

The original q3598 record has no status field; its selected reconstructed
object matches it as parsed, while the complete original and reconstructed
streams differ. The 8b wrapper has a null historical-status value and says
`unassessed`. Root personally read `calendar.rs:1–28` at 6533 under Lens 3.
The e275 record instead describes same-Lens reuse with no fresh personal read
and frozen-source adoption still pending. Neither record transfers Lens 9
credit. This peer independently read the selected 6533 and e275 source lines
as separate historical views and the current 95e views as new work. The file
blob is equal across those revisions, but the three Git trees differ; file
identity does not establish whole-tree identity or complete historical
coverage.

Ledger 66 concerns a Sunday workload, event-retention and resource-policy
question; its supported interval and reach remain open. Original q132 and
ledger 28 and 446 address a separate extreme daily-share arithmetic operation
and its reach. Original q3301 concerns saved-schedule admission. These are
connections for reconciliation, not established aliases, new defect counts or
proof of product behavior.

## Evidence and limits

The peer prospectively registered four bounded displays: historical 6533 and
e275 `calendar.rs:1–28`, current 95e `calendar.rs:1–125`, and current
`activity.rs:1–100`. Displays are reviewer-attested, not independently
telemetered. The author's separately registered Sunday symbol matches
included seven test assertions as source text only; the peer's own four views
did not display those assertions. No test or fixture was run.

The author's first unsealed public projection failed a finite privacy scan on
two private agent-prefix occurrences. The predecessor, builder, diagnostic and
empty predecessor replay destination remain separately preserved in restricted
evidence; the corrected public successor passed its recorded finite scan.
This peer also retained an unavailable-interpreter capture failure and its
successful successor, plus two tool-visible-only lookup failures described as
reconstructed process notes. No source body was displayed before the author
released the corrected packet.

The original queue, old extraction, Git objects and their custody anchors are
same-machine dependencies. No independent backup or recovery of missing
checkpoint 3821 is claimed. SOURCE004, the 73 nontext/no-positive-EOF items,
reconstructed 440 qualifications and distinctions involving normalized 774
evidence remain open. This review makes no queue or ledger edit and does not
close a lens or the thirteen-lens audit.
