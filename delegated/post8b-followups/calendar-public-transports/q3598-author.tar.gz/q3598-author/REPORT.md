# q3598: calendar enum and state-shape review

Reviewer: `wrapped_scope`. This is a separately registered Lens 9 source
assessment of the historical `ROOT-L3-EXT-0069` calendar slice. The pinned
product commit is `95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`; queue and ledger status are from
published checkpoint `8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. No product
execution or validation was performed.

## Bounded disposition

No carried semantic flag beside a conditionally meaningful payload was found in
the registered `crates/adventuresim-world-schema/src/calendar.rs:1–28` slice.
The weekday Boolean at `:23–26` is the result of a named calculation on a day
index, not a stored state tag in that slice. In one inspected caller,
`crates/adventuresim-core/src/activity.rs:74–85`, it is consumed directly as a
filter while collecting overlapping Sunday day indices. This is a bounded
nonfinding under the enum/state-shape lens, not evidence that every caller,
calendar transition, or weekday representation has been reviewed.

The scoped calendar constants at `calendar.rs:10–21` include a `CalendarYear`
and a `StrategicMinute` value, plus numerical units and indices. The separately
registered owner support at `:29–49` and `:82–109` shows distinct year and
absolute-minute wrappers and their selected constructors/accessors. No claim is
made that their raw numeric admission, arithmetic, serialization expansion or
all consumers have cleared other lenses. Replacing these independent units or
the selected predicate with an enum is not supported by this evidence. The
activity support includes other enums and fields at `activity.rs:10–61`;
they were context for the selected caller, not an exhaustive assessment of
those types. The support windows stop in subsequent declarations; no conclusion
is drawn from those partial bodies.

## History and related records

Original 059 q3598 is `OBLIGATION-ROOT-L3-EXT-0069-LENS-09`, with historical
6533 required `1–28` and an empty own-Lens 9 assessed range. The reconstructed
selected object matches the original as parsed, while the full original and
reconstructed streams differ. The 8b wrapper is `unassessed` with null
historical status. The selected 6533 registration and receipt record Root's
personal, bounded, untruncated `1–28` read under Lens 3. The separate e275
record is qualified same-Lens 3 reuse, not a fresh e275 personal read, and
explicitly requires frozen-source adoption before accepting reuse. It neither
establishes that condition nor supplies Lens 9 reading credit.

The calendar file is 698 lines with Git blob
`3bb463487d89fa1040b72d7708f7e641d5e61cec` and SHA-256
`64e57270d86d0c5de29f25c63deb77421e1c0be5eb6ccb4b2e20f805ae9777bc`
at 6533, e275 and 95e. Their trees differ; equal file bytes are not whole-tree
equivalence. Historical records are not checkpoint 3821 recovery.

Ledger 66, `OPEN-CANONICAL-SUNDAY-WORK-BUDGET-001`, concerns an open
workload/event-retention and resource-policy question with supported interval
and reach unresolved. It is related by the Sunday computation, not established
as the same issue. Original q132 and ledger 28/446 concern a separately traced
extreme daily-share arithmetic operation and its reachability. Original q3301
is a separate pending saved-schedule admission question. No alias, unique-count
change or prior reviewer credit is inferred.

## Limits and evidence

Own source displays were registered for calendar `1–28`, support `29–125`,
`activity.rs:1–100`, calendar declaration-match lines before `#[cfg(test)]`,
and matching lines for the Sunday symbol in the two named files. They are
reviewer-attested from retained exact outputs, not independently telemetered.
The registered match display included four `activity.rs:227–230` and three
`calendar.rs:533–535` assertions as source text only; none was executed.
The three complete historical/current calendar source blobs were captured for
identity before the current display registration, and were not displayed until
after registration. No q3598 capture failure occurred before sealing.

The full original 059 stream, old evidence extraction and Git object store are
separately held same-machine replay dependencies. The missing checkpoint 3821,
SOURCE004, 73 nontext/no-positive-EOF items, reconstructed 440 qualifications,
and distinctions involving normalized 774 evidence remain open. Nothing here
implements a repair, validates a product, transfers other-lens credit, or closes
the thirteen-lens audit.
