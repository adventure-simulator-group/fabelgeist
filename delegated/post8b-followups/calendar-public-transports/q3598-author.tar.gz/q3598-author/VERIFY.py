#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,subprocess
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_bytes());ap=argparse.ArgumentParser()
for n in ('repo','original-queue','extraction','private-manifest','replay-manifest','private-report'):ap.add_argument('--'+n,type=Path)
a=ap.parse_args();m=read('MANIFEST.json');assert m['schema']=='726-q3598-l9-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
s=read('SELECTION.json');assert s['index']==3598 and s['original']==s['reconstructed'] and s['original']['lens']==9 and s['selected_equal_as_parsed'] and not s['full_streams_equal'] and s['current']['current_reconciliation']=='unassessed';q=s['original']['exact_source_identities_and_assessed_ranges'][0];assert q['required_ranges']==[[1,28]] and q['assessed_ranges']==[] and q['actual_EOF']==698
src=read('SOURCE.json');assert len(src['calendar_identities'])==3 and len({x['tree'] for x in src['calendar_identities']})==3 and all(x['git_blob']=='3bb463487d89fa1040b72d7708f7e641d5e61cec' and x['sha256']=='64e57270d86d0c5de29f25c63deb77421e1c0be5eb6ccb4b2e20f805ae9777bc' and x['lines']==698 for x in src['calendar_identities'])
for z in src['views']:b=(p/z['name']).read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
hist=read('HISTORY-SELECTED.json');old=hist['READ-ROOT-L3-EXT-067-070.json']['selected_row'];cur=hist['READ-ROOT-L3-CURRENT-007.json']['selected_row'];assert old['fresh_personal_ranges']==[[1,28]] and cur['fresh_personal_ranges']==[] and cur['qualified_reuse_ranges']==[[1,28]] and cur['frozen_source_adoption_pending'] is True
ledger=read('LEDGER-SELECTED.json');assert [ledger['selected'][str(i)]['id'] for i in [28,66,446]]==['REVIEW-CALENDAR-RESTORATIVE-SHARE-001','OPEN-CANONICAL-SUNDAY-WORK-BUDGET-001','ADLER-L11-CALENDAR-DAILY-SHARE-ARITHMETIC'];bind=read('BINDING.json');rr=read('RECORDED-REPLAY.json');assert all(x['exit']==0 and x['stderr_bytes']==0 for x in rr['checks']);assert read('SEALED-CHECK.json')['sealed_private_manifest_sha256']==bind['private_manifest_sha256'];proj=read('REPORT-PROJECTION.json');assert h((p/'REPORT.md').read_bytes())==proj['public_report_sha256']
checks=['public members and selected data'];not_checked=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','postseal_replay_manifest_sha256'),('original_queue','original_queue_sha256')]:
 f=getattr(a,attr)
 if f is None:not_checked.append(attr+' not supplied')
 else:assert h(f.read_bytes())==bind[key];checks.append(attr+' identity')
if a.private_report:
 b=a.private_report.read_bytes();safe,n=re.subn(rb'/[^/\s`]+/(wrapped_scope)',rb'\1',b);assert h(b)==proj['private_report_sha256'] and n==1 and safe==(p/'REPORT.md').read_bytes();checks.append('exact generic-alias report projection')
else:not_checked.append('private report projection not supplied')
if a.original_queue:
 original=json.loads(a.original_queue.read_bytes())['entries'];assert original[3598]==s['original']
 for k,v in read('RELATED-SUMMARY.json')['rows'].items():assert original[int(k)]['contract_id']==v['contract_id'] and original[int(k)].get('first_failed_contract_or_unresolved_question')==v['first_question']
 checks.append('original selected queue and related identities')
if a.extraction:
 for x in read('HISTORY.json')['records']:
  b=(a.extraction/x['locator']).read_bytes();assert h(b)==x['sha256'] and len(b)==x['bytes'];d=json.loads(b);rows=[z for z in d['rows'] if 'calendar.rs' in json.dumps(z)];assert len(rows)==1 and rows[0]==hist[Path(x['locator']).name]['selected_row'] and d['lens']==3
 checks.append('four historical records and selected rows')
else:not_checked.append('protected history not supplied')
if a.repo:
 def git(*cmd):
  r=subprocess.run(['git','-C',str(a.repo),*cmd],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0 and not r.stderr;return r.stdout
 cp='8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b';rev=src['revision'];cal=None
 for x in src['calendar_identities']:
  assert git('rev-parse',x['revision']+'^{tree}').decode().strip()==x['tree'] and git('rev-parse',x['revision']+':'+src['calendar_path']).decode().strip()==x['git_blob'];b=git('show',x['revision']+':'+src['calendar_path']);assert h(b)==x['sha256'];cal=b
 aid=src['activity'];activity=git('show',rev+':'+aid['path']);assert h(activity)==aid['sha256'] and git('rev-parse',rev+':'+aid['path']).decode().strip()==aid['blob']
 def view(b,lo,hi):
  lines=b.decode().splitlines();return ''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 for name,b,lo,hi in [('VIEW-1-28.txt',cal,1,28),('VIEW-29-125.txt',cal,29,125),('VIEW-ACTIVITY-1-100.txt',activity,1,100)]:assert (p/name).read_bytes()==view(b,lo,hi)
 lines=cal.decode().splitlines();stop=next((i for i,x in enumerate(lines,1) if x.strip()=='#[cfg(test)]'),len(lines)+1);decl=''.join(f'{i:4} {x}\n' for i,x in enumerate(lines,1) if i<stop and re.match(r'^(?:pub\s+)?(?:struct|enum)\s+|^impl(?:<[^>]*>)?\s+',x)).encode();assert (p/'DECLARATION-LOCATOR.txt').read_bytes()==decl
 r=subprocess.run(['git','-C',str(a.repo),'grep','-n','-F','is_sunday_day_index',rev,'--','crates/adventuresim-core/src/activity.rs','crates/adventuresim-world-schema/src/calendar.rs'],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode in (0,1) and not r.stderr and r.stdout==(p/'SUNDAY-MATCHES.txt').read_bytes()
 qb=git('show',cp+':baseline-059/queue.json');wb=git('show',cp+':RECONCILIATION-059.json');lb=git('show',cp+':BASELINE-95E-20261110.json');assert h(qb)==s['reconstructed_sha256'] and h(wb)==s['reconciliation_sha256'] and h(lb)==ledger['ledger_sha256'];assert json.loads(qb)['entries'][3598]==s['reconstructed'] and json.loads(wb)['entries'][3598]==s['current'];entries=json.loads(lb)['newly_assessed_ledger']['entries'];assert all(entries[int(k)]==v for k,v in ledger['selected'].items());wrap=json.loads(wb)['entries'];assert all(wrap[int(k)]==v['current'] for k,v in read('RELATED-SUMMARY.json')['rows'].items());assert git('show',cp+':delegated/postdac7-lens-map-correction/mapping/bespoke-map.md')==(p/'LENS-MAP.md').read_bytes();checks.append('three file/tree identities, source windows and matches, selected 8b queue and ledger')
else:not_checked.append('Git sources and 8b queue/ledger not supplied')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence identities only; source display is reviewer-attested; no product/runtime or independent custody claim.'}))
