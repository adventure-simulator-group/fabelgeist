# q3021: bestiary redundant authority, Lens 7

The current bestiary category IDs have two independently maintained lists:
`BestiaryCategory::id` and the organization catalog validator's `BESTIARY`
allowlist. All 13 values and their order agree at 95e. This is an existing
coordinated-authority question, not a current mismatch or a new defect count.

`bestiary.rs:31–86` defines the typed categories, list and ID lookup;
`organization_catalog_validation.rs:47–61,624–628` separately spells the
allowed curriculum IDs. If a future change updates only one list, a catalog
category could be admitted by one side but not recognized by the other, or a
new typed category could be rejected at catalog validation. This is a
conditional drift scenario, not an observed current input or failure.

The selected ordinary path has safeguards. `build.rs:389–429,449–455` pairs
organization documents with source names and validates them before embedding;
`build.rs:495–507` emits the catalog. `organization.rs:1–10,487–496` loads
that catalog, and `time/schedule.rs:344–367` selects it for nonzero scheduled
organization work. The build validator requires a listed bestiary category;
its paired source list is maintained by the selected builder. This does not
prove every possible caller is constrained by that build path.

The retained public `TrainingTarget::Bestiary` holds a `String`
(`organization.rs:354–380`). `apply_curriculum_training` is public and uses
`BestiaryCategory::from_id`; an unknown string does not enter the award branch
(`strategic_schedule.rs:515–547`). For a directly constructed single unknown
entry, that branch supplies no bestiary award. Whether any supported producer
can supply such an entry, whether skipping is intended, and any user-visible
outcome remain open. This is the same bounded selector/authority question
already described by q2373 and 8b ledger 445, not an automatic extra finding.

The 13 `direct` and `direct_mut` mappings in `bestiary.rs:188–220` also match
at 95e. They are separately written read/write mappings; a future inconsistent
edit could direct a write and read to different fields, but no present mismatch
was found. The category iteration list currently agrees with the correlation
index (`bestiary.rs:31–45,88–150`); iteration order and matrix addressing may
have distinct semantics, so equality alone does not establish another shared
authority. `maximum_effective`, `aggregate_effective` and `total_direct`
compute different summaries from the direct fields (`:243–269`); no separately
stored mutable copy was established in this bounded scope.

The original 059 q3021 is Lens 7, own-lens proof/read pending, with no assessed
ranges; its 8b wrapper remains unassessed. The selected original and
reconstructed q3021 bytes match, as do the five selected related records, while
their complete streams differ. The original source label is `pr-working`; its
recorded 6533 and e275 revisit and current 95e have the same file blob
`62768db020d13ac0e30019ff05a82fa85e2322d8`, SHA-256
`0a8870d89db5190ae5b70aaffd93d7511b144e4861f37ffd649c62f464a3d2b7`, and
330 lines. Their trees differ. This is per-file identity, not clean historical
snapshot or whole-tree identity.

Earlier Root Lens 3 personally read 6533 lines 1–330 and used qualified
same-lens reuse at e275 without a fresh current read. Adler's separate Lens 11
receipt records a fresh 1–330 read for original role 2157 under the
`pr-working` label; its selected record gives no standalone Git revision.
Neither transfers Lens 7 credit. The reviewer independently registered and
displayed current 95e lines 1–330; historical revisions were identity-only.
The last 59 primary lines and two indicated organization windows are test
source text, not executed tests.

Prior q3016 concerned type ownership and tactical flattening. Its author later
corrected the mapping: historical Lens 1 means producer propagation, while the
packet actually applied type ownership. Its read credit and provisional 8b
ledger 1096 relationship remain separate. The q3019 Lens 5 author, peer and
additive gate correction concern aggregate effective hours and the distinct
nonfinite-target condition; q3130/ledger 444 separately tracks that admission
question. None supplies this new Lens 7 read or settles an alias.

The support receipt records all 17 independently displayed windows and every
unread complement. The native organization file was captured for identity
navigation only and had no personal body display. Archived full source bytes
in this packet permit Git-tree verification; their presence does not grant
coverage outside the receipts. The public proof assumes the stated 95e root
tree; exact commit objects and the original unredacted queue remain restricted.
All custody is same-machine, and full Git closure, original 774 pre-export
material, SOURCE004, 73 nontext/no-positive-EOF obligations and missing
checkpoint 3821 remain separate. No product, test, fixture, build, repair or
runtime probe was run, and no ledger or queue entry was changed.
