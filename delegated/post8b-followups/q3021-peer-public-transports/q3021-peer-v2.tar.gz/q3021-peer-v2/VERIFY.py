#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,subprocess
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_bytes());ap=argparse.ArgumentParser()
for n in ('repo','original-queue','extraction','private-manifest','replay-manifest','private-report','author-public','author-private'):ap.add_argument('--'+n,type=Path)
a=ap.parse_args();m=read('MANIFEST.json');assert m['schema']=='726-q3021-l7-peer-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
s=read('SELECTION.json');assert s['index']==3021 and s['original']==s['reconstructed'] and s['original']['lens']==7 and s['selected_equal_as_parsed'] and not s['full_streams_equal'] and s['current']['current_reconciliation']=='unassessed';q=s['original']['exact_source_identities_and_assessed_ranges'][0];assert q['required_ranges']==[[1,330]] and q['assessed_ranges']==[]
src=read('SOURCE.json');assert len(src['views'])==15 and len(src['bestiary_history'])==3 and len({x['tree'] for x in src['bestiary_history']})==3 and all(x['git_blob']=='62768db020d13ac0e30019ff05a82fa85e2322d8' and x['sha256']=='0a8870d89db5190ae5b70aaffd93d7511b144e4861f37ffd649c62f464a3d2b7' and x['lines']==330 for x in src['bestiary_history'])
for x in src['views']:
 b=(p/x['name']).read_bytes();assert h(b)==x['sha256']
hist=read('HISTORY.json');old=hist['root_6533']['fields_present'];cur=hist['root_e275']['fields_present'];assert old['fresh_personal_ranges']==[[1,330]] and cur['fresh_personal_ranges']==[] and cur['qualified_reuse_ranges']==[[1,330]] and cur['qualified_reuse_basis'].startswith('Exact own-L3 adopted source receipt') and hist['adler']['original_index']==2157 and hist['adler']['fresh_reads']==[[1,330]]
assert read('STATIC-COMPARISON.json')['result']=='matched' and read('STATIC-COMPARISON.json')['count']==13
bind=read('BINDING.json');rr=read('RECORDED-REPLAY.json');assert all(x['exit']==0 and x['stderr_bytes']==0 for x in rr['checks']);assert read('SEALED-CHECK.json')['sealed_private_manifest_sha256']==bind['private_manifest_sha256'];proj=read('REPORT-PROJECTION.json');assert h((p/'REPORT.md').read_bytes())==proj['public_report_sha256'];checks=['public members, selected metadata and recorded replay'];not_checked=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','postseal_replay_manifest_sha256'),('original_queue','original_queue_sha256')]:
 f=getattr(a,attr)
 if f is None:not_checked.append(attr+' not supplied')
 else:assert h(f.read_bytes())==bind[key];checks.append(attr+' identity')
if a.private_report:
 b=a.private_report.read_bytes();safe,n=re.subn(rb'/[^/\s`]+/(wrapped_scope)',rb'\1',b);assert h(b)==proj['private_report_sha256'] and n==1 and safe==(p/'REPORT.md').read_bytes();checks.append('generic-alias exact report projection')
else:not_checked.append('private report projection not supplied')
for attr,key,mname in [('author_public','author_public_manifest_sha256','MANIFEST.json'),('author_private','author_private_manifest_sha256','PRIVATE-MANIFEST.json')]:
 root=getattr(a,attr)
 if root is None:not_checked.append(attr+' not supplied')
 else:
  assert h((root/mname).read_bytes())==bind[key]
  if attr=='author_public':assert (root/'REPORT.md').read_bytes()==(p/'AUTHOR-REPORT.md').read_bytes()
  checks.append(attr+' manifest identity'+(' and report bytes' if attr=='author_public' else ''))
rowbind=read('ROW-BINDING.json');indices=sorted(map(int,rowbind['selected']))
def slices(b):
 text=b.decode();m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \t\r\n,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
if a.original_queue:
 rows=slices(a.original_queue.read_bytes());assert all(h(rows[i][1])==rowbind['selected'][str(i)]['raw_sha256'] and len(rows[i][1])==rowbind['selected'][str(i)]['bytes'] for i in indices) and rows[3021][0]==s['original'];checks.append('six original raw queue slices')
if a.extraction:
 for x in hist['records']:
  b=(a.extraction/x['locator']).read_bytes();assert h(b)==x['sha256'] and len(b)==x['bytes']
 checks.append('six protected historical record identities')
else:not_checked.append('protected history not supplied')
if a.repo:
 def git(*cmd):
  r=subprocess.run(['git','-C',str(a.repo),*cmd],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0 and not r.stderr;return r.stdout
 cp='8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b';rev=src['revision'];path=q['source_id'].split(':',1)[1]
 for x in src['bestiary_history']:
  assert git('rev-parse',x['revision']+'^{tree}').decode().strip()==x['tree'] and git('rev-parse',x['revision']+':'+path).decode().strip()==x['git_blob'] and h(git('show',x['revision']+':'+path))==x['sha256']
 sources={}
 for path,x in src['objects'].items():
  b=git('show',rev+':'+path);assert h(b)==x['sha256'] and git('rev-parse',rev+':'+path).decode().strip()==x['git_blob'] and len(b.decode().splitlines())==x['lines'];sources[path]=b.decode().splitlines()
 for x in src['views']:
  lo,hi=x['range'];lines=sources[x['path']];assert (p/x['name']).read_bytes()==''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 atext='\n'.join(sources[q['source_id'].split(':',1)[1]]);vtext='\n'.join(sources['crates/adventuresim-core/src/organization_catalog_validation.rs']);sec=lambda s,a,b:s.split(a,1)[1].split(b,1)[0];variants=re.findall(r'Self::(\w+)',sec(atext,'pub const ALL: [Self; 13] = [','];'));ids=dict(re.findall(r'Self::(\w+)\s*=>\s*"([^"]+)"',sec(atext,'pub const fn id(self)','pub const fn label')));allow=re.findall(r'"([^"]+)"',sec(vtext,'const BESTIARY: &[&str] = &[','];'));d=dict(re.findall(r'BestiaryCategory::(\w+)\s*=>\s*self\.(\w+)',sec(atext,'pub fn direct(self,','pub fn direct_mut')));u=dict(re.findall(r'BestiaryCategory::(\w+)\s*=>\s*&mut self\.(\w+)',sec(atext,'pub fn direct_mut','pub fn effective')));assert len(variants)==13 and [ids[x] for x in variants]==allow and d==u and len(d)==13
 qb=git('show',cp+':baseline-059/queue.json');wb=git('show',cp+':RECONCILIATION-059.json');lb=git('show',cp+':BASELINE-95E-20261110.json');assert h(qb)==rowbind['queue_stream_sha256']['reconstructed'] and h(wb)==rowbind['queue_stream_sha256']['wrapper'] and h(lb)==rowbind['queue_stream_sha256']['ledger'];rows=slices(qb);wrap=json.loads(wb)['entries'];assert rows[3021][0]==s['reconstructed'] and all(h(rows[i][1])==rowbind['selected'][str(i)]['raw_sha256'] and wrap[i]==rowbind['selected'][str(i)]['current'] for i in indices);ledger=json.loads(lb)['newly_assessed_ledger']['entries'];assert all(ledger[x['index']]==x['entry'] for x in read('LEDGER-EXCERPTS.json')['entries']);checks.append('three file/tree identities, 15 views, static mappings, 8b rows and ledger')
else:not_checked.append('Git source and 8b records not supplied')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence identities only; personal displays reviewer-attested. Manifest identity checks for supplied author roots do not individually verify their whole member sets; private full replay does. No product/runtime or independent custody claim.'}))
