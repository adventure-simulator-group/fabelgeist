# q3021 independent peer review: bestiary authority

Reviewer: `wrapped_scope`, independent of author `mhr_character` for this
Lens 7 assessment. I previously peer-reviewed the q3019 Lens 5 aggregate study
and its additive nonfinite-target gate correction; that work remains distinct
and supplies no Lens 7 read credit. The source authority is commit
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`; queue and ledger status are
from published 8b.

## Finding and correction

The author's bounded current-source finding is supported. The 13 category IDs
in `crates/adventuresim-world-schema/src/bestiary.rs:15–85` match the separately
maintained allowlist at `crates/adventuresim-core/src/organization_catalog_validation.rs:47–61`,
including order. The separately written `direct` and `direct_mut` mappings at
`bestiary.rs:188–220` also match. The `ALL` order and index mapping at
`:31–45,88–103` agree, but the index addresses a correlation matrix at
`:106–150`; order agreement alone does not establish one shared authority or a
present mismatch. These are static source comparisons, not an executed test.

The build-time validator checks bestiary training category text against its
list (`organization_catalog_validation.rs:584–628`). The selected builder pairs
organization documents and source labels before passing them to validation
(`crates/adventuresim-core/build.rs:389–429,449–455`), then emits a catalog
(`:495–510`). The runtime catalog include and loader are at
`crates/adventuresim-core/src/organization.rs:1–10,487–496`. On the selected
nonzero scheduled-work path, a resolved catalog definition is passed to
training (`crates/adventuresim-stdb-module/src/time/schedule.rs:344–367`).
The public `TrainingTarget::Bestiary` holds a string
(`organization.rs:362–380`); `apply_curriculum_training`
(`crates/adventuresim-core/src/strategic_schedule.rs:515–547`) resolves it
using `BestiaryCategory::from_id`, and an unknown string skips that bestiary
award branch. For a directly constructed single unknown entry, no bestiary
award occurs through that branch. These source states are conditional: no
supported producer bypassing the selected build path, runtime outcome or
policy decision has been established.

The author report associates this skip with q2373 and ledger 445. Precision:
ledger 445 explicitly records the current raw curriculum selector and unknown
name skip, while q2373's own historical first question is the broader
Bestiary owner-complement and table/test-tail scope. Describe the skip as
already recorded in ledger 445 and related to q2373's separately attributed
owner-complement question; do not attribute this exact first operation to
q2373 or infer an alias or new defect count.

`bestiary.rs:243–269` computes maximum effective, average effective and total
direct values as different summaries. No separately stored duplicate of one
of those summaries was established in these windows. q3019 and q3130/ledger
444 concern different aggregate/effective-hour and admission questions; the
q3019 additive correction retains the source-exact `target <= 0.0` gate and
its nonfinite qualification. q3016/ledger 1096 remains a separate provisional
tactical propagation question: its original historical Lens 1 is producer
propagation and its earlier delegate actually applied type ownership.

## Attribution and limits

Original 059 q3021 requires bestiary `1–330`, has no assessed own-Lens 7
range, and its 8b wrapper is unassessed. The original and reconstructed raw
selected q3021 slices, and five selected related record slices, are byte equal;
the complete streams differ. Root personally read the 6533 full file under
Lens 3. The e275 record describes qualified same-Lens reuse from an adopted
frozen-source receipt and equal objects, retaining Root's original attribution
and no fresh e275 read; this selected row does not contain a pending-adoption
flag. Adler's Lens 11 `pr-working` record attributes a separate fresh full-file
read to original source index 2157 but names no standalone Git revision. These
records are not checkpoint 3821 and do not confer Lens 7 credit.

At 6533, e275 and 95e the bestiary file is the same 330-line blob
`62768db020d13ac0e30019ff05a82fa85e2322d8`, SHA-256
`0a8870d89db5190ae5b70aaffd93d7511b144e4861f37ffd649c62f464a3d2b7`;
the three trees differ. The author's separately attributed current review
covers 1–330 and 17 support windows, including test-source text only. I
independently registered and displayed current bestiary 1–271 and 12 selected
support windows. Lines 272–330 were not personally displayed in this peer
review. Retained complete source blobs provide identity/replay, not broader
read credit; displays are reviewer-attested, not independently telemetered.

Before exact entry-by-entry registration, I displayed several author packet
metadata files beyond the initially named report and manifests; those exposures
are recorded and the relevant files were subsequently registered and
recaptured. A first historical display clipped two long receipt rows; the full
records were retained and a bounded field re-display corrected that limit.
My initial history registration's wording could imply a pending-adoption flag;
a separate correction preserves the actual selected e275 row and basis.

The original stream, protected historical extraction, source Git objects and
prior author packets remain separately held same-machine dependencies. Missing
checkpoint 3821, SOURCE004, 73 nontext/no-positive-EOF obligations, original
774 pre-export material, and reconstructed-record qualifications remain open.
No product code, tests, fixtures, macros, build, repair, runtime probe or
validation was run, and no queue or ledger was edited.
