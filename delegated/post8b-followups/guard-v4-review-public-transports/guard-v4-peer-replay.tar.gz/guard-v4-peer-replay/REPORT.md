# Independent static comparison of the post-8b guard draft v4

Reviewer: `final_guard_peer`. Against the fixed stage snapshot, v4 adds the
six later public-transport verifiers and four pending-synthesis verifiers to
the previously reviewed v3 loop. The loop contains all nine transport and all
four pending verifiers present in that snapshot; its 17 entries also include
reconciliation, review binding and two encrypted-custody verifiers. The
application-candidate v2 verifier is invoked separately. All ten newly required
package manifests and their listed member hashes match the captured inventory.
This is a static comparison: none of the prepared guards, builders, installers
or package verifiers was run by this reviewer.

The captured stage contained 314 files. Its before/after inventory records all
file bytes, sizes, file modes and directory/root modes; 74 verifier, manifest,
pin and Markdown files were also copied for inspection. The other stage bytes
remain separately held same-machine dependencies. The q3033 public transport
arrived after this snapshot and is not in v4's loop. Third and fourth custody
groups, the final index and any later additions are also outside the v4 cutoff
and require a successor guard. The snapshot had no `INDEX.md`, which v4's
builder requires before it can proceed.

The successor templates match the two recorded literal substitutions to the
previously reviewed v3; the root template is byte-identical. The v4 derivation
log records a successful derivation and reports that no guard was built; the
outer execution envelope is not separately retained. The captured v4 builder
directory has no build result or `RUN.py`. Its own build script rejects an
optimized interpreter, but the v3 build runner is not present in the v4
directory. A separately recorded build invocation or driver remains later work.

## What the guard would bind

At a future build, v4 inventories each staged regular file's byte length,
SHA-256 and owner-executable bit. It embeds the resulting stage-manifest hash in
the stage guard, then embeds the guard hash in the prospective root guard. The
verification template compares the file set and these values and rejects
descendant symlinks. This is file-byte and Git executable-bit coverage; it does
not bind full POSIX file modes, directory/root modes or empty directories. The
reviewer's full-mode snapshot does not add that enforcement. Root-candidate
capture, exact installation, final stage freeze and publication are separate.

The builder reads the live v3 privacy driver into a root candidate and records
the resulting hash without asserting the earlier review's expected driver
hash. The live file matched that reviewed copy at this review's capture, but
the builder does not itself prevent a later change. A successor must pin or
independently capture the exact driver used. The builder writes the guard and
root candidates sequentially; a failure can leave partial output, so a failed
attempt needs preservation and review before any retry.

## Optional predecessor routing

The root and stage templates accept optional `--predecessor` and `--ancestor`;
an ancestor requires a predecessor. The application-candidate v2 verifier is
designed to check a supplied clean 8b predecessor's HEAD, tree and selected
parent paths. Only when an ancestor is also supplied does it invoke the 8b
root guard with that ancestor. The captured 8b guard routes the argument to
its older application verifier, which checks a clean 8ca HEAD and invokes the
8ca root guard without a further predecessor argument. No predecessor or
ancestor checkout was replayed here, and this route does not establish deeper
history by itself.

The v3 comparison was independently authored by `mhr_character`; this review
binds its public and restricted packets without transferring its credit. This
reviewer authored q3033 and peer-reviewed q3598, both separately scoped source
work, and previously reviewed earlier checkpoint custody and guard controls.
The q3033 transport was captured separately after the stage snapshot only to
record its exclusion.

The original source revision, old extraction, Git objects, encryption key,
prior nonce inventories, authenticated restoration, full privacy scan, final
installation and remote observation remain separately qualified. Missing
checkpoint 3821, SOURCE004, the 73 nontext/no-positive-EOF items,
reconstructed 440 and normalized 774 distinctions remain open. No product
code, tests, builds, fixtures, repairs or runtime probes were executed; no
audit closure or independent backup is claimed.
