from pathlib import Path, PurePosixPath
import hashlib
import json

p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes())
assert m['schema']=='726-post8b-guard-v4-peer-public-manifest-v1'
assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1
 f=p/n;assert f.is_file() and not f.is_symlink();raw=f.read_bytes();assert len(raw)==row['bytes'] and h(raw)==row['sha256']
b=json.loads((p/'BINDING.json').read_bytes());c=json.loads((p/'COVERAGE.json').read_bytes())
assert b['captured_stage_files']==314 and b['transport_verifiers']==9 and b['pending_verifiers']==4 and not b['index_present_at_capture']
assert c['included_at_snapshot']['transport_verifiers']==9 and c['included_at_snapshot']['pending_synthesis_verifiers']==4
print(json.dumps({'public_members':len(m['files']),'result':'passed','qualification':'Public file identity and stated cutoff only; not an execution of the reviewed guard, source validation or independent custody.'}))
