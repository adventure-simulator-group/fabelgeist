#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,subprocess,tarfile,io
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_bytes());ap=argparse.ArgumentParser()
for n in ('repo','original-queue','extraction','private-manifest','replay-manifest','private-report','prior-q3019','prior-q3021'):ap.add_argument('--'+n,type=Path)
a=ap.parse_args();m=read('MANIFEST.json');assert m['schema']=='726-q3023-l9-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
s=read('SELECTION.json');assert s['index']==3023 and s['original']==s['reconstructed'] and s['original']['lens']==9 and s['selected_equal_as_parsed'] and not s['full_streams_equal'] and s['current']['current_reconciliation']=='unassessed';q=s['original']['exact_source_identities_and_assessed_ranges'][0];assert q['required_ranges']==[[1,330]] and q['assessed_ranges']==[]
src=read('SOURCE.json');assert len(src['views'])==19 and len(src['bestiary_history'])==3 and len({x['tree'] for x in src['bestiary_history']})==3 and all(x['git_blob']=='62768db020d13ac0e30019ff05a82fa85e2322d8' and x['sha256']=='0a8870d89db5190ae5b70aaffd93d7511b144e4861f37ffd649c62f464a3d2b7' and x['lines']==330 for x in src['bestiary_history'])
for x in src['views']:
 b=(p/x['name']).read_bytes();assert h(b)==x['sha256']
hist=read('HISTORY-SUMMARY.json');assert hist['root_6533']['fresh_personal_ranges']==[[1,330]] and hist['root_e275']['fresh_personal_ranges']==[] and hist['root_e275']['qualified_reuse_ranges']==[[1,330]] and hist['root_e275']['qualified_reuse_basis'].startswith('Exact own-L3 adopted source receipt') and hist['root_e275']['pending_adoption_field_present'] is False and hist['adler']['original_index']==2157 and hist['adler']['fresh_reads']==[[1,330]] and not hist['adler']['revision_field_present'];rows=read('RAW-SELECTION.json');assert len(rows)==8 and all(x['exact_raw_equal'] for x in rows.values());rel=read('RELATED-SUMMARY.json');assert [rel['ledger'][str(i)]['id'] for i in [444,445,1096,1110]]==['REVIEW-L3-BESTIARY-EXPERIENCE-ADMISSION','REVIEW-L2-BESTIARY-CATEGORY-OWNER-95E','relationship-bestiary-hours-tactical-propagation-95e','relationship-organization-skill-requirement-shape-95e'];bind=read('BINDING.json');rr=read('RECORDED-REPLAY.json');assert all(x['exit']==0 and x['stderr_bytes']==0 for x in rr['checks']);assert read('SEALED-CHECK.json')['sealed_private_manifest_sha256']==bind['private_manifest_sha256'];proj=read('REPORT-PROJECTION.json');assert h((p/'REPORT.md').read_bytes())==proj['public_report_sha256'];evidence=read('EVIDENCE-IDENTITIES.json');assert h((p/'Q2503-REVIEW-L9.md').read_bytes())==evidence['archive_report_sha256'];checks=['public member identities, selected records and recorded replay'];not_checked=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','postseal_replay_manifest_sha256'),('original_queue','original_queue_sha256')]:
 f=getattr(a,attr)
 if f is None:not_checked.append(attr+' not supplied')
 else:assert h(f.read_bytes())==bind[key];checks.append(attr+' identity')
if a.private_report:
 b=a.private_report.read_bytes();safe,n=re.subn(rb'/[^/\s`]+/(wrapped_scope)',rb'\1',b);assert h(b)==proj['private_report_sha256'] and n==1 and safe==(p/'REPORT.md').read_bytes();checks.append('generic-alias exact report projection')
else:not_checked.append('private report projection not supplied')
for root,x in zip([a.prior_q3019,a.prior_q3021],evidence['prior_reports']):
 if root is None:not_checked.append(x['name']+' prior packet not supplied')
 else:assert h((root/'MANIFEST.json').read_bytes())==x['source_manifest_sha256'] and h((root/'REPORT.md').read_bytes())==x['sha256'];checks.append(x['name']+' manifest and report identity')
indices=sorted(map(int,rows))
def slices(b):
 text=b.decode();m=re.search(r'"entries"\s*:\s*\[',text);assert m;pos=m.end();dec=json.JSONDecoder();out={}
 for i in range(max(indices)+1):
  while text[pos] in ' \t\r\n,':pos+=1
  start=pos;v,pos=dec.raw_decode(text,pos)
  if i in indices:out[i]=(v,text[start:pos].encode())
 return out
if a.original_queue:
 selected=slices(a.original_queue.read_bytes());assert all(h(selected[i][1])==rows[str(i)]['sha256'] and len(selected[i][1])==rows[str(i)]['bytes'] for i in indices) and selected[3023][0]==s['original'];checks.append('eight original raw queue slices')
if a.extraction:
 for x in evidence['historical_records']:
  b=(a.extraction/x['locator']).read_bytes();assert h(b)==x['sha256'] and len(b)==x['bytes']
 old=json.loads((a.extraction/'root-l3-extension-20261030/READ-ROOT-L3-EXT-020-027.json').read_bytes());cur=json.loads((a.extraction/'root-l3-extension-20261030/READ-ROOT-L3-CURRENT-004.json').read_bytes());ad=json.loads((a.extraction/'adler/READ-L11-338.json').read_bytes())
 oldrow=next(x for x in old['rows'] if 'bestiary.rs' in json.dumps(x));currow=next(x for x in cur['rows'] if 'bestiary.rs' in json.dumps(x));adrow=next(x for x in ad['sources'] if 'bestiary.rs' in json.dumps(x));ho=hist['root_6533'];hc=hist['root_e275'];ha=hist['adler']
 assert old['lens']==ho['lens'] and oldrow['revision']==ho['revision'] and oldrow['fresh_personal_ranges']==ho['fresh_personal_ranges'] and oldrow['attribution']==ho['attribution']
 assert cur['lens']==hc['lens'] and currow['revision']==hc['revision'] and currow['fresh_personal_ranges']==hc['fresh_personal_ranges'] and currow['qualified_reuse_ranges']==hc['qualified_reuse_ranges'] and currow['qualified_reuse_basis']==hc['qualified_reuse_basis'] and ('frozen_source_adoption_pending' in currow)==hc['pending_adoption_field_present']
 assert ad['lens']==ha['lens'] and all(adrow[k]==ha[k] for k in ('source_id','original_index','scope','fresh_reads')) and ('revision' in adrow)==ha['revision_field_present'] and adrow.get('revision')==ha['recorded_standalone_revision']
 checks.append('six protected history identities and reconstructed selected attribution fields')
else:not_checked.append('protected history not supplied')
if a.repo:
 def git(*cmd):
  r=subprocess.run(['git','-C',str(a.repo),*cmd],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0 and not r.stderr;return r.stdout
 cp='8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b';rev=src['revision'];path=q['source_id'].split(':',1)[1]
 for x in src['bestiary_history']:assert git('rev-parse',x['revision']+'^{tree}').decode().strip()==x['tree'] and git('rev-parse',x['revision']+':'+path).decode().strip()==x['git_blob'] and h(git('show',x['revision']+':'+path))==x['sha256']
 sources={}
 for path,x in src['objects'].items():
  b=git('show',rev+':'+path);assert h(b)==x['sha256'] and git('rev-parse',rev+':'+path).decode().strip()==x['git_blob'] and len(b.decode().splitlines())==x['lines'];sources[path]=b.decode().splitlines()
 for x in src['views']:
  lo,hi=x['range'];lines=sources[x['path']];assert (p/x['name']).read_bytes()==''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 qb=git('show',cp+':baseline-059/queue.json');wb=git('show',cp+':RECONCILIATION-059.json');lb=git('show',cp+':BASELINE-95E-20261110.json');assert h(qb)==s['reconstructed_sha256'] and h(wb)==s['reconciliation_sha256'] and h(lb)==rel['ledger_sha256'];selected=slices(qb);wrap=json.loads(wb)['entries'];assert selected[3023][0]==s['reconstructed'] and wrap[3023]==s['current'];assert all(h(selected[i][1])==rows[str(i)]['sha256'] for i in indices);assert all(wrap[int(k)]==v['current'] for k,v in rel['rows'].items());ledger=json.loads(lb)['newly_assessed_ledger']['entries'];assert all(ledger[int(k)]==v for k,v in rel['ledger'].items())
 central=git('show',cp+':ASSESSMENT-CENTRAL-FOLLOWUPS-21-95E.json');archive=git('show',cp+':delegated/postf2ec-followups/final-transport/q2501-2504.tar.gz');assert h(central)==evidence['central_sha256'] and h(archive)==evidence['archive_sha256'];assessments=json.loads(central)['assessments'];assert next(x for x in assessments if x.get('index')==2503)==read('PRIOR-CENTRAL-Q2503.json')
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:assert t.extractfile('REVIEW-L9.md').read()==(p/'Q2503-REVIEW-L9.md').read_bytes()
 checks.append('three file/tree identities, 19 views, eight reconstructed raw rows and 8b ledger, central and archived q2503 report')
else:not_checked.append('Git sources and 8b records not supplied')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence identities only; personal displays reviewer-attested. Prior peer options check manifest/report identities, not all members; private full replay has the same limit. No product/runtime or independent custody claim.'}))
