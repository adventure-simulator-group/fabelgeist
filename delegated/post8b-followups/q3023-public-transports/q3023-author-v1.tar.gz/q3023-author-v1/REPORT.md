# q3023: bestiary enum and state-shape assessment

Reviewer: `wrapped_scope`, independently registered under Lens 9 at
product commit `95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. Status and relationships are
from published 8b. This work follows the current custody cutoff and remains
unadopted. The reviewer previously peer-reviewed q3019 Lens 5 and q3021 Lens 7,
and authored a separate q2503 Lens 9 organization assessment; none of those
reads transfers credit to this assessment.

## Bounded result

`crates/adventuresim-world-schema/src/bestiary.rs:15–29` already represents
one category with `BestiaryCategory`, a closed unit enum. `BestiaryHours` at
`:154–171` separately stores hours for all categories, and `:173–177,188–220`
uses a category to select one field. These are simultaneous per-category
values rather than a choice of one mutually exclusive state; this evidence
does not support replacing the aggregate with a single category variant.
The boolean at `:180–185` is a computed validity result, not a stored state
flag, and the direct-study condition at `:224–228` is computed from the
selected value. The source-exact condition is `<= 0.0`; nonfinite treatment and
its admission are separate questions, including the prior q3019 gate correction.
No new carried flag/adjacent-payload mismatch was identified inside the
bestiary file in this bounded Lens 9 review.

## Connected organization shape

The selected connected `Requirement::SkillRating` arm carries a free `skill`
string and an optional `leaf` (`crates/adventuresim-core/src/organization.rs:340–352`).
It can be directly constructed with `skill = "bestiary"` and `leaf = None`,
while the selected authored requirement validator requires a listed bestiary
leaf (`organization_catalog_validation.rs:132–167`, category list `:47–61`).
The selected build path pairs documents with source names before calling the
validator (`crates/adventuresim-core/build.rs:389–429,449–455`), whose role
and admission paths call that helper (`organization_catalog_validation.rs:207–216,342–346,494–511`).
Thus that selected build-validated path guards the demonstrated combination;
all other construction, decoding and ingress paths remain open.

If a directly constructed missing-leaf requirement is supplied to the
inspected helpers, the source indicates different local outcomes. The selected
starting-character lookup produces no value for the bestiary skill without a
leaf and its requirement check returns false (`starting_character.rs:789–821,825–860,863–882`).
If a character skills row exists, the native requirement check obtains no
bestiary value and returns its unknown-requirement error
(`crates/adventuresim-stdb-module/src/organization.rs:145–167,195–220`).
The selected life-simulation credential conversion instead produces a
`FixedSkill` target carrying the string (`life_simulation.rs:274–299`); this
review does not establish its later training or player-visible outcome.
Those are source-level conditional traces, not a supported malformed input or
runtime witness. A future owner for valid skill/leaf combinations could encode
the relevant payload with its skill kind while preserving authored wire and
boundary policy; the exact design and alternate producer reach remain open.

This is a corroboration of the already recorded q2503/ledger 1110
organization requirement-shape question, including its selected native error,
not a new finding count. The starting-character and life-simulation windows
are additional separately registered support here; no automatic alias is
assigned to other records. q2373/ledger 445 and q3021 concern the related
training selector/authority and a distinct raw-category skip. q3016/ledger
1096 concerns tactical propagation; q3019 and q3130/ledger 444 concern
aggregate/admission behavior. Preserve those separate first operations.

## Evidence and recovery limits

Original 059 q3023 is `OBLIGATION-ROOT-L3-EXT-0026-LENS-09`, requires
historical bestiary `1–330`, and has an empty own-Lens 9 assessed range. Its
8b wrapper remains unassessed. Eight selected original and reconstructed
queue slices, including q3023 and the named related rows, are byte equal;
their complete streams differ. Root's 6533 personal full-file read is Lens 3;
the e275 record states qualified reuse based on an adopted frozen-source
receipt, with no fresh e275 personal read. The selected e275 row contains no
pending-adoption field. Adler's separate Lens 11 `pr-working` receipt reports
a full-file read for original source registry index 2157 without a standalone
Git revision. None transfers Lens 9 credit or recovers checkpoint 3821.

The 6533, e275 and 95e bestiary file is the same 330-line blob
`62768db020d13ac0e30019ff05a82fa85e2322d8`, SHA-256
`0a8870d89db5190ae5b70aaffd93d7511b144e4861f37ffd649c62f464a3d2b7`;
the trees differ, so this is per-file identity only. Nineteen newly registered
current-source windows were personally displayed; bestiary `:272–330` is
test source text only and was not executed. Displays are reviewer-attested,
not independently telemetered. Complete captured blobs outside displayed
windows are identity evidence, not additional reading credit.

Full original 059, protected history extraction, prior review packets and Git
objects remain separately held same-machine dependencies. Missing 3821,
SOURCE004, 73 nontext/no-positive-EOF items, reconstructed-record and
normalized 774/pre-export qualifications remain open. No product code, build,
test, fixture, macro, repair, runtime probe or validation was run; no queue or
ledger was edited. The selected connected scope does not close the broader
record, any lens, or the audit.
