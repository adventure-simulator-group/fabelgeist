# Prerequisite invoker v3 and outer successors: static review

The separately captured successors address the two failure-recording findings
in the v2 review. The invoker v3 records the expected program hash separately
from the observed before-image, which stays null if no read succeeds. Outer v2
stores a wrapper exception separately from already captured child stderr.
Outer v3 retains that change and pins the exact invoker v3. Its only changes
from outer v2 are the invoker path, its hash and the result schema. Outer v2
still selects invoker v2 and is not interchangeable with outer v3.

`invoker-v3/INVOKE.py:36–50,88–91` establishes the observed/expected split,
including the new v3 prior-result schema; a v2 anchor result cannot satisfy
this v3 check. `outer-v3/RUN.py:20–42` preserves distinct child stderr and
outer-error files, and declares success only with matching pre/post invoker
hashes, zero child exit and no outer error. The exact retained anchor and trial
wrapper hashes match the invoker's pins. Three derivation records match their
captured predecessor and successor whole-file identities. No additional
deterministic blocker was found in this bounded static comparison.

The earlier v1/v2 observations and packets remain unchanged. Anchor output
and invocation records are same-machine evidence rather than independent
custody; their provenance and the later root capture require separate
retained bindings. A separately pinned caller must retain the outer wrapper's
own streams and exit. Pre-log failures, abrupt interruption, concurrent
replacement, storage failure, partial changes and lack of rollback remain
qualified; this review does not establish an atomic transaction. The reviewer
authored the prior invoker and trial/anchor reviews. No invoker, outer wrapper,
anchor, trial, guard, installer, scanner or product was run; replay checks
captured bytes and static predicates only.
