# Prerequisite invoker v2 and outer wrapper: static review

The revised invoker addresses the two recorded v1 gaps for the selected
successful path. It creates an attempt before ordinary input preflight and
checks the prior anchor result's schema, successful exit, mode and pinned child
wrapper identities. Its prior result must be a regular, non-symlink file at
the expected path. An explicit outer wrapper pins the revised invoker before
and after the child, clears inherited Git overrides and Python optimization for
the child, and records selected streams. These are static observations; the
programs were not run.

Two failure-recording issues remain:

1. `outer/RUN.py:31–35` captures the child stdout and stderr, but if the
   subsequent invoker identity read raises, the exception handler replaces
   the child stderr with the traceback. Thus a postcheck failure can discard
   actual child stderr. Keep wrapper errors separate from the child streams.
2. `v2/INVOKE.py:39–40,87–90` writes `program_sha256_before` as the expected
   constant even if the preflight assertion failed because the observed bytes
   did not match. This does not make that attempt successful, but the receipt
   can misstate the observed before-image. Record the observed digest (or null)
   separately from the expected identity.

The derivation binds the retained v1 and v2 whole-file identities. The outer
wrapper's invoker pin and v2's two child-wrapper pins match separately captured
reviewed files. `v2/INVOKE.py:25–31,38–54,80–94` retains ordinary preflight
and postcheck exceptions after attempt creation; `outer/RUN.py:18–45` remains
subject to failures before its own log creation or while recording. Child exit
and wrapper exit are different observations and need separate outer streams.

The anchor result and later capture binding are same-machine evidence, not
independent custody or proof against stale, forged, or concurrently replaced
files. Abrupt interruption, storage failures and concurrent mutation remain
open; no atomic multi-file guarantee or rollback is established. The eventual
outer invocation and root-capture identities need separate retained anchors.
The reviewer authored the prior v1 and trial/anchor reviews. The offline replay
checks captured text and identities only; no invoker, anchor, trial, guard,
installer, scanner or product execution was performed.
