# Static review: trial prerequisite invocation v1

The unrun invoker pins the previously reviewed anchor-v2 and trial-v5 wrapper
bytes. In the normal anchor-to-trial path it carries the root-capture digest
through the anchor outputs and checks the trial wrapper's capture, inventory,
and journal results. Two limits remain before its records can be treated as a
complete invocation binding.

`INVOKE.py:23-40` performs program, capture and prior-record preflight before
creating its attempt directory. A failure in those steps, or in the subsequent
directory creation, leaves no invocation-owned child stream or result record.
A separately captured outer stdout, stderr and exit is needed for those errors.
Interruption and storage failure can also prevent a complete record.

In trial mode, `INVOKE.py:32-40` checks the prior anchor record's success and
mode, and binds the current anchor and anchor-run file hashes and capture
digest. It does not check the prior invocation record's schema, exit, or
recorded wrapper hashes against the reviewed anchor wrapper, and reads that
prior record without a regular non-symlink check. Thus those predicates alone
do not establish the full prior invocation identity. Validate the earlier
record and wrapper identity or retain that attribution as an external custody
and chronology dependency.

The child wrapper hashes in the invoker match the separately captured reviewed
anchor-v2 and trial-v5 wrappers. The invoker itself also needs a separately
bound invocation identity. All captures are same-machine evidence; no
independent backup or protection from concurrent mutation is implied.
The reviewer authored the separate trial-v5/anchor-v2 comparison. No invoker,
anchor, trial, guard, installer, product, build, test, or runtime probe ran.
