#!/usr/bin/env python3
"""Verify finite public bytes and optional reviewed draft identity."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--draft',type=Path);args=ap.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-three-central-v3-peer-public-manifest-v1' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
r=json.loads((p/'REVIEW.json').read_bytes());v=json.loads((p/'EVIDENCE-VERIFY.json').read_bytes());assert r['changed_field_paths']==v['changed_field_paths']==13 and len(v['checks'])==9 and all(v['checks'].values());checked=False
if args.draft is not None:assert args.draft.is_file() and not args.draft.is_symlink() and h(args.draft.read_bytes())==r['reviewed_draft'];checked=True
print(json.dumps({'public_members':len(m['files']),'draft_identity_checked':checked,'qualification':'Finite public bytes and optional draft hash only; no source display or product validation.'}))
