# Independent static review of the post-8b transform

The unrun v4 transform has one wording issue that should be corrected before
application. Its remaining arithmetic and selected-record checks agree with
the captured 8b inputs, subject to the external bindings below. This is a
review of evidence-processing text; it is not a new product-source review or
a decision to adopt the proposal.

At `TRANSFORM-v4.py:64–71`, the proposed ledger relationship says the two 059
streams differ and “neither is missing checkpoint 3821 authority.” That phrase
can mean that neither stream lacks the authority, contradicting the intended
qualification. Use explicit wording such as “neither stream restores or
represents the missing checkpoint 3821 authority.” This changes wording only;
it should not imply recovery, closure, a new count, or a change in attribution.

The v4 function is intentionally a pure transformation over supplied inputs,
but it does not itself prove that those inputs are the authorized ones:

* Lines 25–35 and 45–55 check shapes, selected identities and aggregate counts,
  but do not bind the four `before` byte streams to the exact committed 8b
  objects. An application wrapper must bind all four original bytes and the
  parent commit before invoking the transform; otherwise unrelated altered
  content could be preserved relative to a different supplied baseline.
* Lines 37–42 require equality of selected assessment fields and four proposed
  relationships, but do not require the rest of the report to retain the
  proposal’s top-level input bindings and historical qualification. A truthy
  `independent_assembly_review` or `adoption_qualification`, and an empty
  `pending_reviews`, do not verify the referenced reviews or their chronology.
  Bind a separately reviewed report as a precise allowed successor of v5,
  retain the input identities and qualifications, and verify every required
  review and public evidence target before installation. Candidate bytes marked
  adopted remain an uninstalled candidate until that installation succeeds.
* Lines 31–33 and 83–90 compare the supplied main observation’s ref, revision,
  tree and lexically ordered timestamp strings, then describe a GitHub
  connector observation. They do not authenticate the connector response,
  establish valid UTC timestamps, or bind the input object to the separately
  published `MAIN-RECHECK-POST8B.json`. A later guard must bind the actual
  point-in-time observation, provenance and valid ordered interval before the
  assertion is represented as fact. The observation can become stale.

Static control-flow inspection supports semantic preservation relative to the
supplied inputs: queue entries outside the five indices are compared unchanged;
selected rows may change only reconciliation and added evidence; the first
1,135 ledger entries are retained, four distinct proposed relationships are
appended, and existing progress/baseline fields are preserved except for the
explicit updates. This is a parsed-object statement, not a byte-for-byte claim
for the serialized outputs. The three unchanged 8b JSON inputs already match
the transform’s standard serialization before any modification. The
continuation marker occurs once. No after-image was produced or executed.

The independent data check confirms five unassessed 8b entries with matching
contract IDs, historical lenses and projected statuses. Counts are 3,713 total,
1,404 partial and 2,309 unassessed, with 1,135 ledger entries. If exactly those
five rows and four distinct relationships are applied, the arithmetic becomes
1,409 partial, 2,304 unassessed and 1,139 ledger entries; no semantic closure
or unique-defect increment follows. All relationship queue and ledger indices
are in range and the four IDs are new in that ledger.

All 22 selected/related original and reconstructed 059 records agree in raw
selected bytes and parsed form; the complete streams differ. Original q2701
has no status member; its 8ca wrapper has explicit null. The proposal’s 8ca
q2747/q2750 partial and q2748 unassessed qualifications match that snapshot.
The ten cited source-packet paths exist at 8b. The new report, main observation
and post-8b index do not exist at 8b; a future candidate must stage and verify
them and its actual input identities before application.

The 8b `verify_post8ca_checkpoint.py:7–10` invokes the committed final guard.
That guard checks exact captured root-file bytes and modes at `VERIFY.py:18–24`
and its prior four-row comparison at lines 42–48. A successor that changes the
four root files cannot satisfy the old exact-root guard in place. Replay the old
guard from a separate, exact 8b recovery checkout; its optional `--predecessor`
must name a separate clean 8ca checkout for the nested predecessor replay.
Without that argument the guard expressly reports the nested replay skipped.
The successor’s own guard must then independently verify its new root files,
application, links and historical qualifications. Same-machine Git objects,
keys and recovery checkouts do not establish independent custody or full Git
closure.

This reviewer authored the separate q2743 and q2744 source assessments and was
the q2545 draft peer. Those roles do not transfer independent source credit
into this transform review. Coordinator and original reviewer attribution,
original/reconstructed distinctions, the missing checkpoint and all source
reach/policy limits remain separate. The transform, old guard, product, tests,
fixtures and runtime probes were not executed; no ledger or publication file
was changed.
