# Lens 11 core anatomy selection: bounded metadata result

Reviewer: /root/wrapped_scope. At 8b, lexical navigation over the full recovered
original and reconstructed 059 queue and committed reconciliation found no
unassessed Lens 11 record whose recorded exact source identity names a core
anatomy/injury path. Metadata-only 95e Git tree navigation located
`crates/adventuresim-core/src/body.rs`, `src/combat/wounds.rs` and
`src/physiology.rs`; finding those filenames does not establish that a queued
Lens 11 scope or semantic contract exists. Other indirect or differently
spelled locators may exist, so this is not a global absence or alias proof.

Full-record core navigation found 18 unassessed Lens 11 records mentioning
`adventuresim-core`. q1961/q1976/q2006/q2008 register broad `autoresolve.rs`
ranges at their recorded 7a9d/e275 revisions; that filename alone does not
establish an anatomy-specific scope and may overlap active combat work. The
injury-named q26 concerns strategic terminal-clock behavior, which the
coordinator excluded. The sole compound [11,13] row, q9, is already partial
and concerns attack identity. A separate exact-path cross-lens search found
q2292 and q2333 for `physiology.rs` under Lens 13; q2333 is already partial.
These records retain their own lenses, readers, original revisions, current
status and unreconciled questions; none supplies Lens 11 body credit.

The original and reconstructed complete queue streams differ; their source
identities and checkpoint 8b metadata remain separate. Some printed metadata
previews intentionally used bounded excerpts, with full records still in the
separately held original queue. This selection work displayed no product source
body and did not change a queue, ledger, stage or product file. No product
build, test, fixture, repair or runtime probe was run. The requested reservation
requires a coordinator decision on the unmatched source-family constraint.
Checkpoint 3821 remains unrecovered.
