#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;a=argparse.ArgumentParser()
for n in ['private-manifest','replay-manifest','v4-public-manifest','v4-private-manifest']:a.add_argument('--'+n,type=Path)
args=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());expected={'REPORT.md','BINDING.json','RECORDED-REPLAY.json','STRUCTURAL-CHECK.json','VERIFY.py','PUBLIC-SCAN.json'}
assert m['schema']=='726-post8b-five-v5-peer-public-v1' and set(m['files'])==expected and {x.name for x in p.iterdir()}==expected|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
x=json.loads((p/'BINDING.json').read_bytes());assert x['schema']=='726-post8b-five-v5-peer-binding-v1';r=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert len(r['checks'])==3 and all(c['exit']==0 and c['stderr_bytes']==0 for c in r['checks']);s=json.loads((p/'STRUCTURAL-CHECK.json').read_bytes());assert s['assessments_unchanged']==5 and s['planning_links_unchanged']==4 and s['candidate_counts_unchanged'] and s['application_installation_review_explicit']
checks=['public members','recorded evidence results']
for name,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','replay_manifest_sha256'),('v4_public_manifest','v4_public_manifest_sha256'),('v4_private_manifest','v4_private_manifest_sha256')]:
 value=getattr(args,name)
 if value is not None:assert h(value.read_bytes())==x[key];checks.append(name)
print(json.dumps({'checks':checks,'qualification':'Public identities and optional manifest bytes only; source/history proof requires separately held v3/v4 restricted evidence and external anchors.'}))
