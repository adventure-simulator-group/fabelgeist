#!/usr/bin/env python3
"""Check finite public review bytes and optional exact draft identity."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--draft',type=Path);args=ap.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-three-central-peer-public-manifest-v1' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for name,row in m['files'].items():
 assert len(PurePosixPath(name).parts)==1;f=p/name;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
a=json.loads((p/'REVIEW.json').read_bytes());v=json.loads((p/'EVIDENCE-VERIFY.json').read_bytes());s=json.loads((p/'SOURCE-MAP.json').read_bytes());assert [x['queue_index'] for x in a['selected']]==[2913,2962,2952] and a['personally_displayed_product_windows']==v['personally_displayed_windows']==len(s['product_windows'])==35 and a['personally_displayed_third_party_windows']==v['dependency_windows']==sum(len(x['windows']) for x in s['third_party_packages'])==3 and len(v['checks'])==12 and all(v['checks'].values());checked=False
if args.draft is not None:assert args.draft.is_file() and not args.draft.is_symlink() and h(args.draft.read_bytes())==a['draft'];checked=True
print(json.dumps({'public_members':len(m['files']),'draft_identity_checked':checked,'qualification':'Public bytes and optional draft identity only; no independent display telemetry or product execution.'}))
