# Independent review of the three-record draft

The selected source supports the draft's qualified q2913, q2962 and q2952
summaries. I recommend the source-reference and provenance refinements below
before using this unadopted draft for central reconciliation. The independent
checks do not establish supported scenarios, product behavior, global aliases,
unique-defect counts or audit closure.

* **q2913, texture aggregate state.** The current reservation and install
  windows support the conditional sparse-channel question; the selected
  forest-soil set also demonstrates an intentional mix of two recipes. A new
  mask is allocated on reservation, but a supported later reservation with an
  old retained, unrefreshed material is not established. Add the missing
  startup registration reference
  `crates/adventuresim-tactical-client/src/presentation/mod.rs:227–256` and
  identify the checksum-bound `bevy_asset` 0.19.1
  `src/assets.rs:399–404` source for `Assets::add` allocating a handle.
  Neither sparse admission nor mask lifetime is demonstrated by execution.
* **q2962, grounding behavior.** The separately labeled 58ea producer checks
  each position and constructs the old cell, while 95e also checks the
  aggregate before the collider. Finite-sum overflow, equal relative heights
  after rounding, zero-area handling and winding remain symbolic conditional
  comparisons. The old native result, intended policy and supported inputs are
  open. Add historical 58ea references
  `crates/adventuresim-building-generator/src/spatial_geometry/coordinates.rs:42–53`
  for the position admission and
  `crates/adventuresim-tactical-core/src/city_layout/grounding/enclosure.rs:20–25`
  for the old public fields. The sum-overflow question remains distinct from
  ledger 1083's finite sum followed by a nonfinite centered subtraction.
* **q2952, derivability.** The selected checked conversion calls validation;
  the digest explicitly hashes ordered scalar representations, including
  floating-point bits. The locked `serde_derive` 1.0.229 source shows the
  deserialize-then-TryFrom template. Resolved features, macro expansion,
  equivalent derive alternatives, supported signed-zero changes and policy
  remain open; no derivability repair is established.

All three original queue rows record
`own-lens-proof-qualification-or-read-pending`, with no assessed range under
the selected lens; their committed 8b wrappers are `unassessed`. The selected
original and reconstructed records match as parsed, whereas complete streams
differ. The assigned files match by file at 6533, e275 and 95e; that is not
whole-tree equivalence. For q2962 the introduction file at 5a also matches,
and its parent 58ea lacks the admission file. The 58ea producer and collider
views must stay labeled as historical.

For q2913, the Root Lens 3 historical receipt attributes the 6533 fresh read;
the e275 same-lens receipt has no fresh read and preserves pending adoption
of frozen sources 18/19. For q2952 and q2962, the checked Lens 2 and Lens 3
records attribute distinct fresh 6533 reads and qualified e275 reuse with no
fresh e275 personal read. Their Lens 3 reuse receipt describes an adopted
prior source; the q2913 18/19 pending flag must not be carried over to them.
Adler's separately recovered q2962-related Lens 11 read concerns source
registry index 2708, not queue q2708, and carries no ordered-frontier credit.
None of these records grants another lens or reader source credit.

The q2701 historical summary preserves both
`frozen_named_scope_discovery_complete: false` and a later
`named_scope_discovery_complete: true`. Its separately hash-bound v2 proposal
says root adoption pending and no authority mutation; the current source
adoption condition is separate. Keep the summary and proposal as recorded,
with current reconciliation and global aliases open. q2904 is a separate
Lens 8 `bake/wire.rs` obligation; it does not establish the terrain-mask
lifecycle question. Ledger 201's load failure and ledger 1032/1033's blood
clock questions have distinct first operations from mask replacement.

The author and peer roles also remain distinct. `mhr_character` authored
q2913 and q2962; `wrapped_scope` independently reviewed them and previously
worked on related q2734 and q2957 scopes. `wrapped_scope` authored q2952;
`mhr_character` independently reviewed it. Preserve q2913's author
filename-only locator and preflight correction and the peer's corrected
metadata failure. Preserve q2962's author metadata/caller corrections separately
from the peer's unavailable-`python` retry and scratch-output creation without
per-file preflight. The q2952 author locator transcripts and report path
correction remain qualified in the source packets. The central process record
also retains its own earlier metadata failure and unsaved outer wrappers.

This reviewer had previously packaged process evidence containing q2913 and
q2962 intakes; custody supplied no independent source-read credit. For this
review, 35 product-source windows and three separately registered dependency
windows were personally displayed. The attached source map records exact
revisions, paths and ranges. Display is reviewer-attested, not independently
telemetered. Both dependency archives matched their pinned 95e lock checksums
and captured members; this does not prove resolved features or execution.

A filename-only intake listing occurred before its specific registration and
was cut by broken pipes; a 5a parent/tree metadata lookup preceded its own
verification registration. Their original tool output was not separately
saved. Neither event displayed source or grants read credit. Evidence-check
successors and the original reports are preserved. The restricted snapshot,
Git objects, archive bytes and original historical extraction remain
same-machine dependencies, not an independent backup or full Git closure.
SOURCE004, the 73 nontext/no-positive-EOF obligations and missing checkpoint
3821 remain open. No repair, product build, test, fixture or runtime probe was
performed, and no queue or ledger was edited.
