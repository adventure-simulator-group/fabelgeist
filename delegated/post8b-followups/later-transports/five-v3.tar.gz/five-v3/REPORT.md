# Independent review of the five-row assembly, proposal v3

Reviewer: /root/wrapped_scope. This is a bounded review of the unadopted
five-row proposal against its two exact central drafts, the post-8b snapshot,
and committed 8b evidence. I authored the q2545 and q3044 source assessments,
independently peer-reviewed q2561 and q2743 source, reviewed the q2744 central
drafts, and authored the related q2747 Lens 7 assessment. This review is
independent of the assembly, not of all underlying source or historical work;
no personal or lens credit transfers.

One factual attribution correction is needed. The q3044 credit says the peer's
37 views include "three historical assigned-file windows". The separately
attributed peer report says its three assigned-file views were at 6533, e275
and 95e: two historical revisions and the current revision. State "three
assigned-file views at 6533, e275 and 95e" or equivalent; the 37-view total
and reader do not change. This wording was already present in the prior central
draft and was exactly carried into v3. It does not change a defect count.

The five assessment summaries, source references, history, credit, open
questions and dispositions exactly preserve their corresponding draft fields.
All five selected 8b reconciliation entries remain unassessed. The four proposed
planning relationships exactly preserve the source draft queue and ledger
indices, directions and applicable historical-status qualification; their four
IDs are distinct and do not collide with existing 8b ledger IDs. This check
does not establish a global semantic alias inventory or decide policy.

The committed 8b reconciliation has 3,713 rows: 1,404 partial and 2,309
unassessed. Its ledger has 1,135 entries. If the five partial dispositions and
four planning links were later applied as proposed, arithmetic gives 1,409
partial, 2,304 unassessed and 1,139 ledger entries. Those are prospective
counts, not an installed state or evidence of repair, unique-defect increase,
queue closure or lens completion. The proposal remains unadopted. The captured
8ca and 8b evidence also confirms only queue rows 24, 185, 689 and 3100 changed
between those checkpoints and that the first 1,128 ledger entries match.

Each of the ten proposed source/peer paths resolves to a committed 8b object;
the observed working files matched those committed bytes at capture. Eight
archives and the two peer-report sibling packages were inspected as evidence:
their public manifests' declared file sizes and hashes match the retained
members. These paths and packet identities do not transfer source-read credit.
All 42 source references name existing 95e files and in-bounds line ranges
across 38 files; this is a byte/line-count check, not a semantic reread or proof
of product behavior.

All five selected original and reconstructed 059 row slices match exactly;
the complete streams differ. Their original status fields and the 8b wrapper
projections match the snapshot. The separate q2701 contextual original has no
status member, while its wrapper projects null. The source readers, historic
revisions, per-file identity and no-fresh-reread qualifications remain those
recorded in the source drafts; checkpoint 3821 remains unrecovered. The exact
original queue is separately held, as are other historical originals and the
Git objects needed for strongest replay.

The coordinator's process record preserves prior draft/report displays before
later assembly registration. This review also preserves two intentionally
bounded, tool-visible-only report metadata searches; complete report bytes
were captured and no product-source display or exhaustive-search claim follows.
The restricted packet contains exact input drafts, committed evidence blobs,
source/peer packages, selected historic records, registrations, Git witnesses
and process records. Public identities do not recreate separately held full
queues or establish independent custody. No central draft, queue, ledger,
publication or product file was changed; no product code, build, test, fixture,
shader or runtime probe was run.
