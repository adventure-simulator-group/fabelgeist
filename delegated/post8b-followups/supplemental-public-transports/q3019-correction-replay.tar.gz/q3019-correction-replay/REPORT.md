# Additive correction: q3019 bestiary target gate

The original q3019 Lens 5 report incorrectly says that `effective` requires a
positive direct target before summing. The exact source condition in
`crates/adventuresim-world-schema/src/bestiary.rs:224–240` returns zero when
`self.direct(category) <= 0.0`; otherwise it sums the individually normalized
contributions. A NaN target does not satisfy that comparison, so it can bypass
the early return. The contribution loop separately maps nonfinite direct values
to zero. Whether a nonfinite target reaches a particular supported boundary
remains an admission question, not a runtime result established here.

The finite illustrative example remains unchanged: the Beast target is 5,000,
so it does not satisfy the `<= 0.0` early-return condition; the three selected
finite 5,000-hour leaves and matrix weights yield approximately 10,250 hours by
static decimal arithmetic. The original `ASSESSMENT.json` phrase
“target-positive gate” describes that finite example and should not be read as
a general positive-target predicate. The prospective ledger's reference to a
target gate does not establish that the NaN bypass is intended policy or must
be preserved. The existing q3130 / ledger 444 record separately covers the
nonfinite-target admission and gate question; no new defect or count follows
from this wording correction.

`wrapped_scope` identified this distinction during a separately attributed
independent peer review. `final_guard_peer`, author of the original report,
re-displayed the previously registered 95e source window 221–242 and made this
additive correction. That re-display is not a new independent reader and is
reviewer-attested rather than independently telemetered. The original q3019
public and restricted packets, original pending status, 8b unassessed wrapper,
related ledger records, historical reader qualifications and all prior process
corrections remain unchanged. The original source reading and finite example
are not runtime validation. No product code, test, fixture, build, repair or
runtime probe was executed, and no queue or ledger was edited.

The strongest replay relies on same-machine Git objects and preserved source
and historical evidence; it is not independent backup, whole Git closure or
recovery of missing checkpoint 3821. Earlier SOURCE004, 73 nontext/no-positive-
EOF, reconstructed 440 and normalized 774 versus missing pre-export original
qualifications remain in force.
