# Independent q3019 Lens 5 peer review

The source supports the author's conditional aggregate example and the
separate simulation limit. One wording correction is needed: `effective`
returns zero when the target direct value compares `<= 0.0`; a NaN target does
not satisfy that comparison. The earlier q3130/ledger 444 record already
tracks that distinct nonfinite-target admission question. The reviewed example
uses a finite, positive Beast target, so this correction does not change it.

Reviewer `wrapped_scope` independently reviewed the q3019 source assessment by
`final_guard_peer`. The pinned source is
95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. The author packet remains sealed
and unchanged; this is an additive peer review, not an adopted queue or ledger
change, new defect count, repair or lens closure.

## Findings and conditions

`crates/adventuresim-world-schema/src/bestiary.rs:4–9` describes 5,000 hours
as a practical mastery ceiling and refers to correlated fields. The thirteen
public `f32` fields and their per-leaf finite/range predicate are at :154–185;
the effective calculation is at :224–241. For Beast, Werekin and Wildmen
leaves of 5,000 and all others zero, each leaf passes a 5,000-hour per-field
check, Beast is finite and positive, and the matrix/indexes at :88–112 give
coefficients 1.0, 0.70 and 0.35. Decimal arithmetic gives approximately 10,250
effective Beast hours; actual `f32` evaluation may round. The calculation
returns a one-pass sum without a final 5,000 clamp. This is a representable
source state, not an observed execution or proof of supported admission. If
the ceiling applies to the combined effective value, the per-leaf predicate
alone does not enforce it; if 5,000 instead describes a direct-field or curve
calibration limit, a higher correlated total need not be a defect. Policy and
actual producers remain open.

The source test at `bestiary.rs:272–330` includes that three-leaf construction
and asserts `>= 5,000`, not a strict greater-than outcome. It was read as text
only; no test or fixture ran. The selected isolated simulation's separate
per-field maximum is 1,000,000 hours (`simulation_security.rs:5–6`,
`simulation.rs:46–47,410–435`); the latter checks other skills and attributes
and then a later path updates the skills row at :448–463. Other gates, later
fallible work, supported complete input and transaction outcome are unproved.
The 1,000,000 simulation leaf bound is not the bestiary comment's 5,000.

The selected curriculum branch awards an individual category
(`strategic_schedule.rs:525–547`; `skill.rs:1059–1086`). The selected book
branch projects an effective value against a rank-derived ceiling
(`time/schedule.rs:564–581`; `book.rs:83–145`; `skill.rs:704–730`). The
selected tactical component reconstructs the aggregate and calls its
aggregate or category effective operations (`tactical-core/src/player.rs:
375–391,418,433–435`). These are bounded consumers, not a survey of all
admission, persistence, framework or gameplay paths; they do not decide a
universal 5,000-effective-hour rule.

## Relationships and attribution

At published checkpoint 8b, q3019 is unassessed. Original and reconstructed
059 selected objects match as parsed, while the complete streams differ. The
original 6533 registration requires `bestiary.rs:1–330` and records no Lens 5
assessed range. Root's recovered Lens 3 receipt records a fresh 6533 full-file
read; the e275 receipt records qualified same-lens reuse of 1–330 with no
fresh e275 personal read. The earlier Adler Lens 11 registration/read names
`pr-working` and source-registry index 2157 without a standalone Git revision
in the selected record. None grants this reviewer Lens 5 credit. The file has
the same blob at 6533, e275 and 95e, while those trees differ; this is per-file
identity, not whole-tree equivalence or a new historical read.

q3130/ledger 444 concerns nonfinite target admission and the direct-study
gate; q3130 has no original `status` key and its 8b wrapper is partial. Its
additional current Lens 5 label does not automatically complete q3019.
q2373/ledger 445 concerns category ownership and text selectors; the original
Lens 2 bestiary record includes inherited same-lens native attestation and
Root's fresh complement, not a full Root-personal read. q3016/ledger 1096
concerns provisional tactical flattening/reconstruction and remains unassessed
at 8b; the earlier delegate's type-ownership work does not supply Lens 1
credit. These relationships have different first operations and do not prove
aliases or a new count.

The peer reviewer authored the earlier q2545 Lens 3 assessment and separately
peer-reviewed `final_guard_peer`'s q2561 Lens 7 assessment; portions of the
present simulation, book and schedule support overlap those prior scopes. The
reviewer also authored q3044 Lens 6 and q3051 Lens 13 language assessments.
All current q3019 windows were separately registered and displayed; neither
prior work nor the q3019 author's 25 views is transferred as personal credit.
The author's five scope notes preserve their own process-only adjacent source,
two test-text views, same-reader overlap, capped metadata navigation, earlier
q2561 message-hash correction and q2545 truncated-view/rerender and builder
relocation. The author's missing `python` command and failed non-source glob
are retained as tool-visible-only reconstructions. The author packet's saved
25 display receipts and source bytes matched their registrations and pinned
Git objects; the original display remains reviewer-attested, not independently
telemetered.

The peer displayed 16 separately registered current windows, including the
bestiary test text. An additional formatting probe incidentally displayed only
`world-schema/src/lib.rs:230` from the author's process-only window; this was
not an exact preregistered peer window and is excluded from the peer's usable
coverage and findings. The first author-manifest verifier failed because it
omitted the manifest's explicit root-dot directory entry; a successor included
it and passed. Its original traceback was tool-visible only and is recorded as
a reconstruction. Adjacent religion, language, party and token-environment
name text in the registered support windows is context only; no credential
value was displayed and no other-family coverage is claimed.

The protected historical extraction was read without mutation. The original
full 059 stream, pinned Git objects and author packets are separately held
same-machine dependencies for strongest replay. Checkpoint 3821 remains
missing; SOURCE004, 73 nontext/no-positive-EOF obligations, reconstructed 440,
and the 774 normalized versus missing pre-export originals qualification
remain open or qualified. No product code, builds, tests, fixtures, macros,
runtime probes, repairs, queue or ledger updates were performed.
