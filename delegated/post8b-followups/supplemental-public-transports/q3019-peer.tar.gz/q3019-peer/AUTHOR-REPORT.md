# q3019: bestiary aggregate relationships, Lens 5

This is a bounded source assessment by `final_guard_peer`, not an adopted queue
or ledger update. It uses source revision
`95e63628f9d70b8dd6e6fede64334696c6995009` (tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`) and published queue checkpoint
`8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`, whose parent is
`8caeb2003d10d08320566206817aa0c694231778`. The selected original q3019 is
`own-lens-proof-qualification-or-read-pending`, has no assessed ranges and zero
body/population credit; its 8b wrapper says `unassessed`. The selected original
and reconstructed objects compare equal after parsing, although the complete
streams differ. This work is proposed evidence for central reconciliation; it
does not itself change that status or close the lens.

## Conditional aggregate question

`BestiaryHours` exposes thirteen direct `f32` fields. Its finite-bound predicate
checks the fields separately. Its `effective` method first requires a positive
direct target, then calculates a one-pass weighted sum of direct category values;
it does not impose a final 5,000-hour bound on that sum. The nearby constant
comment describes 5,000 hours as a practical ceiling for direct and transferred
study, including a statement about correlated fields. The meaning and intended
scope of that comment require a decision.

For a source-level example, set Beast, Werekin and Wildmen direct hours to 5,000
and all other categories to zero. Each leaf meets a 5,000-hour per-field
predicate and Beast passes the positive-target gate. The selected matrix
coefficients 1.0, 0.70 and 0.35 yield approximately 10,250 effective Beast
hours by decimal arithmetic; floating-point evaluation may round. This is a
representable aggregate relationship, not an observed runtime result. If a
5,000-hour ceiling applies to the combined effective value, the separate leaf
checks alone do not enforce it. If 5,000 is a calibration or direct-field cap
and correlated effective values may exceed it, this example establishes no
defect. The selected test source only asserts a value is at least 5,000; it was
read as text and was not executed, and does not by itself mandate a value above
5,000. An earlier current assessment cautions against inferring a blanket clamp.

The selected isolated simulation predicate uses a separate 1,000,000-hour
per-field ceiling and a later code path updates a skills row. Other validation,
full input reachability, later fallible operations and transaction behavior were
not established. The selected curriculum path passes an individual category to
an award helper; the selected book path evaluates a projected effective value
against a rank-based ceiling. These limited paths do not settle a universal
aggregate policy or establish ordinary gameplay admission. Selected downstream
consumers include effective and aggregate-effective uses and a tactical
reconstruction; all producers, consumers, framework representations and the
intended relationship remain open. See `SOURCE-MAP.json` for exact bounded
references and process-only exposures.

## Existing relationships and open work

- q3130 and ledger entry 444 cover a different first operation: nonfinite target
  admission and the direct-study gate. The 8b assessment also carries a current
  Lens 5 label; that label is preserved and does not automatically establish
  completion of q3019's exact obligation. Its original status field was absent;
  the 8b wrapper is partial.
- q2373 and ledger entry 445 concern category owner, selectors and text; q2373's
  original status is `open-connected-owner-current-alias-qualification` and
  its 8b wrapper is partial. A shared source is not a global alias.
- q3016 and planning relationship 1096 concern selected tactical flattening and
  reconstruction. q3016 originally remained own-lens pending and its wrapper is
  unassessed. The earlier delegate applied type ownership; that label does not
  confer Lens 1 evidence. Framework requirements and all supported paths remain
  open.

The connected repair ledger is a proposal only. Resolve the effective-hour
contract, admission and producer reach first; if a relationship is required,
trace all supported boundaries and consumers before choosing any change. No
repair, product test, runtime probe, or defect count is claimed here.

## Historical and recovery qualifications

The recovered 6533 record credits Root's Lens 3 reader with a fresh personal
read of the 330-line source. Its e275 counterpart records qualified same-lens
reuse with no fresh personal ranges; neither confers new Lens 5 credit. A
separate Adler Lens 11 record and registration identify `pr-working` and source
registry index 2157; the selected record does not state a standalone Git
revision, so none is assigned to it. The 6533, e275 and 95e versions have the
same selected file blob; their trees differ. File identity is not whole-tree
identity or proof of a fresh read. Six selected original historical records
were compared to 8b's compressed recovered records on the same machine; this is
not independent backup or recovery of checkpoint 3821.

The reviewer previously authored q2561 under Lens 7 and independently peer
reviewed q2545 under Lens 3; separately registered source windows here overlap
parts of those prior book/simulation views. This is reviewer overlap, not a new
independent reader or transferred lens credit. The q2561 delivery-hash message
correction, and q2545's initial truncated display, later complete rerender and
post-seal builder relocation with same-machine re-verification, remain separate
historical controls. The underlying source display is reviewer-attested, not
independently telemetered. Two selected test-source regions were read as text
only; no test or fixture was run. Adjacent unrelated content and the metadata
navigation limit are preserved in the restricted process record, without
coverage credit. Remaining baseline recovery limits, including missing 3821,
SOURCE004 and 73 nontext/no-positive-EOF obligations, are not resolved here.
