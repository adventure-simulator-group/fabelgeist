#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,subprocess
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();ap=argparse.ArgumentParser()
for n in ('repo','private-manifest','replay-manifest','original-stream-manifest','original-queue','extraction','author-public-manifest','author-private-manifest','q2545-manifest','q2561-peer-manifest','q3051-manifest'):ap.add_argument('--'+n,type=Path)
a=ap.parse_args();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q3019-l5-peer-public-v1' and {q.name for q in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
s=json.loads((p/'SOURCE.json').read_bytes());main=(p/'CURRENT-SOURCE.rs').read_bytes();assert s['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and h(main)==s['objects'][s['main_path']]['sha256'] and len(main.decode().splitlines())==330 and len(s['views'])==16
for v in s['views']:
 b=(p/v['name']).read_bytes();assert h(b)==v['sha256']
 if v['path']==s['main_path']:
  lo,hi=v['range'];lines=main.decode().splitlines();assert b==''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
sel=json.loads((p/'SELECTION.json').read_bytes());assert sel['index']==3019 and sel['original']['lens']==5 and sel['original']==sel['reconstructed'] and sel['selected_equal_as_parsed'] and not sel['full_streams_equal'] and sel['current']['current_reconciliation']=='unassessed';rel=json.loads((p/'RELATIONSHIPS.json').read_bytes());assert [rel['ledger_entries'][str(i)]['id'] for i in (444,445,1096)]==['REVIEW-L3-BESTIARY-EXPERIENCE-ADMISSION','REVIEW-L2-BESTIARY-CATEGORY-OWNER-95E','relationship-bestiary-hours-tactical-propagation-95e']
bind=json.loads((p/'BINDING.json').read_bytes());author=json.loads((p/'AUTHOR-MANIFEST.json').read_bytes());assert h((p/'AUTHOR-MANIFEST.json').read_bytes())==bind['author_public_manifest_sha256']
for src,n in [('REPORT.md','AUTHOR-REPORT.md'),('SOURCE-MAP.json','AUTHOR-SOURCE-MAP.json'),('ASSESSMENT.json','AUTHOR-ASSESSMENT.json'),('PROPOSED-LEDGER.json','AUTHOR-PROPOSED-LEDGER.json')]:assert h((p/n).read_bytes())==author['files'][src]['sha256']
r=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert len(r['checks'])==2 and all(x['exit']==0 and x['stderr_bytes']==0 for x in r['checks']);sealed=json.loads((p/'SEALED-CHECK.json').read_bytes());assert sealed['result']=='passed' and sealed['sealed_private_manifest_sha256']==bind['private_manifest_sha256'];history=json.loads((p/'HISTORY.json').read_bytes());checks=['public member identities, assigned source and 16 view hashes, related metadata and recorded corrected replay'];not_checked=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','postseal_replay_manifest_sha256'),('original_stream_manifest','original_stream_manifest_sha256'),('original_queue','original_queue_sha256'),('author_public_manifest','author_public_manifest_sha256'),('author_private_manifest','author_private_manifest_sha256')]:
 q=getattr(a,attr)
 if q is None:not_checked.append(attr+' not supplied')
 else:assert h(q.read_bytes())==bind[key];checks.append(attr+' identity')
for attr,key in [('q2545_manifest','Q2545-MANIFEST.json'),('q2561_peer_manifest','Q2561-PEER-MANIFEST.json'),('q3051_manifest','Q3051-MANIFEST.json')]:
 q=getattr(a,attr)
 if q is None:not_checked.append(attr+' not supplied')
 else:assert h(q.read_bytes())==bind['overlap_manifests'][key];checks.append(attr+' identity')
if a.extraction is None:not_checked.append('protected historical receipts not supplied')
else:
 for x in history['historical_records']:assert h((a.extraction/x['locator']).read_bytes())==x['sha256']
 checks.append('six historical record identities')
if a.repo is None:not_checked.append('Git source, support views and 8b ledger not supplied')
else:
 def git(*cmd):
  r=subprocess.run(['git','-C',str(a.repo),*cmd],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0 and not r.stderr;return r.stdout
 for z in s['main_historical_objects']:assert git('rev-parse',z['revision']+'^{tree}').decode().strip()==z['tree'] and git('rev-parse',z['revision']+':'+s['main_path']).decode().strip()==z['blob'] and git('show',z['revision']+':'+s['main_path'])==main
 cache={}
 for path,z in s['objects'].items():
  b=git('show',s['revision']+':'+path);assert git('rev-parse',s['revision']+':'+path).decode().strip()==z['blob'] and h(b)==z['sha256'] and len(b.decode().splitlines())==z['lines'];cache[path]=b.decode().splitlines()
 for v in s['views']:
  lo,hi=v['range'];lines=cache[v['path']];assert (p/v['name']).read_bytes()==''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 rev=rel['checkpoint'];recon=git('show',rev+':baseline-059/queue.json');wrap=git('show',rev+':RECONCILIATION-059.json');ledger=git('show',rev+':BASELINE-95E-20261110.json');assert h(recon)==sel['reconstructed_sha256'] and h(wrap)==sel['reconciliation_sha256'] and h(ledger)==rel['ledger_sha256'];assert json.loads(recon)['entries'][3019]==sel['reconstructed'] and json.loads(wrap)['entries'][3019]==sel['current'];entries=json.loads(ledger)['newly_assessed_ledger']['entries'];assert all(entries[int(k)]==v for k,v in rel['ledger_entries'].items());checks.append('three per-file identities, 16 current views and 8b queue/ledger')
if a.original_queue is not None:
 entries=json.loads(a.original_queue.read_bytes())['entries'];assert entries[3019]==sel['original']
 for k,v in rel['rows'].items():
  row=entries[int(k)];assert row['contract_id']==v['contract_id'] and ('status' in row)==v['original_status_present'] and row.get('status')==v['original_status']
 checks.append('original selected queue metadata')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence identities only, not independent display telemetry, supported reach, runtime behavior or independent custody. Full author-view replay requires separately held restricted anchors.'}))
