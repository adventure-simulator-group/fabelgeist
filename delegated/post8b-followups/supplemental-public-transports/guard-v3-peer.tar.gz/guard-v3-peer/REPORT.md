# Independent comparison of the prospective post-8b guard v3

The captured v3 templates address all six gaps in the earlier v1 static
review. Exact derivation comparisons and the captured receipt predicates pass.
This is a source-level evidence-tool review: the builder, driver and generated
guard were not run, and installation and publication are not established.

* `guard_v3/BUILD.py:9-10` rejects optimized assertions; its runner clears
  the optimization environment variable before launching it. The v3 privacy
  driver likewise rejects optimization, clears that variable for children, and
  passes `-B`, no-bytecode and no-user-site settings to each child.
* `privacy_v3/AFTER.py:24-29` skips exactly the earlier root guard and requires
  the replacement guard to be one regular, non-symlink inventory member. Its
  actual bytes still need independent installation and checkpoint anchoring.
* `guard_v3/VERIFY-TEMPLATE.py:57-66,91-106` checks exact pattern and corpus
  key sets and zero values for the first and second custody scans. It also
  checks the correction's predecessor manifest, equal restoration bytes, and
  equal scan data apart from schema. Independently evaluated captured receipts
  satisfy those checks; this is not a fresh scan or authenticated restoration.

The four v1-to-v2 and four v2-to-v3 guard scripts exactly match their recorded
literal substitutions; unchanged root and runner templates retain their byte
identities. The privacy driver follows its two recorded successor derivations
exactly. All four coordinator derivation records report child exit zero, with
outer tool envelopes not separately retained. They are attributed to the
coordinator, not to this reviewer.

The stage inventory will bind file bytes and Git owner-executable bits after the
pending index and other final stage artifacts are present. It does not establish
full filesystem modes or the root candidates' installation by itself. The
candidate, separately supplied 8b/8ca checkouts, deeper Git history, key,
prior nonce inventory, full privacy scan, installer and remote observation all
retain their own evidence and limitations. A recorded no-key ciphertext check
is not an authenticated restore or proof of independent custody.

This reviewer authored the earlier v1 template review, q2743 and q2744 source
assessments and a q2545 draft peer review. The v3 comparison is independent of
the successor construction; it does not transfer source or lens credit. The
64 registered source files matched their bytes and modes at the final recheck;
eight separately sealed receipt inputs matched their private manifest. No
product behavior, new defect count, checkpoint 3821 recovery or audit closure
is inferred.
