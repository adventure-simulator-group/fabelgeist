# Independent review of the post-8b candidate v2

The v2 evidence replay corrects the two bounded issues in the independently
reviewed v1 candidate. Within the checks below, no additional application issue
was identified. This is an evidence-tool review, not an installation or a
finding about product behavior.

The successor pins the sibling review-binding manifest by SHA-256 and checks
its exact three declared members, lengths and hashes before running its
verifier. When `--publication` is supplied, its own resolved package directory
must equal the expected v2 candidate directory under that publication. Its
member scan verifies the package before that comparison. A full installation
still needs a separate stage-to-index/worktree check and anchored public package.

In isolated evidence copies, both the ordinary baseline and a synthetic
in-place publication passed. Replacing the sibling verifier with a benign no-op
failed before that script ran. Executing an external copy while supplying a
synthetic publication failed at the resolved-directory check. A missing package
member failed at its member-set check. These five controls do not model all
filesystem races or prove that the candidate was installed.

The two packages have 17 and 18 files respectively. Of 17 shared paths, 15
are byte-identical: the proposal, transform, report, observation, bindings,
pins, README and all eight before/after images. Only `VERIFY.py` and the root
manifest differ; `CORRECTION.json` is the sole added file. A separate static
comparison reconstructed all three successor builder scripts from the v1
scripts using the literal substitutions in the recorded derivation. No builder
or transform was executed for that comparison. The v1 builder bytes were bound
to the earlier sealed independent-review manifest.

The coordinator's separately recorded predecessor replay reports a successful
8b check and nested 8ca predecessor guard, using same-machine checkouts and a
limited object alternate. Its saved child exit and streams were inspected; this
review did not independently rerun those checkouts. The log also states that
the deeper exact 76fe predecessor needs a clean checkout and historical Git
objects. Full object closure, independent custody and a saved outer tool
execution envelope are not established by that recorded replay.

The candidate and sibling package must be bound by the eventual checkpoint.
The installed stage, installer and all preserved raw connector observations
require their separately recorded checks. An observation is point-in-time
recorded evidence, not proof of remote origin or current state. Key availability,
prior ciphertexts and recovery dependencies remain separate custody questions.
No historical evidence is promoted to checkpoint 3821, no defect count or queue
closure is asserted, and no product source was executed or validated.

The reviewer authored the q2743 and q2744 source assessments, was a q2545
draft peer, and reviewed earlier v4-v6 transforms and the v1 candidate. This
review is independent of the v2 construction, but is not independent source
corroboration for those earlier assessments. All earlier readers and revision
claims retain their original attribution.

The first local comparison attempt failed because the v1 review manifest uses
an array where the candidate manifest uses a map. The exact failed command,
exit and stderr remain in restricted evidence; an additive corrected comparison
passed. The v2 builder and coordinator replay records retain their own child
streams and exits; their outer tool envelopes were not separately retained.
Registered inputs matched their captured bytes and source file modes at the end
of this review, with the four supplementary v1 inputs checked for bytes only.
This is a point-in-time comparison, not a claim about intervening writes.
