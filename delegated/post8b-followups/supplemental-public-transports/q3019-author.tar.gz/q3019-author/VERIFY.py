#!/usr/bin/env python3
from pathlib import Path
import hashlib, json
p=Path(__file__).resolve().parent
raw=(p/'MANIFEST.json').read_bytes(); m=json.loads(raw)
assert not p.is_symlink() and p.is_dir()
actual={x.name for x in p.iterdir()}
assert actual==set(m['files'])|{'MANIFEST.json'}
for name,row in m['files'].items():
    assert '/' not in name and '\\' not in name and name not in ('.','..')
    x=p/name; assert x.is_file() and not x.is_symlink()
    b=x.read_bytes(); assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print(json.dumps({'schema':'726-q3019-l5-public-verification-v1','manifest_sha256':hashlib.sha256(raw).hexdigest(),'files':len(m['files']),'result':'local public identity checks passed','qualification':'No key needed; no independent provenance, restricted evidence, source semantics or product validation is established.'},indent=2))
