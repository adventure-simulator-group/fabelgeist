# Static review of the prospective post-8b installation templates

The current installer template should not be treated as confined to the
intended evidence checkout. It accepts arbitrary publication and run paths,
resolves them, and creates the run directory and action log before checking
its pinned inputs or Git state. A different checkout with the same branch and
commit could meet the later checks. Resolving first also discards the original
final symlink identity. Bind both paths to designated real locations, reject
symlink or escape components before any output, and verify Git's top-level
worktree. The capture and scan runners likewise derive output locations from
their own file location without independently pinning that workspace.

The helpers inherit Git environment overrides, including worktree and Git
object-location settings. Thus a clean status and commit reported by Git need
not describe the directory later written unless the environment and Git
worktree identity are separately constrained. The status command checks
tracked and untracked changes; ignored paths outside the explicit destination
and temporary-file checks are not part of that status result.

The preinstall scan runner rejects an optimized parent, but passes its inherited
`PYTHONOPTIMIZE` value to fresh scanner children. The selected digest scanner
uses assertions without its own optimization guard. For example, an isolated
parent interpreter can ignore that variable while a child inherits it. Clear
the variable for children and retain no-bytecode/no-user-site settings. Both
selected scanners contain patterns for the two Windows path spellings; the
runner's positive controls exercise a matching regex, not the whole scanner.

The installer pins the supplied scan result and checks two child exits and
reported counts. It does not require the two expected scanner labels or bind
saved child stdout and stderr hashes to the corresponding files. Its connector
record is pinned and checked for expected branch/main response fields, but the
three times are only compared as strings; freshness, timestamp format and
connector origin need separately recorded verification or explicit policy.

The capture and installer Git helpers pipe both child streams, but do not save
successful stderr or failed child stdout/stderr. A wrapper traceback does not
reconstruct discarded Git output. Record the child exit and both exact streams
if those subprocesses are part of the required evidence.

The installation is sequential and nontransactional. Its success result
states that limitation, but an exception may leave partial changes without a
result file. Action records are emitted after the corresponding writes, so a
failure during a copy or before its record may leave effects not fully described
by the log. Preserve exact wrapper/child failures and capture a read-only
post-failure state; no automatic cleanup is implied.

The templates otherwise specify eight distinct root outputs: four updated
queue/ledger/progress documents, the privacy driver, root guard, assessment and
observation. Five have committed before-images; three must be absent. They
check expected parent commit, tree and branch, stage and root candidate hashes,
absent destination and replacement temps, and full file/directory modes in the
same-machine stage snapshot. Git commits preserve only the executable-bit
projection. The eventual stage index, fixed inputs, raw observation and scan
results were not yet captured or run in this review.

The reviewer authored q2743/q2744 source and previously reviewed the candidate
and guard templates. This is independent inspection of the unrun installer,
not independent source credit. A directory-name-only metadata locator was viewed
after the first registration without a separate prospective locator entry; it
provided no source-body credit and was not captured as a verbatim stream. The
six registered source files matched their captured bytes and file modes at the
final recheck. No product, scanner, capture, installer or connector was run;
no queue closure, publication or checkpoint 3821 recovery is inferred.
