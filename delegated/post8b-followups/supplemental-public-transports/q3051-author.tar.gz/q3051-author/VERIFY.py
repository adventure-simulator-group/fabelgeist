#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,subprocess,re
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();ap=argparse.ArgumentParser()
for n in ('repo','private-manifest','replay-manifest','original-stream-manifest','original-queue','private-report','extraction','q3044-manifest','peer-manifest'):ap.add_argument('--'+n,type=Path)
a=ap.parse_args();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q3051-l13-public-v1' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,z in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==z['bytes'] and h(b)==z['sha256']
s=json.loads((p/'SOURCE.json').read_bytes());main=(p/'CURRENT-SOURCE.rs').read_bytes();assert s['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and h(main)==s['objects'][s['main_path']]['sha256'] and len(main.decode().splitlines())==54 and len(s['views'])==21
for v in s['views']:
 b=(p/v['name']).read_bytes();assert h(b)==v['sha256']
 if v['path']==s['main_path']:
  lines=main.decode().splitlines();lo,hi=v['range'];assert b==''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
sel=json.loads((p/'SELECTION.json').read_bytes());assert sel['index']==3051 and sel['original']['lens']==13 and sel['original']==sel['reconstructed'] and sel['selected_equal_as_parsed'] and not sel['full_streams_equal'] and sel['current']['current_reconciliation']=='unassessed'
rel=json.loads((p/'RELATIONSHIPS.json').read_bytes());assert rel['ledger_entries']['450']['id']=='REVIEW-L3-INITIAL-LANGUAGE-PROFILE-WEIGHTS' and rel['ledger_entries']['1095']['id']=='relationship-language-profile-leaf-propagation-95e'
bind=json.loads((p/'BINDING.json').read_bytes());assert bind['preseal_replay_manifest_sha256']==bind['postseal_replay_manifest_sha256'];r=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert len(r['checks'])==2 and all(x['exit']==0 and x['stderr_bytes']==0 for x in r['checks']);proj=json.loads((p/'REPORT-PROJECTION.json').read_bytes());assert h((p/'REPORT.md').read_bytes())==proj['public_report_sha256'];hist=json.loads((p/'HISTORY.json').read_bytes())
checks=['public member identities, assigned source view, support-view hashes and recorded metadata/replay'];not_checked=[]
for attr,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','postseal_replay_manifest_sha256'),('original_stream_manifest','original_stream_manifest_sha256'),('original_queue','original_queue_sha256')]:
 q=getattr(a,attr)
 if q is None:not_checked.append(attr+' not supplied')
 else:assert h(q.read_bytes())==bind[key];checks.append(attr+' identity')
for attr,key in [('q3044_manifest','q3044_author_manifest_sha256'),('peer_manifest','q3044_peer_manifest_sha256')]:
 q=getattr(a,attr)
 if q is None:not_checked.append(attr+' not supplied')
 else:assert h(q.read_bytes())==hist[key];checks.append(attr+' identity')
if a.private_report is None:not_checked.append('private report projection not supplied')
else:
 raw=a.private_report.read_bytes();assert h(raw)==proj['private_report_sha256'];safe,n=re.subn(rb'/[^/\s`]+/(wrapped_scope|mhr_character)',rb'\1',raw);assert n==2 and safe==(p/'REPORT.md').read_bytes();checks.append('private report alias projection')
if a.extraction is None:not_checked.append('protected historical receipts not supplied')
else:
 for n,z in hist['historical_records'].items():assert h((a.extraction/'root-l3-extension-20261030'/n).read_bytes())==z['sha256']
 checks.append('four historical receipt identities')
if a.repo is None:not_checked.append('Git source, support views and 8b ledger not supplied')
else:
 def git(*cmd):
  r=subprocess.run(['git','-C',str(a.repo),*cmd],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0 and not r.stderr;return r.stdout
 for z in s['main_historical_objects']:
  assert git('rev-parse',z['revision']+'^{tree}').decode().strip()==z['tree'] and git('rev-parse',z['revision']+':'+s['main_path']).decode().strip()==z['blob'] and git('show',z['revision']+':'+s['main_path'])==main
 cache={}
 for path,z in s['objects'].items():
  b=git('show',s['revision']+':'+path);assert git('rev-parse',s['revision']+':'+path).decode().strip()==z['blob'] and h(b)==z['sha256'] and len(b.decode().splitlines())==z['lines'];cache[path]=b.decode().splitlines()
 for v in s['views']:
  lo,hi=v['range'];lines=cache[v['path']];assert (p/v['name']).read_bytes()==''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode()
 rev=rel['checkpoint'];recon=git('show',rev+':baseline-059/queue.json');wrap=git('show',rev+':RECONCILIATION-059.json');ledger=git('show',rev+':BASELINE-95E-20261110.json');assert h(recon)==sel['reconstructed_sha256'] and h(wrap)==sel['reconciliation_sha256'] and h(ledger)==rel['ledger_sha256'];assert json.loads(recon)['entries'][3051]==sel['reconstructed'] and json.loads(wrap)['entries'][3051]==sel['current'];entries=json.loads(ledger)['newly_assessed_ledger']['entries'];assert all(entries[int(k)]==v for k,v in rel['ledger_entries'].items());checks.append('three per-file identities, 21 current views, 8b queue wrapper and ledger')
if a.original_queue is not None:
 entries=json.loads(a.original_queue.read_bytes())['entries'];assert entries[3051]==sel['original']
 for k,v in rel['rows'].items():
  row=entries[int(k)];assert row['contract_id']==v['contract_id'] and ('status' in row)==v['original_status_present'] and row.get('status')==v['original_status']
 checks.append('original selected queue identities')
print(json.dumps({'checks':checks,'not_checked':not_checked,'qualification':'Evidence-only identities and source bytes; not independent custody, display telemetry, supported reach, runtime behavior, or global historical recovery.'}))
