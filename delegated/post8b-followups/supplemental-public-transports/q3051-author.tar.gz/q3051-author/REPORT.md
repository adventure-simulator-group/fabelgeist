# q3051: language initialization, Lens 13 raw primitives

The pinned source uses several distinct primitive roles. The existing profile,
oral-hours and written-hours records own their respective aggregates, while
individual profile leaves, hour values and the character key remain primitive
at this boundary. `UnitBasisPoints` and the strategic character-key wrapper are
relevant existing owners to evaluate; neither can simply replace all the raw
values without settling its actual admission, dependency and behavioral
contracts. The native sampler's `u64` weights and `usize` indices are real
operation boundaries. This bounded assessment identifies conditional policy
and propagation questions, not a proved reachable product defect, new count,
repair, or closure.

The independent reviewer is wrapped_scope. The product revision is
95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. The assigned
`crates/adventuresim-world-schema/src/language/initialization.rs:1–54` was
personally displayed after Lens 13 registration; EOF is 54. The enumerated
support windows and match-line locators were separately registered and
personally displayed. Other bytes captured with those Git objects prove
identity only. The display is the reviewer's attestation, not independently
signed telemetry.

## Occurrence and boundary inventory

* Lines 7–10 and 42–46 take `SettlementLanguageProfile`, a raw `u64`
  `character_id`, and a Boolean `npc`, and return oral/written hour owners.
  At 11–12 and 25–27 the key converts into the generic deterministic `Seed`
  and the streams receive an empty numeric context. `seed.rs:23–45,49–74,
  170–173` shows the seed role and `u64` conversion. The selected character
  insertion obtains its `npc` from `CharacterCreationMode::is_npc`, whose
  player, persistent NPC, temporary NPC and newborn cases are at
  `character.rs:1912–1934,2166–2181`; it passes id and flag at :2259–2260.
  A separate settlement reset forwards its Boolean at :2103–2126; the
  selected mission bootstrap passes `true` at `mission_bootstrap.rs:1292–1299`.
  The name-authority `CharacterId(u64)` is crate-private
  (`character/name_types.rs:55–77`), whereas the initializer is in the shared
  schema crate. Whether a common key owner or a narrower mode value is
  appropriate across these boundaries remains open; seed identity, gameplay
  identity and distinct tactical/strategic lifetimes are not equated.
* Lines 13–23 widen three `u16` basis-point leaves to native `u64` weights,
  sample a `usize` index, and use it with the correspondingly ordered three
  language variants. Each widening is lossless; three maximal `u16` values
  cannot overflow `u64`. `stream.rs:104–115` delegates weighted construction
  and sampling to the named native library, translating errors; the assigned
  code uses `expect`, so a returned error is a panic path in source. The
  external weighted sampler's full implementation and supported invalid
  ingress are not established by this review. The existing zero/default
  precondition question is already recorded as q3132/ledger 450, rather than
  counted anew.
* Lines 24–28 use `npc` to short-circuit the incidence draw; otherwise the
  primitive draw bound is the whole-unit constant 10,000 basis points and its
  result is compared with a `u16` incidence value widened to `usize`.
  `basis_points.rs:4–5` names the constant and `stream.rs:48–60,134–137`
  specifies the nonempty index and half-open draw operation. Zero incidence
  admits no hit under that documented interval. The profile's `is_valid`
  requires the three German weights to total 10,000 and incidence at most
  1,000 (`language.rs:495–512`); the initializer does not itself invoke it.
  Conditional on a direct call supplying `npc = true` and incidence at least
  10,000, every value in the documented draw interval passes the comparison.
  The selected importer checks validity and equality to geographic inference
  before its selected storage path (`world_import.rs:625–640,690–705`), but
  this does not establish all public constructors, deserialization, persisted
  state or supported callers. Whether invalid incidence is reachable or
  violates an intended public-API policy remains open.
* The profile fields at `language.rs:498–503` are raw `u16` leaves.
  `UnitBasisPoints` has a checked 0–10,000 constructor and authored transparent
  deserialization (`basis_points.rs:7–32`). It is a possible individual leaf,
  not enforcement of the aggregate sum or the narrower incidence limit.
  Serde/SATS expansion and all ingress paths were not examined or executed;
  q131 is a separate earlier wire-admission record and ledger 1095 separately
  records profile-leaf propagation.
* Lines 29–38 select and assign `f32` oral hours. The true branch computes
  `ORAL_FLUENCY_HOURS * max(YIDDISH_LOCAL_GERMAN_FLUENCY - correlation, 0.0)`;
  the other branch and Yiddish field use `ORAL_FLUENCY_HOURS`. The constants
  are 5,000 hours and a dimensionless 0.8, and selected correlations are
  authored in the table at `language.rs:14–15,110–134`. The `0.0` floor is a
  dimensionless nonnegative floor before multiplication, not a sentinel or an
  extra hour. `OralLanguageHours` contains the chosen numeric leaves and
  exposes `direct_mut` (`language.rs:138–175`); its later `effective` and
  `add_direct` operations are at :177–203. A scalar semantic owner or range
  policy requires separate evaluation, including native/wire and float
  rounding contracts; the aggregate itself does not prove all leaves admitted
  valid. The authored default oral and written records and defaulting at
  lines 29, 52 are separate modes: written literacy is not assigned by this
  initializer. No macro expansion or product behavior was executed.

The selected geographic producer calculates concrete profile leaves at
`language.rs:524–562`; the named importer supplies one admission path, not a
proof that every supported profile comes from it. The entire selected file was
inventoried; support constants, enum discriminants, other source and tests were
read only where registered to explain these occurrences, not independently
assigned a full Lens 13 assessment.

## Historical relationships and recovery

Original 059 q3051 is `OBLIGATION-ROOT-L3-EXT-0028-LENS-13`, with 6533
required lines 1–54, no assessed Lens 13 range, and an e275 same-range revisit.
The selected reconstructed object matches the original as parsed; the full
original and reconstructed streams differ. The 8b wrapper was unassessed at
`8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. This packet is later review,
not a queue or ledger update.

The recovered Root Lens 3 6533 receipt is a fresh personal full 1–54 read;
the e275 receipt is qualified same-lens 1–54 reuse, not a fresh e275 read.
Its general mixed-attribution wording is narrowed by this selected prior row:
fresh 1–54 with no inherited portion. Those records grant no Lens 13 credit.
The 6533, e275 and 95e file is one Git blob
`a190e0fa176474e088a8e002af8671788e76bf33`, SHA-256
`87ffb9656350a955c7a86f75ec43181d59b5a891053f3938da81e8eb5f82d593`;
their trees differ. This is per-file identity, not whole-tree equivalence or a
new personal historical read. No evidence is promoted to the unrecovered
checkpoint 3821.

The earlier q3044 Lens 6 source assessment was authored by this reviewer and
independently peer-reviewed by mhr_character; it addresses existing
owner placement and a conditional shared-character-key question, without
transferring read credit here. The peer personally displayed the assigned file
at two historical revisions and 95e, plus its own support; that three-revision
sequence must not be described as three historical views. q3040/ledger 1095
records profile-leaf producer propagation, while q3132/ledger 450 records the
zero/default weighted-profile question. q2374 is the separate prior Lens 2
owner complement, and q131 the separate earlier basis-point wire admission
question. Their first operations, status and attributions remain distinct;
none is automatically an alias of the incidence-policy question. A finite
exact-path search of 1,768 JSON files in one earlier `parallel-l13` collection
found no match; it cannot establish absence elsewhere or supply read credit.

The current support view `stream.rs:140–150` incidentally included part of a
`#[cfg(test)]` module; it was source text only and no test ran. Some displayed
support windows also contain adjacent non-scope fields; those are not new
assessment credit. The first metadata helper failed twice because `python`
was unavailable, before source display; the registered successor used
`python3`. A later prior-packet filename lookup failed, and a filename-only
preview stopped at 80 names with broken-pipe diagnostics; both are
reconstructed from tool-visible output, not independent transcripts. The
registered successor search and all credited current source windows completed
without output truncation.

The protected extracted evidence remained read-only. SOURCE004, the 73
nontext/no-positive-EOF obligations, reconstructed 440, the 774 normalized
versus missing pre-export originals qualification, and missing 3821 remain
open or qualified as recorded. Full anchored replay needs the separately held
original 059 stream, protected extraction, Git objects and prior reports; this
packet and its public projection do not create an independent backup of those
dependencies. No product code, builds, tests, fixtures, macros, runtime probes,
repairs, queue changes or ledger changes were performed.
