# Independent review of the prospective post-8b guard

The unrun v1 templates have several evidence-verification gaps. None of the
captured scan records showed a hit. The coordinator has stated that later
successors will address these gaps; those successors are outside this review.
No guard was generated or installed.

* `guard_builder/BUILD.py:13-38` uses assertions for stage prerequisites and
  its before/after inventory comparison, without rejecting optimized Python.
  Its `RUN.py:10-11` inherits `PYTHONOPTIMIZE`. The privacy driver also uses
  assertions for its plan checks without an optimization guard, and passes the
  inherited environment to child verifiers. The two guard templates themselves
  do reject optimization and clear that variable for their children.
* `privacy_driver/AFTER.py:26-38` launches fresh interpreters without `-B` or
  an explicit no-bytecode environment. A no-bytecode flag on the parent alone
  does not propagate to those children. This is a possible evidence-tree write;
  no specific child cache creation was executed or established here.
* The driver excludes the old root guard by exact basename but discovers the
  replacement through a glob, without requiring it to exist. If absent, the
  replacement guard need not run even though the driver prints its general
  success message. Its bytes also need separate checkpoint/installer anchoring.
* `guard_builder/VERIFY-TEMPLATE.py:82-84` checks controls, omissions and
  selected digest-hit fields in both second-custody scan receipts, but does not
  assert the nine `pattern_counts` values. The captured values are all zero.
  The first-custody receipt verifier similarly checks its total and positive
  controls without cross-checking the component pattern and corpus fields;
  all captured components were zero.
* The stage guard inventories both second-custody receipt generations but
  does not assert the v2 correction's binding to v1. Independently, the
  captured correction names the v1 manifest's actual hash, the restoration
  records match byte for byte, and scan values differ only by schema.

The builder inventories all regular stage files present before adding the
checkpoint guard, with their hashes, sizes and owner-executable bits. The guard
checks the resulting file set and the exact two guard members; the prospective
root guard pins the generated guard's bytes. Empty directory structure and full
POSIX modes are outside that inventory. Root candidates, the generated guard,
the eventual stage, and installation must still be captured and anchored
independently; a hash chain is meaningful only once its root is trusted.

The saved original privacy driver matches the object at the stated 8b Git
commit. Its successor is exactly two declared substitutions: skip the earlier
root guard and print the separately supplied predecessor route. With both
arguments supplied, the prospective guard forwards the 8b checkout and 8ca
checkout through candidate v2 to the older guard. Without them, the older exact
replay is skipped. Deeper history, the saved same-machine 8b/8ca replay and its
separately retained limitations are not independently re-executed here.

The no-key ciphertext verifiers check stored bytes and within-group nonce
uniqueness. They do not authenticate without the key or compare the earlier
nonce inventory unless it is supplied. The stage template checks receipt bytes
and the Git owner-executable bit, while treating full-mode restoration and
source comparisons as recorded claims. Independent custody, full historical
Git closure and fresh connector observations remain separate.

The registered stage-root `INDEX.md` lookup found it absent; the coordinator
confirmed it is intentionally pending the final custody cutoff. It is a builder
prerequisite, not a completed index, and no draft was treated as installed. All
36 captured, registered source files matched their captured bytes and file
modes at the final recheck. The original privacy derivation recorded its child
streams and exit; its outer tool envelope was not separately saved.

The reviewer authored q2743 and q2744 source assessments, was a q2545 draft
peer, and reviewed earlier transforms and the candidate v1/v2. This independent
template review transfers no underlying source credit, makes no new defect
count, does not recover checkpoint 3821, and does not establish product
behavior, installation, publication, privacy completeness or audit closure.
