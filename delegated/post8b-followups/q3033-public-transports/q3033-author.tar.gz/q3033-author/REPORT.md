# q3033: bounded language authority review

Reviewer: `final_guard_peer`. This is a new Lens 7 assessment at product
revision `95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. Queue and ledger status is from
published checkpoint `8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. The selected
trace does not complete q3033's full-file obligation or the lens.

## Selected result

In `crates/adventuresim-world-schema/src/language.rs:27–51,110–135` and
`:340–370,417–428`, the oral and written enums, separately authored `ALL`
lists and index matches have complete coverage: the selected lists contain
all eight oral and seven written variants once, with distinct in-range
indices; the matrices have corresponding dimensions. This is a static source
observation, not proof of the intended matrix values or a claim that the two
different matrices express the same learning policy.

There is a conditional authority-maintenance question. A later edit could
duplicate one list entry and omit another while preserving its fixed length;
the selected `direct_fields_valid` and `effective` iterations would then skip
the omitted language (`:177–193,466–481`), and the selected skills presentation
would likewise omit it (`crates/strategic-web/src/templates/settlement/character_skills.rs:386–421`).
Separately, an index collision could make party top slots share a position; a
matrix or index change that misstates the meaning of a position could alter a
selected correlation lookup (`language.rs:123–135,256–305,417–428`). The `ALL`
iteration order is not itself required to equal the index order for these
lookups; the relevant questions are coverage, unique in-range indices and the
authored meaning of matrix positions. These are possible future divergences,
not a demonstrated current mismatch, supported incident or new defect count.

The selected typed written-language book-icon consumer reads the enum's
descriptor to render its English label, monogram and visual style
(`crates/strategic-web/src/templates/components.rs:163–179`). Some monograms
are shared by different languages, but this inspected consumer obtains the
descriptor from the typed language; the selected trace does not show the
monogram being used to recover identity. Other descriptor consumers and their
semantics remain open. Oral and written categories and correlation policies
may have different meanings and should not be collapsed merely because some
presentation strings match.

The next reconciliation should establish whether the separately authored
enumeration and coordinate representations need a single maintained owner or
an explicit consistency contract, while preserving supported ordering, tie
rules, correlation meanings and presentation behavior. Any future repair and
acceptance work requires separate authorization and the remaining consumers
and supported boundaries; none was started here.

## Historical and ledger relationships

Original 059 q3033 is `OBLIGATION-ROOT-L3-EXT-0027-LENS-07`, status
`own-lens-proof-qualification-or-read-pending`, requiring historical
`language.rs:1–756` with empty own-Lens 7 assessed ranges. Its selected
reconstructed object matches as parsed; the full original and reconstructed
streams differ. The 8b wrapper remains `unassessed`.

The earlier Root Lens 3 partial record listed `1–756` as unread; the later
6533 receipt records Root's fresh full-range Lens 3 read. The e275 Lens 3
record describes qualified reuse of that adopted prior receipt, with no fresh
e275 personal read. A separate Adler Lens 11 receipt records `1–756` as fresh
and describes an earlier-range/newly registered-range union. These are
historical records with their original attribution; none transfers Lens 7
credit. The file has the same Git blob at 6533, e275 and 95e, while the three
trees differ. This review captured the historical files for identity and
inspected their records; it did not personally display historical source
bodies.

Original q2374 is a partially reconciled language-owner question. Original
q3131 and ledger 452 concern the separate duplicate-speaker-ID operation in
party selection, while ledger 451 concerns a nonfinite written-language gate.
Original q3132 and ledger 450 concern the separate initialization weight
precondition; q3040 and ledger 1095 concern profile-leaf propagation. These
connections do not establish aliases, supported reach or a count change.

This reviewer previously peer-reviewed q3051 under Lens 13 and had registered
overlapping `language.rs:1–20,110–203` support for that different question.
The present displays were newly registered for Lens 7; no earlier or other
reviewer's source credit is transferred. `mhr_character` reported earlier
character-skills work; that work remains separately attributed.

## Evidence and limits

The seven personal current-source windows cover `language.rs:1–306,340–497`
and the two selected presentation windows above. They were registered before
display and are reviewer-attested, not independently telemetered. The
presentation windows include neighboring, incomplete source: the unrelated
religion, bestiary and terrain book-target arms and other surrounding fields
are process-only exposure, with no additional assessment or source credit.
The symbol locator recorded matching paths and line numbers only, including
some test-source locations; it did not display those test bodies. No product
code, tests, fixtures, builds, repairs or runtime probes were executed.

The source objects, original queue, old extraction and Git object store are
same-machine dependencies. Missing checkpoint 3821, SOURCE004, 73
nontext/no-positive-EOF items, reconstructed 440 qualifications and the
normalized 774 versus missing pre-export originals remain open. Two failed
filename lookups are preserved as reconstructed tool-visible process notes.
No queue or ledger edit, independent backup, product validation or broader
audit closure is claimed.
