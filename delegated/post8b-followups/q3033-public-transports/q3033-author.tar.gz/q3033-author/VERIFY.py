from pathlib import Path, PurePosixPath
import hashlib
import json

p=Path(__file__).resolve().parent
h=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((p/'MANIFEST.json').read_bytes())
assert m['schema']=='726-q3033-l7-public-manifest-v1'
assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,x in m['files'].items():
 assert len(PurePosixPath(n).parts)==1
 f=p/n;assert f.is_file() and not f.is_symlink();raw=f.read_bytes()
 assert len(raw)==x['bytes'] and h(raw)==x['sha256']
b=json.loads((p/'BINDING.json').read_bytes());s=json.loads((p/'SOURCE-MAP.json').read_bytes())
assert b['queue_index']==3033 and b['lens']==7 and b['wrapper_status']=='unassessed'
assert b['prior_q3051_peer_public_manifest_sha256']=='6ef1e7bd8f294c915c8d4a10bab298a2d3bbec2dbc3b64a2c3902aca3af4e4e4'
assert len(s['registered_windows'])==7 and s['unassessed_by_this_lens7_display']==[[307,339],[498,756]]
print(json.dumps({'public_members':len(m['files']),'registered_windows':7,'result':'passed','qualification':'Public file identity and stated scope only; no source correctness, personal-display telemetry, product behavior or independent custody.'}))
