#!/usr/bin/env python3
"""Read-only Git-tree inclusion, source-display and static mapping check."""
import hashlib,json,re,sys
from pathlib import Path
if sys.flags.optimize:raise SystemExit('unoptimized interpreter required')
r=Path(__file__).resolve().parent/'source';load=lambda p:json.loads(p.read_bytes());h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda kind,b:hashlib.sha1((kind+' '+str(len(b))+'\0').encode()+b).hexdigest();proof=load(r/'PROOF.json')
assert proof['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and proof['trusted_root_tree']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f'
def entries(raw):
 i=0;out={}
 while i<len(raw):
  sp=raw.index(b' ',i);nul=raw.index(b'\0',sp);name=raw[sp+1:nul].decode();value=raw[nul+1:nul+21];assert len(value)==20 and name not in out;out[name]=(raw[i:sp].decode(),value.hex());i=nul+21
 assert i==len(raw);return out
source={};used=set()
for row in proof['sources']:
 cur=proof['trusted_root_tree'];parts=row['path'].split('/')
 for i,part in enumerate(parts):
  tree=(r/'trees'/(cur+'.tree')).read_bytes();assert oid('tree',tree)==cur;used.add(cur);mode,cur=entries(tree)[part]
  if i<len(parts)-1:assert mode in ('40000','040000')
  else:assert mode in ('100644','100755')
 data=(r/row['archived_source']).read_bytes();assert (len(data),h(data),oid('blob',data),mode)==(row['bytes'],row['sha256'],row['git_blob'],row['git_mode']) and cur==row['git_blob'];assert row['path'] not in source;source[row['path']]=data
assert len(source)==7 and used==set(proof['tree_objects'])
def display(raw,start,end):
 lines=raw.decode().splitlines();assert 1<=start<=end<=len(lines);return ''.join(f'{i:6}\t{lines[i-1]}\n' for i in range(start,end+1)).encode()
primary=load(r/'PRIMARY-READ.json');data=source[primary['source']];assert h(data)==primary['source_sha256'] and len(data.splitlines())==primary['actual_eof']==330
for x in primary['displays']:
 b=(r/'reads'/f"primary-display-{x['start']:03d}-{x['end']:03d}.txt").read_bytes();assert b==display(data,x['start'],x['end']) and h(b)==x['display_sha256']
support=load(r/'SUPPORT-READ.json')
for x in support['windows']:
 b=(r/'reads'/(x['label']+f"-{x['start']:04d}-{x['end']:04d}.txt")).read_bytes();raw=source[x['path']];assert h(raw)==x['source_sha256'] and len(raw.splitlines())==x['source_eof'] and b==display(raw,x['start'],x['end']) and h(b)==x['display_sha256']
for label,c in support['coverage'].items():
 seen={i for x in support['windows'] if x['label']==label for i in range(x['start'],x['end']+1)};unread={i for a,b in c['unread_ranges'] for i in range(a,b+1)};assert not seen&unread and seen|unread==set(range(1,c['eof']+1)) and len(seen)==c['unique_personally_displayed_lines']
t=data.decode();v=source['crates/adventuresim-core/src/organization_catalog_validation.rs'].decode();ids=re.findall(r'Self::(\w+)\s*=>\s*"([^"]+)"',t.split("pub const fn id(self) -> &'static str {",1)[1].split('pub const fn label',1)[0]);allowed=re.findall(r'"([^"]+)"',v.split('const BESTIARY: &[&str] = &[',1)[1].split('];',1)[0]);read=dict(re.findall(r'BestiaryCategory::(\w+)\s*=>\s*self\.(\w+)',t.split('pub fn direct(self, category: BestiaryCategory)',1)[1].split('pub fn direct_mut',1)[0]));write=dict(re.findall(r'BestiaryCategory::(\w+)\s*=>\s*&mut self\.(\w+)',t.split('pub fn direct_mut(&mut self, category: BestiaryCategory)',1)[1].split('pub fn effective',1)[0]));cmp=load(r/'AUTHORITY-COMPARISON.json');assert [v for k,v in ids]==allowed==cmp['category_ids'] and len(ids)==13 and read==write and len(read)==13
print(json.dumps({'source_files':len(source),'tree_objects':len(used),'primary_windows':len(primary['displays']),'support_windows':len(support['windows']),'static_authority_matches':True,'qualification':'Tree inclusion assumes the stated root; commit-to-tree anchoring, personal reading, policy, reach, product behavior and independent custody are separate.'}))
