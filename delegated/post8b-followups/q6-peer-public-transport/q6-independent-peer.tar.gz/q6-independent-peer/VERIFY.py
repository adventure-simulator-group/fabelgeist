import argparse,hashlib,json,pathlib,re,subprocess
p=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def load(n):return json.loads((p/n).read_bytes())
def raw_entry(data,index):
 s=data.decode();m=re.search(r'"entries"\s*:\s*\[',s);assert m;pos=m.end();d=json.JSONDecoder()
 for i in range(index+1):
  while s[pos] in ' \t\r\n,':pos+=1
  start=pos;v,pos=d.raw_decode(s,pos)
 return v,s[start:pos].encode()
def manifest(d,name,digest):
 d=pathlib.Path(d);b=(d/name).read_bytes();assert H(b)==digest;m=json.loads(b);files={str(v.relative_to(d)) for v in d.rglob('*') if v.is_file() and not v.is_symlink()};assert files==set(m['files'])|{name};assert not any(v.is_symlink() for v in d.rglob('*'))
 for n,x in m['files'].items():
  b=(d/n).read_bytes();assert H(b)==x['sha256'] and len(b)==x['bytes']
 return len(m['files'])
a=argparse.ArgumentParser();a.add_argument('--repo');a.add_argument('--extraction');a.add_argument('--original');a.add_argument('--private-manifest');a.add_argument('--private-replay-manifest');a.add_argument('--author-private-manifest');a.add_argument('--author-public');a.add_argument('--delivery');z=a.parse_args()
m=load('MANIFEST.json');files={x.name for x in p.iterdir() if x.is_file() and not x.is_symlink()};assert files==set(m['files'])|{'MANIFEST.json'} and not any(x.is_symlink() or not x.is_file() for x in p.iterdir())
for n,x in m['files'].items():
 b=(p/n).read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
s=load('SOURCE.json');h=load('HISTORY.json');bind=load('BINDING.json');assert len(s['views'])==19 and len(s['objects'])==14
for v in s['views']:assert H((p/v['output']).read_bytes())==v['sha256'] and len((p/v['output']).read_bytes())==v['bytes']
assert h['original_q6']['status']=='open-reconciliation' and h['checkpoint_q6']=='unassessed' and h['selected_raw_equal'] and not h['complete_streams_equal']
assert H((p/'AUTHOR-REPORT.md').read_bytes())=='7876d80043b6193ec7d30eac1b0900a9dd733e0e63147170c64ca82a28233c5b' and H((p/'DELIVERY-CORRECTION.json').read_bytes())=='1e5c2e71560df20f69f80218bbe1a4d039aa2e6d2a798e227eacc2756a810d5f'
print('PASS public file identities, source-view bytes, selected history and author correction')
if z.repo:
 def git(*x):return subprocess.check_output(['git','-C',z.repo,*x],stderr=subprocess.PIPE)
 cp='8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b';assert git('rev-parse',cp+'^{tree}').decode().strip()=='552bb7853c70fea3c124eb0096d53e3e99b9439a';src={}
 for o in s['objects']:
  b=git('show',o['revision']+':'+o['path']);assert H(b)==o['sha256'] and len(b)==o['bytes'] and len(b.splitlines())==o['lines'];assert git('rev-parse',o['revision']+':'+o['path']).decode().strip()==o['blob_oid'];assert git('rev-parse',o['revision']+'^{tree}').decode().strip()==o['tree_oid'];src[(o['revision'],o['path'])]=b
 for v in s['views']:
  lines=src[(v['revision'],v['path'])].splitlines(keepends=True);b=b''.join((str(i).rjust(5)+' ').encode()+lines[i-1] for i in range(v['start'],v['end']+1));assert b==(p/v['output']).read_bytes()
 rec=json.loads(git('show',cp+':RECONCILIATION-059.json'));led=json.loads(git('show',cp+':BASELINE-95E-20261110.json'));assert rec['entries'][6]['current_reconciliation']=='unassessed';assert led['newly_assessed_ledger']['entries'][8]['id']=='REVIEW-INVENTORY-GRANT-ERROR-ERASURE-001';assert led['newly_assessed_ledger']['entries'][109]['id']=='SEGOVB-L12-INVENTORY-GRANT-ERROR-ERASURE'
 q=git('show',cp+':baseline-059/queue.json');assert H(q)==h['reconstructed_stream_sha256'] and H(raw_entry(q,6)[1])==h['selected_q6_raw_sha256']
 for x in h['related_assessments']:assert H(git('show',cp+':'+x['path']))==x['sha256']
 print('PASS optional Git source windows, file/tree identities, 8b queue, ledger identifiers and related report hashes')
else:print('SKIP Git source and 8b bindings: --repo not supplied')
def orig(data):assert H(data)==h['original_stream_sha256'] and H(raw_entry(data,6)[1])==h['selected_q6_raw_sha256']
if z.original:orig(pathlib.Path(z.original).read_bytes());print('PASS optional original queue stream and q6 raw slice')
else:print('SKIP original queue stream: --original not supplied')
if z.extraction:
 d=pathlib.Path(z.extraction);orig((d/'workflow-20261030/CLOSURE-QUEUE-100.json').read_bytes())
 for x in h['historical_documents']:
  b=(d/'evidence/continuation-segovb/audit-resume-20261027/lens08'/x['name']).read_bytes();assert H(b)==x['sha256'] and len(b)==x['bytes']
 print('PASS optional protected original queue and selected historical document identities')
else:print('SKIP protected original and historical documents: --extraction not supplied')
for val,label,key in [(z.private_manifest,'private manifest','private_manifest_sha256'),(z.private_replay_manifest,'private replay manifest','private_replay_manifest_sha256'),(z.author_private_manifest,'author private manifest','author_private_manifest_sha256')]:
 if val:assert H(pathlib.Path(val).read_bytes())==bind[key];print('PASS optional',label,'identity only; contents not rechecked')
 else:print('SKIP',label,'identity')
if z.author_public:print('PASS optional author public manifest and',manifest(z.author_public,'MANIFEST.json',bind['author_public_manifest_sha256']),'members')
else:print('SKIP author public anchor')
if z.delivery:print('PASS optional postseal delivery manifest and',manifest(z.delivery,'PRIVATE-MANIFEST.json',bind['delivery_manifest_sha256']),'members; modes not checked')
else:print('SKIP delivery anchor')
