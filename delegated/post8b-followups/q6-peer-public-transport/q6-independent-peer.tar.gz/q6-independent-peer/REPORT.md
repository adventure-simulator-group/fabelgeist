# Independent q6 Lens 8 peer review

The selected source supports the author's conditional error-erasure finding
and the later correction to its delivery wording. The existing-mission branch
needs an additional source-order qualification. This is a bounded peer review,
not a new defect count, an alias determination, or an adopted assessment.

The product-source authority is commit
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The author is `final_guard_peer`;
this independent peer is `wrapped_scope`. My 19 source views were registered
before display. My earlier q0 peer covered retained fit and item identity; it
is separate and did not supply q6 reading credit.

## Current conditional paths

- `crates/adventuresim-stdb-module/src/strategic/mission_bootstrap.rs:498–515`
  first authorizes and parses the fixture; an existing request or server causes
  an early return at :516–529. The selected route reaches configuration at :635–642
  only if earlier steps succeed. `crates/adventuresim-core/src/tactical_fixture.rs:16–29,49–56`
  distinguishes derived deserialization from the parser's explicit validation.
- The fixture helper at
  `crates/adventuresim-stdb-module/src/strategic/tactical_enemy_fixture.rs:9–43`
  checks roster cardinality, updates a name, replaces the loadout and then,
  only when requested, equips basic clothing. Its roster comes from
  `crates/adventuresim-stdb-module/src/world_actor.rs:320–347`; ties and broader
  membership guarantees remain open.
- At `crates/adventuresim-stdb-module/src/character.rs:3237–3266`, replacement
  first looks for a matching inventory row not already selected. If none is
  eligible, it calls the quantity-one grant wrapper and turns `None` into the
  loadout error. The checked helper and wrapper at
  `crates/adventuresim-stdb-module/src/item.rs:351–408,429–437` show the
  checked cause discarded by `.ok().flatten()` before that generic error.
- Basic clothing is a distinct branch: after successful loadout replacement
  and when requested, `character.rs:3195–3230` directly calls the same grant
  wrapper for each clothing item; it does not first perform the matching-row
  selection. If that wrapper yields `None`, the starting-item helper returns a
  different generic error. The author's postseal delivery correction is
  supported; no claim is made that a specific failure is reachable from
  supported fixture and catalog inputs.

The helper updates names and unequips roots before later fallible operations.
The reducer also performs source-visible work before configuration. That order
alone neither establishes committed partial state nor settles rollback. At
`mission_bootstrap.rs:716–723`, an existing mission is reused; capture and
insertion of a new snapshot occur only in the other branch. The request insert
at :752–783 is later still and is conditional on execution reaching it after
intervening fallible work. This narrows the report's shorthand that the
snapshot and request are created after configuration; it does not change the
error-erasure finding. The author agreed to record this additively.

## Historical evidence and current relationships

The recovered q6 original is `CONT08-P16-FIXTURE-ERROR-ERASURE`, historical
Lens 8 and `open-reconciliation`. Its selected 059 original and reconstructed
queue rows match byte for byte, while those complete queue streams differ. The
8b reconciliation wrapper is a separate object and remains `unassessed`.

The original completion receipt compares historical base
`a120390947c89b703dc74c4255a13c035d054c50` and head
`039329518e264f19206cf5b0b98d177433f40c17`. It reports source accounting with
findings while currentness, exact alias, repair and validation remain pending.
The selected receipt does not independently identify a personal reader; retain
its collection attribution without transferring reader credit.

The same 43-line fixture helper is byte-identical at base, head and current,
and uses direct `?` at lines 37 and 39. The completion receipt instead says a
per-enemy `map_err(format!(...))` was used. At the historical head,
`character.rs:3243–3297` returns `StrategicOperationResult`, while the helper
returns `Result<(), String>`; `operation_error.rs:10–44` is the inspected
error owner. The bounded source inspection does not establish the conversion
or compilation context and does not claim a build failure.

The current item file equals the historical base file byte for byte. The
current `character.rs:3218–3269` bytes equal historical base :3240–3291. At
head, `item.rs:351–408` returns the typed result and propagates the checked
failure, and `character.rs:3262–3283` propagates that result in the loadout
path. The head also propagates food capability refresh rather than discarding
it; no food fixture reach is inferred. Whole-file identity in this paragraph
is per file, not equality of the three trees.

Registration 039 used a reversed base range and an addition-only delta; its
successor 040 rejected it and 041 compared the actual checked helper. None of
that invalid range supplies reading credit or a closure claim.

8b ledger 8 (`REVIEW-INVENTORY-GRANT-ERROR-ERASURE-001`) and 109
(`SEGOVB-L12-INVENTORY-GRANT-ERROR-ERASURE`) already describe the related
wrapper and a separately conditional generic-inventory caller that ignores
absence and can return success. Here, the selected fixture branches instead
return generic errors. Their different first operations and outcomes remain
separate; neither alias nor a new unique count follows. Ledger 378/379 concerns
fixture admission and count conversion; planning link 1134 also relates q1688,
q3100 and q3134, the last a separate zero-grace enrollment question. These are
contextual dependencies, not interchangeable defects.

Open questions include supported fixture/item-catalog routes to a checked
failure, native transaction semantics, equal-ordinal roster ordering, the
historical conversion discrepancy and the intended boundary for retaining
error context. No repair, product build, test, fixture execution, runtime probe
or product validation was performed.

## Recovery and process qualifications

Ten named historical records were compared byte for byte with the read-only
extraction; the 039 reversed range and 040/041 corrections are retained. The
author's initial queue probe failed, broad metadata outputs were truncated and
two historical registrations unexpectedly exposed embedded source diffs before
registration. Those diffs are process-only. The author's other registered test
or fixture text was not executed.

In this peer review the historical base character window incidentally included
`#[cfg(test)]` and a test-module declaration at :3293–3294 as source text only;
no test was run. The current reducer window included environment-time
expressions as process-only context, with no new calendar coverage. An initial
metadata comparison printed `false` for an original queue row versus its 8b
wrapper; the subsequent exact comparison confirmed that the separate original
and reconstructed queue rows match. All 19 registered source displays were
complete, attested by this reader rather than independent telemetry.

The prior q0 peer, this q6 peer and the author's work remain separately
attributed. Missing checkpoint 3821, SOURCE004 and the 73 nontext/no-positive-EOF
obligations remain open. Git objects, full queue streams, the protected
extraction and full author packets are same-machine dependencies; their hashes
are not evidence of an independent backup or of recovered checkpoint 3821.
