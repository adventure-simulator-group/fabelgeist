# Bounded Lens 8 review: tactical fixture error propagation

The selected current fixture route can replace a checked item-grant error with a
generic loadout error before it reaches the reducer. This is a conditional
source trace: an existing unselected matching item must not be found and the
new grant must fail. Supported inputs, actual reach and transaction behavior
remain open. It is related to the already recorded inventory grant error
erasure; it is not a new defect count or an alias determination.

The source authority for this review is commit
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The ledger and queue snapshot is
checkpoint `8b4b9b9aae3b9d9821418fa3ad5cff4a21e5384b`. Its q6 wrapper remains
unassessed; this packet is a separate proposed assessment, not adoption or
closure.

## Current source trace

1. `crates/adventuresim-core/src/tactical_fixture.rs:16` derives `Deserialize`;
   its `parse` method at :49–56 calls validation. The selected reducer uses that
   parser (`crates/adventuresim-stdb-module/src/strategic/mission_bootstrap.rs:498–515`).
   Direct deserialization and parser validation are distinct admission routes;
   whether other routes are supported or reach this reducer was not determined.
2. The fixture helper checks roster cardinality, updates each selected name, and
   applies the loadout and optional clothing in order
   (`crates/adventuresim-stdb-module/src/strategic/tactical_enemy_fixture.rs:9–43`).
   Its context roster is sorted by ordinal and filters out missing or dead
   characters (`crates/adventuresim-stdb-module/src/world_actor.rs:320–347`).
   Equal-ordinal ordering and any broader uniqueness promise remain policy and
   source questions.
3. The current loadout helper first searches for an unselected matching row. If
   none is found, it asks the ordinary grant helper for one item and converts
   `None` into a generic loadout error
   (`crates/adventuresim-stdb-module/src/character.rs:3237–3266`). The ordinary
   grant wrapper discards a checked error with `.ok().flatten()`
   (`crates/adventuresim-stdb-module/src/item.rs:351–408,429–437`). Basic clothing
   uses the same wrapper and reports a different generic error on absence
   (`crates/adventuresim-stdb-module/src/character.rs:3195–3230`). On these
   selected fixture branches, the reducer receives an error rather than a
   successful return when the wrapper yields `None`; the original checked cause
   is no longer available there. Not every grant error or admitted fixture was
   shown reachable.
4. The reducer performs source-visible work before configuration and creates its
   mission snapshot and request after configuration
   (`crates/adventuresim-stdb-module/src/strategic/mission_bootstrap.rs:534–550,581–642,716–789`).
   The helper also updates names and unequips existing roots before later
   fallible operations. These source-order observations do not establish
   committed partial state or prove or disprove database rollback.

## Historical comparison and correction

The recovered q6 record is `CONT08-P16-FIXTURE-ERROR-ERASURE`, Lens 8,
historically `open-reconciliation`. Its selected historical completion receipt
records base `a120390947c89b703dc74c4255a13c035d054c50` and P16 head
`039329518e264f19206cf5b0b98d177433f40c17`. Those are historical comparison
identities, not the current source authority. The receipt reports source-only
accounting with findings and leaves currentness, exact alias, repair and
validation pending. The selected receipt does not independently name a personal
reader; its collection attribution is retained without assigning an inferred
reader or transferring credit.

The 95e item file is byte-identical to the historical base file. At the P16
head, the selected item grant instead returns `StrategicOperationResult` and
propagates the checked failure; its selected character helper also returns that
result type (`item.rs:351–408` and `character.rs:3243–3297` at 039). Its food
capability refresh also propagates a failure rather than discarding it. The
selected comparison does not establish that a food case reaches this fixture
route, authorize a behavior change, or establish either build's outcome. The
current character helper's selected :3218–3269 text matches base :3240–3291.

The fixture helper is byte-identical across a120, 039 and 95e. The historical
completion receipt describes a per-enemy `map_err(format!(...))`, but the exact
43-line helper instead uses `?` directly at :37 and :39. The P16 character
helper returns `StrategicOperationResult`, while the unchanged fixture helper
declares `Result<(), String>`; the inspected 039 error owner is
`operation_error.rs:1–44`. The actual conversion or compilation context is not
established by this bounded review. Preserve the receipt as historical evidence
and the exact source discrepancy as an open question, rather than promoting its
conversion description as current fact or asserting a build failure.

The earlier historical comparison registered a reversed base range 429–408 and
produced an addition-only delta. Its own next registration rejects that result;
the following registration compares the actual base checked helper and wrapper.
Both the rejected record and correction are retained. No credit comes from the
rejected range.

## Relationships and remaining work

8b ledger entries 8 and 109 already record the same 95e grant-wrapper
first-failure family and its separately assessed conditional false-success and
insertion questions. The q6 fixture branch adds a selected caller that turns
absence into an error; do not assume the same externally visible outcome or a
global alias. Ledger 145 concerns a different party grant wrapper. Entries 378
and 379 and planning relationship 1134 concern fixture admission, count and
related propagation; those are distinct first operations. Their existing
attributions and limits remain unchanged. Historical q218, q946, q947, q1688,
q3100 and q3134 are separately recorded related context, not aliases.

Resolve the supported fixture and item-catalog routes that can cause a checked
grant failure, the desired cause and context at the actual native boundary,
ordering when roster ordinals tie, the historical P16 conversion discrepancy,
and transaction semantics using the later authorized process. The wider M06
strategic error family and exact historical aliases remain open. No repair,
product execution, fixture execution, test, build or runtime probe was done.

## Evidence and process limits

Sixteen individually registered current and historical windows were displayed;
the reader's personal display is an attestation, not independent telemetry.
Their source bytes were checked against the same-machine Git objects and the
selected recovered historical snapshots. A current character window, a base
character window and a validation-tail window incidentally included test or
fixture source text; none was executed. Other environment-time and adjacent
foraging content displayed within registered windows is context only and carries
no separate source-coverage claim.

An initial queue metadata probe raised `IndexError` and was corrected. A broad
recursive metadata search and a directory listing were truncated; their full
original displays were not separately retained. Two historical registration
documents unexpectedly contained source diffs and were displayed before source
window registration; those incidental diffs are quarantined as process-only,
with no personal historical read credit. The exact documents and later
prospectively registered windows are preserved separately.

Selected original and reconstructed queue objects match as raw slices while the
complete streams differ. All anchors and replay dependencies remain on the same
machine; there is no independent backup claim. The missing checkpoint 3821,
SOURCE004 and the 73 nontext/no-positive-EOF obligations remain unresolved.
Historical summaries and reconstructed records are not upgraded to recovered
checkpoint 3821 evidence.
