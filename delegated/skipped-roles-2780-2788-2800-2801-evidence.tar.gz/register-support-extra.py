from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[
('character-construction','crates/adventuresim-stdb-module/src/character.rs',[[1882,1915],[2600,2640]]),
('capability-refresh','crates/adventuresim-stdb-module/src/capability.rs',[[116,163]]),
('governance-more','crates/adventuresim-stdb-module/src/strategic/governance.rs',[[1102,1125],[1383,1455]])
]
entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':'support/'+name+'.rs'});pending.append((name,raw))
out={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Additional production construction/refresh and role/acceptance support; not ordered-role credit.','entries':entries}
(b/'support-registration-extra.json').write_text(json.dumps(out,indent=2)+'\n')
for name,raw in pending:(b/('support/'+name+'.rs')).write_bytes(raw)
print(json.dumps(out,indent=2))
