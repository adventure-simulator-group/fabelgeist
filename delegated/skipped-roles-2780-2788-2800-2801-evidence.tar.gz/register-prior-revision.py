from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>'
rev='c100638b720a7281a5fc96f6a3c5c23d5dda85da';r=json.load(open('registration.json'));entries=[];pending=[]
for row in r['rows']:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+row['path']]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+row['path']],text=True).strip()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 loc=f"source/{row['original_index']}-c100.rs";pending.append((loc,raw))
 entries.append({'original_index':row['original_index'],'path':row['path'],'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':loc,'equals_95e':raw==(b/row['versions'][1]['local']).read_bytes(),'planned_display':False})
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Mechanical retained prior c100 Git bytes for exact earlier assessment identity; no personal source display or transfer of reviewer/lens credit.','entries':entries}
(b/'prior-revision-registration.json').write_text(json.dumps(x,indent=2)+'\n')
for loc,raw in pending:(b/loc).write_bytes(raw)
print(json.dumps(x,indent=2))
