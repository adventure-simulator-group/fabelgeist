from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[
('governance','crates/adventuresim-stdb-module/src/strategic/governance.rs',[[837,910],[1285,1345]]),
('character','crates/adventuresim-stdb-module/src/character.rs',[[795,925],[2040,2080]]),
('capability','crates/adventuresim-stdb-module/src/capability.rs',[[164,205],[570,605]]),
('weapon-instance','crates/adventuresim-stdb-module/src/weapon_instance.rs',[[315,365]]),
('equipment-projection','crates/adventuresim-stdb-module/src/capability/equipment_projection.rs',[[1,55]]),
('character-query','crates/strategic-web/src/routes/parties.rs',[[854,878]]),
('medical','crates/strategic-web/src/routes/settlements/party/inventory_medical.rs',[[707,775]])
]
entries=[];pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 assert max(z for a,z in ranges)<=len(raw.splitlines()),(name,len(raw.splitlines()))
 entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':'support/'+name+'.rs'});pending.append((name,raw))
out={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively registered current bounded production support only, no original role credit. Archived full file bytes do not imply all lines read.','entries':entries}
(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n')
for name,raw in pending:
 p=b/('support/'+name+'.rs');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(out,indent=2))
