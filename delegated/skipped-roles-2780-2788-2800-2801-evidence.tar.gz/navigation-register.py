from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'Navigation match lines only; no body or historical-role credit. Register exact support bodies before display.','queries':[
{'name':'weapon','path':'crates','pattern':'ParametricWeaponCombatGeometry|conditioned_precision\\('},
{'name':'temp','path':'crates/adventuresim-stdb-module/src','pattern':'scale_temporary_enemy|create_temporary_character|refresh_capabilities'},
{'name':'recruitment','path':'crates/adventuresim-stdb-module/src','pattern':'meets_requirements|fn update_recruitment_role|fn request_join'},
{'name':'web','path':'crates/strategic-web/src','pattern':'recruitment_panel_fragment|fn medical_presentation|fn get_character'}
]}
Path('navigation-registration.json').write_text(json.dumps(x,indent=2)+'\n')
