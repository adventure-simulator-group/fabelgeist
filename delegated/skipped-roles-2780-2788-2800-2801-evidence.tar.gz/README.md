# Bounded source evidence: roles 2780, 2788, 2800 and 2801

`REPORT.json` records thirteen partial lens perspectives, historical source
relationships, conditional findings, and open questions. Registrations and
`read-receipt.json` distinguish original and current displays, support,
navigation, and unread complements. The prior current trace assessments
record c100 rather than 95e: both file versions are byte-identical, independently
proved here, but earlier read credit and reviewer attribution remain unchanged.

Original role 2780 is from pr-working, a 6533-based snapshot with unrelated
modifications. The other three are dirty physical-p16 based on a120. A later
reproduced tracked P16 patch matches its historical digest; original generation
and uninterrupted custody are unestablished, and seven untracked files remain
separately qualified. Per-file equality does not make either whole tree clean.
f82 transports evidence and 039 is a cataloged per-file origin, not P16 HEAD.

`historical/` holds exact 059 and 774 records. `recovered/` contains the
registry/archive and 059 queue/ledger plus the explicitly reconstructed 774
catalog and later P16 recovery. `historical-selections-reconstructed.json`
selects original rows into a newly constructed record. Prior assessments retain
their exact revision, attribution and findings. No checkpoint 3821 or
whole-lens completion is asserted. Top-level manifest includes nested manifests.

Run `python3 verify-evidence.py` for offline evidence integrity only. No
product, build, test, fixture, generated code, macro, or runtime execution.
