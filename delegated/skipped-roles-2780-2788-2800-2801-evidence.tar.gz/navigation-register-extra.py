from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'Additional current navigation match lines only. Register source bodies separately before display.','queries':[
{'name':'character-owner','path':'crates/adventuresim-stdb-module/src/character.rs','pattern':'fn insert_new_character|fn insert_character_with_origin|character_capability|refresh_character_capability'},
{'name':'capability-owner','path':'crates/adventuresim-stdb-module/src/capability.rs','pattern':'fn refresh_character_capability|character_capability\\(\\)|fn compute'},
{'name':'role-requirements','path':'crates/adventuresim-stdb-module/src/strategic/governance.rs','pattern':'fn role_requirements|fn validate_recruitment_requirements|fn request_party_join|fn accept'},
{'name':'tactical-cache','path':'crates/adventuresim-tactical-server/src','pattern':'CharacterCapability|character_capability|refresh_capabilities'}
]}
Path('navigation-registration-extra.json').write_text(json.dumps(x,indent=2)+'\n')
