from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');nav={};navigation=[]
files=['navigation-weapon.txt','navigation-temp.txt','navigation-recruitment.txt','navigation-web.txt','navigation-character-owner.txt','navigation-capability-owner.txt','navigation-role-requirements.txt','navigation-tactical-cache.txt','navigation-gateway.txt','navigation-construction.txt']
for name in files:
 lines=(b/name).read_text().splitlines()
 for line in lines:
  if name=='navigation-construction.txt':
   m=re.match(r'^(\d+):',line);assert m;path='crates/adventuresim-stdb-module/src/character.rs';num=int(m.group(1))
  else:
   m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m;path,num=m.group(1),int(m.group(2))
  nav.setdefault(path,set()).add(num)
 rn='navigation-registration-construction.json' if name=='navigation-construction.txt' else 'navigation-registration-gateway.json' if name=='navigation-gateway.txt' else 'navigation-registration-extra.json' if name in files[4:8] else 'navigation-registration.json'
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'registration':rn,'ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2780:[[1,66]],2788:[[494,566]],2800:[[325,342]],2801:[[355,430],[431,506],[507,581]]};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];shown=nums(d);navonly=sorted(nav.get(row['path'],set())-shown) if j else []
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':navonly,'unread_after_assigned_and_navigation':comp(v['eof'],shown|set(navonly)),'qualification':'Current support displays are separate. Historical 2788 pre-registration display and 2800 excluded 343–345 do not receive old role credit.'})
bodies={'governance':[[837,910],[1285,1345]],'character':[[795,860],[861,925],[2040,2080]],'capability':[[164,205],[570,605]],'weapon-instance':[[315,365]],'equipment-projection':[[1,55]],'character-query':[[854,878]],'medical':[[707,775]],'character-construction':[[1882,1915],[2600,2640]],'capability-refresh':[[116,163]],'governance-more':[[1102,1125],[1383,1455]],'character-capability-view':[[175,200]],'capability-evaluation':[[75,115]],'core-capability':[[143,208]]};support=[]
for name in ['support-registration.json','support-registration-extra.json','support-registration-view.json','support-registration-role.json']:
 for x in load(name)['entries']:
  d=bodies[x['name']];shown=nums(d);prior=[]
  for row in reg['rows']:
   if row['path']==x['path']:prior=chunks[row['original_index']]
  prev=nums(prior);navonly=sorted(nav.get(x['path'],set())-shown-prev)
  support.append({'name':x['name'],'registration':name,'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement_after_this_support_and_assigned':comp(x['eof'],shown|prev|set(navonly)),'qualification':'Other support of this same current path is separate; complement does not union those entries.','ordered_role_credit':0})
x=load('gateway-support-registration.json');shown=nums(x['ranges']);navonly=sorted(nav.get(x['path'],set())-shown);eof=load('support-registration.json')['entries'][1]['eof']
support.append({'name':'gateway','registration':'gateway-support-registration.json','path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':eof,'full_line_body_displays':x['ranges'],'prior_assigned_displays_of_same_pinned_path':[],'navigation_only_lines':navonly,'unread_complement_after_this_support_and_assigned':comp(eof,shown|set(navonly)),'qualification':'Separately registered gateway support; other current character.rs displays are separate.','ordered_role_credit':0})
names=['registration.json','navigation-registration.json','navigation-registration-extra.json','navigation-registration-gateway.json','navigation-registration-construction.json','support-registration.json','support-registration-extra.json','support-registration-view.json','support-registration-role.json','gateway-support-registration.json','prior-revision-registration.json']
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Newly reconstructed personal source display and navigation receipts after prospective registrations. c100 historical-trace bytes preserved mechanically, never personally displayed for this task.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'limits':'No product, generated code, macro, test, fixture, build, runtime probe, repair or publication edit.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('sha256',h((b/'read-receipt.json').read_bytes()))
