from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>')
orig=Path('<LOCAL_PATH_1>')
prev=Path('<LOCAL_PATH_2>')
workspace=Path('<LOCAL_PATH_3>')
h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/n,'recovered/'+n,'Original registry/archive/059 where applicable; reconstructed catalog and later independently reproduced tracked patch remain labelled.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-core/AGENTS.md','crates/strategic-web/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Applicable current rules; user source-only prohibition governs.')
for n in ['COVERAGE-L01-ROLES.json','ASSESSMENT-L1-CONTACT-PRECISION.json','ASSESSMENT-L1-TACTICAL-ENTRY-IDENTITY.json','ASSESSMENT-L1-MISSION-ID-SERDE.json','ASSESSMENT-L1-MISSION-ROSTERS.json','ASSESSMENT-L1-RECRUITMENT-ROLE.json','ASSESSMENT-WEAPON-IDENTITY-95E.json','ASSESSMENT-DELEGATED-RECONCILIATION-7-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Prior bounded assessment or later recovery; preserve exact revision/ranges/reviewer and no transfer.')
names=['segovb/READ-L11-453.json','segovb/READ-L11-454.json','segovb/READ-L11-456.json','segovb/STATE-L11-453.json','segovb/STATE-L11-454.json','segovb/STATE-L11-456.json','segovb/VERIFY-L11-453.json','segovb/VERIFY-L11-454.json','segovb/VERIFY-L11-456.json']+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in [1700,1708,1720,1721]]
for n in names:copy(orig/n,'historical/059/'+n,'Exact original 059 receipt/registration; no past reviewer or lens credit transfer.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for owner,folder,names in [('camera','initial07-redundant-authority',['source-range-registration.jsonl','additional-sources.jsonl','qualifications.jsonl','contracts.jsonl','findings.jsonl','character-authority-105.json'])]:
 for n in names:
  gp=f'handoff/774/adler-original/audit/continuation/{owner}/{folder}/{n}';raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp])
  save(raw,f'historical/774/{owner}-{n}','git:'+rev+':'+gp,'Exact original 774 supplier record via f82 transport.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw)
qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw);coverage=load=lambda n:json.loads((b/n).read_bytes());cv=coverage('prior/COVERAGE-L01-ROLES.json')
ids=[2780,2788,2800,2801]
selection={'kind':'Newly reconstructed selected rows from exact historical and current coverage records; not an original standalone record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in ids},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')],'queue_uncompressed_sha256':h(qraw),'queue_entries':{str(i):q['entries'][i] for i in [987,1043]},'prior_coverage_sha256':h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes()),'prior_coverage_roles':{str(i):next(x for x in cv['roles'] if x['original_index']==i) for i in ids},'qualification':'Preserve distinct P16/PR snapshots and actual c100 attributed prior ranges; no 3821 promotion.'}
(b/'historical-selections-reconstructed.json').write_text(json.dumps(selection,indent=2)+'\n')
(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'No prior reviewer/lens credit transfer; f82 transports evidence only.'},indent=2)+'\n')
print('records',len(records),'sha256',h((b/'historical-manifest.json').read_bytes()))
