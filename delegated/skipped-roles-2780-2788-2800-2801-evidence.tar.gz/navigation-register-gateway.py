from pathlib import Path
from datetime import datetime,timezone
import json
x={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'Navigation lines only for gateway visibility; separately register any body.','queries':[{'path':'crates/adventuresim-stdb-module/src','pattern':'fn gateway_character_ids'}]}
Path('navigation-registration-gateway.json').write_text(json.dumps(x,indent=2)+'\n')
