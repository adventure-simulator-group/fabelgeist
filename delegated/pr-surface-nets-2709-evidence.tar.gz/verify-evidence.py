#!/usr/bin/env python3
"""Evidence identities, source read accounting and Git proofs only."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
def vals(r):return {i for lo,hi in r for i in range(lo,hi+1)}
scope=load('read-scope-summary.json')
for regfile,receipt,section in [('registration.json','personal-read-receipt.json','assigned'),('support-registration.json','support-read-receipt.json','support'),('support2-registration.json','support2-read-receipt.json','support')]:
 reg=load(regfile);rc=load(receipt);assert sha((p/regfile).read_bytes())==rc['registration_sha256'] and reg['registered_utc']<rc['recorded_utc'] and len(reg['entries'])==len(rc['actual_displays'])
 for e,x in zip(reg['entries'],rc['actual_displays']):
  d=(p/e['source_archive']).read_bytes();assert (sha(d),blob(d),len(d),len(d.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['EOF']) and x['source_archive']==e['source_archive'] and e['planned_chunks']==x['displayed_chunks'] and vals(e['planned_chunks'])==vals(e['registered_ranges']);s=scope[section][e['source_archive']];assert s['displayed_ranges']==e['registered_ranges'] and s['unread_complement']==x['unread_complement'] and not vals(s['displayed_ranges'])&vals(s['unread_complement']) and vals(s['displayed_ranges'])|vals(s['unread_complement'])==set(range(1,e['EOF']+1))
exp=load('pre-registration-exposure.json');line=gzip.decompress((p/exp['record_archive']).read_bytes());event=json.loads(line);assert sha(line)==exp['record_sha256_uncompressed'] and event['transcript_ordinal']==exp['transcript_ordinal']==53777 and event['command_sha256']==exp['recorded_command_sha256'] and event['output_sha256']==exp['recorded_output_sha256'] and event['recorded_exit_code']==0
reg=load('registration.json');old,cur=reg['entries'];assert (p/old['source_archive']).read_bytes()==(p/cur['source_archive']).read_bytes() and old['registered_ranges']==cur['registered_ranges']==[[1,280]] and old['original_material_ranges']==[[1,206]] and 'unregistered discovery exposure' in scope['qualification'] and 'before this registration' in reg['pre_registration_exposure'];checks.append('Independent historical/current full personal displays and six bounded current supports, with accidental pre-registration excerpt exposure and unread complements')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';j=json.loads(raw);sel=load('registry-selection-reconstructed.json');snap=next(x for x in j['snapshots'] if x['id']=='pr-working');assert sel['role']==j['files'][2709] and sel['pr_working']==snap and snap['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(snap['status_porcelain'])==4 and sel['role']['material_ranges']==[[1,206]] and not any(x[3:]==old['path'] for x in snap['status_porcelain'])
raw=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(raw)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';entries={x['path']:x for x in json.loads(gzip.decompress(raw))['entries']};history=load('historical-index.json');assert sum(x['kind']=='original-059' for x in history['records'])==16 and sum(x['kind']=='historical-774' for x in history['records'])==3
for x in history['records']:
 d=(p/x['file']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (len(d),sha(d),blob(d))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
search=load('recovery-search.json');assert len(search['roots'])==2 and len(search['filenames'])==3 and not search['results'] and not search['errors'] and not search['transport_manifest_matches'] and not any(pathlib.PurePosixPath(x).name in search['filenames'] for x in entries);checks.append('Original registry and unrelated dirty status; 16 exact 059 and three 774 records; bounded proposal search')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];d=gzip.decompress((p/x['archive']).read_bytes());assert (len(d),sha(d),hashlib.sha1(x['type'].encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest())==(x['bytes'],x['sha256'],oid);return d
def trees(d):
 out={};i=0
 while i<len(d):
  s=d.index(b' ',i);z=d.index(b'\0',s);out[d[s+1:z].decode()]=(d[i:s].decode(),d[z+1:z+21].hex());i=z+21
 return out
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==13
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 d=(p/x['archive']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (sha(d),blob(d),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Thirteen offline Git proofs: f82 archived object, individual 6533/990/95e identities, six current supports and three 774 records')
rows=[json.loads(x) for x in gzip.decompress((p/'history-774/rig/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines()];rr=next(x for x in rows if x['id']=='RIG-ADMISSION03-REG-141');assert rr['ranges']==[[1,207]] and rr['sha256']==old['sha256'];q=json.loads(gzip.decompress((p/'history-774/rig/admission03/source-registration-qualification-117.json.gz').read_bytes()));qual=next(x for x in q['entries'] if x['registration']=='RIG-ADMISSION03-REG-141');assert qual['actual_material_ranges']==[[1,206]] and qual['context_or_blank_no_material_credit']==[[207,207]];r=[json.loads(x) for x in gzip.decompress((p/'history-774/rig/admission03/root-support/additional-contracts.jsonl.gz').read_bytes()).splitlines()];additional=next(x for x in r if x['id']=='RIG-ROOT-ADM03-ADDITIONAL-003');assert additional['actual_material_ranges']==[[1,206]]
l11=next(x for x in load('history-059/segovb/READ-L11-442.json')['sources'] if x['original_index']==2709);assert l11['fresh_personal_body_reads']==[[1,206]]
for i,expected in [(2,[[1,195]]),(3,[[196,207]])]:
 x=next(x for x in load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-942-{i:03d}.json')['rows'] if x['original_index']==2709);assert x['fresh_personal_body_reads']==expected and '/root/lens12_frontier' in x['attribution']
assert 'root adoption required' in load('history-059/parallel-l12-20261029/PROPOSAL-L12-942.json')['kind'];group=load('history-059/evidence/audit05/contract-groups-328.json');m=next(x for x in group['source_members'] if x['scope_index']==2709);assert m['personally_read_ranges']==[[1,280]] and m['sha256']==old['sha256'] and group['findings'][0]['id']=='ADLER-RESUMED05-F009';prior=load('history-059/evidence/audit05/remedy-reconciliation/F009-current-990430b-001.json');assert prior['current_canonical']['revision']=='990430b77a9f63548ffcb642074185f61ddb3322' and prior['finding_id']=='ADLER-RESUMED05-F009';assert (p/'history-059/evidence/audit05/STATE.json').read_bytes()==(p/'reference/baseline-state-05.json').read_bytes();checks.append('Original Rig qualified range, Segovb and Lens12 scopes, full Adler historical read and 990 reassessment attributed separately')
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';j=json.loads(raw)
for n,e in q['entries'].items():assert e==j['entries'][int(n)]
for x in load('reference-index.json')['records']:
 d=(p/x['file']).read_bytes();assert (sha(d),len(d))==(x['sha256'],x['bytes'])
for file in ['rules.json','skills.json']:
 for x in load(file)['records']:assert sha((p/x['file']).read_bytes())==x['sha256']
l13=load('reference/l13-literal-proposal.json');assert l13['proposed_question']['contract_id']=='ROOT-L13-2709-SURFACE-NETS-NUMERIC-ADMISSION' and 'historical claims' in l13['qualification'];report=load('report.json');assert report['scope']['roles']==[2709] and {x['number'] for x in report['lenses']}==set(range(1,14));checks.append('Reconstructed original queue, separately sourced prior assessments and literal-only Lens13 proposal; 13 bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and read accounting only; no renderer, viewer, shaders, product, fixtures, tests, builds, runtime probes, simulation, repair, validation, checkpoint3821 promotion, proposal adoption or whole-lens closure.'},indent=2))
