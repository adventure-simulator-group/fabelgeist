import datetime,gzip,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;load=lambda x:json.loads((p/x).read_bytes());write=lambda n,x:(p/n).write_text(json.dumps(x,indent=2)+'\n')
sc={'author':'/root/mhr_character','assigned':{},'support':{},'qualification':'Actual personally displayed scopes only; original role material 1–206 and historic context 207–280 kept distinct. Old lines 170–206 plus partial169 had unregistered discovery exposure in truncated search before prospective registration; later full personal re-displays are separately receipted.'}
for stem in ['','support-','support2-']:
 reg=load(stem+'registration.json');rec=load(('personal-read-receipt.json' if not stem else stem+'read-receipt.json'))
 for e,x in zip(reg['entries'],rec['actual_displays']):
  s={'path':e.get('path'),'revision':e['revision'],'EOF':e['EOF'],'displayed_ranges':x['displayed_ranges'],'unread_complement':x['unread_complement']};sc['assigned' if not stem else 'support'][e['source_archive']]=s
write('read-scope-summary.json',sc)
roots=['<LOCAL_PATH_0>','<LOCAL_PATH_1>'];names=['READ-L12-942.json','VERIFY-L12-942.json','STATE-L12-942.json'];results=[];errors=[]
for root in roots:
 for name in names:
  r=subprocess.run(['rg','--files','--hidden','--no-ignore','-g',name,root],capture_output=True,text=True);results+=r.stdout.splitlines()
  if r.returncode not in (0,1):errors.append({'root':root,'name':name,'code':r.returncode,'stderr':r.stderr})
manifest=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));matches=[e['path'] for e in manifest['entries'] if pathlib.PurePosixPath(e['path']).name in names];write('recovery-search.json',{'searched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roots':roots,'filenames':names,'results':results,'errors':errors,'transport_manifest_matches':matches,'method':'rg files exact name globs in two targets and manifest basename lookup','qualification':'No global absence assertion. Proposal PAR-L12-942 explicitly requires root adoption; these bounded searches do not establish adoption.'});print('adoption search results/errors/manifest matches',len(results),len(errors),len(matches))
