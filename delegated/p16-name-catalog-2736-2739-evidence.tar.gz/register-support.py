from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent;repo=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();entries=[]
spec=[
 ('crates/adventuresim-world-schema/src/person_names.rs',[[275,350],[351,475]]),
 ('crates/adventuresim-world-schema/src/person_names/error.rs',[[1,34]]),
 ('crates/adventuresim-world-schema/src/person_names/identity_validation.rs',[[1,169]]),
 ('crates/fabelgeist-determinism/src/stream.rs',[[1,135]]),
 ('crates/fabelgeist-determinism/Cargo.toml',[[1,26]]),
 ('crates/adventuresim-core/src/starting_character/names.rs',[[1,82]]),
 ('Cargo.lock',[[8583,8591]])
]
for i,(path,ranges) in enumerate(spec):
 raw=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+path],text=True).strip();loc=f'support/{i}.source';q=b/loc;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 entries.append({'kind':'first-party current source','revision':rev,'path':path,'local':loc,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':ranges,'ordered_role_credit':0})
arc=repo/'native-evidence/rand-0.9.5/rand-0.9.5.crate';raw=arc.read_bytes();assert h(raw)=='b9ef1d0d795eb7d84685bca4f72f3649f064e6641543d3a8c415898726a57b41'
(b/'native').mkdir(exist_ok=True);(b/'native/rand-0.9.5.crate').write_bytes(raw)
member='rand-0.9.5/src/distr/weighted/weighted_index.rs'
with tarfile.open(arc,'r:gz') as t:body=t.extractfile(member).read()
assert h(body)=='b4559037354bcb9e0b1eab569c867dd70053de382232c7ed4d9aef3d5b049003';(b/'native/weighted_index.rs').write_bytes(body)
entries.append({'kind':'external rand 0.9.5 crate member; distinct from project Git','archive_local':'native/rand-0.9.5.crate','archive_sha256':h(raw),'member':member,'local':'native/weighted_index.rs','sha256':h(body),'bytes':len(body),'eof':len(body.splitlines()),'planned_display_ranges':[[81,150]],'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','description':'Prospective bounded current application/native support for family/surname sampling, error, selected owner and package provenance; build and package source are evidence only, never executed. Earlier 95e trace remains independently attributed.','entries':entries}
(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2));print('sha256',h((b/'support-registration.json').read_bytes()))
