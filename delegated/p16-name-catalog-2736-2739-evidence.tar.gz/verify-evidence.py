'''Offline evidence-integrity verification only. Never executes product/build scripts/tests or fixtures.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files']
assert all(original[i]==sel['registry_rows'][str(i)] for i in [2155,2165,2166,2167,2736,2737,2738,2739])
assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id'] in ['physical-p16','pr-working']]
snapshot=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes()
assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['recovered_patch']['bytes']==len(patch) and recovery['live_comparison']['status_counts']['??']==7
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows'];expected={2736:[[1,121]],2737:[[1,199]],2738:[[1,410]],2739:[[1,214]]}
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];body=(b/old['local']).read_bytes()
  assert t.extractfile(old['sha256']).read()==body and h(body)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256']
  assert original[i]['material_ranges']==expected[i]==row['original_material_ranges']
  assert catalog[i]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path']
  assert (b/cur['local']).read_bytes()==body
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==body and c['display_planned']==False
for x in rec['registrations']:
 assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(ranges):return [i for a,z in ranges for i in range(a,z+1)]
def partition(n,ranges):
 v=nums(ranges);return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes()
  assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof']
  assert partition(v['eof'],p['actual_display_chunks']+p['unread_complement'])
  assert nums(p['actual_display_chunks'])==nums(expected[row['original_index']])
  assert p['original_assigned_displays']==(expected[row['original_index']] if j==0 else [])
  assert p['unread_complement']==([[411,576]] if row['original_index']==2738 else [])
support=load('support-registration.json');extra=load('more-support-registration.json');planned={x['local']:x for x in support['entries']}
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'] and x['ordered_role_credit']==0
 assert partition(x['eof'],x['actual_display_chunks']+x['unread_complement'])
 permitted=e['planned_display_ranges']+(extra['planned_display_ranges'] if x['local']==extra['local'] else [])
 assert set(nums(x['actual_display_chunks']))==set(nums(permitted))
native=next(x for x in support['entries'] if x['kind'].startswith('external rand'));arc=(b/native['archive_local']).read_bytes()
assert h(arc)==native['archive_sha256']=='b9ef1d0d795eb7d84685bca4f72f3649f064e6641543d3a8c415898726a57b41'
with tarfile.open(b/native['archive_local'],'r:gz') as t:assert t.extractfile(native['member']).read()==(b/native['local']).read_bytes()
assert native['archive_sha256'] in (b/'support/6.source').read_text().splitlines()[8586] and 'version = "=0.9.5"' in (b/'support/4.source').read_text()
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
assert len(proof['proofs'])==35
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
native_rows=readjsonl('historical/774/native-range-registration.jsonl');quals=readjsonl('historical/774/native-followthrough-qualifications.jsonl');contract=load('historical/774/names-contracts-002.json')
for i in range(2736,2740):
 ob=original[i]['admission03_scope_observations'][0];assert native_rows[ob['row_1based']-1]==ob['original_record']
 q=next(x for x in quals if x['registration_id']==ob['registration_id']);assert q==ob['local_qualifications'][0]
 assert contract['source_roles'][i-2736]['effective_material_ranges']==expected[i]
assert native_rows[124]['material_ranges']==[[1,411]] and '411 blank' in contract['source_roles'][2]['context_or_exclusions']
erratum=load('historical/774/reference-erratum-004.json')
assert erratum['immutable_receipt']=='names-contracts-002.json' and erratum['actual_reference'].endswith('lower-dependency-qualification-036.json')
l11=load('historical/059/segovb/READ-L11-447.json')
for i,n in [(2736,1655),(2737,1656),(2738,1657),(2739,1658)]:
 x=next(x for x in l11['sources'] if x['original_index']==i)
 assert x['fresh_personal_body_reads']==expected[i] and h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{n}.json').read_bytes())==x['registration_sha256']
adler=load('historical/059/adler/READ-L11-341.json')
for i,n,ranges in [(2165,1022,[[1,199]]),(2166,1023,[[1,576]]),(2167,1024,[[1,214]])]:
 x=next(x for x in adler['sources'] if x['original_index']==i)
 assert x['fresh_reads']==ranges and h((b/f'historical/059/adler/REGISTRATION-ADLER-{n}.json').read_bytes())==x['registration_sha256']
l12=load('historical/059/segovb/READ-L12-723.json');assert l12['root_personal_rereads']==[]
for i,n,ranges in [(2165,115,[[1,199]]),(2166,116,[[1,576]]),(2167,117,[[1,214]])]:
 x=next(x for x in l12['rows'] if x['original_index']==i)
 assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution']
 assert h((b/f'historical/059/parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json').read_bytes())==x['registration_sha256']
for i,n in [(2736,1),(2737,2)]:
 partial=load(f'historical/059/parallel-l12-20261029/PARTIAL-PAR-L12-957-{n:03}.json')
 assert partial['new_original_credit']==0
 x=partial['rows'][0];assert x['original_index']==i and x['fresh_personal_body_reads']==expected[i] and '/root/lens12_frontier' in x['attribution']
 assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
for i,n in [(2736,802),(2737,803),(2738,804),(2739,805)]:
 x=load(f'historical/059/parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json');assert x['original_index']==i and x['original_record']==original[i]
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: P16 roles2736–2739 and 95e exact assigned scopes independently displayed, validator excluded tail unread; 059 partial-only reviewer and 774 erratum retained; P16 tracked-patch qualification and rand archive/lock/member verified; %d raw Git membership proofs. Thirteen bounded perspectives; no product/build/test/codegen/probe.'%len(proof['proofs']))
