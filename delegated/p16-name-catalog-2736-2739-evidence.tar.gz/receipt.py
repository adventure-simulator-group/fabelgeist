from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
r=load('registration.json');s=load('support-registration.json');m=load('more-support-registration.json')
chunks={2736:[[1,121]],2737:[[1,110],[111,199]],2738:[[1,105],[106,205],[206,310],[311,410]],2739:[[1,110],[111,214]]}
assigned=[]
for x in r['rows']:
 i=x['original_index'];old,cur=x['versions'];unread=[[411,576]] if i==2738 else []
 for j,v in enumerate([old,cur]):
  assigned.append({'original_index':i,'source_id':x['source_id'],'identity':old['identity'] if j==0 else 'pinned current source','revision':None if j==0 else cur['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':chunks[i],'original_assigned_displays':x['original_material_ranges'] if j==0 else [],'current_displays':[] if j==0 else chunks[i],'unread_complement':unread,'qualification':'2738 historical original requested 1–411 then qualified material 1–410; line411 blank, tests412–576 excluded and unread in this old/current source pass.' if i==2738 else 'Old assigned material and current independently displayed; equal bytes do not equate snapshots or prior reviewer credit.'})
def complement(n,ranges):
 used={k for a,z in ranges for k in range(a,z+1)};result=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):result.append([start,i-1]);start=None
 return result
supports=[]
for x in s['entries']:
 if x['local']=='support/0.source':
  shown=[[1,100],[101,195],[196,274],[275,350],[351,475],[476,510]];regs=['support-registration.json','more-support-registration.json']
 elif x['local']=='support/2.source':
  shown=[[1,90],[91,169]];regs=['support-registration.json']
 else:shown=x['planned_display_ranges'];regs=['support-registration.json']
 supports.append({'kind':x['kind'],'path':x.get('path',x.get('member')),'revision':x.get('revision'),'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'actual_display_chunks':shown,'unread_complement':complement(x['eof'],shown),'registrations':regs,'ordered_role_credit':0,'source_test_qualification':'Source text only, no execution; support/2 66–169 and support/0 493–510 are test text.' if x['local'] in ['support/0.source','support/2.source'] else None})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','method':'Newly reconstructed receipt of bounded actual personal line-numbered displays after timestamped prospective registrations. Archive bytes and equal hashes alone do not confer reading.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in ['registration.json','support-registration.json','more-support-registration.json']],'assigned':assigned,'support':supports,'limits':'No build script, macro, fixture, tests, product, sampler or runtime execution, builds, probes, repairs or publication edits.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('sha256',h((b/'read-receipt.json').read_bytes()),d['created_utc'])
