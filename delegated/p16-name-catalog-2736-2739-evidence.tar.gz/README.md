# Bounded P16 name-catalog evidence

This source assessment covers original physical-p16 roles 2736–2739 and the
pinned 95e63628f9d70b8dd6e6fede64334696c6995009 project source. REPORT.json
gives all thirteen bounded perspectives, exact read ranges, conditions, open
questions, and relationships to original 059/774 and prior current work.

The historical P16 snapshot is dirty and based at a120. A subsequently
reproduced tracked patch matches its recorded hash; seven untracked source
objects are separate. Per-file equality with a120, 6533, 039, or 95e does not
equate snapshots or transfer historical reviewers' credit. f82 is the archive
transport, not the historical project head.

Role 2738's historical registration included blank line 411 as context, while
its qualified material ends at 410; the test tail 412–576 was excluded.
This task did not display or run that tail. Other supporting test text was
displayed as text only. The original 059 Lens12 partial receipts cover 2736
and 2737 without frontier credit; registrations for 2738/2739 are not evidence
of reads. The original native reference erratum is preserved with its receipt.

Original records, reconstructed selections, newly assessed work, raw Git
commit/tree proofs, and the pinned rand package source are separately labelled.
No evidence or proposal is promoted into missing checkpoint 3821.

Run `python3 verify-evidence.py` from any directory to verify hashes,
recovered objects, original scope qualifications, actual-read partitions, the
native archive/lock/member chain, and Git membership. It is an offline evidence
check; it does not run product code. MANIFEST.json covers all packet files
except the top-level manifest itself, including nested manifests.
