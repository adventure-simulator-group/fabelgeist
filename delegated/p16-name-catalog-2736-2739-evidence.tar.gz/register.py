from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent;repo=Path('<LOCAL_PATH_0>');base=repo/'recovered/original-registry-source-archive'
h=lambda x:hashlib.sha256(x).hexdigest();r=json.load(gzip.open(base/'registry.json.gz','rt'));rows=[];pending=[]
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 for index in range(2736,2740):
  x=r['files'][index];p=x['source_id'].split(':',1)[1];old=t.extractfile(x['sha256']).read()
  assert h(old)==x['sha256'] and len(old)==x['bytes'] and len(old.splitlines())==x['actual_line_count']
  local=f'source/{index}-physical-p16.rs';pending.append((local,old))
  versions=[{'identity':'original physical-p16 archived object','revision_qualification':'dirty a120-based P16; f82 transports evidence, not project head','sha256':h(old),'bytes':len(old),'eof':len(old.splitlines()),'local':local,'original_assigned_planned':x['material_ranges'],'unplanned_complement':[[411,576]] if index==2738 else []}]
  comparisons=[]
  for rev in ['a120390947c89b703dc74c4255a13c035d054c50','6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']:
   raw=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+p]);blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+p],text=True).strip()
   assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
   n=f'source/{index}-{rev[:4]}.rs';pending.append((n,raw))
   d={'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':n,'equals_archived_file':raw==old}
   if rev.startswith('95e6'):
    d['current_body_planned']=[[1,410]] if index==2738 and raw==old else [[1,len(raw.splitlines())]]
    versions.append(d)
   else:d['display_planned']=False;comparisons.append(d)
  rows.append({'original_index':index,'source_id':x['source_id'],'path':p,'original_material_ranges':x['material_ranges'],'versions':versions,'comparison_git_paths':comparisons})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively display separately original P16 assigned material and pinned95e planned ranges. Original2736 1–121,2737 1–199,2738 1–410,2739 1–214. Historical2738 line411 blank and tests412–576 excluded; no inferred test/body credit. a120/6533 copies identity-only, not planned displays. Any needed support registered separately before display.','original_registry_uncompressed_sha256':h(gzip.decompress((base/'registry.json.gz').read_bytes())),'snapshot_qualification':'physical-p16 dirty a120-based; later recovered tracked patch matches recorded hash with seven untracked objects separately archived. f82 transports evidence, not project head. Equal per-file bytes do not imply equal snapshots.','rows':rows,'limits':'Static source/evidence only; no build script, code generation, product, macro, fixture or test execution, builds, probes, repairs or publication edits.'}
(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 q=b/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
print(json.dumps(d,indent=2));print('REGISTRATION_SHA256',h((b/'registration.json').read_bytes()))
