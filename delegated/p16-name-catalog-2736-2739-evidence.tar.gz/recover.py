from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo=Path('<LOCAL_PATH_0>')
workspace=Path('<LOCAL_PATH_1>')
orig=Path('<LOCAL_PATH_2>')
prev=Path('<LOCAL_PATH_3>')
h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def copy(src,dest,kind):
 raw=Path(src).read_bytes();out=b/dest;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 records.append({'origin':str(src),'local':dest,'sha256':h(raw),'bytes':len(raw),'kind':kind})
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/'recovered'/n,'recovered/'+n,'Exact previously retained original registry/archive or 059 ledger/queue; reconstructed catalog or later tracked patch kept labelled.')
for n in ['RECOVERY-PHYSICAL-P16-PATCH-20261111.json','SEARCH-P16-PATCH-20261111.json','ASSESSMENT-NAME-CATALOG-95E.json','ASSESSMENT-L01-HISTORICAL-2165-2171.json','REGISTRATION-L01-2165-2167.json']:
 copy(repo/n,'prior/'+n,'Previous published current assessment, historical role summary, or patch-recovery evidence, original authorship and scope retained.')
for n in ['AGENTS.md','crates/AGENTS.md']:copy(workspace/n,'rules/'+n,'Current applicable source rules; user forbids build/test/execution.')
names=['segovb/READ-L11-447.json','adler/READ-L11-341.json','segovb/READ-L12-723.json','segovb/READ-L12-724.json','parallel-l12-20261029/PROPOSAL-L12-723.json','parallel-l12-20261029/PROPOSAL-L12-724.json']
for i in range(1655,1659):names.append(f'segovb/REGISTRATION-SEGOVB-{i}.json')
for i in range(1022,1025):names.append(f'adler/REGISTRATION-ADLER-{i}.json')
for i in range(115,118):names.append(f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json')
for i in range(802,806):names.append(f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json')
for i,j in [(802,2736),(803,2737),(804,2738),(805,2739)]:names.append(f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{i}-ORIGINAL{j}.json')
for i in [1,2]:names.append(f'parallel-l12-20261029/PARTIAL-PAR-L12-957-{i:03}.json')
for n in names:copy(orig/n,'historical/059/'+n,'Exact original historical read, registration, qualification or separate Lens12 partial; never imply registration alone was read.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
prefix='handoff/774/adler-original/audit/continuation/native/admission03/'
paths=[
 ('native-range-registration.jsonl',prefix+'source-range-registration.jsonl'),
 ('native-followthrough-qualifications.jsonl',prefix+'source-qualifications-followthrough-current.jsonl'),
 ('names-contracts-002.json',prefix+'camera-lower-followthrough/names-contracts-002.json'),
 ('names-complete-counterpart-diff-001.json',prefix+'camera-lower-followthrough/names-complete-counterpart-diff-001.json'),
 ('reference-erratum-004.json',prefix+'camera-lower-followthrough/reference-erratum-004.json'),
 ('native-person-names-contracts-008.json',prefix+'camera-support/contracts-008.json'),
 ('lower-dependency-qualification-036.json',prefix+'camera-support/lower-dependency-qualification-036.json'),
 ('reference-and-dispatch-qualification-049.json',prefix+'camera-support/reference-and-dispatch-qualification-049.json')
]
for n,p in paths:
 raw=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+p]);out=b/'historical/774'/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 records.append({'origin':'git:'+rev+':'+p,'local':str(out.relative_to(b)),'sha256':h(raw),'bytes':len(raw),'kind':'Exact 774 original historical record via f82 evidence transport, not P16 source head.','transport_revision':rev,'git_path':p})
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw)
qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw)['entries']
d={'kind':'Newly reconstructed selections from exact recovered original registry and 059 queue, not historical standalone records.','registry_uncompressed_sha256':h(rraw),'queue_uncompressed_sha256':h(qraw),'registry_rows':{str(i):r['files'][i] for i in [2155,2165,2166,2167,2736,2737,2738,2739]},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ['pr-working','physical-p16']],'queue_rows':{str(i):q[i] for i in [134,135,284,285,286,1803]}}
(b/'historical-selections-reconstructed.json').write_text(json.dumps(d,indent=2)+'\n')
d={'kind':'Exact historical records, earlier assessments and explicitly reconstructed catalog','registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'Dirty P16 a120-based tracked diff later independently reproduced; untracked sources separate. pr-working is a separate 6533-based dirty snapshot. Historical and new reviewers, scopes and checkpoint3821 must not be conflated.'}
(b/'historical-manifest.json').write_text(json.dumps(d,indent=2)+'\n')
print('historical_records',len(records),'historical_manifest_sha256',h((b/'historical-manifest.json').read_bytes()))
