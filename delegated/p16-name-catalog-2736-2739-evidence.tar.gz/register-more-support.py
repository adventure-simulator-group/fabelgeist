from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
b=Path(__file__).resolve().parent;p=b/'support/0.source';raw=p.read_bytes()
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','description':'Additional prospective bounded display of current semantic names, rendered-name admission and remainder of surname rendering; distinct from previous support receipt and ordered-role credit.','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','path':'crates/adventuresim-world-schema/src/person_names.rs','local':'support/0.source','sha256':hashlib.sha256(raw).hexdigest(),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,274],[476,510]],'ordered_role_credit':0}
(b/'more-support-registration.json').write_text(json.dumps(d,indent=2)+'\n');print('sha256',hashlib.sha256((b/'more-support-registration.json').read_bytes()).hexdigest(),d['created_utc'])
