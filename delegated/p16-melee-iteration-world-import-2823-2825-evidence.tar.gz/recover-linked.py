from pathlib import Path
import hashlib,json
b=Path.cwd();orig=Path('<LOCAL_PATH_0>');h=lambda x:hashlib.sha256(x).hexdigest();man=json.loads((b/'historical-manifest.json').read_bytes());seen={x['local'] for x in man['records']};q=json.loads((b/'historical-selections-reconstructed.json').read_bytes())['queue_entries'];want={}
for e in q.values():
 for src in e['exact_source_identities_and_assessed_ranges']:
  for k in ['receipt','registration']:
   x=src.get(k)
   if isinstance(x,dict) and x.get('path') and x.get('sha256'):want[x['path']]=x['sha256']
missing=[]
for n,digest in want.items():
 src=(orig/n).resolve();assert src.is_relative_to(orig.resolve());local='historical/059/'+n
 if not src.is_file():missing.append({'original':n,'expected_sha256':digest});continue
 raw=src.read_bytes();assert h(raw)==digest,(n,h(raw));p=b/local;p.parent.mkdir(parents=True,exist_ok=True)
 if local in seen:assert p.read_bytes()==raw;continue
 p.write_bytes(raw);man['records'].append({'origin':str(src),'local':local,'sha256':digest,'bytes':len(raw),'kind':'Exact linked original 059 receipt; no prior author/scope transfer.'});seen.add(local)
man['linked_059_missing_originals']=missing;(b/'historical-manifest.json').write_text(json.dumps(man,indent=2)+'\n');print('linked',len(want),'missing',len(missing),'manifest',h((b/'historical-manifest.json').read_bytes()))
