from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');nav={};navigation=[]
files=['navigation-means.txt','navigation-events.txt','navigation-religion.txt','navigation-church.txt']
for name in files:
 lines=(b/name).read_text().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m,(name,line);path,num=m.group(1),int(m.group(2));nav.setdefault(path,set()).add(num)
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'registration':'navigation-registration.json','ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2823:{'old':[[1,269]],'current':[[1,270]]},2824:{'old':[[1,89]],'current':[[1,89]]},2825:{'old':[[681,717]],'current':[[681,717]]}};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']]['current' if j else 'old'];shown=nums(d);navonly=sorted(nav.get(row['path'],set())-shown) if j else []
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':navonly,'unread_after_assigned_and_navigation':comp(v['eof'],shown|set(navonly)),'qualification':'Historical and current source objects personally displayed separately after prospective registration; a120, 039 and 6533 stored comparisons are mechanical only. Diff of role2823 displayed after registration.'})
support=[]
for name in ['support-registration.json','support-registration-extra.json']:
 for x in load(name)['entries']:
  d=x['ranges'];shown=nums(d);prior=[]
  for row in reg['rows']:
   if row['path']==x['path']:prior=chunks[row['original_index']]['current']
  used=shown|nums(prior);navonly=sorted(nav.get(x['path'],set())-used)
  support.append({'name':x['name'],'registration':name,'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement_after_this_support_and_assigned':comp(x['eof'],used|set(navonly)),'qualification':'Other support entries for the same path remain separate; complement does not union those. Navigation-only test/fixture lines and macro text are not execution.','ordered_role_credit':0})
names=['registration.json','navigation-registration.json','support-registration.json','support-registration-extra.json']
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Newly reconstructed actual personal source displays and navigation after prospective registration; no historical reader credit transfer.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'limits':'Evidence/source only. No product, generated code, macro, test, fixture, build, runtime probe, repair or publication edit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('read-receipt sha256',h((b/'read-receipt.json').read_bytes()))
