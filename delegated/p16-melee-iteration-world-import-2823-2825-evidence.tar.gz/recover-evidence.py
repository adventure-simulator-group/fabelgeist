from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');orig=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');workspace=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/n,'recovered/'+n,'Original archive/registry and 059 where labelled, catalog reconstructed; later tracked patch recovery has separate custody and untracked qualifications.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-core/AGENTS.md','crates/adventuresim-tactical-server/src/combat/AGENTS.md','crates/strategic-web/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Governing current source rules; source-only prohibition prevails.')
for n in ['COVERAGE-L01-ROLES.json','ASSESSMENT-MELEE-REPORT-IDENTITY-95E.json','ASSESSMENT-L01-ITERATION-TIMEOUT-95E.json','ASSESSMENT-WORLD-SCHEMA-ADMISSION-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Prior published current assessment/recovery; original attribution, revision and scopes retained.')
copy('<LOCAL_PATH_4>','prior/WEB-PROJECTION-2389-REPORT.json','Earlier /root/hair_ops bounded role2389 report: one full equal-body display with source revision copy unspecified, not two reads; no credit transfer.')
for n in ['segovb/READ-L11-459.json','segovb/STATE-L11-459.json','segovb/VERIFY-L11-459.json','segovb/REGISTRATION-SEGOVB-1744.json','segovb/REGISTRATION-SEGOVB-1745.json','segovb/REGISTRATION-SEGOVB-1746.json']:
 copy(orig/n,'historical/059/'+n,'Exact original 059 historical receipt/registration; prior reviewer and scope unchanged.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
paths=[('camera','initial07-redundant-authority',n) for n in ['source-range-registration.jsonl','qualifications.jsonl','contracts.jsonl','findings.jsonl']]+[('root','admission03',n) for n in ['new-parallel-admission-180.json','new-parallel-admission-194.json']]+[('root','', 'parallel-scope-qualification-193.json')]
for owner,folder,n in paths:
 gp='/'.join(x for x in ['handoff/774/adler-original/audit/continuation',owner,folder,n] if x);raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{owner}-{n}','git:'+rev+':'+gp,'Exact 774 record via f82 transport; differing earlier registry-file hashes and row equality are retained.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw);qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw);cv=json.loads((b/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=[2823,2824,2825]
s={'kind':'Newly reconstructed selected historical and prior coverage rows, not an original record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in ids},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ('physical-p16','pr-working')],'queue_uncompressed_sha256':h(qraw),'queue_entries':{str(i):q['entries'][i] for i in [118,268,276,277,542]},'prior_coverage_sha256':h((b/'prior/COVERAGE-L01-ROLES.json').read_bytes()),'prior_coverage_roles':{str(i):next(x for x in cv['roles'] if x['original_index']==i) for i in ids},'qualification':'P16 dirty a120-based snapshot remains separate from 039 per-file origin/f82 transport and 95e; no checkpoint3821 promotion.'};(b/'historical-selections-reconstructed.json').write_text(json.dumps(s,indent=2)+'\n');(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'Original author/revision/range attribution retained; f82 transports evidence only.'},indent=2)+'\n');print('recovered',len(records),'manifest sha256',h((b/'historical-manifest.json').read_bytes()))
