# P16 melee report, decision logging and world import

This packet contains bounded source-only audit evidence for historical original
roles 2823–2825 and pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. `REPORT.json` gives the 13 partial
lens perspectives, source references, findings, questions and history. The
historical P16 objects are from a dirty a120-based snapshot; 039 is a per-file
catalog origin and f82 is evidence transport, not the P16 workspace HEAD.

`registration.json` and support and navigation registrations precede personal
displays. `read-receipt.json` lists exact old and current displays, independent
support, match-line-only navigation and unread complements. Archived bytes and
comparison revisions alone do not establish a source read. The reconstructed
role2823 diff shows formatting and optional trailing comma changes.

`historical-manifest.json` preserves 059 and 774 records, while selected rows and
registry hash qualification are explicitly reconstructed. Original Camera's
QUAL-167 excludes a premature world-import display; its later registered scope
is 681–717. The historical 774 registration file hashes differ from the f82
whole-file hash even though all three parsed row records agree; earlier
whole-file bytes are not recovered here. The prior reviewer, snapshot, lens,
recovery limitations and one earlier equal-body display remain distinct from
this source pass.

`git-proofs.json` and `git-objects/` retain 32 offline object/path proofs;
`recovered/MANIFEST.json` identifies the archived registry and source objects.
The later P16 tracked patch is a matching-digest recovery with separate command,
custody and untracked-file qualifications. `MANIFEST.json` includes every packet
file except itself, including nested manifests. Run `python3 verify-evidence.py`
for offline integrity verification only; no product code, fixtures, or tests run.
