from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
b=Path(__file__).resolve().parent
j={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'Prospective navigation matches only; support body ranges will be separately registered before display. No ordered-role credit.','queries':[{'name':'means','path':'crates/adventuresim-tactical-server/src/bin/melee_combat_iteration','patterns':['finish_means','contact_measure_samples','mean_attack_start_interval_seconds']},{'name':'events','path':'crates/adventuresim-tactical-server/src','patterns':['MeleeAttackCommittedToDefense','MeleeAttackTransformedByDefense']},{'name':'religion','path':['crates/adventuresim-stdb-module/src/strategic/world_import.rs','crates/strategic-web/src/spacetimedb/types.rs'],'patterns':['religious_status','religion_id']},{'name':'church','path':'crates','patterns':['fn church','fn religion_id']}]}
p=b/'navigation-registration.json';p.write_text(json.dumps(j,indent=2)+'\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
