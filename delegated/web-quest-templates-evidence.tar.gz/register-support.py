from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';ps=['crates/strategic-web/src/routes/quests.rs','crates/strategic-web/src/routes/missions.rs','crates/strategic-web/static/party-trade.js','crates/strategic-web/static/inventory-browser.js','crates/strategic-web/static/strategic-renderer.js','crates/strategic-web/src/spacetimedb/types.rs','crates/strategic-web/src/location_urls.rs','crates/strategic-web/src/location_urls/patterns.rs','crates/adventuresim-core/src/strategic_place.rs','crates/adventuresim-stdb-module/src/tactical.rs','crates/adventuresim-stdb-module/src/strategic/inventory_trade.rs','crates/adventuresim-stdb-module/src/surgery.rs','crates/strategic-web/src/routes/settlements/medical.rs'];entries=[];pending=[]
for p in ps:
 raw=subprocess.check_output(['git','show',rev+':'+p]);entries.append({'revision':rev,'path':p,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'registered_max_scope':[1,len(raw.splitlines())]});pending.append((p,raw))
r={'schema':'726-delegated-prospective-support-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity, quest templates','registration':'Prospective before symbol search/display for mission, quest, form and contextual care contracts; only actual ranges count, no other ordered role or lens credit.','entries':entries};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'support'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support registration sha256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
