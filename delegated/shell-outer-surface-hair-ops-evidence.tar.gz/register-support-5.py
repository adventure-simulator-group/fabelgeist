'''Prospective bounded ray query proof support.'''
import datetime,hashlib,json
from pathlib import Path
p=Path('<LOCAL_PATH_0>');prior=json.loads((p/'support-registration-2.json').read_bytes())['sources'];a=[]
for idx,ranges in [(2,[[265,299]]),(3,[[310,350],[435,448]])]:
 s=prior[idx].copy();s['prospective_ranges']=ranges;s['qualification']='Fresh current bounded ray support, no prior credit.';a.append(s)
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-5.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-5.json').read_bytes()).hexdigest())
