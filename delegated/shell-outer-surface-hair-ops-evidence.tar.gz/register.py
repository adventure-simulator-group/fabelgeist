'''Prospective source registration only; no source bodies displayed or product executed.'''
import datetime,gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
p=Path('<LOCAL_PATH_0>');pub=Path('<LOCAL_PATH_1>');h=lambda b:hashlib.sha256(b).hexdigest();regb=gzip.decompress((pub/'recovered/original-registry-source-archive/registry.json.gz').read_bytes());reg=json.loads(regb);rows=[];rev='95e63628f9d70b8dd6e6fede64334696c6995009';prev='6533e444fa37552927070cc8d8190907fd3b413e';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
with tarfile.open(pub/'recovered/original-registry-source-archive/objects.tar.gz','r:gz') as t:
 for i in (2668,):
  r=reg['files'][i];assert r['snapshot']=='pr-working';path=r['source_id'].split(':',1)[1];old=t.extractfile(r['sha256']).read();assert h(old)==r['sha256'] and len(old)==r['bytes'];fpath='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+r['sha256'];assert subprocess.check_output(['git','-C',str(pub),'show',f82+':'+fpath])==old
  bodies={}
  for revision in (prev,rev):
   result=subprocess.run(['git','-C',str(pub),'show',revision+':'+path],capture_output=True);b=result.stdout if result.returncode==0 else None
   if b is not None:
    bodies[revision]={'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'git_blob':subprocess.check_output(['git','-C',str(pub),'rev-parse',revision+':'+path],text=True).strip(),'equal_original':b==old};(p/f'source/{i}-{revision[:4]}.rs').write_bytes(b)
   else:bodies[revision]={'absent':True,'git_error':result.stderr.decode().strip()}
  (p/f'source/{i}-pr-working.rs').write_bytes(old);rows.append({'role':i,'original_registry_record':r,'path':path,'old_archive':f'source/{i}-pr-working.rs','old_sha256':h(old),'old_lines':len(old.splitlines()),'f82_transport_revision':f82,'f82_transport_path':fpath,'git_comparisons':bodies,'prospective_display':{'pr_working':[[1,len(old.splitlines())]],'current95e':[[1,bodies[rev]['lines']]] if 'lines' in bodies[rev] else []},'qualification':'Prospective full personal displays of original archived pr-working and current 95e separately. 6533 equality does not confer separate historical body read or whole pr-working clean-tree status.'})
out={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','current_revision':rev,'comparison_revision':prev,'registry_uncompressed_sha256':h(regb),'source_archive_sha256':h((pub/'recovered/original-registry-source-archive/objects.tar.gz').read_bytes()),'rows':rows,'rules':'Source inspection only; no repairs/builds/tests/probes/product.'};(p/'registration.json').write_text(json.dumps(out,indent=2)+'\n'); print('registration sha256',h((p/'registration.json').read_bytes()))
for r in rows:print('role',r['role'],'old',r['old_sha256'],'lines',r['old_lines'],'comparisons',json.dumps(r['git_comparisons']))
