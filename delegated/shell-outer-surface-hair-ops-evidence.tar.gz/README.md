# Bounded outer-layer surface source evidence

`REPORT.json` records `/root/hair_ops` review of original role 2668, bounded
current support, historical relationships and thirteen partial perspectives.
This packet is not whole-audit completion, a repair, product validation, or a
substitute for the unrecovered final checkpoint 3821.

`registration.json` prospectively registered the old and current source bodies;
`support-registration*.json` separately registered each support window before
its display. `read-receipt.json` records actual reads and unread complements,
including repeated overlapping support windows without duplicate credit. The
pr-working, 6533, earlier e275 and current 95e files match per file; historical
pr-working has unrelated modifications and no clean-tree claim is made.

`git-proofs.json` and `git-objects/` preserve Git membership. `historical/`
retains exact selected 059 receipts, compressed complete 059 adoption, clearly
reconstructed 774 finding and 059 queue selections, and small exact earlier
role2658 support records. `historical-manifest.json` hash-links prior published
evidence; `MANIFEST.json` fixes this packet's bytes.

Run `python3 verify-evidence.py` for evidence-integrity checks only. It checks
source identity, actual read coverage, Git proofs, historic attributions,
reconstructed values and evidence hashes. It does not execute the product,
geometry, solver, rays, BVH, shader, test, fixture, simulation or repair code.
