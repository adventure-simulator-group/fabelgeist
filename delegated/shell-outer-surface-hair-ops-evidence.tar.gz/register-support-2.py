'''Prospective numerical and bounded broad-phase support, source only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[('crates/fabelgeist-xpbd/src/dynamics/mass.rs',[[1,115]]),('crates/fabelgeist-shell/src/topology.rs',[[115,135]]),('crates/fabelgeist-bvh/src/aabb.rs',[[30,115]]),('crates/fabelgeist-bvh/src/cpu/mod.rs',[[65,90],[245,275]])];a=[]
for i,(path,ranges) in enumerate(paths,4):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':[[x,min(y,eof)] for x,y in ranges if x<=eof],'qualification':'Fresh current bounded support; no historical or ordered-role credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-2.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-2.json').read_bytes()).hexdigest());print([(x['path'],x['eof'],x['prospective_ranges']) for x in a])
