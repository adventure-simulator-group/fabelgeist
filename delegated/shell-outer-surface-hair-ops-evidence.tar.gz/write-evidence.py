'''Record actual displays and clearly reconstructed historical selection.'''
import datetime,gzip,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());g=(p/'historical/059-audit03-adopted-findings.json.gz').read_bytes();b=gzip.decompress(g);a=json.loads(b);ids=['RIG-ADMISSION03-F082','RIG-ADMISSION03-F083','RIG-ADMISSION03-F090'];selected=[{'source_index_zero_based':i,'value':x} for i,x in enumerate(a) if x.get('record',{}).get('id') in ids];assert len(selected)==len(ids);o={'kind':'Reconstructed selection from exact retained 059 adoption, not a claim of complete 774 original findings archive','source_sha256':h(b),'retained_gzip':'historical/059-audit03-adopted-findings.json.gz','retained_gzip_sha256':h(g),'selected':selected,'qualification':'Original 774 supplier and archive/record-index references retained, no checkpoint3821 promotion.'};(p/'historical/774-selected-reconstructed-from-059.json').write_text(json.dumps(o,indent=2)+'\n')
prior=Path('<LOCAL_PATH_0>');files=['report.json','BUNDLE-MANIFEST.json','support-read-receipt.json','support-registration.json'];extra={'prior_outer2658':{'path':str(prior),'author':'/root/mhr_character','records':[{'original':x,'local':'historical/prior-outer-2658-'+x,'sha256':h((p/('historical/prior-outer-2658-'+x)).read_bytes())} for x in files],'qualification':'Earlier current 95e support surface.rs 1–103, unread 104–215; original role2658 packet retains its own authorship, registration, and no role2668 credit.'}};(p/'additional-evidence.json').write_text(json.dumps(extra,indent=2)+'\n')
regs=['registration.json']+['support-registration'+('-'+str(i) if i>1 else '')+'.json' for i in range(1,8)];s=[]
for n in regs[1:]:
 for x in load(n)['sources']:
  if not any(y['saved']==x['saved'] for y in s):s.append(x)
d={'support/00.rs':[[1,116]],'support/01.rs':[[30,55],[75,90],[340,385]],'support/02.rs':[[1,180]],'support/03.rs':[[85,129]],'support/04.rs':[[1,115]],'support/05.rs':[[115,135]],'support/06.rs':[[30,115],[265,299]],'support/07.rs':[[65,90],[245,275],[35,70],[350,425],[80,135],[310,350],[435,448],[1,34],[449,462]]}
def comp(n,rs):
 covered={i for a,z in rs for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in covered:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
support=[{'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['eof'],'displayed':d[x['saved']],'unread_complement':comp(x['eof'],d[x['saved']]),'qualification':'Fresh prospectively registered current support only; overlapping display windows are recorded as displayed without duplicating coverage.'} for x in s];assigned=[{'role':2668,'pr_working_actual_display':[[1,110],[111,215]],'current_95e_actual_display':[[1,110],[111,215]],'unread_old_and_current':[]}];o={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in regs],'assigned':assigned,'support':support,'limits':'Recorded assigned and bounded supporting personal displays; historical and other-agent reads remain separate. Test text was not executed.'};(p/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n');print('reconstructed',[(x['source_index_zero_based'],x['value']['record']['id']) for x in selected])
