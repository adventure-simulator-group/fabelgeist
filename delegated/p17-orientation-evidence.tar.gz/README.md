# Report-p17 orientation and bouncy-bone source review

This packet records `/root/mhr_character`'s bounded source inspection of
original roles 2436–2437 at the separately frozen report-p17 revision
`90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696`, and the pinned current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The original registry's
`/snapshots/2` identifies the clean P17 head and base; matching 774 source copies,
registry hashes and Git commit/tree/blob objects prove the two historical bytes.
Both historical and current bodies were independently displayed after prospective
registration. P17 is not the pr-working 6533 snapshot.

`report.json` records the existing numerical-closure finding, its current
telemetry/report consequence, exact P17 admission contrast, source references,
qualifications, future repair directions, thirteen bounded lens perspectives,
nonfindings and open questions. Both source differences are preserved as patches.
The P17 base and pr-working-head source archives are proof-only, with no personal
body-read credit. Support source reads and their actual ranges are separate.

`historical-059` contains original records checked against the 059 transport
manifest; the full original compressed registry and queue are in `reference/`.
Selected queue and registry records are reconstructed navigation subsets only.
The P17 nested Windows-locator qualification was historically recorded after
body display and grants no retroactive qualification or read credit. Older 774
original and normalized export bytes are separate; the original canonical
`NATIVE-INITIAL05-F013` finding and 391 historical summary are preserved. Nothing
is promoted to checkpoint 3821.

`evidence-verification.json` documents evidence-only integrity checks, and the
bundle manifest lists every file except itself. This packet contains no repairs,
tests, viewer, browser, fixture generation, product builds, native diagnostics,
or runtime probes. The user's explicit stop before product validation overrides
the animation guide's later diagnostic workflow. Central coordination owns
baseline, reconciliation, repair ledger, and publication.
