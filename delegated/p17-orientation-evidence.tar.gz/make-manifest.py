import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');m=p/'BUNDLE-MANIFEST.json';files=[]
for f in sorted(x for x in p.rglob('*') if x.is_file() and x!=m):
 b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m.write_text(json.dumps({'schema':'726-delegate-bundle-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'self_excluded':True,'qualification':'Exact current packet inventory, separate recovered original evidence and reconstructed indices, prior-author packets and newly assessed work. No product execution.','files':files},indent=2)+'\n')
print('files',len(files),'manifest_sha256',hashlib.sha256(m.read_bytes()).hexdigest())
