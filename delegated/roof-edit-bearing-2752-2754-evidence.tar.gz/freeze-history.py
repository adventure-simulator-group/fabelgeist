from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
ex=Path('<LOCAL_PATH_1>')
sha=lambda d:hashlib.sha256(d).hexdigest()
oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d)
 return {'preserved':str(p),'sha256':sha(d),'bytes':len(d)}
refs=[]
for src,dest,kind in [
 ('recovered/original-registry-source-archive/registry.json.gz','history/original-registry.json.gz','original recovered registry'),
 ('recovered/original-transport-manifest.json.gz','history/original-transport-manifest.json.gz','original 059 transport manifest'),
 ('RECOVERY-PHYSICAL-P16-PATCH-20261111.json','history/p16-patch-recovery.json','later independent tracked-patch reproduction report'),
 ('recovered/physical-p16-patch-recovery/tracked.patch','history/p16-tracked.patch','later matching P16 tracked patch; seven untracked paths excluded'),
 ('ASSESSMENT-DELEGATED-RECONCILIATION-11B-95E.json','history/assessment-roof-context-11b.json','prior 95e apse/roof-edit support with own author'),
 ('ASSESSMENT-DELEGATED-RECONCILIATION-11C-95E.json','history/assessment-roof-contacts-11c.json','peer current roof contact reconciliation'),
 ('ASSESSMENT-L01-BEARING-AREA-95E.json','history/assessment-breteche-bearing-95e.json','prior current planar bearing-area assessment')]:
 refs.append({'kind':kind,'original':src,**save((pub/src).read_bytes(),dest)})
for src,dest in [('baseline-059/queue.json','history/baseline-059-queue.json.gz'),('baseline-059/ledger.json','history/baseline-059-ledger.json.gz')]:
 raw=(pub/src).read_bytes();refs.append({'kind':'059 historical summary mechanically compressed; not final 3821','original':src,'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(gzip.compress(raw,mtime=0),dest)})
registry=json.loads(gzip.decompress((b/'history/original-registry.json.gz').read_bytes()));idx={v['path']:v for v in json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()))['entries']}
inds=[2752,2753,2754]
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-registry-reconstruction-v1','qualification':'Mechanically selected rows from retained original registry; do not promote earlier state into missing checkpoint3821.','rows':[{'original_index':i,**registry['files'][i]} for i in inds],'snapshots':[x for x in registry['snapshots'] if x['id'] in ('physical-p16','pr-working')]},indent=2)+'\n')
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries'];qi=[2258,2308]
(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-selected-059-queue-reconstruction-v1','qualification':'Mechanically selected historical queue rows, no new status/count or assumed alias.','entries':[{'original_index_zero_based':i,'entry':q[i]} for i in qi]},indent=2)+'\n')
paths=['segovb/READ-L11-414.json','segovb/READ-L11-419.json','segovb/READ-L11-420.json','segovb/READ-L11-450.json','segovb/READ-L11-451.json','segovb/REGISTRATION-SEGOVB-1671.json','segovb/REGISTRATION-SEGOVB-1672.json','segovb/REGISTRATION-SEGOVB-1673.json','segovb/STATE-L11-450.json','segovb/VERIFY-L11-450.json','segovb/STATE-L11-451.json','segovb/VERIFY-L11-451.json','parallel-l12-20261029/REGISTRATION-PAR-L12-582.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-582-WINDOWS-ORIGINAL2752.json','parallel-l12-20261029/REGISTRATION-PAR-L12-583.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-865-ROOF-OWNED-ERROR-POLICY.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-CONNECTED-TEAM019.json','segovb/READ-L12-CONNECTED-TEAM-019.json','segovb/STATE-L12-CONNECTED-TEAM-019.json','segovb/VERIFY-L12-CONNECTED-TEAM-019.json']
records=[]
for p in paths:
 raw=(ex/p).read_bytes();m=idx[p];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob']
 records.append({'original_path':p,'git_blob':m['git_blob'],**save(raw,'history/059/'+p)})
old=[];prefix='handoff/774/adler-original/audit/continuation/'
for p in ['native/initial05-aggregate-states/source-range-registration.jsonl','native/initial05-aggregate-states/source-qualifications.jsonl','native/initial05-aggregate-states/contract-groups-010.json','native/initial05-aggregate-states/findings.jsonl','root/initial04-invariant-operations/source-range-registration.jsonl','root/initial04-invariant-operations/coverage.jsonl','root/initial04-invariant-operations/contract-groups-003.json','root/initial04-invariant-operations/findings.jsonl']:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+prefix+p]);old.append({'revision':rev,'transport_path':prefix+p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'history/774/'+p+'.gz')})
prior=[]
for directory in ['<LOCAL_PATH_2>','<LOCAL_PATH_3>']:
 d=Path(directory);manifest='packet-manifest.json';report='report.json';mraw=(d/manifest).read_bytes();m=json.loads(mraw)
 for f in m['files']:
  raw=(d/f['path']).read_bytes();assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
 archive=b/('history/'+d.name+'-exact-local.tar.gz')
 with tarfile.open(archive,'w:gz') as t:
  for f in sorted(d.rglob('*')):
   if f.is_file():t.add(f,arcname=str(f.relative_to(d)),recursive=False)
 prior.append({'original_directory':directory,'author':'/root/hair_ops','manifest_name':manifest,'manifest_sha256':sha(mraw),'report_name':report,'report_sha256':sha((d/report).read_bytes()),'qualification':'Exact prior local packet preserved with its original author, distinct role and source scope; public path-redacted copies are reconstructed and have separate hashes.','preserved':str(archive.relative_to(b)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size})
mismatch={'root':{'registry_recorded':'fac20d5f701303cb5bd5d6d1671d1d15b7d869cb5c6d49e58c7e56ab7a62a17f','f82_actual':'44adb80f029797f8356f93ac8d236d38b82db5611fc5b03ac4d427715c969bf5'},'native':{'registry_recorded':'a55052656e8d8119bf9df849d6786c589de4ad51b3a635ed898256cddf1e69bc','f82_actual':'0bb2e7a6198efc2e3db19800dd507c9a5ec91dc47c9fa388e612162d133f5bed'},'qualification':'Each selected parsed f82 registration row equals registry embedded original_record, while whole-file digests differ. Registry-hash whole-file variants were not located in inspected collections. Cause unknown; neither row equality nor f82 provenance proves whole-file identity.'}
out={'schema':'726-roof-edit-bearing-historical-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'records_059':records,'records_774':old,'registration_file_hash_mismatch':mismatch,'prior_packets':prior,'qualification':'059 extracted bytes match original manifest size/SHA/Git blob; 059 payload Git path unavailable in inspected stores. f82 is evidence transport only. The independently reproduced P16 tracked patch proves matching bytes, not original invocation, clean original or uninterrupted custody; seven untracked paths excluded. No 3821 promotion.'}
(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n')
print('references',len(refs),'059',len(records),'774',len(old),'prior archive bytes',[x['bytes'] for x in prior])
