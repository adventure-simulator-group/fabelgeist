from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent
chunks={'roof-producer':[[499,549],[550,600]],'envelope-owner':[[1,34],[35,68]],'generation-owner':[[190,226],[227,263],[264,300]],'gable-owner':[[1,45],[46,90],[91,135]],'network-owner':[[65,105]],'bearing-caller':[[1,55]],'bounds-helper':[[1,33],[34,65],[225,245]],'oriented-overlap':[[1,50],[51,100]],'roof-plane':[[1,35],[400,445]],'building-plan':[[1,53]],'roof-assembly':[[250,285],[286,320]],'orchestration':[[1,50],[51,100]],'generate-audit':[[301,311]],'solid-type':[[60,92],[93,125],[345,372],[373,400]]}
out={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':[],'entries':[]}
for fname in ['support-registration.json','support-registration-2.json']:
 raw=(b/fname).read_bytes();reg=json.loads(raw);out['registrations'].append({'path':fname,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for e in reg['entries']:
  ch=chunks[e['id']];covers={i for a,z in ch for i in range(a,z+1)};missing=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covers and start is None:start=i
   elif (i>e['eof'] or i in covers) and start is not None:missing.append([start,i-1]);start=None
  out['entries'].append({'registration':fname,'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':missing,'qualification':'Personally displayed current support only; no historic role credit; any test text merely read, not run.'})
(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('recorded',len(out['entries']),'support reads')
