import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'registration.json').read_bytes());rows=[]
def collapse(ns):
 out=[]
 for i in sorted(ns):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
def n(rs):return {i for a,b in rs for i in range(a,b+1)}
for e in r['entries']:
 chunks=e['registered_ranges'];extra=[]
 if e['tag']=='json-number':chunks=[[525,575],[576,625]]
 if e['tag']=='p16-lock':chunks=[[9794,9802],[9814,9827]]
 if e['tag']=='current-lock':chunks=[[9397,9405],[9417,9430]]
 if e['tag']=='current-validator':extra=[24,133,301,1148]
 additional=[[133,160]] if e['tag']=='current-validator' else [];seen=n(chunks)|n(additional)|set(extra);rows.append({'additional_parse_registration_chunks':additional,'tag':e['tag'],'kind':e['kind'],'role':e.get('role'),'archive':e['archive'],'sha256':e['sha256'],'EOF':e['EOF'],'displayed_chunks':chunks,'registered_navigation_singletons':extra,'all_personally_displayed_union':collapse(seen),'unread_complement':collapse(set(range(1,e['EOF']+1))-seen)})
(p/'read-receipt.json').write_text(json.dumps({'author':'/root/mhr_character','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration':'registration.json','registration_sha256':sha((p/'registration.json').read_bytes()),'navigation_registration':'navigation-registration.json','navigation_registration_sha256':sha((p/'navigation-registration.json').read_bytes()),'navigation_actual':{'range_1100_1365_function_matches':[1148],'MAX_DIAGNOSTICS_matches':[24,301],'parse_document_matches':[133]},'parse_navigation_registration_sha256':sha((p/'parse-navigation-registration.json').read_bytes()),'parse_registration_sha256':sha((p/'parse-registration.json').read_bytes()),'entries':rows,'qualification':'Numbered untruncated actual source displays followed prospective registrations; navigation singleton hits have separate registration. Historical P16, current project and native packages are distinct; archives and lock metadata parsing confer no full-body reading or feature-resolution credit.'},indent=2)+'\n')
