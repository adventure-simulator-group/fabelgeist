# Bounded catalog validator and native decoder review

`report.json` records independent source assessment for original roles
2587–2590 and related current support. `registration.json`, navigation/parse
registrations and `read-receipt.json` preserve exact personal displays and
unread complements. The recovered P16 validator, pinned native package members,
P16 lock and current project source are distinct identities. The original
registry uses `pinned-cargo` in native role rows but has no snapshot-list row
with that identifier; the label is retained without normalization.

`059-selection-reconstructed.json` selects six exact historical queue records
and their journal links from separately retained complete earlier 059 data.
Original 059 and f82-transported 774 records are indexed and verified; the
historic P16 schema, earlier authors and checkpoint 15 delegate scopes are not
transferred into a current or checkpoint3821 claim. Git commit/tree proofs,
package archives, source members and lock stanzas are retained. The later matching
tracked P16 patch excludes seven separately accounted untracked paths and does
not prove the original command.

`verification.json` is evidence integrity only. Run `python3 verify-evidence.py`
and `python3 verify-manifest.py` for offline checks of this packet. These checks
do not execute a parser, macro, product, fixture, build, test or probe. Original
local records may contain local paths; checkpoint publication metadata retains
the public redaction qualifications. No lens closure, automatic alias or
duplicate count is asserted.
