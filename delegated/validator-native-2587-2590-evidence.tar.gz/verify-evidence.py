import datetime,gzip,hashlib,io,json,pathlib,re,tarfile,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes())
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(v==reg['files'][int(k)] for k,v in sel['roles'].items()) and not any(s['id']=='pinned-cargo' for s in reg['snapshots'])
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256']
patch=(p/'reference/tracked.patch').read_bytes();recovery=load('reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert sha(patch)==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(patch)==recovery['recovered_patch']['bytes'] and recovery['live_comparison']['status_counts']['??']==7
r=load('registration.json');t=load('read-receipt.json');assert t['registration_sha256']==sha((p/'registration.json').read_bytes()) and len(r['entries'])==len(t['entries'])==13
for f in ['registration.json','navigation-registration.json','parse-navigation-registration.json','parse-registration.json']:
 a=load(f);assert datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(a['registered_utc'])
for k,f in [('navigation_registration_sha256','navigation-registration.json'),('parse_navigation_registration_sha256','parse-navigation-registration.json'),('parse_registration_sha256','parse-registration.json')]:assert t[k]==sha((p/f).read_bytes())
def nums(rs):return {i for lo,hi in rs for i in range(lo,hi+1)}
for e,v in zip(r['entries'],t['entries']):
 b=(p/e['archive']).read_bytes();assert e['tag']==v['tag'] and sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'];assert nums(e['registered_ranges'])==nums(v['displayed_chunks']);seen=nums(v['displayed_chunks'])|nums(v['additional_parse_registration_chunks'])|set(v['registered_navigation_singletons']);unseen=nums(v['unread_complement']);assert seen==nums(v['all_personally_displayed_union']) and seen|unseen==set(range(1,e['EOF']+1)) and not seen&unseen
 if e['tag']=='current-validator':assert nums(v['additional_parse_registration_chunks'])==nums(load('parse-registration.json')['registered_ranges']) and set(v['registered_navigation_singletons'])=={24,133,301,1148}
 else:assert not v['additional_parse_registration_chunks'] and not v['registered_navigation_singletons']
 if e.get('role') in (2588,2589,2590) or e['tag']=='p16-validator':assert e['sha256']==reg['files'][e['role']]['sha256']
 if e['tag']=='p16-lock':assert e['sha256']==reg['files'][39]['sha256']
lines=(p/'source/current-validator.source').read_text().splitlines();assert [i for i,s in enumerate(lines,1) if 1100<=i<=1365 and re.search(r'(?:^|\s)(?:fn|pub fn) ',s)]==[1148];assert [i for i,s in enumerate(lines,1) if 'MAX_DIAGNOSTICS' in s]==[24,301];assert [i for i,s in enumerate(lines,1) if 'fn parse_document' in s]==[133]
old=(p/'source/p16-validator.source').read_bytes().splitlines(keepends=True);cur=(p/'source/current-validator.source').read_bytes().splitlines(keepends=True);assert old[:1492]==cur[:1492] and len(old)==2053 and len(cur)==2059 and sha(b''.join(old))!=sha(b''.join(cur))
packages={z['name']+'-'+z['version']:z for z in r['packages']}
for z in packages.values():assert sha((p/z['archive']).read_bytes())==z['sha256']
for e in r['entries']:
 if e['kind']=='pinned-cargo-native':
  with tarfile.open(fileobj=io.BytesIO((p/packages[e['package']]['archive']).read_bytes()),mode='r:gz') as tar:assert tar.extractfile(e['member']).read()==(p/e['archive']).read_bytes()
for e in r['entries']:
 if 'lock' in e['kind']:
  pkgs=tomllib.loads((p/e['archive']).read_text())['package']
  for z in packages.values():
   found=[v for v in pkgs if v['name']==z['name'] and v['version']==z['version']];assert len(found)==1 and found[0]['source']=='registry+https://github.com/rust-lang/crates.io-index' and found[0]['checksum']==z['sha256']
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());lraw=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());q=json.loads(qraw);l=json.loads(lraw);x=load('059-selection-reconstructed.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for path,v in x['journal_entries'].items():
 z=l
 for part in path.strip('/').split('/'):z=z[int(part)] if isinstance(z,list) else z[part]
 assert z==v
assert all(not q['entries'][i]['exact_source_identities_and_assessed_ranges'] and not q['entries'][i]['source_receipt_contexts'] for i in (602,604));assert len(q['entries'][2435]['granular_contract_views'])==2 and q['entries'][2434]['granular_contract_views'][0]['contract_update_as_proposed']['contract_id_or_proposed_new_id']==q['entries'][2391]['contract_id']
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for lens,n in [('L11',424),('L11',425),('L12',878),('L12',879),('L12',880)]:
 read=(p/f'history-059/segovb/READ-{lens}-{n}.json').read_bytes();state=(p/f'history-059/segovb/STATE-{lens}-{n}.json').read_bytes();v=load(f'history-059/segovb/VERIFY-{lens}-{n}.json');assert v['receipt_sha256']==sha(read) and v['state_sha256']==sha(state)
for n in (424,425):
 read=load(f'history-059/segovb/READ-L11-{n}.json')
 for e in read['sources']:
  if e['original_index'] not in (2587,2588,2589,2590):continue
  rel=e['registration'].split('target/726-audit-adler-20261027/',1)[1];assert e['registration_sha256']==sha((p/'history-059'/rel).read_bytes()) and e['sha256']==reg['files'][e['original_index']]['sha256']
for n in (878,879,880):
 read=load(f'history-059/segovb/READ-L12-{n}.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes())
 for e in read['rows']:
  if e['original_index'] not in (2587,2588,2589,2590):continue
  assert e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes()) and e['source_sha256']==reg['files'][e['original_index']]['sha256']
for n in (2433,2434,2435):
 for v in q['entries'][n]['granular_contract_views']:
  a=v['root_adoption'];assert a['sha256']==sha((p/'history-059'/a['path']).read_bytes()) and a['verification_sha256']==sha((p/'history-059'/a['verification']).read_bytes())
prior=load('prior-index.json')
for z in prior['packets']:
 m=(p/('prior-'+z['label'])/z['manifest']).read_bytes();assert sha(m)==z['manifest_sha256'];index={e['path']:e for e in json.loads(m)['files']}
 for e in z['selected_files']:
  b=(p/('prior-'+z['label'])/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(index[e['path']]['bytes'],index[e['path']]['sha256'])
pub=load('reference/DELEGATED-EVIDENCE-CHECKPOINT-15.json')
for bundle,label,member,published in [('p16-main-validator-serde','rig','REPORT.json','published-validator-report.json'),('serde-json-number','json','report.json','published-json-report.json')]:
 z=next(x for x in pub['bundles'] if x['bundle_id']==bundle);old=next(x for x in z['members'] if x['path']==member);assert z['archive_sha256']==next(x['sha256'] for x in prior['published_archives'] if x['bundle']==bundle) and old['original_sha256']==sha((p/('prior-'+label)/member).read_bytes()) and old['published_sha256']==sha((p/'reference'/published).read_bytes())
pin=hist['rig_registration_pin_qualification'];rec=json.loads(gzip.decompress((p/'history-774/continuation/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));rreg=gzip.decompress((p/'history-774/continuation/rig/admission03/source-range-registration.jsonl.gz').read_bytes());rq=gzip.decompress((p/'history-774/continuation/rig/admission03/source-qualifications.jsonl.gz').read_bytes());assert rec['input_pins'][3]['sha256']==pin['root046_rig_registration_expected']!=sha(b''.join(rreg.splitlines(keepends=True)[:35]))==pin['later_first35_sha256'];assert rec['input_pins'][4]['sha256']==pin['root046_qualification_expected']==sha(b''.join(rq.splitlines(keepends=True)[:31]))==pin['later_first31_qualification_sha256']
quals={z['registration_id_resolved']:z['original_record'] for z in rec['role_qualifications'] if z.get('supplier')=='rig' and 'registration_id_resolved' in z}
for role,n in ((2587,20),(2588,21),(2589,22),(2590,23),(2590,25)):
 z=quals[f'RIG-ADMISSION03-REGISTER-{n:03}'];obs=next(o for o in reg['files'][role]['admission03_scope_observations'] if o['registration_id']==f'RIG-ADMISSION03-REGISTER-{n:03}');assert z['source_id']==reg['files'][role]['source_id'] and z['original_ranges']==obs['original_record']['material_ranges'] and z['actual_material_body_ranges']==obs['effective_material_ranges']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==23 and len(report['lens_perspectives'])==13 and [z['index'] for z in report['historical_relations']['selected_059_queue']]==[602,604,2391,2433,2434,2435]
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_sources':len(r['entries']),'git_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(hist['records']),'selected_queue_entries':6,'prior_packets':3,'lens_perspectives':13,'qualification':'Evidence-only checks: exact source/package/lock identities, registered personal windows and navigation, 059/774 attribution and pin mismatch, prior packet/redaction identities, dirty P16 tracked patch and seven exclusions, raw Git paths. No feature resolution, parser, product, build, test, fixture, macro or probe execution.'},indent=2))
