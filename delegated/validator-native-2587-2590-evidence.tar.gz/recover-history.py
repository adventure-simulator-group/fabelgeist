import gzip,hashlib,json,pathlib,shutil,subprocess
p=pathlib.Path(__file__).parent;pub=pathlib.Path('<LOCAL_PATH_0>');old=pathlib.Path('<LOCAL_PATH_1>');sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();(p/'reference').mkdir(exist_ok=True);refs=[]
for src,dst in [('recovered/original-registry-source-archive/registry.json.gz','registry.json.gz'),('recovered/original-transport-manifest.json.gz','original-transport-manifest.json.gz'),('RECOVERY-PHYSICAL-P16-PATCH-20261111.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json'),('recovered/physical-p16-patch-recovery/tracked.patch','tracked.patch'),('DELEGATED-CHECKPOINT-15-QUALIFICATION.json','DELEGATED-CHECKPOINT-15-QUALIFICATION.json'),('DELEGATED-EVIDENCE-CHECKPOINT-15.json','DELEGATED-EVIDENCE-CHECKPOINT-15.json'),('delegated/p16-main-validator-serde-report.json','published-validator-report.json'),('delegated/serde-json-number-report.json','published-json-report.json'),('ASSESSMENT-L03-CATALOG-DIMENSIONS-95E.json','ASSESSMENT-L03-CATALOG-DIMENSIONS-95E.json')]:
 b=(pub/src).read_bytes();(p/'reference'/dst).write_bytes(b);refs.append({'publication_path':src,'file':'reference/'+dst,'sha256':sha(b),'bytes':len(b)})
assert sha((p/'reference/tracked.patch').read_bytes())=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for name,expected in [('queue','2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'),('ledger','3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac')]:
 b=(pub/f'baseline-059/{name}.json').read_bytes();assert sha(b)==expected;(p/f'reference/{name}.json.gz').write_bytes(gzip.compress(b,mtime=0));refs.append({'publication_path':f'baseline-059/{name}.json','file':f'reference/{name}.json.gz','encoding':'gzip','sha256':sha(b),'bytes':len(b),'qualification':'Earlier reconstructed 059, not checkpoint3821.'});globals()[name]=json.loads(b)
qs=(602,604,2391,2433,2434,2435);journals={}
for i in qs:
 for path in queue['entries'][i].get('journal_revisits',[]):
  z=ledger
  for part in path.strip('/').split('/'):z=z[int(part)] if isinstance(z,list) else z[part]
  journals[path]=z
path='/segovb_continuation/lens13/delegated_connected_contracts_pending_alias/281';journals[path]=ledger['segovb_continuation']['lens13']['delegated_connected_contracts_pending_alias'][281]
(p/'059-selection-reconstructed.json').write_text(json.dumps({'queue_source_sha256':sha((pub/'baseline-059/queue.json').read_bytes()),'entries':{str(i):queue['entries'][i] for i in qs},'ledger_source_sha256':sha((pub/'baseline-059/ledger.json').read_bytes()),'journal_entries':journals,'qualification':'Exact earlier 059 selection; 602/604 have empty source identity receipts, other entries preserve attributed granular views and both 2435 views; no automatic aliases.'},indent=2)+'\n');(p/'reference-index.json').write_text(json.dumps({'records':refs},indent=2)+'\n')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);(p/'registry-selection-reconstructed.json').write_text(json.dumps({'registry_sha256':sha(raw),'roles':{str(i):reg['files'][i] for i in (39,2587,2588,2589,2590)},'snapshots':{name:next(s for s in reg['snapshots'] if s['id']==name) for name in ('physical-p16',)},'pinned_cargo_snapshot_row':'not present in registry snapshot list; original role snapshot fields remain pinned-cargo and exact package member evidence is independently verified','qualification':'Exact registry fields; native package snapshots and dirty physical P16 are not clean product Git revisions.'},indent=2)+'\n')
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};wanted=set()
def walk(o):
 if isinstance(o,dict):
  for v in o.values():walk(v)
 elif isinstance(o,list):
  for v in o:walk(v)
 elif isinstance(o,str):
  rel=o.split('target/726-audit-adler-20261027/',1)[-1]
  if rel in idx:wanted.add(rel)
for i in qs:walk(queue['entries'][i])
for lens,n in [('L11',424),('L11',425),('L12',878),('L12',879),('L12',880)]:
 for prefix in ('READ','STATE','VERIFY'):wanted.add(f'segovb/{prefix}-{lens}-{n}.json')
wanted.update([f'segovb/REGISTRATION-SEGOVB-{n}.json' for n in (1498,1499,1500,1501)])
for n,role in [(638,2587),(650,2588),(651,2589),(652,2590)]:wanted.update([f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json',f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{n}-WINDOWS-ORIGINAL{role}.json'])
wanted.update(['parallel-l12-20261029/'+z for z in ['PROPOSAL-L12-878.json','PROPOSAL-L12-879.json','PROPOSAL-L12-880.json','PARTIAL-PAR-L12-879-001.json','PARTIAL-PAR-L12-880-001.json','READ-CONNECTED-PAR-L12-879-SERDE-LOCK-AUTHORITY.json','REGISTRATION-PAR-L12-648.json','REGISTRATION-PAR-L12-649.json','PROPOSAL-BUNDLE-PAR-L12-873-880-v2.json']]);wanted.update(['segovb/READ-L13-PARALLEL-173.json','parallel-l13-20261029/READ-PL13-175.json','parallel-l13-20261029/VERIFY-PL13-175.json','parallel-l13-20261029/REGISTRATION-PL13-175.json','parallel-l13-20261029/VALIDATION-PROPOSAL-PL13-173-175.json'])
records=[];missing=[]
for rel in sorted(wanted):
 if rel not in idx or not (old/rel).is_file():missing.append({'path':rel,'in_transport_manifest':rel in idx,'in_extraction':(old/rel).is_file()});continue
 b=(old/rel).read_bytes();e=idx[rel];assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']);dst=p/'history-059'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);records.append({'kind':'original-059','transport_path':rel,'file':str(dst.relative_to(p)),'sha256':sha(b),'bytes':len(b),'git_blob':blob(b)})
priors=[('rig','<LOCAL_PATH_2>','MANIFEST.json','285b056edaefbb9e72100b9d729030b32aa0f602bd49099c42ac5280c2c1112f',['REPORT.json','registration.json','personal-read-receipt.json','support-registration.json','historical-attribution.json']),('json','<LOCAL_PATH_3>','BUNDLE-MANIFEST.json','260836a10fef67e1af7d0197e5cdbd6ccf4debf49b12592fe576e7d43c06694e',['report.json','registration.json','read-receipt.json','support-read-receipt.json','historical-059-index.json','historical-774-index.json']),('numeric','<LOCAL_PATH_4>','BUNDLE-MANIFEST.json','cc940476c2302efc1c3c8a9facd5d4f67be8c89822495484a98b1bcbf1b8c6b2',['report.json','registration.json','read-receipt.json','drop-read-receipt.json'])];priorrows=[]
for label,path,mname,expected,selection in priors:
 prior=pathlib.Path(path);dst=p/('prior-'+label);dst.mkdir(exist_ok=True);b=(prior/mname).read_bytes();assert sha(b)==expected;(dst/mname).write_bytes(b);index={e['path']:e for e in json.loads(b)['files']};selected=[]
 for rel in selection:
  b=(prior/rel).read_bytes();assert (len(b),sha(b))==(index[rel]['bytes'],index[rel]['sha256']);(dst/rel).write_bytes(b);selected.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
 priorrows.append({'label':label,'original_path':path,'manifest':mname,'manifest_sha256':expected,'selected_files':selected,'qualification':'Selected exact prior original files checked against original manifest without running old verifier; earlier reviewer and scopes are separate.'})
(p/'prior-index.json').write_text(json.dumps({'packets':priorrows,'published_archives':[{'bundle':'p16-main-validator-serde','sha256':'4d9082d02c81a40fb8c3dc575ebdc4215c47241ca669371af990d8bc3ac22a49'},{'bundle':'serde-json-number','sha256':'e89187bcf09230aad4f116417dbd4620a659a32c664cabc16009d70841f55f12'}],'qualification':'Published checkpoint15 evidence records redactions separately; exact selected originals are retained here.'},indent=2)+'\n')
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';paths=['continuation/root/admission03-scope-reconciliation-046.json','continuation/rig/admission03/source-range-registration.jsonl','continuation/rig/admission03/source-qualifications.jsonl','continuation/rig/admission03/contract-groups.jsonl','continuation/rig/admission03/catalogue-schema-receiver-witness-001.json','continuation/camera/admission03/camera-adm03-f004-detail.json','continuation/camera/admission03/camera-adm03-f005-detail.json','continuation/camera/admission03/item-main-admission-026.json']
for rel in paths:
 path='handoff/774/adler-original/audit/'+rel;b=subprocess.check_output(['git','-C',str(pub),'show',f82+':'+path]);dst=p/'history-774'/(rel+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(b,mtime=0));records.append({'kind':'historical-774','transport_path':path,'file':str(dst.relative_to(p)),'encoding':'gzip','sha256':sha(b),'bytes':len(b),'git_blob':blob(b)})
previous=json.loads(pathlib.Path('<LOCAL_PATH_5>').read_bytes());(p/'historical-index.json').write_text(json.dumps({'records':records,'unavailable_requested_records':missing,'rig_registration_pin_qualification':previous['qualifications'],'qualification':'Original 059 matched transport manifest; f82 records separately tree-proved. P16 tracked-patch recovery and each prior reader remain separately attributed; no checkpoint3821 promotion.'},indent=2)+'\n')
for name in ('rules','skills'):shutil.copytree('<LOCAL_PATH_6>'+name,p/name)
for name in ('rules.json','skills.json','build-manifest.py','verify-manifest.py'):shutil.copyfile('<LOCAL_PATH_6>'+name,p/name)
print('059',len(wanted)-len(missing),'missing',missing,'774',len(paths))
