from pathlib import Path
import gzip,hashlib,json,shutil
r=Path(__file__).resolve().parent;src=Path('<LOCAL_PATH_0>');user=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest()
for d in ['recovered','historical','prior']:(r/d).mkdir()
for n in ['MANIFEST.json','registry.json.gz','objects.tar.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:shutil.copyfile(src/n,r/'recovered'/n)
(r/'recovered/p16').mkdir();shutil.copyfile(src/'physical-p16-patch-recovery/tracked.patch',r/'recovered/p16/tracked.patch');shutil.copyfile(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json',r/'recovered/p16/RECOVERY.json')
q=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'));led=json.load(gzip.open(r/'recovered/original-059-ledger.json.gz','rt'));row=q['entries'][2433];finding=led['discovery_findings_and_dependencies'].get(row['contract_id']);(r/'historical/queue-selection-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed single row from exact original 059 queue; not an independently original record or checkpoint3821','index':2433,'queue_row':row,'ledger_finding_if_present':finding},indent=2,ensure_ascii=False)+'\n')
refs={};g=row['granular_contract_views'][0];a=g['root_adoption'];refs[a['path']]=a['sha256'];refs[a['verification']]=a['verification_sha256']
for e in g['contract_update_as_proposed']['exact_source_identities_and_assessed_ranges']:
 for key in ['receipt','prospective_registration','root_adoption']:
  v=e.get(key)
  if v and v.get('path') and v.get('sha256'):refs[v['path']]=v['sha256']
for p,digest in refs.items():
 b=(user/p).read_bytes();assert h(b)==digest,(p,h(b),digest);out=r/'historical'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
packets=[('rig-occupancy-surface','<LOCAL_PATH_3>','MANIFEST.json',['REPORT.json','registration.json','personal-read-receipt.json','original-attribution.json','historical-774-compressed-attribution.json','historical-059/segovb/READ-L11-424.json','historical-059/segovb/REGISTRATION-SEGOVB-1496.json','historical-059/segovb/REGISTRATION-SEGOVB-1497.json','historical-059/parallel-l12-20261029/QUALIFICATION-PAR-L12-636-WINDOWS-ORIGINAL2585.json','historical-059/parallel-l12-20261029/QUALIFICATION-PAR-L12-637-WINDOWS-ORIGINAL2586.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-qualifications-final-current.jsonl','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/catalogue-helper-admission-002.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/catalogue-reconciliation-003.json','historical-774-compressed/additional-contracts.jsonl.gz','historical-774-compressed/contract-groups.jsonl.gz']),('mhr-reflect-history','<LOCAL_PATH_4>','BUNDLE-MANIFEST.json',['report.json','historical-774-index.json','historical-774/registration-observed-first13.jsonl','historical-774/qualification-pin-matching-first13.jsonl','historical-774/root/admission03-scope-reconciliation-044.json.gz','historical-774/rig/admission03/completion-112.json.gz'])]
prior=[]
for label,p,mname,files in packets:
 p=Path(p);dest=r/'prior'/label;dest.mkdir();b=(p/mname).read_bytes();m=json.loads(b);known={e['path']:e['sha256'] for e in m['files']};(dest/mname).write_bytes(b)
 for f in files:
  data=(p/f).read_bytes();assert h(data)==known[f],(label,f);out=dest/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 prior.append({'label':label,'original_packet':str(p),'manifest':mname,'manifest_sha256':h(b),'members':files})
p='ASSESSMENT-EQUIPMENT-TOPOLOGY-95E.json';data=(pub/p).read_bytes();(r/'prior'/p).write_bytes(data)
info={'qualification':'059 source receipts copied read-only from extracted collection and verified against exact q2433 references. Previous packet members match their frozen manifests. 774 later rig registration file is preserved as later evidence, not silently substituted for the different earlier completion112 pin; no prior verifier executed.','q2433_exact_receipts':refs,'prior_packets':prior,'prior_current_assessment':{'path':'prior/'+p,'sha256':h(data),'source':str(pub/p)}}
(r/'historical/evidence-index.json').write_text(json.dumps(info,indent=2,ensure_ascii=False)+'\n');print('Exact 059 referenced receipts',len(refs),'prior packets',len(prior),'current assessment SHA',h(data))
