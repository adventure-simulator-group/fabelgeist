from pathlib import Path
import difflib,gzip,hashlib,json,tarfile
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();m=json.loads((r/'recovered/MANIFEST.json').read_bytes());rb=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());orig=json.loads(rb);assert h(rb)==m['registry_sha256'];assert h((r/'recovered/registry.json.gz').read_bytes())==m['registry_gzip_sha256'];assert h((r/'recovered/objects.tar.gz').read_bytes())==m['objects_archive_sha256']
reg=json.loads((r/'registration.json').read_bytes());extra=json.loads((r/'diagnostics-registration.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());assert rec['registrations']['registration.json']==h((r/'registration.json').read_bytes());assert rec['registrations']['diagnostics-registration.json']==h((r/'diagnostics-registration.json').read_bytes())
with tarfile.open(r/'recovered/objects.tar.gz') as tar:
 for e in reg['entries']:
  if e.get('historical_registry_row'):
   assert e['historical_registry_row']==orig['files'][e['original_index']];b=tar.extractfile(e['historical_registry_row']['sha256']).read();assert b==(r/e['versions'][0]['path']).read_bytes()
  for v in e['versions']:
   b=(r/v['path']).read_bytes();assert h(b)==v['sha256'] and len(b.splitlines())==v['eof'];s=next(x for x in rec['reads'] if x['path']==v['path'] and x['registration']=='registration.json');assert s['display_windows']==v['registered_windows'];obs=set();unread=set()
   for a,z in s['display_windows']:obs.update(range(a,z+1))
   for a,z in s['unread_complement_for_registration']:unread.update(range(a,z+1))
   assert not obs.intersection(unread) and obs.union(unread)==set(range(1,v['eof']+1))
for v in extra['versions']:
 s=next(x for x in rec['reads'] if x['path']==v['path'] and x['registration']=='diagnostics-registration.json');assert s['display_windows']==v['registered_windows'];assert h((r/v['path']).read_bytes())==v['sha256'];obs=set();unread=set()
 for a,z in s['display_windows']:obs.update(range(a,z+1))
 for a,z in s['unread_complement_for_registration']:unread.update(range(a,z+1))
 assert not obs.intersection(unread) and obs.union(unread)==set(range(1,v['eof']+1))
for e in reg['entries'][:2]:assert not any(x[3:]==e['project_path'] for x in next(s for s in orig['snapshots'] if s['id']=='physical-p16')['status_porcelain'])
a=(r/'source/p16-2585.rs').read_text().splitlines();b=(r/'source/95e-2585.rs').read_text().splitlines();changes=[(t,i+1,j,k+1,l) for t,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes() if t!='equal'];assert changes==[('replace',118,121,118,119)]
proof=json.loads((r/'git-proofs.json').read_bytes());objs={}
for k,v in proof['objects'].items():
 b=gzip.decompress((r/v['local']).read_bytes());assert len(b)==v['size'] and h(b)==v['sha256'] and oid(v['type'],b)==k;objs[k]=b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),k
 raise AssertionError(n)
for p in proof['proofs']:
 tree=objs[p['revision']].splitlines()[0].split()[1].decode();assert tree==p['root_tree']
 for c in p['chain']:
  assert tree==c['tree'];mode,k=lookup(objs[tree],c['name']);assert mode==c['mode'] and k==c['object'];tree=k
 assert p['path'].split('/')==[c['name'] for c in p['chain']];b=(r/p['local']).read_bytes();b=gzip.decompress(b) if p.get('encoding')=='gzip' else b;assert h(b)==p['sha256'] and oid('blob',b)==tree==p['blob']
queue=json.loads(gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes()));ledger=json.loads(gzip.decompress((r/'recovered/original-059-ledger.json.gz').read_bytes()));sel=json.loads((r/'historical/queue-selection-reconstructed.json').read_bytes());idx=json.loads((r/'historical/evidence-index.json').read_bytes());row=queue['entries'][2433];assert sel['index']==2433 and sel['queue_row']==row and sel['ledger_finding_if_present']==ledger['discovery_findings_and_dependencies'].get(row['contract_id'])
for p,digest in idx['q2433_exact_receipts'].items():assert h((r/'historical'/p).read_bytes())==digest
for e in idx['prior_packets']:
 base=r/'prior'/e['label'];m=base/e['manifest'];assert h(m.read_bytes())==e['manifest_sha256'];known={y['path']:y['sha256'] for y in json.loads(m.read_bytes())['files']}
 for p in e['members']:assert h((base/p).read_bytes())==known[p]
ca=idx['prior_current_assessment'];assert h((r/ca['path']).read_bytes())==ca['sha256']
rig=r/'prior/rig-occupancy-surface/historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl';assert h(rig.read_bytes())=='24fb01a82c91de97fd9895740404dc79a73877fcd79a846c832c45cbf2495bdb';hi=json.loads((r/'prior/mhr-reflect-history/historical-774-index.json').read_bytes())['hash_qualifications'];assert hi['completion112_registry_expected_sha256']=='698ec787519f08585b75f3ce7f2fd08f0e8793f4f4837f91d88151c2c7783db1' and hi['later_registration_file_sha256']==h(rig.read_bytes())
patch=(r/'recovered/p16/tracked.patch').read_bytes();assert len(patch)==524542 and h(patch)==next(x['patch_sha256'] for x in orig['snapshots'] if x['id']=='physical-p16')
report=json.loads((r/'REPORT.json').read_bytes());assert len(report['lens_perspectives'])==13
manifest=r/'MANIFEST.json'
if manifest.exists():
 entries={e['path']:e for e in json.loads(manifest.read_bytes())['files']};actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p!=manifest};assert set(entries)==actual
 for n,e in entries.items():b=(r/n).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],n
print('PASS: original P16 registry/archive/base membership, old/current source Git proofs and exact file difference; personal read partitions; exact 059 queue/ledger/receipts; original later 774 records and pin discrepancy; prior manifest members; tracked P16 patch; thirteen bounded perspectives'+('; complete manifest' if manifest.exists() else '; before manifest'))
print('Evidence-only: no product, parser, fixture, build, test, probe, repair or runtime validation.')
