from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();objects={};proofs=[]
def save(t,k):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,b)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(b,mtime=0));objects[k]={'type':t,'size':len(b),'sha256':h(b),'local':p}
 return b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);m,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return m.decode(),k
 raise KeyError(n)
def proof(rev,path,local,kind,encoding=None):
 b=(r/local).read_bytes();b=gzip.decompress(b) if encoding=='gzip' else b;root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,k=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':k});tree=k
 assert tree==oid('blob',b),(rev,path,local);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'encoding':encoding,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(b)})
reg=json.loads((r/'registration.json').read_bytes());a120='a120390947c89b703dc74c4255a13c035d054c50'
for e in reg['entries']:
 if 'historical_registry_row' in e:
  old,cur=e['versions'];proof(e['transport_revision'],e['transport_path'],old['path'],'f82 transported exact P16 object');proof(a120,e['project_path'],old['path'],'per-file equality to P16 clean base only');proof(cur['revision'],e['project_path'],cur['path'],'95e current assigned or support')
 else:
  v=e['versions'][0];proof(v['revision'],e['project_path'],v['path'],'95e bounded support')
base=r/'prior/rig-occupancy-surface'; idx=json.loads((base/'original-attribution.json').read_bytes())
for rec in idx['older_774_receipts']:
 local='prior/rig-occupancy-surface/'+rec['preserved_bytes'];proof(rec['transport_revision'],rec['transport_path'],local,'later recovered exact 774 record, preserve earlier pin qualification')
idx=json.loads((base/'historical-774-compressed-attribution.json').read_bytes())
for rec in idx['records']:proof(rec['transport_revision'],rec['transport_path'],'prior/rig-occupancy-surface/'+rec['preserved_gzip'],'exact 774 raw historical records, compressed','gzip')
rev='eb407672813424d64ec31f208193969f5a62620c'
for p,local in [('handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json','recovered/original-059-queue.json.gz'),('handoff/726-audit-20261030-adler/evidence/continuation-segovb/ledger.json','recovered/original-059-ledger.json.gz')]:proof(rev,p,local,'original checkpoint059, not checkpoint3821','gzip')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-p16-catalog-followup-git-proofs-v1','objects':objects,'proofs':proofs,'qualification':'Exact Git file membership only; individual base equality is not full P16 clean, personal display, final 3821 authority or validation.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'sha',h((r/'git-proofs.json').read_bytes()))
