from pathlib import Path
import datetime,hashlib,json
r=Path(__file__).resolve().parent;entry=json.loads((r/'registration.json').read_bytes())['entries'][2];versions=[]
for v in entry['versions']:
 b=(r/v['path']).read_bytes();versions.append({'identity':v['identity'],'revision':v['revision'],'path':v['path'],'sha256':hashlib.sha256(b).hexdigest(),'eof':v['eof'],'registered_windows':[[90,120]]})
x={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','project_path':entry['project_path'],'reason':'Diagnostic push/cap guard before assessing typed-parse rejection; function-name and line-number navigation preceded this registration, not body display.','scope':'separate bounded old/current support, no role2587 credit','versions':versions}
(r/'diagnostics-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('diagnostic registration',hashlib.sha256((r/'diagnostics-registration.json').read_bytes()).hexdigest())
