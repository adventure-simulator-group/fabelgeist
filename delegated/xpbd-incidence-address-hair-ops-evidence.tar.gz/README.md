# Bounded XPBD incidence and constraint-address source evidence

This packet records the `/root/hair_ops` source-only review of original
registry roles 2652–2653 at pr-working and 95e. `REPORT.json` contains the
conditional findings, historical relationships, actual source references and
thirteen bounded perspectives. It is not a complete audit, repair, product
validation, or replacement for the unrecovered final 3821 records.

`registration.json` prospectively registered both assigned source bodies;
`support-registration*.json` separately registered bounded current-source
support before its display. `read-receipt.json` records the actual displays
and the explicit unread support complements. Full source copies under `source/`
and `support/` exist for verification and do not by themselves imply a read.
Historical pr-working, 6533 per-file comparison, 95e, and f82 source transport
are distinct. The historical pr-working snapshot has unrelated changes.

`git-proofs.json` and `git-objects/` retain Git commit/tree membership proofs
for the recorded file identities. `historical/` preserves exact selected 059
receipts and a clearly marked reconstructed selection of 059 queue records;
`historical-manifest.json` hashes original 774 and previous evidence without
copying its large archives. Referenced files remain dependencies for verification.
`MANIFEST.json` fixes the packet's own bytes.

To check evidence integrity only, run `python3 verify-evidence.py`. This checks
registered identities, personal read partitions, prior receipt relationships,
Git object membership, historical hash links and the packet manifest; it does
not run the product, shaders, tests, simulations, or repair code.
