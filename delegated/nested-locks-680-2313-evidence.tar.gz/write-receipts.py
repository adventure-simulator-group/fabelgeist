import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def collapse(nums):
 out=[]
 for i in sorted(nums):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
def comp(n,ranges):return collapse(set(range(1,n+1))-{i for a,z in ranges for i in range(a,z+1)})
for reg,dst in [('registration.json','read-receipt.json'),('package-registration.json','package-read-receipt.json'),('native-registration.json','native-read-receipt.json'),('feature-support-registration.json','feature-support-read-receipt.json')]:
 x=json.loads((p/reg).read_bytes());rows=[]
 for e in x['entries']:
  ranges=e['registered_ranges'];chunks=([[1,60],[61,115]] if e.get('archive')=='source/680-current.toml' else [[1,55],[56,107]] if e.get('label','').endswith('-canvas') else ranges);rows.append({'archive':e['archive'],'sha256':e.get('sha256',e.get('source_sha256')),'displayed_chunks':chunks,'unread_complement':comp(e['EOF'],chunks)})
 (p/dst).write_text(json.dumps({'author':'/root/mhr_character','receipt_utc':now,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':rows,'qualification':'Actual independent numbered untruncated displays following prospective registration; metadata parses/archive staging do not count as line reading. No earlier reviewer credit transfers.'},indent=2)+'\n')
base=json.loads((p/'registration.json').read_bytes());extra=json.loads((p/'package-registration.json').read_bytes());out=[]
for e in base['entries']:
 if e['kind']!='assigned-lock':continue
 a=next(x for x in extra['entries'] if x['archive']==e['archive']);ranges=e['registered_ranges']+a['registered_ranges'];seen={i for lo,hi in ranges for i in range(lo,hi+1)};out.append({'role':e['role'],'label':e['label'],'archive':e['archive'],'source_sha256':e['sha256'],'EOF':e['EOF'],'personally_displayed_union':collapse(seen),'unread_complement':comp(e['EOF'],ranges),'displayed_line_count':len(seen),'unread_line_count':e['EOF']-len(seen)})
(p/'lock-personal-coverage.json').write_text(json.dumps({'author':'/root/mhr_character','entries':out,'qualification':'This packet only. Prior mhr packet and 059 reviewers are separately preserved; structural package-index parsing and complete preserved lock bytes are not full personal reading.'},indent=2)+'\n')
