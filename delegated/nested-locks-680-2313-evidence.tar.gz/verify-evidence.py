import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and [x['index'] for x in sel['rows']]==[680,2313] and all(x['row']==reg['files'][x['index']] for x in sel['rows']);snap=next(z for z in reg['snapshots'] if z['id']=='pr-working');assert snap==sel['snapshot'] and snap['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and snap['base']=='3a50b708381ad00c116445c2c999a49c3943088b'
for e in load('base-identities.json')['entries']:assert e['revision']==snap['base'] and sha((p/e['archive']).read_bytes())==reg['files'][e['role']]['base_sha256']==e['sha256'] and blob((p/e['archive']).read_bytes())==e['git_blob']
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256'],e['file']
groups=[('initial','registration.json','read-receipt.json'),('packages','package-registration.json','package-read-receipt.json'),('native','native-registration.json','native-read-receipt.json'),('feature','feature-support-registration.json','feature-support-read-receipt.json')]
for label,rf,tf in groups:
 a=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes()) and datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(a['registered_utc']);assert len(a['entries'])==len(t['entries'])
 for e,v in zip(a['entries'],t['entries']):
  b=(p/e['archive']).read_bytes();s=e.get('sha256',e.get('source_sha256'));assert sha(b)==s==v['sha256'] and len(b.splitlines())==e['EOF'] and e['archive']==v['archive'];planned={i for lo,hi in e['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in v['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in v['unread_complement'] for i in range(lo,hi+1)};assert planned==seen and seen|missing==set(range(1,e['EOF']+1)) and not seen&missing
  if 'git_blob' in e:assert blob(b)==e['git_blob']
  if e.get('kind')=='assigned-lock' and e['label']=='historical':assert s==reg['files'][e['role']]['sha256']
 counts[label]=len(a['entries'])
regn=load('registration.json');preg=load('package-registration.json');assert preg['source_registration_sha256']==sha((p/'registration.json').read_bytes())
for e in preg['entries']:
 body=(p/e['archive']).read_text().splitlines();assert e['registered_ranges']==[z['range'] for z in e['registered_packages']]
 for z in e['registered_packages']:
  lo,hi=z['range'];x=tomllib.loads('\n'.join(body[lo-1:hi]))['package'][0];assert (x['name'],x['version'])==(z['name'],z['version'])
for e in load('lock-personal-coverage.json')['entries']:
 old=next(z for z in regn['entries'] if z['archive']==e['archive']);new=next(z for z in preg['entries'] if z['archive']==e['archive']);seen={i for lo,hi in old['registered_ranges']+new['registered_ranges'] for i in range(lo,hi+1)};assert seen=={i for lo,hi in e['personally_displayed_union'] for i in range(lo,hi+1)} and set(range(1,e['EOF']+1))-seen=={i for lo,hi in e['unread_complement'] for i in range(lo,hi+1)} and e['displayed_line_count']==len(seen) and e['unread_line_count']==e['EOF']-len(seen)
n=load('native-registration.json');packages={x['version']:x for x in n['packages']}
for version,e in packages.items():assert sha((p/e['archive']).read_bytes())==e['sha256']
for e in n['entries']+load('feature-support-registration.json')['entries']:
 if e['kind']=='native-member':
  with tarfile.open(fileobj=io.BytesIO((p/packages[e['package']]['archive']).read_bytes()),mode='r:gz') as tar:assert tar.extractfile(e['package_member']).read()==(p/e['archive']).read_bytes()
root=next(e for e in n['entries'] if e['kind']=='project-lock');assert any(z['version']=='0.3.103' and z['checksum']==packages['0.3.103']['sha256'] for z in root['metadata_packages'])
for e in regn['entries']:
 if e['kind']=='assigned-lock':
  found=[z for z in tomllib.loads((p/e['archive']).read_text())['package'] if z['name']=='web-sys' and z['version']=='0.3.105'];assert len(found)==1 and found[0]['checksum']==packages['0.3.105']['sha256']
assert (p/'source/web-sys-0.3.103-canvas.rs').read_bytes()==(p/'source/web-sys-0.3.105-canvas.rs').read_bytes();prior=load('reference/prior-native-web-sys-103-manifest.json');assert prior['sha256']==packages['0.3.103']['sha256'] and prior['inspected_members'][0]['sha256']==sha((p/'source/web-sys-0.3.103-canvas.rs').read_bytes())
priorbytes=(p/'prior-mhr/BUNDLE-MANIFEST.json').read_bytes();assert sha(priorbytes)=='c26b0b03d82396ef2e65aa8ed17cbca89896ccca47771f9f228c2fd539e14cdb';priorindex={z['path']:z for z in json.loads(priorbytes)['files']}
for e in load('prior-mhr-index.json')['selected_files']:
 b=(p/'prior-mhr'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(priorindex[e['path']]['bytes'],priorindex[e['path']]['sha256'])
for z in load('prior-mhr/lock-read-coverage.json')['sources']:
 assert z['lines']-z['unread_lines']==(195 if z['kind']=='historical' else 198) and z['sha256'] in {e['sha256'] for e in regn['entries'] if e['role']==2313 and e['kind']=='assigned-lock'}
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']}
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=json.loads(qraw);x=load('queue-selection-reconstructed.json');assert x['source_sha256']==sha(qraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for n in (159,160,194,195,197):
 x=load(f'history-059/parallel-l11-20261029/READ-{n}.json')
 for entry in x['plans']:
  rel=entry['path'].split('target/726-audit-adler-20261027/',1)[1];assert entry['sha256']==sha((p/'history-059'/rel).read_bytes())
for n in (695,696,730,731,733):
 read=(p/f'history-059/segovb/READ-L11-{n}.json').read_bytes();state=(p/f'history-059/segovb/STATE-L11-{n}.json').read_bytes();v=load(f'history-059/segovb/VERIFY-L11-{n}.json');assert v['receipt_sha256']==sha(read) and v['state_sha256']==sha(state)
assert q['entries'][3711]['source_policy_qualification']['whole_current_file_qualified_by_exact_own_union'] and not q['entries'][3711]['source_policy_qualification']['whole_file_fresh_read']
for i,limit in [(2271,2),(2937,1),(2938,1),(3711,1)]:
 for z in q['entries'][i]['exact_source_identities_and_assessed_ranges'][:limit]:
  for kind in ('body_receipt','registration_ref_and_sha256'):
   e=z[kind];rel=e['path'].split('target/726-audit-adler-20261027/',1)[1];assert e['sha256']==sha((p/'history-059'/rel).read_bytes())
  e=z['root_adoption'];assert e['sha256']==sha((p/'history-059'/e['path']).read_bytes()) and e['verification_sha256']==sha((p/'history-059'/e['verification']).read_bytes())
coverage=[json.loads(z) for z in gzip.decompress((p/'history-774/audit-existing-type-owners/rig/coverage.jsonl.gz').read_bytes()).splitlines()];sources=json.loads(gzip.decompress((p/'history-774/audit-producer-propagation/rig/sources.json.gz').read_bytes()));inventory=json.loads(gzip.decompress((p/'history-774/audit-existing-type-owners/rig/cargo-native-config-inventory.json.gz').read_bytes()))
for role,owner_row,producer_row,inv_row in [(680,93,0,0),(2313,94,155,1)]:
 row=reg['files'][role];a=coverage[owner_row];b=sources[producer_row];c=inventory[inv_row];assert a['source_id']==b['source_id']==c['source_id']==row['source_id'] and a['observed_sha256']==b['observed_sha256']==c['observed_sha256']==row['sha256'] and a['read_status']=='full-native-config-structured-byte-inventory' and b['source_read_complete'] and 'TOML metadata decode' in b['read_proof'] and 'notmanual' in c['inventory_method']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==22 and len(report['lens_perspectives'])==13 and len({z['lens'] for z in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'qualification':'Offline evidence integrity only: source/member identity, bounded personal displays, 059/774 provenance, old packet checksums and Git path proofs; no Cargo resolution, product, tests, macro or runtime execution.'},indent=2))
