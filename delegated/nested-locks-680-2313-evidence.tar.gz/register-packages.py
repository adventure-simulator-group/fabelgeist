import datetime,hashlib,json,pathlib,tomllib
p=pathlib.Path(__file__).parent;r=json.loads((p/'registration.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();selected={680:['adventuresim-character-creator','bevy_render','burn-wgpu','cubecl','cubecl-wgpu','wgpu','web-sys'],2313:['fabelgeist-mhr','burn','burn-wgpu','cubecl-wgpu','wgpu','web-sys','pliron']};entries=[]
for e in r['entries']:
 if e['kind']!='assigned-lock':continue
 lines=(p/e['archive']).read_text().splitlines();starts=[i for i,line in enumerate(lines) if line=='[[package]]'];blocks=[]
 for i,start in enumerate(starts):
  end=starts[i+1] if i+1<len(starts) else len(lines);text='\n'.join(lines[start:end]);d=tomllib.loads(text)['package'][0]
  if d['name'] in selected[e['role']]:
   while end>start and not lines[end-1].strip():end-=1
   blocks.append({'name':d['name'],'version':d['version'],'range':[start+1,end]})
 entries.append({'role':e['role'],'label':e['label'],'archive':e['archive'],'source_sha256':e['sha256'],'EOF':e['EOF'],'registered_packages':blocks,'registered_ranges':[b['range'] for b in blocks]})
(p/'package-registration.json').write_text(json.dumps({'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_registration_sha256':sha((p/'registration.json').read_bytes()),'entries':entries,'qualification':'Prospective exact complete package stanzas selected using a structural metadata index; parse is not source-reading credit and not feature resolution. Each registered block must be independently displayed; other lock lines remain unread.'},indent=2)+'\n');print('registration',sha((p/'package-registration.json').read_bytes()));print(json.dumps([{k:v for k,v in e.items() if k in ('role','label','registered_packages')} for e in entries],indent=2))
