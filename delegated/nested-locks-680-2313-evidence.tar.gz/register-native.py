import datetime,hashlib,io,json,pathlib,re,subprocess,tarfile,tomllib
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';cache=pathlib.Path('<LOCAL_PATH_1>');sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();entries=[];packages=[]
path='Cargo.lock';b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);archive='source/root-current.lock';(p/archive).write_bytes(b);lines=b.decode().splitlines();starts=[i for i,x in enumerate(lines) if x=='[[package]]'];root_ranges=[];root_values=[]
for i,start in enumerate(starts):
 end=starts[i+1] if i+1<len(starts) else len(lines);pkg=tomllib.loads('\n'.join(lines[start:end]))['package'][0]
 if pkg['name']=='web-sys':
  while end>start and not lines[end-1].strip():end-=1
  root_ranges.append([start+1,end]);root_values.append(pkg)
entries.append({'kind':'project-lock','label':'root-95e','revision':rev,'path':path,'archive':archive,'sha256':sha(b),'git_blob':blob(b),'EOF':len(lines),'registered_ranges':root_ranges,'metadata_packages':root_values})
for version,expected in [('0.3.103','8622dcb61c0bcc9fffa6938bed81210af2da9a7e4a1a834b2e37a59b6dfb6141'),('0.3.105','9fbddc4a036f00ec4f18c83445bd3115cb306a91da554919a099d9222fe4a7f8')]:
 source=cache/f'web-sys-{version}.crate';raw=source.read_bytes();assert sha(raw)==expected;dst=f'source/web-sys-{version}.crate';(p/dst).write_bytes(raw);pkg={'name':'web-sys','version':version,'archive':dst,'sha256':sha(raw),'bytes':len(raw),'source_cache':str(source)};packages.append(pkg)
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
  for tag,member in [('manifest',f'web-sys-{version}/Cargo.toml'),('canvas',f'web-sys-{version}/src/features/gen_OffscreenCanvas.rs')]:
   data=tar.extractfile(member).read();out=f'source/web-sys-{version}-{tag}.rs' if tag=='canvas' else f'source/web-sys-{version}-Cargo.toml';(p/out).write_bytes(data);ls=data.decode().splitlines()
   if tag=='canvas':ranges=[[1,len(ls)]]
   else:
    indexes=[i for i,z in enumerate(ls) if re.match(r'^OffscreenCanvas\s*=',z)];assert len(indexes)==1;start=indexes[0];end=start
    while not (']' in ls[end] or ls[end].strip().endswith('[]')):end+=1
    ranges=[[1,20],[start+1,end+1]]
   entries.append({'kind':'native-member','label':f'{version}-{tag}','package':version,'package_member':member,'archive':out,'sha256':sha(data),'git_blob':blob(data),'EOF':len(ls),'registered_ranges':ranges})
assert any(z.get('version')=='0.3.103' and z.get('checksum')==packages[0]['sha256'] for z in root_values)
(p/'native-registration.json').write_text(json.dumps({'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packages':packages,'entries':entries,'qualification':'Prospective root 95e web-sys lock stanzas and exact 0.3.103/0.3.105 archive members; selected manifest feature definitions and generated source are separately displayed. Lock metadata and Cargo.toml feature definitions do not prove feature activation, browser target or execution.'},indent=2)+'\n');print('registered',sha((p/'native-registration.json').read_bytes()));print(json.dumps([{'label':e['label'],'ranges':e['registered_ranges'],'sha256':e['sha256']} for e in entries],indent=2))
