#!/usr/bin/env python3
from pathlib import Path
import gzip,hashlib,json,tarfile,tomllib
b=Path(__file__).resolve().parent
sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();read=lambda p:(b/p).read_bytes(); js=lambda p:json.loads(read(p)); jgz=lambda p:json.loads(gzip.decompress(read(p)))
reg=js('registration.json'); receipt=js('personal-read-receipt.json');assert receipt['registration_sha256']==sha(read('registration.json'));assert receipt['recorded_utc']>=reg['registered_utc'];rr={x['id']:x for x in receipt['reads']};assert len(rr)==len(reg['entries'])
with tarfile.open(b/reg['archive']['path'],'r:gz') as t:
 assert sha(read(reg['archive']['path']))==reg['archive']['sha256']=='5fc5f820ee52afeca6d3bb83f15c1bf61ea6196c840a761a21a8bc266a3b166e'
 cargo=tomllib.loads(t.extractfile('bevy_reflect_derive-0.19.1/Cargo.toml').read().decode());assert cargo['package']['name']=='bevy_reflect_derive' and cargo['package']['version']=='0.19.1'
 for e in reg['entries']:
  d=read(e['archive']);assert sha(d)==e['sha256'] and len(d)==e['bytes'] and len(d.splitlines())==e['eof']; r=rr[e['id']];assert r['sha256']==e['sha256'] and r['eof']==e['eof'] and r['actual_display_ranges']==e['prospective_display_ranges']
  covered=set(i for x,y in r['actual_display_ranges'] for i in range(x,y+1));unknown=set(i for x,y in r['unread_complement'] for i in range(x,y+1));assert covered.isdisjoint(unknown) and covered|unknown==set(range(1,e['eof']+1))
  if e.get('member'):assert t.extractfile(e['member']).read()==d
  if e['id'].startswith('lock-'):
   lock=tomllib.loads(d.decode());pkg=[p for p in lock['package'] if p['name']=='bevy_reflect_derive' and p['version']=='0.19.1'];assert len(pkg)==1 and pkg[0]['source']=='registry+https://github.com/rust-lang/crates.io-index' and pkg[0]['checksum']==reg['archive']['sha256']
report=js('REPORT.json');assert [q['queue_index'] for q in report['historical_queue_relationships']]==[2332,3445]
for finding in report['findings']:
 for ref in finding['references']:
  covered=set(i for a,z in rr[ref['source']]['actual_display_ranges'] for i in range(a,z+1));assert all(i in covered for a,z in ref['lines'] for i in range(a,z+1))
proof=js('git-proofs.json'); raw={}
for id,x in proof['objects'].items():
 d=gzip.decompress(read(x['preserved_bytes']));assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==id;raw[id]=d
for rev,x in proof['commits'].items():assert raw[rev].splitlines()[0]==b'tree '+x['root_tree'].encode()
def ents(d):
 z={};i=0
 while i<len(d):
  j=d.index(b'\0',i);m,n=d[i:j].split(b' ',1);z[n.decode()]=(m.decode(),d[j+1:j+21].hex());i=j+21
 return z
for x in proof['paths']:
 d=read(x['preserved_bytes']); assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob'];cur=proof['commits'][x['revision']]['root_tree'];names=[]
 for y in x['path_chain']:
  assert cur==y['tree'];mode,child=ents(raw[cur])[y['name']];assert (mode,child)==(y['mode'],y['object']);cur=child;names.append(y['name'])
 assert '/'.join(names)==x['path'] and cur==x['git_blob']
orig=jgz('history/original-registry.json.gz');queue=jgz('history/baseline-059-queue.json.gz');trans=jgz('history/original-transport-manifest.json.gz');sel=js('history/reconstructed-selections.json');idx={x['path']:x for x in trans['entries']};
for p,d in [('evidence/audit05/original-scope-072.json',gzip.decompress(read('history/original-registry.json.gz'))),('workflow-20261030/CLOSURE-QUEUE-100.json',gzip.decompress(read('history/baseline-059-queue.json.gz')))]:assert idx[p]['bytes']==len(d) and idx[p]['sha256']==sha(d) and idx[p]['git_blob']==oid('blob',d)
assert sel['original_registry_sha256_uncompressed']==sha(gzip.decompress(read('history/original-registry.json.gz'))) and sel['original_queue_sha256_uncompressed']==sha(gzip.decompress(read('history/baseline-059-queue.json.gz')))
for n in (2563,2564,2679,2680):assert sel['registry_roles'][str(n)]==orig['files'][n]
for n in (2332,3445):assert sel['queue_entries'][str(n)]==queue['entries'][n]
attrs=js('history/attribution-and-copies.json'); old=jgz('history/older-774-handoff-manifest.json.gz'); oldidx={x['path']:x for x in old['files']}
for x in attrs['records']:
 d=read(x['copy']);assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if x['scope']=='059':
  y=idx[x['path']];assert (len(d),sha(d),oid('blob',d))==(y['bytes'],y['sha256'],y['git_blob'])
 if x['scope']=='774-segovb-handoff':
  y=oldidx[x['origin']];assert (len(d),sha(d))==(y['bytes'],y['sha256'])
for i,id in [(2563,'native-lib'),(2564,'native-from')]:assert orig['files'][i]['sha256']==next(x['sha256'] for x in reg['entries'] if x['id']==id)
assert sha(read('history/p17-length'))==orig['files'][2680]['sha256']==sha(read('sources/current-length'))
assert sha(read('history/p17-measurement'))==orig['files'][2679]['sha256']!=sha(read('sources/current-measurement'))
r=js('history/p17-recovery.json');assert r['recorded_head']=='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696' and sha(read('history/p17-tracked.patch'))==r['recovered_patch']['sha256'] and sha(read('history/p17-git-delta-proof.tar.gz'))==r['git_tree_delta_proof']['sha256']
p=js('history/prior-hair-packet-manifest.json');pidx={x['path']:x for x in p['files']}
for name in ['report.json','registration.json','read-receipt.json','support-read-receipt.json']:
 d=read('history/prior-hair-'+name);assert sha(d)==pidx[name]['sha256'] and len(d)==pidx[name]['bytes']
c=js('history/published-prior-comparison.json');a=read('history/published-hair-evidence.tar.gz');assert sha(a)==c['published_archive_sha256']
with tarfile.open(b/'history/published-hair-evidence.tar.gz','r:gz') as t:
 for x in c['comparison']:
  d=t.extractfile(x['member']).read(); orig=read('history/prior-hair-'+x['member']);assert sha(d)==x['published_sha256'] and sha(orig)==x['original_sha256'] and (d==orig)==x['byte_identical']
print(json.dumps({'status':'passed','source_entries':len(reg['entries']),'proof_paths':len(proof['paths']),'proof_objects':len(proof['objects']),'historical_records':len(attrs['records']),'queue_indices':[2332,3445],'archive':'exact package archive + selected published prior package comparison','product_execution':'none; evidence verification only','writes':'none'},indent=2))
