#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent;m=json.loads((b/'MANIFEST.json').read_text());seen=set()
for x in m['files']:
 p=b/x['path'];d=p.read_bytes();assert len(d)==x['bytes'] and hashlib.sha256(d).hexdigest()==x['sha256'];seen.add(x['path'])
actual={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};assert actual==seen
print(json.dumps({'status':'passed','verified_files':len(seen),'writes':'none'}))
