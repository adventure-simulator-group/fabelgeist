from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,subprocess,shutil
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
prior=Path('<LOCAL_PATH_1>')
(b/'sources').mkdir(exist_ok=True);(b/'archive').mkdir(exist_ok=True)
archive=b/'archive/bevy_reflect_derive-0.19.1.crate';shutil.copyfile(prior/'archives/bevy_reflect_derive-0.19.1.crate',archive)
sha=lambda x:hashlib.sha256(x).hexdigest()
t=tarfile.open(archive,'r:gz'); entries=[]
for id,path,ranges,role in [('native-lib','src/lib.rs',[[60,127],[192,209],[401,405]],2563),('native-from','src/from_reflect.rs',[[1,105]],2564),('native-opaque','src/impls/opaque.rs',[[25,131]],None)]:
 data=t.extractfile('bevy_reflect_derive-0.19.1/'+path).read();dest='sources/'+id; (b/dest).write_bytes(data)
 entries.append({'id':id,'kind':'native package role' if role else 'native package support','role':role,'package':'bevy_reflect_derive','version':'0.19.1','member':'bevy_reflect_derive-0.19.1/'+path,'archive':dest,'sha256':sha(data),'bytes':len(data),'eof':len(data.splitlines()),'prospective_display_ranges':ranges,'original_role_material':{'2563':[[60,117]],'2564':[[25,56]]}.get(str(role),[]),'identity_qualification':'Package member, not project Git source. Supporting lines confer no original ordered-role credit.'})
rev='95e63628f9d70b8dd6e6fede64334696c6995009'
for id,path,ranges in [('current-length','crates/fabelgeist-geometry/src/length.rs',[[1,40]]),('current-measurement','crates/fabelgeist-geometry/src/measurement.rs',[[1,104]]),('current-geometry-cargo','crates/fabelgeist-geometry/Cargo.toml',[[1,21]])]:
 data=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);dest='sources/'+id;(b/dest).write_bytes(data)
 assert max(y for x,y in ranges)<=len(data.splitlines())
 entries.append({'id':id,'kind':'current project support','revision':rev,'git_path':path,'archive':dest,'sha256':sha(data),'bytes':len(data),'eof':len(data.splitlines()),'prospective_display_ranges':ranges,'identity_qualification':'Fresh independent bounded support, not historical body credit.'})
for tag,r in [('6533','6533e444fa37552927070cc8d8190907fd3b413e'),('95e',rev)]:
 data=subprocess.check_output(['git','-C',repo,'show',r+':Cargo.lock']); dest='sources/'+tag+'-Cargo.lock';(b/dest).write_bytes(data)
 s=data.decode().splitlines();needle='name = "bevy_reflect_derive"';ix=[i+1 for i,l in enumerate(s) if l==needle];assert len(ix)==1
 a=max(1,ix[0]-1);z=ix[0]+6
 entries.append({'id':'lock-'+tag,'kind':'project lock support','revision':r,'git_path':'Cargo.lock','archive':dest,'sha256':sha(data),'bytes':len(data),'eof':len(s),'prospective_display_ranges':[[a,z]],'identity_qualification':'Selection only; Cargo features and actual execution unresolved.'})
out={'registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','purpose':'prospectively registered bounded personal source displays for historical semantic-queue reconciliation, no whole-lens completion','archive':{'path':'archive/bevy_reflect_derive-0.19.1.crate','sha256':sha(archive.read_bytes()),'package':'bevy_reflect_derive','version':'0.19.1'},'entries':entries}
assert out['archive']['sha256']=='5fc5f820ee52afeca6d3bb83f15c1bf61ea6196c840a761a21a8bc266a3b166e'
(b/'registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
