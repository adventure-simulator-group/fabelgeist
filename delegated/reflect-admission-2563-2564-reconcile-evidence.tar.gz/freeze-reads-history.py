from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,subprocess
b=Path(__file__).resolve().parent; prior=Path('<LOCAL_PATH_0>');base=Path('<LOCAL_PATH_1>'); extraction=Path('<LOCAL_PATH_2>')
sha=lambda d:hashlib.sha256(d).hexdigest(); gb=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();w=lambda path,data:(b/path).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
reg=json.loads((b/'registration.json').read_bytes()); reads=[]
for e in reg['entries']:
 covered=set(i for a,z in e['prospective_display_ranges'] for i in range(a,z+1)); unread=[];start=None
 for i in range(1,e['eof']+2):
  if i<=e['eof'] and i not in covered:
   if start is None:start=i
  elif start is not None:unread.append([start,i-1]);start=None
 reads.append({'id':e['id'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_ranges':e['prospective_display_ranges'],'unread_complement':unread,'registration_ranges_are_actual':True})
w('personal-read-receipt.json',{'recorded_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','registration_sha256':sha((b/'registration.json').read_bytes()),'reads':reads,'qualification':'The exact registered windows were displayed with numbered lines; unread archive bytes are retained only for integrity and are not read credit. No tests, execution or full lens completion.'})
(b/'history').mkdir(exist_ok=True)
for name in ['original-registry.json.gz','original-transport-manifest.json.gz','baseline-059-queue.json.gz']:
 shutil.copyfile(base/name,b/'history'/name)
shutil.copyfile('<LOCAL_PATH_3>',b/'history/older-774-handoff-manifest.json.gz')
reg0=json.load(gzip.open(b/'history/original-registry.json.gz','rt'));queue=json.load(gzip.open(b/'history/baseline-059-queue.json.gz','rt'))
w('history/reconstructed-selections.json',{'qualification':'Selections mechanically reconstructed from the recovered original registry and 059 queue. They are not original standalone documents, nor checkpoint3821 records. Source bodies and original reader attribution remain separate.','original_registry_sha256_uncompressed':sha(gzip.decompress((b/'history/original-registry.json.gz').read_bytes())),'registry_roles':{str(i):reg0['files'][i] for i in [2563,2564,2679,2680]},'original_queue_sha256_uncompressed':sha(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes())),'queue_entries':{str(i):queue['entries'][i] for i in [2332,3445]}})
orig=json.load(gzip.open(b/'history/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in orig['entries']}
paths=['segovb/READ-L11-422.json','segovb/READ-L11-571.json','segovb/REGISTRATION-SEGOVB-1470.json','segovb/REGISTRATION-SEGOVB-1471.json','parallel-l12-20261029/PROPOSAL-L12-870.json','parallel-l12-20261029/REGISTRATION-PAR-L12-610.json','parallel-l12-20261029/REGISTRATION-PAR-L12-611.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-610-WINDOWS-ORIGINAL2563.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-611-WINDOWS-ORIGINAL2564.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-870-REFLECTION-DISPATCH-CLOSING.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-865-872.json','parallel-l12-20261029/PROPOSAL-L12-929.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-925-932.json']
records=[]
for p in paths:
 d=(extraction/p).read_bytes();v=idx[p]; assert len(d)==v['bytes'] and sha(d)==v['sha256'] and gb(d)==v['git_blob'];dest='history/059/'+p;(b/dest).parent.mkdir(parents=True,exist_ok=True);(b/dest).write_bytes(d);records.append({'scope':'059','path':p,'copy':dest,'sha256':sha(d),'bytes':len(d),'git_blob':gb(d)})
for name in ['source-range-registration.jsonl','source-qualifications.jsonl','findings.jsonl']:
 d=(prior/'historical/native'/name).read_bytes();dest='history/774-native/'+name;(b/dest).parent.mkdir(parents=True,exist_ok=True);(b/dest).write_bytes(d);records.append({'scope':'774-rig-f82','copy':dest,'transport_path':'handoff/774/adler-original/audit/continuation/rig/admission03/'+name,'sha256':sha(d),'bytes':len(d)})
d=(prior/'historical/774/audit-continuation/operations/contract-groups-615.json').read_bytes();dest='history/774-contract-groups-615.json';(b/dest).write_bytes(d);records.append({'scope':'774-segovb-handoff','copy':dest,'origin':'audit/reconcile-adler-20261023/audit-continuation/operations/contract-groups-615.json','sha256':sha(d),'bytes':len(d)})
for p in ['report.json','registration.json','read-receipt.json','support-read-receipt.json','packet-manifest.json']:
 d=(prior/p).read_bytes();dest='history/prior-hair-'+p;(b/dest).write_bytes(d);records.append({'scope':'earlier 95e independent delegated assessment /root/hair_ops','copy':dest,'sha256':sha(d),'bytes':len(d)})
repo='<LOCAL_PATH_4>'; rev='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696'
for ident,path in [('p17-length','crates/fabelgeist-geometry/src/length.rs'),('p17-measurement','crates/fabelgeist-geometry/src/measurement.rs')]:
 d=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);dest='history/'+ident;(b/dest).write_bytes(d);records.append({'scope':'report-p17 committed comparison source, not a new personal old body read','revision':rev,'git_path':path,'copy':dest,'sha256':sha(d),'bytes':len(d),'original_registry_role':2680 if ident=='p17-length' else 2679})
w('history/attribution-and-copies.json',{'records':records,'qualification':'059 records copied from user extraction and verified against original manifest. 774 rig records transported by f82. The report-p17 body copies are comparison objects, not personal displays. Prior /root/hair_ops data preserves attribution. Historical 059 status is not checkpoint3821 status.'})
print('registrations',len(reads),'historical copied',len(records))
