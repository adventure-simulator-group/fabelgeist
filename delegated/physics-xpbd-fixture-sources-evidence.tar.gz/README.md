# Bounded physics and XPBD fixture-source evidence

This packet records `/root/rig_identity`'s independent source-only review of
original registry roles 2663 (the physics collider-capacity text fixture) and
2665 (the XPBD constraint-native JSON fixture). It supplies thirteen bounded
perspectives; it does not establish whole-lens completion, fixture or test
validation, product behavior, or new unique ledger counts.

The recorded `pr-working` snapshot has head
`6533e444fa37552927070cc8d8190907fd3b413e` and four unrelated status entries.
Each fixture object individually equals its file at that head and pinned current
revision `95e63628f9d70b8dd6e6fede64334696c6995009`. Revision
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee` transports recovered evidence; it
is not a project revision. Raw Git commit, tree and blob proofs are in
`git-proofs.json` and `git-objects/`.

Both historical and current fixture texts were independently displayed in full
after registration: 2663 lines 1–11 and 2665 lines 1–47. Current test text,
count, collider, constraint and incidence bodies were separately registered as
support; `personal-read-receipt.json` records actual chunks and unread
complements. Prior `/root/rig_identity` current support reads of each fixture
are independently preserved in `prior-current-reads.json`, with their exact
receipts, registrations and manifests. They do not transfer historical or
ordered-role credit.

Original 774 rig ADD107 left the capacity fixture unread at that earlier
point; its later ADD126 and ADD128 separately record full historical fixture
reads. The 059 Lens11 receipts also record full reads without naming an
individual. `/root/lens12_frontier` personally read 2663 in 920 and 2665 in
922, and root adoptions record no personal rereads.

The capacity source rows include oversized-count wrap expectations connected
to existing q479; they do not demonstrate safe allocation. The constraint
fixture includes a maximum u32 particle word, but the inspected test text
records a lambda clear rather than a constraint solve using that index. The
four existing count/attachment reason predicates remain separate. Old error
spelling and unsupported overflow results are not compatibility mandates.

`registry-selection-reconstructed.json` and
`queue-selection-reconstructed.json` are selected reconstructed records, not
original standalone files. The 059 records in `historical-059/` are exact bytes
checked against the recovered original transport manifest. The 774 records and
earlier assessments are hash-linked in `evidence-links.json`.
`published-prior-packet-links.json` checks only its selected archive members;
it does not assert every member is an exact original. Published bundles and
exact earlier packets remain dependencies of full evidence verification.

The separate P16 dirty snapshot is based on
`a120390947c89b703dc74c4255a13c035d054c50`; that base is not the dirty
snapshot's commit. Its later recovered tracked patch matches the recorded hash,
with seven untracked files separate; matching bytes do not establish the
original diff invocation or uninterrupted custody. This packet does not
recover or promote the checkpoint 3821 ledger or queue.

Run `python3 verify-evidence.py` to check evidence hashes, provenance and
source ranges; run `python3 verify-manifest.py` to check frozen packet files.
These are evidence-integrity checks only. No fixture was invoked or parsed,
and no fixture/test validation, product execution, GPU, simulation, build or
runtime probe was performed.
