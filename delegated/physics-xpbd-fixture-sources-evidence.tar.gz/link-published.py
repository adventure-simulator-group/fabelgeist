from pathlib import Path
import hashlib,json,tarfile
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();out=[]
items=[('p16-catalog-occupancy-surface','<LOCAL_PATH_1>',['MANIFEST.json','git-proofs.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774-compressed/additional-contracts.jsonl.gz'],['/source-range-registration.jsonl','/additional-contracts.jsonl'])]
for name,local,files,suffixes in items:
 base=Path(local);p=pub/(name+'-evidence.tar.gz');blob=p.read_bytes();gp=json.load(open(base/'git-proofs.json'));oids=set()
 for suffix in suffixes:
  matches=[x for x in gp.get('paths',gp.get('proofs')) if x['path'].endswith(suffix)];assert len(matches)==1;x=matches[0];oids.add(x['revision']);oids.update(y['tree'] for y in x.get('path_chain',x.get('chain')))
 files+=sorted(gp['objects'][x].get('preserved_bytes',gp['objects'][x].get('archive')) for x in oids);members=[]
 with tarfile.open(p,'r:gz') as t:
  for f in files:
   raw=t.extractfile(f).read();assert raw==(base/f).read_bytes(),(name,f);members.append({'member':f,'sha256':sha(raw),'bytes':len(raw)})
 out.append({'published_archive':str(p),'sha256':sha(blob),'bytes':len(blob),'local_original_bundle':local,'byte_identical_members':members,'qualification':'Only listed members checked; unrelated members may be reconstructed public copies.'})
(b/'published-prior-packet-links.json').write_text(json.dumps({'schema':'726-physics-xpbd-fixtures-published-prior-packets-v1','archives':out},indent=2)+'\n');print([(x['published_archive'],len(x['byte_identical_members'])) for x in out])
