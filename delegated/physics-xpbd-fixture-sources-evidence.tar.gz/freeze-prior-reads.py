from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();entries=[]
for label,local,source in [('physics-contact-tests','<LOCAL_PATH_0>','support/collider-capacity.txt'),('shell-xpbd-tests','<LOCAL_PATH_1>','support/constraint-native.json')]:
 root=Path(local);receipt=json.loads((root/'personal-read-receipt.json').read_bytes());row=next(x for x in receipt['reads'] if x['archive']==source);files=[]
 for f in ['personal-read-receipt.json',row['registration'],'MANIFEST.json']:
  d=(root/f).read_bytes();p=b/'prior-current-reads'/label/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(d);files.append({'original':str(root/f),'preserved':str(p.relative_to(b)),'sha256':sha(d),'bytes':len(d)})
 entries.append({'prior_author':receipt['author'],'prior_packet':str(root),'recorded_utc':receipt['recorded_utc'],'prior_read':row,'copied_evidence':files,'qualification':'Prior registered current support belongs to its original reviewer and packet. It is not original ordered-role credit or a historical personal read.'})
out={'schema':'726-fixture-prior-current-attribution-v1','entries':entries};(b/'prior-current-reads.json').write_text(json.dumps(out,indent=2)+'\n');print('entries',len(entries),'index_sha',sha((b/'prior-current-reads.json').read_bytes()))
