from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda d:hashlib.sha256(d).hexdigest()
plans=[('crates/fabelgeist-physics/src/contact/count/tests.rs','support/count-tests.rs',[[1,19]]),('crates/fabelgeist-physics/src/contact/count.rs','support/count.rs',[[1,55]]),('crates/fabelgeist-physics/src/collider.rs','support/collider.rs',[[11,13]]),('crates/fabelgeist-xpbd/src/constraint/tests.rs','support/constraint-tests.rs',[[1,111]]),('crates/fabelgeist-xpbd/src/constraint.rs','support/constraint.rs',[[95,115],[119,145],[148,218],[240,285]]),('crates/fabelgeist-xpbd/src/incidence.rs','support/incidence.rs',[[6,14],[35,45],[59,87]])]
rows=[]
for path,dest,ranges in plans:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in ranges)
 chunks=[[start,min(start+59,z)] for a,z in ranges for start in range(a,z+1,60)];(b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(raw);rows.append({'kind':'connected current support; source text only','revision':rev,'path':path,'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path]).decode().strip(),'sha256':sha(raw),'bytes':len(raw),'eof':eof,'archive':dest,'registered_ranges':ranges,'planned_chunks':chunks})
r={'schema':'726-physics-xpbd-fixture-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'Prospective current connected text support; no original role/other reader credit, fixture parsing, test or product execution.'};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration',sha((b/'support-registration.json').read_bytes()));print(json.dumps(rows,indent=2))
