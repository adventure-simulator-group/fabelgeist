import gzip,hashlib,json,pathlib
src=pathlib.Path('<LOCAL_PATH_0>');out=pathlib.Path('<LOCAL_PATH_1>');old=pathlib.Path('<LOCAL_PATH_2>');handoff=pathlib.Path('<LOCAL_PATH_3>');ref=out/'reference';ref.mkdir(exist_ok=True)
refpaths=['registry.json.gz','original-transport-manifest.json.gz','queue-059.json.gz'];refs=[]
for n in refpaths:
 source=pathlib.Path('<LOCAL_PATH_4>')/n;b=source.read_bytes();(ref/n).write_bytes(b);refs.append({'source':str(source),'copy':'reference/'+n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'classification':'Lossless original registry/transport/059 queue; preserve historical state and attribution.'})
m=json.loads(gzip.decompress((ref/'original-transport-manifest.json.gz').read_bytes()));entries={e['path']:e for e in m['entries']}
paths=['segovb/READ-L11-403.json','segovb/READ-L11-569.json','segovb/READ-L12-819.json','parallel-l12-20261029/READ-FUTURE-PAR-L12-819-ORIGINAL2435.json','parallel-l12-20261029/REGISTRATION-PAR-L12-444.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-444-WINDOWS-ORIGINAL2435.json','segovb/REGISTRATION-SEGOVB-1328.json','segovb/REGISTRATION-SEGOVB-1330.json','segovb/REGISTRATION-SEGOVB-1331.json','parallel-l11-20261029/READ-033.json','parallel-l11-20261029/PLAN-034.json','parallel-l11-20261029/VERIFY-033.json','segovb/VALIDATE-INHERITED-031-033-ROOT-002.json']
rows=[];missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file():missing.append(path);continue
 b=(src/path).read_bytes();e=entries[path];h=hashlib.sha256(b).hexdigest();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),path
 dst=out/'historical'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);rows.append({'original_transport_path':path,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+path})
f=out/'historical-manifest.json';f.write_text(json.dumps({'qualification':'Exact original 059 transport copies with original author/revision; never promote earlier state to checkpoint3821.','records':rows,'unavailable':missing},indent=2)+'\n');print('059 verified',len(rows),'missing',missing)
mb=(handoff/'MANIFEST.json').read_bytes();(ref/'older-774-handoff-manifest.json.gz').write_bytes(gzip.compress(mb,mtime=0));ix={e['path']:e for e in json.loads(mb)['files']}; older=[]
paths=['audit/reconcile-adler-20261023/audit-continuation/operations/contract-groups-583.json','audit/reconcile-adler-20261023/audit-continuation/redundant-authority/contract-564.json','historical-family-execution/final-acceptance-20261021/wave-01/producer-supplement-after-owner/camera/traces.jsonl','historical-family-execution/final-acceptance-20261021/wave-01/producer-supplement-after-owner/native/traces.jsonl']
for n in paths:
 b=(handoff/n).read_bytes();e=ix[n];h=hashlib.sha256(b).hexdigest();assert (len(b),h)==(e['bytes'],e['sha256']);merged=None
 if n.startswith('audit/'):
  merged=old/n.removeprefix('audit/');assert merged.read_bytes()==b
 name='older-774-'+n.replace('/','__')+'.gz';(ref/name).write_bytes(gzip.compress(b,mtime=0));older.append({'manifest_path':n,'merged_copy':str(merged) if merged else None,'bytes':len(b),'sha256':h,'compressed_copy':'reference/'+name,'qualification':'Exact original 774 handoff bytes checked against its manifest; preserve individual record source revision and original reviewer. Full JSONL retained; source body reads not transferred.'})
f=ref/'older-774-selection.json';f.write_text(json.dumps({'manifest_compressed':'reference/older-774-handoff-manifest.json.gz','manifest_uncompressed_sha256':hashlib.sha256(mb).hexdigest(),'records':older},indent=2)+'\n');print('774 verified',len(older));f=ref/'manifest.json';f.write_text(json.dumps({'records':refs,'older_manifest_sha256':hashlib.sha256((ref/'older-774-selection.json').read_bytes()).hexdigest()},indent=2)+'\n')
