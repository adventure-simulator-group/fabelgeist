import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=['vendor/bevy_ahoy/Cargo.toml','vendor/bevy_ahoy/src/camera.rs','vendor/bevy_ahoy/src/kcc.rs','vendor/bevy_ahoy/src/input.rs','vendor/bevy_ahoy/src/dynamics.rs','crates/adventuresim-tactical-core/src/physics.rs','crates/adventuresim-tactical-core/src/lib.rs','crates/adventuresim-tactical-server/src/player_projection.rs','crates/adventuresim-tactical-netcode/src/replication.rs']
rows=[]
for index,path in enumerate(paths):
 b=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True,check=True).stdout;name=f'support/{index:02d}-'+path.rsplit('/',1)[-1];(out/name).write_bytes(b)
 rows.append({'path':path,'revision':rev,'registered_range':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'local_path':name})
f=out/'support-registration-01.json';f.write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','scope':'Bounded connected support; actual displayed ranges recorded separately. No ordered-role or other-lens credit.','sources':rows},indent=2)+'\n');print('registration_sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(rows,indent=1))
