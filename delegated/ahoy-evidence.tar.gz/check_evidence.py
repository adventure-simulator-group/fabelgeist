import gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(r,path):return subprocess.run(['git','-C',repo,'show',r+':'+path],capture_output=True,check=True).stdout
def checkref(obj):assert sha((p/obj['path']).read_bytes())==obj['sha256']
report=json.loads((p/'report.json').read_text());reg=json.loads((p/'registration.json').read_text());checkref(report['registration']);x=reg['ordered_roles'][0];bs=[]
for v in x['versions']:
 b=(p/v['local_path']).read_bytes();assert b==git(v['revision'],x['path']);assert (len(b),len(b.splitlines()),sha(b),blob(b))==(v['bytes'],v['lines'][1],v['sha256'],v['git_blob']);bs.append(b)
assert bs[0]==bs[1]
r=report['role_records'][0];rs=r['fresh_personally_displayed_body_ranges'];assert rs[0][0]==1 and all(rs[i][1]+1==rs[i+1][0] for i in range(len(rs)-1)) and rs[-1][1]==len(bs[1].splitlines());assert r['fresh_personal_display_path']==r['current_source'] and not r['unread_assigned_ranges'] and not r['historical_body_personal_display_ranges']
registered=[]
for z in report['support_registrations']:
 checkref(z);registered+=json.loads((p/z['path']).read_text())['sources']
assert len(registered)==len(report['support'])
for s,rs in zip(registered,report['support']):
 b=(p/s['local_path']).read_bytes();assert b==git(s['revision'],s['path']);assert (len(b),len(b.splitlines()),sha(b),blob(b))==(s['bytes'],s['registered_range'][1],s['sha256'],s['git_blob']);assert rs['path']==s['path'] and rs['local_path']==s['local_path'] and rs['sha256']==s['sha256'];assert all(1<=a<=z<=s['registered_range'][1] for a,z in rs['actual_body_ranges']);assert all(1<=n<=s['registered_range'][1] for n in rs['navigation_only_displayed_line_numbers'])
for z in report['navigation_receipts']:checkref(z)
checkref(report['historical_manifest']);h=json.loads((p/'historical-manifest.json').read_text());assert not h['unavailable'];transport={x['path']:x for x in json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()))['entries']}
for x in h['records']:
 b=(p/x['copy_path']).read_bytes();e=transport[x['original_transport_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
checkref(report['reference_archives']);refs=json.loads((p/'reference/manifest.json').read_text())
for x in refs['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
checkref(report['older_774_selection']);old=json.loads((p/'reference/older-774-selection.json').read_text());assert refs['older_manifest_sha256']==report['older_774_selection']['sha256'];mb=gzip.decompress((p/old['manifest_compressed']).read_bytes());assert sha(mb)==old['manifest_uncompressed_sha256'];ix={e['path']:e for e in json.loads(mb)['files']}
for x in old['records']:
 b=gzip.decompress((p/x['compressed_copy']).read_bytes());e=ix[x['manifest_path']];assert (len(b),sha(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256']);assert x['merged_copy'] is None or b==pathlib.Path(x['merged_copy']).read_bytes()
for who,id in [('camera','CAM-PPS-SERVER-PROJECTION-EQUIPMENT-055'),('native','NATIVE-PS-SERVER-PLAYER-PROJECTION-026')]:
 row=next(x for x in old['records'] if '/'+who+'/traces.jsonl' in x['manifest_path']); raw=gzip.decompress((p/row['compressed_copy']).read_bytes());matches=[json.loads(line) for line in raw.splitlines() if json.loads(line).get('id',json.loads(line).get('trace_id'))==id];assert len(matches)==1;d=matches[0];sources=d.get('additional_actual_source_proofs',d.get('additional_actual_receivers',[]));assert any(y.get('source_id')=='pr-working:vendor/bevy_ahoy/src/lib.rs' and y.get('read_ranges')==[[282,331]] and y.get('sha256')==sha(bs[1]) for y in sources)
q=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()))
for x in report['historical_queue']:assert (q['entries'][x['index']]['contract_id'],q['entries'][x['index']].get('status'))==(x['id'],x['status_as_recovered'])
assert len(report['lens_notes'])==13
print('Evidence integrity passed: 1 identical historical/current role object, full current display union,',len(registered),'registered support Git objects with bounded ranges,',len(h['records']),'original 059 transport-verified records,',len(old['records']),'774 manifest-verified exact historical records, two original supplier JSONL scopes,',len(report['historical_queue']),'exact queue identities and 13 bounded lens perspectives.')
print('Only Git/source object, JSON, gzip, hash, range and provenance checks; no product execution, tests, builds, UI, probes or validation.')
