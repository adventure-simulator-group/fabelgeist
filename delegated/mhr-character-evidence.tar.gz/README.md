# Delegated MHR character source audit

The central audit owns the baseline, reconciliation, ordered-role statuses,
ledger and publication. This bundle is a bounded review of original roles
2316–2318 and explicitly registered support. Read `report.json` first.

`registration.json` and `read-receipt.json` identify separate personal full
reads of current 95e and historical 6533 source bodies. The support registrations
and `support-read-receipt.json` record the exact support ranges. The recorded
registration clock is a sample taken before the write; the latter receipt also
records the filesystem write times and the chronology qualification.

`git-proofs.json` and `git-objects/` preserve commit and tree membership for
all 15 source bodies. The source files are exact bytes, each independently
matched to its Git blob and SHA-256. `evidence-verification.json` describes the
evidence-only consistency check; no product validation occurred.

`historical-059/` contains original extraction bytes verified against the
original 059 transport manifest. `older-774/` contains six exact originals
recovered from earlier collections and verified against that older export's
original-record hashes, as well as two different path-normalized exports.
These provenance classes are separate: no 3821 ledger or queue was recovered
and no evidence in this bundle changes that qualification.

The locally preserved original records may include nonessential local paths.
Public copies require the central publisher's path review and explicit,
hash-documented redaction, preserving the separate original and export hashes.
