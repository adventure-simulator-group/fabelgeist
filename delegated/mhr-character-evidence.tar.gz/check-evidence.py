import hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>')
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
reg=json.loads((p/'registration.json').read_text());sregs=[json.loads((p/n).read_text()) for n in ['support-registration.json','support-registration-2.json']]
entries=[]
for e in reg['sources']:
 b=(p/e['source_file']).read_bytes();assert sha(b)==e['sha256'] and blob(b)==e['git_blob_sha1'] and len(b)==e['bytes'] and len(b.splitlines())==e['lines'];entries.append(e)
for sr in sregs:
 for e in sr['entries']:
  b=(p/e['file']).read_bytes();assert sha(b)==e['sha256'] and blob(b)==e['git_blob_sha1'] and len(b)==e['bytes'] and len(b.splitlines())==e['lines'];entries.append(e)
rr=json.loads((p/'read-receipt.json').read_text()); sr=json.loads((p/'support-read-receipt.json').read_text());byfile={e['file']:e['ranges'] for e in sr['support_displays']};allowed={}
for e in reg['sources']:
 if e['kind']=='current':allowed[e['path']]=e['planned_display_ranges']
for e in entries[6:]:allowed[e['path']]=byfile[e['file']]
report=json.loads((p/'report.json').read_text()); refs=[]
def walk(v):
 if isinstance(v,dict):
  if {'revision','path','lines'} <= v.keys() and isinstance(v['lines'],list):refs.append(v)
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(report)
for r in refs:
 assert r['revision']==report['current_authoritative_revision'] and r['path'] in allowed,r
 for a,b in r['lines']:
  assert any(x<=a<=b<=y for x,y in allowed[r['path']]),r
proof=json.loads((p/'git-proofs.json').read_text());objcache={}
for f in (p/'git-objects').iterdir():
 oid,typ=f.name.split('.');b=f.read_bytes();assert hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid;objcache[(oid,typ)]=b
for e in proof['proofs']:
 c=objcache[(e['revision'],'commit')];assert b'tree '+e['commit_tree'].encode()+b'\n' in c;tree=e['commit_tree']
 for item in e['membership']:
  assert item['parent_tree']==tree;line=item['mode'].encode()+b' '+item['entry'].encode()+b'\0'+bytes.fromhex(item['object']);assert line in objcache[(tree,'tree')];tree=item['object']
 assert tree==e['blob_sha1'] and blob((p/e['file']).read_bytes())==tree
h=json.loads((p/'historical-059-index.json').read_text())
for e in h['records']:
 b=(p/e['local_exact_copy']).read_bytes();assert sha(b)==e['sha256'] and blob(b)==e['git_blob'] and len(b)==e['bytes']
o=json.loads((p/'older-774/INDEX.json').read_text())
assert sha((p/o['export_manifest_file']).read_bytes())==o['export_manifest_sha256']
for e in o['entries']:
 b=(p/e['original_local_copy']).read_bytes();assert sha(b)==e['original_sha256']==e['older_export_manifest_entry']['original_record_sha256']
 if e['export_differs_from_original']:assert sha((p/e['normalized_export_local_copy']).read_bytes())==e['normalized_export_sha256']==e['older_export_manifest_entry']['published_export_sha256']
summary=json.loads((p/'registry-selected-reconstructed.json').read_text())
for e in reg['sources']:
 if e['kind']=='historical':assert summary['rows'][e['original_role_index']-2316]['sha256']==e['sha256']
result={'kind':'Evidence-only consistency verification','status':'passed','ordered_body_count':len(reg['sources']),'support_body_count':len(entries)-len(reg['sources']),'source_references_within_personal_displays':len(refs),'git_path_proof_count':len(proof['proofs']),'git_commit_tree_objects':len(objcache),'original_059_exact_records':len(h['records']),'older_774_exact_original_records':len(o['entries']),'older_774_distinct_normalized_exports':sum(e['export_differs_from_original'] for e in o['entries']),'qualification':'No product code, tests, builds, runtime probes, fixtures or validation were executed; all checks verify preserved audit evidence only.'}
(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
