import gzip,hashlib,json,pathlib
b=pathlib.Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
oid=lambda k,x:hashlib.sha1(k.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
report=json.loads((b/'REPORT.json').read_bytes())
h=json.loads((b/'history-manifest.json').read_bytes())
m=json.loads(gzip.decompress((b/'original-transport-manifest.json.gz').read_bytes()))
index={x['path']:x for x in m['entries']}
assert sha((b/'original-transport-manifest.json.gz').read_bytes())==h['original_transport_manifest_sha256']
for e in h['original_059_records']:
    raw=(b/e['preserved_bytes']).read_bytes();want=index[e['original_path']]
    assert len(raw)==e['bytes']==want['bytes'] and sha(raw)==e['sha256']==want['sha256'] and oid('blob',raw)==e['git_blob']==want['git_blob'],e['original_path']
for e in h['older_774_receipts']:
    raw=(b/e['preserved_bytes']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob'],e['transport_path']
for name in ['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json']:
    raw=(b/name).read_bytes();assert sha(raw)==report['registrations'][name]['sha256'];r=json.loads(raw)
    for e in r['entries']:
        dest=(b/'sources'/e['revision'][:4]/e['path']) if name=='registration.json' else (b/'support'/e['path'])
        v=dest.read_bytes();assert len(v)==e['bytes'] and sha(v)==e['sha256'] and oid('blob',v)==e['git_blob'],e['path']
for r in report['original_roles']:
    assert (b/r['current_bytes']).read_bytes()==(b/r['historical_bytes']).read_bytes()
    assert not r['historical_personal_displayed_ranges']
for name in ['queue','ledger']:
    e=report['evidence_files']['original_059_'+name]
    assert sha(gzip.decompress((b/e['path']).read_bytes()))==e['uncompressed_sha256']
selection=json.loads((b/'registry-selection-reconstructed.json').read_bytes())
assert sha((b/selection['exact_registry_gzip']).read_bytes())==selection['exact_registry_gzip_sha256']
registry=json.loads(gzip.decompress((b/selection['exact_registry_gzip']).read_bytes()))
for i,row in enumerate(selection['rows'],2327):
    assert row['original_index']==i and {k:v for k,v in row.items() if k!='original_index'}==registry['files'][i]
p=json.loads((b/'git-proofs.json').read_bytes());objects={}
for oid_key,e in p['objects'].items():
    raw=gzip.decompress((b/e['preserved_bytes']).read_bytes())
    assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==oid_key
    objects[oid_key]=raw
def entries(raw):
    result={};i=0
    while i<len(raw):
        end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1)
        result[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());i=end+21
    assert i==len(raw)
    return result
for e in p['paths']:
    c=p['commits'][e['revision']]
    assert objects[c['commit_object']].splitlines()[0]==b'tree '+c['root_tree'].encode()
    current=c['root_tree']
    for link in e['path_chain']:
        assert link['tree']==current
        mode,child=entries(objects[current])[link['name']]
        assert mode==link['mode'] and child==link['object']
        current=child
    assert current==e['git_blob'] and '/'.join(x['name'] for x in e['path_chain'])==e['path']
assert not h['unavailable_original_records']
assert len(report['thirteen_lens_dispositions'])==13
print('Evidence integrity passed:',len(h['original_059_records']),'original 059 records,',len(h['older_774_receipts']),'older 774 records/variants,',len(p['paths']),'Git path proofs and',len(p['objects']),'Git commit/tree objects; registered source bytes, original queue/ledger, registry selection and registrations verified. No product tests or probes.')
