# Bounded checkpoint 17 reconciliation proposal

This additive packet concerns original roles 2621 and 2622 and current revision
95e63628f9d70b8dd6e6fede64334696c6995009. `report.json` gives the proposed
existing-ledger and historical relationships, safeguards and open questions.
This is source-only evidence, with no repair, product validation or lens closure.

`registration.json` predates this packet's independent source displays;
`read-receipt.json` records their actual ranges and unread complements. Full
saved support bytes do not constitute full personal reads. Both assigned
historical/current bodies were separately displayed. The same author's earlier
checkpoint 17 support registration documents an unregistered one-line locator
display of joint_cup.rs:142; that incident receives no credit and this packet's
later registered reread does not erase or reattribute it. `git-proofs.json` and
compressed Git objects prove per-file membership. f82 is transport, and recorded
6533 pr-working HEAD has unrelated modifications.

`reference/` preserves exact baseline materials and earlier reconstructed 059
queue and ledger. The 059 and registry selection files are newly reconstructed
exact selections, not original receipts. `history-059/` is checked against the
original transport manifest; `history-774/` is tree-proved f82 evidence. The
historical index retains both rig registration-prefix hash mismatches and the
matching qualification pins without assigning a cause. q140's recorded revision
and attribution remain null in its original source views.

`prior/` is a hash-checked selection of the earlier frozen same-author packet.
`public-prior-members.json` distinguishes original versus public identities;
the selected report, registration, receipt and historical index are unchanged.
Other member redactions remain qualified in checkpoint 17 metadata. Original
reviewers retain their own ranges and revisions, and no historical material is
promoted to checkpoint 3821.

`verification.json` is evidence-integrity verification, not product validation.
The root manifest hashes every packet file except itself, including nested
manifests. `staging-qualification.json` preserves a failed verifier-adaptation
attempt that wrote no verifier; its corrected successor was run before freeze.
No old verifier or product code was executed.
