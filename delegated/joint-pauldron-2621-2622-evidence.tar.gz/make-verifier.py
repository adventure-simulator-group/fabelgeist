from pathlib import Path
s=Path('<LOCAL_PATH_0>').read_text()
repls=[("(2615,2616)","(2621,2622)"),("'5e98f9550e19a46e5d41fd05d5807920d99a23820a0c2684e256e50c5dce07bf'","'8a2a09de2cb8dcca93053a669a945a9e0ec0f78331e52d7a3afb7dffc69f249d'"),("'armor-pierced-sampling-hair-ops'","'armor-joint-pauldron'"),("==[609,1813,3141]","==[140,1817,1818]"),("['entries'][471]['id']=='REVIEW-L3-HELMET-CARRIER-TOPOLOGY-ADMISSION' and baseline['newly_assessed_ledger']['entries'][472]['id']=='REVIEW-BUFFE-BREATH-COURSE-CONTEXT-95E'","['entries'][477]['id']=='REVIEW-PAULDRON-CARRIER-DESIGN-ASSOCIATION-95E' and baseline['newly_assessed_ledger']['entries'][478]['id']=='REVIEW-PAULDRON-RECORD-CARRIER-STATUS-95E'"),("len(proof['proofs'])==19","len(proof['proofs'])==22"),("explicit sampling unread complements","explicit support unread complements")]
for a,b in repls:
 assert a in s,a;s=s.replace(a,b)
start=s.index("assert (p/'source/pr-working-2615.rs')");end=s.index("\nqraw=",start)
s=s[:start]+"for role in (2621,2622):assert (p/f'source/pr-working-{role}.rs').read_bytes()==(p/f'source/current-{role}.rs').read_bytes()"+s[end:]
s=s.replace("for i in (609,1813):","for i in (1817,1818):").replace("q['entries'][3141]['exact_source_identities_and_assessed_ranges']","q['entries'][140]['exact_source_identities_and_assessed_ranges']")
s=s.replace("('L11-427','L12-893','L12-894')","('L11-428','L12-896','L12-732')").replace("READ-L11-427.json","READ-L11-428.json")
s=s.replace("assert len(l11)==3 and [e['fresh_personal_body_reads'] for e in l11]==[[[1,188]],[[1,43]],[[44,45]]]","assert len(l11)==2 and [e['fresh_personal_body_reads'] for e in l11]==[[[1,51]],[[1,141]]]")
start=s.index("for n,role,ran in ");end=s.index("\nrefs=[]",start)
s=s[:start]+"""read=load('history-059/segovb/READ-L12-896.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes())
for role,ran in [(2621,[[1,51]]),(2622,[[1,141]])]:
 e=next(z for z in read['rows'] if z['original_index']==role);assert e['fresh_personal_body_reads']==ran and e['source_sha256']==reg['files'][role]['sha256'] and e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes())
read732=load('history-059/segovb/READ-L12-732.json');assert read732['root_personal_rereads']==[] and read732['proposal_sha256']==sha((p/'history-059'/read732['proposal']).read_bytes())"""+s[end:]
s=s.replace("walk(q['entries'][3141],'/entries/3141')","walk(q['entries'][140],'/entries/140')")
s=s.replace("assert next(v for v in members['members'] if v['path']=='historical-manifest.json')['changed'] and not next(v for v in members['members'] if v['path']=='REPORT.json')['changed'] and sha((p/'reference/published-prior-report.json').read_bytes())==sha((p/'prior/REPORT.json').read_bytes())","assert all(not v['changed'] for v in members['members']) and sha((p/'reference/published-prior-report.json').read_bytes())==sha((p/'prior/report.json').read_bytes())")
s=s.replace("((2615,62),(2616,63))","((2621,69),(2622,70))")
start=s.index("adds=gzip.decompress");end=s.index("\nproof=",start)
s=s[:start]+"""adds=gzip.decompress((p/'history-774/continuation/rig/admission03/additional-contracts.jsonl.gz').read_bytes()).splitlines();d69=json.loads(adds[54]);d70=json.loads(adds[55]);assert d69['id']=='RIG-ADMISSION03-ADDITIONAL-069' and d69['actual_source_ranges']==[[1,51]] and d70['id']=='RIG-ADMISSION03-ADDITIONAL-070' and d70['actual_source_ranges']==[[1,141]]
findings=gzip.decompress((p/'history-774/continuation/rig/admission03/findings.jsonl.gz').read_bytes()).splitlines();f052=json.loads(findings[52]);assert f052['id']=='RIG-ADMISSION03-F052' and 'lower_lames255' in f052['finding']
groups=gzip.decompress((p/'history-774/continuation/rig/admission03/contract-groups.jsonl.gz').read_bytes()).splitlines();assert json.loads(groups[595])['id']=='RIG-ADMISSION03-CONTRACT-596' and json.loads(groups[604])['id']=='RIG-ADMISSION03-CONTRACT-605'
assert 'line 142' in load('prior/support-registration-03.json')['navigation_qualification']"""+s[end:]
s=s.replace("'public_historical_manifest_redacted':True","'selected_public_prior_members_unchanged':True")
s=s.replace("revision diff and membership proofs", "per-file equality and membership proofs")
Path('<LOCAL_PATH_1>').write_text(s)
