# SATS admission and historical queue reconciliation

This additive packet relates older 059 queue records 131, 2332 and 3443 to
original native roles 2561–2562 and bounded 95e project evidence. Start with
`REPORT.json`. Registrations and `personal-read-receipt.json` list the exact
newly displayed ranges; preserved full bytes do not enlarge them. Each package
archive and its lockfile selections retain distinct native and project
identities. Earlier reviewer records and ranges remain separately attributed.

The full older 059 registry, queue, ledger and transport manifest are retained
in gzip; selected entries are mechanical reconstructions. Selected historical
transcript projections are normalized printed values, not original queue bytes,
a complete queue, current status or checkpoint 3821. The original 774 camera
and native review records retain their scopes and date. A later matching P16
tracked patch is preserved with its separate untracked-file, invocation and
custody qualifications. `git-proofs.json` authenticates individual commit-tree
paths and historical source transports.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` for read-only
evidence integrity checks. No product, macro, build, test, fixture or runtime
probe was executed; no repair or source/publication edit was made.
