from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).parent;r=json.loads((b/'registration.json').read_bytes());e=json.loads((b/'extra-registration.json').read_bytes());chunks={'native-2561':[[251,293]],'native-2562':[[30,96],[145,171],[273,332],[333,392],[625,688],[689,752]],'world-cargo':[[1,31]],'module-cargo':[[1,31]],'basis':[[1,75],[76,151]],'disease':[[1,45],[600,650],[825,855],[1580,1620]],'exposure':[[1,77]],'lock-6533':[[10242,10255]],'lock-95e':[[9784,9797]],'lib':[[39,49]],'sats-lib':[[74,96]],'typespace':[[300,325]],'native-2562-extra':[[393,480]]}
def union(xs):
 out=[]
 for a,z in sorted(xs):
  if out and a<=out[-1][1]+1:out[-1][1]=max(out[-1][1],z)
  else:out.append([a,z])
 return out
def complement(xs,eof):
 out=[];n=1
 for a,z in union(xs):
  if a>n:out.append([n,a-1])
  n=z+1
 if n<=eof:out.append([n,eof])
 return out
rows=[]
for x in r['entries']+e['entries']:
 c=chunks[x['id']];assert union(c)==union(x['prospective_ranges']);rows.append({'id':x['id'],'sha256':x['sha256'],'archive':x['archive'],'actual_chunks':c,'actual_union':union(c),'unread_complement_of_this_registration':complement(c,x['eof']),'eof':x['eof'],'registration':'registration.json' if x in r['entries'] else 'extra-registration.json'})
(b/'personal-read-receipt.json').write_text(json.dumps({'schema':'726-sats-queue-personal-display-v1','recorded_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','registration_sha256':hashlib.sha256((b/'registration.json').read_bytes()).hexdigest(),'extra_registration_sha256':hashlib.sha256((b/'extra-registration.json').read_bytes()).hexdigest(),'entries':rows,'qualification':'Individual exact untruncated displayed chunks only. The separate additional native role window is not counted in the first registration complement; prior reviewer displays and full byte retention grant no new personal or historical credit.'},indent=2)+'\n');print('recorded',len(rows))
