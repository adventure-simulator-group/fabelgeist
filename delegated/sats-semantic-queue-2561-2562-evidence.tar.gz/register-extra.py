from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,io,tomllib
b=Path(__file__).parent;repo=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();sources=[];archives=[]
for package,filename,expected,members in [('spacetimedb-lib','<LOCAL_PATH_1>','bceaf72bdbf1a624d55d17ebaa38f8cf78a4972e43641c6cbf94f82318b5581d',[('lib','src/lib.rs',[[39,49]])]),('spacetimedb-sats',str(repo/'native-evidence/spacetimedb-sats-2.6.1/spacetimedb-sats-2.6.1.crate'),'6cefb87b7d5e760d43cb65855591e25af772bdcca19562e5796ae797240d1998',[('sats-lib','src/lib.rs',[[74,96]]),('typespace','src/typespace.rs',[[300,325]])])]:
 raw=Path(filename).read_bytes();assert sha(raw)==expected;dest='source/'+package+'.crate';(b/dest).write_bytes(raw);archives.append({'package':package,'version':'2.6.1','archive':dest,'sha256':sha(raw),'bytes':len(raw)})
 for lock in ['lock-6533.toml','lock-95e.toml']:
  packs=tomllib.loads((b/'source'/lock).read_text())['package'];p=next(x for x in packs if x['name']==package and x['version']=='2.6.1');assert p['checksum']==expected
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  for id,path,ranges in members:
   member=package+'-2.6.1/'+path;d=t.extractfile(member).read();dest='source/'+id+'.rs';(b/dest).write_bytes(d);sources.append({'id':id,'kind':'native-support','package':package,'version':'2.6.1','package_sha256':expected,'archive':dest,'member':member,'sha256':sha(d),'bytes':len(d),'eof':len(d.splitlines()),'prospective_ranges':ranges})
source=(b/'source/native-2562.rs').read_bytes();sources.append({'id':'native-2562-extra','kind':'separate-fresh-role-window','original_role':2562,'archive':'source/native-2562.rs','sha256':sha(source),'bytes':len(source),'eof':len(source.splitlines()),'prospective_ranges':[[393,480]]})
(b/'extra-registration.json').write_text(json.dumps({'schema':'726-sats-semantic-extra-registration-v1','author':'/root/rig_identity','registered_utc':datetime.now(timezone.utc).isoformat(),'archives':archives,'entries':sources,'qualification':'Additional native crate members independently checksum-matched to both project locks as data; no feature resolution, generated macro execution or product code. Extra role window prospectively registered separately.'},indent=2)+'\n');print(json.dumps(sources,indent=2))
