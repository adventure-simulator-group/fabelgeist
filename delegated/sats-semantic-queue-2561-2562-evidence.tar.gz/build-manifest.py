from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
b=Path(__file__).resolve().parent;files=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':
  d=p.read_bytes();files.append({'path':str(p.relative_to(b)),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
(b/'MANIFEST.json').write_text(json.dumps({'schema':'726-sats-semantic-queue-manifest-v1','created_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','self_excluded':True,'qualification':'Bounded source evidence and separately attributed historical material; reconstructed records are marked.','files':files},indent=2)+'\n');print('manifest files',len(files))
