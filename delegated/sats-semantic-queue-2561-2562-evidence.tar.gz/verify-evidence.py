from pathlib import Path
from collections import Counter
from datetime import datetime
import gzip,hashlib,io,json,tarfile,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();j=lambda p:json.loads((b/p).read_bytes());reg=j('registration.json');extra=j('extra-registration.json');receipt=j('personal-read-receipt.json');hist=j('historical-attribution.json');report=j('REPORT.json');proof=j('git-proofs.json');es={x['id']:x for x in reg['entries']+extra['entries']};rs={x['id']:x for x in receipt['entries']}
def union(ranges):
 out=[]
 for a,z in sorted(ranges):
  assert 1<=a<=z
  if out and a<=out[-1][1]+1:out[-1][1]=max(out[-1][1],z)
  else:out.append([a,z])
 return out
def complement(ranges,eof):
 out=[];n=1
 for a,z in union(ranges):
  if a>n:out.append([n,a-1])
  n=z+1
 if n<=eof:out.append([n,eof])
 return out
assert sha((b/'registration.json').read_bytes())==receipt['registration_sha256'] and sha((b/'extra-registration.json').read_bytes())==receipt['extra_registration_sha256'];assert datetime.fromisoformat(reg['registered_utc'])<=datetime.fromisoformat(receipt['recorded_utc']) and datetime.fromisoformat(extra['registered_utc'])<=datetime.fromisoformat(receipt['recorded_utc'])
for id,e in es.items():
 d=(b/e['archive']).read_bytes();r=rs[id];assert sha(d)==e['sha256']==r['sha256'] and len(d)==e['bytes'] and len(d.splitlines())==e['eof'];assert union(r['actual_chunks'])==r['actual_union']==union(e['prospective_ranges']);assert complement(r['actual_union'],e['eof'])==r['unread_complement_of_this_registration']
 if 'git_blob' in e:assert oid('blob',d)==e['git_blob']
archives={'spacetimedb-bindings-macro':{'path':'source/package.crate','sha256':'fce86c7657dcb42a33ce55f0100f98964dc15b64e79f06803a478676b74d6c82'}}
for x in extra['archives']:archives[x['package']]={'path':x['archive'],'sha256':x['sha256']}
for package,x in archives.items():
 data=(b/x['path']).read_bytes();assert sha(data)==x['sha256']
 for lock in ('source/lock-6533.toml','source/lock-95e.toml'):
  pkgs=tomllib.loads((b/lock).read_text())['package'];p=next(v for v in pkgs if v['name']==package and v['version']=='2.6.1');assert p['checksum']==x['sha256']
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
  for e in es.values():
   if e.get('package')==package and e.get('member'):assert t.extractfile(e['member']).read()==(b/e['archive']).read_bytes()
assert len(report['thirteen_bounded_perspectives'])==13
refs=[]
for finding in report['findings_and_relationships']:refs+=finding['source_refs']
for x in refs:
 e=es[x['id']];assert x['archive']==e['archive'] and x['sha256']==e['sha256']
 for a,z in x['lines']:assert any(a>=i and z<=k for i,k in rs[x['id']]['actual_union']),(x['id'],a,z)
for x in hist['references']:
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'];
 if x['archive'].endswith('.gz'):
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
registry_raw=gzip.decompress((b/'history/original-registry.json.gz').read_bytes());assert sha(registry_raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(registry_raw);sel=j('history/registry-selection-reconstructed.json')
for x in sel['roles']:assert x['entry']==registry['files'][x['index']]
for role in (2561,2562):assert registry['files'][role]['sha256']==es['native-'+str(role)]['sha256']
for role,id in [(2672,'lib'),(2673,'sats-lib'),(2674,'typespace')]:assert registry['files'][role]['sha256']==es[id]['sha256']
q=json.loads(gzip.decompress((b/'history/baseline-059-queue.json.gz').read_bytes()))['entries'];selection=j('history/queue-selection-reconstructed.json')
for x in selection['entries']:assert x['entry']==q[x['index']]
assert [(q[i]['contract_id'],q[i]['status']) for i in (131,2332,3443)]==[('ADLER-L11-BASIS-POINTS-WIRE-ADMISSION','open-reconciliation'),('L12-CLOSURE-NATIVE-SATS-REFLECTION-ADAPTER-OWNERS','open-source-reconciliation'),('L12-CLOSURE-PHYSICAL-SATS-NAMESPACE','open-source-reconciliation')]
mi=json.loads(gzip.decompress((b/'history/original-transport-manifest.json.gz').read_bytes()));index={x['path']:x for x in mi['entries']}
for x in hist['records_059']:
 d=(b/x['archive']).read_bytes();m=index[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
for x in hist['records_774']:
 d=(b/x['archive']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['original_bytes'] and sha(raw)==x['original_sha256'] and oid('blob',raw)==x['git_blob']
for p in hist['prior_packets']:
 copies={x['name']:x for x in p['copies']};m=copies['MANIFEST.json'];assert m['sha256']==p['original_manifest_sha256'];manifest=j(m['archive']);idx={x['path']:x for x in manifest['files']}
 for x in p['copies']:
  d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'];
  if x['name']!='MANIFEST.json':assert idx[x['name']]['sha256']==x['sha256']
fr=j('history/fragments-selected-reconstructed.json');idx=json.loads(gzip.decompress((b/'history/fragments/EXTENDED-INDEX.json.gz').read_bytes()));assert idx['snapshot_sha256']==fr['snapshot_sha256'];ids={'ADLER-L11-BASIS-POINTS-WIRE-ADMISSION','L12-CLOSURE-NATIVE-SATS-REFLECTION-ADAPTER-OWNERS','L12-CLOSURE-PHYSICAL-SATS-NAMESPACE'};assert fr['index_hits']==[x for x in idx['entries'] if x['contract_id'] in ids];keys={x['normalized_sha256'] for x in fr['index_hits']};allvalues=[json.loads(x) for x in gzip.decompress((b/'history/fragments/PRINTED-VALUES.jsonl.gz').read_bytes()).splitlines()];assert fr['values']==[x for x in allvalues if x['normalized_sha256'] in keys]
for x in fr['values']:
 d=(json.dumps(x['value'],indent=2,ensure_ascii=False)+'\n').encode();assert sha(d)==x['normalized_sha256']
assert next(x['value']['status'] for x in fr['values'] if x['normalized_sha256']=='74abcc32b987c41eb9cb8afcb378537d5ee592a221a83cfbd310f7d98964376b')=='source-discovery-complete-with-owned-repair';assert sha((b/'history/p16-reproduced-tracked.patch').read_bytes())=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
objects={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved_bytes']).read_bytes());assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==key;objects[key]=(x['type'],raw)
def tree(raw):
 d={};i=0
 while i<len(raw):
  end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1);d[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());i=end+21
 return d
for rev,c in proof['commits'].items():
 typ,data=objects[rev];assert typ=='commit' and data.splitlines()[0].split()[1].decode()==c['root_tree']
for p in proof['paths']:
 d=(b/p['preserved_bytes']).read_bytes();d=gzip.decompress(d) if p['preserved_bytes'].endswith('.gz') else d;assert len(d)==p['bytes'] and sha(d)==p['sha256'] and oid('blob',d)==p['git_blob'];cur=proof['commits'][p['revision']]['root_tree'];segs=p['path'].split('/');assert len(segs)==len(p['path_chain'])
 for seg,ch in zip(segs,p['path_chain']):
  assert ch['tree']==cur and ch['name']==seg;typ,raw=objects[cur];assert typ=='tree';mode,cur=tree(raw)[seg];assert mode==ch['mode'] and cur==ch['object']
 assert cur==p['git_blob']
print(json.dumps({'schema':'726-sats-semantic-evidence-verification-v1','status':'passed','source_registrations':len(es),'source_references':len(refs),'native_package_archives':len(archives),'git_membership_paths':len(proof['paths']),'raw_git_objects':len(objects),'exact_059_records':len(hist['records_059']),'older_774_records':len(hist['records_774']),'normalized_printed_values':len(fr['values']),'qualifications':'Evidence-only parsing, hashing and Git object/path membership. No source execution, macro expansion, product build, test, fixture or probe.'},indent=2))
