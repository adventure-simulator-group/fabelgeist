from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objs={};commits={};proofs=[]
def save(t,k):
 if k not in objs:
  d=g('cat-file',t,k);assert oid(t,d)==k;p='git-objects/'+k+'.'+t+'.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(d,mtime=0));objs[k]={'type':t,'sha256':sha(d),'bytes':len(d),'preserved_bytes':p}
 return gzip.decompress((b/objs[k]['preserved_bytes']).read_bytes())
def entries(raw):
 out={};i=0
 while i<len(raw):
  end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1);out[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());i=end+21
 return out
def root(rev):
 if rev not in commits:
  d=save('commit',rev);commits[rev]={'root_tree':d.splitlines()[0].split()[1].decode(),'parent_objects':[x.split()[1].decode() for x in d.splitlines() if x.startswith(b'parent ')]}
 return commits[rev]['root_tree']
def proof(rev,path,file,kind):
 data=(b/file).read_bytes();data=gzip.decompress(data) if file.endswith('.gz') else data;cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',data)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(data),'bytes':len(data),'git_blob':cur,'preserved_bytes':file,'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for x in json.loads((b/'registration.json').read_bytes())['entries']:
 if x['kind']=='pinned-crate-native':proof(f82,x['transport_path'],x['archive'],'original native source transport; no project Git revision')
 else:proof(x['revision'],x['git_path'],x['archive'],'pinned project source/lock; exact range in receipt')
for x in json.loads((b/'extra-registration.json').read_bytes())['entries']:
 if x['kind']=='native-support':proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],x['archive'],'registered additional native package member transport')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(f82,x['transport_path'],x['archive'],'older 774 historical record transport')
(b/'git-proofs.json').write_text(json.dumps({'schema':'726-sats-semantic-git-proofs-v1','commits':commits,'objects':objs,'paths':proofs,'qualification':'Git membership authenticates project objects and historical transports; native package version/archive identity is separately checksum bound. No worktree, feature-resolution or product execution assertion.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objs))
