from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;raw=(b/'registration.json').read_bytes();reg=json.loads(raw);chunks={2786:[[3,17],[19,36]],2787:[[6,40],[41,75],[76,106]],2789:[[50,79]]};out=[]
for e in reg['entries']:
 ch=chunks[e['role']];covers={i for a,z in ch for i in range(a,z+1)};missing=[];start=None
 for i in range(1,e['eof']+2):
  if i<=e['eof'] and i not in covers and start is None:start=i
  elif (i>e['eof'] or i in covers) and start is not None:missing.append([start,i-1]);start=None
 out.append({'registration_id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':missing,'qualification':'Separate historical/current bounded body displays; stored bytes grant no unread complement credit.'})
(b/'read-receipt.json').write_text(json.dumps({'schema':'726-personal-read-receipt-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(raw).hexdigest(),'entries':out},indent=2)+'\n');print('recorded',len(out),'separate displays')
