# Viewer museum, report bones and procedural rig evidence

This source-only packet by `/root/rig_identity` covers pr-working role 2786
and report-p17 roles 2787 and 2789. Current source is pinned to
`95e63628f9d70b8dd6e6fede64334696c6995009`. Each historical object matches the
same individual path at P17 base 18360, P17 head 90a, pr-working head 6533 and
the pinned current revision. The two historical snapshots, reviewer reads
and full worktree states remain distinct.

`REPORT.json` contains bounded findings, nonfindings, thirteen lens
perspectives and open questions. `registration.json` and `read-receipt.json`
retain each prospectively registered historical/current personal display.
Current supports, including further rig binding, are separately registered;
full archived source bytes do not establish read credit for excluded ranges.
`native-registration.json` describes an installed Rust standard-library source
copy separately from project Git and does not prove compiler selection.

`history/` retains original registry and transport manifest, 059 records,
Git-proved f82-transported 774 records, historical summaries, a prior exact
capture packet, and later P17 patch recovery with raw Git delta proof. Registry
and queue selections are mechanically reconstructed from retained originals.
One 059 summary says 29 BoneRole variants; exact scoped source and the 774 rig
record show 27. Both the original words and the later correction are retained.
The three selected old registration rows match the registry, but their entire
f82 files have different hashes from the registry-recorded whole-file hashes;
the cause and missing variants remain unknown.

The 059 source payload Git path was unavailable in inspected stores; selected
extracted records match its original transport manifest by size, SHA-256 and Git
blob ID. The reproduced P17 patch matches the recorded digest and its 85 Git
objects prove the 32-path delta. Matching bytes do not prove the original
invocation, uninterrupted custody, current worktree cleanliness, completed
shared motor work or checkpoint 3821. No earlier state is promoted into 3821.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` for evidence
integrity only. The verifier checks the archived delta and patch hash; it does
not reproduce the patch itself or validate product behavior. No viewer,
fixture, rendering, simulation, product execution, macro, repair, build, test,
or runtime probe was performed. Central owns reconciliation and publication.
