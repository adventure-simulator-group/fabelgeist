from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json');names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','native-registration.json'];groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2786,2787,2789]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
p17=next(x for x in registry['snapshots'] if x['id']=='report-p17');pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');recovery=load('history/p17-patch-recovery.json')
assert p17['base']=='18360adba0fb43add88c75dfbd2f45d7e71d8ace' and p17['head']=='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696' and p17['status_porcelain']==[] and p17['changed_variants']==32
patch=(b/'history/p17-tracked.patch').read_bytes();assert p17['patch_sha256']==sha(patch)=='3c72c8c4f9816b49ae6306994d55571ceeff420b5a47bb5ff8bcec3c6668c9cd' and recovery['recovered_patch']['bytes']==len(patch) and recovery['recorded_base']==p17['base'] and recovery['recorded_head']==p17['head']
assert pr['base']=='3a50b708381ad00c116445c2c999a49c3943088b' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
 if name!='native-registration.json':assert oid('blob',d)==x['git_blob']
for role,ranges in [(2786,[[3,17],[19,36]]),(2787,[[6,106]]),(2789,[[50,79]])]:
 old=regs[('registration.json',f'{role}-historical')];cur=regs[('registration.json',f'{role}-current')];assert old['sha256']==registry['files'][role]['sha256'] and old['prospective_personal_read_ranges']==registry['files'][role]['material_ranges']==ranges
 assert all(old['comparison_metadata'][k]['equal_to_historical'] for k in ['p17_base','p17_head','pr_head','current']) and old['sha256']==cur['sha256'] and (b/old['archive']).read_bytes()==(b/cur['archive']).read_bytes()
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];sel=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in sel['entries']]==[1151,1216,1229,1231]
for x in sel['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[1229]['contract_id']=='Q-L12-702460b99f30e116d7c9'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
r=load('history/059/segovb/READ-L11-454.json')
for role,ranges in [(2786,[[3,17],[19,36]]),(2787,[[6,106]]),(2789,[[50,79]])]:
 e=next(x for x in r['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==ranges and e['sha256']==registry['files'][role]['sha256']
assert any('29variant' in x for x in r['role_dispositions'])
r=load('history/059/segovb/READ-L11-482.json');e=next(x for x in r['rows'] if x['overlay_index']==223);assert e['fresh_personal_body_reads']==[] and e['reused_ranges']==[[108,129]] and e['source_id']==registry['files'][2787]['source_id']
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
for role in [2786,2787,2789]:
 for x in registry['files'][role]['scope_registration']:
  path='history/774/'+x['record'].removeprefix('continuation/')+'.gz';raw=gun(path);rows=[json.loads(z) for z in raw.splitlines()];assert sha(raw)!=x['sha256'] and rows[x['row_1based']-1]==x['original_record']
for kind in ['native','rig']:
 path='history/774/'+('native/initial05-aggregate-states/' if kind=='native' else 'rig/initial06-type-ownership/')+'source-range-registration.jsonl.gz';assert sha(gun(path))==history['registration_file_hash_mismatch'][kind]['f82_actual']
nativequals=[json.loads(z) for z in gun('history/774/native/initial05-aggregate-states/source-qualifications.jsonl.gz').splitlines()];assert next(x for x in nativequals if x.get('id')=='NATIVE-INITIAL05-QUAL015')['qualified_material_ranges']==[[3,17],[19,36]] and next(x for x in nativequals if x.get('id')=='NATIVE-INITIAL05-QUAL016')['qualified_material_ranges']==[[6,106]]
assert 'closed27' in json.dumps(load('history/774/rig/initial06-type-ownership/contracts-062.json.gz') if False else json.loads(gun('history/774/rig/initial06-type-ownership/contracts-062.json.gz')))
for x in history['prior_packets']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 with tarfile.open(fileobj=io.BytesIO(d),mode='r:gz') as t:
  members={m.name for m in t.getmembers() if m.isfile()};mraw=t.extractfile(x['manifest_name']).read();assert sha(mraw)==x['manifest_sha256'];m=json.loads(mraw);assert {f['path'] for f in m['files']}|{x['manifest_name']}<=members
  for f in m['files']:
   raw=t.extractfile(f['path']).read();assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
  assert sha(t.extractfile(x['report_name']).read())==x['report_sha256']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
assert len(proof['paths'])==40
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
# Verify archived P17 changed-tree objects and full 32-path difference without running product or rebuilding the patch.
archive=(b/'history/p17-git-delta-proof.tar.gz').read_bytes();assert sha(archive)==recovery['git_tree_delta_proof']['sha256']
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
 members=t.getmembers();assert all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in members);data={x.name:t.extractfile(x).read() for x in members};assert len(data)==len(members)
d=json.loads(data['proof.json']);go={}
for h,x in d['objects'].items():
 raw=data[x['archive']];assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and oid(x['type'],raw)==h;go[h]=(x['type'],raw)
assert len(go)==85 and d['base']==p17['base'] and d['head']==p17['head'];assert set(data)=={'proof.json'}|{x['archive'] for x in d['objects'].values()}
for k in ('base','head'):assert go[d[k]][1].splitlines()[0]==b'tree '+d[k+'_tree'].encode()
leaves=[]
def walk(a,c,path):
 left=entries(go[a][1]) if a else {};right=entries(go[c][1]) if c else {}
 for name in sorted(left.keys()|right.keys()):
  x=left.get(name);y=right.get(name)
  if x==y:continue
  p=path+name
  if (x and x[0].lstrip('0')=='40000') or (y and y[0].lstrip('0')=='40000'):
   assert not x or x[0].lstrip('0')=='40000';assert not y or y[0].lstrip('0')=='40000';walk(x[1] if x else None,y[1] if y else None,p+'/')
  else:
   for t in (x,y):
    if t:assert t[0].lstrip('0')=='100644' and go[t[1]][0]=='blob'
   leaves.append({'path':p,'base':{'mode':x[0].lstrip('0'),'blob':x[1]} if x else None,'head':{'mode':y[0].lstrip('0'),'blob':y[1]} if y else None})
walk(d['base_tree'],d['head_tree'],'');assert leaves==d['changed_paths'] and len(leaves)==32
coverage={}
def record(regname,id,chunks,unread,when,recorded_sha):
 x=regs[(regname,id)];assert datetime.fromisoformat(groups[regname]['at_utc'])<datetime.fromisoformat(when) and recorded_sha==x['sha256'];actual={i for a,z in chunks for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in unread for i in range(a,z+1)};assert actual<=planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage.setdefault(id,set()).update(actual)
a=load('read-receipt.json');assert a['registration_sha256']==sha((b/'registration.json').read_bytes())
for e in a['entries']:record('registration.json',e['registration_id'],e['actual_display_chunks'],e['unread_complement'],a['at_utc'],e['sha256'])
s=load('support-read-receipt.json')
for x in s['registrations']:assert x['sha256']==sha((b/x['path']).read_bytes())
for e in s['entries']:record(e['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
n=load('native-read-receipt.json');assert n['registration_sha256']==sha((b/'native-registration.json').read_bytes())
for e in n['entries']:record('native-registration.json',e['id'],e['actual_display_chunks'],e['unread_complement'],n['at_utc'],e['sha256'])
assert len(regs)==22 and len(coverage)==22
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(e['id']==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
src=(b/'sources/2789-current.source').read_text().splitlines();assert sum(1 for line in src[51:78] if line.strip().endswith(','))==27
print(json.dumps({'status':'PASS','registered_personal_scopes':len(regs),'assigned_historical_material':{'2786':[[3,17],[19,36]],'2787':[[6,106]],'2789':[[50,79]]},'059_records_manifest_matched':len(history['records_059']),'774_records_git_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'prior_exact_packet_verified':True,'p17_patch_digest_verified':True,'p17_raw_git_objects_and_delta_paths_verified':[len(go),len(leaves)],'p17_patch_reproduction_qualification':'Earlier reproduction report retained; this verifier does not rerun git diff or prove original invocation/custody','bone_role_variant_count':27,'bounded_lenses':13,'native_stdlib':'Installed pinned-channel source bytes only; no proof actual compiler selection','product_build_test_fixture_execution_probe_validation':'not performed'},indent=2))
