from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;raw=(b/'native-registration.json').read_bytes();reg=json.loads(raw);chunks={'btree-map':[[1705,1718],[2535,2555]],'btree-dedup':[[1,25],[26,49]],'stable-sort':[[135,145],[185,200]]};out=[]
for e in reg['entries']:
 ch=chunks[e['id']];have={i for a,z in ch for i in range(a,z+1)};miss=[];start=None
 for i in range(1,e['eof']+2):
  if i<=e['eof'] and i not in have and start is None:start=i
  elif (i>e['eof'] or i in have) and start is not None:miss.append([start,i-1]);start=None
 out.append({'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':miss})
(b/'native-read-receipt.json').write_text(json.dumps({'schema':'726-native-stdlib-read-receipt-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registration_sha256':hashlib.sha256(raw).hexdigest(),'entries':out},indent=2)+'\n');print('recorded native',len(out))
