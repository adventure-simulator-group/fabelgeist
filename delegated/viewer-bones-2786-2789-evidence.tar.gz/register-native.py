from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;root=Path('<LOCAL_PATH_0>');(b/'native').mkdir(exist_ok=True);rows=[]
for id,p,ranges in [('btree-map','collections/btree/map.rs',[[1705,1718],[2535,2555]]),('btree-dedup','collections/btree/dedup_sorted_iter.rs',[[1,49]]),('stable-sort','slice.rs',[[135,145],[185,200]])]:
 src=root/p;d=src.read_bytes();out='native/'+id+'.source';(b/out).write_bytes(d);rows.append({'id':id,'installed_toolchain_path':str(src),'declared_project_channel':'nightly-2026-07-13','identity_qualification':'Bytes copied from installed toolchain source path, not a crate archive checksum or proof which compiler was invoked; source text only.','archive':out,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'eof':len(d.splitlines()),'prospective_personal_read_ranges':ranges})
r={'schema':'726-native-stdlib-source-registration-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'native-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registered',len(rows),r['at_utc'])
