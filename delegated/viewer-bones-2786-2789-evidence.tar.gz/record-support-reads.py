from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent
chunks={'root-motion':[[1,25],[26,50]],'repeated-eval':[[1,39],[40,78],[79,117],[118,155]],'report-mod':[[80,105],[106,130]],'global-bones':[[1,30],[31,59]],'harness':[[1,28],[29,55],[100,120],[140,172],[173,205]],'capture-integration':[[690,727],[728,765]],'rig-assignment':[[1,25],[26,49],[80,112],[113,145],[185,215],[216,245]],'capture-calls':[[610,637],[638,665]],'rig-index':[[246,280],[281,315]],'rig-identity':[[1,28],[29,55]],'scene-loader':[[180,202],[203,225]],'scene-owner':[[145,165]],'rust-toolchain':[[1,5]]}
out={'schema':'726-bounded-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':[],'entries':[]}
for fname in ['support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json']:
 raw=(b/fname).read_bytes();reg=json.loads(raw);out['registrations'].append({'path':fname,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for e in reg['entries']:
  ch=chunks[e['id']];covers={i for a,z in ch for i in range(a,z+1)};missing=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covers and start is None:start=i
   elif (i>e['eof'] or i in covers) and start is not None:missing.append([start,i-1]);start=None
  out['entries'].append({'registration':fname,'id':e['id'],'sha256':e['sha256'],'actual_display_chunks':ch,'unread_complement':missing,'qualification':'Personally displayed current support only; no historic role credit; any test text merely read, not run.'})
(b/'support-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('recorded',len(out['entries']),'support reads')
