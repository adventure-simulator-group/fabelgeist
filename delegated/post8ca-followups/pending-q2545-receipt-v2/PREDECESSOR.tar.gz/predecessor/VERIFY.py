#!/usr/bin/env python3
"""Verify receipt bytes and optional separately supplied manifest identities."""
from pathlib import Path
import argparse,hashlib,json
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--public-manifest',type=Path);ap.add_argument('--private-manifest',type=Path);ap.add_argument('--replay-manifest',type=Path);a=ap.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q2545-peer-replay-receipt-v1' and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,r in m['files'].items():
 f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(r['bytes'],r['sha256'])
x=json.loads((p/'REPLAY.json').read_bytes());assert len(x['checks'])==3 and all(r['exit']==0 and r['stderr_bytes']==0 for r in x['checks']) and len(x['postseal_checks'])==2 and all(r['exit']==0 and r['stderr_bytes']==0 for r in x['postseal_checks']);checked=[]
for name,key in [('public_manifest','public_manifest_sha256'),('private_manifest','private_manifest_sha256'),('replay_manifest','replay_manifest_sha256')]:
 f=getattr(a,name)
 if f is not None:assert f.is_file() and h(f.read_bytes())==x[key];checked.append(name)
print(json.dumps({'receipt_members':len(m['files']),'supplied_manifest_checks':checked,'qualification':'Receipt bytes and optional manifest identities only; full evidence replay needs separately held Git objects, original queue and protected extraction; no independent custody or product execution.'}))
