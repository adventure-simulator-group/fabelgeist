# q2962: grounding admission, Lens 8

This is a bounded, independently registered behavior-preservation assessment
of historical 059 q2962, `grounding/admission.rs:1–58`. The 6533, e275 and
95e source objects are the same Git blob
`a65dc4432cb4dbea04fdd65f02e78d2d1ba81922`, SHA-256
`11bb44acefc12ab10604d09e33f8b1d26fc3958fa916255972ec6ea63e1f6d2f`.
Each full body was personally displayed separately. This per-file equality
is not whole-tree equality or proof that every caller behaves identically.
The helper was introduced at 5a581ee, where its object also matches; the
parent 58ea2ca has no `admission.rs` path. Separate registered source reads
compare selected old, introduction, 6533 and 95e producers and consumers.

## Selected before/after contracts

- **Individual versus aggregate admission.** At the pre-refactor parent,
  `enclosure/projection.rs:166–219` builds each top and base point through
  finite `Position<GateRelative>` admission and rejects head at or below base,
  then constructs the public cell fields. At 95e, the selected producer
  retains those point checks and calls `BoundarySupportCell::new`
  (`projection.rs:177–229`, `enclosure.rs:24–57`). The constructor also
  requires the six-point sum to be finite, paired X/Z, no reversed heights
  and at least one positive height (`admission.rs:25–43`). This adds an
  aggregate construction error to the selected producer, rather than proving
  that formerly supported data violated the intended contract.
- **Symbolic finite-sum boundary.** Six separately finite, paired positions
  with positive heights and X coordinates near half of `f32::MAX` can have a
  finite mathematical average yet overflow the f32 six-point sum. The old
  public cell representation could carry such positions; 95e `prism` returns
  `NonFinite` before physics. The old collider also summed points before
  passing centered vertices to its native shape constructor
  (`enclosure.rs` at 58ea:122–143). Supported producer reach, accepted
  coordinate limits, and the old native result are unproved. This is a
  different first operation from ledger 1083's finite-sum followed by
  nonfinite centered subtraction; no alias or count is decided.
- **Exact contact and winding.** Before the refactor, the selected enclosure
  and foundation colliders sent the fixed eight faces to `convex_mesh` and
  expected a shape (`enclosure.rs` at 58ea:122–143; `foundations.rs` at
  58ea:73–96). At 95e `solid_faces` returns no solid faces for exact zero
  plan area, reverses all faces for negative winding and retains positive
  winding (`admission.rs:46–58`). Callers skip contact-only cells and return
  typed errors for other native `None` results (`enclosure.rs:227–252`;
  `foundations.rs:176–203`). If all parts are contact-only, the result is
  `SupportCollision::ContactOnly` (`collider.rs:35–60`). The selected server
  boundary observer adds a static body only for `Solid`
  (`tactical-server/src/boundaries.rs:4–29`); the selected foundation
  replacement collects only a solid collider
  (`foundations/replacement.rs:87–120`). The old code's actual native
  outcome for any input, supported reach and downstream product effects are
  not established. Source comments explicitly describe zero-area contact
  cells as valid; no unrequested regression or compatibility requirement is
  inferred.

For the selected caller paths, the 6533 and 95e source bodies of enclosure,
foundation, replacement, collider owner, boundary observer, projection and
position owner match per file. The 5a commit message describes admitting
typed and immutable support contracts; this is context, not proof that every
behavioral difference was approved. Other producers, consumers, schema
entry paths, native rules and whole-application behavior remain unreviewed.

## Recovered evidence and attribution

The original q2962 records 6533, required 1–58 and no assessed ranges; 8ca
marks it unassessed. Original and reconstructed q2962 selected bytes match,
while their complete queue streams differ. The Root Lens 3 receipt records a
fresh personal 6533 display and qualified same-Lens-3 e275 reuse with no
fresh e275 range. The older Adler Lens 11 record separately describes a
fresh connected 1–58 read and zero ordered original-frontier credit for
source registry index 2708; this is not queue entry q2708. Root Lens 2's
6533 display and e275 same-Lens-2 reuse are also separate. None transfers
Lens 8 credit or establishes checkpoint 3821.

The wrapped_scope q2957 Lens 2 report independently read this body at the
three revisions and documented the separate retained-position owner
question. Its provenance and corrections remain separate. Historical q2369
records the native fixed-shape and exact contact/winding roles; 8ca ledger
1083 records the distinct conditional centering issue. These relationships
are evidence connections, not global alias decisions or closure.

## Process and open questions

A metadata selection failed on a list/dictionary shape and was corrected; a
caller locator failed parsing Git grep output and was corrected. One broad
changed-path metadata display and one prior packet filename listing were
truncated. The full changed-path metadata was retained and relevant paths
redisplayed. A Git history metadata locator and an Adler existence-only
lookup preceded their exact registrations; both were recorded, and the Git
history was re-registered and redisplayed. Four copied support-capture
predecessors had an inapplicable pinned-root assertion caught before
execution; corrected successors and identities are retained. None supplied
source credit. No registered source view was truncated.

Reachability of extreme or zero-area inputs through supported producers,
source policy for this aggregate bound, complete caller/wire changes and
native effects remain open. All examples above are symbolic source reasoning;
no product code, physics, fixture, test, build or runtime probe was run.
The complete original/reconstructed queues and original extraction remain
separately held same-machine inputs for strongest replay; their custody and
checkpoint 3821 cannot be established by a public-only packet.
