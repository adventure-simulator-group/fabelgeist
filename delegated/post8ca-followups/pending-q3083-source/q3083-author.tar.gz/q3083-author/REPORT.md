# q3083: contact-role shape in tactical receipts

Reviewer: /root/mhr_character. Lens 9 is enum and state shape under the recovered
handoff mapping. This is a source-only assessment at 95e63628f9d70b8dd6e6fede64334696c6995009;
no product or test was executed. The historical assigned file is
`crates/adventuresim-tactical-server/src/mission/receipt.rs:1–102`.
The whole-file SHA-256 at 6533, e275 and 95e is
`24e17b0e16c1731ef4fa81d7e8f2448cd42b12b6b75dbbe16bc502f0f606508d`.
This establishes the same file bytes, not equal trees or equal behavior.

The retained contact's `defender_equipment` boolean describes a two-way role.
`combat.rs:191–203` stores it with the item and owner. The bounded current
producers in `combat/consequence.rs:78–174` construct attacker-weapon and
defender-equipment contacts under different guards. `mission/receipt.rs:21–74`
maps the boolean into `TacticalEquipmentContactRole` with variants
`AttackerWeapon` and `DefenderEquipment`. The authoritative native schema
`adventuresim-stdb-module/src/tactical.rs:52–87` and generated client source
represent this as an enum with common contact payload. This is a candidate for
an explicitly owned internal role enum or appropriate reuse of the existing
role owner, with explicit protocol mapping. Whether the generated client type is
the appropriate internal owner is an architectural question; this review does
not assume it. No alternative payload or new variant is required by the
selected source. Other observed flags are local predicates, not automatically
this retained role.

The historical first-role question is separate from this shape observation.
`combat/consequence.rs:243–270` coalesces by item ID and retains the first
owner/role while accumulating capped stress. If one item contributes in both
roles, a later role is not represented by a second retained contact; this is a
conditional source implication, not proof that supported event histories can
produce it or that the role means exhaustive provenance. Native validation
`tactical.rs:1037–1130` checks party, current custody, quantity and equipment
and accepts a held weapon for either role when all other relevant guards pass.
A shield or armor is subject to the corresponding separate checks. The selected
application `tactical.rs:1185–1223` passes item ID and stress to impact, without
using role in that call. These facts do not establish a gameplay effect,
authorize a mixed-role history, or determine desired aggregation policy.
`mission/systems.rs:52–67` freezes resolution and receipt together. The
`tactical.rs:1142–1183` bounds checks also reject repeated item IDs in a receipt.

Historical q1712 has no directly attached source contexts and requires locator
resolution. Its referenced original ledger record at
`/segovb_continuation/lens12/pending_connected_contracts/822` asks about the
same first-owner/role operation and custody. The exact selected original and
reconstructed record bytes match; the complete ledgers differ. An independently
captured Segovb Lens 12 receipt recorded a fresh 6533
`combat/consequence.rs:1–308` read and the same conditional question; the
published 95e consequence assessment connects that prior receipt and lists
`REVIEW-TACTICAL-CONTACT-FIRST-ROLE-001`, ledger row 390. That assessment's
listed lenses exclude Lens 9. Row 389's contact cap and row 1099's terminal
roster question are distinct first operations. q3128 and q3127 are related
terminal records, while q3064 is a separately attributed Lens 1 review; no
alias, unique defect count or disposition follows from these relationships.

Original q3083 records 6533 required 1–102 with no assessed ranges. Root's
historical Lens 3 6533 read and e275 qualified reuse are separately captured;
neither supplies this review's Lens 9 credit. The 19 personal windows in the
receipt were registered before display. The historical pr-working snapshot's
per-file identity does not establish a clean whole tree. Checkpoint 3821 was
not recovered and is not credited. Registered test-source windows and generated
bindings were inspected as text only.

Open questions are supported mixed-role and ownership-transfer reachability,
whether the role witnesses authorization or exhaustively records provenance,
the appropriate internal owner and aggregation policy, and any downstream
consumer not included in these bounded windows. Runtime equivalence, actual
product impact and global absence of other issues remain unproved. The
reservation was announced before source display; explicit coordinator
confirmation had not arrived at that point. A failed metadata-only `python`
invocation, later retried with `python3`, and the other locator, truncation and
source-qualification details are retained in the process record.
