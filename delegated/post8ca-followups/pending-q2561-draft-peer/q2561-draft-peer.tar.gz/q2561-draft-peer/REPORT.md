# Independent review of the q2561 draft

Reviewer: /root/mhr_character. This review covers only the q2561 Lens 7
assessment and its first planning relationship in the unadopted central draft
at pinned product revision `95e63628f9d70b8dd6e6fede64334696c6995009`.
I authored the separate q3044 peer review; I do not independently assess
q3044 here. The q2561 source assessment was authored by final_guard_peer and
peer-reviewed by wrapped_scope. Their source reads remain separately credited.

The q2561 draft is supported in the selected scope, with one recommended
precision change. `book.rs:19–65` and
`item_catalog_validation.rs:1386–1445` assign the same maximum rank to each
of the same 21 skill names. `book.rs:285–313` maps those same names to `Skill`;
the mapping does not assign rank limits. The book and catalog predicates and
`schedule.rs:429–438` each enumerate the same six terrain names. Describe the
two matching rank tables and the same-name mapping explicitly rather than
saying that all three classifications agree without that distinction. This is
a wording refinement, not an identified current list mismatch.

The full book and catalog predicates differ. A directly constructed Book with a
valid medium, target `cooking`, quality one and allowlist `[""]` passes the
selected `book_shape_is_valid` predicate (`book.rs:56–65`) but fails the
catalog's empty-ID check (`item_catalog_validation.rs:1386–1402`). Public Book
fields are shown at `item_catalog_schema.rs:498–529`. An empty vector is a
different state: the selected bookstore path treats it as unrestricted
(`schedule.rs:664–692`). Neither example proves that a supported producer
admits a malformed item or that both predicates have the same required scope.
Adding the words “directly constructed” to the draft example would make that
limit easier to read; the draft already says supported mismatches and outcomes
are unproved.

`book.rs:83–145` accepts an effective target rank, direct hours and projection
callback as separate inputs. Its lower gate uses the supplied rank and its
projection gate applies the upper ceiling. A stale supplied rank can therefore
change that helper's decision if its other guards hold, but no supported stale
caller is demonstrated. The selected schedule derives the target snapshot from
its current skills immediately before applying the training branch
(`schedule.rs:477–515,518–638`); all other callers and the direct-hour field
mapping remain open. A future name-list drift can cause the selected snapshot
to return None and its candidate filter to skip that book
(`schedule.rs:501–515,699–710`); no present admitted mismatch is established.
The build script imports schema and validator modules and calls the item
compiler (`build.rs:39–50,74–80,222–262`); the selected validator chain
reaches the catalog check (`item_catalog_validation.rs:212–267,313–318,`
`537–539,1148–1153,1360–1383`). This is source evidence only; no build ran.

The proposed planning relationship is appropriate as a planning connection,
not an alias or new count. q2492 asks about the book target owner; q2573
registers the item-schema Lens 7 scope; q2681 registers the current validator
Lens 7 scope. Their 8ca wrappers remain unassessed. Ledger 451's nonfinite
written-language gate and ledger 859's reading-preview omission have different
first operations. No complete alias or reachability search follows.

The original q2561 row specifies 6533, `book.rs:1–318` with EOF 529 and no
Lens 7 assessed range. Its original and reconstructed rows match as parsed,
while full streams differ. The earlier Lens 2 receipt qualifies inherited
supplier coverage, naming the native supplier's f82 metadata; Root's selected
reinspection is separately recorded with no new coverage credit. None of that
is this reviewer's or the q2561 author's Lens 7 credit. The book file bytes at
6533 and 95e match, while the compared schema blobs differ; these per-file
facts do not establish whole-tree or runtime equality. Checkpoint 3821 remains
unrecovered.

Sixteen independently registered current source windows were personally
displayed for this review, recorded separately from the author's 17 and the
peer's 18. Display receipts are attestation, not independent telemetry. The
source files beyond those windows, all callers and policies, product outcomes,
parser/macro execution and global alias relations remain open. The original
author's failed metadata locator, later terrain-capture correction, initial
uncaptured verifier output and corrected delivery hash, as well as the earlier
peer's 6533 metadata-registration lapse, remain separately qualified in those
packets. This review's first metadata projection raised a TypeError after its
inputs were captured; a corrected projection followed. A later historical
metadata view intentionally printed only selected fields; complete captured
records remain restricted. No product, fixture, build, test or probe ran, and
no record was adopted or closed.
