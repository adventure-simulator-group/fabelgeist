# q3044: language initialization, Lens 6 type ownership

Reviewer: wrapped_scope. This is an independently performed, bounded source
assessment at commit 95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. The historical queue row is
OBLIGATION-ROOT-L3-EXT-0028-LENS-06, q3044. At checkpoint
8caeb2003d10d08320566206817aa0c694231778 (tree
246d1442c001f653da8f2ea3094620473aae1c32), its reconciliation says
unassessed. This report is later work, not an adopted queue or ledger change.

## Assessment

The reviewed language profile and language-hours representations already have
a shared owner in world-schema. The selected server stores and uses those
owners; generated client wire structs are adapters, not evidence by themselves
of competing handwritten domain owners. The focused review found no established
reason on these selected uses to move those language types. Other consumers and
admissions remain open.

A separate, conditional ownership question concerns character identity. The
selected initialization API accepts a raw u64, while selected durable name
operations use a crate-private CharacterId wrapper and the tactical ECS defines
its own CharacterId component. The inspected server-to-client-to-tactical path
carries the character row's id into that ECS component. This supports asking
whether a shared identity leaf should own the common key, with explicit native,
wire and ECS adapters for their distinct purposes. It does not establish a
runtime failure, prove every character-ID producer or lifetime equivalent, or
justify merging strategic and tactical authority. The initializer's conversion
to generic deterministic Seed is a numerical seeding boundary, not proof that
Seed owns character identity. World-schema is already a dependency of both
selected consumers; feasibility and complete contracts remain to be assessed.
This is an independently observed candidate relationship, not a claimed alias
or a new defect count.

The existing UnitBasisPoints is a possible semantic leaf for some raw profile
fields, subject to separately assessed admissions. It would not alone enforce
that the three German weights sum to 10,000 or the different 1,000 incidence
limit. Its derived serialization and native admission cannot be assumed to
honor its checked constructor; the prior q131 assessment and actual ingress
remain separate. Ledger 1095 already records the separate Lens 1 propagation
question.

## Selected source chain

* `crates/adventuresim-world-schema/src/language/initialization.rs:4-54` takes
  the profile, raw character id and NPC flag; samples weighted vernacular and
  optional Yiddish incidence, builds oral hours and starts written hours at
  default. Its `expect` requires a positive total.
* `crates/adventuresim-world-schema/src/language.rs:1-5,14-17,27-39,138-175,431-465,495-562`
  owns the shared profile and hour values, their validity predicate and selected
  geographic profile derivation. Its default profile has zero weights.
  `crates/adventuresim-world-schema/src/lib.rs:3873-3901` embeds the profile
  in settlement import. The selected importer checks validity and equality with
  inferred geography before storage in
  `crates/adventuresim-stdb-module/src/strategic/world_import.rs:110-129,625-640,690-705`.
* `crates/adventuresim-stdb-module/src/character.rs:528-556,2103-2130,2259-2263`
  uses the shared hour types, selects the settlement, initializes oral exposure,
  and preserves separately handled literacy. These source paths are not runtime
  observations and do not prove all producers use the same admission gate.
* `crates/adventuresim-stdb-client/src/settlement_language_profile_type.rs:1-18`,
  `oral_language_hours_type.rs:1-22`, and `written_language_hours_type.rs:1-21`
  identify themselves as generated client wire forms. The generated files are
  evidence only; generation was not run.
* `crates/adventuresim-world-schema/src/basis_points.rs:1-32` defines the
  checked UnitBasisPoints constructor and a transparent derived deserializer.
  `crates/adventuresim-world-schema/Cargo.toml:9-17` shows the selected shared
  crate dependencies. The selected profile's aggregate policy is independent
  of any single leaf bound.
* `crates/adventuresim-stdb-module/src/character.rs:2166-2208,2259-2260,2537-2539,2649-2656`
  inserts the selected character id, passes it to initialization, and wraps
  it for selected name-authority calls. `character/name_types.rs:55-77` and
  `character/name_identity.rs:26-35,43-55,83-107,148-162` show the durable
  wrapper and selected identity consumers.
* `crates/adventuresim-stdb-module/src/tactical.rs:270-275,328-370` constructs
  ConnectedPlayer from a character-table row and selected keyed components;
  generated `crates/adventuresim-stdb-client/src/connected_player_type.rs:1-28`
  is the client wire representation. `crates/adventuresim-tactical-server/src/player_projection.rs:729-739,1994-2014`
  wraps the row id for the selected tactical ECS and shows a reflection/dump
  use; `player_projection/spawn_admission.rs:31-48` shows one error consumer.
  `crates/adventuresim-tactical-core/src/player.rs:98-114` defines the separate
  immutable ECS CharacterId. `crates/adventuresim-tactical-core/Cargo.toml:14-20`
  and `crates/adventuresim-stdb-module/Cargo.toml` show the dependency boundary.
* `crates/fabelgeist-determinism/src/seed.rs:23-45,49-78,170-173` defines the
  generic deterministic seed and conversion from u64; its seeding role is not
  the same claim as character identity ownership.

All 38 personal source displays and their exact line windows, registrations,
source bytes and receipts are retained in the restricted packet. Display is the
reviewer's attestation, not independent display telemetry. Capturing a full
source object does not confer read credit outside registered displayed windows.

## Historical and ledger relationships

The original q3044 row names 6533e444fa37552927070cc8d8190907fd3b413e,
required lines 1-54 and EOF 54, with no assessed range or named Lens 6 reader.
Its reconstructed selected row has identical bytes to the recovered original
selected row. The recovered original registration and 6533 receipt attribute a
separate, complete 1-54 personal Lens 3 read to Root. The e275
(e2755a732c84e67296b5e3441a4259a84f461b2f) receipt qualifies 1-54 as reuse,
not a fresh e275 read: its general basis preserves mixed fresh/inherited
attribution, while this selected prior row specifies fresh 1-54 and no inherited
range. Neither grants Lens 6 credit. The reviewed file is the same individual
Git blob at 6533, e275 and 95e; this is not whole-tree equivalence. The
historical records are not checkpoint 3821, which remains unrecovered.

* q3040 and ledger 1095 concern Lens 1 profile-leaf propagation; their reads
  and reviewer attribution remain separate from this Lens 6 assessment.
* q3132 and ledger 450 concern the zero/default weighted-profile admission
  question. The original q3132 record lacks a status key, while the 8ca
  reconciliation's historical_status is explicitly null. The selected
  importer has a validity gate, but all admission paths, native sampler behavior
  and a reachable invalid-profile outcome are not independently established
  here. Do not infer an alias to the identity question.
* q131 is Adler's separate basis-point wire-admission question. Its original
  revision and attribution fields are null; the separately recovered named
  Adler receipt is evidence of that receipt, not a new historical revision or
  checkpoint 3821 credit. Native macro expansion and supported ingress remain
  open. q2374 is Root's earlier Lens 2 language-owner complement, with its
  recorded inherited native attestation and fresh complement, not a complete
  Root-personal read.
* q649 and q656/q663/q667 concern tactical identity in sound-related scopes;
  ledger 856 concerns full-width identity at a browser Number boundary.
  q246/ledger 18 concern elapsed ambient-language time. Ledger 451 concerns a
  written-language nonfinite gate and ledger 452 duplicate speaker identity.
  Their first operations and attributions remain distinct; bounded lexical
  searches do not establish a global alias inventory.

Open questions include all identity producers and lifetimes, legitimate
strategic and tactical wrapper distinctions, wire/serde/SATS/reflection
contracts, generated adapters, profile admissions and whether any supported
user-visible issue exists. No repair, product execution, build, test, fixture,
macro, shader or runtime probe was performed; no lens or queue closure is claimed.

## Evidence and recovery qualifications

The exact protected historical extraction was read without mutation. The
original and reconstructed selected historical records and the historical
registrations/receipts are retained separately from the new source assessment.
The complete original 059 stream and relevant Git objects are independently
held same-machine dependencies for full anchored replay; a selected-record packet
alone does not reconstruct a missing full stream or missing checkpoint 3821.

The first abbreviated 8ca Git lookup failed (tool-visible traceback only) and
was corrected to the full commit. A historical registration locator returned
seven copies; a uniqueness assertion stopped before opening one. A subsequent
registered comparison verified their matching hashes and selected the protected
original copy. A metadata navigation script retained three pre-registered blob
captures but then failed on an explanatory suffix in a filename; its traceback
was tool-visible only and a corrected navigation result is retained. A question
was clipped to 260 characters in one metadata display, then fully displayed and
retained. An additional broad evidence-root `git ls-tree --name-only` display
was truncated; it showed evidence filenames only, did not display product
source and grants no source credit. The full selected records and correctly
bounded source displays remain retained. No independently captured transcript
exists for those tool-only failures; they are qualified rather than recreated.
