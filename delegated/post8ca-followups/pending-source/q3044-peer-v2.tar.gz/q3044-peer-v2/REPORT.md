# Independent q3044 Lens 6 review

Reviewer: /root/mhr_character. I independently reviewed the source-level
ownership claims of the q3044 assessment by /root/wrapped_scope. Its public
manifest SHA-256 is a23d0bfd1cc8921a30bf1921647fba73db3fa0eaa903e44eee2fb29f3b4aaf42;
the separately verified restricted manifest is
c42b2352e295ffd543c55959a0e0f5b3f92cda71cb646b4cc1098f61501a6d47.
This review supports the author's qualified source conclusions. It does not
establish a defect, select an owner, count an alias, close a queue or lens, or
transfer another reader's credit.

The reviewed product revision is 95e63628f9d70b8dd6e6fede64334696c6995009,
tree 1eec97de340d9b7debbb30ca0c0fb2240a73b93f. Checkpoint 8caeb2003d10d08320566206817aa0c694231778
is the evidence metadata checkpoint, not the product revision. Its q3044
wrapper says unassessed; this later peer review makes no central ledger change.

## Source-level assessment

* `crates/adventuresim-world-schema/src/language/initialization.rs:6-54`
  accepts a settlement profile, raw character ID and NPC flag; it uses two
  deterministic streams, assigns oral hours and starts written hours at
  default. Its positive-weight expectation is a separate admission condition.
* `crates/adventuresim-world-schema/src/language.rs:138-175,431-465,495-562`
  defines the shared oral/written hour records and profile. The selected native
  table and initialization callers use those shared types
  (`crates/adventuresim-stdb-module/src/character.rs:528-556,2103-2130,2259-2263`).
  The generated client forms in
  `crates/adventuresim-stdb-client/src/{settlement_language_profile_type,oral_language_hours_type,written_language_hours_type}.rs`
  identify themselves as generated wire forms. These selected uses give no
  established reason to move the shared language types; they do not survey all
  admissions or consumers.
* The name wrapper `character/name_types.rs:55-77` is crate-private and is
  used in selected name-authority calls at `character/name_identity.rs:26-55,
  83-107,148-162`. The selected character insertion passes its raw ID into
  language initialization and separately wraps the row ID for naming
  (`character.rs:2166-2208,2259-2260,2537-2539`). The native
  `tactical.rs:328-370` view selects character rows and creates ConnectedPlayer;
  its generated client form carries the character, and
  `tactical-server/src/player_projection.rs:729-739` wraps that row ID in the
  tactical ECS component defined by `tactical-core/src/player.rs:98-114`.
  This supports an open shared-key ownership question. Different scope,
  persistence, schema/replication and ECS lifecycle contracts may justify
  distinct wrappers; the selected chain does not prove equivalent lifetimes,
  all producers, an ownership merger, or a runtime failure. It does not move
  strategic or tactical authority. The generic deterministic Seed conversion
  in `fabelgeist-determinism/src/seed.rs:23-45,49-78,170-173` is a sampling
  boundary, not itself an owner of character identity.
* `language.rs:495-512` has public raw weights and a validity predicate: the
  three German weights total 10,000 and Yiddish incidence is at most 1,000.
  The selected importer checks that predicate and equality with geographic
  inference before storing the profile
  (`strategic/world_import.rs:625-640,690-705`); this does not cover every
  constructor, deserializer, stored state or caller. `basis_points.rs:7-32`
  supplies a checked UnitBasisPoints constructor and a transparent derived
  Deserialize declaration. An individual bounded leaf would not itself
  enforce the sum or the smaller incidence cap; neither derive expansion nor
  supported bad-value ingress was run or established.
* The inspected manifests declare world-schema dependencies in the selected
  native and tactical crates; that is dependency-direction evidence, not Cargo
  feature resolution or proof of a feasible migration.

## Original and related evidence

The original 059 q3044 row names 6533e444fa37552927070cc8d8190907fd3b413e,
source lines 1-54, EOF 54, with an empty assessed range and no named Lens 6
reader. Its selected reconstructed row is byte-identical, while this does not
claim full-stream equivalence. The independently verified source file has
SHA-256 87ffb9656350a955c7a86f75ec43181d59b5a891053f3938da81e8eb5f82d593
at 6533, e2755a732c84e67296b5e3441a4259a84f461b2f and 95e. This is a single
file identity, not a clean or identical historical working tree.

The recovered Root Lens 3 receipt records a fresh personal 6533 read of 1-54;
the e275 receipt qualifies reuse of precisely that row and records no fresh
e275 read. Its general basis preserves mixed attribution, whereas this selected
prior row is explicitly fresh 1-54 with no inherited range. These historical
reads and the author's 95e Lens 6 read are separate from this independent
review. Checkpoint 3821 is unrecovered; no evidence is promoted into it.

q3040 and ledger 1095 concern Lens 1 profile-leaf propagation. q3132 and ledger
450 concern the zero/default weighted-profile admission question; the original
q3132 has no `status` key while its 8ca wrapper's historical status is null.
q131 is Adler's distinct basis-point wire-admission record; its selected
historical revision and attribution fields are null, and the named receipt is
not a license to invent either. q2374 is the earlier Lens 2 owner complement
with its recorded mixed fresh and inherited scope. q649, q656, q663 and q667
concern tactical sound identity; ledger 856 concerns browser number precision.
q246/ledger 18, ledger 451 and ledger 452 concern distinct ambient-time,
written-language, and duplicate-speaker questions. First operations and
attributions remain distinct; no exhaustive alias inventory is asserted.

## Scope and recovery

I personally displayed the assigned 1-54 at each of 6533, e275 and 95e and 34
registered 95e support windows, 37 windows in all. The source objects and Git
commit/tree/blob proofs are retained in the restricted packet. Personal display
is reviewer-attested; bytes preserved outside those windows are identity
proof, not extra read credit. The original and reconstructed 059 full streams,
protected extracted evidence, author private packet and Git object store are
separately held same-machine dependencies for the strongest provenance replay;
the restricted selected-record packet alone does not recreate missing full
streams or 3821.

The initial request for a new Lens 3 review was corrected to this peer review
before any queue row or product-source display under that request. After the
author report, I displayed two author historical-locator metadata projections
before my historical registration; they listed locations/hashes only and
receive no source or historical-row read credit. All credited history and
source views were registered before display. The author's own recorded failed
lookup, duplicated locators, navigation error, clipped question and truncated
evidence-filename listing remain attributed and qualified in their unchanged
report; no transcript is invented for tool-visible-only failures.

Remaining questions include supported creation, wire and native admissions,
character-ID producers and lifetimes, the appropriate owner and adapter
boundaries, feature and serialization contracts, and user-visible reach. No
product code, examples, fixtures, macros, builds, tests or runtime probes ran.
