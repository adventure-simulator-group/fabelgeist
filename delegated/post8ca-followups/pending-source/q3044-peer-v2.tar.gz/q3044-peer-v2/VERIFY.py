#!/usr/bin/env python3
"""Read-only complete public and optional private evidence replay."""
from pathlib import Path
import argparse,hashlib,json,stat,subprocess,sys
if sys.flags.optimize:raise RuntimeError('unoptimized interpreter required')
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--queue-private',type=Path);ap.add_argument('--extraction',type=Path);a=ap.parse_args();H=lambda b:hashlib.sha256(b).hexdigest()
def check(root,manifest,expected=None):
 mb=(root/manifest).read_bytes();assert expected is None or H(mb)==expected;m=json.loads(mb);assert oct(stat.S_IMODE(root.stat().st_mode))==m['root_mode'];seen_files=set();seen_dirs=set()
 for x in root.rglob('*'):
  assert not x.is_symlink();rel=x.relative_to(root).as_posix()
  if x.is_dir():seen_dirs.add(rel)
  elif x.is_file():
   if rel!=manifest:seen_files.add(rel)
  else:raise RuntimeError('unsupported file kind')
 assert seen_files=={x['path'] for x in m['files']} and seen_dirs=={x['path'] for x in m['directories']}
 for d in m['directories']:assert oct(stat.S_IMODE((root/d['path']).stat().st_mode))==d['mode']
 for row in m['files']:
  x=root/row['path'];b=x.read_bytes();assert len(b)==row['bytes'] and H(b)==row['sha256'] and oct(stat.S_IMODE(x.stat().st_mode))==row['mode']
 return m
m=check(p,'MANIFEST.json');assert H((p/'author-public/MANIFEST.json').read_bytes())=='a23d0bfd1cc8921a30bf1921647fba73db3fa0eaa903e44eee2fb29f3b4aaf42';assert H((p/'REPORT.md').read_bytes())==json.loads((p/'ASSESSMENT.json').read_bytes())['report_sha256'];results={'public':'pass','nested_manifests':sum(x['path'].endswith('/MANIFEST.json') for x in m['files']),'private':'not_supplied','external_dependencies':'not_supplied','no_product_execution':True}
if a.private:
 expect=json.loads((p/'PRIVATE-BINDING.json').read_bytes())['private_manifest_sha256'];check(a.private,'PRIVATE-MANIFEST.json',expect);x=subprocess.run([sys.executable,'-B',str(a.private/'VERIFY-PRIVATE.py')],capture_output=True,text=True);assert x.returncode==0;results['private']='pass'
if a.queue_private or a.extraction:
 assert a.private and a.queue_private and a.extraction;x=subprocess.run([sys.executable,'-B',str(a.private/'VERIFY-DEPENDENCIES.py'),'--queue-private',str(a.queue_private),'--extraction',str(a.extraction)],capture_output=True,text=True);assert x.returncode==0;results['external_dependencies']='pass'
print(json.dumps(results))
