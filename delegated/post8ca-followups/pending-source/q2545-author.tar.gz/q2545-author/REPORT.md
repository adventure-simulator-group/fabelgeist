# q2545: saved schedule admission and preview adapter

Reviewer: wrapped_scope. This is a bounded, independently registered Lens 3
assessment at product commit 95e63628f9d70b8dd6e6fede64334696c6995009,
tree 1eec97de340d9b7debbb30ca0c0fb2240a73b93f. Published checkpoint
8caeb2003d10d08320566206817aa0c694231778 supplies queue and ledger metadata.
The original q2545 row is pending its independent lens qualification; its 8ca
reconciliation remains unassessed. This later report changes neither record.

## Admission contracts and selected paths

The web `schedule::validate` passes the ten minute fields and both organization
pairs to `validate_daily_allocation`. The core validates 15-minute increments
and the 1,440-minute day budget, then parses the organization pairs. Its
`OrganizationAllocation::parse` rejects zero minutes with an organization,
positive minutes with no organization, and a blank positive organization ID;
it trims an accepted ID. The web adapter first maps a blank optional ID to
None and copies the parsed IDs back. The selected native update reducer calls
the same core validator, rebuilds a canonical schedule, checks organization
membership and practice permission, and then updates the saved row
(`schedule.rs:11-39`, `strategic_schedule/allocation.rs:19-59,104-131`,
`time/stationary.rs:195-262`, `time/schedule.rs:128-152`). Authorization,
membership and transaction outcomes are source conditions, not observed runs.

The public `OrganizationAllocation::Scheduled` variant permits a separately
representable combination that its parser excludes: `ActivityMinutes::try_from(0)`
passes the generic quarter-hour check, and the public variant can pair that
value with an empty String. Its getters return zero and Some(empty). This
corroborates the descriptive admission question in historical q628; that row
has no linked source receipt and its original locator remains unresolved.
No actual direct constructor, supported consumer, persistence outcome or
unique new issue is established. Valid zero time with no organization remains
a legitimate `None` mode.

The public `validate_daily_allocation` API also takes the activity array and
organization-minute tuples independently, without comparing their corresponding
values. The selected web and native writers pass matching fields. This
aggregate question is already tracked separately in 8ca ledger 89 and planning
relationship 1120; no alternative supported caller or new count is inferred.

`ValidatedSchedule` explicitly validates numeric daily allocation independently
of persistence and organization access. The web `effective` and preview
calculator use that numeric contract, not the full organization-pair parser.
For example, a zero-minute allocation retaining Some(nonblank ID) is rejected
by the full parser but is numerically acceptable to `effective`, which retains
the ID in its returned clone. This separation is not by itself a defect: the
native stationary path deliberately filters current organization eligibility
on a temporary clone, can zero an activity while retaining its ID, and then
uses the numeric effective-schedule boundary. The `None` preview-location mode
also intentionally returns the saved clone without calling numeric validation.
Whether every supported retained plan is admitted correctly remains open.

Web normalization and direct native parsing also have a bounded policy
difference: for zero minutes and Some(blank ID), the web adapter drops the
blank value before parsing, while the core parser presented with that raw pair
returns `OrganizationWithoutMinutes`. No supported discrepancy, error-policy
requirement or product outcome is established by source inspection alone.

## Historical simulation-writer question, rechecked at 95e

The recovered q3301 Lens 3 proposal previously identified a selected simulation
writer that checks the daily total before retaining a raw schedule, rather than
calling the full schedule validator. Current `configure_simulation_character`
still requires an owned run, a fresh ordinary solo character, matching IDs,
valid attributes and skills, an existing settlement and a suitable solo party;
it checks only `downtime.allocated_minutes() > MINUTES_PER_DAY` before assigning
the raw value to the schedule row. Additional helper calls follow the update
(`simulation.rs:253-263,349-493`).

A source-representable example is one reading minute with all other values zero
and no organization IDs: its total is below a day, but it fails
`ActivityMinutes::try_from` because it is not a multiple of 15. If all other
configuration and later transaction conditions succeed, such a schedule is
committed, and a selected non-camp stationary path or a Some(location) web
preview later reaches the numeric validator, its `expect` would encounter that
error (`time/schedule.rs:71-89`, `time/stationary.rs:68-85`,
`character_skills.rs:2103-2112`). This is a conditional source chain. An
actually admitted or committed input, transaction rollback semantics, selected
location, ordinary-player reach and runtime outcome have not been observed.
It is the same first-operation family as historical q3301, not a new unique
count or an accepted incident.

The default saved allocation is all zero with no organization IDs. The
selected NPC initializer runs only for an adult, not-yet-initialized, unallocated
schedule and writes the core initial plan with no organization IDs. Its producer
uses labor 360 plus `60 + 15 * index(5)` socializing minutes. Under the source's
declared half-open index contract, that is 420-480 total in 15-minute steps;
the underlying random-library behavior and an actual NPC run were not tested.
These valid zero/default and NPC modes remain distinct from the malformed
simulation example.

## Sources personally displayed at 95e

* `crates/strategic-web/src/schedule.rs:1-99`: the complete assigned adapter,
  including validation, numeric effective projection, transport mapping and
  preview calculation.
* `crates/adventuresim-core/src/strategic_schedule/allocation.rs:1-283` and
  `crates/adventuresim-core/src/activity.rs:1-62`: organization allocation,
  checked minutes, day and pair validation, numeric schedule admission and
  selected redistribution; the activity segment is 15 minutes.
* `crates/adventuresim-world-schema/src/calendar.rs:1-28` and
  `crates/fabelgeist-determinism/src/stream.rs:35-75`: day budget and declared
  bounded-index contract. The external sampler implementation was not run or
  independently validated.
* `crates/adventuresim-stdb-client/src/schedule_allocation_type.rs:1-26` and
  `crates/adventuresim-stdb-module/src/time/model.rs:1-98`: generated client
  wire form and native saved schedule fields. A generated/derived type alone
  does not establish every decoding or write invariant.
* `crates/strategic-web/src/routes/settlements/party/training_activity.rs:1-117`:
  form projection, adapter validation and selected reducer call.
* `crates/adventuresim-stdb-module/src/time/stationary.rs:1-263` and
  `time/schedule.rs:60-100,115-165,155-195,720-741`: selected stationary
  consumer, checked native update, default, current-organization filter and
  numeric effective projection. The listed windows overlap intentionally.
* `crates/adventuresim-stdb-module/src/simulation.rs:240-275,340-495`,
  `npc_causal.rs:195-265`, `crates/adventuresim-core/src/npc_policy.rs:110-185`,
  and `crates/strategic-web/src/templates/settlement/character_skills.rs:2073-2115`:
  selected simulation, NPC and preview boundaries.

Twenty-four separately registered current source windows over 14 files were
personally displayed. The source windows include test-annotated text in the
web route and NPC policy; that text was inspected as source and no tests were
run. Exact bytes and registrations are retained. Display is reviewer-attested,
not independently telemetered; full blob capture gives no extra read credit.

## Historical provenance and relationships

Original and reconstructed q2545 selected bytes match (SHA-256
`c200ca630a99fb2a0be6dd70b102b54c3ce812083aac400d460850c86497ea70`);
the complete 059 queue streams differ. The row names 6533 revision
`6533e444fa37552927070cc8d8190907fd3b413e`, required 1-99, EOF 99 and zero
own-Lens assessed ranges. The recorded Root Lens 2 personal 6533 read is a
separate earlier lens. A recovered q3301 proposal and its named registration
and receipt also attribute a fresh untruncated 6533 Lens 3 read of the same
1-99 source to Root. The e275 receipt records qualified reuse, no personal
e275 reread, and `frozen_source_adoption_pending: true`: frozen same-lens
adoption must precede accepting that reuse. Satisfaction of that condition is
not established here. This reviewer's fresh 95e display does not transfer or
alter either prior reader's credit.

The extracted 6533 source object and 6533, e275 and 95e Git files are the
same individual blob, SHA-256
`87bb6b40cc4c57605e3b8c0601b6db29818a0a548aa8d3d4c3b136f55411f001`.
Twelve selected q3301 historical 6533 source objects also match their captured
95e counterparts byte-for-byte. These are per-file identities, not tree
identity, native coverage, automatic current adoption or checkpoint 3821.

Historical q628 is the separate Lens 11 zero/blank public-variant question;
its source locator and producer remain open. Its 059 reconstructed-ledger
journal text matches the original queue's description, but no linked personal
source read is inferred. Historical q3444 is a distinct Lens 12 organization
identity/string question. Its named physical-p16 registration and receipt
credit subagent lens12_frontier; the retained f82 audit-object bytes match the
95e core allocation file, a per-file comparison only. Its pending identity and
public-construction questions remain distinct. Neither historical record is
promoted to checkpoint 3821, whose queue and ledger remain unrecovered.

q2494 is the older Lens 2 saved-schedule question. q3301 remains unassessed at
8ca despite its recovered historical proposal. This reviewer's earlier role
0058 work used other lenses; q3462 is a separately adopted partial aggregate
assessment, and ledger 89/1120 preserve that planning relationship. No prior
reader, historical or reconstructed record, or different first operation is
collapsed into another. Bounded lexical searches did not establish a global
alias inventory.

## Recovery and remaining work

The protected historical extraction was read without mutation. Exact named
registrations, receipts, proposals, selected queue records, a physical source
object and current source captures are retained in the restricted packet.
The original full 059 queue, protected extraction and Git objects remain
separately held same-machine anchors for full replay; public hashes alone do
not recreate them or independent custody. A q3301 metadata display was
intentionally clipped to 11,000 characters and followed by a targeted facet
inspection; the complete selected record is retained. Bounded candidate and
ledger searches are not exhaustive alias searches.

Open work includes other schedule producers and decoders, the direct public
variant's supported users, the frozen e275 adoption condition, native
transaction outcomes, actual preview locations, membership policy, external
sampler behavior, independent custody and cross-lens reconciliation. After
authorization, any repair decision would need to preserve valid empty/default
and NPC modes and the intended distinction between persisted and temporary
numeric schedules. No implementation, product build, test, fixture, parser,
shader, runtime probe or product validation was performed; no queue/lens
closure or new unique-defect count is claimed.
