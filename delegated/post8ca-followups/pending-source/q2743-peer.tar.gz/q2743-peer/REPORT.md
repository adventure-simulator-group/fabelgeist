# Independent peer review: q2743 tactical material owners

Reviewer: wrapped_scope. This is an independent, bounded Lens 2 peer review
of mhr_character's q2743 assessment at product commit
95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. Checkpoint
8caeb2003d10d08320566206817aa0c694231778 supplies historical queue and ledger
metadata only. The author and peer are different readers; this reviewer also
authored the separate q2747 Lens 7 assessment of the same file. Neither that
work nor the author's source reads transfer personal or lens credit here.

## Verdict

The selected current file supports the author's narrow nonfinding. Its full
40-line body groups concrete, typed material and presentation plugins through
`Plugin::build` and `&mut App`; it does not itself declare a domain-valued
primitive field, parameter, return or retained value to replace with an existing
bespoke owner. The 15-element tuple statement and the spelled-out comparison
of two or three objects per square metre are comments. This review did not
independently establish the framework's tuple limit or a rendered density.
The conclusion does not clear individual material definitions, the renderer,
other producers or the entire lens.

Selected adjacent types support the author's distinctions. `ChunkSize(f32)`
is already an owner for a square ground-cell edge in metres; `InstanceReach`
contains horizontal, above and below geometry extents. Their common numerical
representation does not establish interchangeable roles or a finite/positive
contract: the field is exposed and the selected source divides positions by
its value. The vista path uses `ChunkSize(256.0)`. All callers, policy and
supported invalid inputs remain open.

The selected pebble uniform packs linear RGB and a separate ambient scale in
one `Vec4`; the fourth component is not established as alpha. A vista uniform
has different mixed-purpose parameters including height, seed and wind.
Neither source demonstrates an exact substitute among existing colour or
length owners, and similar vector shape is not sufficient. Layout, actual
shader consumption, all producers and device behavior were not assessed.

## Independently displayed source

* `crates/adventuresim-tactical-client/src/presentation/materials.rs:1-40`:
  complete current primary file, including the material tuple and three
  typed chunk-material plugin registrations.
* `crates/adventuresim-tactical-client/src/presentation/chunk_instancing.rs:34-44,63-77`
  and `chunk_instancing/material.rs:23-38`: generic plugin and existing
  material trait boundary, including native asset and binding requirements.
* `crates/adventuresim-tactical-client/src/presentation/chunk_instancing/spawn.rs:16-38,61-65`:
  batch, reach, cell-edge owner and selected division operation.
* `crates/adventuresim-tactical-client/src/presentation/ground_scatter/loose_stone.rs:59-108`
  and `presentation/vista/tree_cards.rs:32-70`: concrete material
  implementations, selected packed uniforms and vista cell size.
* `crates/adventuresim-tactical-client/src/presentation/mod.rs:227-234`:
  source-level registration of the material group after scatter plugins. That
  sequence alone does not prove runtime scheduling or rendering output.

Nine 95e windows were personally displayed after registration; exact bytes,
registrations, captures and receipts are retained. The display event is the
reviewer's attestation, not independent telemetry. Full blob capture confers
no reading credit outside these windows. Shader and macro text is source
context only; no generator, shader, test or product code was executed.

## Recovered and related history

Original q2743 `OBLIGATION-ROOT-L3-EXT-0004-LENS-02` names revision
6533e444fa37552927070cc8d8190907fd3b413e, required 1-35 and EOF 35;
its own Lens 2 assessed range is empty. It remains unassessed in the 8ca
reconciliation. The author-retained selected original and reconstructed row
bytes match, and each was separately matched to the respective full stream.
This does not establish whole-stream equality or recovery of checkpoint 3821.

The recovered original 6533 source object and the 6533 and e275 Git file
objects match at EOF 35 and SHA-256
`ccff04d8f8288d9f670097d34527841e9a8f2f91472692b25e5dd53b85c5aba8`.
The 95e file has EOF 40 and SHA-256
`e12ef47cca13c862efbcd2db69dbde2408609cdf34a3afd48842d377fc3aa6a0`.
Those are per-file comparisons, not tree equivalence. The author registered
and attested a separate personal Lens 2 read of 1-35 at each historical
revision and 1-40 at 95e. This peer captured the historical objects for
identity only and did not personally display their historical bodies.

Root's recovered Lens 3 receipt attributes a fresh, untruncated 6533 read of
1-35 to Root. Its e275 receipt records reuse of 1-35 without fresh e275 personal
reading; the row's `source_adoption_pending_for_frozen18_19` is false while the
reuse basis refers to a transaction condition for other sources 18 and 19.
Their adoption is not inferred. Adler's separate Lens 11 receipt records a
connected fresh 1-35 read with zero additional ordered-frontier credit. None
of these historical reads supplies Lens 2 credit for another reviewer.

q2747 and ledger 251 concern a separate conditional cached celestial-material
lifecycle question; this peer authored the earlier Lens 7 assessment. The
8ca ledger 1088 relates the author's q2748/q2750 RenderApp startup question,
with no-render reach and outcome open. q2748 remains unassessed and q2750
partial in 8ca, independently of their source packets. q49/ledger 201 concern
texture residency failure state; q2701 concerns recipe/channel admission.
The q2701 original record has no status key; absence is not a recorded null.
The relationships are contextual, not automatic aliases or new issue counts.

## Process and recovery limits

The original author packet, receipt and process manifests are separately
bound. The author retained an earlier failed metadata locator, two clipped
directory metadata outputs and an unregistered support-registration
projection; those do not supply source credit. The author's personal display
receipt is a reviewer attestation, not independent telemetry. This peer's
first report-capture attempt verified the public manifest, then mistakenly
indexed its files list as a mapping and failed before source display; the
traceback was tool-visible only, not separately captured. A corrected lookup
and this qualification are retained. The coordinator initially assigned this
peer the peer's own q3044 packet; no q3044 peer review was performed and the
assignment was corrected to q2743.

The complete original 059 stream, Git object store, protected historical
extraction and author packets are separately held same-machine dependencies
for full provenance replay. Selected historical rows, exact named historical
receipts and the reviewed source objects are retained in this restricted
packet; public hashes alone do not recreate those external inputs or provide
independent custody. Other type owners, source producers, admission contracts,
framework operation, shader layout, supported reachability and a global alias
inventory remain open. No repair, product build, test, fixture, shader, macro,
runtime probe or product validation was performed. No queue/lens closure or
new unique-defect count is claimed.
