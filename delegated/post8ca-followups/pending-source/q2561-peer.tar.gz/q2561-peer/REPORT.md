# Independent peer review: q2561 book target authorities

Reviewer: wrapped_scope. This is an independent, bounded Lens 7 peer review
of final_guard_peer's q2561 source assessment. The checked product source is
commit 95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. Checkpoint
8caeb2003d10d08320566206817aa0c694231778 provides queue and ledger metadata,
not a product worktree. No queue or ledger change is proposed here.

## Verdict

The selected source supports the author's principal qualifications. The
book module and catalog validator currently agree on the 21 named ordinary
skills and their maximum book ranks: two names at rank 4, six at rank 2, and
13 at rank 1. The separately written ordinary-skill mapping contains those
same names. The selected book validator, catalog validator and schedule mapping
also contain the same six terrain names. This is present source equality, not
proof of a single authority, authored-content coverage or future equality.

The whole predicates differ. The catalog predicate separately checks allowlist
length, spelling and duplicates; the book predicate checks target and quality.
A public Book with a cooking target, quality 1 and an allowlist containing one
empty string (`[""]`) satisfies the selected book predicate but fails the
catalog's explicit empty-ID check. An empty allowlist vector is different: it
passes this particular empty-ID check and the selected bookstore path treats
it as unrestricted. This is a source-representable difference, not proof of a
supported invalid book, a product fault, or a policy requirement that the
whole predicates agree.

The bounded-training helper independently accepts a supplied effective rank,
direct-hours reference and projection callback. Its lower-band check consults
the supplied rank; its projection check enforces the upper hours ceiling. For
example, at the API level, a supplied rank of 1 for a 1-to-2 book can pass the
lower gate while a projection represents zero target hours, provided the
other finite/rate/aptitude and upper-ceiling conditions also hold. This is a
conditional stale-input state, not proof a supported caller supplies it. The
selected schedule computes the target snapshot from skills immediately before
passing its rank to the helper for ordinary skill, terrain, religion and
bestiary branches. The direct-hours field mapping, all other callers and the
written-target wrapper remain outside this peer's trace. No supported stale
rank or gameplay outcome is established.

For ordinary skills, the inspected schedule projection mirrors the shown
one-pass effective-hours formula when direct-hour inputs and the correlation
snapshot match. Terrain variants carry authored intuitive attributes and the
shown terrain correlations have no self entry. Macro expansion was not run;
those attributes alone do not independently establish generated behavior.

## Independently displayed source

* `crates/adventuresim-core/src/book.rs:19-65,83-145,265-313`: rank policy,
  book predicate, independently supplied training inputs, selection filter and
  ordinary-skill mapping.
* `crates/adventuresim-core/src/item_catalog_validation.rs:1360-1445`:
  selected catalog book validation, separate allowlist rules and rank groups.
  `item_catalog_schema.rs:498-529` exposes the Book and target fields.
* `crates/adventuresim-stdb-module/src/time/schedule.rs:429-438,477-515,518-638,641-714`:
  terrain mapping, skill snapshot, bounded-helper branches and selected
  candidate/bookstore path. A drifted newly admitted skill name would make
  this selected `target_snapshot` return None and the filter skip that
  candidate, conditional on such a catalog item and path being reached.
* `crates/adventuresim-core/src/skill.rs:90-107,831-889,1098-1125`:
  authored terrain attributes, correlation table and one-pass trait formula.
* `crates/adventuresim-core/build.rs:39-50,74-80,222-262` and
  `item_catalog_validation.rs:212-267,313-318,537-539,1148-1153,1360-1383`:
  the selected static build-to-document-to-book validator chain. No build ran.

Eighteen independently registered and personally displayed windows cover the
listed source and narrowly adjacent context. The exact windows and a static
literal census are retained in the restricted packet. Display is this reviewer's
attestation, not independent telemetry. The review did not personally read the
entire q2561 source range: the original reviewer separately reported 1-318.
Neither full source capture nor a foreign reader's work supplies this reviewer's
additional line or lens credit. No product tests or test bodies were run.

## Historical and current records

Original q2561, `EXTENSION-L7-ROOT-L2-EXT-0060`, records 6533 revision
`6533e444fa37552927070cc8d8190907fd3b413e`, book source 1-318 and EOF 529;
its Lens 7 assessed range is empty. At 8ca its reconciliation is unassessed.
The exact selected original and reconstructed records match as parsed; this
is not whole-stream equality. The 6533 and 95e book file objects are identical,
while the selected item-schema objects differ. Per-file identity does not
establish equivalent trees.

The recovered Lens 2 receipt qualifies 1-318 as inherited same-lens supplier
coverage; the named inherited record identifies the native supplier and records
its metadata revision f82adcabd9d89c4fa2dd7f99253a45297a0681ee. Root's
reinspection is recorded separately and is not new fresh supplier coverage.
This history grants neither the original Lens 7 reviewer nor this peer a
fresh historical personal read. The author personally registered and reported
separate 95e Lens 7 reads; this peer has independently registered its smaller
windows. The 3821 checkpoint ledger and queue remain unrecovered.

q2492 is the prior book target owner question; q2573 and q2681 are other Lens 7
obligations. All three are unassessed in the 8ca metadata. Ledger 451 concerns
written-language nonfinite admission, and 859 concerns reading preview
omission. They provide related context with distinct first operations; no alias,
new defect count, repaired status or global/lens closure is inferred.

## Process and recovery limits

The original reviewer's public report and manifests are bound by exact hashes;
their restricted source packet, replay and receipt remain separately held. The
original complete 059 stream and Git objects are external same-machine anchors
for full replay. Public identities do not recreate restricted originals or
independently preserve those anchors. Historical source and checkpoint
qualifications remain attached to their original revisions and readers.

During 95e source capture, this peer compared 6533 book and schema objects in
memory without explicitly listing that historical identity comparison in the
prior registration. Only blob/hash metadata was displayed. It grants no personal
historical source-read credit; historical schema bytes were not separately
retained, so Git is needed to repeat that comparison. The 95e source windows
were prospectively registered before display. The author's earlier metadata
locator failure and corrected terrain-capture overclaim remain in the original
packet. An incorrect hash in the author's initial delivery was corrected in a
separate retained receipt; its sealed manifest did not change. The author also
briefly conflated q2561 with another scope in a collaboration message and
corrected that message. The peer's record of that exchange is reconstructed,
not an independently captured transcript.

All-caller inventories, direct-hours mappings, actual supported reachability,
policy intent, parser/macro behavior, related-alias searches and independent
custody remain open. No product code, build, test, fixture, macro or runtime
probe was executed, and no repair or product validation was performed.
