#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;a=argparse.ArgumentParser()
for n in ['private-manifest','replay-manifest','original-stream-manifest','author-public-manifest','author-private-manifest','author-replay-manifest','author-receipt-manifest']:a.add_argument('--'+n,type=Path)
args=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());expected={'REPORT.md','RECORDED-REPLAY.json','BINDING.json','VERIFY.py','PUBLIC-SCAN.json'}
assert m['schema']=='726-q2561-peer-public-v1' and set(m['files'])==expected and {x.name for x in p.iterdir()}==expected|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
x=json.loads((p/'BINDING.json').read_bytes());assert x['schema']=='726-q2561-peer-public-binding-v1' and x['queue_index']==2561 and x['historical_lens']==7
rr=json.loads((p/'RECORDED-REPLAY.json').read_bytes());assert rr['exit']==0 and rr['stderr_bytes']==0 and rr['restricted_manifest_sha256']==x['private_manifest_sha256']
checks=['public members','recorded evidence-only full replay']
for name,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','replay_manifest_sha256'),('original_stream_manifest','original_stream_collection_manifest_sha256'),('author_public_manifest','author_public_manifest_sha256'),('author_private_manifest','author_private_manifest_sha256'),('author_replay_manifest','author_replay_manifest_sha256'),('author_receipt_manifest','author_receipt_manifest_sha256')]:
 value=getattr(args,name)
 if value is not None:assert h(value.read_bytes())==x[key];checks.append(name)
print(json.dumps({'checks':checks,'qualification':'Public file identities and optional manifest bytes only; full replay requires separately held restricted evidence, original queue and Git objects.'}))
