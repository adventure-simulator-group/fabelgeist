# q2744: invariant operations in tactical material registration

Reviewer: /root/mhr_character. This is a bounded independent Lens 4 source
assessment of q2744, OBLIGATION-ROOT-L3-EXT-0004-LENS-04, at product commit
95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. Evidence checkpoint
8caeb2003d10d08320566206817aa0c694231778 records the wrapper as unassessed;
the coordinator reserved this record separately. No ledger or queue was
changed, and no count, alias or lens closure is claimed.

## Assigned file and selected connected operations

`crates/adventuresim-tactical-client/src/presentation/materials.rs:1-40`
registers typed material and presentation plugins; it performs no direct
numeric transformation. Compared with the historical 35-line file, pinned 95e
replaces the pebble material registrations with chunk-material plugins and
adds a vista-tree chunk-material plugin. This source delta is not a runtime
comparison. `presentation/mod.rs:227-234` installs the material group after a
separately listed grass plugin; registration order alone does not prove system
execution or rendering.

The selected shared chunk path groups instances by
`floor(position.xz / chunk_size)` and builds bounds using reach and largest
scale (`presentation/chunk_instancing/spawn.rs:16-38,45-125`). `ChunkSize`
and `InstanceReach` expose floating fields without local validation; that
alone is not an established supported-input failure. Selected pebble and vista
producers supply positive fixed chunk sizes 24 and 256 respectively
(`ground_scatter/loose_stone/batches.rs:20-22,100-115`,
`vista/tree_cards.rs:32-35,146-160`). Pebble scales are 0.58 or 1.0
(`loose_stone/spawn.rs:205-211`), while the selected vista scale is derived
from a clamped variation and a positive multiplier (`vista/details.rs:237-255,
264-270`). All scene coordinates, asset-derived card heights, other internal
callers, bounds overflow and native device behavior remain unproved.

The selected pebble fade ranges are fixed with positive fade-out widths
(`loose_stone.rs:144-165`), and the vista path uses a zero-start `until` band
and one of two positive-width fixed fade-outs (`vista/tree_cards.rs:118-160`,
`vista/details.rs:272-292`). These facts do not establish every material or
rendering path as safe.

## Conditional shared-band operation

`chunk_instancing/instance.rs:48-60` tries to prevent a zero fade-in width by
using `fade_in.end.max(fade_in.start + 0.001_f32)`; it keeps fade-out unchanged.
For the representable f32 start and end 32768.0, adding 0.001 rounds back to
32768.0: an equal-ended fade-in remains equal. The nearby source comment says
that the width must never be zero. This is an internal API counterexample,
not an observed product outcome.

A separately installed grass plugin shares this chunk renderer. Its graphics
configuration admission checks finite, nonnegative, *nondecreasing* endpoints
(`presentation/config.rs:207-212,242-329,332-345`). Its selected grass batch
copies the tier arrays into `FadeBand::new` (`ground_scatter/instanced_grass.rs:
455-468`, `instanced_grass/batches.rs:28-65`). For example, if all other
configuration fields pass and a tier is decoded as fade-in [0.0, 0.001] and
fade-out [1.0, 1.0], these endpoint checks allow the equal fade-out and the
band constructor retains it. A different accepted endpoint ordering such as
fade-in [32768.0, 32768.0] followed by fade-out [32769.0, 32770.0] exhibits
the rounding case, conditional on decoding those values as stated. The
shipped configuration's displayed tier endpoints have positive widths
(`assets/config/tactical-graphics.yaml:35-65`). No configuration parser or
fixture was executed.

The source trace connects the possible equal endpoints to a native boundary:
`chunk_instancing/draw.rs:163-197` uploads `band.shader_range()` and
`pipeline.rs:74-90` adds the visibility-dither shader definition. Shared
shader text `chunk_instancing/chunk_instancing.wgsl:62-67` selects fade-in or
fade-out bounds and divides by `bounds.y - bounds.x`; the grass shader invokes
it at `assets/shaders/tactical_grass_instanced.wgsl:218-220`. Thus, if a
custom configuration with such endpoints is admitted, a nonempty grass tier is
produced, its chunk and pipeline become drawable and visible, and the selected
camera-distance branch is evaluated, the source expression has a zero
width denominator. The exact backend result, actual scene reach, visual effect,
retry behavior and supported hard-cut policy are untested and unresolved.
The grass path is connected support, not itself one of q2744's three selected
pebble/vista material registrations. The examples share one denominator
contract and are not asserted as separate unique defects.

If a future repair is authorized, decide whether equal endpoints represent a
hard cut or must be rejected, then connect config admission, band construction
and the shader operation while preserving valid fade transitions. Future
acceptance should address both fade directions, f32 rounding at large finite
values, selected shipped values and the real supported render boundary. This
is planning evidence, not a repair or product validation.

## Provenance and related records

Original 059 q2744 names the historical revision
6533e444fa37552927070cc8d8190907fd3b413e, required 1-35, EOF 35 and empty
own-lens assessed ranges. Its selected original and reconstructed bytes match;
this does not imply whole-stream equality. The recovered original source
object and 6533/e275 individual Git files match at SHA-256
ccff04d8f8288d9f670097d34527841e9a8f2f91472692b25e5dd53b85c5aba8. The pinned
95e file is SHA-256 e12ef47cca13c862efbcd2db69dbde2408609cdf34a3afd48842d377fc3aa6a0.
These are per-file identities, not clean or equivalent whole working trees.

Root's historical Lens 3 receipt records a fresh 6533 personal 1-35 read; the
e275 receipt records qualified reuse and no new e275 personal reread. Its
`source_adoption_pending_for_frozen18_19` field is false; wording about a
transaction condition for other sources does not settle their adoption.
Adler's separate Lens 11 connected read covered 1-35 with zero added original
frontier credit. My q2743 Lens 2 review and wrapped_scope's independent q2743
peer, wrapped_scope's q2747 Lens 7 and my q2748 Lens 8 and q2750 Lens 10 work
retain their own revision, range and reviewer attribution. None supplies q2744
Lens 4 source credit. Checkpoint 3821 remains unrecovered.

Related earlier records retain different first questions: q49/ledger 201
texture-residency failure state; q2701/ledger 1084 recipe/channel admission;
q2747/ledger 251 celestial material lifecycle; and q2748/q2750/ledger 1088
conditional RenderApp startup. The original q2701 has no status field; its
wrapper's null historical status does not create one. A bounded lexical search
of original queue and 8ca ledger for fade-band/dither terms found no matches;
that is not a global semantic alias inventory. The shared-band question's
relationship to other current or historical work remains for central review.

## Coverage, chronology and recovery

I personally displayed 39 prospectively registered source windows: historical
6533 and e275 1-35, current 95e 1-40, and 36 bounded current support windows.
Shader and test-annotated source was read as text only. Full captured files and
Git objects prove identities; they do not extend personal read ranges. Display
is a reviewer attestation, not independent telemetry.

The first metadata selection failed with KeyError because a source-identity
field had a different shape; its traceback was tool-visible only and the
corrected projection is preserved. My previous q2743 report was displayed
before its specific prior-report registration and then re-displayed after
registration; the first narrative view gives no q2744 source or Lens 4 credit.
A copy-time prior-manifest check was not a real assertion; an additive exact
manifest/member comparison was subsequently recorded. These qualifications do
not change source or history identities.

The restricted packet preserves exact selected records, old receipts, source
blobs and Git proofs. Full original/reconstructed 059 streams and the
protected extraction are separately held same-machine dependencies for the
strongest provenance replay; public hashes do not recreate them or checkpoint
3821. No product execution, parser, build, test, fixture, shader, renderer,
macro, runtime probe or repair was performed.
