#!/usr/bin/env python3
"""Read-only public and optional private evidence verification."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,stat,subprocess,sys
if sys.flags.optimize:raise RuntimeError('unoptimized')
p=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();a=argparse.ArgumentParser();a.add_argument('--private',type=Path);a.add_argument('--queue-private',type=Path);a.add_argument('--extraction',type=Path);z=a.parse_args();assert bool(z.queue_private)==bool(z.extraction) and (z.private or not z.queue_private)
def check(root,m,excluded):
 rows={x['path']:x for x in m['files']};assert len(rows)==len(m['files']);files={};dirs={}
 for f in root.rglob('*'):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_dir():dirs[n]=oct(stat.S_IMODE(f.stat().st_mode))
  elif f.is_file() and n!=excluded:files[n]=f
 assert set(files)==set(rows) and dirs=={x['path']:x['mode'] for x in m['directories']} and oct(stat.S_IMODE(root.stat().st_mode))==m['root_mode']
 for n,f in files.items():
  q=PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts;b=f.read_bytes();r=rows[n];assert (len(b),H(b),oct(stat.S_IMODE(f.stat().st_mode)))==(r['bytes'],r['sha256'],r['mode'])
 return len(files)
m=json.loads((p/'MANIFEST.json').read_bytes());binding=json.loads((p/'PRIVATE-BINDING.json').read_bytes());out={'public_files':check(p,m,'MANIFEST.json'),'private_replay':'not requested','dependency_replay':'not requested'}
if z.private:
 q=z.private.resolve();raw=(q/'PRIVATE-MANIFEST.json').read_bytes();assert H(raw)==binding['private_manifest_sha256'];out['private_files']=check(q,json.loads(raw),'PRIVATE-MANIFEST.json');r=subprocess.run([sys.executable,'-B',str(q/'VERIFY-PRIVATE.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==0 and not r.stderr;out['private_replay']=json.loads(r.stdout)
 if z.queue_private:
  r=subprocess.run([sys.executable,'-B',str(q/'VERIFY-DEPENDENCIES.py'),'--queue-private',str(z.queue_private),'--extraction',str(z.extraction)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==0 and not r.stderr;out['dependency_replay']=json.loads(r.stdout)
  r=subprocess.run([sys.executable,'-B',str(q/'VERIFY-ARCHIVE-OBJECT.py'),'--extraction',str(z.extraction)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==0 and not r.stderr;out['archive_object_replay']=json.loads(r.stdout)
print(json.dumps(out,sort_keys=True))
