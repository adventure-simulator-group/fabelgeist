# q2743: existing owners in tactical material registration

This bounded independent Lens 2 review inspected the entire registered
`materials.rs` body at 6533 and e275, and the entire changed 40-line body at
pinned 95e. In that assigned file, no domain-valued primitive field, parameter,
return value, or retained state was found for substitution with an existing
bespoke owner. The file groups already typed material and presentation plugins
through the framework `Plugin::build` and `&mut App` boundary. The literal 15 is
in a source comment describing tuple arity; this review did not independently
verify the framework's arity limit. This is a scoped nonfinding, not a claim
that all material definitions, plugin lifecycles, or Lens 2 are clear.

The checked product revision is
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. Historical 6533 and e275 share
file blob `7d306375f850f8ea333173be870f883ed15e8c26`, SHA-256
`ccff04d8f8288d9f670097d34527841e9a8f2f91472692b25e5dd53b85c5aba8`, and
EOF 35. The recovered original object matches that file byte-for-byte. Pinned
95e has blob `793ead6b7927d3589a3a224b533b6ee7699a33c5`, SHA-256
`e12ef47cca13c862efbcd2db69dbde2408609cdf34a3afd48842d377fc3aa6a0`, and
EOF 40. This is a per-file comparison, not a clean-tree or runtime claim.

## Existing owners and connected support

At `crates/adventuresim-tactical-client/src/presentation/materials.rs:9–38`,
ordinary `MaterialPlugin` values use concrete material types, and three
`ChunkMaterialPlugin` values use pebble, pebble-billboard and vista-tree types.
`presentation/chunk_instancing.rs:34–44,63–77` already has the generic
`ChunkMaterialPlugin<M>`, constrained by the existing
`ChunkInstancedMaterial` trait. Its definition in
`chunk_instancing/material.rs:23–38` supplies a shader and optional pipeline
specialization contract, with asset and bind-group trait bounds. The concrete
implementations were independently inspected in
`ground_scatter/loose_stone.rs:59–108` and `vista/tree_cards.rs:37–70`.
`presentation/mod.rs:227–234` installs the material group after its separately
listed scatter plugins; source registration order is not proof of runtime
ordering or rendering output. Prior Lens 8 work separately records the old-to-
current plugin change and conditional renderer startup question.

`chunk_instancing/spawn.rs:16–38` already gives the selected batch a
`ChunkSize` owner, described as a square-cell edge in metres, and a separate
`InstanceReach` record for horizontal, above and below extents. The vista
support path uses `ChunkSize(256.0)` at `vista/tree_cards.rs:32–35`; an
ordinary colour or an arbitrary reach is not automatically the same role as a
cell edge. `ChunkSize` exposes its `f32` and the selected operation divides by
it at `spawn.rs:61–65`; no positivity or finite-value guarantee follows from
the type alone. Its complete callers, admission policy and arithmetic are
outside this primary file and remain open, not a newly counted q2743 defect.

The selected concrete material support contains packed native vector fields
under `#[uniform]`. For example, `loose_stone.rs:89–100` packs linear RGB and
an ambient scale into a `Vec4`; the fourth component is not established as
colour alpha. `vista/tree_cards.rs:40–53` records a different mixed-purpose
parameter vector. Replacing these with a similarly shaped colour or length
owner without comparing representation, units, consumers and shader/native
layout would be unjustified. This bounded support review did not establish an
exact existing owner, shader ABI or invalid supported input; those definitions
and their uninspected producers/consumers remain outside the ordered role.

## Recovered evidence and earlier readers

Original 059 q2743 records revision 6533, required 1–35, empty assessed
ranges, Lens 2 status pending, and zero foreign/body credit. The selected
original and reconstructed bytes match; the 8ca reconciliation wrapper is
`unassessed`. The recovered Root Lens 3 registration and receipt attribute a
fresh, untruncated 6533 read of 1–35 to Root. The separate e275 Lens 3 receipt
qualifies same-lens reuse of 1–35 with no fresh personal e275 reread. Its
recorded `source_adoption_pending_for_frozen18_19` field is false, while the
reuse basis also mentions a transaction condition for other sources 18/19;
this packet does not infer those other sources' adoption state. Adler's
separately recovered Lens 11 receipt 206 records a fresh connected 1–35 read
and zero ordered-frontier credit, with no other-lens transfer. Historical
records do not become checkpoint 3821 evidence.

The wrapped_scope q2747 Lens 7 review and this reviewer's earlier q2748 Lens 8
and q2750 Lens 10 reviews have their own independently recorded source scopes;
none substitutes for this Lens 2 read. The q2747 report retains a separate
conditional material-lighting lifecycle relationship already recorded as
ledger 251. The 8ca ledger's relationship 1088 links the prior q2748/q2750
conditional RenderApp startup question; supported no-render reach and actual
behavior remain open. Original q49 and ledger 201 address texture residency
failure state, while q2701 addresses recipe/channel admission. These are
related by plugin context, not established aliases or new counts. Original
q2701 has no `status` field; do not turn that absence into a recorded null.

## Scope and process limits

Eleven personally displayed, prospectively registered windows are listed in
the receipt. Full captured Git blobs prove identities but do not extend support
read ranges. The first metadata locator failed on a string-valued identity
before any product source display; a corrected locator retained only mapping
identities for navigation. Two earlier directory-list metadata displays were
truncated, and one later projection of prior support registration was not
separately pre-registered; neither gives source credit. Historical record
projections were intentionally bounded, with exact records preserved. The
unrelated procedural-assets subtree guide was read as context but does not
apply to the parent assigned file. Some support windows include test-annotated
source and shader/macro text; none was executed.

Unexamined material fields, other producers, device layout, shader execution,
framework activation, policy and rendered behavior remain open. No repair,
product build, test, fixture, shader, runtime probe, publication or ledger
change was performed. No lens or queue closure, global alias, or unique defect
count is asserted. Future decisions on related renderer or material contracts
belong to central reconciliation after the complete audit.
