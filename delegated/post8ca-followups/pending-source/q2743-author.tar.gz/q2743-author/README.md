# q2743 existing-owner evidence

The report is a bounded Lens 2 nonfinding, not a lens or queue closure.
`SOURCE-DIFF.patch` compares only the named historical and current file.

Run `python3 -B VERIFY.py` for public file identities. Add `--private` for
captured Git objects, historical rows and source-window evidence. Supply both
`--queue-private` and `--extraction` with `--private` to compare full 059
streams, six original historical proof files and the archived source object.
The private packet and its dependencies remain separately held on this
machine; no independent custody or product validation is implied.
