#!/usr/bin/env python3
"""Verify this bounded Lens 7 review's public evidence identities."""
from pathlib import Path,PurePosixPath
import hashlib,io,json,sys,tarfile
if sys.flags.optimize:raise RuntimeError('unoptimized Python required')
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q2561-l7-public-evidence-v1'
expected={'REPORT.md','SOURCES.json','HISTORY.json','STATIC-CENSUS.json','SOURCE-VIEWS.tar.gz','SCAN.json','VERIFY.py'};assert set(m['files'])==expected and {x.name for x in p.iterdir()}==expected|{'MANIFEST.json'}
for name,row in m['files'].items():
 assert len(PurePosixPath(name).parts)==1;f=p/name;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
s=json.loads((p/'SOURCES.json').read_bytes());assert s['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and s['reader']=='final_guard_peer' and len(s['sources'])==6 and len(s['views'])==17
rows={x['member']:x for x in s['views']};assert len(rows)==17
seen=set()
with tarfile.open(fileobj=io.BytesIO((p/'SOURCE-VIEWS.tar.gz').read_bytes()),mode='r:gz') as tar:
 for item in tar:
  n=PurePosixPath(item.name);assert len(n.parts)==1 and item.isfile() and item.name not in seen and item.name in rows and item.mode==0o644;seen.add(item.name);b=tar.extractfile(item).read();row=rows[item.name];assert (len(b),h(b))==(row['bytes'],row['sha256']);lo,hi=row['window'];lines=b.splitlines();assert len(lines)==hi-lo+1 and all(line.startswith(str(i).rjust(4).encode()+b'  ') for i,line in zip(range(lo,hi+1),lines))
assert seen==set(rows)
history=json.loads((p/'HISTORY.json').read_bytes());assert history['queue_ledger_snapshot']=='8caeb2003d10d08320566206817aa0c694231778' and history['queue_index']==2561 and history['lens']==7 and history['current_reconciliation']=='unassessed' and history['selected_original_reconstructed_equal_as_parsed'] and not history['whole_queue_stream_bytes_equal']
c=json.loads((p/'STATIC-CENSUS.json').read_bytes());assert c['book_and_catalog_skill_rank_groups_match'] and c['ordinary_skill_target_names_match_ranked_union'] and c['terrain_target_count']==6 and c['consumer_terrain_names_match']
scan=json.loads((p/'SCAN.json').read_bytes());assert scan['positive_controls_passed'] and scan['known_path_value_hits']==scan['known_path_digest_hits']==0 and all(x==0 for x in scan['pattern_hits'].values())
print('Verified bounded public source views, historical relationships and scan record; separately held restricted evidence and audit closure remain open.')
