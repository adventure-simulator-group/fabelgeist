# Lens 7: book target authorities and training inputs

Reader: `final_guard_peer`. This is a partial source assessment of historical
queue record q2561, `EXTENSION-L7-ROOT-L2-EXT-0060`, at source revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. Checkpoint
`8caeb2003d10d08320566206817aa0c694231778` supplies the queue and ledger
snapshot only. No repair, product build, test, runtime probe or product
validation was performed.

The selected source has three independently maintained classifications of
book targets:

- `crates/adventuresim-core/src/book.rs:19–65,285–313` assigns maximum
  teaching ranks to skill-name strings, validates six terrain strings, and
  separately maps skill-name strings to `Skill`.
- `crates/adventuresim-core/src/item_catalog_validation.rs:1360–1383,1386–1445`
  independently implements catalog book target and quality validation.
  At this revision its skill groups match the book module: two names have
  maximum rank 4, six have rank 2, and 13 have rank 1. The 21 names also
  match the `ordinary_skill` mapping. Its six terrain names match the book
  module and the separate mapping at
  `crates/adventuresim-stdb-module/src/time/schedule.rs:429–438`.
- The build-script source calls item compilation, which calls the catalog
  document validator; the displayed validator chain reaches these book checks
  (`crates/adventuresim-core/build.rs:74–80,222–262` and
  `crates/adventuresim-core/src/item_catalog_validation.rs:212–267,313–318,`
  `537–539,1148–1153,1360–1383`). This is a static source trace; no build ran.

The lists agree now. If a future catalog edit admits a new skill name while
`ordinary_skill` remains unchanged, the selected reading candidate's
`target_snapshot` would return `None` and the selection filter would skip it
(`time/schedule.rs:477–515,641–714`). That is a conditional drift path, not
evidence of a currently reachable mismatching catalog entry or product fault.
The build script imports the schema and validator separately
(`build.rs:39–50`), so any shared policy proposal must account for that
source boundary.

The two complete shape predicates are not equivalent: the catalog check also
rejects invalid or duplicate settlement-allowlist entries, while
`book_shape_is_valid` checks only target and quality. For example, a directly
constructed `Book` with a cooking target, quality 1 and an empty allowlist ID
satisfies the latter predicate but fails the former's explicit empty-ID check.
The public fields permit that representation
(`item_catalog_schema.rs:498–529`). No supported path or promise that the two
whole predicates must agree has been established. The separate allowlist
policy must not be lost merely to consolidate the shared target policy.

The public bounded-training helper also takes an already computed effective
rank independently of direct hours and projection callbacks
(`book.rs:83–145`). Its lower-band gate uses the supplied rank, while the
projection is checked against the upper ceiling. If a caller supplies a stale
rank that is at least the lower band when the projected underlying target is
below it, the helper can admit training; this is a representable conditional
API state, not a demonstrated supported call. The selected schedule path
computes rank from the same skills before passing it to the helper
(`time/schedule.rs:477–515,518–638`); the direct-hours field mapping and all
other callers remain untraced. Its projected ordinary-skill formula mirrors
the shown one-pass trait formula under matching direct-hour inputs and a
stable correlation snapshot (`skill.rs:1098–1125`; `schedule.rs:606–635`).
The authored terrain variant attributes say they are intuitive and their
shown correlations have no self entry (`skill.rs:90–107,831–889`); generated
macro expansion was not executed or independently verified.

The original q2561 record attributes its earlier coverage to a Lens 2 supplier;
that evidence supplies no Lens 7 body or reader credit. The original and
reconstructed 059 q2561 rows match as parsed, although the whole queue streams
are different. The book file's historical 6533 and current 95e Git blobs are
identical; the separately inspected item-schema file changed between those
revisions. Related q2492, q2573 and q2681 remain unassessed at the 8ca snapshot.
Ledger row 451 concerns a written-language nonfinite admission gate, and row 859
concerns a reading preview omission; they are related context with distinct
first operations, not established aliases of this observation. The original
checkpoint 3821 ledger and queue remain missing.

Seventeen prospectively registered source windows were displayed. In the
original book window, lines 315–318 are test-module declarations/imports;
the later test body was not read or run. Full source files were captured for
identity checks only outside those windows. Parser coverage, complete
producer/caller and alias inventories, policy intent, and supported reachability
remain open. This report supplies no semantic queue closure, lens completion or
unique-defect count.
