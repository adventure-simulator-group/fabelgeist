# q2913: texture residency aggregate states, Lens 5

This independently registered source-only assessment covers historical 059
q2913, `runtime/handles.rs:1–110`, at pinned 95e. The 6533 and e275 source
objects and the recovered per-file object match 95e exactly: Git blob
`fca01420ed189a94e58bb88b40ae87e20627c147`, SHA-256
`d39e2fce7f4e99648f2c1b5409b52a5a34a55d97514699a77d803e1e2273ffd1`.
This is a per-file identity, not a clean-working-tree or whole-tree claim.
The full assigned body was personally displayed separately at each revision.
Connected files have only the ranges in the personal display receipt.

## Conditional source relationships

1. **Recipe installed versus all expected channels.** The reservation owner
   associates four surface maps with one recipe (`handles.rs:88–110`);
   `runtime.rs:35–57,71–105` separately stores requested recipe handles,
   installed recipe IDs, and per-(recipe, channel) destinations. Its install
   loop writes each supplied map and then marks the recipe installed; readiness
   checks the installed ID, not all destination channels. `bake/wire.rs:60–122`
   rejects empty maps, duplicates, invalid dimensions and malformed lengths,
   but its displayed admission does not require the expected channel set for
   that recipe. A hypothetical, successfully admitted nonempty Rock container
   containing only a valid Albedo map, with all other applicable constraints
   and selected reservation/request/loader operations satisfied, can leave
   Normal, Height and Arm destination images unreplaced while that recipe ID
   is marked installed. This is a source-derived conditional, not an observed
   asset, successful decode, runtime outcome, or established policy violation.
   A surface consumer separately uses albedo, normal and ARM
   (`presentation/buildings/materials.rs:343–365`). An extra supplied channel
   can instead encounter the destination `expect`; that is the first operation
   of the existing q2934 family, and earlier loop writes could precede it.

2. **Transient mask ownership on hypothetical re-reservation.** Reservation
   reuses baked-map destinations keyed by recipe/channel, but creates a new
   terrain blood mask through `images.add` on each call (`handles.rs:10–13,
   63–65,103–110`; `runtime.rs:71–80`). The pinned `bevy_asset` 0.19.1 source
   describes `Assets::add` as allocating a new strong handle (`assets.rs:
   390–405`). A selected terrain material clones the resource's mask handle
   (`presentation/terrain/material.rs:1–103`), and selected focused-ground
   installation retains material handles (`presentation/vista/focused.rs:
   30–88`); particle stamping looks up the current resource's handle
   (`combat_effects.rs:259–303`). If a later reservation installs a new
   resource while old terrain materials and their prior mask remain retained,
   the material and writer can reference different masks. The selected startup
   system registers one setup in a chain (`presentation/mod.rs:227–256`);
   no supported second call, material retention through replacement, absence
   of refresh, rendered output or intended policy is established. Pending
   terrain may refresh (`presentation/terrain.rs:80–165`). This is an open
   lifecycle question, distinct in first operation from recipe-channel admission.

The public texture-set fields are independently typed image handles
(`lib.rs:55–143`); type-correct mixed sets are representable, but no supported
bad construction or universal same-recipe rule is shown. In fact the selected
forest-soil aggregate intentionally combines two recipes (`handles.rs:25–34`).
No defect count, global alias, lens closure, implementation or validation is
claimed. Future planning should decide channel completeness and failure
ownership, and separately decide the intended lifecycle of transient masks.

## Historical and recovery boundaries

The original q2913 names 6533, requires 1–110, records no assessed ranges and
no Lens 5 reader. Its original and reconstructed selected entry bytes match;
their full queue streams differ. The evidence checkpoint 8ca reports this
obligation unassessed. Neither 8ca nor the prior histories is checkpoint 3821.
The original 6533 Root receipt documents a fresh *Lens 3* personal read of
the same body; the e275 receipt records qualified same-Lens-3 reuse, no fresh
read and `source_adoption_pending_for_frozen18_19: true`, with acceptance
conditioned on its named transaction. Neither confers Lens 5 read credit.

The original q2701 summary names q2934 as its canonical conditional
recipe/channel finding. Its later named-scope-completion summary and the
separately recovered v2 proposal's pending-adoption label are preserved as
separate historical records; this review does not resolve that chronology.
The sparse case relates to q2934 and 8ca ledger relationship 1084, which
separates sparse-channel policy from extra-channel handling. Adler's load
failure state in ledger 201 is a distinct first operation. q2904 is an older
Lens 8 record and q2733 a separate source scope; no other reader's scope is
transferred. The original queue and reconstruction matched for the selected
entries only. Original raw evidence and local path values remain restricted.

## Gaps and evidence-only limits

Whether any supported input is sparse, whether all consumers require those
channels, whether re-reservation occurs with retained material, eventual
refresh, intended behavior and native outcomes remain open. The native crate
archive matches its pinned lock checksum, but the lock was structurally parsed
only and selected package source windows were read; no resolved feature set
is inferred. Test-annotated text was read only as source. No product, fixture,
asset, parser, shader, renderer, build, test or runtime probe was run. Full
original/reconstructed queue stream and protected original extraction are
separately held same-machine inputs to strongest replay; offline public replay
alone cannot establish their custody or full-recovery independence.
