# q689: combat defense producers and authored tuning

This bounded Lens 1 source review leaves historical q689 open. At pinned
revision `95e63628f9d70b8dd6e6fede64334696c6995009`, two separate combat
defense operations construct a half-second `AnimationElapsed` directly, while
the retained-attack-power calculation uses additional numerical factors.
The selected authored file and its inspected build projection do not name
counterparts for those particular roles. Whether they are runtime tuning that
must be authored, and which owner should supply each one, remains a policy and
scope question. No unique defect or repair is asserted.

`crates/adventuresim-core/src/autoresolve/melee_round/commitment.rs:142–157`
constructs a half-second work duration and passes it to weapon-defense or
dodge work for a selected response. In `autoresolve.rs:249–266`, action work
uses the embedded fatigue parameters and retains the original duration in
`active_work_seconds`. The workload function in `combat/fatigue.rs:24–58`
clamps the duration to configured bounds for the weapon-energy calculation;
its dodge-energy branch instead uses body and carried mass and dodge speed.
The selected `content/tactical/combat.yaml:10–21` declares a 0.1–0.35 second
work interval, so, **if** that inspected configuration is used in the shown
projection, the half-second input is clamped to 0.35 for weapon-work energy,
while the separate active-work update still sees the original half-second span.
This is a source-level relationship, not a built or observed product result.
The build source parses and validates fatigue parameters and emits the embedded
projection (`build/combat_resolution.rs:63–68,92–113,175–180,259–274`;
`src/combat/fatigue_config.rs:5–45`). Its build script was inspected as text
only.

A second half-second duration is produced for nonempty attempted responses
(`commitment.rs:159–170`). Its use depends on the commitment branch: an
in-flight shield block can retain the attack with zero added recovery;
neutral-guard dodge retains the duration while neutral-guard block or parry
uses zero; other response/phase combinations can retain the duration
(`commitment.rs:171–204`). The selected caller adds that checked span to the
contact time and takes the maximum with previous readiness before conditionally
updating the combatant (`melee_round/mod.rs:207–268`;
`battle_time.rs:23–49`). These distinct work and readiness roles should not be
merged merely because their literals match.

For an effective shield block during a committed attack, the same commitment
function multiplies the stored attack power by the clamped factor
`1.0 - 0.4 * effectiveness` (`commitment.rs:171–180`). For a finite
input, after the inner effectiveness clamp that single factor is near the
interval 0.6–1.0, so the 0.2 lower clamp on the factor is not reached by that
finite case. The floor applies per factor, not to the accumulated stored
multiplier. The selected later exchange takes and resets that retained value,
then multiplies the attack result by it (`autoresolve.rs:49–76,129–150`;
`melee_round/mod.rs:357–373,406–450`). Supported sequences, non-finite
admission and actual outcomes were not established. The YAML energy-transfer
value of 0.4 and its reflex-window value of 0.5 name different roles in the
inspected source; equality alone does not establish aliases or substitutions.

The original and separately reconstructed 059 streams have different whole
identities, but the exact q689 and related q677 selected object bytes agree.
Both historical records explicitly remain open and the published 76fe queue
marks each unassessed. The separately recovered Segovb continuation journal
records q689 at `/segovb_continuation/lens1/pending_connected_contracts/50`
and q677 at `/segovb_continuation/lens1/pending_connected_contracts/37`;
these are related records, not an automatically resolved alias. Original e275
receipts 010 and 008 attribute the historic Lens 1 reads to Root Segovb. The
five q689 linked files and the commitment file match e275 and 95e by exact Git
blob and SHA-256 identity, which proves neither whole-tree identity nor transfer
of a reader's credit. The new 95e views are separately registered and
attributed to `/root/verifier_scope`.

At the 76fe evidence checkpoint, ledger rows 70 and 71 record distinct ranged
attack and ranged defense fatigue questions, and row 77 records empty-hand
attack workload. They share fatigue context with this review, but their first
operations and unresolved policies differ. No alias or count follows. The
precise commitment-name ledger search found no literal match; broader semantic
relationships remain open.

The reviewer displayed 26 prospectively registered source windows under Lens 1.
The primary incapacitation test module and other explicitly excluded test
modules were not read. Other authors, native tactical consumers, possible
configuration paths, and supported action sequences remain outside this bounded
trace. A metadata lookup first used an object store lacking 95e and a later
historical-file copy collided with an existing registration; exclusive creation
preserved both predecessors. Both initial tracebacks were tool-visible but not
separately captured byte-for-byte. A broad ledger locator output was truncated;
its complete structured result is retained. A separate evidence-proof metadata
successor corrects a key that said `95e` while its commit value and Git objects
correctly identified evidence checkpoint 76fe. Policy and skill texts were
displayed before their capture registrations; product source views were
registered before display.

The restricted originals include the historical streams, journal, receipts,
source-view captures and Git objects needed by the offline evidence verifier.
Raw object and local process details remain restricted. Same-machine custody
and a later separately held encryption key are not independent custody. No
repair, product build, test, fixture, runtime probe, product validation, lens
closure, unique count, or recovery of checkpoint 3821 is claimed.
