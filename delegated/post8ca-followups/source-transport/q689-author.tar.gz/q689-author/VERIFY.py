#!/usr/bin/env python3
"""Offline evidence-only identity and source-proof replay."""
import argparse,gzip,hashlib,json,pathlib,stat,sys
if sys.flags.optimize:raise SystemExit('optimized Python is not supported')
def ck(ok,label):
    if not ok:raise ValueError(label)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def files(root,manifest,exclude):
    rows=manifest['files'];names=[r['path'] for r in rows];ck(len(names)==len(set(names)),'duplicate paths')
    actual=set()
    for p in root.rglob('*'):
        ck(not p.is_symlink(),'symlink')
        if p.is_file() and p.relative_to(root).as_posix() not in exclude:actual.add(p.relative_to(root).as_posix())
    ck(actual==set(names),'file set')
    for row in rows:
        rel=pathlib.PurePosixPath(row['path']);ck(not rel.is_absolute() and '..' not in rel.parts,'unsafe path')
        p=root.joinpath(*rel.parts);b=p.read_bytes()
        ck(len(b)==row['bytes'] and sha(b)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8),'file identity/mode')
    if 'directories' in manifest:
        dirs={x['path']:int(x['mode'],8) for x in manifest['directories']}
        actualdirs={p.relative_to(root).as_posix():stat.S_IMODE(p.stat().st_mode) for p in root.rglob('*') if p.is_dir()}
        ck(len(dirs)==len(manifest['directories']) and dirs==actualdirs and stat.S_IMODE(root.stat().st_mode)==int(manifest['root_mode'],8),'directory set/mode')
    return len(rows)
def entries(raw):
    i=0
    while i<len(raw):
        s=raw.index(b' ',i);z=raw.index(b'\0',s+1);ck(z+21<=len(raw),'short tree')
        yield raw[i:s].decode(),raw[s+1:z].decode(),raw[z+1:z+21].hex();i=z+21
    ck(i==len(raw),'tree framing')
def obj(objects,oid,typ):
    ck(oid in objects and objects[oid][0]==typ,'object missing');return objects[oid][1]
def root_tree(objects,rev):
    line=obj(objects,rev,'commit').splitlines()[0];ck(line.startswith(b'tree '),'commit tree');return line[5:].decode()
def walk(objects,rev,path,chain=None):
    cur=root_tree(objects,rev);parts=path.split('/');ck(chain is None or len(parts)==len(chain),'chain length')
    for i,name in enumerate(parts):
        found=[v for v in entries(obj(objects,cur,'tree')) if v[1]==name];ck(len(found)==1,'tree member');mode,_,oid=found[0]
        ck(mode in (('40000','040000') if i<len(parts)-1 else ('100644',)),'tree mode')
        if chain is not None:
            row=chain[i];ck((row['tree'],row['name'],row['mode'],row['object'])==(cur,name,mode,oid),'chain entry')
        cur=oid
    return cur
def view(body,lo,hi):
    lines=body.decode().splitlines();ck(1<=lo<=hi<=len(lines),'view bounds')
    return ''.join(f'{n:4} {lines[n-1]}\n' for n in range(lo,hi+1)).encode()
def slices(raw,want):
    s=raw.decode();d=json.JSONDecoder();i=s.index('[',s.index('"entries"'))+1;out={}
    for n in range(max(want)+1):
        while s[i].isspace() or s[i]==',':i+=1
        start=i;_,i=d.raw_decode(s,i)
        if n in want:out[n]=s[start:i].encode()
    return out
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);args=ap.parse_args();pub=pathlib.Path(__file__).resolve().parent
    npublic=files(pub,load(pub/'MANIFEST.json'),{'MANIFEST.json'});result={'public_files_checked':npublic,'private_replay':'not requested'}
    if args.private is None:print(json.dumps(result,sort_keys=True));return
    r=args.private.resolve();binding=load(pub/'PRIVATE-BINDING.json');raw=(r/'PRIVATE-MANIFEST.json').read_bytes();ck(sha(raw)==binding['private_manifest_sha256'],'private manifest binding');m=json.loads(raw)
    nprivate=files(r,m,{'PRIVATE-MANIFEST.json'});ck(nprivate==binding['private_files_excluding_manifest'] and len(m['directories'])==binding['private_directories'],'private manifest counts')
    specs=[('SOURCE-CAPTURE.json','SOURCE-REGISTRATION.json','source-git-objects'),('COMMITMENT-CAPTURE.json','COMMITMENT-REGISTRATION.json','commitment-git-objects'),('CALLER-CAPTURE.json','CALLER-SOURCE-REGISTRATION.json','caller-git-objects'),('CALLER2-CAPTURE.json','CALLER2-SOURCE-REGISTRATION.json','caller2-git-objects'),('OWNER-CAPTURE.json','OWNER-SOURCE-REGISTRATION.json','owner-git-objects'),('PUBLISHED-PROOF-v2.json','PUBLISHED-PROOF-REGISTRATION.json','published-git-objects')];objects={}
    for cap,reg,store in specs:
        for oid,meta in load(r/cap)['object_inventory'].items():
            b=(r/store/oid).read_bytes();typ=meta['type'];ck(len(b)==meta['bytes'] and sha(b)==meta['sha256'],'Git evidence bytes');ck(hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid,'Git object hash');ck(oid not in objects or objects[oid]==(typ,b),'conflicting object');objects[oid]=(typ,b)
    source_rev='95e63628f9d70b8dd6e6fede64334696c6995009';historic_rev='e2755a732c84e67296b5e3441a4259a84f461b2f';published_rev='76fe53635e2bf1e3e08bbfaa364314f5e7888bf8';ck(root_tree(objects,source_rev)=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','source tree')
    windows=0;paths=set()
    for cap,registration,store in specs:
        capture=load(r/cap);spec=load(r/registration);rows=capture['rows'];ck(len(rows)==len(spec['windows']),'row count')
        for row,requested in zip(rows,spec['windows']):
            ck(row['path']==requested['path'] and [v['range'] for v in row['views']]==requested['ranges'],'registered path/ranges');b=(r/row['source_file']).read_bytes();ck(len(b.splitlines())==row['lines'],'source line count')
            expected=(('published',published_rev),) if cap=='PUBLISHED-PROOF-v2.json' else ((('e275',historic_rev),('95e',source_rev)) if cap in ('SOURCE-CAPTURE.json','COMMITMENT-CAPTURE.json') else (('95e',source_rev),))
            ck(set(row['proofs'])=={x[0] for x in expected},'proof labels')
            for label,rev in expected:
                proof=row['proofs'][label];ck(proof['revision']==rev,'proof revision');oid=walk(objects,rev,row['path'],proof['chain']);ck(oid==proof['blob'] and obj(objects,oid,'blob')==b and sha(b)==proof['sha256'],'source Git binding')
            if cap!='PUBLISHED-PROOF-v2.json':paths.add(row['path'])
            for v in row['views']:
                data=(r/v['file']).read_bytes();ck(data==view(b,*v['range']) and sha(data)==v['sha256'],'registered source view');windows+=1
    ck(windows==26 and len(paths)==12,'personal view scope')
    prior=load(r/'PUBLISHED-PROOF.json');successor=load(r/'PUBLISHED-PROOF-v2.json');p1=dict(prior);p2=dict(successor);p1.pop('qualification');p2.pop('qualification')
    for row in p1['rows']:row['proofs']['published']=row['proofs'].pop('95e')
    ck(p1==p2,'published proof key correction')
    indices={677,689};streams={}
    for label,digest in [('ORIGINAL','2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'),('RECONSTRUCTED','3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173')]:
        b=(r/(label+'-QUEUE-FULL.json')).read_bytes();ck(sha(b)==digest,'historical whole stream');selected=slices(b,indices);streams[label]=selected
        for n,x in selected.items():ck((r/f'Q{n}-{label}.json').read_bytes()==x,'historical exact slice')
    for n,digest in [(677,'2f87efdfcd6f6626833d934fa1d4c8dd4488e4db2ee54d1c63550478d80c00b1'),(689,'d4ae39942882e901092a7eae8df7b73b0e77f0450f9528ee0c61d6a2bdf6742c')]:ck(streams['ORIGINAL'][n]==streams['RECONSTRUCTED'][n] and sha(streams['ORIGINAL'][n])==digest,'historical slice equality')
    oldrows={n:json.loads(streams['ORIGINAL'][n]) for n in indices};ck(all(oldrows[n]['lens']==1 and oldrows[n]['status']=='open-evidence-or-disposition' for n in indices),'historical status')
    for n,needle in [(677,'READ-ROOT-L1-CURRENT-008.json'),(689,'READ-ROOT-L1-CURRENT-010.json')]:ck(any(needle in x.get('path','') for x in oldrows[n]['source_receipt_contexts']),'historical receipt pointer')
    for name,digest in [('HISTORICAL-READ.json','59a549a8805d1a703f95560b7c143812a61ccb400123c7f45fc7102d96c80e70'),('HISTORICAL-008-READ.json','29d81ee6692138f592cf5d9a85dc01cc13850051a1558b00666601779979c28d'),('HISTORICAL-SEGOVB-LEDGER.json','3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac')]:ck(sha((r/name).read_bytes())==digest,'historical recovered record hash')
    h10=load(r/'HISTORICAL-READ.json');h08=load(r/'HISTORICAL-008-READ.json');src=load(r/'SOURCE-CAPTURE.json')['rows'];commit=load(r/'COMMITMENT-CAPTURE.json')['rows'][0]
    for i,row in enumerate(src):
        previous=h10['rows'][i];ck(previous['git_path']==row['path'] and previous['sha256']==row['proofs']['e275']['sha256'] and previous['attribution'].startswith('Root Segovb personal independent L1') and not previous['body_output_truncated'],'historical 010 attribution')
    previous=h08['rows'][2];ck(previous['git_path']==commit['path'] and previous['sha256']==commit['proofs']['e275']['sha256'] and previous['attribution'].startswith('Root Segovb personal independent L1') and not previous['body_output_truncated'],'historical 008 attribution')
    hist=load(r/'HISTORICAL-SEGOVB-LEDGER.json')['segovb_continuation']['lens1']['pending_connected_contracts'];ck(hist[37]==load(r/'HISTORICAL-JOURNAL-Q677.json') and hist[50]==load(r/'HISTORICAL-JOURNAL-Q689.json'),'recovered journal selections')
    queue=load(r/'PUBLISHED-00.raw')['entries'];ledger=load(r/'PUBLISHED-01.raw')['newly_assessed_ledger']['entries'];pending=load(r/'PUBLISHED-02.raw')['rows'];ck(len(queue)==3713 and len(ledger)==1115,'published counts')
    for n in indices:ck(queue[n]==load(r/f'Q{n}-CURRENT.json') and queue[n]['current_reconciliation']=='unassessed' and queue[n]['historical_lens']==1,'published queue selection')
    ck([x['queue_index'] for x in pending]==[3344,3353,3354,3356,3368,3462] and not indices.intersection(x['queue_index'] for x in pending),'pending scope')
    selected=load(r/'LEDGER-SELECTED.json');ck(set(selected)=={'70','71','77'} and all(ledger[int(i)]==v for i,v in selected.items()),'selected ledger rows')
    for file in ('LEDGER-LOCATOR.json','LEDGER-LOCATOR-2.json'):
        loc=load(r/file);ck(loc['hits']==[],'literal ledger locator')
    reg=load(r/'LEDGER-BROAD-REGISTRATION.json');hits=[]
    for i,row in enumerate(ledger):
        s=json.dumps(row,sort_keys=True,ensure_ascii=False).casefold();matched=[t for t in reg['terms'] if t.casefold() in s]
        if matched:hits.append({'index':i,'id':row.get('id'),'matched_terms':matched})
    ck(load(r/'LEDGER-BROAD-LOCATOR.json')=={'rows':len(ledger),'hits':hits} and len(hits)==327,'full broad ledger locator')
    result.update({'private_replay':'passed','private_files_checked':nprivate,'git_objects_checked':len(objects),'registered_views':windows,'distinct_source_files':len(paths),'historical_selected_records':len(indices),'published_ledger_rows_selected':len(selected),'qualification':'Evidence identities and recorded source views only; no runtime outcome, closure or independent custody proven.'});print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
