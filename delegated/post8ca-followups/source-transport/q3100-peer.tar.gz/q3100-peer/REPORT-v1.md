# Independent peer review of q3100, Lens 1

The separately authored q3100 report and its additive historical-attribution
correction are supported by the bounded source and record checks below. I found
no substantive discrepancy in those checked claims. This review is independent
of the q3100 author; it does not independently attest every one of that
reviewer's 52 reported displays, establish a defect count, or close the queue or
lens. Product revision is `95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`.

The author's report separately identifies an application-level typed timing
producer question and retained half-open sample question. The generic numeric
sampler is a real arithmetic boundary; raw floating point there alone is not a
defect. Neither question proves a supported failure or an appropriate new owner.

* `crates/adventuresim-tactical-server/src/bot.rs:63–90` retains a typed
  `Seed` at the seeded entry and forwards raw float sampling to
  `fabelgeist-determinism/src/stream.rs:74–93`. The selected reaction delay
  bounds are `AnimationElapsed` values (`tactical-core/src/combat_config.rs:
  333–337`), and selected initiative and cadence values use the same owner
  (`tactical-core/src/combat_config/ai_offense.rs:5–12`).
  `core/src/elapsed.rs:10–12,24–39,100–104` checks finite, nonnegative seconds
  through its constructor and deserialization conversion. Config validation
  checks selected min/max ordering when that validation path is used
  (`combat_config.rs:417–419,532–541`; `ai_offense.rs:21–25`).
* In the ordinary reaction branch, `bot/defense.rs:230–243` extracts seconds,
  samples, readmits the result to `AnimationElapsed`, then refines it for a
  native timer. The special guaranteed-dodge branch is separate. The selected
  melee and ranged jitter branches likewise readmit the sample before typed
  addition and the timer boundary (`bot/offense/phase.rs:329–353`). Initiative
  sampling has an intervening instinct scale before readmission
  (`bot/offense/tactics.rs:3–12`). Whether an application-level checked
  sampler is appropriate, how to retain rounding and draw ordering, and the
  reach of other callers remain open.
* `fabelgeist-determinism/src/lib.rs:12–19` maps the high 24 bits to a
  half-open unit sample. On the selected contact path,
  `combat/contact.rs:52–56,59–90` draws separate contact and defense-alignment
  samples. Both are stored as raw `f32` in pending contact and intent records
  (`combat/ingress/attack_start.rs:102–110,215–245`;
  `combat/protocol.rs:35–45,58–65`), then forwarded only in the shown
  target/body-part branch (`combat/ingress.rs:274–303`). Selected melee and
  active-defense operations consume those values (`combat/melee.rs:182–216,
  340–341,416–450`; `combat/melee/active_defense.rs:56–74`). This does not
  prove every producer or admission preserves their roles. The existing
  `core/src/unit_interval.rs:9–34` admits the closed endpoint 1, so it alone
  does not express the generator's half-open bound.
* `bot.rs:44–61` resolves optional fixture inputs and copies a loaded fixture's
  enemy count to `Args.required_enemy_kills`. The selected main path passes
  that `u32` into `MissionState` (`main.rs:66–89,119–120,168–175`;
  `mission/mod.rs:29–57`) and a terminal snapshot (`mission/systems.rs:
  234–245`). Without a fixture, the CLI count remains. The selected terminal
  check treats zero, insufficient loaded enemies, unsealed enrollment, or an
  empty party as no outcome (`mission/mod.rs:165–202`); this is source
  behavior, not a demonstrated mission failure. The normal fixture loader
  validates nonempty and at most 30 entries before its count conversion
  (`core/src/tactical_fixture.rs:48–80,87–100`;
  `core/src/threat_escalation.rs:18`), while derived deserialization is a
  distinct path whose reach is not established here.

The original 059 q3100 and reconstructed selected row match byte-for-byte.
The exact original row records revision `6533e444fa37552927070cc8d8190907fd3b413e`,
required `bot.rs:1–90`, EOF 1248 and empty assessed ranges; it names no reader.
Its separately recovered prospective registration and source object match the
recorded hashes. The prior Root Lens 3 receipt identifies a personal 6533 read.
A later e275 Lens 3 receipt qualifies 1–62 reuse subject to frozen-source
adoption in the same transaction, while the 63–90 receipt preserves a mixed
fresh/inherited basis; neither records a fresh e275 personal reread. Whether
the adoption condition was fulfilled is not established. Neither history
confers this Lens 1 read or checkpoint 3821 credit. The 6533, e275 and 95e
`bot.rs` blobs and recovered object match per-file; that is not whole-tree
equivalence. At the checked 76fe checkpoint q3100 remains unassessed.

Original and reconstructed selected q662 bytes also match. Its separately
attributed Root e275 Lens 1 question concerns extreme opposite-sign finite
range endpoints and is not the same first operation as typed elapsed
propagation. The selected well-formed elapsed endpoints are nonnegative; this
excludes that particular opposite-sign witness there, not all rounding issues,
invalid construction paths, or other callers. A separately selected spawn
caller uses -5 to 5 (`player_projection/spawn_admission.rs:69–74`), not that
extreme witness. Ledger 378 is the separately recorded fixture deserialization
admission question; ledger 379 concerns the production count `expect`.
Ledger 377 and q1688 concern the fixture path helper and parser boundary, and
q3134 concerns zero-grace enrollment. The original q3134 status key is absent;
the reconciliation wrapper has an explicit null historical status. These are
related records, not established aliases. Ledger 380 and 381 are separate AI
configuration-admission records.

The author's sealed public and restricted manifest-listed members and modes,
and the separate process manifest-listed members, were independently hashed.
The author's public report is byte-identical to the previously shared draft;
its correction is byte-identical to the separately shared correction. The
recovered historical receipt rows were checked directly. The author reports an
evidence-only replay and finite scans; their receipt and process log are
preserved as separately attributed evidence, not as this reviewer's execution
or independent display telemetry. My own registered 95e source views are
separate and limited to the listed windows.

Two support batches attempted ranges past EOF: tactics lines 49–55 and AI
configuration lines 38–65 do not exist. Each attempt stopped with a tool-visible
`IndexError` whose stream was not separately captured; earlier windows had
already been displayed and saved, but each original batch receipt was not
written. Reconstructed hashes and newly registered, completed EOF-bounded
views preserve the correction; no nonexistent lines are credited. An initial
metadata projection looked up the wrong revision field and printed null for a
missing key; it was corrected before the primary source display. A narrow
unit-owner filename search found no match and was corrected by a broader
filename-only lookup. Display events are reviewer-attested, not independently
telemetered. No product, fixture, test, build or runtime probe was run.

The restricted packet and 95e/6533/e275/76fe/original-queue Git objects are
needed for the full evidence replay. The authored packet and its separately
held complete historical streams remain additional same-machine dependencies;
public metadata alone does not recover them or establish independent custody.
All policy, reachability, untraced paths, cross-lens reconciliation and repair
planning remain open.
