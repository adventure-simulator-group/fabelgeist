#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;a=argparse.ArgumentParser()
for n in ['private-manifest','replay-manifest','author-public-manifest','author-private-manifest','author-receipt-manifest','author-process-manifest','q689-manifest']:a.add_argument('--'+n,type=Path)
args=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q3100-peer-public-v1';expected={'REPORT.md','REPORT-v1.md','REFERENCE-CORRECTION.json','RECORDED-REPLAY.json','PROCESS-QUALIFICATION.json','BINDING.json','VERIFY.py','PUBLIC-SCAN.json'};assert set(m['files'])==expected and {x.name for x in p.iterdir()}==expected|{'MANIFEST.json'}
for n,row in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(row['bytes'],row['sha256'])
c=json.loads((p/'REFERENCE-CORRECTION.json').read_bytes());before=(p/'REPORT-v1.md').read_bytes();after=(p/'REPORT.md').read_bytes();assert h(before)==c['predecessor_sha256'] and h(after)==c['successor_sha256'];assert before.count(c['insert_after'].encode())==1 and before.replace(c['insert_after'].encode(),c['insert_after'].encode()+c['inserted_text'].encode())==after
x=json.loads((p/'BINDING.json').read_bytes());assert x['schema']=='726-q3100-peer-public-binding-v1' and x['queue_index']==3100 and x['lens']==1;checks=['public members','exact report-reference clarification']
for name,key in [('private_manifest','private_manifest_sha256'),('replay_manifest','replay_manifest_sha256'),('author_public_manifest','author_public_manifest_sha256'),('author_private_manifest','author_private_manifest_sha256'),('author_receipt_manifest','author_receipt_manifest_sha256'),('author_process_manifest','author_process_manifest_sha256'),('q689_manifest','q689_manifest_sha256')]:
 value=getattr(args,name)
 if value is not None:assert h(value.read_bytes())==x[key];checks.append(name)
print(json.dumps({'checks':checks,'qualification':'Public members and optionally supplied manifests only; full replay needs separately held restricted evidence and Git objects.'}))
