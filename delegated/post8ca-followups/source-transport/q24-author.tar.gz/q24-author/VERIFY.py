#!/usr/bin/env python3
"""Offline evidence-only identity and source-proof replay."""
import argparse,gzip,hashlib,json,pathlib,stat,sys
if sys.flags.optimize:raise SystemExit('optimized Python is not supported')
def ck(ok,label):
    if not ok:raise ValueError(label)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def files(root,manifest,exclude):
    rows=manifest['files'];names=[r['path'] for r in rows];ck(len(names)==len(set(names)),'duplicate paths')
    actual=set()
    for p in root.rglob('*'):
        ck(not p.is_symlink(),'symlink')
        if p.is_file() and p.relative_to(root).as_posix() not in exclude:actual.add(p.relative_to(root).as_posix())
    ck(actual==set(names),'file set')
    for row in rows:
        rel=pathlib.PurePosixPath(row['path']);ck(not rel.is_absolute() and '..' not in rel.parts,'unsafe path')
        p=root.joinpath(*rel.parts);b=p.read_bytes()
        ck(len(b)==row['bytes'] and sha(b)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8),'file identity/mode')
    if 'directories' in manifest:
        dirs={x['path']:int(x['mode'],8) for x in manifest['directories']}
        actualdirs={p.relative_to(root).as_posix():stat.S_IMODE(p.stat().st_mode) for p in root.rglob('*') if p.is_dir()}
        ck(len(dirs)==len(manifest['directories']) and dirs==actualdirs and stat.S_IMODE(root.stat().st_mode)==int(manifest['root_mode'],8),'directory set/mode')
    return len(rows)
def entries(raw):
    i=0
    while i<len(raw):
        s=raw.index(b' ',i);z=raw.index(b'\0',s+1);ck(z+21<=len(raw),'short tree')
        yield raw[i:s].decode(),raw[s+1:z].decode(),raw[z+1:z+21].hex();i=z+21
    ck(i==len(raw),'tree framing')
def obj(objects,oid,typ):
    ck(oid in objects and objects[oid][0]==typ,'object missing');return objects[oid][1]
def root_tree(objects,rev):
    line=obj(objects,rev,'commit').splitlines()[0];ck(line.startswith(b'tree '),'commit tree');return line[5:].decode()
def walk(objects,rev,path,chain=None):
    cur=root_tree(objects,rev);parts=path.split('/');ck(chain is None or len(parts)==len(chain),'chain length')
    for i,name in enumerate(parts):
        found=[v for v in entries(obj(objects,cur,'tree')) if v[1]==name];ck(len(found)==1,'tree member');mode,_,oid=found[0]
        ck(mode in (('40000','040000') if i<len(parts)-1 else ('100644',)),'tree mode')
        if chain is not None:
            row=chain[i];ck((row['tree'],row['name'],row['mode'],row['object'])==(cur,name,mode,oid),'chain entry')
        cur=oid
    return cur
def view(body,lo,hi):
    lines=body.decode().splitlines();ck(1<=lo<=hi<=len(lines),'view bounds')
    return ''.join(f'{n:4} {lines[n-1]}\n' for n in range(lo,hi+1)).encode()
def slices(raw,want):
    s=raw.decode();d=json.JSONDecoder();i=s.index('[',s.index('"entries"'))+1;out={}
    for n in range(max(want)+1):
        while s[i].isspace() or s[i]==',':i+=1
        start=i;_,i=d.raw_decode(s,i)
        if n in want:out[n]=s[start:i].encode()
    return out
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);args=ap.parse_args();pub=pathlib.Path(__file__).resolve().parent
    npublic=files(pub,load(pub/'MANIFEST.json'),{'MANIFEST.json'});result={'public_files_checked':npublic,'private_replay':'not requested'}
    if args.private is None:print(json.dumps(result,sort_keys=True));return
    r=args.private.resolve();binding=load(pub/'PRIVATE-BINDING.json');raw=(r/'PRIVATE-MANIFEST.json').read_bytes();ck(sha(raw)==binding['private_manifest_sha256'],'private manifest binding');m=json.loads(raw)
    nprivate=files(r,m,{'PRIVATE-MANIFEST.json'});ck(nprivate==binding['private_files_excluding_manifest'] and len(m['directories'])==binding['private_directories'],'private manifest counts')
    specs=[('SOURCE-CAPTURE.json','SOURCE-REGISTRATION.json','source-git-objects')]+[(f'SUPPORT{str(i) if i>1 else ""}-CAPTURE.json',f'SUPPORT{str(i) if i>1 else ""}-REGISTRATION.json',f'support{str(i) if i>1 else ""}-git-objects') for i in range(1,10)]+[('PUBLISHED-PROOF-v2.json','PUBLISHED-PROOF-REGISTRATION.json','published-git-objects')];objects={}
    for cap,reg,store in specs:
        for oid,meta in load(r/cap)['object_inventory'].items():
            b=(r/store/oid).read_bytes();typ=meta['type'];ck(len(b)==meta['bytes'] and sha(b)==meta['sha256'],'Git evidence bytes');ck(hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid,'Git object hash');ck(oid not in objects or objects[oid]==(typ,b),'conflicting object');objects[oid]=(typ,b)
    source_rev='95e63628f9d70b8dd6e6fede64334696c6995009';historic_rev='e2755a732c84e67296b5e3441a4259a84f461b2f';frozen_rev='6533e444fa37552927070cc8d8190907fd3b413e';published_rev='76fe53635e2bf1e3e08bbfaa364314f5e7888bf8';ck(root_tree(objects,source_rev)=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','source tree')
    windows=0;paths=set()
    for cap,registration,store in specs:
        capture=load(r/cap);spec=load(r/registration);rows=capture['rows'];ck(len(rows)==len(spec['windows']),'row count')
        for row,requested in zip(rows,spec['windows']):
            ck(row['path']==requested['path'] and [v['range'] for v in row['views']]==requested['ranges'],'registered path/ranges');b=(r/row['source_file']).read_bytes();ck(len(b.splitlines())==row['lines'],'source line count')
            expected=(('published',published_rev),) if cap=='PUBLISHED-PROOF-v2.json' else ((('6533',frozen_rev),('e275',historic_rev),('95e',source_rev)) if cap=='SOURCE-CAPTURE.json' else (('95e',source_rev),))
            ck(set(row['proofs'])=={x[0] for x in expected},'proof labels')
            for label,rev in expected:
                proof=row['proofs'][label];ck(proof['revision']==rev,'proof revision');oid=walk(objects,rev,row['path'],proof['chain']);ck(oid==proof['blob'] and obj(objects,oid,'blob')==b and sha(b)==proof['sha256'],'source Git binding')
            if cap!='PUBLISHED-PROOF-v2.json':paths.add(row['path'])
            for v in row['views']:
                data=(r/v['file']).read_bytes();ck(data==view(b,*v['range']) and sha(data)==v['sha256'],'registered source view');windows+=1
    ck(windows==42 and len(paths)==17,'personal view scope')
    prior=load(r/'PUBLISHED-PROOF.json');successor=load(r/'PUBLISHED-PROOF-v2.json');p1=dict(prior);p2=dict(successor);p1.pop('qualification');p2.pop('qualification')
    for row in p1['rows']:row['proofs']['published']=row['proofs'].pop('95e')
    ck(p1==p2,'published proof key correction')
    indices={24,3289};streams={}
    for label,digest in [('ORIGINAL','2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'),('RECONSTRUCTED','3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173')]:
        b=(r/(label+'-QUEUE-FULL.json')).read_bytes();ck(sha(b)==digest,'historical whole stream');selected=slices(b,indices);streams[label]=selected
        for n,x in selected.items():ck((r/f'Q{n}-{label}.json').read_bytes()==x,'historical exact slice')
    for n,digest in [(24,'5f47db35d2f474133fa048f2f60b5215c29908523fdbfb8c9f811345143c3405'),(3289,'0f51bdb1746d872d0da9dbd31d7d1fc3b5cfc30b8888fa1c537127ff8260e5ae')]:ck(streams['ORIGINAL'][n]==streams['RECONSTRUCTED'][n] and sha(streams['ORIGINAL'][n])==digest,'historical slice equality')
    original=json.loads(streams['ORIGINAL'][24]);ck(original['contract_id']=='ADLER-L11-TEMPORARY-STAKE-SETTLEMENT' and original['lens']==11 and original['status']=='open-reconciliation' and original['body_or_population_credit']==0,'historical q24 status')
    hs=original['exact_source_identities_and_assessed_ranges'][0];ck(hs['revision_as_recorded'] is None and hs['attribution_as_recorded'] is None and hs['source_sha256']=='013eba5886065bb81edc072a7a9ea987b50af7766422f605d6df603f29e73010','historical source qualification')
    body=(r/'SOURCE-00.raw').read_bytes();ck(body==(r/'HISTORICAL-SOURCE-OBJECT.raw').read_bytes() and sha(body)==hs['source_sha256'],'historical exact source object')
    for name,digest in [('HISTORICAL-READ-L11-122.json','a155bf833c0515ba137951134fc89dd5b47ea176418533e29022252c0953bb54'),('HISTORICAL-REGISTRATION-ADLER-026.json','5b144e8369ec9f7e369fc720af198ad3dae217011984be9661e14cc17dae2811'),('HISTORICAL-SEGOVB-LEDGER.json','3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac')]:ck(sha((r/name).read_bytes())==digest,'historical recovered record identity')
    hist=load(r/'HISTORICAL-READ-L11-122.json');registration=load(r/'HISTORICAL-REGISTRATION-ADLER-026.json');selected=load(r/'HISTORICAL-READ-SELECTED.json');ck(hist['lens']==11 and hist['original_index']==1225 and hist['sha256']==hs['source_sha256'] and registration['prospective'] and registration['sha256']==hs['source_sha256'],'historical receipt identity');ck(selected['fresh_reads']==hist['fresh_reads'] and selected['scope']==hist['scope'] and selected['selected_role_dispositions']==[v for v in hist['role_dispositions'] if any(lo<=3046<=hi for lo,hi in v['ranges'])],'historical summary selection')
    ledger_hist=load(r/'HISTORICAL-SEGOVB-LEDGER.json')['discovery_findings_and_dependencies']['ADLER-L11-TEMPORARY-STAKE-SETTLEMENT'];ck(ledger_hist==load(r/'HISTORICAL-LEDGER-Q24.json') and ledger_hist['accepted_unique_count_change']==0,'historical ledger selection')
    queue=load(r/'PUBLISHED-00.raw')['entries'];ledger=load(r/'PUBLISHED-01.raw')['newly_assessed_ledger']['entries'];pending=load(r/'PUBLISHED-02.raw')['rows'];ck(len(queue)==3713 and len(ledger)==1115,'published counts')
    for n in indices:ck(queue[n]==load(r/f'Q{n}-CURRENT.json') and queue[n]['current_reconciliation']=='unassessed','published queue selection')
    ck(queue[24]['historical_lens']==11 and queue[24]['historical_status']=='open-reconciliation','published q24 status');ck([x['queue_index'] for x in pending]==[3344,3353,3354,3356,3368,3462] and 24 not in [x['queue_index'] for x in pending],'pending scope')
    loc=load(r/'LEDGER-LOCATOR.json');reg=load(r/'LEDGER-LOCATOR-REGISTRATION.json');hits=[]
    for i,row in enumerate(ledger):
        s=json.dumps(row,sort_keys=True,ensure_ascii=False).casefold();matched=[t for t in reg['terms'] if t.casefold() in s]
        if matched:hits.append({'index':i,'id':row.get('id'),'matched_terms':matched})
    ck(loc=={'rows':len(ledger),'hits':hits} and not hits,'bounded literal ledger locator')
    result.update({'private_replay':'passed','private_files_checked':nprivate,'git_objects_checked':len(objects),'registered_views':windows,'distinct_source_files':len(paths),'historical_selected_records':len(indices),'literal_ledger_hits':len(hits),'qualification':'Evidence identities and recorded source views only; no runtime outcome, closure or independent custody proven.'});print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
