# q24: temporary-member stake settlement

The historical q24 question remains a conditional source-level settlement
mismatch at pinned revision `95e63628f9d70b8dd6e6fede64334696c6995009`.
For a leader removing a temporary nonleader, the selected helper transfers
party currency to that member but does not itself debit the member's separate
stake. If a positive stake remains after that transfer, the immediately
following guard returns an error before the membership-removal statements.
Supported arrival at that state and the database's commit or rollback behavior
on the error remain unproved. No new defect count or closure is claimed.

`crates/adventuresim-stdb-module/src/strategic/inventory_trade.rs:3000–3056`
checks the acting character, party membership, leader/self rule and camp
fireplace before calling the temporary-member helper. The helper at
`:3093–3109` selects a member's recorded stake, returns early for zero, and
otherwise calls the party-to-personal currency transfer at `:1799–1832`.
That transfer checks pooled currency, moves selected currency stacks and
calls the personal item-insertion wrapper; it contains no direct PartyStake
update. The next guard tests whether any stake for that member is still
positive. An absent or zero stake, insufficient coin, another earlier error,
or an indirect change to the stake requires a different disposition.

Party stake is a separately recorded member entitlement, not the pooled coin
stack (`strategic/authority_model.rs:1079–1104`). Ordinary item withdrawal
and stake-funded purchase explicitly update the stake after their distinct
value or payment operations (`inventory_trade.rs:1871–1889,2317–2344`).
The schema shown uses an independent primary ID and indexes the party and
character separately; it does not show a unique pair constraint. Whether
multiple stake rows can arise through supported writers is open. These roles
and first operations should not be flattened merely because they use numeric
amounts, nor treated as automatic aliases.

The selected insertion path calls `add_inventory_item_checked` through a
wrapper that converts its error to `None` (`item.rs:351–438`); the transfer
ignores that returned option. For an ordinary projected currency item with no
food, measured, durable, container or attachment capabilities, the displayed
classification and insertion paths do not directly update stake
(`item.rs:140–190,254–287,322–407`; `inventory_amount.rs:33–53`;
`weapon_instance.rs:141–150`). Six selected authored currency definitions and
their shared ID list are visible in the preserved source windows. Actual
persisted item definitions, indirect hooks, caller behavior and what survives a
reducer error were not validated. In particular, this review does not assert
that coins are lost, duplicated or retained after an error.

A separate source-level producer can credit a positive stake to each living
party member when a reported contract has a sufficiently large positive reward
and its preceding conditions succeed (`strategic/mission_bootstrap.rs:10–69`;
`strategic/party_readiness.rs:1–20`). The living-member selector does not test
the temporary flag. This does not establish that a generated temporary
companion can join such a party: the selected temporary-character creation
source is explicitly a tactical-server path (`character.rs:797–824`), and
other admission and membership producers remain unreviewed. The selected
authorized-action dispatcher also calls the removal function
(`strategic/approved_action.rs:99–114`), without proving the entire external
authorization chain.

The recovered original and separately reconstructed 059 whole streams differ,
but the exact q24 selected object bytes agree. Its historical status is
`open-reconciliation`; the published 76fe queue records it as unassessed.
The original queue source record uses `pr-working`, leaves its explicit
revision and attribution fields null, and grants zero new reading credit. A
separately recovered Adler Lens 11 receipt and registration record a historical
full-file read. The recovered exact pr-working source object matches that
receipt's SHA-256 and the single file at Git revisions 6533, e275 and 95e;
that proves file-byte identity only, not historical whole-tree identity or
transfer of the earlier reader's credit. The older continuation ledger
contains the original q24 source-level question and records repair and
validation as incomplete. None of these older records is checkpoint 3821.

A bounded literal search of the 1,115 newly assessed 76fe ledger entries for
q24 and selected stake terms returned no hits. It does not rule out semantic
relationships or aliases elsewhere. Central reconciliation owns that decision.
Open questions include supported temporary-member and positive-stake
production, the precise authority boundary, all stake writers and uniqueness,
insufficient-liquidity behavior, indirect insertion effects, and native
transaction semantics. Repair dependencies can be described as one coherent
stake/currency/member settlement contract, but no implementation, validation,
or acceptance is performed here.

The reviewer personally displayed 42 prospectively registered current source
windows across 17 files under Lens 11. The remainder, including test modules,
was not read merely because full source blobs were captured as integrity
proofs. A different candidate, q3289, was considered and dropped before any of
its product source was displayed because it was adjacent to the separately
excluded challenge family. Its full queue-record output and the full historical
Adler receipt output were tool-truncated; exact original bytes and a separately
shown compact receipt selection are preserved. A guessed native-module rule
file was absent; its error was tool-visible without a separately captured
byte-for-byte transcript, and recursive rule discovery found no such file.
The imported same-reviewer 76fe Git proof includes its predecessor and
metadata-label correction.

The restricted evidence retains original and reconstructed queues, historical
object and receipt, registered views and raw Git proofs for offline evidence
replay. Same-machine originals and any later separately held key are not
independent custody. No product execution, build, test, fixture, runtime
probe, repair, product validation, unique count or lens closure is claimed.
