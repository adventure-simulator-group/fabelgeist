#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--peer-private-manifest',type=Path);a.add_argument('--peer-replay-manifest',type=Path);a.add_argument('--delegate-public-manifest',type=Path);a.add_argument('--delegate-private-manifest',type=Path);args=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q24-peer-public-manifest-v1' and set(m['files'])=={'REPORT.md','BINDING.json','RECORDED-REPLAY.json','VERIFY.py','PUBLIC-SCAN.json'} and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,r in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(r['bytes'],r['sha256'])
x=json.loads((p/'BINDING.json').read_bytes());assert x['schema']=='726-q24-peer-public-binding-v1' and x['queue_index']==24 and x['lens']==11;checks=['public members']
for value,key,label in ((args.peer_private_manifest,'peer_private_manifest_sha256','peer private manifest'),(args.peer_replay_manifest,'peer_replay_manifest_sha256','peer replay manifest'),(args.delegate_public_manifest,'delegate_public_manifest_sha256','delegate public manifest'),(args.delegate_private_manifest,'delegate_private_manifest_sha256','delegate private manifest')):
 if value is not None:assert h(value.read_bytes())==x[key];checks.append(label)
print(json.dumps({'checks':checks,'qualification':'Public identities and optional supplied manifests only. Full evidence replay requires the separately held peer, delegate and Git objects.'}))
