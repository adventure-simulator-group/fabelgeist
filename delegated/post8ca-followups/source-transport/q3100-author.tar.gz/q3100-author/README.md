# q3100 source-review evidence

Read REPORT.md and the additive REPORT-CORRECTION.md together. Their
conclusions are bounded, conditional, and separately attributed.

Run `python3 -B VERIFY.py` for public file identities. Optionally supply
`--private <restricted-packet>` to replay the captured Git-object and source
range proofs and `--author-private <prior-author-packet>` to check the four
selected records against both complete historical streams. These are
evidence-only checks. The restricted captures and prior-author dependency are
separately held on the same machine; this public transport alone does not
contain the exact raw bodies or prove independent durable custody.
