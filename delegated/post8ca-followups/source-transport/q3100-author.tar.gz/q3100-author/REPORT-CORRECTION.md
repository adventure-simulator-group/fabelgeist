# Additive historical-attribution qualification

This clarification supplements, and does not replace, `REPORT.md`. For the
historical e275 1–62 reuse, the recovered Lens 3 receipt makes acceptance of
that reuse conditional on frozen-source adoption in the same transaction. The
separate 63–90 receipt identifies a mixed fresh/inherited basis and requires
preserving its original attributions. Neither receipt claims a fresh e275
personal reread. Whether the transaction's adoption condition was satisfied is
not independently established by this packet. No earlier reading transfers
into this Lens 1 assessment or checkpoint 3821.

The selected original q3100 row itself does not identify a reader and has empty
assessed ranges. The attribution of the older Root Lens 3 source reading comes
from the separately recovered receipt, not from the selected q3100 row. The
first metadata projection that rendered q3134's absent status as null was later
corrected by an explicit field-membership check; the wrapper's null is a
separate field. These corrections change no product-source or ledger status.
