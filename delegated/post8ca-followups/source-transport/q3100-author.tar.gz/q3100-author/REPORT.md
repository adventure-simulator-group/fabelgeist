# Independent q3100: tactical random producers, Lens 1

This is a bounded source assessment at product commit
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. It neither closes a queue
entry or lens nor assigns a unique defect count. No product, fixture, test,
shader, or runtime was executed. Central reconciliation remains separate.

## Historical scope and credit

The original 059 `/entries/3100` has lens 1 and records
`crates/adventuresim-tactical-server/src/bot.rs` at revision
`6533e444fa37552927070cc8d8190907fd3b413e`, required lines 1–90, EOF 1248,
and empty assessed ranges. That selected row does not identify a reader. Its
original and reconstructed selected bytes match; this does not make the whole
queues identical. Its own-lens proof remained pending at the separately
examined `76fe53635e2bf1e3e08bbfaa364314f5e7888bf8` evidence checkpoint.

The separately recovered Root Lens 3 receipt records a personal 6533 read of
1–90. Later e275 receipts qualify same-lens reuse of 1–62 and 63–90 without a
fresh e275 personal reread. No such credit transfers to this independent Lens 1
read. We prospectively registered and personally displayed 6533 1–90, e275
1–62 and 63–90, pinned 95e 1–90, and 95e support 91–130. All three revisions
have this file's Git blob `578d143c62f51c6c96109758fecde7444e8aa28d` and
SHA-256 `8626aece6d47f2087249b45ecc70c2fc943b600943ac23e3a5eb3c7cbc55619b`.
The 6533 file also matches the archived original object byte-for-byte. This is
per-file equality only; the historical working snapshot had unrelated changes.
The older readings and this work are not checkpoint 3821 evidence.

## Typed timing producer boundary

`bot.rs:85–86` exposes a generic `f32` range producer. The numeric kernel
`crates/fabelgeist-determinism/src/stream.rs:90–94` checks finite ordered
bounds and computes a `f32` interpolation. Tactical defense reaction bounds
are held as `AnimationElapsed` in
`crates/adventuresim-tactical-core/src/combat_config.rs:333–337`; the config
validation at 532–541 checks their order. The checked elapsed constructor at
`crates/adventuresim-core/src/elapsed.rs:24–35` requires finite, nonnegative
seconds. These safeguards apply when the selected construction and validation
paths actually run; other public construction paths were not exhaustively read.

In `bot/defense.rs:230–243`, the selected ordinary reaction branch extracts
seconds from the typed bounds, samples a raw `f32`, then readmits the result
through `AnimationElapsed::from_seconds` before creating a native timer. Its
special guaranteed-dodge branch is distinct. The melee and ranged recovery
branches at `bot/offense/phase.rs:329–353` likewise sample raw seconds and
readmit the result before typed addition and native timers. At
`bot/offense/tactics.rs:3–12`, initiative sampling is followed by an additional
instinct scaling operation before the checked elapsed constructor; it is not an
immediate reconstruction. These selected paths expose a connected Lens 1
producer-to-retained-state question: should a checked elapsed sampler own the
application-level input and output type while retaining the numeric kernel?

Any future repair proposal must preserve the actual draw count and ordering,
`f32` rounding, bounds, scaling, error order, and the distinct non-time callers.
We did not prove whether an appropriate typed owner already exists elsewhere,
select an implementation layer, or establish that a supported input fails.
The raw numeric interpolation itself is a legitimate numerical boundary, not a
defect merely because it uses `f32`. Historical q662 and its separately
attributed current determinism assessment concern a conditional extreme
opposite-sign finite-bound interpolation overflow. That first question differs
from the typed elapsed migration; reach and any alias remain open. The selected
spawn-coordinate use at `player_projection/spawn_admission.rs:69–74` samples
-5 to 5, and is not that extreme-bound witness.

## Unit samples and retained state

`fabelgeist-determinism/src/lib.rs:17–19` derives a half-open unit sample;
`bot.rs:77–78` exposes it as `f32`. `combat/contact.rs:52–56,59–88` obtains
two separate draws. `combat/ingress/attack_start.rs:14–29,90–108,215–245`
passes them to retained pending contact; `combat/protocol.rs:35–45,58–65`
contains the raw fields. The selected due-contact branch
`combat/ingress.rs:274–303` forwards them when the target and body part exist.
`combat/melee.rs:182–216,340–341,416–426,440–450` and
`combat/melee/active_defense.rs:56–74` consume them in numeric selection.

Whether a suitable owner can preserve the distinct samples and the half-open
interval through internal state is an open design question. A closed unit
interval accepting 1 would not establish the same contract. Other producers,
consumers, admissions, and scheduling remain outside these bounded reads. A
numeric sink is not itself proof of an error, and the two draws must not be
merged. No automatic alias or additional defect count is proposed.

## Fixture and mission path safeguards

The selected producer `bot.rs:44–61` resolves the optional roster fixture and
uses its enemy count. `main.rs:66–89,119–120,168–175` passes the resulting
count to `mission/mod.rs:30–57`, and `mission/systems.rs:234–245` reads it for
a snapshot. The mission check in `mission/mod.rs:165–202` is a separate
selected consumer; all paths and correspondence to the actual enemy roster
remain open. Without a fixture, the CLI value is retained. The normal loaded
fixture path `tactical_fixture.rs:48–80,87–101` validates nonempty and the
`threat_escalation.rs:18` cap of 30 before converting the length. This guard
is conditional on that validated load path, and direct derived deserialization
is not equivalent to it.

Existing 76fe ledger rows 378 and 379 already record, respectively, the direct
deserialization admission issue and the production count `expect`; the
validated 1–30 path makes that conversion safe. Ledger 377 and original q1688
address the separate always-Ok path helper and the real parser boundary.
Original q3134 addresses zero-grace mission enrollment. Its original status
field is absent; the 76fe wrapper presents null. These records are related by
selected ownership paths, not established aliases. The bounded reads do not
prove a malformed fixture, oversized roster, public requester, or observed
mission failure. Existing rows 380 and 381 concern other AI config admissions.

## Evidence and unresolved work

The private receipt lists 52 individually registered and displayed windows,
including selected test and fixture source *as text only*. Whole source blobs
and Git objects establish identities; they do not confer full-file reading.
Historical original and reconstructed selected records q662, q1688, q3100,
and q3134 are captured, while complete source streams remain separately held.
The first locator's broad metadata output and a later history projection were
truncated; an exact selected capture and later complete projection correct the
latter. An initial dictionary projection rendered a missing q3134 status as
null; a subsequent membership check established it was absent. Locator hits in
`bot.rs:350–390` and `combat/ingress.rs:600–645` include test-source context;
the separately registered production ingress view is 270–310. No test ran.

Open questions include selected config validation and supported caller reach,
the correct application-level time and sample owners, preservation of the
native numerical contract, other retained-state admissions and readers, and
policy for zero or mismatched mission counts. No assertion of global source,
queue, ledger, alias, or lens completeness follows from this packet.
