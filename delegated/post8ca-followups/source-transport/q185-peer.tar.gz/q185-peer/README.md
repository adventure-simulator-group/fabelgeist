# q185 independent peer evidence

Read the independent REPORT.md together with both separately attributed
author reports in q185-public-v1 and q185-public-v2. The latter corrects the
approval fallthrough wording and preserves the original.

Run `python3 -B VERIFY.py` for public identities. `--private` also checks the
restricted source and historical proofs. Supply all of `--author-private`,
`--queue-private` and `--extraction` with `--private` to compare prior author
records, both complete queue streams and the original read-only extraction.
These are evidence-only checks. Full originals are separately held on the same
machine; this transport alone does not provide independent durable custody or
product validation.
