#!/usr/bin/env python3
"""Read-only public and optional separately held evidence verification."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,stat,subprocess,sys
if sys.flags.optimize:raise RuntimeError('unoptimized')
p=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();a=argparse.ArgumentParser();a.add_argument('--private',type=Path);a.add_argument('--author-private',type=Path);a.add_argument('--queue-private',type=Path);a.add_argument('--extraction',type=Path);z=a.parse_args();ext=[z.author_private,z.queue_private,z.extraction];assert all(ext) or not any(ext);assert z.private or not any(ext)
def check(root,manifest,excluded):
 e={x['path']:x for x in manifest['files']};assert len(e)==len(manifest['files']);files={};dirs={}
 for x in root.rglob('*'):
  assert not x.is_symlink();name=x.relative_to(root).as_posix()
  if x.is_dir():dirs[name]=oct(stat.S_IMODE(x.stat().st_mode))
  elif x.is_file() and name!=excluded:files[name]=x
 assert set(files)==set(e) and dirs=={x['path']:x['mode'] for x in manifest['directories']} and oct(stat.S_IMODE(root.stat().st_mode))==manifest['root_mode']
 for name,x in files.items():
  n=PurePosixPath(name);assert not n.is_absolute() and '..' not in n.parts;b=x.read_bytes();r=e[name];assert len(b)==r['bytes'] and H(b)==r['sha256'] and oct(stat.S_IMODE(x.stat().st_mode))==r['mode']
 return len(files)
m=json.loads((p/'MANIFEST.json').read_bytes());binding=json.loads((p/'PRIVATE-BINDING.json').read_bytes());result={'public_files':check(p,m,'MANIFEST.json'),'private_replay':'not requested','dependency_replay':'not requested'}
for tag,key in [('q185-public-v1','author_original_public_manifest_sha256'),('q185-public-v2','author_corrected_public_manifest_sha256')]:assert H((p/tag/'MANIFEST.json').read_bytes())==binding[key]
if z.private:
 q=z.private.resolve();raw=(q/'PRIVATE-MANIFEST.json').read_bytes();assert H(raw)==binding['private_manifest_sha256'];result['private_files']=check(q,json.loads(raw),'PRIVATE-MANIFEST.json');r=subprocess.run([sys.executable,'-B',str(q/'VERIFY-PRIVATE.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==0 and not r.stderr;result['private_replay']=json.loads(r.stdout)
 if all(ext):
  r=subprocess.run([sys.executable,'-B',str(q/'VERIFY-DEPENDENCIES.py'),'--author-private',str(z.author_private),'--queue-private',str(z.queue_private),'--extraction',str(z.extraction)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==0 and not r.stderr;result['dependency_replay']=json.loads(r.stdout)
print(json.dumps(result,sort_keys=True))
