# Independent q185 travel-planning peer review

The corrected q185 assessment is supported within the selected source scope.
This review independently read Lens 11 windows at product revision
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The original and corrected q185
reports were authored by `wrapped_scope`; their source credit is separate.
The original and its correction must be retained together. The evidence
checkpoint 76fe and the later publication checkout are not the product baseline.

## Approval correction and producer boundary

At `crates/strategic-web/src/routes/mod.rs:904–928`, if the request payload
fails to decode as the web `PartyAction`, the planned-call helper is skipped
and ordinary approval is requested. If decoding succeeds, `Ok(Some(...))`
selects planned approval; `Ok(None)` selects ordinary approval; and an `Err`
from the helper propagates through `?` before the ordinary call. The corrected
v2 report records these cases accurately. Ordinary approval then performs its
own native typed payload decode and kind check; this source does not prove that
a web decode failure necessarily passes or fails every native schema boundary.

On the selected leader path, `routes/mod.rs:291–299` similarly propagates a
helper error and selects `action.reducer_call` only for `Ok(None)`. Both travel
variants select unplanned reducer names in `routes/party_actions.rs:145–154`.
Case-site and settlement web handlers construct their respective actions at
`routes/quests.rs:360–376` and `routes/settlements/rest.rs:581–598`. These are
source paths, not proof that a request was authorized, accepted or committed.

The helper's `Result<Option<...>, String>` distinguishes outer errors from
absence, yet maps selected outbound and case-site return planner errors to
`Ok(None)` at `routes/mod.rs:626–657`. `routes/travel.rs:205–257` shows
separate queue timeout, closed permit, worker timeout or failure, native planning
error and cache-lock error paths. Their occurrence under supported inputs is
unproved. Other `Ok(None)` paths represent absent terrain, non-travel actions,
or no available origin. These are conditional: with terrain present, character
lookup and party terrain-profile work at `routes/mod.rs:524–533` precede the
non-travel match at 566 and can return an error before `Ok(None)`.

The Lens 11 question is whether an application-level result should preserve a
failed plan as a distinguishable outcome rather than selecting the same
fallback protocol as an unavailable or inapplicable plan. Historical q185
states a proposed required-plan contract; the source establishes its present
fallthrough, not that this policy has been decided or violated in live use.
No implementation or defect count is proposed.

## Planned and unplanned native boundaries

The web helper assembles a planned reducer name and a three-element argument
vector at `routes/mod.rs:661–673`; planned approval forwards its third element
at 904–919. Native `strategic/governance.rs:169–202` checks the gateway,
living leader, request, party leader and action kind before ordinary dispatch.
Its separately inspected planned approval at 216–257 applies leader and kind
checks and accepts only travel variants before passing `Some(route)` to the
matching travel implementation. The source includes further checks and state
writes; neither path proves transaction completion.

The case-site native entry points at `strategic/travel_reducers.rs:1–19` pass
`None` or `Some(route)` to the same implementation. After its independent
party, location and route checks, its no-route branch at 247–273 computes a
straight-line route; the helper at 51–127 constructs a reversed return leg.
Settlement entry points at 471–491 likewise pass optional routes, but the
settlement implementation's road connectivity, coordinate and location checks
at 530–655 are distinct. A missing plan therefore does not establish native
acceptance, equal route geometry, or a completed journey for either variant.

## Historical provenance and relationships

The selected original and reconstructed q185 bytes match (SHA-256
`2b02990f66dc1e1f8bca7ccc51d3607b01b0aece3220e169c6e448b8c8ccd147`). The
original states `open-reconciliation`; the 76fe wrapper says `unassessed`.
Its recorded source revision, Git path and attribution fields are null and its
queue scope credit is zero; these fields are not filled by later inferences.
The separate Adler Lens 11 receipt 382 records fresh source reads of missions
1–340 and routes/mod 1–930. Receipt 382 and registrations 1237, 1238 and 1239
match the user-supplied extraction exactly. The 1239 registration qualifies an
overshooting 1238 request ending at 935 to actual EOF 930, before any such
out-of-range body read; 931–935 were not read or credited. The selected queue
metadata does not name an individual historical reader.

The two recorded source hashes independently match the Git file objects at
6533, e275 and 95e. This establishes per-file identity only, not identical
working trees, a recorded queue revision, a named reader, or credit at
checkpoint 3821. My personally displayed 95e windows and the earlier reviewer's
reads are separately registered and attributed.

Original q186 addresses route-progress multiplication, a different first
operation. 76fe ledger 442 concerns road inference's handling of terrain
errors. Rows 798–802 correspond to q521–q525 and record separate Lens 12
planner error/cause classifications. Each of the seven selected original and
reconstructed queue pairs checked here has identical selected bytes; no whole
queue equality, global alias or count follows. Those relationships belong to
central reconciliation and do not transfer a source reading or close a lens.

## Limits and process qualifications

Actual planner error reach, optional terrain and fallback policy, authority of
all callers, transaction behavior, and any externally visible outcome remain
open. Exact source displays total 17 registered windows; full Git blobs are
identity evidence only. Two windows include test source as text; no test or
fixture was executed. No build, product execution, runtime probe or repair was
performed.

My first prospective source registration failed before any product-source
display because the planned 875–940 view exceeded actual EOF 930. The failed
script and traceback are retained, then 875–930 was freshly registered and
displayed. The first history-capture attempt failed after creating an empty
output directory because the author manifest used a mapping rather than a
list; the exact script and an explicitly abbreviated failure transcript are
retained, followed by a successful corrected capture. One early prior-author
path locator was displayed as metadata before a separate locator registration;
it earns no source credit. Some historical metadata projections were
intentionally bounded or clipped, while the exact underlying records remain in
the restricted packet. Display completion is this reviewer's attestation.
