#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import argparse,hashlib,json
p=Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--private-manifest',type=Path);a.add_argument('--replay-manifest',type=Path);a.add_argument('--correction-manifest',type=Path);a.add_argument('--correction-replay-manifest',type=Path);a.add_argument('--predecessor-manifest',type=Path);a.add_argument('--original-report',type=Path);args=a.parse_args();h=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'MANIFEST.json').read_bytes());assert m['schema']=='726-q185-public-manifest-v2' and set(m['files'])=={'REPORT.md','BINDING.json','RECORDED-REPLAY.json','CORRECTION.json','CORRECTION-REPLAY.json','VERIFY.py','PUBLIC-SCAN.json'} and {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,r in m['files'].items():
 assert len(PurePosixPath(n).parts)==1;f=p/n;assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),h(b))==(r['bytes'],r['sha256'])
x=json.loads((p/'BINDING.json').read_bytes());c=json.loads((p/'CORRECTION.json').read_bytes());assert x['schema']=='726-q185-public-binding-v2' and x['queue_index']==185 and x['lens']==11 and h((p/'REPORT.md').read_bytes())==c['successor_report_sha256'];checks=['public members and corrected report']
for value,key,label in ((args.private_manifest,'private_manifest_sha256','private manifest'),(args.replay_manifest,'replay_manifest_sha256','replay manifest'),(args.correction_manifest,'correction_manifest_sha256','correction manifest'),(args.correction_replay_manifest,'correction_replay_manifest_sha256','correction replay manifest'),(args.predecessor_manifest,'predecessor_public_manifest_sha256','predecessor manifest')):
 if value is not None:assert h(value.read_bytes())==x[key];checks.append(label)
if args.original_report is not None:
 b=args.original_report.read_bytes();assert h(b)==c['predecessor_report_sha256'] and b.count(c['old'].encode())==1 and b.replace(c['old'].encode(),c['new'].encode())==(p/'REPORT.md').read_bytes();checks.append('exact report replacement')
print(json.dumps({'checks':checks,'qualification':'Public identities and optional supplied anchors only. Full source replay requires separately held restricted evidence and Git objects.'}))
