# q185: planned travel failure and fallback protocol

This is an independently attributed, bounded Lens 11 source assessment at
`95e63628f9d70b8dd6e6fede64334696c6995009` (tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`), not an assessment of the whole
lens or a queue closure. It considers the selected travel-action producer,
planner result, dispatch, and native reducer boundaries only. It does not
establish runtime reachability, transaction results, or a defect count.

The reconstructed q185 row and selected original 059 row are byte-identical
for this record (SHA-256
`2b02990f66dc1e1f8bca7ccc51d3607b01b0aece3220e169c6e448b8c8ccd147`). Its
historical status is `open-reconciliation`; the 76fe reconciliation says
`unassessed`. Its recorded `pr-working` source identities have null revision,
Git-path and attribution fields and zero queue body credit. The separate,
hash-verified Adler Lens 11 receipt 382 records personal fresh ranges for
source indices 2369 and 2370, with registrations 1237 and 1239. The latter
qualifies the raw 1238 request for lines 1–935 to the actual 930-line EOF;
lines 931–935 were not read or credited. No individual reader name is supplied
by the queue metadata. These are recovered historical records, not checkpoint
3821 evidence. The selected source files have equal per-file Git blobs at
6533, e2755a732c84e67296b5e3441a4259a84f461b2f, and 95e, matching the
historical source hashes; that does not equate the trees or supply a missing
historical revision/reader. The reconstructed queue as a whole is not asserted
to match the original.

Selected current findings:

* The case-site handler constructs `PartyAction::TravelToCaseSite`
  (`crates/strategic-web/src/routes/quests.rs:360–376`); the settlement handler
  constructs `TravelToSettlement` (`routes/settlements/rest.rs:581–598`).
  They pass actions to the shared executor; authorization, live input and
  successful execution are not established by those static call sites.
* `routes/mod.rs:516–567,589–610` returns `Ok(None)` for absent terrain,
  non-travel actions and an unavailable origin, while other lookup errors can
  propagate. For an eligible action reaching the planner, outbound failure or
  a case-site return-plan failure is logged and also becomes `Ok(None)`
  (`:626–657`). This conflates a failed planning attempt with distinct
  no-planned-call states, despite the outer `Result` being capable of carrying
  an error. The planner itself returns `Result<RoutePlan, String>` and selected
  errors include cache, permit, timeout, worker and native-plan failures
  (`routes/travel.rs:205–257`); source inspection does not establish which
  errors occur in supported use. Even the second cache lock can fail after the
  native plan was produced.
* With all earlier lookup/readiness steps successful and the actor on the
  leader branch, `routes/mod.rs:291–299` dispatches the planned call if present
  and otherwise calls `PartyAction::reducer_call`; the two travel variants map
  to the unplanned reducer names (`routes/party_actions.rs:145–154`). The
  nonleader action is first requested (`routes/mod.rs:301–316`); on approval,
  successful decoding and `Ok(Some(...))` select planned approval. Decode
  failure or `Ok(None)` selects ordinary approval; a propagated helper error
  returns early (`:904–928`). The ordinary
  native approval checks leader and typed action kind before executing it
  (`strategic/governance.rs:169–202`), and the typed dispatch calls the
  unplanned travel reducers (`strategic/approved_action.rs:99–110`). These
  branches are distinct; none establishes a committed journey.
* For case-site travel the two native entry points pass `None` or `Some(route)`
  to the same implementation (`strategic/travel_reducers.rs:1–19`); subject
  to its independent checks, the no-route case calculates straight-line
  distance and constructs a route with a reversed return leg
  (`:51–127,130–160,247–285`). For settlement travel, `:471–491,550–582`
  shows separate planned/unplanned entry points and native road/coordinate
  checks, with additional case-site and zero-distance conditions at
  `:584–655`. An unplanned request is therefore not automatically admitted,
  and the two native destinations must not be treated as identical.

Historical and current relationships remain separate. Reconstructed q186
concerns route-progress multiplication rather than this planner-to-protocol
selection. Existing 76fe ledger row 442 concerns a different road-inference
terrain-error operation. Rows 798–802 retain Lens 12 planner error/cause
questions and their original historical identities (q521–q525); they identify
adjacent error producers, not proven aliases, and their earlier readers receive
no credit for this independent Lens 11 read. The broader relationship and any
connected repair-ledger decision belong to the central reconciliation.

Open questions include the supported presence or absence of terrain; actual
reachable planner errors versus no-route, package and resource failures; the
intended policy for failed required plans and case-site return plans; the
selected producer and approval authorization paths in a live deployment; and
native transaction/committed-state behavior. Candidate later acceptance should
separately cover outbound failure, return failure, no terrain, no applicable
travel plan, successful plan, and both direct/approved action paths, while
retaining native admission constraints. No repair, build, test, fixture or
runtime probe was performed.

Evidence limits: historical registrations and receipt are recovered exact
bytes; the selected original and reconstructed rows are preserved, and
source windows were personally displayed after registration. Display completion
is the reviewer's attestation rather than independent telemetry. The first
metadata command failed because `python` was unavailable before any read; the
exact tool output was visible but not separately captured. Two broad metadata
list displays were truncated, with their complete generated JSON retained; a
later bounded historical metadata print intentionally sliced a nested object.
No product-source view was claimed from those metadata displays. The abbreviated
`e275` Git lookup failed as ambiguous; the explicit commit comparison above
is separate and does not repair the historical null attribution. Full replay
requires the separately held publication Git objects and Python/Git; public
metadata alone cannot recover private originals. This assessment does not
upgrade missing checkpoint 3821 or assert whole-tree equivalence.
