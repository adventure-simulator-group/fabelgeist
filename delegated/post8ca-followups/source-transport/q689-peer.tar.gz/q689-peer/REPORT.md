# Independent q689 producer-propagation review

Reviewer: `/root/mhr_character`. The source review being checked was authored
by `/root/verifier_scope`. This review is bounded to the questions below at
`95e63628f9d70b8dd6e6fede64334696c6995009`, tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. It supports the author's
conditional source description, with the active-work and cumulative-factor
clarifications below. It does not adopt a unique defect count, settle a policy,
close q689 or infer product behavior.

The commitment source constructs one 0.5-second `AnimationElapsed` for the
work call at `commitment.rs:142–157` and another for nonempty attempted defense
at `:159–170`. These are distinct producers with different downstream roles.
The work function constructs its duration before matching `None`, but the
`None` branch charges no work. The readiness producer returns early on `None`.
For the selected readiness path, an effective shield block during a committed
attack requires a positive shield bonus and produces zero added recovery
(`:171–181`). Neutral-guard dodge retains the duration, while neutral-guard
block or parry returns zero (`:183–192`); the remaining branch retains it
(`:194–204`). The caller adds it to contact time, takes the maximum with
previous readiness, and writes the result only for a non-`None` response
(`melee_round/mod.rs:207–251`). Checked time addition can return an error
(`battle_time.rs:23–48`).

For selected block or parry, `charge_action_work` passes the original elapsed
span into `combat_action_workload` (`autoresolve.rs:249–266`). Its energy
calculation clamps the seconds to the configured minimum and maximum
(`fatigue.rs:24–46`), whereas the active-work field is updated to
`max(previous_active_work, original_span)` (`autoresolve.rs:260–266`): it sees
0.5 seconds but may retain a larger prior value. If the displayed authored YAML
and build projection are the ones actually used, the 0.1–0.35-second bounds
make the selected 0.5-second weapon-work energy use 0.35 seconds. The dodge
branch computes its mechanical energy from moved mass and configured speed,
not from the clamped duration (`fatigue.rs:34–54`). The clamp expression is
still evaluated before that branch. This is source-level reasoning; no build or
runtime configuration was observed. The selected projection validates fatigue
values and emits its embedded fields (`combat_resolution.rs:92–113,175–180,
259–274`; `fatigue_config.rs:22–44`).

For a nonempty attempt with an effective shield block, positive shield bonus,
and committed-attack phase, `commitment.rs:165–180` multiplies the stored
attack-power multiplier by `clamp(1 - 0.4 * clamp(effectiveness, 0, 1), 0.2,
1)`. For finite effectiveness, the individual factor is approximately
0.6–1.0, so its 0.2 lower bound is not reached. That lower clamp applies to each
factor, not to the accumulated field. Conditional on four such multiplications
at effectiveness 1 before the selected reset, the ideal product is about
0.1296, below 0.2; floating-point rounding does not change that comparison.
The selected exchange takes and resets the stored field at
`melee_round/mod.rs:357–373` and applies the taken value at `:427–450`.
Whether the scheduler permits that sequence, whether inputs satisfy those
conditions, and whether this result is intended or observable remain open.
Non-finite inputs and other writers/readers were not exhaustively traced.

The complete inspected `combat.yaml:1–346` and selected core build projection
`combat_resolution.rs:1–275` have no named fields for these exact work,
readiness or retained-factor roles. The YAML's `armed_attack_energy_transfer`
and `melee_reflex_window_seconds` are separately named roles; matching numeric
values alone do not identify a shared owner. Other configuration paths and
native tactical consumers are outside this review. Governing current-session
core and tactical rules direct new combat tuning through authored configuration
and typed projections, but deciding whether and how these existing constants
must be migrated remains a policy and owner question.

The original and reconstructed 059 selected q689 and q677 bytes independently
match; their full streams have distinct identities. Both original records say
`open-evidence-or-disposition`. At the separately identified 76fe evidence
checkpoint both wrapper entries were unassessed. The q689 linked historical
receipt 010 and q677 receipt 008 name Root Segovb as the independent Lens 1
reader at e275. The former lists five linked files and the latter four; all nine
independently checked e275 blobs match their corresponding 95e file blobs and
recorded SHA-256 values. This is per-file equality only, not whole-tree identity
or transferred personal read credit. The related journal pointers are q689
`/segovb_continuation/lens1/pending_connected_contracts/50` and q677
`/segovb_continuation/lens1/pending_connected_contracts/37`. Their relation is
an open reconciliation question, not an automatic alias.

Independently checked 76fe ledger rows 70 and 71 concern ranged attack and
ranged defense fatigue; row 77 concerns empty-hand attack workload. They share
fatigue context but have different stated first operations. No global alias or
count follows. The author's proof-metadata successor correctly labels 76fe as
an evidence checkpoint; the original, correction and prior failures remain
separately attributed. No old material becomes checkpoint 3821 evidence.

This reviewer displayed 19 personally preregistered current source windows:
16 initial and three later registered build-projection complements. Full bodies
and raw Git objects were retained for identity, not credited as full reads.
`melee_round/mod.rs:454–465` is test source within a registered window and was
read as text only, never run. Unread ranges and external/native consumers remain
open. The initial historical metadata check used mismatched octal text formats
before copying evidence; a corrected numeric comparison passed. An initial
battle-time path lookup failed before source display and was prospectively
corrected. Rule and skill texts were displayed before their evidence captures,
but before any product-source display. Exact receipts and limited proofs are in
the restricted packet. No build, test, fixture, shader, probe or repair ran.
