#!/usr/bin/env python3
"""Read-only public, optional private and prior-author evidence verification."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,stat,subprocess,sys
if sys.flags.optimize:raise RuntimeError('unoptimized interpreter required')
P=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();a=argparse.ArgumentParser();a.add_argument('--private',type=Path);a.add_argument('--author-private',type=Path);q=a.parse_args();assert q.private or not q.author_private
def check(root,manifest,exclude):
 rows=manifest['files'];names=[r['path'] for r in rows];assert len(names)==len(set(names));actual=set();dirs={}
 for z in root.rglob('*'):
  assert not z.is_symlink();rel=z.relative_to(root).as_posix()
  if z.is_file() and rel!=exclude:actual.add(rel)
  elif z.is_dir():dirs[rel]=oct(stat.S_IMODE(z.stat().st_mode))
 assert actual==set(names)
 for r in rows:
  rel=PurePosixPath(r['path']);assert not rel.is_absolute() and '..' not in rel.parts;z=root.joinpath(*rel.parts);b=z.read_bytes();assert (len(b),H(b),stat.S_IMODE(z.stat().st_mode))==(r['bytes'],r['sha256'],int(r['mode'],8))
 if 'directories' in manifest:assert dirs=={x['path']:x['mode'] for x in manifest['directories']}
 if 'root_mode' in manifest:assert stat.S_IMODE(root.stat().st_mode)==int(manifest['root_mode'],8)
 return len(rows)
manifest=json.loads((P/'MANIFEST.json').read_bytes());pub=check(P,manifest,'MANIFEST.json');binding=json.loads((P/'PRIVATE-BINDING.json').read_bytes());result={'public_files':pub,'private_replay':'not requested','complete_stream_replay':'not requested'}
if q.private:
 root=q.private.resolve();raw=(root/'PRIVATE-MANIFEST.json').read_bytes();assert H(raw)==binding['private_manifest_sha256'];result['private_files']=check(root,json.loads(raw),'PRIVATE-MANIFEST.json');r=subprocess.run([sys.executable,'-B',str(root/'VERIFY-PRIVATE.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==0 and not r.stderr;result['private_replay']=json.loads(r.stdout)
 if q.author_private:
  r=subprocess.run([sys.executable,'-B',str(root/'VERIFY-AUTHOR-DEPENDENCY.py'),'--author-private',str(q.author_private)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert r.returncode==0 and not r.stderr;result['complete_stream_replay']=json.loads(r.stdout)
print(json.dumps(result,sort_keys=True))
