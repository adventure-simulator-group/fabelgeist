#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,stat,sys
if sys.flags.optimize:raise SystemExit('optimized Python is not supported')
p=argparse.ArgumentParser();p.add_argument('--public',required=True,type=pathlib.Path);a=p.parse_args();r=pathlib.Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_bytes());actual=set()
for x in r.rglob('*'):
 if x.is_symlink():raise SystemExit('symlink')
 if x.is_file() and x.relative_to(r).as_posix()!='MANIFEST.json':actual.add(x.relative_to(r).as_posix())
rows=m['files'];names=[x['path'] for x in rows]
if len(names)!=len(set(names)) or set(names)!=actual:raise SystemExit('file set')
for row in rows:
 rel=pathlib.PurePosixPath(row['path'])
 if rel.is_absolute() or '..' in rel.parts:raise SystemExit('unsafe path')
 f=r.joinpath(*rel.parts);data=f.read_bytes()
 if (len(data),hashlib.sha256(data).hexdigest(),format(stat.S_IMODE(f.stat().st_mode),'04o'))!=(row['bytes'],row['sha256'],row['mode']):raise SystemExit('file identity')
if format(stat.S_IMODE(r.stat().st_mode),'04o')!=m['root_mode']:raise SystemExit('root mode')
receipt=json.loads((r/'REPLAY.json').read_bytes())
if hashlib.sha256((a.public/'MANIFEST.json').read_bytes()).hexdigest()!=receipt['public_manifest_sha256']:raise SystemExit('public manifest identity')
print(json.dumps({'receipt_files_checked':len(rows),'public_manifest_bound':True},sort_keys=True))
