'''Prospective bounded current-source support registration only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/adventuresim-character-creator/src/hair/shape.rs',[[1,235]]),('crates/adventuresim-character-creator/src/hair/groom.rs',[[1,150]]),('crates/fabelgeist-hair/src/hairdo.rs',[[100,185],[280,325],[410,445]]),('crates/fabelgeist-hair/src/gpu/guides.rs',[[100,160]]),('crates/fabelgeist-hair/src/look.rs',[[300,325],[440,470]])];a=[]
for i,(path,ranges) in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);ranges=[[x,min(y,eof)] for x,y in ranges if x<=eof];a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Current bounded support only, no historical or ordered-role credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest());print([(x['path'],x['eof'],x['prospective_ranges']) for x in a])
