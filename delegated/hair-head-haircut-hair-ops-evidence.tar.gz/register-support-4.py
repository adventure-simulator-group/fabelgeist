'''Prospectively register bounded interpolation helpers; source text only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[('crates/fabelgeist-hair/src/gpu/wgsl/common.rs',[[112,132]]),('crates/fabelgeist-hair/src/ops/mod.rs',[[190,205]])];a=[]
for i,(path,ranges) in enumerate(paths,9):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':len(b.splitlines()),'saved':saved,'prospective_ranges':ranges,'qualification':'Current bounded support only. Earlier own role 2301 read remains separate; no shader execution.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-4.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-4.json').read_bytes()).hexdigest())
