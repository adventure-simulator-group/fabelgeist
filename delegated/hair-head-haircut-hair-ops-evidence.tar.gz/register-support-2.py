'''Prospective bounded GPU host/native-text support registration; no execution.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/fabelgeist-hair/src/gpu/guides.rs',[[240,285]]),('crates/fabelgeist-hair/src/gpu/guides/packed.rs',[[1,85]]),('crates/fabelgeist-hair/src/gpu/wgsl/guides.rs',[[470,510],[775,870]])];a=[]
for i,(path,ranges) in enumerate(paths,5):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);ranges=[[x,min(y,eof)] for x,y in ranges if x<=eof];a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Bounded current host/native shader source text only; no historical/ordered credit or shader compilation.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-2.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-2.json').read_bytes()).hexdigest());print([(x['path'],x['eof'],x['prospective_ranges']) for x in a])
