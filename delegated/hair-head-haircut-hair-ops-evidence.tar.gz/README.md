# Bounded head and haircut source audit

Author: `/root/hair_ops`. Original registry roles 2637–2638. Working revision:
`95e63628f9d70b8dd6e6fede64334696c6995009`. Historical objects are the
registered `pr-working` sources individually equal to
`6533e444fa37552927070cc8d8190907fd3b413e`; the containing historical
snapshot had unrelated changes. `f82adcabd9d89c4fa2dd7f99253a45297a0681ee`
is source transport, not their revision. Old and current bodies were
displayed independently after registration. The 6533 copies were compared,
not separately displayed. Inline test source was inspected only.

`REPORT.json` gives thirteen bounded perspectives, source-backed observations,
conditions, historical relationships and open questions. Registration and
support registration files, `read-receipt.json`, and `git-proofs.json` retain
exact bytes, prospective scopes, actual displays and Git membership.
`historical-manifest.json` lists exact original 059 receipts and hash-linked
prior evidence; selected 059 queue rows are reconstructed selections, not
checkpoint3821. Rig, Segovb and `/root/lens12_frontier` have separately
attributed historical ranges. The original complete F067 body is not supplied
here; rig's additional record references it. `MANIFEST.json` hashes each
packet file.

Run `python3 verify-evidence.py` solely for evidence-integrity verification;
it reads hash-linked evidence dependencies and does not run or validate
product code. The guide-length and scale questions need supported-producer,
policy and alias review before any repair. No rendering, shader execution,
product execution, tests, builds, or probes were performed.
