import gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;pub='<LOCAL_PATH_0>';native='<LOCAL_PATH_1>';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records=[];seen=set()
def add(kind,repo,rev,path,archive,sha,blob,**extra):
 k=(rev,path)
 if k in seen:return
 seen.add(k);records.append(dict(kind=kind,repo=repo,revision=rev,path=path,archive=archive,sha256=sha,blob=blob,**extra))
for e in json.loads((p/'registration.json').read_bytes())['entries']:
 if e['label']=='historical':add('original native source object via f82','project',f82,e['transport_path'],e['archive'],e['sha256'],e['git_blob'])
 else:add('native Git source path','native',e['native_revision'],e['native_path'],e['archive'],e['sha256'],e['git_blob'])
for rf in ['support-registration.json','support2-registration.json']:
 for e in json.loads((p/rf).read_bytes())['entries']:add('bounded '+e['kind']+' support','native' if e['kind']=='native-git' else 'project',e['revision'],e['path'],e['archive'],e['sha256'],e['git_blob'])
for e in json.loads((p/'lock-inventory-registration.json').read_bytes())['entries']:add('project lock structural inventory','project',e['revision'],e['path'],e['archive'],e['sha256'],e['git_blob'])
for e in json.loads((p/'historical-index.json').read_bytes())['records']:
 if e['kind']=='historical-774':add('original 774 native record via f82','project',f82,e['transport_path'],e['file'],e['sha256'],e['git_blob'],encoding='gzip')
(p/'git-objects').mkdir(exist_ok=True);objs={};proof=[]
def data(t,oid,repo):
 b=subprocess.check_output(['git','-C',native if repo=='native' else pub,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objs:
  dst=p/'git-objects'/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objs[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in records:
 commit=data('commit',x['revision'],x['repo']);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(data('tree',tree,x['repo']))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (hashlib.sha256(b).hexdigest(),oid,tree)==(x['sha256'],x['blob'],x['blob']);proof.append(dict(x,commit_tree=root,chain=chain))
(p/'git-proofs.json').write_text(json.dumps({'objects':objs,'proofs':proof,'qualification':'1a5 proofs are native dependency Git, f82 proofs are historical transport, and 6533/95e proofs are project Git; never equate their revisions or transfer earlier reviewers coverage.'},indent=2)+'\n');print('proofs',len(proof),'objects',len(objs))
