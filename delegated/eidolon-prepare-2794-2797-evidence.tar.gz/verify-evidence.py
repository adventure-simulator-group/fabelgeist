import datetime,gzip,hashlib,json,pathlib,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);sid='pinned-native-git-1a5aff8d4809287e5f5713fb4cf72181b2285fff';assert sid not in {x['id'] for x in registry['snapshots']};assert all(registry['files'][i]['snapshot']==sid for i in range(2794,2798));trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue);sel=load('queue-selection-reconstructed.json');assert all(q['entries'][int(k)]==v for k,v in sel['entries'].items());sel=load('registry-selection-reconstructed.json');assert all(registry['files'][int(k)]==v for k,v in sel['roles'].items()) and sel['snapshot_rows']==registry['snapshots']
for n in ['reference-index.json','rules.json','skills.json']:
 for e in load(n)['records']:
  b=(p/e['file']).read_bytes();assert sha(b)==e['sha256'],e['file']
groups=[('assigned','registration.json','personal-read-receipt.json'),('support','support-registration.json','support-read-receipt.json'),('support2','support2-registration.json','support2-read-receipt.json')]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'] and blob(body)==a['git_blob'];assert len(body.splitlines())==a['EOF'] and a['archive']==b['archive'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[name]=len(r['entries'])
reg=load('registration.json')
for e in reg['entries']:
 row=registry['files'][e['original_index']];assert (e['source_id'],e['snapshot'],e['sha256'],e['EOF'],e['original_material_ranges'])==(row['source_id'],row['snapshot'],row['sha256'],row['actual_line_count'],row['material_ranges'])
for i in range(2794,2798):assert (p/f'source/{i}-historical.rs').read_bytes()==(p/f'source/{i}-native-git.rs').read_bytes()
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
hist=p/'history-059/segovb'
for batch in [455,456]:
 receipt=json.loads((hist/f'READ-L11-{batch}.json').read_bytes());state=json.loads((hist/f'STATE-L11-{batch}.json').read_bytes());verification=json.loads((hist/f'VERIFY-L11-{batch}.json').read_bytes());assert receipt['current_reconciled'] is False and receipt['accepted_unique_count_change']==0 and state['accepted_unique_count_change']==0 and verification['gate'] is False;assert state['receipt_sha256']==sha((hist/f'READ-L11-{batch}.json').read_bytes())==verification['receipt_sha256'];assert verification['state_sha256']==sha((hist/f'STATE-L11-{batch}.json').read_bytes())
 for role,num in ([(2794,1714),(2795,1715),(2796,1716)] if batch==455 else [(2797,1717)]):
  f=hist/f'REGISTRATION-SEGOVB-{num}.json';x=json.loads(f.read_bytes());src=[s for s in receipt['sources'] if s['original_index']==role];assert len(src)==1 and src[0]['registration_sha256']==sha(f.read_bytes()) and src[0]['assessed_ranges']==src[0]['fresh_personal_body_reads']==x['ranges']==registry['files'][role]['material_ranges'] and x['sha256']==registry['files'][role]['sha256'] and x['prospective']
assert json.loads((hist/'STATE-L11-456.json').read_bytes())['predecessor_sha256']==sha((hist/'STATE-L11-455.json').read_bytes())
rp=p/'history-774/native/initial05-aggregate-states';rows=[json.loads(l) for l in gzip.decompress((rp/'source-range-registration.jsonl.gz').read_bytes()).splitlines()];group=json.loads(gzip.decompress((rp/'contract-groups-071.json.gz').read_bytes()));assert group['id']=='NATIVE-INITIAL05-GROUP-071' and group['new_unique_findings']==[]
for role,k in zip(range(2794,2798),range(18,22)):
 row=registry['files'][role];assert rows[k-1]==row['scope_registration'][0]['original_record'];member=next(x for x in group['source_members'] if x['source_id']==row['source_id']);assert member['sha256']==row['sha256'] and member['scoped_ranges_compared']==row['material_ranges']
prior=(p/'prior-2790-2793/MANIFEST.json').read_bytes();assert sha(prior)=='3200c59749bee4c8b027f9072a358369f08c504a302395a9883b75b0e7f40a5b';pm={x['path']:x for x in json.loads(prior)['files']}
for e in load('prior-index.json')['selected_files']:
 b=(p/'prior-2790-2793'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(pm[e['path']]['bytes'],pm[e['path']]['sha256'])
previous=load('prior-2790-2793/REPORT.json');assert previous['author']=='/root/rig_identity' and sha((p/'prior-2790-2793/REPORT.json').read_bytes())=='2a47746580d55d7cf84861e2e83e30af90ff61fa2e8ee609c190beda5e8ab654';oldrec=load('prior-2790-2793/support-read-receipt.json');assert oldrec['author']=='/root/rig_identity' and datetime.datetime.fromisoformat(oldrec['at_utc'])<datetime.datetime.fromisoformat(reg['registered_utc']);prevprepare=next(e for e in oldrec['entries'] if e['id']=='native-prepare');assert prevprepare['unread_complement']==[[106,226]] and prevprepare['actual_display_chunks']==[[1,35],[36,70],[71,105],[227,260],[261,300],[301,340]]
for rr in oldrec['registrations']:
 f=p/'prior-2790-2793'/rr['path'];assert sha(f.read_bytes())==rr['sha256'] and datetime.datetime.fromisoformat(rr['at_utc'])<datetime.datetime.fromisoformat(oldrec['at_utc'])
li=load('lock-inventory-registration.json');lr=load('lock-inventory.json');assert lr['registration_sha256']==sha((p/'lock-inventory-registration.json').read_bytes()) and datetime.datetime.fromisoformat(lr['completed_utc'])>datetime.datetime.fromisoformat(li['registered_utc']);assert len(li['entries'])==len(lr['entries'])==2
for a,b in zip(li['entries'],lr['entries']):
 body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'] and blob(body)==a['git_blob'];ps=tomllib.loads(body.decode())['package'];matches=[{'name':x['name'],'version':x['version'],'source':x.get('source'),'checksum':x.get('checksum')} for x in ps if x['name']=='bevy_eidolon'];consumers=[x['name'] for x in ps if any(d.split()[0]=='bevy_eidolon' for d in x.get('dependencies',[]))];assert (len(ps),matches,consumers)==(b['package_count'],b['matches'],b['direct_lock_consumers'])
assert len(lr['entries'][0]['matches'])==1 and lr['entries'][0]['matches'][0]['source'].endswith('#1a5aff8d4809287e5f5713fb4cf72181b2285fff') and lr['entries'][1]['matches']==[]
sr=load('search-registration.json');so=load('search-results.json');assert so['registration_sha256']==sha((p/'search-registration.json').read_bytes()) and datetime.datetime.fromisoformat(so['completed_utc'])>datetime.datetime.fromisoformat(sr['registered_utc']);x=so['results'][0];tree=(p/x['tracked_tree_listing']).read_bytes();assert sha(tree)==x['tracked_tree_sha256'] and len(tree.split(b'\0'))-1==x['tracked_tree_entries'] and x['exit_code']==1 and x['matching_paths']==[]
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==28
report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13 and len(load('read-scope-summary.json')['scopes'])==len(groups)
print(json.dumps({'status':'pass','scope':'Offline 059/774 provenance, original and native source receipts/read complements, 1a5/f82/6533/95e raw Git path proofs, selected earlier reviewer evidence, root-lock metadata and recorded bounded search integrity; no product validation','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'prior_selected_files':len(load('prior-index.json')['selected_files']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
