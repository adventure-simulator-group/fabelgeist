# Bounded bevy_eidolon evidence: roles 2794–2797

This packet records a static source review by `/root/mhr_character` of four
native source roles. `report.json` contains thirteen bounded perspectives,
conditional observations, historical relationships and open questions. No
whole native package, lens or audit completion is claimed.

All four recovered original objects match native Git source paths at
`1a5aff8d4809287e5f5713fb4cf72181b2285fff`; the `f82...` commit transports
the historical objects and records. It is not the native commit or the
project revision. The original registry's pinned-native snapshot label is
preserved even though it has no corresponding snapshot-list row. Original
774 native and 059 segovb reviewer registrations and receipts remain separately
attributed.

The 6533 root lock names this native Git dependency; the 95e root lock metadata
inventory does not. A separate literal search found no Eidolon token within
95e's tracked root Cargo files and `crates/`, but cannot rule out aliases,
indirect mechanisms or paths outside that search. Current chunk-instancing
sources are transition context, not proof that the historical native code runs
in the current renderer. Lock and manifest metadata do not establish effective
features, target choices, device capability or actual runtime behavior.

The author independently registered and displayed both recovered and native
Git versions in full at 2794 lines 1–152, 2795 lines 1–118, 2796 lines 1–47
and 2797 lines 1–47. `read-scope-summary.json` preserves exact support reads and
unread complements; archived bytes outside those ranges are not read credit.
Some native `id_allocator` tests appear as source text only and were not run.
The earlier `/root/rig_identity` packet remains separately attributed. Its
frozen receipt records native `prepare/mod.rs` support at 1–105 and 227–340,
with 106–226 unread; this packet includes a manifest-verified subset of that
prior evidence, not the complete prior packet.

`python3 verify-evidence.py` checks source and read receipts, original 059/774
records, raw Git commit/tree path proofs, root-lock inventories and earlier
reviewer hashes. `python3 verify-manifest.py` checks all packet members,
including the nested prior manifest. These are evidence integrity checks, not
product validation. No source, renderer, shader, fixture, test, macro, build,
product or runtime probe was executed. The original checkpoint 3821 queue and
ledger remain unrecovered; historical records are not promoted into it.
