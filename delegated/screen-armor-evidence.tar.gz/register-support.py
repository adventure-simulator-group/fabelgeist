from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';specs=[('anime-old',old,'crates/fabelgeist-armor/src/anime_design.rs',[[1,56]]),('anime-current',cur,'crates/fabelgeist-armor/src/anime_design.rs',[[1,56]]),('armor-design',cur,'crates/fabelgeist-armor/src/design.rs',[[1,24]]),('breastplate-design',cur,'crates/fabelgeist-armor/src/breastplate_design.rs',[[1,125]]),('icon',cur,'crates/adventuresim-weapon-model/src/icon.rs',[[1,60],[125,175]]),('icon-render',cur,'crates/adventuresim-weapon-model/src/icon/render.rs',[[1,115]])];rows=[]
for name,rev,path,rs in specs:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path]);eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in rs);archive='support/'+name+'.rs';(b/archive).write_bytes(raw);chunks=[]
 for a,z in rs:
  for s in range(a,z+1,65):chunks.append([s,min(s+64,z)])
 blob=subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+path]).decode().strip();rows.append({'revision':rev,'path':path,'archive':archive,'sha256':sha(raw),'bytes':len(raw),'git_blob':blob,'actual_eof':eof,'registered_ranges':rs,'planned_chunks':chunks,'qualification':'Independent bounded support only; no original-role credit or previous authorship transfer.'})
x={'schema':'726-screen-armor-support-prospective-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows};raw=(json.dumps(x,indent=2)+'\n').encode();(b/'support-registration.json').write_bytes(raw);print('sha256',sha(raw));print([(x['archive'],x['registered_ranges'],x['planned_chunks']) for x in rows])
