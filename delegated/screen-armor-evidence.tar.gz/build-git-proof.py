from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',repo,*args])
objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);tree=c.splitlines()[0].split()[1].decode();commits[rev]={'root_tree':tree,'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 raw=(b/body).read_bytes();raw=gzip.decompress(raw) if body.endswith('.gz') else raw;cur=root(rev);chain=[]
 for segment in path.split('/'):
  mode,child=entries(save('tree',cur))[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
rows=json.load(open(b/'registration.json'))['entries']
for e in rows:
 proof(e['revision'],e['path'],e['archive'],'Assigned role: historical pr-working per-file 6533 identity or pinned 95e source')
 if e['transport_path']:proof('f82adcabd9d89c4fa2dd7f99253a45297a0681ee',e['transport_path'],e['archive'],'Original source object in historical transport f82; not product revision')
for e in json.load(open(b/'support-registration.json'))['entries']:
 proof(e['revision'],e['path'],e['archive'],'Separately registered bounded supporting source, no ordered credit')
for e in json.load(open(b/'historical-attribution.json'))['records_774']:
 proof(e['transport_revision'],e['transport_path'],e['preserved_gzip'],'Original 774 findings file; f82 archival transport')
r={'schema':'726-screen-armor-git-proof-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Raw commit/tree proofs bind exact path objects; 6533 per-file equality is not a claim the whole pr-working snapshot was clean.'};(b/'git-proofs.json').write_text(json.dumps(r,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects))
