from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).parent;p='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';specs=[('navigation-icon.txt','screen::|occupied_bounds|raw_coordinates|relative_screen|IconBounds|IconError|rasterize_icon',['crates/adventuresim-weapon-model/src/icon.rs','crates/adventuresim-weapon-model/src/icon']),('navigation-armor.txt','struct (Millimeters|BreastplateDesign|AnimeDesign)|enum BreastplateConstruction|wall_thickness|lap_lift|impl Default for (AnimeDesign|BreastplateDesign)|fn validate\\(' ,['crates/fabelgeist-armor/src/anime_design.rs','crates/fabelgeist-armor/src/design.rs','crates/fabelgeist-armor/src/breastplate_design.rs']),('navigation-resolve.txt','fn resolve|Vec::with_capacity|alpha.push|rgba.push|for y in 0..|for x in 0..',['crates/adventuresim-weapon-model/src/icon/render.rs'])];out=[]
for name,pattern,paths in specs:
 raw=subprocess.check_output(['git','-C',p,'grep','-n','-E',pattern,rev,'--',*paths]);(b/name).write_bytes(raw);out.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'pattern':pattern,'searched_paths':paths,'revision':rev,'qualification':'Matching singleton source lines only; navigation does not count as a contiguous body read.'})
roots=[]
for path in ['crates/AGENTS.md','crates/fabelgeist-armor/AGENTS.md']:
 raw=Path('<LOCAL_PATH_1>',path).read_bytes();git=subprocess.check_output(['git','-C',p,'show',rev+':'+path]);assert raw==git;roots.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'workspace_bytes_equal_pinned':True,'qualification':'Applicable rules personally read. Armor modeling workflow is not invoked for source-only review; user prohibits product validation.'})
(b/'navigation-and-rules.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'navigation':out,'rules':roots},indent=2)+'\n');print('navigation',len(out),'rules',len(roots))
