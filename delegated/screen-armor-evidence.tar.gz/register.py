from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');g=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);sha=lambda x:hashlib.sha256(x).hexdigest();reg=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';prefix='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/';entries=[]
for i in (2605,2606):
 row=reg['files'][i];path=row['source_id'].split(':',1)[1];oldraw=g('show',f82+':'+prefix+row['sha256']);base=g('show',old+':'+path);now=g('show',cur+':'+path);assert oldraw==base and sha(oldraw)==row['sha256'] and len(oldraw)==row['bytes'] and len(oldraw.splitlines())==row['actual_line_count']
 snap=next(x for x in reg['snapshots'] if x['id']=='pr-working');assert len(snap['status_porcelain'])==4 and not any(x[3:]==path for x in snap['status_porcelain'])
 for tag,rev,data in [('historical',old,oldraw),('current',cur,now)]:
  name=f'sources/{i}-{tag}.rs';(b/name).write_bytes(data);end=len(data.splitlines());ranges=row['material_ranges'] if tag=='historical' else [[1,end]];chunks=[]
  for lo,hi in ranges:
   for v in range(lo,hi+1,70): chunks.append([v,min(v+69,hi)])
  entries.append({'role':i,'revision':rev,'snapshot':'pr-working individual file' if tag=='historical' else 'pinned current project','path':path,'archive':name,'sha256':sha(data),'bytes':len(data),'git_blob':g('rev-parse',rev+':'+path).decode().strip(),'actual_eof':end,'registered_ranges':ranges,'planned_chunks':chunks,'original_registry_ranges':row['material_ranges'] if tag=='historical' else None,'transport_path':prefix+row['sha256'] if tag=='historical' else None})
x={'schema':'726-screen-armor-prospective-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':entries,'qualification':'Original pr-working per-file bytes match 6533 and recorded 774 transport; entire original snapshot had four other modifications. Current source checked independently; original armor role excludes historical 1–85. No product execution.'};raw=(json.dumps(x,indent=2)+'\n').encode();(b/'registration.json').write_bytes(raw);print('registration sha256',sha(raw));print([(x['role'],x['revision'][:7],x['sha256'],x['actual_eof'],x['registered_ranges'],x['planned_chunks']) for x in entries])
