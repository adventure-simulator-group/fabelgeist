# P16 armor and ordered-sigil source evidence

This packet records independent source-only assessment of historical original
physical-p16 roles 2818 and 2826 against project revision
95e63628f9d70b8dd6e6fede64334696c6995009. Both exact archived objects match
individual clean-base a120 and current Git paths, but the original P16 snapshot
was dirty. The reproduced tracked patch matches its historical hash and excludes
seven separately archived untracked paths. The f82 revision is an evidence
transport, not the product revision.

`report.json` records conditional findings and nonfindings, scoped perspectives
on thirteen lenses, history and open questions. `read-scope-summary.json`
reconstructs actual displays from separate prospective registration and receipt
files. Role 2818 source lines 79–205 and role 2826 historical lines 13–55 and
82–392 remain unread in the assigned role. Selected current extra windows were
independently registered as support. A previous pr-working armor role and a
previous puzzle support review remain separately attributed in `prior/`.

`history-059/` records match the recovered original transport manifest;
`history-774/` records are bound to f82 transport. The registry records earlier
registration-file hashes that differ from the transported complete JSONLs;
matching individual rows and the bounded prefix search are documented in
`registration-version-qualification.json`. Registry and queue selections are
reconstructed, and no checkpoint 3821 recovery is claimed.

`git-proofs.json` and `git-objects/` preserve raw commit and tree proofs. Run
`python3 verify-evidence.py` and `python3 verify-manifest.py` for offline
integrity checks only. No product execution, test, fixture, runtime probe or
repair is part of this packet. The central coordinator owns reconciliation,
ledger, publication and finding counts.
