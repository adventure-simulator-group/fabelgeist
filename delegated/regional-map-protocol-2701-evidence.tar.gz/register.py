from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
g=lambda *a: subprocess.check_output(['git','-C',repo,*a])
sha=lambda d: hashlib.sha256(d).hexdigest()
oid=lambda d: hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
current='95e63628f9d70b8dd6e6fede64334696c6995009'
old='6533e444fa37552927070cc8d8190907fd3b413e'
transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
path='crates/adventuresim-tactical-client/src/presentation/regional_map/protocol.rs'
expected='b38278c0ba58dc3340ed19e4e21d06e2fde33846e95cc58b804421f73366f024'
tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+expected
historical=g('show',old+':'+path)
assert sha(historical)==expected and historical==g('show',transport+':'+tp)
rows=[]
for kind,revision in [('pr_head',old),('current',current)]:
 raw=g('show',revision+':'+path); n=len(raw.splitlines()); dest='sources/2701-'+kind+'.rs'; (b/dest).write_bytes(raw)
 rows.append({'role':2701,'kind':kind,'revision':revision,'git_path':path,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'archive':dest,'prospective_personal_read_ranges':[[1,n]],'transport_revision':transport if kind=='pr_head' else None,'transport_path':tp if kind=='pr_head' else None,'qualification':'6533 per-file equals f82 recovered object; recorded pr-working tree had unrelated modifications, not a clean snapshot' if kind=='pr_head' else 'pinned current 95e independent full body read, not historical credit'})
out={'schema':'726-prospective-role-registration-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','reason':'independently display both assigned full bodies, retaining original role 2701 historical 1–126 and current changes separately','entries':rows,'no_product_execution':True}
(b/'registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
