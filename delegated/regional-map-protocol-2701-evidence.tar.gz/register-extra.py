from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
cur='95e63628f9d70b8dd6e6fede64334696c6995009';old='6533e444fa37552927070cc8d8190907fd3b413e'
items=[('old-canvas',old,'crates/adventuresim-tactical-client/src/strategic_scene/protocol.rs',[[1,68]]),('producer',cur,'crates/strategic-web/src/strategic_map/producer.rs',[[1,55],[125,155]]),('scene-owner',cur,'crates/strategic-web/static/strategic-scene.js',[[70,110]]),('queue-boundary',cur,'crates/adventuresim-tactical-client/src/browser_runtime.rs',[[175,219]]),('wasm-boundary',cur,'crates/adventuresim-tactical-client/src/main.rs',[[210,235]])]
rows=[]
for name,rev,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);n=len(raw.splitlines());assert all(1<=a<=z<=n for a,z in ranges),(name,n)
 dest=f'support/{name}.source';(b/dest).write_bytes(raw)
 rows.append({'name':name,'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'eof':n,'prospective_personal_read_ranges':ranges,'role':'independent bounded support, no historical role or prior reviewer credit'})
out={'schema':'726-prospective-support-registration-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows}
(b/'extra-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
