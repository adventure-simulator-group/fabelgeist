from pathlib import Path
from datetime import datetime
import gzip,hashlib,json
b=Path(__file__).resolve().parent
sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes())
history=load('historical-attribution.json');report=load('REPORT.json');receipt=load('personal-read-receipt.json')
names=('registration.json','support-registration.json','extra-registration.json','camera-registration.json','camera-tail-registration.json','camera-end-registration.json')
groups={name:load(name) for name in names};allregs={(name,e['archive']):e for name,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('historical/registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('historical/transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';mi=json.loads(raw);idx={x['path']:x for x in mi['entries']}
selected=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in selected['rows']]==[1621,1622,2701]
for x in selected['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in selected['snapshots']:assert x in registry['snapshots']
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4 and pr['patch_sha256']=='dba7a85bb2105ccdf0587c4713fdc2a33b374600457f5c05e9c5f29d087193b1'
for name,r in groups.items():
 for x in r['entries']:
  d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
old,cur=groups['registration.json']['entries'];assert old['sha256']==registry['files'][2701]['sha256'] and old['eof']==126 and old['prospective_personal_read_ranges']==registry['files'][2701]['material_ranges']==[[1,126]] and cur['eof']==126
a=(b/old['archive']).read_text().splitlines();c=(b/cur['archive']).read_text().splitlines();assert [i+1 for i,(x,y) in enumerate(zip(a,c)) if x!=y]==[12]
queue=json.loads(gun('historical/baseline-059-queue.json.gz'))['entries'];q=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in q['entries']]==[553,636,1342,1343,1344,1345,1883]
for x in q['entries']:assert x['entry']==queue[x['original_index_zero_based']]
assert queue[1345]['contract_id']=='Q-L12-6693021d5a22a3fd2476' and 'same-source/home' in json.dumps(queue[1345])
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
adler=load('historical/059/adler/READ-L11-243.json');entry=next(x for x in adler['connected_reinspection'] if x['original_index']==2701);assert entry['fresh_reads']==[[1,126]] and entry['additional_original_frontier_credit']==0
seg=load('historical/059/segovb/READ-L11-440.json');entry=next(x for x in seg['sources'] if x['original_index']==2701);assert entry['fresh_personal_body_reads']==[] and entry['same_lens_prior']['entry']['fresh_reads']==[[1,126]]
l12=load('historical/059/segovb/READ-L12-511.json');assert all(next(x for x in l12['rows'] if x['original_index']==i)['fresh_personal_body_reads']==[[1,231]] for i in (1621,1622))
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
regs=[json.loads(z) for z in gun('historical/774/root/admission03/source-range-registration.jsonl.gz').splitlines()];norms={x['registration_id']:x for x in map(json.loads,gun('historical/774/root/admission03/source-qualifications-final-current.jsonl.gz').splitlines())}
for x in registry['files'][2701]['admission03_scope_observations']:
 assert regs[x['row_1based']-1]==x['original_record']
 for y in x['local_qualifications']:assert norms[y['registration_id']]==y
root=json.loads(gun('historical/774/root/admission03/map-capture-producers-073.json.gz'));assert root['id']=='ROOT-ADM-G073' and 'REG042 full126' in root['scope']
rig=json.loads(gun('historical/774/rig/admission03/dependency-qualification-116.json.gz'));assert 'no newRigbody/source registration' in rig['source_scope']
rigrows=[json.loads(z) for z in gun('historical/774/rig/admission03/contract-groups.jsonl.gz').splitlines()];assert next(x for x in rigrows if x['id']=='RIG-ADMISSION03-CONTRACT-756')['actual_source_ranges']==[[1,161]]
rr=[json.loads(z) for z in gun('historical/774/rig/admission03/root-support/contracts.jsonl.gz').splitlines()];assert next(x for x in rr if x['id']=='RIG-ROOT-ADM03-193')['actual_read_ranges']==[[1,231]]
prior=load('historical/prior-current-window.json');entry=next(x for x in prior['current_supporting_sources'] if x['path'].endswith('/regional_map/protocol.rs'));assert entry['sha256']==cur['sha256'] and entry['ranges']==[[1,126]]
prior=load('historical/strategic-scripts-REPORT.json');entry=next(x for x in prior['original_roles'] if x['original_role']==2421);assert entry['historical_sha256']==entry['current_sha256']==sha((b/'support/browser-view.source').read_bytes()) and entry['actual_personally_displayed_current_ranges']==entry['actual_personally_displayed_historical_ranges']==[[1,161]]
assert sha((b/'historical/strategic-scripts-REPORT.json').read_bytes())=='9f2df65e5818ca426dc152c3afb0d3867a8c839c0bf140616f1c40f2752adcb9' and sha((b/'historical/strategic-scripts-MANIFEST.json').read_bytes())=='24603d44db823794baac993ec55a8fa6066562ca5098144c0b8c1f1c2cd1b37b'
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==26
for x in proof['paths']:
 curtree=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==curtree and s['name']==name;mode,child=entries(objects[curtree])[name];assert mode==s['mode'] and child==s['object'];curtree=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==curtree
assert len(receipt['entries'])==len(allregs)==17;cover={}
for e in receipt['entries']:
 source=allregs[(e['registration'],e['archive'])];rr=groups[e['registration']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']) and e['sha256']==source['sha256'] and e['revision']==source['revision']
 chosen={i for a,z in e['actual_personal_display_chunks'] for i in range(a,z+1)};planned={i for a,z in source['prospective_personal_read_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert chosen==planned and chosen.isdisjoint(unread) and chosen|unread==set(range(1,source['eof']+1));cover.setdefault((e['archive'],e['revision']),set()).update(chosen)
assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   possible=[e for e in allregs.values() if e['archive']==x['archive'] and e['revision']==x['revision']];assert possible and x['sha256']==possible[0]['sha256'] and x['path']==possible[0]['git_path']
   assert all(set(range(a,z+1))<=cover[(x['archive'],x['revision'])] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','scope':'registered source identities, displayed chunks, precise historical attributions and Git proofs','registered_personal_read_scopes':len(receipt['entries']),'historical_059_records_manifest_matched':len(history['records_059']),'historical_774_records_git_path_proved':len(history['records_774']),'git_paths_proved':len(proof['paths']),'bounded_lenses':len(report['thirteen_lens_dispositions']),'historic_059_payload_git_path_proof':'payload commit absent from the inspected publication and two project object databases; exact records match original transport manifest','product_validation':'not performed'},indent=2))
