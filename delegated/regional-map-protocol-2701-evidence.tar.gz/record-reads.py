from pathlib import Path
from datetime import datetime,timezone
import json
b=Path(__file__).resolve().parent
chunks={
'sources/2701-pr_head.rs':[[1,64],[65,126]],'sources/2701-current.rs':[[1,64],[65,126]],
'support/receiver.source':[[1,70],[71,140],[141,210]],'support/canvas.source':[[1,77]],
'support/status.source':[[1,60],[61,120],[121,169]],'support/browser-view.source':[[1,55],[56,110],[111,161]],
'support/browser-environment.source':[[1,64],[65,128]],'support/browser-runtime.source':[[1,50],[51,100],[220,280]],
'support/map-owner.source':[[1,62],[63,124],[125,186],[187,245]],'support/old-canvas.source':[[1,68]],
'support/producer.source':[[1,55],[125,155]],'support/scene-owner.source':[[70,110]],
'support/queue-boundary.source':[[175,219]],'support/wasm-boundary.source':[[210,235]],
'support/camera.source':[[1,50],[51,85]]}
rows=[]
for reg in ['registration.json','support-registration.json','extra-registration.json','camera-registration.json','camera-tail-registration.json','camera-end-registration.json']:
 data=json.loads((b/reg).read_bytes())
 for e in data['entries']:
  c=({'camera-tail-registration.json':[[86,145]],'camera-end-registration.json':[[146,189]]}.get(reg) or chunks[e['archive']]);assert set(i for a,z in c for i in range(a,z+1))==set(i for a,z in e['prospective_personal_read_ranges'] for i in range(a,z+1))
  touched=set(i for a,z in c for i in range(a,z+1));unread=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in touched and start is None:start=i
   if start is not None and (i>e['eof'] or i in touched):unread.append([start,i-1]);start=None
  rows.append({'registration':reg,'registration_at_utc':data['at_utc'],'archive':e['archive'],'revision':e['revision'],'git_path':e['git_path'],'sha256':e['sha256'],'eof':e['eof'],'actual_personal_display_chunks':c,'unread_complement':unread,'reader':'/root/rig_identity','qualification':'source text displayed in bounded chunks after listed prospective registration; archived bytes and other reviewers do not grant additional reads'})
out={'schema':'726-personal-source-read-receipt-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows,'qualification':'Recording time is not a per-chunk display timestamp. Assigned 6533 and 95e bodies were displayed separately. No execution or other-lens/frontier/3821 transfer.'}
(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('entries',len(rows))
