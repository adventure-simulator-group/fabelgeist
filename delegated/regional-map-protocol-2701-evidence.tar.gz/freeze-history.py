from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
ex=Path('<LOCAL_PATH_1>')
sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def save(d,p):
 t=b/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(d);return {'preserved':p,'sha256':sha(d),'bytes':len(d)}
refs=[]
for src,dest,kind in [('recovered/original-registry-source-archive/registry.json.gz','historical/registry.json.gz','full original recovered registry'),('recovered/original-transport-manifest.json.gz','historical/transport-manifest.json.gz','original 059 transport manifest'),('ASSESSMENT-REGIONAL-MAP-WINDOW-95E.json','historical/prior-current-window.json','prior central bounded current trace; no inferred reader name'),('ASSESSMENT-REGIONAL-MAP-SURFACE-95E.json','historical/prior-current-surface.json','prior central conditional retained identity trace; no inferred reader name'),('ASSESSMENT-DELEGATED-RECONCILIATION-7-95E.json','historical/prior-delegated-reconciliation-7.json','prior reconciled cross-kind map identity and route questions'),('ASSESSMENT-DELEGATED-RECONCILIATION-8-95E.json','historical/prior-delegated-reconciliation-8.json','prior reconciled JS readiness question'),('ASSESSMENT-BROWSER-COMMAND-CANVAS-95E.json','historical/prior-browser-canvas.json','prior browser canvas/command trace')]:
 refs.append({'kind':kind,'original':src,**save((pub/src).read_bytes(),dest)})
for src,dest in [('baseline-059/queue.json','historical/baseline-059-queue.json.gz'),('baseline-059/ledger.json','historical/baseline-059-ledger.json.gz')]:
 raw=(pub/src).read_bytes();refs.append({'kind':'059 historical summary mechanically compressed; original status retained','original':src,'uncompressed_sha256':sha(raw),'uncompressed_bytes':len(raw),**save(gzip.compress(raw,mtime=0),dest)})
oldprior=Path('<LOCAL_PATH_2>')
for name in ('REPORT.json','MANIFEST.json'):
 raw=(oldprior/name).read_bytes();refs.append({'kind':'earlier /root/rig_identity strategic scripts packet record only, not entire earlier packet or new personal read credit','original':str(oldprior/name),**save(raw,'historical/strategic-scripts-'+name)})
registry=json.loads(gzip.decompress((b/'historical/registry.json.gz').read_bytes()));manifest=json.loads(gzip.decompress((b/'historical/transport-manifest.json.gz').read_bytes()));idx={x['path']:x for x in manifest['entries']}
queue=json.loads(gzip.decompress((b/'historical/baseline-059-queue.json.gz').read_bytes()))['entries']
(b/'registry-selection-reconstructed.json').write_text(json.dumps({'schema':'726-registry-selection-reconstruction-v1','qualification':'Selected original rows reconstructed standalone, not checkpoint3821','rows':[{'original_index':i,**registry['files'][i]} for i in (1621,1622,2701)],'snapshots':[x for x in registry['snapshots'] if x['id']=='pr-working']},indent=2)+'\n')
(b/'queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-queue-selection-reconstruction-v1','qualification':'Selected 059 entries reconstructed from preserved full historical summary; no 3821 promotion or alias claim','entries':[{'original_index_zero_based':i,'entry':queue[i]} for i in (553,636,1342,1343,1344,1345,1883)]},indent=2)+'\n')
paths=['adler/READ-L11-243.json','adler/REGISTRATION-ADLER-523.json','adler/STATE-L11-243.json','adler/VERIFY-L11-243.json','segovb/READ-L11-440.json','segovb/REGISTRATION-SEGOVB-1619.json','segovb/STATE-L11-440.json','segovb/VERIFY-L11-440.json','segovb/READ-L12-511.json','segovb/PLAN-L12-511.json','segovb/REGISTRATION-SEGOVB-L12-528.json','segovb/REGISTRATION-SEGOVB-L12-529.json','segovb/STATE-L12-511.json','segovb/VERIFY-L12-511.json']
records=[]
for p in paths:
 raw=(ex/p).read_bytes();m=idx[p];assert sha(raw)==m['sha256'] and len(raw)==m['bytes'] and oid(raw)==m['git_blob'];records.append({'original_path':p,'git_blob':m['git_blob'],**save(raw,'historical/059/'+p)})
transport='handoff/774/adler-original/audit/continuation/';revision='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';old=[]
for p in ['root/admission03/source-range-registration.jsonl','root/admission03/source-qualifications-final-current.jsonl','root/admission03/map-capture-producers-073.json','rig/admission03/dependency-reconciliation-113.json','rig/admission03/dependency-qualification-116.json','rig/admission03/contract-groups.jsonl','rig/admission03/root-support/contracts.jsonl']:
 raw=subprocess.check_output(['git','-C',str(pub),'show',revision+':'+transport+p]);old.append({'revision':revision,'transport_path':transport+p,'source_sha256':sha(raw),'source_bytes':len(raw),'git_blob':oid(raw),'encoding':'gzip',**save(gzip.compress(raw,mtime=0),'historical/774/'+p+'.gz')})
out={'schema':'726-regional-map-protocol-historical-attribution-v1','references':refs,'records_059':records,'records_774':old,'qualification':'Original full evidence bytes, histories and material ranges retained. Reconstructed selections are not original full records. 774 ROOT G073 fresh full126; Rig dependency-116 consumed Root G073 with no new Rig source credit, correcting prior 113 ViewRect shorthand. 059 Adler L11-243 fresh full126 with no then-ordered credit; SEGOVB L11-440 adopted same-lens proof without fresh reread. SEGOVB L12-511 independently read historical map mod 1–231 and surface 1–231, including strict no 232–240 qualification, not protocol role2701. No historic evidence is promoted to checkpoint3821.'}
(b/'historical-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('historical 059',len(records),'774',len(old),'prior refs',len(refs))
