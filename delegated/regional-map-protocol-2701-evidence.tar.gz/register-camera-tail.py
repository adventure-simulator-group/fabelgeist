from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;raw=(b/'support/camera.source').read_bytes();path='crates/adventuresim-tactical-client/src/presentation/regional_map/camera.rs';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
out={'schema':'726-prospective-support-registration-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':[{'name':'camera-tail','revision':rev,'git_path':path,'archive':'support/camera.source','sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'eof':len(raw.splitlines()),'prospective_personal_read_ranges':[[86,145]],'role':'additional current support; separate from earlier camera registration and from historical role'}]};(b/'camera-tail-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
