# Role 2701: regional map command protocol

This is a bounded source-only packet for central review. `REPORT.json` records
the assigned role, the thirteen scoped perspectives, prior relationships,
conditional observations and unanswered policies. `personal-read-receipt.json`
records the exact personally displayed source chunks and unread complements;
the full archived files themselves do not expand that credit. Registrations
were recorded before source displays. The test text within the canvas support
file was only read; no tests were run.

The registered `pr-working` historical body is the 4,052-byte 126-line source
matching both its original recovered f82 transport object and the 6533 project
file. The historical snapshot recorded unrelated modifications; the matching
file does not make the snapshot clean. The 95e file differs at its shared
`CanvasRect` import. Full path proofs and Git commit/tree bytes are under
`git-proofs.json` and `git-objects/`.

`historical/059/` preserves exact original receipt bytes matched to the full
recovered original transport manifest. Its payload commit is not present in
the three inspected project/publication object databases, so this packet does
not claim independent Git path proof for those receipts. `historical/774/`
contains original records at f82 with full Git path proofs. Full historical
registry, queue and ledger summaries are retained; the selected row files are
mechanical reconstructions, explicitly labeled, and are not checkpoint 3821.

Prior current and delegated assessments retain their original authors and
ranges. The earlier strategic-scripts report and manifest are included as
exact records; the rest of that prior packet is not duplicated or claimed as
part of this packet. No earlier historical or current read has been converted
to this delegate's read, another lens, or checkpoint 3821 credit.

Run the evidence-only integrity checks from this directory:

```
python3 verify-evidence.py
python3 verify-manifest.py
```

These checks examine archived bytes, hashes, paths, read scopes, historical
records and report citations. They do not build, run or validate the product.
The central agent owns the audit baseline, reconciliation, connected repair
ledger and publication. No implementation, product tests, runtime probes,
browser, renderer, simulation or product validation occurred in this packet.
