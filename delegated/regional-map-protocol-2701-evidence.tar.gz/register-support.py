from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[
('receiver','crates/adventuresim-tactical-client/src/presentation/regional_map/mod.rs',[[1,210]]),
('canvas','crates/adventuresim-tactical-client/src/presentation/canvas_view.rs',[[1,77]]),
('status','crates/adventuresim-tactical-client/src/presentation/regional_map/status.rs',[[1,169]]),
('browser-view','crates/strategic-web/static/regional-map-view.js',[[1,161]]),
('browser-environment','crates/strategic-web/static/regional-environment-request.js',[[1,128]]),
('browser-runtime','crates/adventuresim-tactical-client/src/browser_runtime.rs',[[1,100],[220,280]]),
('map-owner','crates/adventuresim-tactical-core/src/regional_map.rs',[[1,245]])]
out=[];(b/'support').mkdir(exist_ok=True)
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);n=len(raw.splitlines());assert all(1<=a<=z<=n for a,z in ranges),(path,n,ranges)
 dest=f'support/{name}.source';(b/dest).write_bytes(raw)
 out.append({'name':name,'revision':rev,'git_path':path,'archive':dest,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'eof':n,'prospective_personal_read_ranges':ranges,'role':'bounded support; no ordered role or previous reviewer credit'})
record={'schema':'726-prospective-support-registration-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out}
(b/'support-registration.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
