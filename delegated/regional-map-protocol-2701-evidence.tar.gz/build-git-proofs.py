from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',repo,*a])
objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
for x in json.loads((b/'registration.json').read_bytes())['entries']:
 proof(x['revision'],x['git_path'],x['archive'],x['qualification'])
 if x['kind']=='pr_head':proof(x['transport_revision'],x['transport_path'],x['archive'],'f82 transport of exact historical source object; 6533 comparison is per-file only')
for f in ('support-registration.json','extra-registration.json','camera-registration.json','camera-tail-registration.json','camera-end-registration.json'):
 for x in json.loads((b/f).read_bytes())['entries']:proof(x['revision'],x['git_path'],x['archive'],x['role'])
proof('6533e444fa37552927070cc8d8190907fd3b413e','crates/strategic-web/static/regional-map-view.js','support/browser-view.source','Earlier separately credited 6533 prior script source object equality proof; no new historical personal display')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(x['revision'],x['transport_path'],x['preserved'],'Exact 774 original record transported by f82; original authors retained')
out={'schema':'726-regional-map-protocol-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Git path membership proves per-file object identities. f82 is transport, never historical source commit. pr-working had unrelated changes; 059 local records are checked against its separately recovered transport manifest, not proven here as Git membership in unavailable payload commit 3378.'}
(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('paths',len(proofs),'objects',len(objects))
