# Bounded garment pose source evidence

`REPORT.json` records the `/root/hair_ops` source-only review of original role
2657, separately registered support, historical relationships and thirteen
partial perspectives. The packet is not whole-audit completion, a repair,
product validation or a substitute for the unrecovered checkpoint 3821.

`registration.json` prospectively registered separate pr-working and current
95e bodies; `support-registration*.json` separately registered current support.
`read-receipt.json` records actual displays and unread complements. Full saved
source bytes do not alone confer read credit. The historical pr-working,
6533, and current 95e source files are byte-identical; the pr-working snapshot
has unrelated modifications, so this is not a clean-tree claim.

`git-proofs.json` and `git-objects/` retain file membership proofs. `historical/`
preserves selected exact original 059 records, the full compressed 059 adoption
file, and explicitly reconstructed selections of its F088 value and selected
queue rows. The F088 selection retains the original 774 archive and record
references, but does not claim the full 774 findings archive was recovered.
`historical-manifest.json` hashes prior published evidence dependencies, and
`MANIFEST.json` fixes the packet bytes.

Run `python3 verify-evidence.py` for evidence-integrity verification only. It
checks source identities, actual read partitions, prior receipt relationships,
Git proofs, reconstructed selections and evidence hashes. No product, geometry,
solver, test, rendering, simulation or repair code is run.
