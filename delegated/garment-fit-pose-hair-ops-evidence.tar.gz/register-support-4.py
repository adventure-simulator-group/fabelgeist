'''Prospective additional constructor carrier window.'''
import datetime,hashlib,json
from pathlib import Path
p=Path('<LOCAL_PATH_0>');s=json.loads((p/'support-registration.json').read_bytes())['sources'][0].copy();s['prospective_ranges']=[[210,240]];s['qualification']='Fresh current carrier support; no earlier credit transferred.';o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':[s]};(p/'support-registration-4.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-4.json').read_bytes()).hexdigest())
