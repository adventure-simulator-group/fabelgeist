# P16 runtime equipment and deterministic unit conversions

This bounded packet covers original physical-p16 roles 2593 and 2594. Their
individual objects equal the a120 base files and 95e files, without implying a
clean P16 snapshot. The later recovered tracked patch and separately preserved
untracked files remain historical evidence, not checkpoint 3821 restoration.

Start with `REPORT.json`, the three prospective registrations and
`personal-read-receipt.json`. The original P16 role 2594 review excluded its
test tail; this delegate later read that source text separately without running
it. Current supporting windows and their unread complements are explicitly
partitioned. Search-only singleton exposures are recorded in
`navigation-exposures.json`; they are not body-read credit.

Original 059 and a 774 witness are preserved here. The original 774 registry
and contract records are hash-linked to the earlier losslessly preserved
packet; other published historical/current assessments are linked without
copying large archives. Existing reviewers and revisions retain their own
attribution, and reconstructed registry and queue selections are labeled.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` to verify
evidence identity, source scope, linked local packets and Git proofs. These
checks do not execute product code. No repair, build, test, asset generation,
render, runtime probe, simulation or product validation occurred. The thirteen
perspectives do not claim a complete lens.
