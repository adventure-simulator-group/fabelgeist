from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256((b/p).read_bytes()).hexdigest();names=['registration.json','support-registration.json','support2-registration.json']
def complement(n,r):
 used={i for a,z in r for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if (i>n or i in used) and start is not None:out.append([start,i-1]);start=None
 return out
reg=json.loads((b/names[0]).read_bytes());assigned=[]
for e in reg['entries']:
 assigned.append({'original_index':e['original_index'],'source_id':e['source_id'],'snapshot':e['snapshot'],'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'actual_eof':e['actual_EOF'],'displayed_ranges':[[1,e['actual_EOF']]],'display_chunks':e['planned_chunks'],'unread_ranges':[],'original_material_ranges':e['original_material_ranges'],'original_historical_excluded_tail':complement(e['actual_EOF'],e['original_material_ranges']) if e['original_material_ranges'] else None,'source_archive':e['source_archive'],'qualification':'Personally displayed this historical or current role body in separate bounded chunks. Tests source tails viewed as text only, never executed. Historical byte equality is not whole-tree clean credit.'})
support=[]
for name in names[1:]:
 for e in json.loads((b/name).read_bytes())['sources']:
  ranges=e['registered_ranges'];chunks=e.get('planned_chunks',ranges)
  support.append({'registration':name,'path':e['path'],'revision':e['revision'],'source_archive':e['source_archive'],'sha256':e['sha256'],'actual_eof':e['actual_EOF'],'displayed_ranges':ranges,'display_chunks':chunks,'unread_ranges_for_this_registration':complement(e['actual_EOF'],ranges),'qualification':'Separately registered current support; complements are registration-specific and may be covered by another support registration.'})
r={'schema':'726-p16-runtime-determinism-personal-read-receipt-v1','reader':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registrations':[{'path':p,'sha256':sha(p)} for p in names],'assigned_personal_reads':assigned,'support_personal_reads':support,'qualification':'Actual source displays only. Registrations precede display; archived source outside declared displays is not claimed read. Original 774 and 059 readers retain their own ranges and attribution.'}
(b/'personal-read-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('assigned',len(assigned),'support',len(support))
