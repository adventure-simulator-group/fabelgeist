from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,sys
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda p:json.loads((b/p).read_bytes());reg=load('registration.json');rr=load('personal-read-receipt.json');at=load('historical-attribution.json');gp=load('git-proofs.json');rep=load('REPORT.json');links=load('evidence-links.json');r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));snap=next(x for x in r['snapshots'] if x['id']=='physical-p16');assert snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and len(snap['status_porcelain'])==159 and sha((pub/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes())==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for i in (2593,2594):
 row=r['files'][i];old=next(e for e in reg['entries'] if e['original_index']==i and e['transport_path']);cur=next(e for e in reg['entries'] if e['original_index']==i and not e['transport_path']);a=(b/old['source_archive']).read_bytes();c=(b/cur['source_archive']).read_bytes();assert a==c and sha(a)==row['sha256']==old['sha256']==cur['sha256'] and len(a)==row['bytes'] and len(a.splitlines())==row['actual_line_count'] and not any(s[3:]==old['path'] for s in snap['status_porcelain']);assert any(p['revision']==old['revision'] and p['path']==old['path'] and p['sha256']==sha(a) for p in gp['paths']) and any(p['revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' and p['path']==old['transport_path'] and p['sha256']==sha(a) for p in gp['paths']);assert any(p['revision']==cur['revision'] and p['path']==cur['path'] and p['sha256']==sha(c) for p in gp['paths'])
for e in links['published']:
 raw=(pub/e['path']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],e['path']
for e in links['prior_packet_records']:
 raw=Path(e['path']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],e['path']
prior=Path('<LOCAL_PATH_1>');sr=(prior/'historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl').read_text().splitlines();entries=[json.loads(line) for line in sr];assert any(e.get('id')=='RIG-ADMISSION03-REGISTER-027' and e.get('sha256')==r['files'][2593]['sha256'] for e in entries);assert any(e.get('id')=='RIG-ADMISSION03-REGISTER-033' and e.get('sha256')==r['files'][2594]['sha256'] for e in entries)
m=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));mi={e['path']:e for e in m['entries']};assert not at['missing']
for e in at['059']:
 raw=(b/e['preserved_bytes']).read_bytes();x=mi[e['original_path']];assert len(raw)==e['bytes']==x['bytes'] and sha(raw)==e['sha256']==x['sha256'] and oid('blob',raw)==e['git_blob']==x['git_blob']
for e in at['774']:
 raw=(b/e['preserved_bytes']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
def tree_entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
objects={}
for key,e in gp['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,c in gp['commits'].items():assert objects[rev].splitlines()[0]==b'tree '+c['root_tree'].encode()
for p in gp['paths']:
 raw=(b/p['preserved_bytes']).read_bytes();raw=gzip.decompress(raw) if p['preserved_bytes'].endswith('.gz') else raw;assert sha(raw)==p['sha256'] and len(raw)==p['bytes'] and oid('blob',raw)==p['git_blob'];cur=gp['commits'][p['revision']]['root_tree'];assert [v['name'] for v in p['path_chain']]==p['path'].split('/')
 for step in p['path_chain']:
  assert step['tree']==cur and tree_entries(objects[cur])[step['name']]==(step['mode'],step['object']);cur=step['object']
 assert cur==p['git_blob']
for v in rr['registrations']:
 assert sha((b/v['path']).read_bytes())==v['sha256'] and datetime.fromisoformat(json.loads((b/v['path']).read_bytes())['registered_utc'])<datetime.fromisoformat(rr['recorded_utc'])
reads=rr['assigned_personal_reads']+rr['support_personal_reads']
for e in reads:
 raw=(b/e['source_archive']).read_bytes();assert sha(raw)==e['sha256'] and len(raw.splitlines())==e['actual_eof'];assert all(1<=a<=z<=e['actual_eof'] for a,z in e['display_chunks']);assert all(any(a<=c<=d<=z for a,z in e['displayed_ranges']) for c,d in e['display_chunks'])
for e in load('navigation-exposures.json')['entries']:assert sha((b/e['path']).read_bytes())==e['sha256']
def walk(x):
 if isinstance(x,dict):
  if 'source_archive' in x and 'range' in x:
   a,z=x['range'];assert sha((b/x['source_archive']).read_bytes())==x['sha256'];covered={i for e in reads if e['source_archive']==x['source_archive'] for u,v in e['displayed_ranges'] for i in range(u,v+1)};assert all(i in covered for i in range(a,z+1)),x
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(rep);assert len(rep['lens_perspectives'])==len({e['lens'] for e in rep['lens_perspectives']})==13;q=load('queue-selection-reconstructed.json');assert not q['missing'] and {e['original_index_zero_based'] for e in q['entries']}=={61,646,662,2482}
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','checks':['Registry and P16 dirty/base/patch distinctions','Both assigned per-file current and historical identities','Personal registered chunks, support unread complements and citation coverage','059 recovered bytes against original transport manifest and 774 witness','Exact 774 register/contract hash links and prior manifest','Published hash links and raw offline Git membership','Navigation singleton exposures and thirteen bounded perspectives'],'limits':'No independent proof of personal reading, feature or runtime behavior, complete consumers, uninterrupted historical custody or whole-lens completion; no product validation.'}
if '--record' in sys.argv:(b/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: evidence, provenance, Git proof and read partitions; no product execution')
