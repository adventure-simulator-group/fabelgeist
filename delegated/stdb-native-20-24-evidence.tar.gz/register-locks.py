from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;prev=json.loads((b/'lock-registration.json').read_bytes());es=[]
for x in prev['entries']:
 raw=(b/x['archive']).read_bytes();assert hashlib.sha256(raw).hexdigest()==x['sha256'];es.append({'id':x['id'],'revision':x['revision'],'git_path':x['git_path'],'archive':x['archive'],'sha256':x['sha256'],'bytes':len(raw),'qualification':'Reused original lock bytes and prior registration; prospective structural TOML inventory only, not body-read or feature-resolution claim.'})
(b/'stdb-lock-registration.json').write_text(json.dumps({'schema':'726-stdb-lock-inventory-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'prior_registration_sha256':hashlib.sha256((b/'lock-registration.json').read_bytes()).hexdigest(),'entries':es},indent=2)+'\n')
