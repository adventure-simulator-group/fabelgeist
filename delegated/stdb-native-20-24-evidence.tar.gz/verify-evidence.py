from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tomllib,tarfile
b=Path(__file__).parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');report=load('REPORT.json')
for x in hist['references']:
 if 'preserved' in x:
  d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
  if 'uncompressed_sha256' in x:assert sha(gzip.decompress(d))==x['uncompressed_sha256']
 if 'preserved_report_manifest' in x:
  r=x['preserved_report_manifest'];manifest=json.loads((b/r['MANIFEST.json']['preserved']).read_bytes())
  for n,z in r.items():
   d=(b/z['preserved']).read_bytes();assert len(d)==z['bytes'] and sha(d)==z['sha256']
  assert next(z for z in manifest['files'] if z['path']=='REPORT.json')['sha256']==r['REPORT.json']['sha256']
registry=json.loads(gun('history/original-registry.json.gz'));assert sha(gun('history/original-registry.json.gz'))=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';assert sha(gun('history/original-transport-manifest.json.gz'))=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858'
roles=[20,21,22,23,24];sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==roles+[491,495,2477]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
checks={'spacetimedb':'b6eff5017248ff2e35e03564df947fdf3e963f7198be6ae1d9e894c2efb2ea15','spacetimedb-bindings-macro':'fce86c7657dcb42a33ce55f0100f98964dc15b64e79f06803a478676b74d6c82','spacetimedb-sats':'6cefb87b7d5e760d43cb65855591e25af772bdcca19562e5796ae797240d1998','spacetimedb-sdk':'074a6d8828638176eb8e9bba7a3e6fb75dc659b260717306eb966c7e10575cd7'}
for n,h in checks.items():assert sha((b/f'packages/{n}-2.6.1.crate').read_bytes())==h
names=['registration.json','support-registration.json','support-registration-2.json'];groups={n:load(n) for n in names};regs={(n,str(e['id'])):e for n,r in groups.items() for e in r['entries']}
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
 if name=='registration.json' or x.get('repo_kind')=='crate-archive':
  with tarfile.open(b/x['package_archive']) as tar:assert tar.extractfile(x['member_path']).read()==d
for i in roles:
 x=regs[('registration.json',str(i))];r=registry['files'][i];assert x['original_source_id']==r['source_id'] and x['sha256']==r['sha256'] and x['package_checksum']==checks[x['package']] and x['original_owner_contract_proofs']==r.get('owner_contract_proofs',[])
assert len({registry['files'][i]['source_id'] for i in [23,495,2477]})==3 and len({registry['files'][i]['sha256'] for i in [23,495,2477]})==1
assert registry['files'][24]['source_id']!=registry['files'][491]['source_id'] and registry['files'][24]['sha256']==registry['files'][491]['sha256']
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];selection=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in selection['entries']]==list(range(732,740))+[2105]
for x in selection['entries']:assert x['entry']==q[x['original_index_zero_based']]
r=load('history/059/segovb/READ-L11-474.json');row=next(x for x in r['rows'] if x['overlay_index']==107);assert r['new_original_role_credit']==0 and row['fresh_personal_body_reads']==[] and row['reused_ranges']==[[560,628],[703,712],[1290,1308]]
r=load('history/059/segovb/READ-L11-411.json');assert r['fresh_bounded_windows']['1376']==[[1,195]] and r['fresh_bounded_windows']['1381']==[[196,201]]
for n in ['1376','1381']:
 e=next(x for x in r['sources'] if x['registration'].endswith(f'REGISTRATION-SEGOVB-{n}.json'));assert sha((b/f'history/059/segovb/REGISTRATION-SEGOVB-{n}.json').read_bytes())==e['registration_sha256']
r=load('history/059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-839-TIMESTAMP-NATIVE-TAIL.json');e=r['rows'][0];assert e['original_index']==2477 and e['fresh_personal_body_reads']==[[196,343]] and '/root/lens12_frontier' in e['attribution'] and e['new_original_credit']==0 and sha((b/'history/059/parallel-l12-20261029/REGISTRATION-PAR-L12-491.json').read_bytes())==e['registration_sha256']
for n in ['020','021']:
 r=load(f'history/059/root-l1-current-e275-20261029/READ-ROOT-L1-CURRENT-{n}.json');assert sha((b/f'history/059/root-l1-current-e275-20261029/REGISTRATION-ROOT-L1-CURRENT-{n}.json').read_bytes())==r['registration_sha256'];assert all(x.get('current_product_lock_revision','e2755a732c84e67296b5e3441a4259a84f461b2f')=='e2755a732c84e67296b5e3441a4259a84f461b2f' for x in r['rows'])
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
for who in ['native','camera','root']:
 a=[json.loads(z) for z in gun(f'history/774/{who}-owner-redacted.jsonl.gz').splitlines()];c=[json.loads(z) for z in gun(f'history/774/{who}-owner-original-paths.jsonl.gz').splitlines()];assert sha(gun(f'history/774/{who}-owner-redacted.jsonl.gz'))!=sha(gun(f'history/774/{who}-owner-original-paths.jsonl.gz'))
 for x in [v for v in hist['selected_supplier_variant_comparisons'] if v['supplier']==who]:
  r=registry['files'][x['role']];proof=r['owner_contract_proofs'][0];j=proof['row'];u,v=a[j],c[j];assert j==x['registry_row_zero_based'] and j+1==x['physical_line_1based'];assert u['source_id']==v['source_id']==r['source_id'] and u.get('observed_sha256',u.get('sha256'))==v.get('observed_sha256',v.get('sha256'))==r['sha256'] and u['read_ranges']==v['read_ranges']==proof['read_ranges'];assert sorted(k for k in set(u)|set(v) if u.get(k)!=v.get(k))==x['different_top_level_keys'];assert u.get('source_read_status')==x['supplier_source_read_status'] and u.get('read_status')==x['supplier_read_status'] and proof.get('read_status')==x['registry_read_status']
for i in [20,21,22]:
 r=registry['files'][i];assert r['owner_contract_proofs'][0]['read_status'] is None;x=next(x for x in hist['selected_supplier_variant_comparisons'] if x['role']==i);assert x['supplier_source_read_status'] is not None
adm=[json.loads(z) for z in gun('history/774/native-admission-coverage.jsonl.gz').splitlines()]
for role,no in [(20,13),(21,14),(22,15),(23,16),(24,17)]:
 x=next(x for x in adm if x.get('id')==f'NATIVE-ADMISSION03-SOURCE-{no:03d}');assert x['source_id']==registry['files'][role]['source_id'] and x['sha256']==registry['files'][role]['sha256']
x=next(x for x in adm if x.get('id')=='NATIVE-ADMISSION03-SOURCE-013');assert [560,655] in x['read_ranges'] and [703,712] in x['read_ranges'] and [1228,1308] in x['read_ranges']
g=json.loads(gun('history/774/native-aggregate-067.json.gz'))
for i in [20,21,22]:
 m=next(x for x in g['source_members'] if x['source_id']==registry['files'][i]['source_id']);assert m['scoped_ranges_compared']==registry['files'][i]['owner_contract_proofs'][0]['read_ranges']
cam=[json.loads(z) for z in gun('history/774/camera-redundant-contracts.jsonl.gz').splitlines()];assert all(any(x.get('id')==i for x in cam) for i in ['CAMERA-INITIAL07-CONTRACT-007','CAMERA-INITIAL07-CONTRACT-008'])
prior=hist['prior_lock_packet_report_manifest'];manifest=json.loads((b/prior['MANIFEST.json']['preserved']).read_bytes());assert next(x for x in manifest['files'] if x['path']=='REPORT.json')['sha256']==prior['REPORT.json']['sha256']
for n in ['REPORT.json','MANIFEST.json']:
 x=prior[n];d=(b/x['preserved']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes']
for x in hist['copied_prior_lock_evidence']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
lreg=load('stdb-lock-registration.json');inv=load('stdb-lock-inventory.json');assert lreg['prior_registration_sha256']==sha((b/'lock-registration.json').read_bytes()) and inv['registration_sha256']==sha((b/'stdb-lock-registration.json').read_bytes()) and datetime.fromisoformat(lreg['at_utc'])<datetime.fromisoformat(inv['at_utc']) and len(lreg['entries'])==len(inv['entries'])==8
for x,y in zip(lreg['entries'],inv['entries']):
 raw=(b/x['archive']).read_bytes();assert x['id']==y['id'] and len(raw)==x['bytes'] and sha(raw)==x['sha256']==y['sha256'];packages=tomllib.loads(raw.decode())['package'];matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in packages if p['name'] in checks and p['version']=='2.6.1'];assert len(packages)==y['package_count'] and matches==y['matches'];expected=4 if x['git_path']=='Cargo.lock' else 2 if x['git_path']=='crates/adventuresim-character-creator/Cargo.lock' else 0;assert len(matches)==expected
 for p in matches:assert p['checksum']==checks[p['name']] and p['source']=='registry+https://github.com/rust-lang/crates.io-index'
hreg=load('historical-lock-registration.json');hinv=load('historical-lock-inventory.json');he=hreg['entries'][0];hd=(b/he['archive']).read_bytes();assert sha(hd)==he['sha256']=='58118b1b138af4f9feea993ea990dc334f63d30c4aa66f8b5597a0f1dfecfcf6' and he['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and hinv['registration_sha256']==sha((b/'historical-lock-registration.json').read_bytes()) and datetime.fromisoformat(hreg['at_utc'])<datetime.fromisoformat(hinv['at_utc']);pkgs=tomllib.loads(hd.decode())['package'];matches=[{'name':p['name'],'version':p['version'],'source':p.get('source'),'checksum':p.get('checksum')} for p in pkgs if p['name'] in checks and p['version']=='2.6.1'];assert matches==hinv['matches'] and len(matches)==4 and all(x['checksum']==checks[x['name']] for x in matches)
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
assert len(proof['paths'])==40 and not proof['absent_paths']
coverage={}
for receipt in ['read-receipt.json','support-read-receipt.json','support-read-receipt-2.json']:
 r=load(receipt);name=r['registration'];assert r['registration_sha256']==sha((b/name).read_bytes()) and datetime.fromisoformat(groups[name]['at_utc'])<datetime.fromisoformat(r['recorded_at_utc'])
 for e in r['entries']:
  id=str(e['id']);x=regs[(name,id)];assert e['sha256']==x['sha256'];actual={i for a,z in e['actual_display_chunks'] for i in range(a,z+1)};planned={i for a,z in x.get('prospective_personal_read_ranges',x.get('prospective_read_ranges',[])) for i in range(a,z+1)};remaining={i for a,z in e['unread_existing_lines'] for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage[id]=actual
assert len(regs)==len(coverage)==11
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(str(e['id'])==str(x['id']) and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[str(x['id'])] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','native_roles':roles,'personal_registered_scopes':len(regs),'774_records_git_proved':len(hist['records_774']),'historical_aliases':'23/495/2477 and 24/491 have same respective bytes but distinct roles/scopes','role20_extra_history':'earlier native admission expands ranges; this personal receipt leaves complements unread','059_receipts':'exact byte hashes and original fresh versus reused attributions','git_paths_proved':len(proof['paths']),'lockfiles_structurally_verified':9,'package_archives_verified':4,'bounded_lenses':13,'feature_resolution':'not inferred','macro_build_test_fixture_database_product_execution_probe_validation':'not performed'},indent=2))
