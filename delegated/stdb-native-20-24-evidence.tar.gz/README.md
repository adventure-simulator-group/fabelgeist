# Bounded SpacetimeDB 2.6.1 native review: roles 20–24

`REPORT.json` contains the bounded source assessment, open questions, and
historical relationships. `registration.json` and `read-receipt.json` record
prospectively registered and personally displayed assigned ranges. Separate
support registrations and receipts record additional SDK and current project
source, including generated client text. Complete native members are retained
for recovery; unread source ranges are not credited.

`packages/` preserves four distinct checksum-matched crates.io archives.
`locks/` preserves 6533 and 95e root/child lock bytes plus separately registered
earlier e275 root lock bytes. Structural inventory authenticates package choices
in those specific files; it does not establish enabled features, a running
connection, or product behavior. Git path proofs preserve project commits,
package-member transport objects, and 774 records. The transporting commit f82
is neither a native package revision nor a clean historical project snapshot.

`history/059/` preserves exact original local extracted receipts, registrations,
and proof records, including the distinction between historical fresh reads and
reused ranges. `history/774/` preserves exact historical records and supplier
variants; the redacted and original-path files are not identical. Original-path
variants and some exact 059 receipts contain local paths. Review and redact any
public copy, retain original local bytes, and record the separate hashes.
`registry-selection-reconstructed.json` and `queue-selection-reconstructed.json`
are mechanical selections from recovered historical records, not standalone
original records or checkpoint 3821. Role 23, 495 and 2477 share package bytes
but have distinct role IDs, reviewers and ranges; the same distinction applies
to roles 24 and 491.

Verify evidence integrity without product execution:

```sh
python3 <LOCAL_PATH_0>
python3 <LOCAL_PATH_1>
```

No product repairs, builds, tests, macro expansion, generated-client generation,
fixture or database operations, network requests, runtime probes, or product
validation were performed. Thirteen-lens notes apply only to displayed windows;
they do not claim whole-lens completion.
