# Extremity and joint: checkpoint 17 reconciliation

This is an additive, bounded source-only proposal by `/root/rig_identity` for
original roles 2617 and 2618, against working source revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The historical pr-working snapshot
recorded HEAD `6533e444fa37552927070cc8d8190907fd3b413e` and four unrelated
modified paths. Each role file individually matches the 6533 and 95e Git blob;
that does not establish a clean historical tree. Old and current extremities
1–78 and joint-cup 1–128 were independently displayed after registration.

Registrations and receipts preserve actual source windows, the individual
reader, timestamps and unread complements. Full archived bytes and source
hashes are not evidence of an additional read. Current support includes bounded
recipe, frame, batch, joint design, editor and shader-source windows; no kernel
or shader was executed. `REPORT.json` gives the connected q610 partial-recording
question, the selected construction and count guards, historical relationships,
open caller/policy questions, and thirteen bounded lens perspectives. No unique
finding count, automatic alias, runtime outcome or whole-lens clearance is
claimed. The caller-owned batch trace is conditional: a supported missing-frame
caller and its response to an error have not been established.

`history/` preserves exact 059 reviewer records, original 774 rig evidence,
mechanically reconstructed selected registry, queue and ledger values, and the
previous `/root/hair_ops` packet. It retains the P16 matching tracked patch and
its separate custody, original-command and untracked-file qualifications; no
P16 role credit or checkpoint 3821 restoration follows. The old 774 first-13
registration pin differs from the later recovered prefix; that earlier pin
predates and does not itself invalidate later rows 064/066. The prior public
archive's `historical-manifest.json` is a reconstructed path-redacted copy;
its original and published hashes are separately retained. Four other selected
members match exactly, without a claim of whole-archive identity.

The committed and observed working baseline copies are separately captured at
the commit in `history/publication-capture.json`. Their full hashes differ;
the selected current ledger entry compares equal and the working copy is not
represented as committed. `git-proofs.json` and `git-objects/` preserve exact
commit, tree, blob, source and transport paths. Central review must inspect
retained local-path metadata before any external publication.

From this directory, these commands verify evidence without modifying it:

```
python3 verify-evidence.py
python3 verify-manifest.py
```

Both are read-only and execute no product code. Construction scripts write
packet files and must not be rerun after freezing. No repairs, builds, tests,
macro or shader execution, rendering, fixtures, probes, or product validation
were performed. Central coordination owns final ledger and publication.
