import gzip, hashlib, json, pathlib
src=pathlib.Path('<LOCAL_PATH_0>')
pub=pathlib.Path('<LOCAL_PATH_1>')
out=pathlib.Path('<LOCAL_PATH_2>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f: entries={e['path']:e for e in json.load(f)['entries']}
paths=[]
for i,reg in [(386,1254),(388,1260)]:
 paths += [f'adler/READ-L11-{i}.json',f'adler/STATE-L11-{i}.json',f'adler/VERIFY-L11-{i}.json',f'adler/REGISTRATION-ADLER-{reg}.json']
for i in [795,798]:
 paths += [f'segovb/READ-L12-{i}.json',f'segovb/REGISTRATION-SEGOVB-L12-{i}.json',f'segovb/VERIFY-L12-{i}.json',f'parallel-l12-20261029/PROPOSAL-L12-{i}.json']
paths += ['parallel-l12-20261029/REGISTRATION-PAR-L12-377.json','parallel-l12-20261029/REGISTRATION-PAR-L12-381-CONNECTED-ORIGINAL2389.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-796-NATIVE-ENVELOPE-SATS-TYPES-PARTIAL001.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-798-ORIGINAL2389-ORDERED-CREDIT.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-795-797.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-798-800.json']
rows=[]; missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file(): missing.append(path); continue
 b=(src/path).read_bytes(); e=entries[path]; h=hashlib.sha256(b).hexdigest(); blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(); assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),path
 dst=out/'historical'/path; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(b); rows.append({'original_transport_path':path,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+path})
o={'schema':'delegated-recovered-historical-evidence-v1','qualification':'Exact copies from read-only original extraction checked against original transport SHA-256, length and Git blob. Preserve original reviewer, revision, scopes and open statuses; never promote to checkpoint3821 or current personal reads.','records':rows,'unavailable':missing}
f=out/'historical-manifest.json'; f.write_text(json.dumps(o,indent=2)+'\n'); print('verified',len(rows),'unavailable',missing,'manifest',hashlib.sha256(f.read_bytes()).hexdigest())
ref=out/'reference'; ref.mkdir(exist_ok=True)
refs=[('<LOCAL_PATH_3>','registry.json.gz','exact original registry'),('<LOCAL_PATH_4>','original-transport-manifest.json.gz','exact original transport manifest'),('<LOCAL_PATH_5>','queue-059.json.gz','losslessly compressed 059 queue, not checkpoint3821'),('<LOCAL_PATH_6>','strategic-web-AGENTS-95e.md','current governing rules'),(str(pub/'ASSESSMENT-L1-RECRUITMENT-ROLE.json'),'prior-assessment-recruitment-role.json','earlier c100 assessment, author unspecified'),(str(pub/'ASSESSMENT-L1-TACTICAL-ENTRY-IDENTITY.json'),'prior-assessment-tactical-entry.json','earlier c100 assessment, author unspecified'),(str(pub/'source-evidence/recruitment-role/current/crates/strategic-web/src/spacetimedb/types.rs.gz'),'prior-types-recruitment-c100.source.gz','earlier c100 role2389 object'),(str(pub/'source-evidence/tactical-entry/current/crates/strategic-web/src/spacetimedb/types.rs.gz'),'prior-types-tactical-c100.source.gz','earlier c100 role2389 object'),(str(pub/'ASSESSMENT-L05-EVIDENCE-PROVENANCE-95E.json'),'prior-assessment-evidence-provenance-95e.json','prior current evidence-knowledge provenance assessment, not automatic alias')]
rs=[];unavailable=[]
for source,name,cl in refs:
 s=pathlib.Path(source)
 if not s.is_file(): unavailable.append(source); continue
 b=s.read_bytes(); (ref/name).write_bytes(b); rs.append({'source':source,'copy':'reference/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'classification':cl})
f=ref/'manifest.json'; f.write_text(json.dumps({'records':rs,'unavailable':unavailable},indent=2)+'\n'); print('references',len(rs),'unavailable',unavailable,'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
