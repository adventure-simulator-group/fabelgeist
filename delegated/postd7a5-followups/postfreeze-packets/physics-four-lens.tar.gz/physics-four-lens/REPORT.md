# Physics WGSL: four independent lens assessments

This packet records a bounded source-only assessment of 059 q3220 (Lens 2),
q3221 (Lens 4), q3222 (Lens 5), and q3223 (Lens 6). The 413-line
`crates/fabelgeist-physics/src/wgsl.rs` blob was freshly preregistered for all
four named perspectives, then personally displayed in bounded chunks at 6533,
e275, and pinned 95e. Those file bodies are identical; the earlier working
snapshot as a whole is not thereby clean. `READ-RECEIPT.json` records the
exact views, support-only ranges and unread complements. This was one shared
read per revision, not four separate source displays.

The important source relationships and unresolved conditions are separate in
`ASSESSMENTS.json`. In brief:

- Lens 2: host `Shape`/`Collider` already own semantic variant data before
  packing, while WGSL is a numeric projection. Geometry `SignedLength` is a
  partial candidate only if unit, domain and finite-operation contracts fit;
  `PositiveLength` rejects zero, so it is not a universal collision scalar.
- Lens 4: the short nonzero capsule branch, medial-normal parity and
  count/length narrowing reconnect earlier attributed candidates. Input scale,
  allocation feasibility, device semantics and supported reach remain open.
- Lens 5: list/buffer/capacity, particle buffers/count and mesh/BVH buffers
  have correlated state. Existing 13Q already analyzes the conditional
  zero-capacity returned-error case; public buffer fields alone do not prove a
  supported incoherent producer.
- Lens 6: host semantic objects and shader layouts have different jobs.
  `ColliderCount` and `ColliderCapacity` have different authorities, and
  separate host and WGSL algorithms raise a policy/parity question rather than
  automatically proving a duplicate type owner.

Recovered 059 q3220–3223 were pending in their original snapshot. Original
and reconstructed whole queue streams differ; the four parsed selections
match and their normalized files are derived representations. The exact
original Root Lens 2 6533 receipt and e275 reused-identity receipt preserve
the earlier author, scope and lack of e275 reread. Earlier Adler, Lens12, rig,
and q3219 reviews keep their own source ranges and revisions; none transfer
read credit or become checkpoint 3821. Two oversized history displays were
truncated, then the relevant smaller selections were redisplayed.

No product, shader, macro, fixture, test or build was run. Evidence verification
checks bytes, registered views and source-object paths only; native execution,
producer reachability, policy, aliases, unique counts and lens/queue closure
remain for central reconciliation.
