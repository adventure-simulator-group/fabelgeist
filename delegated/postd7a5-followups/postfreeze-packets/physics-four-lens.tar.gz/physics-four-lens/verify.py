#!/usr/bin/env python3
"""Read-only verification of q3220-3223 evidence; never executes source text."""
import argparse,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent

def load(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(kind,b):return hashlib.sha1(kind+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(v,msg):
 if not v:raise ValueError(msg)
def safe(n):
 p=pathlib.PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return P.joinpath(*p.parts)
def tree(b):
 out={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a+1);need(z+21<=len(b),'truncated tree');name=b[a+1:z].decode();need(name not in out,'duplicate tree entry');out[name]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return out
def runs(s):
 out=[]
 for i in sorted(s):
  if out and out[-1][1]+1==i:out[-1][1]=i
  else:out.append([i,i])
 return out

def main():
 a=argparse.ArgumentParser();a.add_argument('--restricted',type=pathlib.Path);a.add_argument('--repository');a=a.parse_args()
 m=load(P/'MANIFEST.json');files={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(files==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest file set')
 for n,v in m['files'].items():
  b=safe(n).read_bytes();need(len(b)==v['bytes'] and sha(b)==v['sha256'],'manifest identity '+n)
 for e in load(P/'SKILLS-REGISTRATION.json')['skills']:
  b=(P/'skills'/(e['name']+'.md')).read_bytes();need(sha(b)==e['sha256'] and len(b.splitlines())==e['lines'],'skill '+e['name'])
 reg=load(P/'SOURCE-REGISTRATION.json');need([(x['queue'],x['lens']) for x in reg['assigned_own_lenses']]==[(3220,2),(3221,4),(3222,5),(3223,6)],'four preregistered lenses')
 rr=load(P/'READ-RECEIPT.json');nviews=0;uniq=set()
 for r in rr['rows']:
  e=next(x for x in load(P/r['registration'])['sources'] if x['label']==r['label']);b=safe(r['source_file']).read_bytes();lines=b.decode().splitlines();need(sha(b)==r['source_sha256']==e['sha256'] and oid(b'blob',b)==r['git_blob'] and len(lines)==r['eof']==e['eof'],'source identity '+r['label']);need(r['revision']==e['revision'] and r['path']==e['path'] and [x['range'] for x in r['views']]==e['planned_ranges'],'registration '+r['label'])
  seen=set()
  for v in r['views']:
   first,last=v['range'];need(1<=first<=last<=len(lines),'view bounds');data=safe(v['file']).read_bytes();need(sha(data)==v['sha256'] and data.decode().splitlines()==[f'{i}: {lines[i-1]}' for i in range(first,last+1)],'view contents '+v['file']);seen.update(range(first,last+1));nviews+=1
  need(runs(seen)==r['displayed_union'] and runs(set(range(1,len(lines)+1))-seen)==r['unread_complement'],'coverage '+r['label']);uniq.add((r['revision'],r['path']))
 need(len(uniq)==len(rr['rows'])==12,'source pair count')
 for r in rr['rows'][:3]:need(r['displayed_union']==[[1,413]] and r['unread_complement']==[],'primary range')
 proofs=load(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==len(uniq),'path proofs count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'tree chain length')
  for k,(part,step) in enumerate(zip(parts,x['tree_chain'])):
   need(step['tree']==cur and step['entry']==part,'tree chain');b=(P/'trees'/(cur+'.bin')).read_bytes();need(oid(b'tree',b)==cur,'tree oid');mode,nxt=tree(b)[part];need(mode==step['mode'] and nxt==step['object'],'tree path');cur=nxt
   if k+1<len(parts):need(mode in ('40000','040000'),'tree mode')
  need(cur==x['blob'] and oid(b'blob',safe(x['source_file']).read_bytes())==cur,'source blob')
  if a.repository:need(subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip()==x['root_tree'],'repository root')
 hc=load(P/'HISTORY-CAPTURE.json');objs=[]
 for s in hc['streams']:
  group=[]
  for r in s['rows']:
   b=(P/'queue'/('q'+str(r['index'])+'-'+s['name'])).read_bytes();need(len(b)==r['bytes'] and sha(b)==r['selected_normalized_sha256'],'normalized queue selection');group.append(json.loads(b))
  objs.append(group)
 need(objs[0]==objs[1] and [x['lens'] for x in objs[0]]==[2,4,5,6],'parsed selected equality')
 prior=P/'prior-lens2';checks={'READ-ROOT-L2-EXT-034-044.json':'4fed2c38883249b24797792793112a4a74ac77cb617a40c07d25b62fd02f3016','REGISTRATION-ROOT-L2-EXT-034-041.json':'225bd390e94bc9f3f67a6f03d162a149ffa26001d01515f203e81f9a1f2301a1','READ-ROOT-L2-CURRENT-009.json':'8d0211ebe9b9d119321efe63ccee1e0aa7de63ce089841b0f656418f6bc9758f','VERIFY-L2-EXT-CURRENT-009.json':'cf39c230c5b6830dc54da2543b20f8a68416f0abcc4bae62cfa5bffbbc252375'}
 for n,h in checks.items():need(sha((prior/n).read_bytes())==h,'prior Lens2 exact bytes')
 old=load(prior/'READ-ROOT-L2-EXT-034-044.json')['rows'][6];now=load(prior/'READ-ROOT-L2-CURRENT-009.json')['rows'][6];need(old['fresh_personal_ranges']==[[1,413]] and old['revision'].startswith('6533') and now['revision'].startswith('e275') and now['fresh_personal_ranges']==[] and old['source_sha256']==now['source_sha256'],'prior Lens2 attribution')
 report=load(P/'ASSESSMENTS.json');need([(x['queue'],x['lens']) for x in report['assessments']]==[(3220,2),(3221,4),(3222,5),(3223,6)],'report obligation mapping')
 restricted=False
 if a.restricted:
  d=a.restricted;h=d/'historical';streams=[]
  for s in hc['streams']:
   b=(h/s['name']).read_bytes();need(len(b)==s['bytes'] and sha(b)==s['sha256'],'restricted whole queue');q=json.loads(b);streams.append(q)
   for r in s['rows']:
    serial=(json.dumps(q['entries'][r['index']],indent=2,ensure_ascii=False)+'\n').encode();need(sha(serial)==r['selected_normalized_sha256'] and serial==(P/'queue'/('q'+str(r['index'])+'-'+s['name'])).read_bytes(),'restricted selection')
  need(all(streams[0]['entries'][i]==streams[1]['entries'][i] for i in range(3220,3224)),'restricted parsed equality')
  roots={}
  for x in load(d/'PRIVATE-COMMIT-IDENTITIES.json')['commits']:
   b=(d/'private-commits'/(x['revision']+'.commit')).read_bytes();need(sha(b)==x['whole_commit_payload_sha256'] and oid(b'commit',b)==x['revision'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'restricted commit anchor');roots[x['revision']]=x['root_tree']
  for x in proofs:need(roots[x['revision']]==x['root_tree'],'offline revision root')
  prior_manifest=(h/'q3219-link'/'PRIVATE-MANIFEST.json').read_bytes();need(sha(prior_manifest)=='970f412a67bb334740d0833845bc054eeac262bad43842d647b93d52b7a7069c','earlier manifest anchor');prior_files=json.loads(prior_manifest)['files']
  for rel in load(P/'HISTORICAL-SUPPORT-REGISTRATION.json')['capture_paths']:
   b=(h/'q3219-link'/rel).read_bytes();need(rel in prior_files and len(b)==prior_files[rel]['bytes'] and sha(b)==prior_files[rel]['sha256'],'earlier captured record')
  for n in checks:need((h/'prior-lens2'/n).read_bytes()==(prior/n).read_bytes(),'prior 059 exact copy')
  restricted=True
 print(json.dumps({'result':'pass','public_files':len(files),'registered_views':nviews,'source_revision_pairs':len(uniq),'git_path_proofs':len(proofs),'restricted_originals_and_commit_anchors_checked':restricted,'git_repository_revision_binding_checked':bool(a.repository),'qualification':'Evidence bytes, provenance and recorded display scopes only; no product, shader, runtime, unique-count or closure assertion.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
