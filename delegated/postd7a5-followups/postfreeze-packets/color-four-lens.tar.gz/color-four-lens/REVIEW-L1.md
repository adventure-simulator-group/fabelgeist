# q3171 — Lens 1: producer propagation

Reviewer: [independent reviewer; identity separately held]. This is a newly assessed source-only disposition,
separate from the original 059 record and all earlier reviewers. A shared
1–472 display was prospectively registered for the four named lenses and
independently read at historical 6533, e275, and pinned 95e. No q3178 Lens 9
or other reader's body credit was transferred. Commit/tree/blob proofs show
the selected color crate subtree is identical at those three revisions, not
that entire repository trees are equal. The 95e commit bytes were separately
recovered. Original and reconstructed selected 059 entries match byte for byte.
Checkpoint 3821 is missing; no earlier record is promoted to it. The missing
pre-export, 440 reconstructed-record, SOURCE004 and 73 nontext/no-positive-EOF
qualifications remain. This is not global lens closure, a unique defect count,
a repair or a product validation.

The source has a specific same-crate matrix propagation seam.
`crates/fabelgeist-color/src/space.rs:153–155,199–208` produces RGB-to-XYZ
and inverse 3×3 row-major matrices as `[f64; 9]` and implements the raw-array
inverse. `conversion.rs:20–58,115–123` defines the public row-major
`Matrix3x3` owner, immediately wraps the two produced arrays in
`ColorTransform::new`, and has `Matrix3x3::invert` unwrap its own array to the
same `space::invert_3x3` helper. The subsequent matrix multiplications and
vector transform are actual numerical consumers, but the two public producer
returns are not themselves foreign or wire boundaries. Carrying the existing
matrix owner between these internal color APIs is a concrete propagation
candidate; frame/row order, the `Option` inversion behavior, custom-primary
admission, public API direction and all other consumers must be reconciled
before a change. Conversion syntax by itself does not prove a numerical defect.

RGB values have a different role: `conversion.rs:142–159` takes three raw
channels and invokes transfer decoding, matrix arithmetic and transfer
encoding. `transfer.rs:28–112` operates on primitive channel arithmetic;
`color.rs:4–14,36–54` is an untagged four-component RGBA value with alpha.
It is not an exact replacement for every intermediate RGB triple. Historical
q2405 preserves this distinction and leaves actual owner and HDR policy open;
the new matrix producer-to-wrapper trace is a more specific candidate, not an
assertion that all numeric arrays are interchangeable. Do not impose a unit
interval on arbitrary linear/HDR, signed or nonfinite values without policy.

The historical Lens 1 handoff reports aggregate inherited population scope;
the bounded uncompressed search did not identify a target-specific personal
receipt. That is not proof of historical absence.
