# Four independent source-only color assessments

- `REVIEW-L1.md`: q3171 producer propagation.
- `REVIEW-L2.md`: q3172 existing type owners.
- `REVIEW-L5.md`: q3174 aggregate states.
- `REVIEW-L6.md`: q3175 type ownership.

This is a privacy-reviewed reconstruction; exact historical queue records,
private reports, commit objects and the complete 059 queues are separately
held. The Adler Lens 5 group is included in its exact bytes. Whole-file hashes
and offsets permit optional verification against private originals without a
digest of any individual removed path.

`python3 verify-public.py` checks the manifest, tree-to-blob paths, registered
displays and four focused skills. Without private originals it cannot bind
trees to commits, establish full queue or historical receipt membership,
reconstruct private bytes, or verify the ledger anchor. With separately held
evidence, use `python3 verify-public.py --private RESTRICTED_DIRECTORY
--anchors ANCHOR_DIRECTORY`; omit `--anchors` to leave full-queue membership
unchecked. The private manifest and file set are checked before the restricted
evidence verifier is run.

Registered source displays include inline test code as text; no product code,
tests, examples, shaders, macros, builds, repairs or runtime probes ran. No
checkpoint 3821 recovery, global lens clearance, unique count or product
validation is claimed.
