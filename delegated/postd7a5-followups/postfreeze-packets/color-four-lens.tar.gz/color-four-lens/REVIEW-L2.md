# q3172 — Lens 2: existing owners

Reviewer: [independent reviewer; identity separately held]. This is a newly assessed source-only disposition,
separate from the original 059 record and all earlier reviewers. A shared
1–472 display was prospectively registered for the four named lenses and
independently read at historical 6533, e275, and pinned 95e. No q3178 Lens 9
or other reader's body credit was transferred. Commit/tree/blob proofs show
the selected color crate subtree is identical at those three revisions, not
that entire repository trees are equal. The 95e commit bytes were separately
recovered. Original and reconstructed selected 059 entries match byte for byte.
Checkpoint 3821 is missing; no earlier record is promoted to it. The missing
pre-export, 440 reconstructed-record, SOURCE004 and 73 nontext/no-positive-EOF
qualifications remain. This is not global lens closure, a unique defect count,
a repair or a product validation.

`conversion.rs:20–22,115–123` already defines and consumes a row-major
`Matrix3x3([f64; 9])`, while `space.rs:153–155,199–208` emits row-major
3×3 matrices as the same raw array and `conversion.rs` immediately wraps them.
That producer/result relationship is an exact representation-and-operation
fit for the existing wrapper, subject to the deliberately separate RGB→XYZ
versus XYZ→RGB directions and inversion/error policy. It is a candidate for
connected owner propagation, not evidence of a wrong matrix or a blanket demand
to wrap every coefficient array. Historical q2405 concluded that no exact
existing substitution had then been demonstrated for its bounded numeric
roles; compare the newly traced producer-to-wrapper path on its merits rather
than silently changing that recorded disposition.

`yuv.rs:65–93` already owns `ChromaSubsampling::Yuv420` and the independent
ceil-divided chroma width and height. The I420 consumer uses ceil chroma width
(`yuv.rs:201–223`), while the higher-level wrapper divides total pixel count
by four (`conversion.rs:215–245`). This is a directly relevant dimensions
owner for the previously recorded q3145 extent question. It does not by
itself define NV12's interleaved byte stride, odd-dimension support, zero-size
policy or checked total size; those decisions must precede any general reuse.
`PixelFormat::bytes_per_pixel` intentionally returns `None` for the selected
planar formats (`pixel.rs:433–482`), so a packed bytes-per-pixel formula is
not a complete planar layout owner. `Color` remains a four-channel untagged
RGBA value, not an automatic owner for every three-channel RGB calculation.

Root's historical Lens 2 receipt records a fresh 6533 1–472 read; its e275
receipt records exact same-lens 1–472 reuse and zero fresh current lines. This
reviewer's new reading is separate. q2405, q3145 and current ledger row 495
are relationships, not automatically aliases or new unique counts.
