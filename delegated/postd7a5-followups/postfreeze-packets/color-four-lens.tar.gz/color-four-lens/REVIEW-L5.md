# q3174 — Lens 5: aggregate states

Reviewer: [independent reviewer; identity separately held]. This is a newly assessed source-only disposition,
separate from the original 059 record and all earlier reviewers. A shared
1–472 display was prospectively registered for the four named lenses and
independently read at historical 6533, e275, and pinned 95e. No q3178 Lens 9
or other reader's body credit was transferred. Commit/tree/blob proofs show
the selected color crate subtree is identical at those three revisions, not
that entire repository trees are equal. The 95e commit bytes were separately
recovered. Original and reconstructed selected 059 entries match byte for byte.
Checkpoint 3821 is missing; no earlier record is promoted to it. The missing
pre-export, 440 reconstructed-record, SOURCE004 and 73 nontext/no-positive-EOF
qualifications remain. This is not global lens closure, a unique defect count,
a repair or a product validation.

`conversion.rs:166–182` couples declared width/height and source/destination
formats with byte slices, but its identical-format branch copies the smaller
slice length and returns success without admitting the declared pixel extent.
For the symbolic public-API case of a 1×1 same-format RGBA request with empty
source and destination, that branch returns success by source control flow;
no function was executed. The established first operation is Adler's
`ADLER-RESUMED05-F003` (Lens 5) and separately retained 059 q147 / dac7d row
493 (Lens 11). Actual callers, arithmetic overflow, and whether a distinct
partial-copy policy is intended remain open.

For I420, `conversion.rs:215–245` divides total pixel count by four per chroma
plane, while `yuv.rs:201–223` indexes with ceil-divided chroma width. Existing
q3145 records the symbolic 1×1 case and keeps caller reachability and odd
layout policy open. NV12 additionally indexes interleaved pairs using width as
row stride (`yuv.rs:148–168,252–327`), so its odd-width storage policy cannot
be resolved solely by replacing the I420 count. No image or index ran.

Packed RGBA/BGRA branches check minimum expected bytes but zip every complete
chunk of the supplied slices (`conversion.rs:249–323`); R8 conversion bounds
the input prefix (`:324–375`). For an illustrative one-pixel request with two
complete pixels in each slice, the packed loop's source-level iteration covers
two chunks. Whether the second chunk must remain unchanged is an open suffix
contract already recorded separately as q3146, not the short identity-copy
predicate. `ColorTransform` also exposes its matrix and transfer fields, but
arbitrary custom combinations are not shown invalid merely by differing from
a predefined `ColorSpace`.

Adler's `audit05/contract-groups-220.json#/source_members/1` records a personal
1–472 Lens 5 read of the pr-working source, identifies F003, and attributes
custom-primary inversion admission to Rig's `RIG-ADMISSION03-F056`. The catalog
independently relates that source to 6533; the Adler receipt does not itself
name the commit. A later F003 comparison is at historical revision
990430b77a9f63548ffcb642074185f61ddb3322 and remains a qualified historical
record. Rig's F056, original q148 and dac7d row 494 concern custom-primary
inverse/nonfinite handling; they are distinct from the image-extent first
operation. Preserve all attributions without asserting global deduplication.
