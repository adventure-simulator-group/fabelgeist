#!/usr/bin/env python3
"""Four-lens color evidence replay only; no product, shader, macro or test execution."""
import argparse,hashlib,json,re,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);d[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return d
def path(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/f'{t}.tree').read_bytes();assert oid('tree',b)==t;mode,t=tree(b)[part]
 assert mode=='100644' and oid('blob',data)==t
def manifest(d):
 m=json.loads((d/'MANIFEST.json').read_bytes());found={str(f.relative_to(d)) for f in d.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};assert found==set(m['files'])
 for n,v in m['files'].items():
  f=d/n;assert H(f.read_bytes())==v['sha256'] and (f.stat().st_mode&0o777)==v['mode']
ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: public packet manifest (--skip-manifest)')
else:manifest(P);print('public file set, modes and hashes: pass')
proof=json.loads((P/'SOURCE-002-RESULT.json').read_bytes());roots={'6533':'849ec1e8faca2236c7021893cda7a3f7cb5c72e8','e275':'7737c903f98397669c12da05475f759aa7fcfe73','95e':'1eec97de340d9b7debbb30ca0c0fb2240a73b93f'};base='crates/fabelgeist-color/'
for r in proof['rows']:
 label=r['label'];root=r['chain'][0]['tree'];assert root==roots[label];b=(P/'source'/f'{label}.rs').read_bytes();assert H(b)=='1c16766feee62bbb80b38bdcc46c18cd7c732d6f2d796a4c26e228cb4eff6f1e' and len(b.splitlines())==472 and b.endswith(b'\n');path(root,base+'src/conversion.rs',b);ls=b.decode().splitlines()
 for lo,hi in [(1,236),(237,472)]:assert (P/'displays'/f'{label}-{lo}-{hi}.txt').read_text()==''.join(f'{i}: {ls[i-1]}\n' for i in range(lo,hi+1))
adj={n:base+'src/'+n for n in ['color.rs','lib.rs','pixel.rs','space.rs','transfer.rs','yuv.rs']};adj.update({'dmat3.rs':'crates/fabelgeist-math/src/matrix/dmat3.rs','color-Cargo.toml':base+'Cargo.toml','math-Cargo.toml':'crates/fabelgeist-math/Cargo.toml'})
for n,name in adj.items():path(roots['95e'],name,(P/'adjacent'/n).read_bytes())
for f in (P/'adjacent-displays').iterdir():
 m=re.fullmatch(r'(.+)-(\d+)-(\d+)\.txt',f.name);assert m
 n,lo,hi=m.group(1),int(m.group(2)),int(m.group(3));assert n in adj;ls=(P/'adjacent'/n).read_text().splitlines();assert f.read_text()==''.join(f'{i:4d} {ls[i-1]}\n' for i in range(lo,hi+1))
rows=json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows'];names={1:'producer-propagation',2:'existing-type-owners',5:'aggregate-states',6:'type-ownership'}
for r in rows:assert r['name']==names[r['number']] and H((P/f"SKILL-L{r['number']}.md").read_bytes())==r['skill']['sha256']
b=(P/'HIST-L5-220.json').read_bytes();assert H(b)=='e593e3afea19341d413087debd5968646a4a641f54a2315195390f49f94bf058';r=json.loads(b)['source_members'][1];assert r['scope_index']==2234 and r['personally_read_ranges']==[[1,472]]
print('selected tree-to-source paths, complete target and adjacent displays, four skills and exact Adler group bytes: pass')
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if not a.private:print('NOT CHECKED: commit-to-root binding, original handoff map, complete queue membership, historical receipt linkage, private reconstruction and dac7d ledger membership; separately held restricted packet required')
else:
 assert H((a.private/'MANIFEST.json').read_bytes())=='87b7ea77119f7258d570b63bccdf43a0fe06c2f492ffcc453fb92f4d94aff00f';manifest(a.private)
 c=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes())
 for item in c['files']:
  old=(a.private/item['original_file']).read_bytes();assert H(old)==item['original_whole_file_sha256'];out=bytearray();last=0
  for r in item['replacements']:
   i=r['original_byte_offset'];n=r['original_byte_length'];assert i>=last;out+=old[last:i]+r['replacement'].encode();last=i+n
  out+=old[last:];assert bytes(out)==(P/item['successor']).read_bytes() and H(out)==item['successor_whole_file_sha256']
 print('restricted manifest, file set and ten reconstruction crosswalks: pass')
 cmd=[sys.executable,str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,end='')
 if r.returncode:print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
print('Evidence integrity does not prove semantic conclusions, recover 3821 or validate product behavior.')
