# q3175 — Lens 6: type ownership

Reviewer: [independent reviewer; identity separately held]. This is a newly assessed source-only disposition,
separate from the original 059 record and all earlier reviewers. A shared
1–472 display was prospectively registered for the four named lenses and
independently read at historical 6533, e275, and pinned 95e. No q3178 Lens 9
or other reader's body credit was transferred. Commit/tree/blob proofs show
the selected color crate subtree is identical at those three revisions, not
that entire repository trees are equal. The 95e commit bytes were separately
recovered. Original and reconstructed selected 059 entries match byte for byte.
Checkpoint 3821 is missing; no earlier record is promoted to it. The missing
pre-export, 440 reconstructed-record, SOURCE004 and 73 nontext/no-positive-EOF
qualifications remain. This is not global lens closure, a unique defect count,
a repair or a product validation.

The row-major `Matrix3x3` value is publicly owned by the color conversion
module (`conversion.rs:20–58`), but `ColorPrimaries` produces the same shape
as raw arrays and `space::invert_3x3` owns the inverse implementation
(`space.rs:153–155,199–229`). The conversion module already depends on space
for primaries and inversion; a shared same-crate matrix owner could clarify
that producer/consumer boundary, but moving or reusing it requires examining
all actual API consumers, matrix direction and failure semantics. This is a
bounded ownership question, not proof that the current module split corrupts
results or that a particular move is required.

A separately defined `fabelgeist-math::DMat3` is a double-precision 3×3
matrix (`crates/fabelgeist-math/src/matrix/dmat3.rs:5–16,24–42,82–124`),
but it stores `columns[c][r]` and is documented primarily for rotations;
the selected full source does not provide the color owner's general inverse
method. Color's owner and XYZ arrays are row-major. The two crate manifests
show no direct color↔math dependency. Shared width and shape therefore do not
establish a drop-in replacement, and an adapter, dependency direction,
precision, inverse behavior and semantic frames need independent review.
The names-only search was limited to the color and math source trees; it was
not a repository-wide competing-owner inventory.

The distinct `Color` RGBA, `ColorSpace`, `TransferFunction`, `PixelFormat` and
`ChromaSubsampling` owners retain different roles (`color.rs:4–14`,
`space.rs:231–290`, `transfer.rs:4–25`, `pixel.rs:143–232`,
`yuv.rs:65–93`). No universal bounded-channel invariant or forced unification
is inferred. The historical Lens 6 handoff preserves inherited population and
successor attribution; a bounded uncompressed path search did not recover an
individual target-specific same-lens body receipt, which does not establish
its global absence.
