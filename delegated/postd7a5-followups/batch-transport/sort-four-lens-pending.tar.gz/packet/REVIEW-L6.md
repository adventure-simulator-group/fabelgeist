# q3187 — Lens 6: type ownership

Reviewer: [independent reviewer; identity separately held]. This newly assessed, source-only disposition is
separate from the original 059 record and every earlier review. The registered
shared 1–327 body displays were independently completed at historical 6533,
e275, and pinned 95e for the four explicitly named lenses; no q3190 Lens 9 or
other reviewer's personal reading was transferred. The three source files are
identical by commit/tree/blob proof, not by whole-tree equivalence. The 95e
commit bytes were separately recovered. The original 059 and reconstructed
selected entries match byte for byte. Checkpoint 3821 remains missing; neither
earlier records nor this work are promoted to it. Missing-pre-export and
SOURCE004 recovery qualifications and all 73 nontext/no-positive-EOF obligations
remain. This is not global lens closure, a unique defect count, implementation,
or product validation.

The inspected pinned owner direction places `BufferByteLength` and
`BufferByteOffset` in the lower `fabelgeist-gpu` buffer module
(`fabelgeist-gpu/src/data/gpu/buffer/extent.rs:1–36`), while
`fabelgeist-compute/Cargo.toml:8–10` depends on that GPU crate. Its sort and
batch consumers use the GPU buffer representation (`sort/mod.rs:233–257`;
`kernel/mod.rs:317–329`). The byte-length type is the relevant common leaf;
a byte offset has a different role. The remaining raw internal byte parameter
is a producer/consumer propagation and owner-fit question, not evidence that
the shared leaf itself is owned by the wrong crate.

`ScanElementCount` is declared and consumed by the compute prefix-sum module
(`prefix_sum.rs:19–57,162–211,233–269`) and is explicitly used by radix sort
for the histogram scan (`sort/mod.rs:174–180,282–287`). The sorted-key count,
triangle count and histogram scan-word count have different producing and
receiving roles. No competing equivalent owner or wrong dependency direction is
substantiated in these selected files, and no consolidation of those counts is
justified solely by their primitive representation. A complete competing-owner
inventory and external producers remain open: a names-only scan of the whole
pinned root failed because that object was unavailable in the live Git store;
the proved compute subtree search and selected pinned GPU objects succeeded.

The historical Lens 6 map preserves inherited population attribution and warns
against treating successor work as Root-personal. The bounded exact-path search
found no directly identifying Lens 6 body receipt, which does not establish its
global absence. No historical source or verdict has been transferred to this
reviewer's four-lens reading.
