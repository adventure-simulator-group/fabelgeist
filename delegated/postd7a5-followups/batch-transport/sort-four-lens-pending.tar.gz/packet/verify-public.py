#!/usr/bin/env python3
"""Evidence-only four-lens replay; never executes product, shader, macro or tests."""
import argparse,hashlib,json,re,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);d[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return d
def path(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/f'{t}.tree').read_bytes();assert oid('tree',b)==t;mode,t=tree(b)[part]
 assert mode=='100644' and oid('blob',data)==t
def manifest(directory):
 m=json.loads((directory/'MANIFEST.json').read_bytes());found={str(f.relative_to(directory)) for f in directory.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};assert found==set(m['files'])
 for n,v in m['files'].items():
  f=directory/n;assert H(f.read_bytes())==v['sha256'] and (f.stat().st_mode&0o777)==v['mode']
ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: public packet manifest (--skip-manifest)')
else:manifest(P);print('public file set, modes and hashes: pass')
proof=json.loads((P/'SOURCE-002-RESULT.json').read_bytes());roots={'6533':'849ec1e8faca2236c7021893cda7a3f7cb5c72e8','e275':'7737c903f98397669c12da05475f759aa7fcfe73','95e':'1eec97de340d9b7debbb30ca0c0fb2240a73b93f'};base='crates/fabelgeist-compute/'
for r in proof['rows']:
 label=r['label'];root=r['chain'][0]['tree'];assert root==roots[label];b=(P/'source'/f'{label}.rs').read_bytes();assert H(b)=='2cf6b4446ab00dce84c8b3169d9685d3b2e304b869f4c25d0e4322c7bedf9634' and len(b.splitlines())==327 and b.endswith(b'\n');path(root,base+'src/sort/mod.rs',b);ls=b.decode().splitlines()
 for lo,hi in [(1,164),(165,327)]:assert (P/'displays'/f'{label}-{lo}-{hi}.txt').read_text()==''.join(f'{i}: {ls[i-1]}\n' for i in range(lo,hi+1))
adj={'lib.rs':base+'src/lib.rs','prefix_sum.rs':base+'src/prefix_sum.rs','vertex_normals.rs':base+'src/vertex_normals.rs','kernel.rs':base+'src/kernel/mod.rs','compute-Cargo.toml':base+'Cargo.toml','gpu-extent.rs':'crates/fabelgeist-gpu/src/data/gpu/buffer/extent.rs','gpu-buffer.rs':'crates/fabelgeist-gpu/src/data/gpu/buffer/mod.rs'}
for n,name in adj.items():path(roots['95e'],name,(P/'adjacent'/n).read_bytes())
for f in (P/'adjacent-displays').iterdir():
 m=re.fullmatch(r'(.+)-(\d+)-(\d+)\.txt',f.name);assert m
 n,lo,hi=m.group(1),int(m.group(2)),int(m.group(3));assert n in adj;ls=(P/'adjacent'/n).read_text().splitlines();assert f.read_text()==''.join(f'{i:4d} {ls[i-1]}\n' for i in range(lo,hi+1))
rows=json.loads((P/'LENS-MAP-SELECT.json').read_bytes())['rows'];names={1:'producer-propagation',2:'existing-type-owners',5:'aggregate-states',6:'type-ownership'}
for r in rows:assert r['name']==names[r['number']] and H((P/f"SKILL-L{r['number']}.md").read_bytes())==r['skill']['sha256']
cor=json.loads((P/'CORRECTION-034.json').read_bytes());assert (P/'REVIEW-L5-predecessor.md').read_text().replace(cor['old_text'],cor['new_text'])==(P/'REVIEW-L5.md').read_text()
print('selected tree-to-source proofs, complete target and adjacent displays, four skills and Lens5 correction: pass')
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if not a.private:print('NOT CHECKED: commit-to-root binding, original handoff map, complete queue membership, historical receipt attribution, private reconstruction and dac7d ledger membership; separately held restricted packet required')
else:
 assert H((a.private/'MANIFEST.json').read_bytes())=='1cea51f8a7ee7fdea4c8d3c4c23c4de1311743a53f334a7f4a8f0c9e2fb3012d';manifest(a.private)
 c=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes())
 for item in c['files']:
  old=(a.private/item['original_file']).read_bytes();assert H(old)==item['original_whole_file_sha256'];out=bytearray();last=0
  for r in item['replacements']:
   i=r['original_byte_offset'];n=r['original_byte_length'];assert i>=last;out+=old[last:i]+r['replacement'].encode();last=i+n
  out+=old[last:];assert bytes(out)==(P/item['successor']).read_bytes() and H(out)==item['successor_whole_file_sha256']
 print('restricted manifest, file set and nine reconstruction crosswalks: pass')
 cmd=[sys.executable,str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,end='')
 if r.returncode:print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
print('Evidence integrity does not prove findings, recover checkpoint 3821 or validate product behavior.')
