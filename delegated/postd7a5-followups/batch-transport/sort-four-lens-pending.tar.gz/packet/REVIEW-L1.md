# q3183 — Lens 1: producer propagation

Reviewer: [independent reviewer; identity separately held]. This newly assessed, source-only disposition is
separate from the original 059 record and every earlier review. The registered
shared 1–327 body displays were independently completed at historical 6533,
e275, and pinned 95e for the four explicitly named lenses; no q3190 Lens 9 or
other reviewer's personal reading was transferred. The three source files are
identical by commit/tree/blob proof, not by whole-tree equivalence. The 95e
commit bytes were separately recovered. The original 059 and reconstructed
selected entries match byte for byte. Checkpoint 3821 remains missing; neither
earlier records nor this work are promoted to it. Missing-pre-export and
SOURCE004 recovery qualifications and all 73 nontext/no-positive-EOF obligations
remain. This is not global lens closure, a unique defect count, implementation,
or product validation.

The selected 95e caller `crates/fabelgeist-compute/src/vertex_normals.rs:228–255,298–338`
creates corner capacity from triangle capacity, produces corner count from
triangle count, and passes that raw count and a bit width derived from vertex
count to `RadixSort::record`. The shader text writes a triangle index as each
key and a corner slot as its payload (`vertex_normals.rs:64–100`). These are
one selected producer and consumer, not an inventory of all sort producers.

`sort/mod.rs:159–180,233–287` derives the histogram scan word count from
RADIX times tile count and admits it as `ScanElementCount`; the receiving
`prefix_sum.rs:19–57,233–303` uses that owner through its public record check,
then extracts a `u32` into a private recursive helper before arithmetic,
recursive block counts and uniform parameter insertion. The helper does real
numerical work, and the GPU uniform itself is `u32`. Whether the role should
remain typed through that internal helper is a propagation question, not a
proved numerical failure or a mandate to treat the different input-key count
as a scan count.

An exact byte-unit path is independently visible: `Buffer.size` is
`BufferByteLength` (`fabelgeist-gpu/src/data/gpu/buffer/mod.rs:15–35` and
`extent.rs:1–36`). Sort converts the typed input sizes to `u64` for the
application-side comparison and sends computed byte length as `u64` to
`KernelBatch::copy_buffer` (`sort/mod.rs:245–257,300–302`;
`kernel/mod.rs:317–329`). That helper compares raw counts before passing bytes
to the native encoder. Retaining the byte-length owner through the internal
comparison/copy interface is a concrete propagation candidate, subject to
separate owner-fit, zero, alignment, caller and native-boundary review; the
present trace does not establish incorrect output. A later connected decision
would preserve existing no-op/error behavior and convert where the actual native
call requires a primitive. The historical Lens 1 state is an aggregate coverage
summary; this bounded search did not identify a direct per-target same-lens
receipt, and does not prove one never existed.
