# q3186 — Lens 5: aggregate states

Reviewer: [independent reviewer; identity separately held]. This newly assessed, source-only disposition is
separate from the original 059 record and every earlier review. The registered
shared 1–327 body displays were independently completed at historical 6533,
e275, and pinned 95e for the four explicitly named lenses; no q3190 Lens 9 or
other reviewer's personal reading was transferred. The three source files are
identical by commit/tree/blob proof, not by whole-tree equivalence. The 95e
commit bytes were separately recovered. The original 059 and reconstructed
selected entries match byte for byte. Checkpoint 3821 remains missing; neither
earlier records nor this work are promoted to it. Missing-pre-export and
SOURCE004 recovery qualifications and all 73 nontext/no-positive-EOF obligations
remain. This is not global lens closure, a unique defect count, implementation,
or product validation.

`sort/mod.rs:144–195,233–303` constructs key, value, histogram, scan and
capacity together, then exposes the first three buffers publicly while keeping
scan and capacity private. `ensure` returns without reconstruction when the
requested capacity already fits. For count above one, `record` checks private
capacity and input-buffer sizes before recording the histogram dispatch; it
does not first validate actual scratch key/value/histogram extents against the
stored capacity. The subsequent scan checks its histogram buffer metadata only
after that dispatch has been recorded (`prefix_sum.rs:240–269`). A short or
otherwise mismatched replacement is therefore a source-representable API state;
actual supported writers, buffer admission, bind/dispatch outcomes and device
behavior remain open. No claim is made that a particular current caller reaches
it. Count zero or one returns before these checks as a no-work path.

`fabelgeist-gpu/src/data/gpu/buffer/mod.rs:15–35` separately exposes its native
handle, typed size and usage as public fields; construction initially sets them
together. `sort/mod.rs:251–257` and `kernel/mod.rs:319–328` rely on the stored
size metadata. Whether any supported writer can desynchronize that metadata,
how native validation reacts, and whether this is the same repair family as
scratch replacement need separate reconciliation. Do not infer an observed GPU
failure. The extreme `RADIX * tiles` width issue is another conditional native
extent question, not a measured allocation or runtime result.

A distinct selected caller relation also remains open. `vertex_normals.rs:93–99`
copies triangle indices into sort keys; `:298–338` checks declared counts
against capacities and chooses the sort's bits from vertex count, while
`:120–147` later indexes starts/ends by each key. For illustration, with
vertex count 2, triangle keys `[0, 256, 0]`, adequate capacity and otherwise
successful native operations, the selected bit width requests one eight-bit
pass, whose digit cannot distinguish 0 from 256. If the stable source contract
holds, the two zero-key runs remain separated and the range shader text would
address the same per-key entries from separate runs. The inspected host method
does not itself read triangle-buffer values; whether a supported upstream
admission excludes this input, and any actual device outcome, were not proved.
This is a contract question, not an asserted reachable defect or alias.

Historical evidence is separately attributed: Adler's
`audit05/contract-groups-222.json#/source_members/4` records a personal
1–327 Lens 5 read of the same pr-working source and relates its scratch
question to Rig's inherited `RIG-ADMISSION03-F059`. The selected source catalog
links that source identity to 6533; the Adler receipt does not itself name the
commit. Rig's retained admission record states the conditional scratch and
histogram-width concerns with validation unexecuted; original 059 q3142 is
Root's later distinct Lens 3 admission record. Central reconciliation must
assess exact relationships without inferring a new count.
