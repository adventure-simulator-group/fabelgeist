# q3184 — Lens 2: existing owners

Reviewer: [independent reviewer; identity separately held]. This newly assessed, source-only disposition is
separate from the original 059 record and every earlier review. The registered
shared 1–327 body displays were independently completed at historical 6533,
e275, and pinned 95e for the four explicitly named lenses; no q3190 Lens 9 or
other reviewer's personal reading was transferred. The three source files are
identical by commit/tree/blob proof, not by whole-tree equivalence. The 95e
commit bytes were separately recovered. The original 059 and reconstructed
selected entries match byte for byte. Checkpoint 3821 remains missing; neither
earlier records nor this work are promoted to it. Missing-pre-export and
SOURCE004 recovery qualifications and all 73 nontext/no-positive-EOF obligations
remain. This is not global lens closure, a unique defect count, implementation,
or product validation.

`fabelgeist-gpu/src/data/gpu/buffer/extent.rs:1–36` defines
`BufferByteLength` as a logical byte extent, separate from a byte offset.
`Buffer::new` accepts that owner and retains it as `Buffer.size`
(`buffer/mod.rs:15–35`); `prefix_sum.rs:19–57` independently converts scan
words to that same byte extent. In `sort/mod.rs:245–257,300–302`, the
`needed = count * 4` value is also a byte extent and is compared with the
typed input-buffer sizes, but the comparison and `KernelBatch::copy_buffer`
interface (`kernel/mod.rs:317–329`) operate on raw `u64`s. This is a concrete
existing-owner fit for the internal byte extent, not proof that current byte
arithmetic is wrong. A connected owner decision must keep the eventual native
primitive boundary and existing zero, alignment, capacity and error contracts;
`BufferByteLength` itself accepts zero while `Buffer::new` rejects zero.

`ScanElementCount` counts scan words. Sort's input key count and its flat
histogram count are related by `RADIX * ceil(count / TILE)`, not equivalent
roles (`sort/mod.rs:159–180,233–287`). Reusing `ScanElementCount` for generic
sorted-key count solely because both are `u32` is unproved. The original 059
q2406 and dac7d ledger row 510 retain that owner-fit question, with application
semantics and aliases open.

Earlier same-lens evidence is separately recovered: Root's 6533
`READ-ROOT-L2-EXT-034-044.json#/rows/3` records a fresh full 1–327 read;
Root's e275 `READ-ROOT-L2-CURRENT-009.json#/rows/3` records exact same-lens
reuse over 1–327 and zero fresh current lines. The newly registered reading
here is independent of both. The bounded search does not rule out additional
owners or other historical receipts.
