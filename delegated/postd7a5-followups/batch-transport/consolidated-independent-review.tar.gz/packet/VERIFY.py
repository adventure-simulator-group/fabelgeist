#!/usr/bin/env python3
"""Verify public packet; optionally authenticate, restore and replay restricted evidence."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,io,json,os,subprocess,sys,tarfile,tempfile,zlib
r=Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('FAIL: disable optimization')
def need(x,m):
 if not x:raise SystemExit('FAIL: '+m)
def sha(b):return hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--key',type=Path);a.add_argument('--restore-to',type=Path);a=a.parse_args();need(not a.restore_to or a.key,'--restore-to requires --key')
m=json.loads((r/'MANIFEST.json').read_bytes());rows=m['files'];names={x['path'] for x in rows};need(len(names)==len(rows) and {x.name for x in r.iterdir()}==names|{'MANIFEST.json'},'packet membership')
for e in rows:
 f=r/e['path'];need(f.is_file() and not f.is_symlink(),'file type');b=f.read_bytes();need(len(b)==e['bytes'] and sha(b)==e['sha256'],'file identity')
x=json.loads((r/'REVIEW.json').read_bytes());e=json.loads((r/'ENCRYPTION.json').read_bytes());cipher=(r/'restricted.aesgcm').read_bytes();need(x['parent_checkpoint']=='d7a5e77ebdbd44a05cde30881493d6fc22ef025d' and x['product_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and x['restricted_manifest_sha256']==e['restricted_manifest_sha256'] and sha(cipher)==e['ciphertext_sha256'] and len(cipher)==e['ciphertext_bytes'],'review/encryption binding')
print('Public packet, ciphertext identity and checkpoint binding verified.')
if not a.key:
 print('Encrypted originals and source/history proof not checked; supply --key. Separate key and cryptography package are required.');raise SystemExit(0)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
key=a.key.read_bytes();need(len(key)==32,'key length');packed=AESGCM(key).decrypt(bytes.fromhex(e['nonce_hex']),cipher,e['aad_ascii'].encode());archive=zlib.decompress(packed);need(len(archive)==e['decompressed_archive_bytes'],'archive length')
if a.restore_to:
 root=a.restore_to;need(not root.exists() and not root.is_symlink(),'restore destination exists');root.mkdir(mode=0o700)
else:
 root=Path(tempfile.mkdtemp(prefix='postd7-review-restore-'));os.chmod(root,0o700)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as t:
 members=t.getmembers();names=set()
 for v in members:
  path=PurePosixPath(v.name);need(not path.is_absolute() and path.parts and path.parts[0]=='evidence' and all(z not in ('','.','..') for z in path.parts),'archive path');need(v.name not in names and (v.isdir() or v.isfile()) and not v.issym() and not v.islnk(),'archive member');names.add(v.name);need(v.mode in (0o600,0o700),'archive mode')
 for v in members:
  if v.isdir():
   dest=root.joinpath(*PurePosixPath(v.name).parts);dest.mkdir(mode=v.mode)
 for v in members:
  if v.isfile():
   dest=root.joinpath(*PurePosixPath(v.name).parts);source=t.extractfile(v);need(source is not None,'archive file');data=source.read();need(len(data)==v.size,'archive size');fd=os.open(dest,os.O_WRONLY|os.O_CREAT|os.O_EXCL,v.mode)
   with os.fdopen(fd,'wb') as out:out.write(data)
evidence=root/'evidence';need(sha((evidence/'MANIFEST.json').read_bytes())==e['restricted_manifest_sha256'],'restricted manifest');env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON') and not k.startswith('GIT_')};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1');q=subprocess.run([sys.executable,'-B',str(evidence/'VERIFY-PACKET.py')],env=env,capture_output=True);need(q.returncode==0 and not q.stderr,'restricted proof');print('Authenticated restricted evidence restored and evidence-only replay passed.');print('Private restored directory:',str(root));print('Same-machine key custody is not independent recovery; no product validation or closure.')
