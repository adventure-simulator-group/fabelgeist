#!/usr/bin/env python3
"""Dispatch ordering source evidence replay; no product or GPU execution."""
import argparse,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);d[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return d
def path(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/f'{t}.tree').read_bytes();assert oid('tree',b)==t;mode,t=tree(b)[part]
 assert mode=='100644' and oid('blob',data)==t
def manifest(p):
 m=json.loads((p/'MANIFEST.json').read_bytes());actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};assert actual==set(m['files'])
 for n,v in m['files'].items():
  f=p/n;assert H(f.read_bytes())==v['sha256'] and (f.stat().st_mode&0o777)==v['mode']
ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: support manifest (--skip-manifest)')
else:manifest(P);print('support file set, modes and hashes: pass')
root='1eec97de340d9b7debbb30ca0c0fb2240a73b93f';k=(P/'kernel.rs').read_bytes();s=(P/'slow.rs').read_bytes();assert H(k)=='dae1952c339f41ebda108d54286ef154bcb482d6b45879321dbc8bb6f498b274' and H(s)=='80e026906d336daf2078cbeae5c04c49d737da5056542fa81c9fa03e96f2452d';path(root,'crates/fabelgeist-compute/src/kernel/mod.rs',k);path(root,'crates/fabelgeist-gpu/src/data/gpu/compute/pass/mod.rs',s)
for name,source,lo,hi in [('DISPLAY.txt',k,225,299),('slow-1-80.txt',s,1,80),('slow-440-484.txt',s,440,484)]:
 ls=source.decode().splitlines();assert (P/name).read_text()==''.join(f'{i:4d} {ls[i-1]}\n' for i in range(lo,hi+1))
ls=s.decode().splitlines();hits=[{'line':i,'text':ls[i-1]} for i in range(37,485) if re.search(r'\breturn\b',ls[i-1])];assert hits==json.loads((P/'CONTROL-NAV-006-RESULT.json').read_bytes())
print('pinned-root tree-to-blob paths, registered dispatch displays and bounded return search: pass')
if a.base:
 assert H((a.base/'MANIFEST.json').read_bytes())=='1cea51f8a7ee7fdea4c8d3c4c23c4de1311743a53f334a7f4a8f0c9e2fb3012d';manifest(a.base);c=(a.base/'PRIVATE-95e.commit').read_bytes();assert oid('commit',c)=='95e63628f9d70b8dd6e6fede64334696c6995009' and c.splitlines()[0]==b'tree '+root.encode() and (a.base/'adjacent/kernel.rs').read_bytes()==k
 print('separately held base file set and 95e commit-to-root binding: pass')
else:print('NOT CHECKED: root-to-95e-commit binding (provide separately held --base)')
print('Source integrity does not prove device outcomes or validate product behavior.')
