# Dispatch ordering source support

This separately registered source-only follow-up checks the four-lens Lens 5
report's ordering statement. For the radix sort's nonzero `[tiles, 1, 1]`
workgroup request, `KernelBatch::dispatch` either records a fast-path dispatch
or calls `ComputePass::record`; its successful terminal path records the
dispatch before returning. Either branch may fail or be rejected before then.
The later nonzero scan count check is reached only after that call returns
successfully. This is source control-flow evidence, not actual submission,
GPU execution, device acceptance, or a product validation.

`python3 verify.py` checks the manifest, pinned-root tree-to-blob paths and
display transcripts. It does not bind the root to a commit by itself. With
the separately held restricted four-lens evidence, add `--base BASE_DIR` to
verify the base manifest, file set and 95e commit-to-root binding. No product
code, shader, macro, test, fixture, example, build, repair or probe ran.
