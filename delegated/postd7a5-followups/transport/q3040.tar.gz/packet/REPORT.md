# Independent q3040 producer-propagation review

Reviewer: `/root/mhr_character`. This is bounded evidence-only work against
pinned product revision `95e63628f9d70b8dd6e6fede64334696c6995009` and does
not close a queue, lens, ledger, alias inventory or implementation gate. No
product code, build, test, example, fixture, sampler or runtime probe ran.

## Lens, source identity and attribution

The historical 059 obligation `/entries/3040`,
`OBLIGATION-ROOT-L3-EXT-0028-LENS-01`, is Lens 1. The observed working audit
map and focused suite table identify Lens 1 as **producer propagation** and
Lens 6 as type ownership; this review applied the producer-propagation skill.
The separate additive corrections for this reviewer's earlier q2968 and q3016
packets are identified below and do not change their frozen records.

The assigned source is
`crates/adventuresim-world-schema/src/language/initialization.rs:1–54`.
I prospectively registered and personally displayed the full 54 lines at each
of 6533, e275 and 95e. All three per-file Git blobs are
`a190e0fa176474e088a8e002af8671788e76bf33`, SHA-256
`87ffb9656350a955c7a86f75ec43181d59b5a891053f3938da81e8eb5f82d593`;
the separately recovered Root-registered object matches. Same-file identity
does not prove the historical pr-working snapshot or entire tree was clean.
Original 56f and reconstructed dac7d selected q3040 and q3132 bytes match, but
their complete queue streams differ. Checkpoint 3821 remains unrecovered.

The old Root Lens 3 receipt records its own fresh 6533 full-file read; its e275
receipt records qualified same-lens reuse with no fresh read. Both preserved
receipt hashes match their historical references. The q3040 historical Lens 1
entry is pending; a bounded search of three working metadata files located no
exact prior path, which is not a global absence proof. No earlier Lens 3, prior
summary or source identity is converted into my Lens 1 read credit.

## Producer-to-boundary trace

- The producer `language.rs:524–562` derives three vernacular shares and a
  Yiddish incidence into `SettlementLanguageProfile`. The public serialized
  profile stores four raw `u16` fields, and `is_valid` separately checks the
  three-share total equals 10,000 and incidence is at most 1,000
  (`language.rs:495–512`). At the selected importer,
  `strategic/world_import.rs:625–640` requires both validity and equality to
  geographic inference before accepting the imported settlement. Three selected
  demo bootstrap literals (`strategic/mission_bootstrap.rs:947–967`) each have
  a positive 10,000 total. These are selected source safeguards, not proof that
  every persisted profile or constructor follows those routes.
- The initializer retains the aggregate profile as its argument, widens the
  three weights to `u64` for `DeterministicRng::weighted_index` and uses the
  incidence as a numeric comparison (`initialization.rs:6–28`). The inspected
  numerical API actually requests `&[u64]` and returns a sampled index
  (`fabelgeist-determinism/src/stream.rs:104–115`); the `u16` widening at that
  handoff is therefore a legitimate numerical boundary, not a defect merely
  because it uses primitives. `StreamId::rng` accepts a `Seed`, and the shown
  `From<u64> for Seed` is the native seed adapter (`seed.rs:23–45,170–173`).
  Preserve stream names, draw order, weight order and seed bits in any future
  refactor; this review did not run the sampler or establish output equivalence.
- The profile retains untyped basis-point leaves between inference, settlement
  storage, and initialization. `world-schema/src/basis_points.rs:7–30,67–69`
  provides a `UnitBasisPoints` leaf for a fraction of one whole. This is a
  bounded owner-fit/propagation candidate: investigate whether individual
  profile values should retain that semantic leaf from their producer through
  storage until the numeric sampler. It is not a completed migration or an
  automatically counted defect. A leaf alone cannot guarantee the three-way
  sum, the stricter 1,000 incidence limit, or all deserialization guarantees;
  keep those aggregate and admission contracts explicit. Actual feature,
  serializer, native DB and other producer requirements remain open. The
  related conditional zero-profile precondition is already tracked by
  historical q3132 and current `REVIEW-L3-INITIAL-LANGUAGE-PROFILE-WEIGHTS`;
  exact alias or shared-repair decisions remain central.
- `initialization.rs:19–39` maps the sampled index into the existing
  `OralLanguage` roles and writes `OralLanguageHours`; `42–53` returns distinct
  oral and written hour aggregates. Selected `character.rs:2103–2131` stores
  the returned oral aggregate on relocation and intentionally retains the
  existing written state; `2255–2263` obtains both at creation before selected
  literacy policy. The shown path therefore propagates distinct oral/written
  owners through those points; it does not prove all callers, retained-state
  validity or actual execution.
- The initializer accepts a raw character `u64` and converts it into seed bits.
  A private durable character-name-boundary `CharacterId` exists in the higher
  `stdb-module` (`character/name_types.rs:55–78`); the lower world-schema
  initializer cannot simply depend on that upper-layer private type. The exact
  shared identity owner, all adapters and framework constraints are untraced,
  so no replacement, collision or additional finding is asserted.

## Historical relationships and limits

Original q3132 records the all-zero default profile and `weighted_index`/expect
precondition as conditional, not a demonstrated ordinary incident; its
historical text calls the relevant profile `InitialLanguageProfile`, while the
inspected current source type is `SettlementLanguageProfile`. The prior
`ASSESSMENT-LANGUAGE-ADMISSION-95E.json` separately attributes its selected
native sampler and importer evidence and reports the zero-weight failure as a
source-level conclusion; this review preserves that attribution and does not
independently execute or re-read the native rand implementation. The current
working ledger entry remains partial, with all native admissions and aliases
open. A profile whose fields are public can be constructed without invoking
`is_valid`; the selected import safeguard must not be generalized to all paths.

Every support read and its unread complement is in READ-RECEIPT.json; source
bytes retained outside those views do not add read credit. The first attempted
Git-tree evidence script failed during Python parsing before any statement ran;
the corrected proof capture is separately registered. Git-tree membership is
portable from the recorded tree roots, but commit-to-root trust needs an
external pinned repository; raw commit author metadata is not copied. A bounded
working ledger observation and exact original/reconstructed queues are held in
the restricted packet; the public packet summarizes them rather than claiming
byte-identical public replay. No global alias, all-caller, native admission or
product validation claim follows.

Mapping corrections are separately sealed: correction manifest
`d43aa2c992a6a442a4033efeec32cf85b3031e861a31e877e4e82135012862c7` and
field-level clarification manifest
`d0628a68bd03aa12662a3b1ed46d29c482e9e572c61758b25f7692fa1d37a1c5`.
They preserve earlier q2968/q3016 source reads as type-ownership work, not
an automatic Lens 1 producer-propagation disposition.
