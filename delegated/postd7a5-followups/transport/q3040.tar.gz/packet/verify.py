#!/usr/bin/env python3
"""Evidence-only verification; optional external Git and restricted custody."""
import argparse,hashlib,json,pathlib,subprocess,sys

def need(x,msg):
 if not x:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def gitsha(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def lookup(raw,name):
 i=0
 while i<len(raw):
  s=raw.index(b' ',i);z=raw.index(b'\0',s+1);mode=raw[i:s].decode();n=raw[s+1:z].decode();oid=raw[z+1:z+21].hex()
  if n==name:return mode,oid
  i=z+21
 raise ValueError('tree entry absent')
def select(text,index):
 key=text.find('"entries"');need(key>=0,'entries missing');pos=text.find('[',key)+1;decoder=json.JSONDecoder()
 for i in range(index+1):
  while text[pos].isspace() or text[pos]==',':pos+=1
  start=pos;_,pos=decoder.raw_decode(text,pos)
 return text[start:pos].encode()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repository',type=pathlib.Path);ap.add_argument('--restricted',type=pathlib.Path);a=ap.parse_args();p=pathlib.Path(__file__).resolve().parent
 m=json.loads((p/'MANIFEST.json').read_text());e={x['path']:x for x in m['files']};need(not any(x.is_symlink() for x in p.rglob('*')),'symlink')
 found={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file() and x!=p/'MANIFEST.json'};need(found==set(e),'manifest file set')
 for name,row in e.items():
  b=(p/name).read_bytes();need(len(b)==row['bytes'] and sha(b)==row['sha256'],'file identity '+name)
 for pf in ['GIT-TREE-PROOFS.json','MANIFEST-GIT-PROOFS.json']:
  for row in json.loads((p/pf).read_text())['proofs']:
   b=(p/row['source_file']).read_bytes();need(sha(b)==row['sha256'] and gitsha('blob',b)==row['blob'],'blob '+row['path']);cur=row['root_tree']
   for x in row['steps']:
    need(cur==x['tree'],'tree chain');raw=(p/'trees'/(cur+'.tree')).read_bytes();need(gitsha('tree',raw)==cur,'tree hash');mode,cur=lookup(raw,x['entry']);need(mode==x['mode'] and cur==x['oid'],'tree member')
   need(cur==row['blob'],'tree leaf')
   if a.repository:
    root=subprocess.check_output(['git','-C',str(a.repository),'rev-parse',row['revision']+'^{tree}'],text=True).strip();need(root==row['root_tree'],'external anchor')
 for rf in ['READ-RECEIPT.json','MANIFEST-READ-RECEIPT.json']:
  for r in json.loads((p/rf).read_text())['reads']:
   name=r['label'];file=p/(name+'.source' if name.startswith(('old-','current-')) else 'support/'+name+'.source');lines=file.read_text().splitlines();need(sha(file.read_bytes())==r['source_sha256'] and len(lines)==r['eof'],'read source')
   reg=json.loads((p/r['registration']).read_text());sources=reg['sources']
   if r['registration']=='SUPPORT2-SOURCE-REGISTRATION.json':planned=next(x['planned_ranges'] for x in sources if x['source']['label']==name)
   else:planned=next(x['planned_ranges'] for x in sources if x['label']==name)
   need(planned==[x['range'] for x in r['displayed']],'prospective ranges');covered=set()
   for v in r['displayed']:
    lo,hi=v['range'];b=''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();need((p/v['file']).read_bytes()==b and sha(b)==v['sha256'],'view');covered.update(range(lo,hi+1))
   unread={i for lo,hi in r['unread_complement_for_this_registration'] for i in range(lo,hi+1)};need(covered.isdisjoint(unread) and covered|unread==set(range(1,len(lines)+1)),'unread complement')
 if a.restricted:
  h=json.loads((p/'HISTORICAL-SUMMARY.json').read_text());d=a.restricted/'historical'
  for name,key in [('queue-original-56f','original_queue_sha256'),('queue-reconstructed-dac7d','reconstructed_queue_sha256')]:
   b=(d/(name+'.json')).read_bytes();need(sha(b)==h[key],'queue stream')
   for n,want in h['selected_raw_sha256'].items():need(sha(select(b.decode(),int(n)))==want,'queue selected')
  need(sha((d/'registered-6533.source').read_bytes())==h['source_sha256'],'recovered source')
  for item in h['historical_receipts']:need(sha((d/pathlib.Path(item['path']).name).read_bytes())==item['sha256']==item['expected'],'historical receipt')
  need(sha((d/'ledger-observed.json').read_bytes())==h['working_ledger_sha256'],'working ledger observation')
 print('Evidence-only check passed: file set, source displays, unread complements, and tree/blob proofs.')
 print('External Git anchors '+('checked.' if a.repository else 'NOT checked; supply --repository.'))
 print('Restricted queue/source/receipt replay '+('checked.' if a.restricted else 'NOT checked; supply --restricted.'))
if __name__=='__main__':
 try:main()
 except Exception as e:print('Evidence verification FAILED:',str(e),file=sys.stderr);sys.exit(1)
