#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
r=Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('FAIL optimization')
def need(x,m):
 if not x:raise SystemExit('FAIL '+m)
def sha(b):return hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--inputs',type=Path);a.add_argument('--previous-review',type=Path);a.add_argument('--earlier-evidence',type=Path);a=a.parse_args();m=json.loads((r/'MANIFEST.json').read_bytes());rows=m['files'];names={x['path'] for x in rows};need(len(names)==len(rows) and {x.name for x in r.iterdir()}==names|{'MANIFEST.json'},'membership')
for e in rows:
 f=r/e['path'];need(f.is_file() and not f.is_symlink(),'type');b=f.read_bytes();need(len(b)==e['bytes'] and sha(b)==e['sha256'],'identity')
x=json.loads((r/'REVIEW.json').read_bytes());env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON') and not k.startswith('GIT_')};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
if a.previous_review:
 need(sha((a.previous_review/'MANIFEST.json').read_bytes())==x['earlier_public_manifest_sha256'] and sha((a.previous_review/'REPORT.md').read_bytes())==x['earlier_public_report_sha256'],'prior review binding');print('Earlier public review bound.')
else:print('Earlier public review not checked; supply --previous-review.')
if a.inputs:
 f=a.inputs/'VERIFY-DRAFT.py';need(sha(f.read_bytes())==x['restricted_draft_verifier_sha256'],'draft verifier');q=subprocess.run([sys.executable,'-B',str(f)],env=env,capture_output=True);need(q.returncode==0 and not q.stderr,'draft check');print('Exact predecessor/successor delta and failure metadata verified.')
else:print('Draft delta not checked; supply --inputs.')
if a.earlier_evidence:
 f=a.earlier_evidence/'VERIFY-PACKET.py';need(sha((a.earlier_evidence/'MANIFEST.json').read_bytes())==x['earlier_restricted_manifest_sha256'] and sha(f.read_bytes())==x['earlier_restricted_verifier_sha256'],'earlier evidence binding');q=subprocess.run([sys.executable,'-B',str(f)],env=env,capture_output=True);need(q.returncode==0 and not q.stderr,'earlier evidence');print('Earlier sealed source/history proof passed.')
else:print('Earlier source/history proof not checked; supply --earlier-evidence.')
print('Additive successor review verified; no queue/lens/product closure.')
