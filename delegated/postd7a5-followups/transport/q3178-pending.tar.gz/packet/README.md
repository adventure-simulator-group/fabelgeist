# q3178 evidence-only public successor

`REVIEW.md` reconstructs the independently attributed restricted report
after redacting its reviewer identity. The exact restricted original, full
historical queues, receipts, handoff map and raw Git commit metadata must be
separately held; they cannot be recovered from this packet. The crosswalk
records whole-file hashes and byte offsets without removed-value digests.

`python3 verify-public.py` checks the public manifest, selected tree/source
objects and saved displays. It cannot bind roots to commits or replay original
queue membership and historical attribution without the separately held
restricted packet. Add `--private DIR --anchors DIR` for full evidence-only
replay. The verifier does not execute product code, macros or tests. See
`READ-LIMITS.json` for historical search and recovery qualifications.
