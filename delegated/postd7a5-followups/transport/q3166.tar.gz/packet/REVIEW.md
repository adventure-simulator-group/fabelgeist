# q3166 — independent historical Lens 9 enum-shapes review

Reviewer: [independent reviewer; identity separately held]. This later source-only review is outside the
frozen checkpoint. No product code, shader, renderer, macro, test, example,
build or runtime probe was executed.

## Scope and provenance

The recovered handoff map names Lens 9 `enum-shapes`, and the matching
focused skill was read. Original and reconstructed 059 q3166 selected
entries are byte-identical but retain distinct queue provenance. The
original entry records `own-lens-proof-qualification-or-read-pending` and
zero prior body/population credit. Independent raw Git commit/tree/blob
proofs bind `crates/fabelgeist-armor/src/gpu/helmet/surface.rs` at
6533e444fa37552927070cc8d8190907fd3b413e,
e2755a732c84e67296b5e3441a4259a84f461b2f and
95e63628f9d70b8dd6e6fede64334696c6995009 to the same blob, SHA-256
`d6e8b3b39d21c87e2a7c4d51f25b2e9e57b2a884a87b2b8fad17b24b1a2d1087`,
EOF 235. The full file was independently displayed for this Lens 9 review at
each revision. The selected helmet subtree also matches; this is not a
whole-tree identity claim.

Normalized 774 catalog row 2188 recovers the 6533 object and says source
recovery alone gives no audit coverage. The recovered historical Lens 9
nested state does not list this role among its scoped-range exceptions;
that absence does not establish its personal reader, complete body range, or
e275 review. The bounded filename/path searches did not recover an
individually attributable same-Lens 9 read. The nested state is separately
hash-identified and not shown directly hash-linked to the map-verified root
state. Do not promote these historical summaries into checkpoint 3821.

Original 6533 Lens 2 receipt attributes a fresh 1–235 read to Root; Root's
separate Lens 3 receipt also reports a fresh untruncated 1–235 read. Its e275
Lens 3 receipt is qualified same-Lens 3 reuse of 1–235 with zero fresh
current personal lines. Adler's separate Lens 11 receipt records a fresh
1–235 source scope under a prospective registration. None supplies Lens 9
coverage. Historical source-extension rows for 6533 helmet codes and shape
were registered as Lens 7 receiver dependencies and explicitly preserve
independent reconciliation for other lenses.

## Candidate: host tag and payload are independent

`gpu/helmet/surface.rs:59–74` exposes the helmet-local
`CoordSurface::vertex(kind: VertexKind, values: [f32; 3])`, then places the
tag and supplied payload together in `[f32; 4]`. The first three payload
slots are not typed by `kind`. For example, :153–170 builds a FanPoint as
`[latitude, across, 0]` and a FanCrest as `[side, base-as-0-or-1, across]`.
The host API can represent a tag paired with another kind's float layout;
this is a source-level type-shape/migration candidate, not evidence that a
selected caller actually does so or that a render fails.

`gpu/helmet/codes.rs:5–26,121–133` declares the fieldless `VertexKind` and
the text-generating macro for matching WGSL constants. The source-only WGSL
consumer at `gpu/helmet/shape.rs:199–226,504–537` dispatches on the packed
kind and reads FanPoint's `coord.y,z` versus FanCrest's `coord.y,z,w`; the
crest branch interprets `coord.z > 0.5` as the base-width choice. For a
hypothetical mismatched FanCrest payload, these documented slot meanings no
longer follow the tag. This is reasoning from source, not shader execution.

A possible connected later repair is a helmet-host variant with its own
fields for each coordinate layout (for example `FanPoint { latitude, u }`
and `FanCrest { side, width, u }`), with exhaustive conversion to the
existing numeric tag/float layout at the actual GPU adapter. An explicit
side choice could prevent the private `Latitude::Crest`'s arbitrary f32 side
values at that host boundary. Preserve the single generated wire-code owner,
`-1/+1` side and `0/1` width mapping, and actual payload order. This is a
repair candidate for central reconciliation, not an implementation or an
accepted unique count.

There is a crucial adjacent alternate layout. `gpu/helmet/burgonet.rs:
301–316,339–341` creates cheek coordinates as `[v, angle, tab, relief]`,
then sets `shell.values[0] = CHEEK_SHELL`; `shape.rs:475–506` chooses the
cheek consumer before ordinary kind decoding. These coordinates are not
ordinary VertexKind records. The source can separately represent a shell
selector and coordinates that do not belong together; the selected cheek
producer sets the selector. Whether a helmet-specific typed shell/layout
owner should couple those states is open, and any later repair must preserve
this path rather than treating all `CoordSurface::coord` calls as tagged
vertices or imposing helmet meaning on the generic coordinate-shell API.
The literal-name search was bounded to the selected helmet subtree, not a
global caller or alias inventory.

`surface.rs:18–55` represents regular versus crest rows as variants. The
selected crest builder supplies all four combinations of side and base/half;
those two axes are independent and no invalid cross-combination was shown.
The `crest > 0` and optional fluting predicates at :124–143 are independent
choices. `connect(..., periodic)` at :77–94 is an immediate topology mode,
not established as a tag beside an unrelated conditional payload.
`gpu/coord.rs:31–62,161–190` provides a separate generic shell and a
payload-bearing `CoordExtrusion::Radial`; reflection and optional hinge are
independent inputs encoded at the device boundary. Their whole-system
validity and all other callers were not audited here.

## Relationships and remaining work

Original 059 q2404 is Root's separate Lens 2 existing-owner-fit review: it
did not establish an existing scalar-owner reuse defect for these native
coordinates. That narrower result does not decide this Lens 9 host
tag/payload question. q3141 and immutable dac7d ledger entry 471 concern
Root's separate paired-ring/fluting topology-admission question and later
bounded source reasoning; they are not asserted aliases. Current aliases,
other producers/consumers, any occurrence of a mismatched payload, and any
GPU/product effect remain open. q1814 appeared in the broad path-context
search; its selected unresolved issue concerns another Lens 12 scope and is
not treated as this candidate.

Any future acceptance work should establish correct variant-specific host
construction and encoding for each selected helmet layout, explicitly retain
the cheek-shell mode/payload relation and generated code mapping, and then
validate behavior separately. No such repair or validation occurred here.
Target lines 220–235 are test source read only. The normalized 774 catalog is
not its missing pre-export original. Missing checkpoint 3821, 440
reconstructed records, SOURCE004 and 73 nontext/no-positive-EOF obligations
remain qualified. This scoped review does not close the lens or queue.

## Evidence limits

READ-LIMITS.json records the truncated Lens 3 historical metadata display and
registered bounded repeat, partial symbol navigation, a benign search-pattern
warning, and the bounded historical-search and provenance limits. All target
and selected adjacent source displays were complete. The evidence-only
verifier checks file identities and display linkage, not semantic findings.
Full original/reconstructed 059 queue membership needs separately held
anchors; private originals cannot be reconstructed from the public successor.
