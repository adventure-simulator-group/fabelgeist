#!/usr/bin/env python3
"""q3166 evidence verification only; no product, macros or shaders are executed."""
import argparse,hashlib,json,re,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def entries(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);d[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return d
def path(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/f'{t}.tree').read_bytes();assert oid('tree',b)==t;mode,t=entries(b)[part]
 assert mode=='100644' and oid('blob',data)==t
ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: public packet manifest (--skip-manifest)')
else:
 m=json.loads((P/'MANIFEST.json').read_bytes());found={str(f.relative_to(P)) for f in P.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};assert found==set(m['files'])
 for n,v in m['files'].items():
  f=P/n;assert H(f.read_bytes())==v['sha256'] and (f.stat().st_mode&0o777)==v['mode']
 print('public file set, modes and manifest hashes: pass')
proof=json.loads((P/'SOURCE-PROOF-002-RESULT.json').read_bytes());base='crates/fabelgeist-armor/src/gpu/'
for r in proof['rows']:
 label=r['label'];root=r['chain'][0]['tree'];b=(P/'source'/f'{label}.rs').read_bytes();assert H(b)=='d6e8b3b39d21c87e2a7c4d51f25b2e9e57b2a884a87b2b8fad17b24b1a2d1087' and len(b.splitlines())==235 and b.endswith(b'\n');path(root,base+'helmet/surface.rs',b)
 assert (P/'displays'/f'{label}-1-235.txt').read_text()==''.join(f'{i}: {v}\n' for i,v in enumerate(b.decode().splitlines(),1))
 for n in ['codes','shape','parts','burgonet']:path(root,base+'helmet/'+n+'.rs',(P/'adjacent'/('helmet-'+n+'.rs')).read_bytes())
 if label in ['e275','95e']:path(root,base+'coord.rs',(P/'adjacent/gpu-coord.rs').read_bytes())
for f in (P/'adjacent-displays').iterdir():
 m=re.fullmatch(r'(.+\.rs)-(\d+)-(\d+)\.txt',f.name);assert m
 name,lo,hi=m.group(1),int(m.group(2)),int(m.group(3));ls=(P/'adjacent'/name).read_text().splitlines();assert f.read_text()==''.join(f'{i:4} {ls[i-1]}\n' for i in range(lo,hi+1))
lens=json.loads((P/'LENS-MAP-SELECT.json').read_bytes());assert lens['row']['number']==9 and lens['row']['name']=='enum-shapes' and H((P/'SKILL-ENUM-SHAPES.md').read_bytes())=='964ebea7b08a545b5abcabf605c22b92ac0dbb09ed79e6f79651ea2f141a3500'
print('selected tree-to-source objects, complete target and adjacent displays, focused skill: pass')
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if not a.private:print('NOT CHECKED: commit-to-root binding, original handoff map, full 059 queue membership, historical attribution/receipt linkage, private reconstruction and dac7d ledger membership; separately held restricted packet required')
else:
 assert H((a.private/'MANIFEST.json').read_bytes())=='216e623b50039cfd68be4d1d7dd194c0bff8b2fbd7fef40bcd1eea48b666b336'
 c=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes());old=(a.private/c['original_file']).read_bytes();assert H(old)==c['original_whole_file_sha256'];out=bytearray();last=0
 for r in c['replacements']:
  i=r['original_byte_offset'];n=r['original_byte_length'];assert i>=last;out+=old[last:i]+r['replacement'].encode();last=i+n
 out+=old[last:];assert bytes(out)==(P/c['successor']).read_bytes() and H(out)==c['successor_whole_file_sha256']
 print('restricted manifest anchor and reconstructed report crosswalk: pass')
 cmd=[sys.executable,str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,end='')
 if r.returncode:print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
print('Evidence integrity does not prove semantic findings, recover missing checkpoint 3821, or validate the product.')
