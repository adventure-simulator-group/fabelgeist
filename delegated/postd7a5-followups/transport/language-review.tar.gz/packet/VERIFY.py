#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
r=Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('FAIL optimization')
def need(x,m):
 if not x:raise SystemExit('FAIL '+m)
def sha(b):return hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--restricted',type=Path);a=a.parse_args();m=json.loads((r/'MANIFEST.json').read_bytes());files=m['files'];names={x['path'] for x in files};need(len(names)==len(files) and {x.name for x in r.iterdir()}==names|{'MANIFEST.json'},'membership')
for e in files:
 p=r/e['path'];need(p.is_file() and not p.is_symlink(),'type');b=p.read_bytes();need(len(b)==e['bytes'] and sha(b)==e['sha256'],'identity')
x=json.loads((r/'REVIEW.json').read_bytes());need(x['product_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and x['personal_current_distinct_lines']==473,'review facts')
if a.restricted:
 p=a.restricted/'VERIFY-REVIEW.py';need(sha(p.read_bytes())==x['restricted_verifier_sha256'],'restricted verifier');env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON') and not k.startswith('GIT_')};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1');q=subprocess.run([sys.executable,'-B',str(p)],env=env,capture_output=True);need(q.returncode==0 and not q.stderr,'restricted proof');print('Restricted source and history identity proof passed.')
else:print('Restricted source and history identity proof not checked; supply --restricted.')
print('Public review packet verified; no queue, lens or product-validation closure.')
