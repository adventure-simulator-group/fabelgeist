#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
r=Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('FAIL optimization')
def need(x,m):
 if not x:raise SystemExit('FAIL '+m)
def sha(b):return hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--restricted',type=Path);a.add_argument('--predecessor',type=Path);a=a.parse_args();m=json.loads((r/'MANIFEST.json').read_bytes());rows=m['files'];names={x['path'] for x in rows};need(len(names)==len(rows) and {x.name for x in r.iterdir()}==names|{'MANIFEST.json'},'membership')
for e in rows:
 f=r/e['path'];need(f.is_file() and not f.is_symlink(),'type');b=f.read_bytes();need(len(b)==e['bytes'] and sha(b)==e['sha256'],'identity')
x=json.loads((r/'REVIEW.json').read_bytes());c=json.loads((r/'CORRECTION.json').read_bytes());need(x['predecessor_manifest_sha256']==c['prior_public_manifest_sha256'] and 'same delegate' in (r/'REPORT.md').read_text(),'attribution correction')
if a.predecessor:
 need(sha((a.predecessor/'MANIFEST.json').read_bytes())==c['prior_public_manifest_sha256'] and sha((a.predecessor/'REPORT.md').read_bytes())==c['prior_report_sha256'],'predecessor binding');print('Preserved predecessor identities verified.')
else:print('Predecessor not checked; supply --predecessor.')
if a.restricted:
 f=a.restricted/'VERIFY-REVIEW-v2.py';need(sha(f.read_bytes())==x['restricted_verifier_sha256'],'restricted verifier identity');env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON') and not k.startswith('GIT_')};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1');q=subprocess.run([sys.executable,'-B',str(f)],env=env,capture_output=True);need(q.returncode==0 and not q.stderr,'restricted proof');print('Original restricted evidence proof passed.')
else:print('Restricted proof not checked; supply --restricted.')
print('Corrected public attribution verified; no queue/lens/product closure.')
