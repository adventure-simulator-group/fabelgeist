#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,sys
r=Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('FAIL: disable optimization')
def need(v,m):
 if not v:raise SystemExit('FAIL: '+m)
def sha(b):return hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser()
for x in ('review','v3','v4','correction'):a.add_argument('--'+x,type=Path)
a=a.parse_args();m=json.loads((r/'MANIFEST.json').read_bytes());rows=m['files'];names={x['path'] for x in rows}
need(len(names)==len(rows) and {p.name for p in r.iterdir()}==names|{'MANIFEST.json'},'packet membership')
for e in rows:
 p=r/e['path'];need(p.is_file() and not p.is_symlink(),'file type');b=p.read_bytes();need(len(b)==e['bytes'] and sha(b)==e['sha256'],'file identity')
c=json.loads((r/'CORRECTION.json').read_bytes());need(c['mapping']=={'lens_1':'producer propagation','lens_6':'type ownership','basis':c['mapping']['basis']},'mapping')
for n,key in (('review','report_sha256'),('v3','draft_v3_sha256'),('v4','draft_v4_sha256'),('correction','v4_correction_sha256')):
 f=getattr(a,n)
 if f:need(sha(f.read_bytes())==(c['old_review'][key] if n=='review' else c['successor_review'][key]),n+' identity')
if a.v4:
 d=json.loads(a.v4.read_bytes());need(d['ledger_relationships'][1]['lens'] is None and 'provisional' in d['ledger_relationships'][1]['lens_assignment'].lower() and 'not count q2968' in d['counts']['assessment_count_qualification'],'v4 semantics')
print('Withdrawal packet verified; supplied predecessor/successor identities checked.')
print('Omitted optional inputs are not verified; no Lens 1 credit or closure is asserted.')
