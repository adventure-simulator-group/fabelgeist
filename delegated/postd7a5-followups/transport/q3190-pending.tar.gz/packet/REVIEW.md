# q3190: independent historical Lens 9 assessment

Reviewer: [independent reviewer; identity separately held]. This is newly assessed work; it is not an
original 059 record, an historical delegate's finding, a 3821 checkpoint, a
repair, or a product validation.

## Scope and provenance

Original 059 /entries/3190 and the separately reconstructed 059 entry are
byte-identical (SHA-256 0029a819e95794d5192cba9b597aaee7d9772b90056444903de293738e9d31bb).
The historical queue names OBLIGATION-ROOT-L3-EXT-0038-LENS-09, with no
own-lens body or population credit and own-lens proof or reading pending.
The recovered handoff map selects Lens 9, enum-shapes, and the preserved
focused skill. This assessment follows that lens independently. Source
identity and three pinned commits are established by saved raw commit, tree,
and blob bytes; the 95e commit was separately recovered because the live
shared object database did not supply that commit. Each target file is the
same Git blob cc2b45a9bad82995f753638c67df97f0d7a12234, SHA-256
2cf6b4446ab00dce84c8b3169d9685d3b2e304b869f4c25d0e4322c7bedf9634,
11,495 bytes, 327 lines, newline at EOF. Each 1–327 historical 6533 and e275
and pinned 95e view was prospectively registered and read in complete chunks
by this reviewer. Identical target file and sort subtree are not evidence that
the entire historical and pinned trees are equal.

The normalized 774 source catalog identifies source original 2247 and its
exact recovered bytes; it states source recovery rather than review credit.
The map-anchored historical Lens 9 handoff summarizes inherited populations
and named receipts, with qualifications; the separately recovered nested state
has no exact 2247 scoped-range exception, but its direct link to the map root
was not established. A bounded filename/index search of captured historical
receipts found no individual same-lens target-body receipt; this does not
establish historical noncoverage or negate the summarized inherited scope.
Adler's Lens 11 registration 1108 prospectively includes 1–327, specifically
noting the mandatory all-13 extension 306–327 beyond raw metadata 1–305;
Adler's read 356 records a fresh full 1–327 read at 6533. Root's Lens 2 and
Lens 3 6533 receipts also record fresh 1–327 reads; Root's e275 Lens 3
receipt qualifies reused identical source, with zero fresh e275 lines. These
are separately attributed foreign-lens records, not this Lens 9 reading.
Neither e275 nor any earlier state is promoted to checkpoint 3821; 3821
remains missing. The recovered 059 and normalized 774 carry their existing
missing-pre-export and reconstruction qualifications, including SOURCE004 and
73 nontext/no-positive-EOF obligations. No global lens or queue closure is
claimed.

## Source observations and disposition

- `crates/fabelgeist-compute/src/sort/mod.rs:84–142`: WGSL source text
  computes `in_range` locally from the lane index and count. Inactive lanes
  supply a sentinel digit to shared storage; source branches guard the live
  loads and final writes. This is an execution predicate and temporary lane
  representation, not a retained application mode tag. This textual reading
  does not prove shader execution, synchronization or backend correctness.
- `sort/mod.rs:144–196`: `SortScratch` has key, value and histogram buffers,
  a scan scratch and capacity. `new` constructs them together; `ensure`
  returns `Result<bool>` immediately to indicate whether it reallocated.
  That result does not accompany a retained optional payload in this file.
  Public buffers are independently replaceable while capacity and scan are
  private: this is the separate previously recorded aggregate/admission
  question, not a newly asserted enum-shape defect or reachable failure.
- `sort/mod.rs:219–305`: `passes_for` derives a count from significant bits;
  `record` returns early for counts <= 1, checks capacity and input buffer
  size for larger counts, swaps key/value buffer pairs after each pass, and
  copies back on odd parity. Parity is computed from the pass count rather than
  retained as a tag. Pair alignment, capacity, aliasing and numerical limits
  are aggregate or admission questions; this reading establishes no need to
  encode them as mutually exclusive variants.
- `sort/mod.rs:198–217,308–327` stores compiled histogram, scan and scatter
  passes and exposes the wrapper that submits a batch; the test module
  declaration was read, not the child test source. No stored semantic flag with
  a conditionally meaningful neighboring payload or new enum-shape defect is
  substantiated in this assigned source. Other call sites, formats and policy
  are not thereby cleared.
- Minimal pinned adjacent source: `prefix_sum.rs:19–52,162–211` declares a
  scan *element* count and its own private scratch/ensure; it does not itself
  prove sorted-key count is the same role. `lib.rs:44–52,74–81` exports the
  two owners. `vertex_normals.rs:210–255,271–294,298–350` shows one selected
  caller that constructs private sort scratch for corner capacity and passes
  its key/corner buffers, count and bit width to `record`, before consuming
  output keys. This is one source path, not an inventory of all producers.

## Relationships and open questions

Original 059 q3142 (`REVIEW-L3-RADIX-SCRATCH-BUFFER-ADMISSION`, Root) already
records public scratch-buffer versus private-capacity admission and separates
the extreme histogram-count overflow question. It requires actual writers and
device contracts before asserting ordinary inconsistent-scratch reachability.
Original q2406 (Root, Lens 2) distinguishes the generic key count and payload
from the typed histogram scan count; dac7d ledger row 510 preserves this as
an owner-fit question with current reuse qualified. Original q301 and q302
(Segovb Lens 12, delegate [original delegate; identity separately held] at 6533) retain distinct
capacity-error and input-extent-error first predicates; dac7d row 509 groups a
failure family without asserting aliases. Dac7d row 514 records a conditional
large-dispatch dimension concern and row 1010 a separate prefix folded-grid
candidate; retain their distinct first operations and source/reachability
qualifications. The single selected caller does not prove all writers, exact
aliases, buffer/device acceptance, supported bit/count policy, runtime shader
behavior, or the actual application populations. Central reconciliation owns
any ledger decisions; no new defect count or repair is asserted here.

## Read and recovery limits

A small adjacent symbol-location display was inadvertently emitted before its
separate display registration. UNREGISTERED-011 preserves the source lines and
scope; later registered windows do not erase that lapse. A historical L11
full-document display was tool-truncated; the captured whole original bytes and
a separately registered exact 2247 projection are retained. Other deliberate
metadata output caps, the failed `python` command and the corrected missing
queue filename probe are recorded. Filenames-only history searches excluded
compressed evidence; a permissions-limited scratch search was not exhaustive.
No product code, test, shader, macro, fixture, example, build, repair or runtime
probe was executed. Evidence replay checks bytes and relationships, not the
interpretations, missing checkpoint recovery, or product behavior.
