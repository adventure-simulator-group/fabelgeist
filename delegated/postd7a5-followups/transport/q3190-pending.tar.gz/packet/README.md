# q3190 public-safe reconstructed evidence

This packet is a newly assessed source-only Lens 9 review and a privacy-reviewed
reconstruction of a separately held restricted evidence packet. The complete
originals, original queue anchors, commit bytes and personal attribution are
not recoverable solely from this successor. The crosswalk uses whole-file
identities and offsets; it contains no digest of an individual removed path.

`python3 verify-public.py` verifies this manifest, selected tree-to-blob proofs,
source ranges, adjacent windows and skill bytes. Without separately held
originals it cannot bind trees to commits, establish exact original queue and
record membership, verify historical read attribution, or reconstruct private
bytes. For the separately held packet and both full queue anchors, use
`python3 verify-public.py --private RESTRICTED_DIRECTORY --anchors ANCHOR_DIRECTORY`.
The verifier checks the restricted file set before running its evidence-only
verifier. Omit `--anchors` to leave full-queue membership unchecked.

The named source lines are text, including WGSL and macro input. No product
code, test, fixture, shader, macro, example, build, repair or runtime probe ran.
No test-source child module was reviewed. This is not a global lens closure,
a product validation, a unique defect count, or a recovery of checkpoint 3821.
A prior unregistered adjacent symbol display and a truncated historical
document view are preserved and qualified in the evidence.
