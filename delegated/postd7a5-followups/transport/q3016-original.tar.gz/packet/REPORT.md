# Independent q3016 type-ownership review

Reviewer: `/root/mhr_character`. This is a bounded source review at pinned
`95e63628f9d70b8dd6e6fede64334696c6995009`; it postdates the frozen checkpoint
being verified. It does not close a lens, queue, ledger, alias inventory or
implementation gate. No product code, build, test, fixture, or probe ran.

## Scope, identity and historical attribution

Recovered original 059 `/entries/3016`,
`OBLIGATION-ROOT-L3-EXT-0026-LENS-01`, requests historical Lens 1 for
`crates/adventuresim-world-schema/src/bestiary.rs:1–330` at 6533 and an e275
revisit. I prospectively registered and personally displayed the whole file in
five bounded chunks at each of 6533, e275, and 95e, including test-module text
without running it. Each revision has Git blob
`62768db020d13ac0e30019ff05a82fa85e2322d8`, SHA-256
`0a8870d89db5190ae5b70aaffd93d7511b144e4861f37ffd649c62f464a3d2b7`, and
EOF 330. A separately recovered source object named by the historical Root
registration also matches these bytes. This proves per-file identity only: the
recorded pr-working snapshot had unrelated changes and is not asserted clean.
The original 56f and reconstructed dac7d q3016 selected raw bytes match, while
the full queue streams differ. Missing checkpoint 3821 is not reconstructed
or credited by this equality.

Earlier original role 2157 registered 1–112 and 140–285; an independent
registration added 113–139 and 286–330. Adler `READ-L11-338` records its own
fresh full-file Lens 11 read. Root's Lens 3 receipt records a fresh full-file
6533 read and an e275 same-lens reuse with no fresh e275 lines. Root's Lens 2
receipt inherited the original supplier's 1–112 and 140–285 and personally
read the two gap ranges; its e275 receipt reused that qualified evidence.
`ASSESSMENT-L01-HISTORICAL-2157.json` separately records a previous personal
Lens 1 historical full-body read and current content via identical historical
bytes, with an empty current-personal range. Its selected metadata does not name
that reader. None of those reads are attributed to this reviewer or promoted to
3821. Exact receipt hashes and remaining qualifications are in the history
summary and restricted originals.

## Source findings and nonfindings

- `bestiary.rs:11–29,154–171` defines the shared category and study-hours
  owners in world-schema. `adventuresim-core/src/bestiary.rs:1–4,366–385`
  re-exports and consumes those exact types; tactical categories similarly use
  the shared category (`tactical-core/src/player.rs:123–134`). This selected
  evidence supports shared lower-layer ownership; it does not establish every
  producer or rule out another owner across the entire repository.
- A separate, bounded producer-propagation question remains at the tactical
  boundary. `tactical-server/src/player_projection.rs:537–565,579–631` shows
  an admitted connected-player projection copying the 13 bestiary fields into
  tactical `Skills`. The `Skills` component itself retains 13 separate `f32`
  fields (`tactical-core/src/player.rs:277–318`) and reconstructs a shared
  `BestiaryHours` for the category consumer (375–391,433–435). Default
  construction also copies the same fields from starting-character study
  (320–365). If no framework or serialization contract requires the flattened
  form, this is a concrete opportunity to retain the shared hours owner through
  tactical state. It does not demonstrate value corruption or product failure.
  `Skills` derives Bevy `Component`, `Reflect`, and Serde; the shown shared
  `BestiaryHours` declaration does not list a `Reflect` derive. Whether another
  implementation, required framework representation, replication consumer or
  adapter justifies the layout remains unverified. Preserve all category values
  and effective-study behavior in any future work. No new count or global alias
  decision is assigned here.
- `adventuresim-stdb-client/src/bestiary_hours_type.rs:1–27` and
  `character_skills_type.rs:1–45` identify generated SATS wire representations.
  `strategic-web/src/spacetimedb/types.rs:450–455,1085–1100,1466–1483,1905–1920`
  adapts generated values to the shared owner and delegates calculations. This
  selected transport boundary is not evidence of a competing hand-written
  semantic owner or a reason to edit generated bindings.
- The category is a diagnostic-study category, not automatically equivalent to
  a generic skill, threat identity, or creature species. The inspected trait
  `adventuresim-core/src/skill.rs:1098–1130` exposes a default that ignores its
  category and returns the generic Bestiary skill; the selected tactical
  implementation overrides that default. Other implementations, supported
  dispatch and policy remain outside this bounded trace; no runtime conclusion
  follows from the default alone.
- The source exposes public `f32` fields and a finite/range predicate
  (`bestiary.rs:154–185`); direct mutation and a one-pass effective computation
  are at 206–240. Existing current ledger
  `REVIEW-L3-BESTIARY-EXPERIENCE-ADMISSION` and original q3130 already retain
  the conditional invalid-input question, including a NaN direct-target gate;
  no invalid ordinary retained state was established here. Current ledger
  `REVIEW-L2-BESTIARY-CATEGORY-OWNER-95E` separately records a curriculum
  category text/typed-owner question, with alias, producers and policy open.
  This review does not transfer those earlier source reads or assign a duplicate
  count. Prior assessment notes the existing test source expects correlated
  effective hours may reach or exceed mastery; the comment at 4–8 alone does
  not establish a new enforced global effective-hours cap.

## Limits and recovery

Exact selected queue slices for q2373, q2455, q3016 and q3130 match between the
original and reconstructed queue streams; the complete streams differ.
Historical records, the observed working ledger and selected prior assessments
are retained restricted. The ledger locator inspected 1,093 entries in the
observed working file (its hash is recorded); it is not a complete alias search
or a claim that a changing working file is a committed checkpoint. The prior
Lens 2 supplier, Root and Adler readers retain their original distinct scopes.

An unregistered broad history filename search emitted a large truncated result;
it was navigation only and supplies no source or record credit. Selected
historical fields were separately registered and displayed; one prior-assessment
support list was intentionally output-limited, and no whole-list credit is
claimed. A first tree-proof script failed to parse before executing any
statement; a corrected capture was separately recorded. Support source read
ranges and unread complements are enumerated per registration in
READ-RECEIPT.json; overlapping windows remain separate. Git proofs bind the
source blobs to trees; revision-to-root identity needs a separately trusted
pinned repository, since commit author objects are not copied. The public
packet is a privacy-reviewed reconstruction and excludes exact unredacted
queue streams; the restricted packet retains them.
