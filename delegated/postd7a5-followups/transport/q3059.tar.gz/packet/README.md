# q3059 evidence-only public successor

`REVIEW.md` is a privacy-redacted reconstruction of the independently
attributed restricted report. The exact restricted original, predecessor,
manifest, historical queue anchors, full handoff map, earlier receipts and
raw Git commit metadata must be separately held; they cannot be recovered
from this successor. The crosswalk records only whole-file hashes and offsets,
without individual removed-value digests.

`python3 verify-public.py` verifies the public manifest, selected tree and
source objects and display transcripts. It cannot bind those tree roots to
commits, verify the full original queues or historical attribution without
the restricted original. Add `--private DIR --anchors DIR` to replay those
checks when those separate originals are available. These scripts verify
evidence, not the product or the interpretation. See `READ-LIMITS.json` for
registration, truncation, failed lookup and empty-artifact qualifications.
