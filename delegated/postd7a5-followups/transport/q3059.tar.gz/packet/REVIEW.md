# q3059 — independent historical Lens 9 enum-shapes review

Reviewer: [independent reviewer; identity separately held]. This later source-only assessment is outside
the frozen checkpoint. Source and evidence inspection does not run the product.

## Scope and provenance

The recovered handoff map names Lens 9 `enum-shapes`; the matching focused
skill was read. Original and reconstructed 059 q3059 selected entries have
the same exact bytes and distinct queue provenance. The original record says
`own-lens-proof-qualification-or-read-pending`, zero own-lens body/population
credit, and e275 own-lens evidence still required. Independent commit/tree/blob
proofs bind `crates/adventuresim-tactical-server/src/mission/enrollment.rs`
at 6533e444fa37552927070cc8d8190907fd3b413e,
e2755a732c84e67296b5e3441a4259a84f461b2f, and
95e63628f9d70b8dd6e6fede64334696c6995009 to the same 189-line blob, SHA-256
`9d6646ad8d4c3da14afcf544a8426c44afd33921fc4c39d20f4e2c09a49aa5f1`.
All 189 lines were independently displayed at each revision. This proves the
selected file identity, not whole-tree equivalence; the current mission subtree
is the same, while its containing crate/source trees differ.

The older recovered Lens 9 state gives scope index 2814 as lines 1–125 with
actual EOF 189. The normalized 774 catalog identifies that source as 6533,
but expressly says source recovery is not coverage. The state record does not
identify an individual completed reader or establish an e275 own-Lens 9 read;
the targeted local search did not recover an individually attributable
same-Lens 9 receipt. Its nested state bytes are hash-identified, but their
hash was not linked from the separately map-hash-verified root state. Keep
these historical summaries and their recovery limits separate from this
new complete independent read and from missing checkpoint 3821.

Root's recovered 6533 Lens 3 registration and fresh untruncated personal
read cover 1–189; its e275 Lens 3 receipt explicitly records zero fresh
personal lines, qualified same-Lens 3 reuse of 1–189, and pending frozen
source adoption. They are foreign-lens evidence here and do not transfer
Lens 9 coverage. Their original revision and attribution remain intact.

## Scoped source assessment

No substantiated enum-shape defect was established in the assigned source
and traced boundaries. This is not a whole-lens or alias disposition.

* `mission/enrollment.rs:5–33`: `EnrollmentEffect` and `AdmissionResult`
  describe local outcome choices; `PartyEnrollment` uses `Awaiting`,
  `Enrolling`, and `Sealed` variants. `Awaiting` holds the nonzero expected
  count; the latter two variants carry the observed identities and empty
  duration used while active. The shared history is meaningful across seal,
  and should not be discarded merely to make fields visually distinct.
* `enrollment.rs:35–68,113–122`: `begin` transitions the state; an unseen
  member may be admitted while enrolling and rejected after seal, while
  observed members may reconnect. `mission/mod.rs:29–50,67–99` owns the
  state and delegates these operations. `player_projection.rs:1013–1040,
  1050–1078` shows two selected join checks and their rejection paths.
  The bool returned by `allows_join` is an immediate decision, not a stored
  tag beside a conditional payload. This is not an audit of every join path.
* `mission/systems.rs:191–217` derives `has_loading_player` from the
  loading query and `loaded_party` from accepted loaded party members; these
  are independent inputs to `advance`, not proven to form one exclusive
  state. `enrollment.rs:97–109` resets or advances empty duration according
  to those inputs. A zero duration by itself does not encode whether a player
  is present; the current call also has the presence inputs.
* `enrollment.rs:78–109` can transition to `Sealed`, set that effect, then
  return `Abandoned` on the same call if the threshold is met. In the selected
  current consumer, `mission/systems.rs:218–232`, the `Sealed` arm logs and
  the `Abandoned` arm commits a Failed terminal result; when `advance`
  returns, enrollment is sealed, but this call does not emit the seal log. An abstract input/state
  permits the overlap. It remains open whether the effect contract is an
  exhaustive event report or intentionally prioritizes terminal abandonment,
  and whether an externally relevant product state reaches this overlap. No
  separate enum repair, incident, alias or unique finding is asserted.
* `enrollment.rs:126–189` is test source inside the assigned full-file range.
  It was read as source, never executed, and provides no validation credit.

## Historical and ledger relationships

Original 059 q3134, `SEGOVB-L3-PARTY-ZERO-GRACE-ABANDONMENT`, is a separate
retained source-conditional Lens 3 finding: zero grace makes the zero empty
duration meet the threshold even for a present/loading party. The original
record and immutable dac7d ledger entry 406 preserve the original e275
qualified reuse, no fresh e275 personal read, frozen-adoption qualification,
open policy and unrun validation. The independently traced same-call
seal/abandon priority is related source context, not asserted to be an alias
or an additional unique defect. The previously published enrollment
assessment covers lenses 1, 3, 4, 6, 7, 8, 11, 12 and 13, not this Lens 9
review. A bounded dac7d ledger term search found entry 406; it is not a
global alias search or proof about a later ledger.

The normalized 774 catalog is not the missing pre-export original. The 440
reconstructed records, SOURCE004, 73 nontext/no-positive-EOF obligations,
and the missing 3821 queue/ledger remain qualified and are not promoted.

## Evidence limits

READ-LIMITS.json preserves the unregistered first skill print and later
registered repeat, the truncated prior historical-record display, intentional
partial filename views, the unavailable old collection, and an exclusively
created empty file misleadingly named as a Git tree for a blob. The empty
file is preserved and is never used for proof. Full source and adjacent
displays were bounded and untruncated. No product tests, builds, examples,
runtime probes or repairs were performed. The evidence verifier checks
identities and replay linkages, not semantic interpretations. Exact full
original/reconstructed 059 queue membership requires separately held anchors.
