# Independent q2957 Lens 2 source review

Reader: independent reviewer; exact attribution is held in the restricted original. The recovered original and reconstructed 059
`/entries/2957` spans are byte-identical; the whole streams differ. The entry
`OBLIGATION-ROOT-L3-EXT-0021-LENS-02` recorded zero own-lens body/population
credit and a pending exact own-lens qualification. It is not checkpoint 3821.

The registered `crates/adventuresim-tactical-core/src/city_layout/grounding/
admission.rs` file at 6533e444fa37552927070cc8d8190907fd3b413e,
e2755a732c84e67296b5e3441a4259a84f461b2f and pinned
95e63628f9d70b8dd6e6fede64334696c6995009 was freshly and independently
displayed at each revision, lines 1–58 through EOF. The three exact path
chains independently prove the same Git blob
a65dc4432cb4dbea04fdd65f02e78d2d1ba81922, SHA-256
11bb44acefc12ab10604d09e33f8b1d26fc3958fa916255972ec6ea63e1f6d2f.
This is per-file identity, not whole-tree equivalence. Exact current bytes and
raw trees were recovered from the separately attributed q2368/q2369 packet.

## Owner and contract assessment

`admission.rs:5–23` owns distinct support-geometry errors, including the
existing typed PropertyMemberIssue cause. `:29–43` takes six native vectors,
rejects nonfinite individual points or sum, requires exact paired X/Z values,
rejects a reversed height and requires at least one nonzero height interval.
`:48–58` uses the represented winding: exact zero plan area has no solid faces,
negative winding reverses faces, and positive winding retains them. This
optional no-solid result is an intentional contact mode, not proof of a failed
collider or an automatically invalid cell.

The existing `Position<F>` owns a finite point in an explicit coordinate frame
(`adventuresim-building-generator/src/spatial_geometry/coordinates.rs:9–29,
54–88`), and Scene and GateRelative are distinct nominal frames
(`scene_coordinates/spatial.rs:20–42`). `enclosure.rs:24–62` retains
`[Position<GateRelative>; 6]` and maps it to Vec3 for `prism`; the collider
converts the same positions to native vectors before calling `solid_faces` and
the physics library (`:227–252`). `foundations.rs:73–124` instead accepts
`Position<Scene>` cells and cut faces, maps them to Vec3, and retains raw
scene-metre positions and cut faces in PropertyFoundationMesh; `:133–173`
exposes/revalidates those arrays, and `:176–188` converts selected cells to
physics. `enclosure/projection.rs:25–34` also uses retained foundation
positions for GroundTriangle construction before the native collider boundary.
The two callers deliberately use different frames while sharing frame-neutral
prism and face arithmetic.

This is a bounded existing-owner/producer-propagation candidate: the retained
foundation values have a matching upstream Position<Scene> owner, and at least
one internal geometry consumer uses the retained raw positions. It is not yet
a verified defect or a new unique count. PropertyFoundationMesh explicitly
describes native scene-metre mesh storage and exposes native-vector getters;
other producers, consumers, storage/port policy and any intentional accepted
deferral have not been exhaustively traced. A future owner decision must compare
the complete consumer and API boundary, preserve valid zero/contact and
negative winding, and retain the aggregate prism finiteness, sum, pair, height
and topology checks: Position<F>'s per-point finite guarantee alone is not
equivalent. No implementation or product validation is authorized here.

## Historical and current relationships

The named Lens 3 6533/e275 registration and read receipts are distinct. The
recovered q2368 Lens 2 `READ-ROOT-L2-EXT-021-033.json#/rows/1` records Root's
fresh 6533 lines 1–58; `READ-ROOT-L2-CURRENT-008.json#/rows/1` records the
e275 exact same-lens reuse of those lines with no fresh e275 personal range.
This supports a same-lens historical qualification candidate for q2957 and
is not my own independent read. Historical q2369's scoped disposition treats
the six/eight-element native shapes, winding and optional contact as their
existing native roles; it does not settle the separate retained-scene-position
question. Historical q3125 is a separately attributed Lens 3 scoped admission
disposition; q1491 and q1494 are separate Lens 12 native/contact and aggregate
questions. Historical q102 concerns an independent Lens 11 volume operation.

Immutable dac7d ledger row 1083 `relationship-prism-centering-finite-input-95e`
records a conditional nonfinite centered f32 vertex despite finite inputs and
sum, leaving supported inputs, native outcome, policy and alias questions open.
Row 321 separately concerns volume arithmetic; rows 320 and 322 concern
contact-only aggregate and empty-foundation policy respectively. These do not
prove an alias or unique defect count for the retained-position question.

## Limits

The full original/reconstructed queues, immutable dac7d ledger and recovered
historic lens-mapping document remain separately held replay anchors. The
packet contains exact selected spans and independently verified source proofs.
A prior proof metadata row was loaded for navigation before its separate
q2957 registration; it supplied no source-body credit and was subsequently
independently verified against raw tree objects. No source output truncation
was observed in the registered displays. No product code, example, parser,
build, test, fixture, repair or runtime probe was executed. All 73
nontext/no-positive-EOF obligations, SOURCE004, reconstructed 440, 774
normalized versus missing pre-export originals, missing checkpoint 3821,
other lenses and populations remain open or qualified as in the handoff.
