# q2957 bounded Lens 2 evidence

This later public-safe successor contains exact selected source blobs, raw Git
tree objects, registered source displays, four already published ledger rows,
and a reconstructed assessment. The report and historical synopsis are not
the raw original queue or receipt files; those and the raw commit metadata
remain in a separately held restricted packet.

`python3 verify.py` checks this manifest, source blobs, raw tree paths and all
registered displays. It cannot bind roots to commits or establish original
queue/receipt, ledger or historical mapping membership without restricted
originals. Add `--private DIR`, and optionally `--anchors DIR --ledger FILE
--historic-values FILE`, to replay those exact separately held anchors.

The three revisions have the same selected file blob; no whole-tree identity
is claimed. The missing checkpoint 3821 and 73 nontext/no-positive-EOF
obligations remain open. Verification reads evidence only and does not execute
product code or validate behavior.
