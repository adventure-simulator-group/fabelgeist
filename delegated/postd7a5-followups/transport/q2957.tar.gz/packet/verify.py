#!/usr/bin/env python3
import argparse,hashlib,json,os,pathlib,stat,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--skip-manifest',action='store_true');p.add_argument('--private');p.add_argument('--anchors');p.add_argument('--ledger');p.add_argument('--historic-values');a=p.parse_args()
sha=lambda b:hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def js(n):return json.loads((root/n).read_bytes())
def manifest(d,expected=None):
 raw=(d/'MANIFEST.json').read_bytes();assert expected is None or sha(raw)==expected;m=json.loads(raw);listed={x['path'] for x in m['files']};actual={str(x.relative_to(d)) for x in d.rglob('*') if x.is_file()}-{'MANIFEST.json'};assert listed==actual
 for x in m['files']:
  f=d/x['path'];b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and stat.S_IMODE(f.stat().st_mode)==x['mode'],x['path']
 return len(listed)
if a.skip_manifest:print('NOT CHECKED: public manifest (--skip-manifest)')
else:print('public manifest and file modes checked:',manifest(root))
def tree(t):
 b=(root/'trees'/(t+'.tree')).read_bytes();assert oid('tree',b)==t;d={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j+1);name=b[j+1:k].decode();assert name not in d and len(b[k+1:k+21])==20;d[name]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 assert i==len(b);return d
def chain(row,start):
 steps=row['chain'];assert steps[0]['tree']==start and [x['component'] for x in steps]==row['path'].split('/')
 for i,x in enumerate(steps):
  assert tree(x['tree'])[x['component']]==(x['mode'],x['oid'])
  if i+1<len(steps):assert x['mode']=='40000' and x['oid']==steps[i+1]['tree']
 assert steps[-1]['mode']=='100644' and steps[-1]['oid']==row['blob']
proof=js('SOURCE-PROOF-004-RESULT.json');assert len(proof['rows'])==3 and proof['all_file_blobs_identical'];root95=None
for row in proof['rows']:
 chain(row,row['chain'][0]['tree'])
 if row['label']=='95e':root95=row['chain'][0]['tree']
 src=(root/'source'/(row['label']+'.rs')).read_bytes();assert sha(src)==row['sha256']=='11bb44acefc12ab10604d09e33f8b1d26fc3958fa916255972ec6ea63e1f6d2f' and oid('blob',src)==row['blob'] and len(src.splitlines())==58
assert root95
adj=js('ADJ-PROOF-007-RESULT.json')['rows']+[js('CONSUMER-013-RESULT.json')]+js('FRAME-PROOF-016-RESULT.json')['rows'];assert len(adj)==6
for row in adj:
 assert row['status']=='pass';chain(row,root95);name=row['file'] if 'file' in row else row['label']+'.rs';src=(root/'adjacent'/name).read_bytes();assert sha(src)==row['sha256'] and oid('blob',src)==row['blob'] and len(src.splitlines())==row['eof']
def render(raw,start,end):
 lines=raw.splitlines(keepends=True);assert 1<=start<=end<=len(lines);return b''.join(str(i).encode()+b': '+lines[i-1] for i in range(start,end+1))
for x in js('DISPLAY-005-RECEIPT.json')['rows']:
 v=(root/'displays'/(x['label']+'-1-58.txt')).read_bytes();assert sha(v)==x['sha256'] and v==render((root/'source'/(x['label']+'.rs')).read_bytes(),*x['range'])
count=0;total=0
for n in ['ADJ-DISPLAY-009-RESULT.json','CONSUMER-DISPLAY-018-RESULT.json','TOPOLOGY-DISPLAY-020-RESULT.json']:
 for x in js(n):
  v=(root/'adjacent-displays'/(x['name']+'.txt')).read_bytes();assert sha(v)==x['sha256'] and v==render((root/'adjacent'/x['file']).read_bytes(),*x['range']);count+=1;total+=x['range'][1]-x['range'][0]+1
assert count==8 and total==492
assert sha((root/'SKILL-EXISTING-TYPE-OWNERS.md').read_bytes())=='0876e49f57d2b5397d23735b9c49916d5d20087b33c110746beaa73c1c8cba3f'
print('source blobs, raw tree paths, 3 full and 8 adjacent displays checked; roots not yet bound to commits')
if any([a.anchors,a.ledger,a.historic_values]) and not a.private:raise SystemExit('external anchors require --private')
if a.private:
 d=pathlib.Path(a.private);n=manifest(d,'eca2b34e2d8cbffb1bcddd344f8be1d3bc09a20bc400d21165a3d269ce3e230c');cmd=[sys.executable,str(d/'verify-evidence-v2.py')]
 for flag,value in [('--anchors',a.anchors),('--ledger',a.ledger),('--historic-values',a.historic_values)]:
  if value:cmd.extend([flag,value])
 r=subprocess.run(cmd,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});assert r.returncode==0,('restricted evidence replay failed',r.returncode)
 print('restricted manifest, commit/tree bindings and named historical receipts checked:',n)
 for value,label in [(a.anchors,'full 059 queue membership'),(a.ledger,'dac7d ledger membership'),(a.historic_values,'historic lens mapping membership')]:print(('checked: ' if value else 'NOT CHECKED: ')+label)
else:print('NOT CHECKED: commit-to-root binding, original queue and receipts, immutable ledger membership, historic lens mapping; restricted originals required')
print('evidence-only replay; no product execution or runtime validation')
