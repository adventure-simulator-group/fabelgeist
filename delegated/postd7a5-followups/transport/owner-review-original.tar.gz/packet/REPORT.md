# Independent review of the later central owner draft

The independently reviewed successor draft has SHA-256
`e7bd8ac8fc4837514ea8e4184749d59359de538d31cc66fc6c1e1bee9a003304`.
Its three partial assessments and two planning relationships are supported at
the recorded source scope, with the limits below. This is not a source-frontier,
queue, lens, repair or product-validation closure. The retained predecessor
has SHA-256
`b8448601e7cd1f1a3f4d5ac1da0a192149c15ede250decf8b5296c55bd5b5f1b`.
The successor corrects the two findings below without changing counts.

For q2945, `binding.rs:157-172` places an upper bound on cells and checks
element presence in both directions. It does not require an exact cell count
or a particular multiplicity per element. It also does not prove geometric or
material correspondence between each admitted cell and the descriptor.
`binding.rs:109-124,134-155` separately checks owner shape, property/front,
ordered elements and the descriptor digest. The predecessor's ambiguous
“checks count” wording is corrected in the successor. The separate
contact-only aggregate is immutable dac7d ledger row 320,
`REVIEW-BOUNDARY-WIRE-CONTACT-ONLY-001`; it is not queue entry 320.

For q2957, `admission.rs:29-58` checks individual finite points and finite
sum, exact paired X/Z coordinates, and ordered, not wholly collapsed heights.
Its zero-area `solid_faces` result is no solid, and negative winding reverses
the faces. `enclosure.rs:24-62,227-252` retains gate-relative positions to its
native port. `foundations.rs:73-124,133-188` admits scene positions but stores
native vectors and cut faces; `enclosure/projection.rs:25-34` consumes retained
positions to construct a GroundTriangle before the collider boundary. This
supports a bounded frame-owner propagation question, not a demonstrated
reachable defect. Native storage and getters are documented; complete producer
and consumer coverage, storage policy, native outcome and aliases remain open.
The earlier contact/native and centering observations keep their own first
operations; no automatic merge or new unique count follows.

For q2968, `validate-city-support.rs:23-37,84-104,127-132` stores the
optional selector as `Option<u64>`, compares both typed property identifiers
through `.0`, errors unless a supplied selector leaves exactly one property,
and reports the optional value. An omitted selector bypasses that branch.
`CityPropertyId(pub u64)` is transparent and does not itself enforce nonzero.
Historical q2370 already names the same selector reuse candidate. The current
scene-input digest `String` and checked imported `SourcePackageDigest` have
distinct authorities; a matching hex representation does not prove shared
ownership. Parser adaptation, other producers, consumers, scene-digest owners
and global aliases remain open.

## Attribution and evidence

The original 56f and reconstructed dac7d 059 queues are different complete
streams. Eleven exact selected entries match across them and are bound to
their respective Git commit/tree/blob paths in this restricted packet.
The original q2945, q2957 and q2968 entries recorded pending own-lens
qualification and zero body/population credit. Historical q2368 and q2369
record Root's fresh Lens 2 6533 reads of the binding and admission bodies and
qualified e275 same-lens reuse with no fresh e275 personal range. q2370
records the corresponding earlier Root Lens 2 CLI finding; it does not grant
Lens 1 read credit. The q2945 and q2957 delegate reports separately record
fresh full-body displays at all three revisions; the q2968 delegate records
fresh full-file displays at all three. These are per-file identities, not
whole-tree equivalence or transferred reviewer credit.

This review personally displayed the coordinator's 23 registered 95e ranges
plus the separately registered CLI lines 104-126: 24 ranges, 780 lines. The
50 retained selected Git objects bind 22 commit/tree paths, six delegate ledger
selections and the two complete historical queue streams. Object hashing and
copying provide no personal read credit. Immutable dac7d ledger rows 1082 and
1083 retain the earlier descriptor-cell and finite-centering relationships;
rows 320-322 are separate contact, volume and empty-foundation questions.

Three broad locator/metadata displays were truncated and are navigation only.
An initial structural read of the two complete queue streams preceded their
separate exact file registration; the subsequent registered check repeated
byte identity and membership, with no semantic read credit. A product-worktree
Git availability locator lacked 95e; a separate publication object store had
the required revisions. Only boolean output of that initial locator was
retained, so no missing-source inference is justified. The q2945/q2957
pre-registration proof-metadata limitations, q2968 fixed-path scratch incident,
failed locators and display/receipt corrections remain in their separately
attributed packets. The initial and successor drafts are both retained.

The original final checkpoint 3821 ledger and queue remain unrecovered. The
73 nontext/no-positive-EOF obligations, SOURCE004, reconstructed 440,
individual 774 normalized-versus-pre-export qualifications and other unread
lenses and aliases remain open. This is source/evidence review only: no product
code, parser, shader, test, build, fixture, repair or runtime probe was run.
