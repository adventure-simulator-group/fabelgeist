#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,sys
r=Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('disable Python optimization')
m=json.loads((r/'MANIFEST.json').read_text());rows=m['files'];names={x['path'] for x in rows}
if len(rows)!=len(names) or {x.name for x in r.iterdir()}!=names|{'MANIFEST.json'}:raise SystemExit('file set')
for x in rows:
 p=r/x['path']
 if p.is_symlink() or not p.is_file():raise SystemExit('unsafe file')
 b=p.read_bytes()
 if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256']:raise SystemExit('identity mismatch')
print('Public review report and bounded privacy receipt identities verified; inspect the restricted evidence proof separately.')
