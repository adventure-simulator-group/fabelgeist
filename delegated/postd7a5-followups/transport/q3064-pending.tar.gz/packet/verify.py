#!/usr/bin/env python3
"""Read-only q3064 evidence verifier; never runs product or fixture code."""
import argparse, hashlib, json, pathlib, re, subprocess, sys
P=pathlib.Path(__file__).resolve().parent

def load(path): return json.loads(path.read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def tree_hash(data): return hashlib.sha1(b'tree '+str(len(data)).encode()+b'\0'+data).hexdigest()
def require(b,msg):
    if not b: raise ValueError(msg)
def safe(name):
    q=pathlib.PurePosixPath(name)
    require(not q.is_absolute() and '..' not in q.parts,'unsafe path')
    return P.joinpath(*q.parts)
def tree_entries(data):
    pos=0; out={}
    while pos<len(data):
        sp=data.index(b' ',pos); nul=data.index(b'\0',sp+1)
        require(nul+21<=len(data),'truncated tree')
        name=data[sp+1:nul].decode(); require(name not in out,'duplicate tree entry')
        out[name]=(data[pos:sp].decode(),data[nul+1:nul+21].hex()); pos=nul+21
    return out

def runs(nums):
    out=[]
    for n in sorted(nums):
        if out and out[-1][1]+1==n: out[-1][1]=n
        else: out.append([n,n])
    return out

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--repository'); parser.add_argument('--restricted'); args=parser.parse_args()
    manifest=load(P/'MANIFEST.json'); require(manifest['schema']=='q3064-public-manifest-v1','manifest schema')
    found={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'}
    require(not any(x.is_symlink() for x in P.rglob('*')),'symlinks not allowed')
    require(found==set(manifest['files']),'manifest file set')
    for name,entry in manifest['files'].items():
        data=safe(name).read_bytes(); require(len(data)==entry['bytes'] and sha(data)==entry['sha256'],'file mismatch '+name)
    rr=load(P/'READ-RECEIPT.json'); unions={}; seen=0
    for r in rr['registered_displays']:
        src=safe(r['source_file']).read_bytes(); lines=src.decode().splitlines()
        require(len(lines)==r['eof'] and sha(src)==r['source_sha256'] and blob(src)==r['git_blob'],'source identity '+r['label'])
        reg=load(safe(r['registration']))
        if r['label']=='combat-agents':
            rows=reg['sources']; ranges=reg['rules_planned_ranges']
        elif 'sources' in reg:
            rows=reg['sources']; ranges=None
        else:
            rows=[reg['source']]; ranges=reg['planned_ranges']
        source=next(x for x in rows if x['label']==r['label'])
        planned=ranges if ranges is not None else source['planned_ranges']
        require(source['revision']==r['revision'] and source['path']==r['path'] and source['sha256']==r['source_sha256'],'registration identity')
        require([x['range'] for x in r['displayed']]==planned,'registration ranges')
        key=(r['revision'],r['path']); unions.setdefault(key,{'eof':len(lines),'numbers':set()})
        for v in r['displayed']:
            a,z=v['range']; data=safe(v['file']).read_bytes(); require(sha(data)==v['sha256'],'view hash'); view=data.decode().splitlines()
            require(1<=a<=z<=len(lines) and len(view)==z-a+1,'view range')
            for n,line in enumerate(view,a):
                m=re.match(r'^\s*(\d+)(?:: ?| )',line)
                require(m is not None and int(m.group(1))==n and line[m.end():]==lines[n-1],'view content')
            unions[key]['numbers'].update(range(a,z+1));seen+=1
    require(len(rr['per_source_union_and_unread'])==len(unions),'coverage population')
    for r in rr['per_source_union_and_unread']:
        u=unions[(r['revision'],r['path'])]; require(u['eof']==r['eof'],'coverage EOF')
        require(runs(u['numbers'])==r['registered_personal_union'],'coverage union')
        require(runs(set(range(1,u['eof']+1))-u['numbers'])==r['unread_complement'],'unread complement')
    proofs=load(P/'TREE-PROOFS.json')['proofs']; require(len(proofs)==len(unions),'proof population')
    for proof in proofs:
        oid=proof['root_tree']; parts=proof['path'].split('/'); chain=proof['tree_chain'];require(len(parts)==len(chain),'proof length')
        for i,(part,step) in enumerate(zip(parts,chain)):
            require(step['tree']==oid and step['entry']==part,'tree chain'); raw=(P/'trees'/f'{oid}.bin').read_bytes();require(tree_hash(raw)==oid,'tree identity')
            mode,oid=tree_entries(raw)[part];require(mode==step['mode'] and oid==step['object'],'tree member')
            if i+1<len(parts):require(mode in ('40000','040000'),'tree directory')
        require(oid==proof['blob'],'leaf oid'); b=safe(proof['source_file']).read_bytes(); require(blob(b)==oid and sha(b)==proof['source_sha256'],'leaf bytes')
        if args.repository:
            root=subprocess.check_output(['git','-C',args.repository,'rev-parse',proof['revision']+'^{tree}'],text=True).strip(); require(root==proof['root_tree'],'revision root')
    h=load(P/'HANDOFF-LOCATOR-REGISTRATION.json'); data=(P/'handoff-PROMPT.source').read_bytes(); require(sha(data)==h['sha256'] and blob(data)==h['git_blob'],'handoff bytes')
    if args.repository:
        oid=subprocess.check_output(['git','-C',args.repository,'rev-parse',h['revision']+':'+h['path']],text=True).strip(); require(oid==h['git_blob'],'handoff revision binding')
    private_checked=False
    if args.restricted:
        d=pathlib.Path(args.restricted); hist=d/'historical'; summ=load(P/'HISTORICAL-SUMMARY.json'); captures=load(P/'QUEUE-CAPTURE-IDENTITIES.json')
        qobjs=[]
        for label in ('queue-original-56f','queue-reconstructed-dac7d'):
            q=(hist/(label+'.json')).read_bytes(); require(sha(q)==captures[label]['stream_sha256'],'queue identity');obj=json.loads(q);qobjs.append(obj)
            for idx,expected in captures[label]['selected'].items():
                b=(hist/(label+'-q'+idx+'.json')).read_bytes();require(sha(b)==expected['sha256'] and len(b)==expected['bytes'],'historical selected bytes'); require(json.loads(b)==obj['entries'][int(idx)],'historical selected value')
        require(qobjs[0]['entries'][3064]==qobjs[1]['entries'][3064] and qobjs[0]['entries'][3128]==qobjs[1]['entries'][3128],'queue selected equivalence')
        for name in ('q3128-queue-original-56f.json','q3128-queue-reconstructed-dac7d.json'):
            b=(hist/name).read_bytes(); require(sha(b)==summ['recovered_059']['q3128_selected_sha256'] and json.loads(b)==qobjs[0]['entries'][3128],'q3128 copy')
        for row in summ['receipt_and_registration_identities']:
            b=(hist/pathlib.PurePosixPath(row['path']).name).read_bytes();require(sha(b)==row['sha256'] and row['sha256']==row['expected'],'historical receipt')
        prior=hist/'ASSESSMENT-L01-HISTORICAL-2061-2066.json';require(sha(prior.read_bytes())==load(P/'SAME-LENS-ASSESSMENT-REGISTRATION.json')['sha256'],'prior assessment')
        role=load(prior)['historical_source_roles'][4];require(role['original_index']==2065 and role['new_personal_read_ranges']==[[1,303]] and role['current_comparison']['current_personal_ranges']==[],'prior role scope')
        require(sha((hist/'ledger-observed.json').read_bytes())==load(P/'LEDGER4-LOCATOR.json')['sha256'],'ledger snapshot')
        private_checked=True
    print(json.dumps({'result':'pass','manifest_files':len(found),'registered_views':seen,'source_revision_pairs':len(unions),'git_tree_proofs':len(proofs),'repository_binding_checked':bool(args.repository),'restricted_history_checked':private_checked,'limits':'No product execution; does not prove prior reviewers read more than their own receipts, runtime reachability, whole-tree cleanliness, queue or lens closure, or private history unless supplied.'},sort_keys=True))

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('evidence verification failed:',type(exc).__name__,str(exc),file=sys.stderr);sys.exit(1)
