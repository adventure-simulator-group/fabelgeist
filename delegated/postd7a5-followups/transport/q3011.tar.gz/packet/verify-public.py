#!/usr/bin/env python3
"""Verify q3011 evidence only. No product source is executed."""
import argparse,hashlib,json,re,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
H=lambda x:hashlib.sha256(x).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def entries(b):
 out={};i=0
 while i<len(b):
  j=b.index(b' ',i);k=b.index(b'\0',j);out[b[j+1:k].decode()]=(b[i:j].decode(),b[k+1:k+21].hex());i=k+21
 return out
def path(root,name,data):
 t=root
 for part in name.split('/'):
  b=(P/'trees'/(t+'.tree')).read_bytes();assert oid('tree',b)==t
  mode,t=entries(b)[part]
 assert mode=='100644' and oid('blob',data)==t
ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);ap.add_argument('--skip-manifest',action='store_true');a=ap.parse_args()
if a.skip_manifest:print('NOT CHECKED: public packet manifest (--skip-manifest)')
else:
 m=json.loads((P/'MANIFEST.json').read_bytes());found={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};assert found==set(m['files'])
 for n,v in m['files'].items():
  p=P/n;assert H(p.read_bytes())==v['sha256'] and p.stat().st_mode&0o777==v['mode']
 print('public file set, modes and manifest hashes: pass')
proof=json.loads((P/'SOURCE-PROOF-012-RESULT.json').read_bytes());base='crates/adventuresim-weapon-model/src/'
adj={'partition.rs':'construction/partition.rs','polygon.rs':'construction/polygon.rs','surface_quality.rs':'construction/surface_quality.rs','mod.rs':'construction/mod.rs','contoured_plate.rs':'model/contoured_plate.rs','cell.rs':'model/contoured_plate/cell.rs'}
for row in proof['rows']:
 label=row['label'];root=row['chain'][0]['tree'];b=(P/'source'/(label+'.rs')).read_bytes();assert H(b)=='0c28888bf192ddcf2768b572e9cbd672a5ec2af2bc0c38d46af448782d987a65' and len(b.splitlines())==236 and b.endswith(b'\n');path(root,base+'construction/surface_refinement.rs',b)
 assert (P/'displays'/(label+'-1-236.txt')).read_text()==''.join(f'{i}: {v}\n' for i,v in enumerate(b.decode().splitlines(),1))
 for file,rel in adj.items():path(root,base+rel,(P/'adjacent'/file).read_bytes())
for f in (P/'adjacent-displays').iterdir():
 m=re.fullmatch(r'(.+\.rs)-(\d+)-(\d+)\.txt',f.name);assert m
 name,lo,hi=m.group(1),int(m.group(2)),int(m.group(3));lines=(P/'adjacent'/name).read_text().splitlines();assert f.read_text()==''.join(f'{i:4} {lines[i-1]}\n' for i in range(lo,hi+1))
assert H((P/'SKILL-ENUM-SHAPES.md').read_bytes())=='964ebea7b08a545b5abcabf605c22b92ac0dbb09ed79e6f79651ea2f141a3500'
assert json.loads((P/'LENS-MAP-006-RESULT.json').read_bytes())['row']['name']=='enum-shapes'
print('selected tree-to-source identities, complete target and adjacent displays, focused skill: pass')
if a.anchors and not a.private:raise SystemExit('--anchors requires --private')
if not a.private:
 print('NOT CHECKED: commit-to-root binding, original handoff map, exact original/reconstructed queue membership, historic attribution receipts, private report reconstruction and ledger membership; separately held restricted packet required')
else:
 pm=a.private/'MANIFEST.json';assert H(pm.read_bytes())=='cecad6e26db20b739d454edb1bb916ba2c808ffeff510b6a9fe83172cac7b307'
 cw=json.loads((P/'RECONSTRUCTION-CROSSWALK.json').read_bytes());old=(a.private/cw['original_file']).read_bytes();assert H(old)==cw['original_whole_file_sha256'];out=bytearray();last=0
 for row in cw['replacements']:
  off=row['original_byte_offset'];n=row['original_byte_length'];assert off>=last;out+=old[last:off]+row['replacement'].encode();last=off+n
 out+=old[last:];assert bytes(out)==(P/cw['successor']).read_bytes() and H(out)==cw['successor_whole_file_sha256']
 print('restricted manifest anchor and reconstructed report crosswalk: pass')
 cmd=[sys.executable,str(a.private/'verify-evidence.py')]
 if a.anchors:cmd+=['--anchors',str(a.anchors)]
 result=subprocess.run(cmd,capture_output=True,text=True);print(result.stdout,end='');
 if result.returncode:print(result.stderr,file=sys.stderr);raise SystemExit(result.returncode)
print('Evidence integrity checks do not prove semantic findings, recover missing checkpoint 3821 or perform product validation.')
