# q3011 — independent historical Lens 9 enum-shapes review

Reviewer: [independent reviewer; identity held separately], independently assessed after the frozen
checkpoint. This is source inspection, not implementation or product validation.
The recovered 059 record is an obligation, not evidence that 3821 survived.

## Scope and identity

Recovered handoff lens map `/lenses/8` names Lens 9 `enum-shapes`; the focused
skill has SHA-256 `964ebea7b08a545b5abcabf605c22b92ac0dbb09ed79e6f79651ea2f141a3500`.
The original and reconstructed q3011 selected entries are byte-identical;
keep the two queue provenances separate. The original 059 status is
`own-lens-proof-qualification-or-read-pending`, with zero prior own-lens
body/population credit. Commit/tree/object proofs bind the target file at
6533e444fa37552927070cc8d8190907fd3b413e,
e2755a732c84e67296b5e3441a4259a84f461b2f and
95e63628f9d70b8dd6e6fede64334696c6995009 to the same blob, SHA-256
`0c28888bf192ddcf2768b572e9cbd672a5ec2af2bc0c38d46af448782d987a65`,
EOF 236. The reviewer independently displayed all 236 lines at each of the
three revisions. These are per-file/subtree identity proofs, not tree-wide
equivalence.

## Source assessment

No substantiated enum-shape defect was found within the assigned file and
traced local boundaries. This is a scoped disposition, not whole-lens closure.

* `construction/surface_refinement.rs:9–19,24–58,129–146,193–219`: the edge,
  subresolution, curvature and before/after limit booleans are named local
  numerical predicates; they do not carry an independent status tag with
  conditionally meaningful payload across an API or stored transition. The
  limit tuple is temporary; its boolean tracks the conjunction of per-edge
  checks while the numeric values support their distinct comparisons.
* `surface_refinement.rs:60–112`: the map lookup produces exactly three
  independent optional midpoints, one per triangle edge. Count 0, 1, 3 and
  the remaining count 2 cover all possible option arrangements. In each
  nonzero arm, the count establishes the required `position`/`unwrap` cases.
  An enum merely renaming these combinations is not established as useful.
  This argument does not validate the map's indices or topology.
* `construction/polygon.rs:9–14,190–221` owns points, triangle indices and
  boundary indices and constructs a midpoint map locally;
  `construction/partition.rs:41–102` constructs shared crossings before
  splitting. Their aggregate index/topology contracts are independent open
  questions, not a finding proved or resolved by the option-count argument.
* `model/contoured_plate.rs:13–39,41–85` selects `PlateSurface` variants and
  supplies `field.cell(point)` and a height callback to refinement.
  `model/contoured_plate/cell.rs:3–42` expresses the classifier family as
  `CellBand::Ridge(PlateBand)` or `CellBand::Profile(usize)`, each carrying
  its appropriate payload. `construction/surface_quality.rs:15–37,56–100,
  164–220` compares the generic Eq class for protected boundaries and
  candidate changes; it does not make callback admission globally valid.
* `surface_refinement.rs:114–118,147–182` documents a height-function
  precondition and includes budget/error/retry behavior. This review does
  not establish ordinary-input callback validity, error atomicity, numeric
  limits, or product reachability and does not propose a repair.

## Relationships and unresolved questions

Original 059 q3129 records Root's separate 6533 Lens 3 callback-admission
review and qualified e275 same-lens reuse; it recognizes the option-count
guards but keeps actual geometry/callback admission and ordinary failing
input open. q2372 records Root's separate Lens 2 `Metres` and refinement
control-owner classification; precise native policy and connected producer
scope remain open. q1784 cites [earlier Lens 12 reviewer; identity held separately]'s separate Lens 12
source read and unresolved string/error scope. None supplies this Lens 9
reading, and no alias or additional unique defect count is asserted.

A bounded search of the immutable dac7d ledger's 1,084 newly assessed entries
for `surface_refinement`, `refine_rational_surface`, `split_edges`, `weapon
refinement`, and `callback preconditions` returned no hits. This is not a
global alias search and does not exclude differently named records or later
ledger changes. Root retains responsibility for reconciliation. All 73
nontext/no-positive-EOF obligations and other inherited recovery
qualifications remain open. The 440 reconstructed records, normalized 774
versus missing pre-export, SOURCE004 qualification and missing checkpoint
3821 are not promoted or treated as newly recovered.

## Evidence limits

See READ-LIMITS.json for clipped/wrong metadata displays, incidental test
source display, and the unrelated truncated/failed navigation. No product
tests, builds, examples, parsers, fixtures, runtime probes or code were run.
The evidence-only verifier checks byte identities and source/display linkage,
not the correctness of the interpretation. External 059 queue anchors are
required for exact original queue membership replay; private selected entries
are retained here and the two whole queue hashes are fixed in the verifier.
