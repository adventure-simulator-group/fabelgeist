# Evidence and privacy qualifications

This public-safe successor is reconstructed. The exact restricted original,
its full manifest, original 059 queues, historical receipts and raw commit
metadata must be separately held; they cannot be recovered from this packet
alone. Optional evidence-only replay against the independently held original
checks the fixed private manifest and, when queue anchors are supplied,
selected exact queue membership. It is not product validation.

An initial metadata view registered the lens row but displayed an intentionally
clipped prefix of the map instead; a separately registered correct row view
followed. Two filename searches intentionally displayed only their first 20
results while complete output was retained privately. An unrelated prior
packet listing was tool-truncated and a guessed prior-packet README lookup
failed; neither supplied source evidence. One adjacent source display included
test source lines after the classifier definition; no test was run.

The 95e commit was unavailable in the live object store. The separately held
raw commit and Git tree chain prove the selected paths, not whole-tree
equivalence. The exact original Lens 3 reading, qualified e275 reuse and other
reviewers retain their own attributions; none substitutes for this Lens 9
reading. The selected 059 original and reconstruction are separate, even when
the selected spans match byte-for-byte. The missing checkpoint 3821, SOURCE004,
440 reconstructed records, 774 normalized versus missing pre-export, and 73
nontext/no-positive-EOF obligations remain qualified. No global alias or
whole-lens closure is asserted.
