# q3011 evidence-only successor

`REVIEW.md` is a privacy-redacted reconstruction of the independently
attributed restricted report, not its exact original. `RECONSTRUCTION-CROSSWALK.json`
records whole-file identities and byte ranges without individual removed-value
digests. Preserve the separately held original packet and queue anchors.

Run `python3 verify-public.py` to check this manifest, saved source/tree
objects and displays. Without the separately held restricted packet it cannot
check commit-to-root linkage, historical original queue membership, or the
private attribution/receipt chain. To replay those checks, add `--private DIR`
and `--anchors DIR`; the original verifier is evidence-only. Its output makes
any omitted check explicit. All conclusions remain source-only.
