# q3207: hair facade producer propagation

The assigned 187-line file is a documented module and re-export facade. It
contains no local value-producing implementation, and its `no_run` example was
read only. This reviewer independently displayed the complete file at 6533,
e275 and the authoritative 95e revision under Lens 1, plus selected connected
source ranges. The same recovered working-source bytes match all three files;
this is per-file identity, not whole-tree equality or product validation.

A bounded connected question concerns the guide seed. `Look::guides` extracts
an `i32` word from `HairSeed` and casts it to `u64` for public
`Hairdo::guides`; the optional GPU host path stores the same cast in
`Guides::Hairdo`. Both selected paths reach `guide_key`, which mixes the low and
high 32-bit halves. The public guide inputs accept a wider `u64` domain than
the signed hair owner. For a negative hair word, the direct signed-to-`u64`
cast has an all-one high half, while `HairSeed::from_word` constructs its
canonical `Seed` from a zero-extended 32-bit word. Replacing one path with the
other without an explicit adapter would therefore change an input half to the
hash. This is symbolic source reasoning, not an executed seed or GPU result.
Whether and where a typed owner should propagate, the public 64-bit domain, all
callers and exact aliases remain open.

A separate selected identity path constructs `StrandId` from a guide hash,
retains it through `Attachment` and `Strands`, and extracts its word at the
numeric hash and random functions used for level-of-detail ordering and
rendering data. `StrandInfo` retains derived random, radius and UV in a
`repr(C)` representation. This selected trace does not prove ID uniqueness or
that downstream rendering needs the original identity; the primitive adapter
alone is not a defect.

Immutable dac7d ledger row 669 already records a related typed-owner escape in
retained hair operations. The direct guide seed path is related but has a
different selected first operation; central reconciliation must decide any
shared repair and exact alias. Rows 646–647 and historical q161 retain the
separate signed-offset arithmetic question. Row 633's parallel-array admission
and row 645's guide-point admission are distinct related contracts. No new
unique defect count, alias or queue/lens closure is claimed.

Original q3207 was pending with zero body credit. Original and reconstructed
selected entries match, but their full 059 streams differ. Root's historical
Lens 3 read is fresh at 6533 and qualified same-lens reuse at e275 with no fresh
e275 range; it does not supply Lens 1 credit. Historical q2407 and q3144 retain
their separate Lens 2 and Lens 3 facade attributions. The map-hash-bound older
Lens 1 state and normalized source catalog were checked, but bounded searches
did not establish an individually attributable prior same-lens facade receipt;
source recovery alone is not coverage and the search is not a global absence
proof. The original checkpoint 3821 ledger and queue remain unrecovered.

One old-evidence filename display was intentionally limited and additionally
tool-truncated; its full filename output is retained privately and is only
navigation. Earlier related-record displays were clipped and followed by
separately registered full projections. A GPU-module excerpt was test source,
read as text only. Git proof capture stdout appeared only in the tool transcript;
the offline verifier independently checks all saved path proofs. The 73
nontext/no-positive-EOF obligations, SOURCE004, normalized 774 versus missing
pre-export, reconstructed 440 and other inherited qualifications remain open.

No product code, shader, macro, test, build, fixture or runtime probe ran.
