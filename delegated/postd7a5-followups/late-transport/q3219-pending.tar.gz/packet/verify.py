#!/usr/bin/env python3
"""Read-only q3219 evidence verifier; source, shaders and macros are never run."""
import argparse,hashlib,json,pathlib,tarfile,subprocess,sys
P=pathlib.Path(__file__).resolve().parent

def load(f):return json.loads(f.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(kind,b):return hashlib.sha1(kind+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def need(v,msg):
 if not v:raise ValueError(msg)
def safe(n):
 p=pathlib.PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts,'unsafe path');return P.joinpath(*p.parts)
def tree(b):
 pos=0;out={}
 while pos<len(b):
  a=b.index(b' ',pos);z=b.index(b'\0',a+1);need(z+21<=len(b),'tree truncated');name=b[a+1:z].decode();need(name not in out,'duplicate tree name');out[name]=(b[pos:a].decode(),b[z+1:z+21].hex());pos=z+21
 return out
def runs(s):
 a=[]
 for i in sorted(s):
  if a and a[-1][1]+1==i:a[-1][1]=i
  else:a.append([i,i])
 return a

def main():
 a=argparse.ArgumentParser();a.add_argument('--restricted',type=pathlib.Path);a.add_argument('--repository');a=a.parse_args();m=load(P/'MANIFEST.json');found={x.relative_to(P).as_posix() for x in P.rglob('*') if x.is_file() and x!=P/'MANIFEST.json'};need(found==set(m['files']) and not any(x.is_symlink() for x in P.rglob('*')),'manifest set')
 for n,v in m['files'].items():
  b=safe(n).read_bytes();need(len(b)==v['bytes'] and sha(b)==v['sha256'],'manifest identity '+n)
 rr=load(P/'READ-RECEIPT.json');part=load(P/'PARTICLES-READ-RECEIPT.json');rows=rr['rows']+[part];unions={};nviews=0
 for r in rows:
  data=safe(r['source_file']).read_bytes();lines=data.decode().splitlines();need(sha(data)==r['source_sha256'] and oid(b'blob',data)==r['git_blob'] and len(lines)==r['eof'],'source identity '+r['label']);reg=load(safe(r['registration']));entries=reg['sources'];e=next(x for x in entries if x['label']==r['label']);planned=e['ranges'] if r['registration']=='SUPPORT-ADDITIONAL-REGISTRATION.json' else e['planned_ranges'];need([x['range'] for x in r['views']]==planned,'registered ranges '+r['label'])
  if r['registration']!='SUPPORT-ADDITIONAL-REGISTRATION.json':need(e['revision']==r['revision'] and e['path']==r['path'] and e['sha256']==r['source_sha256'],'registration identity')
  k=(r['revision'],r['path']);unions.setdefault(k,{'eof':len(lines),'n':set()})
  for v in r['views']:
   first,last=v['range'];b=safe(v['path']).read_bytes();need(sha(b)==v['sha256'] and 1<=first<=last<=len(lines),'view bounds');actual=b.decode().splitlines();need(actual==[f'{i}: {lines[i-1]}' for i in range(first,last+1)],'view contents');unions[k]['n'].update(range(first,last+1));nviews+=1
 for c in rr['coverage']:
  u=unions[(c['revision'],c['path'])];need(runs(u['n'])==c['displayed_union'] and runs(set(range(1,u['eof']+1))-u['n'])==c['unread_complement'],'coverage')
 u=unions[(part['revision'],part['path'])];need(runs(u['n'])==part['displayed_union'] and runs(set(range(1,u['eof']+1))-u['n'])==part['unread_complement'],'particle coverage')
 proofs=load(P/'TREE-PROOFS.json')['proofs'];need(len(proofs)==len(unions),'proof count')
 for x in proofs:
  cur=x['root_tree'];parts=x['path'].split('/');need(len(parts)==len(x['tree_chain']),'proof length')
  for i,(component,step) in enumerate(zip(parts,x['tree_chain'])):
   need(step['tree']==cur and step['entry']==component,'tree chain');b=(P/'trees'/f'{cur}.bin').read_bytes();need(oid(b'tree',b)==cur,'tree oid');mode,nxt=tree(b)[component];need(mode==step['mode'] and nxt==step['object'],'tree path');cur=nxt
   if i+1<len(parts):need(mode in ('40000','040000'),'tree mode')
  need(cur==x['blob'] and oid(b'blob',safe(x['source_file']).read_bytes())==cur,'blob path')
  if a.repository:
   root=subprocess.check_output(['git','-C',a.repository,'rev-parse',x['revision']+'^{tree}'],text=True).strip();need(root==x['root_tree'],'repository revision-root')
 skill=load(P/'SKILL-REGISTRATION.json');need(sha((P/'FOCUSED-SKILL.md').read_bytes())==skill['sha256'],'focused skill');lm=load(P/'LENS-MAP-REGISTRATION.json');need(sha((P/'LENS-MAP.md').read_bytes())==lm['sha256'],'lens map');lines=(P/'LENS-MAP.md').read_text().splitlines();need((P/'views/lens-map-40-53.txt').read_text().splitlines()==[f'{i}: {lines[i-1]}' for i in range(40,54)],'lens map view')
 restricted=False;archive_checked=False
 if a.restricted:
  d=a.restricted;hist=d/'historical';summary=load(P/'HISTORICAL-SUMMARY.json');hc=load(P/'HISTORY-CAPTURE.json');objs=[]
  for x in hc['streams']:
   b=(hist/x['stream']).read_bytes();need(sha(b)==x['stream_sha256'] and len(b)==x['stream_bytes'],'queue stream');q=json.loads(b);objs.append(q);sel=(json.dumps(q['entries'][3219],indent=2,ensure_ascii=False)+'\n').encode();need(sha(sel)==x['selected_serialization_sha256'],'q3219 selected');need((hist/('selected-'+x['stream'])).read_bytes()==sel,'q3219 stored selection')
  need(objs[0]['entries'][3219]==objs[1]['entries'][3219],'q3219 selection equality')
  for x in load(P/'RELATED-QUEUE-CAPTURE.json'):
   for j,label in enumerate(['original-56f','reconstructed-dac7d']):
    b=(hist/f"selected-q{x['index']}-{label}.json").read_bytes();v=(json.dumps(objs[j]['entries'][x['index']],indent=2,ensure_ascii=False)+'\n').encode();need(b==v and sha(b)==x['records'][j]['selected_sha256'],'related queue selection')
  for fn in ['PRIOR-RECEIPTS-IDENTITIES.json','SPLIT-READ-IDENTITIES.json']:
   for x in load(P/fn):
    b=(hist/'prior'/pathlib.PurePosixPath(x['path']).name).read_bytes();need(sha(b)==x['expected_sha256'] and x['match'],'historical receipt')
  old=(hist/'prior'/summary['source_sha256']).read_bytes();need(sha(old)==summary['source_sha256'],'original object')
  assessment=(hist/'ASSESSMENT-DELEGATED-SOURCE-ROLES-3.json').read_bytes();need(sha(assessment)==load(P/'SAME-LENS-REGISTRATION.json')['sha256'],'earlier assessment');role=json.loads(assessment)['historical_source_roles'][8];need(role['original_index']==2329 and role['new_personal_read_attribution']=='/root/rig_identity' and role['new_personal_read_ranges']==[[1,413]] and role['new_personal_read_revision']==summary['prior_same_lens']['current_revision'],'earlier same-lens scope')
  items=load(P/'PRIOR-DELEGATE-MEMBERS.json');dd=hist/'delegate'
  for x in items:
   b=(dd/x['captured']).read_bytes();need(len(b)==x['bytes'] and sha(b)==x['sha256'],'prior selected archive member')
  l1=(dd/'member-02.dat').read_bytes().splitlines()[22];l2=(dd/'member-03.dat').read_bytes().splitlines()[22];need(l1==l2 and sha(l1)==summary['prior_774']['original_and_variant_line23_sha256'],'prior trace line');rig=json.loads(l1);need(rig['id']=='RIG-PPS-023' and any(x.get('source_id')=='pr-working:crates/fabelgeist-physics/src/wgsl.rs' and x.get('read_ranges')==[[1,385]] for x in rig['additional_actual_source_proofs']),'prior trace scope')
  roots={};ci=load(d/'PRIVATE-COMMIT-IDENTITIES.json')
  for x in ci['commits']:
   b=(d/'private-commits'/(x['revision']+'.commit')).read_bytes();need(sha(b)==x['whole_commit_payload_sha256'] and oid(b'commit',b)==x['revision'] and b.splitlines()[0]==b'tree '+x['root_tree'].encode(),'private commit');roots[x['revision']]=x['root_tree']
  for x in proofs:need(roots[x['revision']]==x['root_tree'],'offline revision-root')
  working=(hist/'observed-BASELINE-95E-20261110.json').read_bytes();committed=(hist/'committed-dac7-baseline.json').read_bytes();need(sha(working)==summary['working_vs_dac7_ledger']['working_sha256'] and sha(committed)==summary['working_vs_dac7_ledger']['committed_sha256'] and working!=committed,'baseline identities'); wa=json.loads(working)['newly_assessed_ledger']['entries'];ca=json.loads(committed)['newly_assessed_ledger']['entries']
  for id in ['ADLER-L11-BOX-MEDIAL-NORMAL-PARITY','SEGOVB-L12-CONNECTED-PHYSICS-COLLIDER-NATIVE-COUNT-ADMISSION','SEGOVB-L12-CONNECTED-PHYSICS-COLLIDER-CAPACITY-ERROR-STATE','MESH-POSITION-UPDATE-LENGTH-TRUNCATION-RELATION','RIG-ADMISSION03-F082']:
   x=[v for v in wa if v.get('id')==id];y=[v for v in ca if v.get('id')==id];need(len(x)==len(y)==1 and x==y,'selected ledger '+id)
  archive=dd/'physics-contact-evidence.tar.gz';need(sha(archive.read_bytes())==load(P/'PRIOR-DELEGATE-ARCHIVE-REGISTRATION.json')['archive_sha256'],'prior archive');idx=load(hist/'transport-0.json');bundle=next(x for x in idx['bundles'] if x['bundle_id']=='physics-contact');expected={x['path']:x for x in bundle['members']};seen=set();count=0
  with tarfile.open(archive,'r:gz') as t:
   for mem in t:
    if not mem.isfile():continue
    need(mem.name not in seen and mem.name in expected and mem.size<=134217728,'prior archive member');seen.add(mem.name);x=expected[mem.name];f=t.extractfile(mem);hasher=hashlib.sha256();size=0
    while True:
     chunk=f.read(1048576)
     if not chunk:break
     hasher.update(chunk);size+=len(chunk)
    need(hasher.hexdigest()==x['published_sha256'] and size==x['published_bytes'],'prior public tuple');count+=1
  need(seen==set(expected) and count==126,'prior archive index set');archive_checked=True;restricted=True
 print(json.dumps({'result':'pass','public_files':len(found),'registered_views':nviews,'source_revision_pairs':len(unions),'git_tree_proofs':len(proofs),'repository_revision_binding_checked':bool(a.repository),'restricted_history_and_offline_commit_checked':restricted,'prior_public_archive_index_checked':archive_checked,'qualification':'Integrity and recorded ranges only; no product/shader execution, individual cognition, runtime reachability, global alias or queue/lens closure inferred.'},sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as e:print('evidence verification failed:',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
