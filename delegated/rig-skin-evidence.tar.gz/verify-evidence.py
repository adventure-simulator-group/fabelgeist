import gzip,hashlib,json,pathlib
b=pathlib.Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda k,x:hashlib.sha1(k.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest()
report=json.load(open(b/'REPORT.json'));h=json.load(open(b/'history-manifest.json'));m=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));index={x['path']:x for x in m['entries']};assert sha((b/'original-transport-manifest.json.gz').read_bytes())==h['original_transport_manifest_sha256']
for e in h['original_059_records']:
 raw=(b/e['preserved_bytes']).read_bytes();want=index[e['original_path']];assert len(raw)==e['bytes']==want['bytes'] and sha(raw)==e['sha256']==want['sha256'] and oid('blob',raw)==e['git_blob']==want['git_blob']
for e in h['older_774_receipts']:
 raw=(b/e['preserved_bytes']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
for e in h['related_current_delegate_reports']:
 raw=(b/e['preserved_bytes']).read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
for name,folder in [('registration.json','sources'),('support-registration.json','support'),('historical-support-registration.json','historical-support')]:
 r=json.load(open(b/name))
 for e in r['entries']:
  dest=(b/folder/e['revision'][:4]/e['path']) if folder=='sources' else (b/folder/e['path']);raw=dest.read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
p=json.load(open(b/'git-proofs.json'));objects={}
for oid_key,e in p['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==oid_key;objects[oid_key]=raw
def entries(raw):
 result={};i=0
 while i<len(raw):
  end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1);result[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());i=end+21
 assert i==len(raw);return result
for e in p['paths']:
 c=p['commits'][e['revision']];assert objects[c['commit_object']].splitlines()[0]==b'tree '+c['root_tree'].encode();current=c['root_tree']
 for link in e['path_chain']:
  assert link['tree']==current;mode,child=entries(objects[current])[link['name']];assert mode==link['mode'] and child==link['object'];current=child
 assert current==e['git_blob'] and '/'.join(x['name'] for x in e['path_chain'])==e['path']
assert not h['unavailable_original_records'];print('Evidence integrity passed: registered source bodies, 059 transport records, historical 774 records and raw Git path proofs; no product tests or probes.')
