import datetime,hashlib,json,subprocess,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');cur='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest();entries=[];body={}
planned=[('crates/adventuresim-tactical-client/src/presentation/config.rs',[[180,245]]),('crates/adventuresim-tactical-server/src/startup.rs',[[1,85]]),('crates/adventuresim-tactical-core/src/combat_config/defaults.rs',[[1,26]])]
for n,(path,ranges) in enumerate(planned):
 raw=subprocess.check_output(['git','-C',str(pub),'show',cur+':'+path]);oid=subprocess.check_output(['git','-C',str(pub),'rev-parse',cur+':'+path],text=True).strip();local=f'support/project-{n}.rs';body[local]=raw
 entries.append({'path':path,'revision':cur,'git_blob':oid,'sha256':h(raw),'eof':len(raw.splitlines()),'local':local,'prospective_ranges':ranges,'role':'bounded current support, never original ordered-role credit','earlier_personal_support':'Graphics full 1-404 in previous api/options packet; startup 27-42 and defaults 1-26 in role40 packet. Fresh registered displays remain separately documented.'})
archive=pub/'native-evidence/serde-saphyr-1.2.0/serde-saphyr-1.2.0.crate'
with tarfile.open(archive,'r:gz') as t:raw=t.extractfile('serde-saphyr-1.2.0/src/de/api.rs').read()
assert h(raw)=='02fd000004106ce209ca065c78b70c71a7b86ac03a3ddbedd48eb7e577358ce7';local='support/native-api.rs';body[local]=raw
entries.append({'path':'serde-saphyr-1.2.0/src/de/api.rs','revision':'native package 1.2.0 (not project Git)','package_sha256':h(archive.read_bytes()),'sha256':h(raw),'eof':len(raw.splitlines()),'local':local,'prospective_ranges':[[70,110]],'role':'fresh bounded native support only; previous role2573 own display 1-180 retained separately'})
d={'schema':'726-native-error-adapter-support-v1','reader':'/root/hair_ops','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':entries,'qualification':'Register before display; exact actual displays and unread complements in receipt.'}
with (r/'support-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for p,raw in body.items():(r/p).write_bytes(raw)
print('registered',d['registered_utc'],h((r/'support-registration.json').read_bytes()))
for x in entries:print(x['path'],x['eof'],x['sha256'],x['prospective_ranges'])
