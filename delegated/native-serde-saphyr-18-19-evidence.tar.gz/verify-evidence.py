'''Offline evidence verification only: never executes package or product code.'''
from pathlib import Path
import gzip,hashlib,json,tarfile,tomllib
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((r/'registration.json').read_bytes());sp=json.loads((r/'support-registration.json').read_bytes());old=json.loads((r/'historical-lock-registration.json').read_bytes());hist=json.loads((r/'historical-manifest.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());selected=json.loads((r/'historical-selections-reconstructed.json').read_bytes());proof=json.loads((r/'git-proofs.json').read_bytes());report=json.loads((r/'REPORT.json').read_bytes())
for x in hist['records']:
 b=(r/x['local']).read_bytes();assert h(b)==x['sha256'] and len(b)==x['bytes']
for x in rec['registrations']:assert h((r/x['path']).read_bytes())==x['sha256']
archive=r/'native/serde-saphyr-1.2.0.crate';ab=archive.read_bytes();assert h(ab)==reg['package']['archive_sha256']
registry_raw=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());assert h(registry_raw)==reg['registry_decompressed_sha256'];registry=json.loads(registry_raw)
recovery=json.loads((r/'recovered/MANIFEST.json').read_bytes());assert h((r/'recovered/objects.tar.gz').read_bytes())==reg['recovered_archive_sha256']==recovery['objects_archive_sha256'];assert h((r/'recovered/registry.json.gz').read_bytes())==recovery['registry_gzip_sha256']
queue_raw=gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(queue_raw);assert selected['registry_uncompressed_sha256']==h(registry_raw) and selected['queue_uncompressed_sha256']==h(queue_raw)
for i,x in selected['registry_rows'].items():assert x==registry['files'][int(i)]
for i,x in selected['queue_rows'].items():assert x==q['entries'][int(i)]
with tarfile.open(archive,'r:gz') as pkg,tarfile.open(r/'recovered/objects.tar.gz','r:gz') as original:
 for x in reg['rows']:
  b=(r/x['local']).read_bytes();assert h(b)==x['sha256']==registry['files'][x['original_index']]['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof'];assert pkg.extractfile(x['package_member']).read()==b==original.extractfile(x['sha256']).read()
 assert pkg.extractfile('serde-saphyr-1.2.0/src/de/api.rs').read()==(r/'support/native-api.rs').read_bytes()
 assert original.extractfile(old['sha256']).read()==(r/old['local']).read_bytes()
for lock in ['support/Cargo.lock','support/pr-working-Cargo.lock']:
 d=tomllib.loads((r/lock).read_text());entries=[x for x in d['package'] if x['name']=='serde-saphyr' and x['version']=='1.2.0'];assert len(entries)==1 and entries[0]['checksum']==h(ab) and entries[0]['source']=='registry+https://github.com/rust-lang/crates.io-index'
for x in rec['assigned_roles']+rec['support_reads']:
 b=(r/x['source']).read_bytes();assert len(b.splitlines())==x['eof'];occ=[]
 for lo,hi in x['display_union']+x['unread_complement']:
  assert 1<=lo<=hi<=x['eof'];occ.extend(range(lo,hi+1))
 assert len(occ)==x['eof'] and set(occ)==set(range(1,x['eof']+1))
for x in rec['assigned_roles']:
 rr=next(y for y in reg['rows'] if y['original_index']==x['index']);assert x['display_union']==rr['prospective_display_ranges']
for x in sp['entries']:
 a=next(y for y in rec['support_reads'] if y['source']==x['local']);assert a['display_union']==x['prospective_ranges'] and h((r/x['local']).read_bytes())==x['sha256']
assert next(x for x in rec['support_reads'] if x['source']==old['local'])['display_union']==old['prospective_ranges']
rows=[json.loads(l) for l in (r/'historical/774/00-additional-sources.jsonl').read_text().splitlines()];assert rows[152]['source_id']==reg['rows'][0]['source_id'] and rows[153]['source_id']==reg['rows'][1]['source_id']
for row,x in zip(rows[152:154],rec['assigned_roles']):assert row['read_ranges']==x['old_root_material'] and row['observed_sha256']==x['sha256']
coverage=[json.loads(l) for l in (r/'historical/059/evidence/audit11/inherited-coverage.jsonl').read_text().splitlines()];assert coverage[18]['ranges']==rec['assigned_roles'][0]['old_root_material'] and coverage[19]['ranges']==rec['assigned_roles'][1]['old_root_material']
objs={}
for k,x in proof['objects'].items():
 b=gzip.decompress((r/x['preserved']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'] and oid(x['type'],b)==k;objs[k]=b
def lookup(b,name):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,n=b[i:z].split(b' ',1);child=b[z+1:z+21].hex();i=z+21
  if n.decode()==name:return mode.decode(),child
 raise KeyError(name)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for node in x['chain']:
  assert tree==node['tree'];mode,child=lookup(objs[tree],node['name']);assert mode==node['mode'] and child==node['object'];tree=child
 b=(r/x['local']).read_bytes();assert oid('blob',b)==tree==x['blob'] and h(b)==x['sha256']
assert len(report['lens_perspectives'])==13 and report['implementation']=='not started'
if (r/'MANIFEST.json').exists():
 manifest=json.loads((r/'MANIFEST.json').read_bytes());filepaths={str(x.relative_to(r)) for x in r.rglob('*') if x.is_file() and x!=r/'MANIFEST.json'};assert filepaths=={x['path'] for x in manifest['files']}
 for x in manifest['files']:
  b=(r/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
print('PASS: archive and both lock checksums; 2 native roles; original source registry and historical rows; 10 offline Git membership chains; receipts and exact read/unread partitions; 13 bounded perspectives; packet manifest if present. No parser, build, test or product execution.')
