import datetime,gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
recover=Path('<LOCAL_PATH_1>')
archive=pub/'native-evidence/serde-saphyr-1.2.0/serde-saphyr-1.2.0.crate'
nativebase=Path('<LOCAL_PATH_2>')
sha=lambda b:hashlib.sha256(b).hexdigest()
cur='95e63628f9d70b8dd6e6fede64334696c6995009'; transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
registry_raw=gzip.decompress((recover/'registry.json.gz').read_bytes())
assert sha(registry_raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f'
reg=json.loads(registry_raw)['files']; package=archive.read_bytes()
assert sha(package)=='3afb591f9cdb6223c88ba39269aff895620c7f0716dc42b705b5733d5c7c0823'
scopes={18:[[1,120],[676,1100],[1920,2005],[2200,2280]],19:[[1,139]]}
rows=[]; contents={}
with tarfile.open(recover/'objects.tar.gz','r:gz') as recovered,tarfile.open(archive,'r:gz') as crate:
 for i,ranges in scopes.items():
  row=reg[i];name=row['source_id'].split(':',1)[1];digest=row['sha256'];raw=recovered.extractfile(digest).read();assert sha(raw)==digest
  assert crate.extractfile(name).read()==raw
  assert (nativebase/name).read_bytes()==raw
  obj='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+digest
  assert subprocess.check_output(['git','-C',str(pub),'show',transport+':'+obj])==raw
  contents[i]=raw
  rows.append({'original_index':i,'source_id':row['source_id'],'snapshot':row['snapshot'],'registry_row':row,'sha256':digest,'bytes':len(raw),'eof':len(raw.splitlines()),'package_archive':str(archive),'package_sha256':sha(package),'package_member':name,'old_recovered_archive_member':digest,'evidence_transport_revision':transport,'evidence_transport_path':obj,'local':f'source/role-{i}.rs','prospective_display_ranges':ranges,'qualification':'One external package source body; native package archive, recovered role object, local package cache, and f82 transport object match. Different representations and current Cargo lock membership do not mean additional source displays or a project-Git native source revision.'})
lock=subprocess.check_output(['git','-C',str(pub),'show',cur+':Cargo.lock']);blob=subprocess.check_output(['git','-C',str(pub),'rev-parse',cur+':Cargo.lock'],text=True).strip()
doc={'schema':'726-prospective-native-roles-18-19-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','source_scope':'Original native-dependency roles; old root original materials retained without transfer','project_baseline':cur,'registry_decompressed_sha256':sha(registry_raw),'recovered_archive_sha256':sha((recover/'objects.tar.gz').read_bytes()),'recovered_manifest_sha256':sha((recover/'MANIFEST.json').read_bytes()),'package':{'name':'serde-saphyr','version':'1.2.0','archive_sha256':sha(package),'archive_bytes':len(package)},'rows':rows,'project_support':[{'path':'Cargo.lock','revision':cur,'git_blob':blob,'sha256':sha(lock),'eof':len(lock.splitlines()),'local':'support/Cargo.lock','prospective_display_ranges':[[9370,9408]],'qualification':'current lock support only; remaining lock clauses unread'}],'earlier_same_agent_attribution':'Own earlier api/options packet covered native de/api.rs 1–180, de/options.rs 1–560, selected support windows and current Cargo.lock 9370–9418; neither role18 nor role19 was read there. Source credit here requires fresh display.','instruction':'Registration precedes all source displays; tests and examples as text only, no parsing/execution.'}
with (root/'registration.json').open('x') as f:json.dump(doc,f,indent=2);f.write('\n')
(root/'source').mkdir();(root/'support').mkdir();(root/'historical').mkdir()
for i,raw in contents.items():(root/f'source/role-{i}.rs').write_bytes(raw)
(root/'support/Cargo.lock').write_bytes(lock)
print('registered',doc['registered_utc'],'sha256',sha((root/'registration.json').read_bytes()))
for row in rows:print(row['original_index'],row['sha256'],'eof',row['eof'],'ranges',row['prospective_display_ranges'])
print('lock blob',blob,'sha256',sha(lock))
