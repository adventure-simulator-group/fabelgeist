# Bounded native serde-saphyr source audit

`REPORT.json` assesses original external native roles 18–19, their 1.2.0
package identity, and the limited pinned 95e project adapters. `read-receipt.json`
records personal display ranges and unread complements. Earlier root, Adler and
Segovb reviewer evidence is retained without changing its revision or credit.

The historical registry and source-object archives, full original queue in its
recovered compressed container, exact named historical records, crate archive,
source bytes, and offline Git object proofs are included. Historical selections
are newly reconstructed navigation views, not original records. The f82 commit
is a recovery transport; the crate is an external package and the old pr-working
lock object does not make its whole snapshot clean.

Run `python3 verify-evidence.py` for offline evidence integrity only. It checks
archive and lock identities, original registry ranges and source objects,
retained Git memberships, source read partitions and manifest. It does not run
the dependency or product. Implementation and product validation have not begun.
