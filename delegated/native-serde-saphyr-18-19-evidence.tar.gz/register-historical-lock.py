import datetime,gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent;p=Path('<LOCAL_PATH_0>');pub='<LOCAL_PATH_1>';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';h=lambda x:hashlib.sha256(x).hexdigest();row=json.load(gzip.open(p/'registry.json.gz','rt'))['files'][497]
with tarfile.open(p/'objects.tar.gz','r:gz') as t:b=t.extractfile(row['sha256']).read()
assert h(b)==row['sha256'];path='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];assert subprocess.check_output(['git','-C',pub,'show',f82+':'+path])==b
d={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','role':'bounded historical lock support only; not renewed ordered role497 credit','source_id':row['source_id'],'snapshot':row['snapshot'],'registry_row':row,'sha256':h(b),'eof':len(b.splitlines()),'local':'support/pr-working-Cargo.lock','prospective_ranges':[[9767,9783]],'transport_revision':f82,'transport_path':path,'qualification':'PR-working snapshot has unrelated modifications; this is its exact recovered per-file object, not an assertion of a clean 6533 or whole snapshot. Original root cites this same window as pin proof; historical attribution retained separately.'}
with (r/'historical-lock-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
(r/d['local']).write_bytes(b);print(d['registered_utc'],h((r/'historical-lock-registration.json').read_bytes()),'eof',d['eof'],'source sha',h(b))
