from pathlib import Path
import datetime,gzip,hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');old=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');ws=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**kw):
 p=r/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**kw})
def cp(p,local,kind):save(Path(p).read_bytes(),local,p,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz']:
 cp(prev/'recovered'/n,'recovered/'+n,'Recovered original data in retained transport; catalog and gzip container may be reconstructed, not newly attributed source reads.')
cp(pub/'native-evidence/serde-saphyr-1.2.0/serde-saphyr-1.2.0.crate','native/serde-saphyr-1.2.0.crate','Exact crates.io archive independently matched against both recorded lock checksums.')
for n in ['evidence/audit11/inherited-coverage.jsonl','adler/READ-L11-206.json','adler/READ-L11-217.json','adler/REGISTRATION-ADLER-354.json','segovb/READ-L12-698.json']:
 cp(old/n,'historical/059/'+n,'Exact original 059 historical material; prior author and revision remain separate from current reads.')
for n in ['COVERAGE-L01-ROLES.json','ASSESSMENT-COMBAT-CONFIG-ERROR-95E.json','ASSESSMENT-GRAPHICS-CONFIG-ADMISSION-95E.json']:
 cp(pub/n,'prior/'+n,'Central prior assessment or coverage record; reader attribution and revision unchanged.')
prior=Path('<LOCAL_PATH_4>')
for n in ['REPORT.json','MANIFEST.json','read-receipt.json']:
 cp(prior/n,'prior/api-options/'+n,'Earlier personal api/options packet; no read attribution transfer.')
for n in ['AGENTS.md','crates/AGENTS.md']:
 cp(ws/n,'rules/'+n,'Applicable repository guidance; user prohibition of validation remains controlling.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';base='handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/'
paths=['audit-existing-type-owners/root/additional-sources.jsonl','audit-existing-type-owners/root/contracts.jsonl','producer-supplement-after-owner/root/traces.jsonl']
for i,n in enumerate(paths):
 gp=base+n;raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{i:02d}-{Path(n).name}','git:'+rev+':'+gp,'Exact original 774 root record; f82 is a recovery transport commit.',transport_revision=rev,git_path=gp)
registry_raw=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());registry=json.loads(registry_raw);queue_raw=gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes());queue=json.loads(queue_raw);cat=json.loads((r/'recovered/catalog-774.json').read_bytes());cov=json.loads((r/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=[18,19,497];qs=[52,71,278,774,1547,1549,2241,2242]
selected={'kind':'Newly reconstructed selections for navigation only; full recovered queue and registry are included unchanged.','registry_uncompressed_sha256':h(registry_raw),'queue_uncompressed_sha256':h(queue_raw),'registry_rows':{str(i):registry['files'][i] for i in ids},'catalog_rows':{str(i):cat['rows'][i] for i in [18,19]},'coverage_rows':{str(i):cov['roles'][i] for i in [18,19]},'queue_rows':{str(i):queue['entries'][i] for i in qs},'qualification':'Preserve each exact original row, source ID, reviewer and historical revision. No historical record is checkpoint3821.'}
(r/'historical-selections-reconstructed.json').write_text(json.dumps(selected,indent=2)+'\n')
(r/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'qualification':'Original files, recovered source archives and explicitly reconstructed navigation selections are distinct. f82 is evidence transport, not native package revision.'},indent=2)+'\n')
print('retained',len(records),'historical manifest sha256',h((r/'historical-manifest.json').read_bytes()))
