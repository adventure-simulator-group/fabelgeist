from pathlib import Path
import datetime,hashlib,json
r=Path(__file__).resolve().parent;out=r/'MANIFEST.json';assert not out.exists();rows=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p!=out:
  b=p.read_bytes();rows.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
doc={'schema':'726-native-18-19-packet-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'qualification':'All packet files, including nested MANIFEST.json files, are enumerated; this top-level manifest does not include itself. Historical records and reconstructed selections keep their own attribution and revision.'};out.write_text(json.dumps(doc,indent=2)+'\n');print(len(rows),'files, sha256',hashlib.sha256(out.read_bytes()).hexdigest())
