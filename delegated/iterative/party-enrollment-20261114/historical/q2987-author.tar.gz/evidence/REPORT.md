# q2987: mission enum and state shapes

At pinned source commit 95e63628f9d70b8dd6e6fede64334696c6995009, the
selected mission source already uses data-carrying enrollment and terminal
variants for several lifecycle distinctions. This bounded review does not
establish a new enum-shape defect, a supported runtime outcome, a unique
finding count, or closure. It independently confirms a conditional effect
reporting question already recorded in ledger 1097.

`PartyEnrollment` separates awaiting, enrolling and sealed states; the two
active states retain the seen identities and empty duration across sealing.
`TerminalLifecycle` separately carries the frozen strategic resolution and
receipt in retry and submitting states, then carries a tactical presentation
outcome in presenting and finished states. A stalled acknowledgement enters
`TransportFailed`; the selected system exits without presenting an outcome.
The selected standalone branch applies local acceptance without establishing
a strategic transaction. These shapes should not be flattened solely because
some payload fields overlap. Their broader transition and serialization
contracts remain outside the inspected slice.

There is a concrete conditional overlap in the existing effect shape. If the
enrolling state has reached its expected seen count, no player is loading,
and reconnect grace is zero, `advance` changes the state to `Sealed` and then
returns `Abandoned`; this includes a symbolic input with one loaded party
member. The selected caller therefore takes the abandonment branch rather
than the separate seal-log branch. This is the existing ledger 1097
event-reporting and effect-priority question, not a new counted defect.
Whether callers must observe both the seal transition and abandonment, or
whether abandonment intentionally takes priority, remains a policy question.
If both must be conveyed, a separately typed transition and terminal decision
or an event sequence is one planning option; if priority is intentional, its
current behavior must be preserved. No shape change is prescribed here.
The distinct q3134/ledger 406 issue is the zero-grace threshold itself; its
supported input policy and product reach also remain open.

The private combat snapshot's `enrollment_sealed` boolean is supplied by the
selected system's readiness predicate: sealed enrollment *and* no loading
player. A false value therefore does not distinguish unsealed from sealed
while loading. The selected consumer uses it as an immediate gate; no need
for it to carry the two reasons separately is established. Its independently
stored counts and flag can represent incoherent aggregate inputs, while the
selected producer derives the flag from the same mission and uses one enemy
query and one party loop. The q2983 Lens 5 and q2989 Lens 11 assessments
separately cover that conditional aggregate issue; count conversion bounds,
other constructors, policy and supported reach remain open. No new alias is
inferred.

The selected timeout is already an `Option<Timer>`, with a source-level CLI
flag controlling timer construction. The predicate result, timeout option,
enemy and party hold durations, enrollment state and terminal state are not
shown to be one mutually exclusive state. The strategic-to-tactical outcome
projection is coarser, but follows the accepted branch; it is not shown to
replace the frozen resolution before submission. Parser macro behavior,
wire serialization, external callers, alternative products and tie policy
were not executed or exhaustively inspected.

Independent current views cover:

- `crates/adventuresim-tactical-server/src/mission/mod.rs:1-220`, including
  the test-configured helper at 214-220 as source text only.
- `crates/adventuresim-tactical-server/src/mission/enrollment.rs:1-68,70-125`
  and `crates/adventuresim-tactical-server/src/mission/systems.rs:21-110,112-277`
  for construction, transitions, predicates and the selected consumer.
- `crates/adventuresim-tactical-server/src/mission/terminal.rs:1-203` and
  `crates/adventuresim-tactical-server/src/main.rs:64-106,119-120,168-176`
  for lifecycle payloads, presentation, timeout and startup boundaries.

The original 059 q2987 row names mission/mod.rs at 6533, required lines 1-220
of 362, with own-Lens-9 evidence pending and no own-lens assessed ranges. Its
f2c wrapper remains unassessed. The selected original and reconstructed row
bytes match, while their full streams differ. The same file has identical
Git bytes at 6533, e275 and 95e, but the three trees differ.

No attributable earlier Lens 9 read of this exact mission file was located
in the bounded searches. That is not a claim that no such record exists:
opaque checkpoint snapshots, compressed material and differently named or
embedded receipts were not exhausted. The separately recovered normalized
774 catalog identifies source-registry entry 2063 and explicitly records that
source recovery is not audit coverage; its pre-export original and referenced
older object path remain unavailable. A separately recovered nested Lens 9
state has no exact mission-path or numeric-2063 object in this structural
selection; its hash is not linked from the separately map-verified root
state. Neither record identifies a prior individual q2987 reader or supplies
current credit. Source-registry entry 2063 is distinct from queue row q2063.

Other-lens evidence remains separate: Native's registered Lens 5 continuation
and later group reports describe `pr-working` reads, with no standalone
revision on the selected historical row; the complete original JSONL was not
recovered. The q2983 correction keeps the explicit numerical witness in the
separately attributed q2989 report. Adler's Lens 11 receipt attests reads
1-158 and 159-220, with Segovb qualification but no new Segovb read. Root's
6533 Lens 3 read covers 1-220; its e275 qualified reuse records zero fresh
personal lines and pending frozen-source adoption. None transfers Lens 9
credit. The separate q3059 Lens 9 enrollment assessment and its correction
were captured and replayed; its full original/reconstructed queue membership
was not repeated by that prior verifier here. The later q2983 Lens 5 report
and correction were also captured and replayed with available anchors.

Seventeen current windows were independently registered and displayed; the
test-configured helper was not executed, and the 221-362 tail was not
personally displayed. Personal display is reviewer-attested rather than
independently telemetered. This reviewer previously worked on q2980 Lens 1,
q2989 Lens 11 peer and q2990/q3062 Lens 12; those and the parallel q2990 and
q2983 reviews retain their own authorship and do not supply this read credit.

Historical filename-only navigation included an initial no-match glob and
two clipped metadata filename displays, followed by bounded recorded
successors. A prior-report filename lookup failed, and one historical
metadata display was clipped; exact raw tool envelopes for those incidents
were not separately saved and their descriptions are reconstructed. An
older referenced collection was unavailable. None supplied source-read
credit or supports a global absence claim.

The protected extraction, original 059 stream, Git objects and prior packets
remain separately held same-machine dependencies, not independent backup or
full Git closure. Checkpoint 3821, SOURCE004, 73 nontext/no-positive-EOF
obligations and the missing pre-export originals behind reconstructed 440 and
normalized 774 remain unresolved. No product code, tests, fixtures, builds,
repairs, runtime probes, queue edits or ledger edits were performed.
