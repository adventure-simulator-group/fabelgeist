#!/usr/bin/env python3
"""Verify public evidence bytes; optional external same-machine identity checks are not runtime validation."""
import argparse,hashlib,json,pathlib,re,subprocess
P=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_bytes())
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.PIPE)
def raw(b,n):
 s=b.decode();m=re.search(r'"entries"\s*:\s*\[',s);assert m;pos=m.end();d=json.JSONDecoder()
 for i in range(n+1):
  while s[pos] in ' \t\r\n,':pos+=1
  start=pos;v,pos=d.raw_decode(s,pos)
 return v,s[start:pos].encode()
a=argparse.ArgumentParser();a.add_argument('--repo');a.add_argument('--checkpoint-repo');a.add_argument('--original');a.add_argument('--author-public');a.add_argument('--prior-l1');a.add_argument('--prior-l5');a.add_argument('--prior-l12');args=a.parse_args()
m=J(P/'MANIFEST.json'); names={x.name for x in P.iterdir()};assert names==set(m['files'])|{'MANIFEST.json'}
for name,e in m['files'].items():
 p=P/name;assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert len(b)==e['bytes'] and H(b)==e['sha256']
b=J(P/'BINDING.json');views=J(P/'SOURCE-MAP.json')['views'];assert len(views)==19
if args.repo:
 assert git(args.repo,'rev-parse',b['source_revision']+'^{tree}').decode().strip()==b['source_tree'];memo={}
 for v in views:
  path=v['path']
  if path not in memo:
   x=git(args.repo,'show',b['source_revision']+':'+path);assert H(x)==v['source_sha256'] and len(x.splitlines())==v['EOF'];assert git(args.repo,'rev-parse',b['source_revision']+':'+path).decode().strip()==v['blob'];memo[path]=x.decode().splitlines()
  lo,hi=v['range'];x=''.join(f'{n:4d}  {memo[path][n-1]}\n' for n in range(lo,hi+1)).encode();assert x==(P/v['file']).read_bytes() and H(x)==v['sha256']
if args.original:
 o=pathlib.Path(args.original).read_bytes();assert H(o)==b['original_queue_sha256'] and H(raw(o,2987)[1])==b['q2987_selected_raw_sha256']
if args.checkpoint_repo:
 repo=args.checkpoint_repo;rev=b['checkpoint'];assert git(repo,'rev-parse',rev+'^{tree}').decode().strip()==b['checkpoint_tree'];q=git(repo,'show',rev+':baseline-059/queue.json');w=git(repo,'show',rev+':RECONCILIATION-059.json');l=git(repo,'show',rev+':BASELINE-95E-20261110.json');assert H(q)==b['reconstructed_queue_sha256'] and H(w)==b['reconciliation_sha256'] and H(l)==b['ledger_sha256'];assert H(raw(q,2987)[1])==b['q2987_selected_raw_sha256'];rows=json.loads(w)['entries'];ledger=json.loads(l)['newly_assessed_ledger']['entries'];assert rows[2987]['current_reconciliation']=='unassessed' and ledger[1097]['id']=='relationship-enrollment-seal-abandon-effect-priority-95e' and ledger[406]['id']=='SEGOVB-L3-PARTY-ZERO-GRACE-ABANDONMENT'
if args.author_public:
 p=pathlib.Path(args.author_public);assert H((p/'MANIFEST.json').read_bytes())==b['author_public_manifest_sha256'] and H((p/'REPORT.md').read_bytes())==b['author_report_sha256']
for arg,key in ((args.prior_l1,'q2980_l1'),(args.prior_l5,'q2983_l5'),(args.prior_l12,'q2990_l12')):
 if arg:assert H((pathlib.Path(arg)/'MANIFEST.json').read_bytes())==b['prior_public_manifest_sha256'][key]
print(json.dumps({'result':'pass','verified_views':len(views),'external_anchors':{k:bool(v) for k,v in vars(args).items()},'limits':'Evidence identities only. Optional same-machine anchors do not establish independent backup, product execution, supported reach, global historical absence, authentication, source-credit transfer or closure.'},indent=2))
