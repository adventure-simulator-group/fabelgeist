#!/usr/bin/env python3
import pathlib,hashlib,json,argparse,subprocess,re
p=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((p/n).read_bytes());m=J('MANIFEST.json');assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,v in m['files'].items():
 q=p/n;assert q.is_file() and not q.is_symlink();b=q.read_bytes();assert len(b)==v['bytes'] and H(b)==v['sha256']
a=argparse.ArgumentParser();a.add_argument('--repo');a.add_argument('--checkpoint-repo');a.add_argument('--original');a.add_argument('--history-extraction');a.add_argument('--prior-incident');a=a.parse_args();B=J('BINDING.json');S=J('SOURCE-MAP.json');assert len(S['views'])==21
G=lambda repo,*args:subprocess.run(['git','-C',str(repo),*args],capture_output=True,check=True).stdout
def raw(data,n):
 s=data.decode();m=re.search(r'\"entries\"\s*:\s*\[',s);assert m;pos=m.end();d=json.JSONDecoder()
 for i in range(n+1):
  while s[pos] in ' \t\r\n,':pos+=1
  start=pos;v,pos=d.raw_decode(s,pos)
 return v,s[start:pos].encode()
if a.repo:
 assert G(a.repo,'rev-parse',B['source_revision']+'^{tree}').decode().strip()==B['source_tree'];cache={}
 for v in S['views']:
  path=v['path'];b=cache.setdefault(path,G(a.repo,'show',B['source_revision']+':'+path));assert H(b)==v['blob_sha256'];ls=b.decode().splitlines();assert len(ls)==v['eof'];x,y=v['range'];assert ''.join(f'{i:4d}  {ls[i-1]}\n' for i in range(x,y+1)).encode()==(p/v['artifact']).read_bytes()
 primary=S['views'][0]
 for r in ['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f']:assert H(G(a.repo,'show',r+':'+primary['path']))==primary['blob_sha256']
if a.checkpoint_repo:
 cp=B['checkpoint'];assert G(a.checkpoint_repo,'rev-parse',cp+'^{tree}').decode().strip()==B['checkpoint_tree'];q=G(a.checkpoint_repo,'show',cp+':baseline-059/queue.json');w=G(a.checkpoint_repo,'show',cp+':RECONCILIATION-059.json');l=G(a.checkpoint_repo,'show',cp+':BASELINE-95E-20261110.json');assert H(q)==B['reconstructed_queue_sha256'] and H(w)==B['wrapper_sha256'] and H(l)==B['ledger_sha256'];assert H(raw(q,2982)[1])==B['q2982_sha256'] and H(raw(q,3134)[1])==B['q3134_sha256'];assert json.loads(w)['entries'][2982]['current_reconciliation']=='unassessed' and json.loads(w)['entries'][3134]['current_reconciliation'].startswith('partial');assert json.loads(l)['newly_assessed_ledger']['entries'][406]['id']=='SEGOVB-L3-PARTY-ZERO-GRACE-ABANDONMENT';assert H(G(a.checkpoint_repo,'show',cp+':ASSESSMENT-MISSION-ENROLLMENT-95E.json'))==B['prior_assessment_sha256']
if a.original:
 b=pathlib.Path(a.original).read_bytes();assert H(b)==B['original_059_sha256'];assert H(raw(b,2982)[1])==B['q2982_sha256'] and H(raw(b,3134)[1])==B['q3134_sha256']
if a.history_extraction:
 root=pathlib.Path(a.history_extraction);checks={'root-l3-extension-20261030/REGISTRATION-ROOT-L3-EXT-020-027.json':'52cd1cccefd4bd8e9a4e433696ca018b72ff6603ed17cedaf3fa65dc9af8b3e8','root-l3-extension-20261030/READ-ROOT-L3-EXT-020-027.json':'8f42acb336d90954c4c59d4f729197f4a29c5e7b00f96935ca58615ccb215ce8','root-l3-extension-20261030/REGISTRATION-ROOT-L3-CURRENT-002.json':'55d4b0516eb53b37d6e0f7ee65f2b3864ff23b9507dc1640329cf8be6ad729d3','root-l3-extension-20261030/READ-ROOT-L3-CURRENT-002.json':'ec1ed3123f364a2db3c7267e3d31da590e21a6f794058da9a38ce2532a73ab52','root-l3-extension-20261030/CONTRACT-PROPOSALS-ROOT-L3-EXT-CURRENT-003.json':'675ea1e1ef9fb98fa5f6673016551be95f08ddaf02d3e65a3b4931cb5bd73434','segovb/STATE-L3-EXT-CURRENT-003.json':'7b9cdcef87236aa23898361a3be5bd246dce6fe16cef5479e9da76801c93130e'}
 for rel,h in checks.items():assert H((root/rel).read_bytes())==h
if a.prior_incident:
 q=pathlib.Path(a.prior_incident);b=(q/'PRIVATE-MANIFEST.json').read_bytes();assert H(b)==B['prior_incident_manifest_sha256'];e=next(x for x in json.loads(b)['entries'] if x['path']=='PROCESS-CORRECTION.json');assert H((q/'PROCESS-CORRECTION.json').read_bytes())==e['sha256']
print(json.dumps({'result':'PASS','view_count':len(S['views']),'repo_checked':bool(a.repo),'checkpoint_checked':bool(a.checkpoint_repo),'original_checked':bool(a.original),'history_checked':bool(a.history_extraction),'prior_incident_checked':bool(a.prior_incident),'qualification':'Byte and metadata checks only; no product execution, reachable failure, policy, independent display telemetry, private-original recovery or lens closure.'}))
