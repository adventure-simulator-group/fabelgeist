# q2982: mission invariant operations

This is a bounded source-only Lens 4 assessment at
`95e63628f9d70b8dd6e6fede64334696c6995009`. The assigned source is
`crates/adventuresim-tactical-server/src/mission/mod.rs:1–220`; positive EOF
is 362. Lines 214–220 are a test-configured helper read as text only. Lines
221–362 are outside this personal source slice. No test, fixture, product
program, build, repair or runtime probe was executed, and no queue/lens
closure or new finding count is claimed.

## Existing zero-grace operation

`MissionState::new` retains a `Duration` reconnect grace while its expected
party size is `NonZeroU32` (`mission/mod.rs:39–53`); the selected system passes
the retained grace into enrollment (`mission/systems.rs:191–216`). Once an
admitted loaded party member or a loading player has begun enrollment,
`PartyEnrollment::advance` resets `empty_for` to zero while the party is
present or loading, then performs an unconditional `empty_for >=
reconnect_grace` comparison (`mission/enrollment.rs:40–59,70–110`). For the
representable value `Duration::ZERO`, the comparison is true after that reset,
so the selected method returns `Abandoned` even with that party present or
loading. The system then enters its `Failed` frozen-terminal submission path
(`mission/systems.rs:211–231,52–67`); successful external submission, database
commit and player-visible outcome are not established.

The default selected by this source is ten seconds
(`mission/systems.rs:21–27`). The command-line field is an `f32` with no
explicit nonzero range on the shown declaration (`src/main.rs:98–106`), and
the selected transformer only changes enemy count (`src/bot.rs:57–62`); the
value is converted to `Duration` for `MissionState` (`src/main.rs:119–120,
168–176`). Parser/macro expansion, native conversion behavior for other values,
actual server startup and supported runtime reach were not tested. Zero-grace
policy remains open: immediate abandonment for an actually empty party and
abandonment while a member is present are distinct behaviors. The awaiting
state without a loaded or loading party returns before this comparison
(`mission/enrollment.rs:97–100`).

This is not a new issue. Published f2c ledger 406,
`SEGOVB-L3-PARTY-ZERO-GRACE-ABANDONMENT`, and its
`ASSESSMENT-MISSION-ENROLLMENT-95E.json` already record the same conditional
operation and selected submission path, with Lens 4 among the current lenses.
The original q3134 record has no status field; its f2c wrapper is partial.
The current review independently corroborates a bounded cross-lens relationship
and does not transfer the earlier read to q2982 or add a count.

## Other bounded operation checks

The two combat hold durations use `Duration::saturating_add` and reset to zero
when their respective condition is false; ineligible snapshots reset both
(`mission/mod.rs:175–210`). The threshold is three seconds and simultaneous
party/enemy defeat selects failure first (`mission/mod.rs:21,191–201`). A
large caller-provided delta can satisfy a hold in one advance; the selected
caller passes `Time::delta()` (`mission/systems.rs:234–245`). Whether such a
delta is supported and the intended timing policy are open, not demonstrated
runtime failures. `tick_timeout` delegates to Bevy's `Timer` and reads its
finished state (`mission/mod.rs:156–162`); native timer behavior and feature
resolution were not audited. The selected timeout caller ticks before checking
that the terminal is running (`mission/systems.rs:258–276`), while the
inspected terminal lifecycle has no transition back to Running
(`mission/terminal.rs:14–140`); no retry or state-loss consequence is shown.

The terminal lifecycle uses saturating addition for acknowledgement and retry
deadlines and saturating subtraction for presentation time
(`mission/terminal.rs:41–140`). As a symbolic API boundary, if a valid frozen
terminal is begun at `Duration::MAX` with a positive timeout, its stored
acknowledgement deadline saturates to that same value, and a stalled check at
the same timestamp returns true (`terminal.rs:41–55,119–127`). The selected
system supplies `Time::elapsed()` and a ten-second acknowledgement timeout
(`mission/systems.rs:21–23,52–67,146–156`); actual reach of that clock value,
selected scheduling, policy, and any external effect remain unproved. This is
a representable boundary question, not a demonstrated product failure. A
bounded ledger keyword search found no named terminal-deadline match, but it
was not an exhaustive alias search.

## History and coverage

Original 059 q2982 is `own-lens-proof-qualification-or-read-pending`, with
6533 and e275 required ranges 1–220 and zero own-Lens4 body credit; the f2c
wrapper remains unassessed. Root's earlier 6533 Lens 3 receipt records a fresh
personal 1–220 read with no reported output truncation. The e275 Lens 3
receipt records same-lens reuse with no fresh e275 read and explicitly makes
acceptance dependent on adopting the frozen source first. It is not fresh
Lens 4 evidence. The 6533, e275 and 95e Git bytes match for this file only;
this does not establish whole-tree equality or checkpoint3821 recovery. The
full original and reconstructed 059 streams differ; raw q2981–q2983 and q3134
selected rows match. The bounded exact-path locator found no separately named
Lens 4 historical read receipt; this is not a claim of global absence. The
published ledger 406 assessment already lists current Lens 4, as above.

Neighboring q2981 Lens 2 and q2983 Lens 5 are separate obligations. Prior
q2990 Lens 12 mission-module review, q3000 Lens 10 systems review, q3059
Lens 9 enrollment review, q3083 Lens 9 receipt review and q3100 bot review
retain their own readers and scope; no credit or alias transfers. The f2c
wrapper for q3059 is partial; those for q2990/q3000/q3083 are unassessed.

Twenty-one preregistered windows were displayed and are reviewer-attested,
not independently telemetered. The initial caller registration incorrectly
said all test modules began at line 424: `src/main.rs:390–423`, which was
personally displayed, is a test helper under a compound cfg at line 365. Its
exact display and correction are retained as process-only test/fixture text;
it supplies no production credit. The primary test helper at 214–220 was
registered as test text. Captured whole source blobs can contain other test
text that was not displayed and is not personal read credit. The earlier
q2973 scratch-copy mode incident remains separately sealed and is not erased
or transferred into this task. No product, queue, ledger or checkpoint file
was modified.
