#!/usr/bin/env python3
"""Verify a bounded source-evidence packet; optional local Git is read-only."""
from pathlib import Path
import argparse,hashlib,json,os,stat,subprocess,sys
if sys.flags.optimize:raise SystemExit('unoptimized interpreter required')
a=argparse.ArgumentParser();a.add_argument('--git-repository');a.add_argument('--strict-modes',action='store_true');z=a.parse_args();root=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((root/'MANIFEST.json').read_bytes());expected={x['path']:x for x in m['files']};expected_dirs={x['path']:x for x in m['directories']};actual={};dirs={}
if z.strict_modes:assert oct(stat.S_IMODE(root.stat().st_mode))==m['root_mode']
for q in root.rglob('*'):
 assert not q.is_symlink();rel=q.relative_to(root).as_posix();mode=oct(stat.S_IMODE(q.stat().st_mode))
 if q.is_dir():dirs[rel]=mode
 elif q.is_file() and rel!='MANIFEST.json':actual[rel]=(q.read_bytes(),mode)
 else:assert q.is_file()
assert set(dirs)==set(expected_dirs) and set(actual)==set(expected)
if z.strict_modes:assert all(dirs[k]==v['mode'] for k,v in expected_dirs.items())
for name,row in expected.items():
 b,mode=actual[name];assert len(b)==row['bytes'] and h(b)==row['sha256']
 if z.strict_modes:assert mode==row['mode']
 else:assert bool(int(mode,8)&0o100)==bool(int(row['mode'],8)&0o100)
idx=json.loads((root/'SOURCE-INDEX.json').read_bytes());checked=0
for v in idx['windows']:
 b=(root/v['file']).read_bytes();assert h(b)==v['window_sha256'];checked+=1
if z.git_repository:
 env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update({'GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'})
 def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',z.git_repository,*args],env=env,stderr=subprocess.PIPE)
 def oid(t,b):return hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
 commits={};blobs={}
 for v in idx['windows']:
  commit=v['commit'];tree=v['tree'];path=v['path']
  if commit not in commits:
   raw=git('cat-file','commit',commit);assert oid('commit',raw)==commit and raw.splitlines()[0].decode()=='tree '+tree;commits[commit]=tree
  else:assert commits[commit]==tree
  key=(commit,path)
  if key not in blobs:
   raw=git('cat-file','blob',commit+':'+path);assert oid('blob',raw)==v['blob'] and h(raw)==v['source_sha256'];blobs[key]=raw.splitlines(keepends=True)
  lines=blobs[key];lo,hi=v['range'];assert 1<=lo<=hi<=len(lines);data=b''.join(f'{i:05d}: '.encode()+lines[i-1] for i in range(lo,hi+1));assert data==(root/v['file']).read_bytes()
print(json.dumps({'packet_files':len(actual),'source_windows':checked,'git_check_performed':bool(z.git_repository),'strict_modes':z.strict_modes,'qualification':'Evidence identities only; manifest needs an external anchor, prior attribution and product behavior remain separately qualified.'}))
