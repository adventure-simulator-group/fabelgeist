# Independent q2982 Lens 4 peer review

The zero-grace source operation is supported and is already recorded by
q3134 and ledger 406. With zero reconnect grace, an enrolling or sealed
party that has an admitted loaded member or a loading player has its empty
clock reset to zero. The unconditional `>=` check then returns `Abandoned`.
The selected system maps that effect to a frozen Failed terminal resolution.
This is conditional source reasoning; supported configuration reach, scheduling,
intended zero-grace policy, and any external result remain open.

The awaiting state without a loaded or loading player returns before the
threshold comparison. The selected CLI uses a ten-second default and exposes
an f32 grace field without an explicit zero restriction in the displayed
declaration. The selected fixture transformer changes enemy count, while the
constructor retains the converted duration. No parser expansion, startup,
conversion probe, database transaction or player-visible behavior was run.
In standalone mode the selected submission function can resolve locally;
with a connection it queues or schedules retry. A frozen Failed value does not
establish external acceptance or a committed database change.

At the separate terminal deadline boundary, `now = Duration::MAX` plus a
positive acknowledgement timeout saturates to the same maximum value. If the
lifecycle remains `Submitting` until `fail_if_ack_stalled` is called at that
time, its `>=` comparison marks the transport failed. Standalone immediate
acceptance, enqueue failure, a callback or another transition may intervene.
The selected system uses elapsed time and a ten-second timeout, but no
reachable maximum clock, scheduler order, effect or intended policy is shown.
The earlier operation is the existing ledger 406 finding; this deadline case
is a distinct conditional question with aliases and counts open.

The two combat outcome holds saturating-add elapsed time when their conditions
hold and reset otherwise; an ineligible snapshot resets both, and simultaneous
thresholds choose failure. A sufficiently large caller delta can meet the
three-second hold in one advance, but supported delta and policy remain open.
The timeout delegates to a Bevy timer; this review does not establish its native
implementation or retry effect.

Independent 95e source views and identities are in `SOURCE-INDEX.json`:

- `mission/mod.rs:39-54,82-106,145-162,175-210` retains grace and performs
  hold and timeout operations;
- `mission/enrollment.rs:40-60,70-110` starts enrollment, seals when ready,
  resets the empty clock and compares the threshold;
- `mission/systems.rs:21-27,52-107,146-156,175-245,258-276` supplies
  defaults, advances enrollment, routes failure and checks stalled submission;
- `mission/terminal.rs:14-86,89-140` retains terminal state, saturates
  deadlines, handles results and compares the acknowledgement deadline; and
- `main.rs:90-106,119-120,168-176` and `bot.rs:57-62` show the selected
  configuration and transformer boundaries.

All paths are under `crates/adventuresim-tactical-server/src/`. This is a
bounded peer review, not a complete personal reread of the historical 1-220
scope: the test-configured helper at 214-220 and the later tail remain outside
our own displayed range. Captured full blobs support identity, not read credit.

Original q2982 records 6533 lines 1-220 with no own-Lens-4 assessed range;
the f2c wrapper is unassessed. Its selected original and reconstructed bytes
match although the whole queues differ. Root personally read the bounded 6533
Lens 3 scope. The e275 receipt explicitly has zero fresh ranges, same-lens
reuse and pending frozen-source adoption. Original q3134 repeats the earlier
personal-attribution label on its e275 record; the receipt, ledger 406 and the
prior current assessment provide the narrower interpretation. q3134 lacks an
original status field and its f2c wrapper is partial. No historical reading or
other lens transfers credit. Equal primary file bytes at 6533, e275 and 95e
are not whole-tree equality or checkpoint 3821 recovery.

The author personally displayed a registered `main.rs:390-423` range that was
unexpectedly test-fixture text under a compound test configuration. The author
preserved it as process-only and corrected the marker scan; no test or fixture
ran. The author also retained the separately sealed q2973 scratch-copy incident:
the target was written with truncating rather than exclusive creation in a
fresh directory, without an immediate existence check. Prior target bytes and
concurrent interference cannot be ruled out; no move or removal was reported.
The author's private replay has an additive qualification naming this prior
incident as an external dependency.

This review's first full display of the registered prior assessment was
truncated by the tool. The captured exact assessment bytes were unaffected;
a separately registered bounded display of relevant JSON pointers followed.
Displays are reviewer-attested, not independent telemetry. No source, ledger or
publication file was changed. No example, product, test, fixture, build, repair
or runtime probe ran; alias, count and closure decisions remain open.
