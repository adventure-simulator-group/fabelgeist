# Precision correction

The prior Native Lens 5 report records the broader incoherent raw-count and boolean snapshot relationship; the selected Native passage does not itself give the specific `loaded=1, incapacitated=2` numerical witness. That witness is stated in the separately attributed q2989 Lens 11 author and peer reports. Both describe the same surrounding aggregate question without establishing a global alias or an additional count. Read this correction with the original assessment; neither source nor historical evidence was changed.
