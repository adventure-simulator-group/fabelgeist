#!/usr/bin/env python3
"""Verify q2983 evidence only; never execute product code."""
import pathlib,hashlib,json,argparse,subprocess,re
p=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();J=lambda n:json.loads((p/n).read_bytes());m=J('MANIFEST.json');assert {x.name for x in p.iterdir()}==set(m['files'])|{'MANIFEST.json'}
for n,v in m['files'].items():
 q=p/n;assert q.is_file() and not q.is_symlink();b=q.read_bytes();assert len(b)==v['bytes'] and H(b)==v['sha256']
a=argparse.ArgumentParser();a.add_argument('--repo');a.add_argument('--checkpoint-repo');a.add_argument('--original');a.add_argument('--history-extraction');a.add_argument('--native-115');a.add_argument('--native-117');a.add_argument('--prior-l1');a.add_argument('--prior-l11');a.add_argument('--peer-l11');a=a.parse_args();B=J('BINDING.json');S=J('SOURCE-MAP.json');hist=J('HISTORY.json');assert len(S['views'])==18
G=lambda repo,*args:subprocess.run(['git','-C',str(repo),*args],capture_output=True,check=True).stdout
def raw(data,n):
 s=data.decode();pos=re.search(r'"entries"\s*:\s*\[',s).end();d=json.JSONDecoder()
 for i in range(n+1):
  while s[pos] in ' \t\r\n,':pos+=1
  start=pos;v,pos=d.raw_decode(s,pos)
 return v,s[start:pos].encode()
for v in S['views']:
 lo,hi=v['range'];assert all(any(x<=i<=y for x,y in v['displayed_ranges']) for i in range(lo,hi+1));assert H((p/v['artifact']).read_bytes())==v['view_sha256']
if a.repo:
 assert G(a.repo,'rev-parse',B['source_revision']+'^{tree}').decode().strip()==B['source_tree'];cache={}
 for v in S['views']:
  path=v['path']
  if path not in cache:cache[path]=G(a.repo,'show',B['source_revision']+':'+path)
  b=cache[path];assert H(b)==v['blob_sha256'];ls=b.decode().splitlines();assert len(ls)==v['EOF'];lo,hi=v['range'];assert ''.join(f'{i:4d}  {ls[i-1]}\n' for i in range(lo,hi+1)).encode()==(p/v['artifact']).read_bytes()
 for old in B['historical_revisions']:assert H(G(a.repo,'show',old+':'+S['views'][0]['path']))==S['views'][0]['blob_sha256']
if a.checkpoint_repo:
 cp=B['checkpoint'];assert G(a.checkpoint_repo,'rev-parse',cp+'^{tree}').decode().strip()==B['checkpoint_tree'];q=G(a.checkpoint_repo,'show',cp+':baseline-059/queue.json');w=G(a.checkpoint_repo,'show',cp+':RECONCILIATION-059.json');l=G(a.checkpoint_repo,'show',cp+':BASELINE-95E-20261110.json');assert H(q)==B['reconstructed_queue_sha256'] and H(w)==B['wrapper_sha256'] and H(l)==B['ledger_sha256'];assert H(raw(q,2983)[1])==B['q2983_sha256'];W=json.loads(w)['entries'];assert W[2983]['current_reconciliation']=='unassessed' and W[2980]['current_reconciliation']=='unassessed' and W[2989]['current_reconciliation']=='unassessed';L=json.loads(l)['newly_assessed_ledger']['entries'];assert L[406]['id']=='SEGOVB-L3-PARTY-ZERO-GRACE-ABANDONMENT' and L[1097]['id']=='relationship-enrollment-seal-abandon-effect-priority-95e' and L[1134]['id']=='REL-FIXTURE-COUNT-PROPAGATION-95E'
 for x in hist['published_reports']:assert H(G(a.checkpoint_repo,'show',cp+':'+x['name']))==x['sha256']
if a.original:
 b=pathlib.Path(a.original).read_bytes();assert H(b)==B['original_059_sha256'];v,x=raw(b,2983);assert H(x)==B['q2983_sha256'] and v['contract_id']=='OBLIGATION-ROOT-L3-EXT-0023-LENS-05'
if a.history_extraction:
 root=pathlib.Path(a.history_extraction)
 for x in hist['protected_l3_documents']:
  b=(root/x['relative_path']).read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
for param,name in [(a.native_115,'group115'),(a.native_117,'group117')]:
 if param:
  b=pathlib.Path(param).read_bytes();assert H(b)==hist['native_groups'][name]['sha256'];v=json.loads(b)
  if name=='group115':
   s=next(x for x in v['source_members'] if x['source_id'].endswith('/mission/mod.rs'));d=next(x for x in v['registered_direct_dependencies'] if x['registration_id']=='NATIVE-INITIAL05-REG027');assert s['scoped_ranges_compared']==[[1,158]] and d['scoped_ranges_compared']==[[159,212]] and d['source_body_proof']=='Fresh exact registered body after registration'
  else:assert v['existing_range_overlay']['ranges']==[[159,212]]
def prior(root,sha,name):
 q=pathlib.Path(root);b=(q/'PRIVATE-MANIFEST.json').read_bytes();assert H(b)==sha;entry=next(x for x in json.loads(b)['entries'] if x['path']==name);assert H((q/name).read_bytes())==entry['sha256']
if a.prior_l1:prior(a.prior_l1,B['prior_l1_manifest_sha256'],'ASSESSMENT.md')
if a.prior_l11:prior(a.prior_l11,B['prior_l11_manifest_sha256'],'ASSESSMENT.md')
if a.peer_l11:
 q=pathlib.Path(a.peer_l11);assert H((q/'MANIFEST.json').read_bytes())==B['peer_l11_manifest_sha256'];v=json.loads((q/'MANIFEST.json').read_bytes());assert H((q/'REPORT.md').read_bytes())==next(x['sha256'] for x in v['files'] if x['name']=='REPORT.md')
print(json.dumps({'result':'PASS','public_view_count':len(S['views']),'repo':bool(a.repo),'checkpoint':bool(a.checkpoint_repo),'original':bool(a.original),'history_l3':bool(a.history_extraction),'native115':bool(a.native_115),'native117':bool(a.native_117),'prior_l1':bool(a.prior_l1),'prior_l11':bool(a.prior_l11),'peer_l11':bool(a.peer_l11),'limits':'Selected evidence only; external original Native JSONL stream not recovered. Same-machine anchors; display reviewer-attested; no product execution, reach, count or closure.'}))
