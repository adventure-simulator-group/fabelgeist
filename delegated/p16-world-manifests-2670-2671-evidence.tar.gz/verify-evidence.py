#!/usr/bin/env python3
"""Self-contained integrity and recorded-scope checks; no Cargo/product execution."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');rr=load('personal-read-receipt.json');assert rr['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<rr['recorded_utc'] and len(rr['reads'])==len(r['entries'])==4
for x in rr['reads']:
 e=next(e for e in r['entries'] if e['original_index']==x['original_index'] and e['snapshot']==x['snapshot']);b=(p/x['archive']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['actual_display_chunks']==e['planned_chunks'] and not x['unread_complement']
 cov={i for a,z in x['actual_display_chunks'] for i in range(a,z+1)};assert cov==set(range(1,e['actual_EOF']+1))
assert r['entries'][0]['sha256']==r['entries'][1]['sha256'] and r['entries'][2]['sha256']!=r['entries'][3]['sha256']
checks.append('Four independently registered and displayed source objects; correct equal/different current comparisons')
sr=load('support-registration.json');rc=load('support-read-receipt.json');assert rc['registration_sha256']==sha((p/'support-registration.json').read_bytes()) and sr['at']<rc['at'] and len(rc['reads'])==2
for x in rc['reads']:
 e=next(e for e in sr['rows'] if e['file']==x['source_file']);data=(p/e['file']).read_bytes();assert (sha(data),blob(data),len(data.splitlines()))==(e['sha256'],e['blob'],e['eof']) and e['prospective_ranges']==x['actual_ranges']
 a={i for f,t in x['actual_ranges'] for i in range(f,t+1)};u={i for f,t in x['unread_for_this_registration'] for i in range(f,t+1)};assert not a & u and a|u==set(range(1,e['eof']+1))
checks.append('Two prospectively registered current support windows and unread complements')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);selected=load('registry-selection-reconstructed.json');assert selected['original_registry_sha256_uncompressed']==sha(raw)
for x in selected['rows']:assert reg['files'][x['original_index']]==x['entry']
snap=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert selected['physical_p16_snapshot']==snap and snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for i in [2670,2671]:assert not any(x[3:]==reg['files'][i]['source_id'].split(':',1)[1] for x in snap['status_porcelain'])
assert sha((p/'reference/p16-tracked.patch').read_bytes())==snap['patch_sha256'];assert sha((p/'reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007'
raw=gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes());assert sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';transport=json.loads(raw);entries={x['path']:x for x in transport['entries']}
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==17 and sum(x['kind']=='historical-774' for x in hi['records'])==5
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original registry, physical-P16 base/status and later tracked patch, 17 exact 059 and five 774 records')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==15
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Fifteen commit/tree/blob membership chains preserve a120/current source and distinct f82 transport')
l11=load('history-059/READ-L11-437.json')
for i,expected in [(2670,[[1,31]]),(2671,[[178,182]])]:
 x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected
prop=load('history-059/PROPOSAL-L12-925.json');adopt=load('history-059/READ-L12-925.json');assert adopt['root_personal_rereads']==[] and len(prop['partial_read_receipts'])==2
for j,(i,expected) in enumerate([(2670,[[1,31]]),(2671,[[178,182]])],1):
 part=load('history-059/PARTIAL-PAR-L12-925-%03d.json'%j);x=next(x for x in part['rows'] if x['original_index']==i);regx=load('history-059/REGISTRATION-PAR-L12-%s.json'%('734' if i==2670 else '735'));assert x['fresh_personal_body_reads']==expected and x['registered_at']==regx['registered_at'] and x['registered_at']<part['at']<prop['at']<adopt['at'] and '/root/lens12_frontier' in x['attribution']
old=gzip.decompress((p/'history-774/source-range-registration.jsonl.gz').read_bytes()).splitlines();qual=gzip.decompress((p/'history-774/source-qualifications-final-082.jsonl.gz').read_bytes()).splitlines()
for ix in [14,15]:assert json.loads(old[ix-1])['id']==f'NATIVE-ADMISSION03-REG-{ix:03d}' and json.loads(qual[ix-1])['id']==f'NATIVE-ADMISSION03-QUAL-{ix:03d}'
w=json.loads(gzip.decompress((p/'history-774/p16-basispoints-admission-witness-042.json.gz').read_bytes()));g=json.loads(gzip.decompress((p/'history-774/contract-groups-043.json.gz').read_bytes()));assert 'mappingrequestedbeforeadditionalroutecredit' in w['sats_status'] and 'p16-basispoints-all-adapter-routes' in g['groups']
checks.append('Historic 774 original material scopes, witness-to-group qualification, 059 original 2670/2671 windows and authorship')
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';assert json.loads(raw)['entries'][131]==q['entries']['131'] and q['entries']['131']['contract_id']=='ADLER-L11-BASIS-POINTS-WIRE-ADMISSION'
for x in load('prior-assessments.json')['records']:
 b=(p/x['preserved_bytes']).read_bytes();assert (sha(b),len(b))==(x['sha256'],x['bytes'])
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
rep=load('report.json');assert {x['number'] for x in rep['lenses']}==set(range(1,14)) and rep['support_reads']==rc['reads']
checks.append('Reconstructed 059 queue selection, retained previous assessments, rules and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Static evidence integrity and recorded scope only. No cargo feature resolution, macro execution, product execution, build, lint, test, runtime probe, repair or checkpoint 3821 promotion.'},indent=2))
