# P16 world-schema and workspace manifest evidence

This source-only packet covers original registry roles 2670 and 2671 and their
current counterparts at `95e63628f9d70b8dd6e6fede64334696c6995009`. The
historical P16 snapshot is dirty and based on
`a120390947c89b703dc74c4255a13c035d054c50`. Each assigned historical file
individually equals its base object; this does not make the snapshot clean.
F82 is evidence transport, not a project revision.

`registration.json` was written before the four separate personal source
text displays recorded in `personal-read-receipt.json`. The original 774/059
material range for role 2671 was only lines 178–182; this review's independently
registered full old-manifest display adds context but cannot enlarge that
historical reader's scope. `support-registration.json` and
`support-read-receipt.json` record narrower current type and module support,
including every unread complement. `report.json` describes the two revisions,
conditional relationships, open questions, thirteen bounded perspectives and
reviewer qualifications. `root-manifest.diff` is a source text comparison.

`history-059/` contains exact original registrations, receipts, proposals,
qualifications and partials checked against the original transport manifest.
`history-774/` contains losslessly compressed original native and camera
records, including the witness that left SATS mapping pending and its later
source comparison. `reference/` preserves the original registry and transport
manifest, recovered 059 queue, later P16 recovery record and tracked patch, and
small prior current assessments. Reconstructed registry and queue selections
are explicitly labeled. Git commit/tree objects prove individual source and
transport membership without attributing earlier source reads to this review.

Run `python3 verify-evidence.py` for self-contained evidence integrity and
scope accounting. Run `python3 verify-manifest.py` for packet member hashes.
Neither check invokes Cargo, computes a resolved feature graph, expands macros,
executes product, builds, runs tests or probes, or validates product behavior.
No repair, source or publication edit, checkpoint 3821 promotion or whole-lens
completion is claimed.
