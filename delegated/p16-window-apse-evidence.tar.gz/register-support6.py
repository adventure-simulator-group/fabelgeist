from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';items=[('crates/adventuresim-tactical-client/src/targeting.rs',[(1,100)]),('crates/adventuresim-tactical-client/src/equipment.rs',[(55,75)]),('crates/adventuresim-tactical-server/src/equipment.rs',[(40,78)])];entries=[]
for path,ranges in items:
 raw=subprocess.check_output(['git','show',rev+':'+path]);eof=len(raw.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dst='support/95e/'+path;p=b/dst;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);entries.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':subprocess.check_output(['git','rev-parse',rev+':'+path],text=True).strip(),'bytes':len(raw),'actual_eof':eof,'planned_ranges':ranges,'source_archive':dst,'purpose':'bounded client range and authoritative ownership admission'})
x=(json.dumps({'schema':'726-p16-window-apse-support-registration-v6','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries},indent=2)+'\n').encode();(b/'support-registration-06.json').write_bytes(x);print(hashlib.sha256(x).hexdigest());print('\n'.join(f"{e['path']} EOF {e['actual_eof']} {e['planned_ranges']}" for e in entries))
