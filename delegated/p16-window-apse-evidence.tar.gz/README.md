# Bounded P16 server windows and historical church apse evidence

This packet contains /root/rig_identity's bounded audit of original roles 2530
and 2533, separately registered historical and pinned 95e source bodies, current
support reads, thirteen perspectives, and conditional findings. Start with
`REPORT.json`, `registration.json`, and `personal-read-receipt.json`.

Role 2530 is a recovered physical-p16 dirty object transported through f82;
its recorded base is a120 and the original dirty patch is unrecovered. Role
2533 is the exact clean 6533 Git file from the historical pr-working registry;
that registry's whole working snapshot records four unrelated modified paths.
Both individual files match 95e. None of these file-level equalities establishes
whole-snapshot equivalence or restores either working patch.

`historical-059/` and `historical-774/` contain exact historical records. The
registry and queue selections are explicitly reconstructed, not original
records. `published-references.json` hash-links the complete central baseline
registry, transport manifest, queue, ledger, and prior assessments. The
`prior-delegate/` directory contains selected exact reports, manifests and
personal receipts, without copying the complete older packets. Historical
records retain their revision and attribution and are not checkpoint 3821 work.

`git-proofs.json` and `git-objects/` provide raw commit/tree inclusion chains.
`evidence-verification.json` checks evidence hashes, published links, source
scopes and citations only. `MANIFEST.json` inventories the packet. Run
`python3 verify-manifest.py` on the frozen packet. To repeat structural checks,
copy the packet and run `python3 verify-evidence.py /path/to/publication` in
the copy; the command rewrites that copy's verification timestamp. No repair,
implementation, product execution, build, test, fixture, UI, simulation,
runtime probe or product validation was performed.
