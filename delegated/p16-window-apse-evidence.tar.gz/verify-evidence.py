from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,sys
b=Path(__file__).resolve().parent;pub=Path(sys.argv[1]) if len(sys.argv)>1 else Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();refs=json.loads((b/'published-references.json').read_bytes())
for e in refs['entries']:
 raw=(pub/e['repository_relative_path']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'],e['repository_relative_path']
reg=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));assigned=json.loads((b/'registration.json').read_bytes())['entries'];receipt=json.loads((b/'personal-read-receipt.json').read_bytes());proof=json.loads((b/'git-proofs.json').read_bytes());report=json.loads((b/'REPORT.json').read_bytes());man=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in man['entries']}
for e in assigned:
 raw=(b/e['source_archive']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and len(raw.splitlines())==e['actual_eof'] and oid('blob',raw)==e['git_blob']
 if e['original_material_ranges'] is not None:
  row=reg['files'][e['original_role']];assert e['sha256']==row['sha256'] and e['bytes']==row['bytes'] and e['original_material_ranges']==row['material_ranges']
for role in (2530,2533):
 rows=[e for e in assigned if e['original_role']==role];assert len(rows)==2 and rows[0]['sha256']==rows[1]['sha256'] and rows[0]['git_blob']==rows[1]['git_blob']
s=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert s['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(s['status_porcelain'])==159
selection=json.loads((b/'registry-selection-reconstructed.json').read_bytes());assert s in selection['snapshots'] and next(x for x in reg['snapshots'] if x['id']=='pr-working') in selection['snapshots']
for row in selection['rows']:
 i=row['original_index'];assert {k:v for k,v in row.items() if k!='original_index'}==reg['files'][i]
q=json.loads((pub/'baseline-059/queue.json').read_bytes());qi={e.get('contract_id'):e for e in q['entries']};qs=json.loads((b/'historical-queue-selection-reconstructed.json').read_bytes());assert not qs['requested_missing']
for e in qs['entries']:assert e==qi[e['contract_id']]
old=json.loads((b/'original-attribution.json').read_bytes());assert not old['missing_originals']
for e in old['original_059_records']:
 raw=(b/e['preserved_bytes']).read_bytes();orig=idx[e['original_path']];assert sha(raw)==e['sha256']==orig['sha256'] and len(raw)==orig['bytes'] and oid('blob',raw)==orig['git_blob']==e['git_blob']
for e in old['older_774_receipts']:
 raw=(b/e['preserved_bytes']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and oid('blob',raw)==e['git_blob']
for p in old['prior_delegate_selected_records']:
 rec={}
 for e in p['records']:
  raw=(b/e['preserved_bytes']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'];rec[e['name']]=raw
 prior=json.loads(rec.get('BUNDLE-MANIFEST.json') or rec.get('MANIFEST.json'));mi={e['path']:e for e in prior['files']}
 for n in rec:
  if n not in ('BUNDLE-MANIFEST.json','MANIFEST.json'):
   assert n in mi and sha(rec[n])==mi[n]['sha256'] and len(rec[n])==mi[n]['bytes']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
objects={}
for key,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,e in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==e['root_tree']
for p in proof['paths']:
 curr=proof['commits'][p['revision']]['root_tree'];parts=p['path'].split('/');assert len(parts)==len(p['path_chain'])
 for name,step in zip(parts,p['path_chain']):
  assert step['tree']==curr and step['name']==name;mode,child=entries(objects[curr])[name];assert mode==step['mode'] and child==step['object'];curr=child
 raw=(b/p['preserved_bytes']).read_bytes();assert oid('blob',raw)==curr==p['git_blob'] and sha(raw)==p['sha256'] and len(raw)==p['bytes']
assert len(receipt['assigned_personal_reads'])==4 and len(receipt['support_personal_reads'])==28 and len(report['lenses'])==13
for e in receipt['assigned_personal_reads']+receipt['support_personal_reads']:
 seen=set();absent=set()
 for a,z in e['contiguously_displayed_ranges']:
  assert 1<=a<=z<=e['actual_eof'];seen.update(range(a,z+1))
 for a,z in e['not_contiguously_displayed_ranges']:
  assert 1<=a<=z<=e['actual_eof'];absent.update(range(a,z+1))
 assert seen.isdisjoint(absent) and len(seen)+len(absent)==e['actual_eof']
for e in receipt['assigned_personal_reads']:assert e['contiguously_displayed_ranges']==([[1,294]] if e['role']==2530 else [[1,75]])
scopes={}
for e in receipt['support_personal_reads']:
 scopes.setdefault(e['path'],set()).update(i for a,z in e['contiguously_displayed_ranges'] for i in range(a,z+1))
for e in receipt['assigned_personal_reads']:
 if e['source_identity']=='95e63628f9d70b8dd6e6fede64334696c6995009':scopes.setdefault(e['path'],set()).update(range(1,e['actual_eof']+1))
def visit(x):
 if isinstance(x,dict):
  if x.get('revision')=='95e63628f9d70b8dd6e6fede64334696c6995009' and 'ranges' in x:
   assert x['path'] in scopes
   for a,z in x['ranges']:assert set(range(a,z+1))<=scopes[x['path']],(x['path'],a,z)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Hash-linked published registry, transport manifest, queue/ledger and earlier gate assessments match','Mixed P16/6533 registry assigned hashes, source EOF and exact current matches verified, P16 dirty patch remains unrecovered','Raw commit/tree chains prove f82 archive and individual files at 95e, a120 and 6533; PR-working dirty overall and 059/774 attribution preserved','Selected earlier delegate reports and personal receipts match their original manifests; four assigned displays, twenty-eight bounded support scopes, citations and thirteen perspectives checked'],'scope':'Evidence hashes, Git chain, source scopes and citations only. No product validation, testing or runtime probes.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw);print('PASS',sha(raw),'proofs',len(proof['paths']),'059',len(old['original_059_records']),'published links',len(refs['entries']))
