#!/usr/bin/env python3
"""Evidence-only replay; does not import or execute product source."""
import argparse,hashlib,io,json,os,stat,subprocess,sys,tarfile,zlib
from pathlib import Path
if not __debug__:raise SystemExit('optimization prohibited')
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_bytes())
def check(root,name,expected=None):
 b=(root/name).read_bytes();assert expected is None or sha(b)==expected;m=json.loads(b);fs={};ds={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_dir():ds[n]=format(stat.S_IMODE(f.stat().st_mode),'04o')
  elif f.is_file() and n!=name:
   b=f.read_bytes();fs[n]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(f.stat().st_mode),'04o')}
  else:assert n==name
 assert fs==m['files'];assert 'directories' not in m or ds==m['directories']
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();key=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if key==name:return mode,oid
 raise AssertionError('missing tree member')
def history(r):
 info=j(r/'HISTORICAL-GIT-PROOF.json');objs={}
 for oid,m in info['objects'].items():
  b=(r/'historical-git-objects'/(oid+'.zlib')).read_bytes();assert sha(b)==m['stored_sha256'];raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid;head,body=raw.split(b'\0',1);kind,n=head.decode().split(' ');assert kind==m['type'] and len(body)==int(n)==m['size'] and sha(body)==m['sha256'];objs[oid]=(kind,body)
 out={}
 for p in info['proofs']:
  c=objs[p['revision']];assert c[0]=='commit';first=c[1].split(b'\n',1)[0];assert first.startswith(b'tree ');tree=first[5:].decode();trees=[];parts=p['path'].split('/')
  for i,n in enumerate(parts):
   trees.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],n)
   if i<len(parts)-1:assert int(mode,8)==int('40000',8);tree=oid
   else:assert int(mode,8) in (int('100644',8),int('100755',8)) and oid==p['blob'] and objs[oid][0]=='blob';body=objs[oid][1]
  assert [x['tree'] for x in p['chain']]==trees and p['chain'][-1]['child']==oid and sha(body)==p['sha256'] and len(body)==p['bytes'];out[(p['revision'],p['path'])]=body
 assert len(out)==4;return out
def selections(raw,ids):
 t=raw.decode();needle='"entries": [';pos=t.index(needle)+len(needle);dec=json.JSONDecoder();out={}
 for i in range(max(ids)+1):
  while t[pos] in ' \t\r\n,':pos+=1
  start=pos;value,pos=dec.raw_decode(t,pos)
  if i in ids:out[i]=(value,t[start:pos].encode())
 return out
def view(raw,p,lo,hi):
 lines=raw.decode().splitlines();assert 1<=lo<=hi<=len(lines);s=''.join(f'{i:5} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert s==p.read_bytes()
def anchors(a,ref):
 raw=(a/'ANCHOR-MANIFEST.json').read_bytes();assert sha(raw)=='e3262991171c1b8279952062621c01b95803d573fbb4a20cd05cb8b2cc794a2d' and raw==ref.read_bytes();m=json.loads(raw);want={x['file'] for x in m['anchors']}|set(m['support'])|{'ANCHOR-MANIFEST.json'};assert {f.name for f in a.iterdir()}==want and stat.S_IMODE(a.stat().st_mode)==0o700
 for x in m['anchors']:
  f=a/x['file'];assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['source_mode_octal']==x['preserved_mode_octal']
 for n,x in m['support'].items():
  f=a/n;b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['mode_octal']
def strict_delegate(root,expected,count):
 raw=(root/'MANIFEST.json').read_bytes();assert sha(raw)==expected;m=json.loads(raw);actual={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_file() and n!='MANIFEST.json':
   b=f.read_bytes();actual[n]={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(f.stat().st_mode)}
  else:assert f.is_dir() or n=='MANIFEST.json'
 assert actual==m['files'] and len(actual)==count

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--anchors',type=Path);a=ap.parse_args();pub=Path(__file__).resolve().parent;check(pub,'MANIFEST.json');print('public manifest: PASS')
 if not a.private:assert not a.anchors;print('restricted replay not requested');return
 r=a.private.resolve();check(r,'MANIFEST-PRIVATE.json','c1a6e0042a3f37ba5ef6e287604cd8ca683b6615a74b33af00b9348ae1c033b1');p=r/'delegate-public';dp=r/'delegate-private'
 strict_delegate(p,'e2da98288113303ada94fcf3d9d03457a92abd021cbb8e30fc48727e7323ae25',138)
 strict_delegate(dp,'d10d86ab4e8988a917dc00d8eaf149c1ca24872ae61be53ef2b2a1910df01292',361)
 raw=(r/'q3356-source.tar.gz').read_bytes();assert sha(raw)=='ca0aff00052514ca2c675bc7f7e9a1cf07665df1ea778379c2ad79e3effe62f8';seen=set()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  for x in t:
   path=Path(x.name);assert not path.is_absolute() and '..' not in path.parts and x.isfile() and x.name not in seen;seen.add(x.name);f=p/path;assert f.is_file() and not f.is_symlink() and t.extractfile(x).read()==f.read_bytes() and stat.S_IMODE(f.stat().st_mode)==x.mode
 assert seen=={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file()}
 cmd=[sys.executable,'-B',str(p/'verify-public.py'),'--private',str(dp)]
 if a.anchors:anchors(a.anchors,r/'ANCHOR-MANIFEST.json');cmd+=['--anchors',str(a.anchors)]
 proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});assert proc.returncode==0,proc.stderr.decode(errors='replace')
 cap=j(r/'SOURCE-CAPTURE.json');reg=j(r/'REGISTRATION-002.json');assert reg['lens']==5 and reg['queue']==3356 and reg['product_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009';mapping={'crates/strategic-web/src/routes/dialogue.rs':'source/95e.rs'}
 for name in ('ADJ-013','CLIENT-024','CATALOG-019'):
  for x in j(p/(name+'-CAPTURE-RESULT.json')):mapping[x['path']]=x['file']
 count=0;src={}
 for item in cap['items']:
  b=(r/'sources'/f"{item['id']}.source").read_bytes();src[item['id']]=b;assert b==(p/mapping[item['path']]).read_bytes() and sha(b)==item['sha256'];assert [[x['lo'],x['hi']] for x in item['views']]==reg['product_windows'][item['path']]
  for x in item['views']:
   f=r/x['file'];assert sha(f.read_bytes())==x['sha256'];view(b,f,x['lo'],x['hi']);count+=1
 assert count==19
 s=j(r/'SUPPLEMENT-004.json');assert j(r/'REGISTRATION-004.json')['range']==[545,625];assert sha((r/s['view']).read_bytes())==s['sha256'];view(src[5],r/s['view'],545,625);count+=1
 for item,x in zip(j(r/'REGISTRATION-006.json')['windows'],j(r/'SUPPLEMENT-006.json')):
  lo,hi=item['range'];assert sha((r/x['file']).read_bytes())==x['sha256'];view(src[item['source_id']],r/x['file'],lo,hi);count+=1
 assert count==22
 import re
 assert [i for i,line in enumerate(src[2].decode().splitlines(),1) if re.search(r'\bcurrentSocial\s*=',line)]==j(r/'NAV-003.json')['line_numbers']==[251,394,404,419,743]
 h=history(r);old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';new='dac7d0055716053f245139971eb67ddfd87fa462';q='baseline-059/queue.json';assert sha(h[(old,q)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(h[(new,q)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173'
 for rev,label in ((old,'original'),(new,'reconstructed')):
  value,selected=selections(h[(rev,q)],[3356])[3356];assert selected==(r/f'history/q3356-{label}.json').read_bytes()==(dp/f'PRIVATE-Q3356-{label}.json').read_bytes();assert value['lens']==5 and value['exact_source_identities_and_assessed_ranges'][0]['required_ranges']==[[1,1897]]
 assert (r/'history/q3356-original.json').read_bytes()==(r/'history/q3356-reconstructed.json').read_bytes()
 rec=j(dp/'PRIVATE-ede12-RECONCILIATION-059.json')['entries'][3356];assert rec['historical_lens']==5 and rec['current_reconciliation']=='unassessed'
 summary=j(r/'history/INDEPENDENT-SUMMARY.json');ledger=j(dp/'PRIVATE-ede12-BASELINE-95E-20261110.json')['newly_assessed_ledger']['entries'];assert all(ledger[i]['id']==summary['ledger'][str(i)]['id'] for i in [758,759,760,761,762,773])
 group=dp/'historical/evidence__audit05__contract-groups-242.json';assert sha(group.read_bytes())=='997b99c50766b5d37faf27538f7a6587da8b2c9eeab6b31a1dfdc053a0c3fb6f';row=j(dp/'historical/evidence__audit01-delta__predecessor__source-catalog.json')['rows'][2361];assert row['scope_index']==2361 and row['status']=='exact source recovered; no audit coverage inferred' and row['expected_sha256']==sha(src[0])
 assert j(dp/'SOURCE-005-READ.json')['reader']=='/root/wrapped_scope' and 3356 in j(dp/'SOURCE-005-READ.json')['assessments']
 challenge=r/'manifest-challenge';cm=j(challenge/'MANIFEST.json');present=set()
 for f in challenge.rglob('*'):
  assert not f.is_symlink()
  if f.is_file() and f.relative_to(challenge).as_posix()!='MANIFEST.json':present.add(f.relative_to(challenge).as_posix())
 result=j(r/'replay/challenge-RESULT.json');assert result['inherited_verifier_exit']==0 and present-set(cm['files'])==set(result['strict_extra_relative_paths'])=={'source/MANIFEST.json'} and not set(cm['files'])-present
 assert all(x['exit']==0 for x in j(r/'replay/FULL-RESULT.json'))
 print('strict inherited inventories, archive and full delegate replay: PASS')
 print('22 prospectively registered bounded source windows and historic Git queue proofs: PASS')
 print('controlled nested-manifest limitation reproduced from preserved receipt: PASS')
 print('q2812 anchor collection checked now: '+str(bool(a.anchors)))
 print('Source evidence only; no runtime, global closure, unique count or independent custody.')
if __name__=='__main__':main()
