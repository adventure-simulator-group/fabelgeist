# Independent q3356 aggregate-state peer review

This is a bounded source-only peer review under historical Lens 5, at product
revision `95e63628f9d70b8dd6e6fede64334696c6995009` and tree
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`. The delegate was a different
reviewer. This peer independently registered and displayed 22 source windows;
this is not a fresh read of the full 1–1897 route, a queue or lens closure, a
unique finding count, product validation, or evidence of runtime behavior.

The social revision token encodes selected state (`dialogue.rs:210–250`,
`1077–1085`). About-topic text also depends on familiar address
(`dialogue.rs:1006–1020`, `1028–1076`), which is derived from relationship and
social inputs (`social.rs:335–368`) but is absent from the encoded token. If
all encoded fields remain equal while this flag differs, the token can match
while text differs. Supported transitions, token policy and external clients
remain open. The selected client update paths rerender topic categories when a
current view exists, and character selection clears panels
(`dialogue-client.js:331–340`, `394–419`, `735–748`). Static assignment
navigation found a declaration, three selected non-null assignments and a reset;
it is not an exhaustive alias or runtime proof. No supported stale-button
sequence or observed failure is established.

Events and prompts independently decode neighboring fragment/choice and
source-reference arrays and associate them by position
(`dialogue.rs:1384–1417`, `1461–1479`); malformed, missing or mismatched inputs
are representable, while supported corruption and intended failure policy are
unresolved. Topic construction uses checked `ResolvedTurn`
(`dialogue_prompts.rs:253–280`; `adventuresim-dialogue/src/lib.rs:290–333`).
Greeting and choice-result construction allocate sources separately
(`dialogue_sessions.rs:220–259`; `dialogue_prompts.rs:529–594`). Testimony can
expand (`lib.rs:212–255`), but the inspected semantic and build-source checks
reject that specific expansion in those selected positions (`lib.rs:482–582`,
`663–686`; `build.rs:112–195`, `253–275`, `385–395`). These source checks do
not prove activation at runtime or universal alignment. Separate awaited social,
status, commitment and time reads (`dialogue.rs:939–969`, `1103–1119`) leave
the snapshot-coherence policy open; no inconsistency is observed.

The exact original 059 q3356 entry identifies a Lens 5 own-lens obligation for
`dialogue.rs:1–1897` at 6533. The selected bytes agree with the reconstructed
059 entry; the complete queue streams differ. At the independently identified
ede12 snapshot q3356 was unassessed, without a claim about subsequent state.
The separately recovered Adler group 242 records a prior Lens 5 pr-working
read and describes the revision as retaining its declared inputs; it does not
assert coverage of every display field. Normalized source catalog row 2361
binds a 6533 source identity while explicitly granting no audit coverage from
recovery. Earlier q2721 dialogue-bindings work was authored by this peer, is a
separate scope and is not independent authorship or q3356 credit. Per-file
6533/e275/95e equality does not establish historical checkout cleanliness or
whole-revision equality. Ledger rows 758–762 address distinct JSON cause
boundaries and row 773 addresses referral source shape; these are relationships,
not automatic aliases or a count.

## Evidence and recovery limits

The inherited public and restricted manifest verifiers exclude every file whose
basename is `MANIFEST.json` and do not explicitly reject symlinks. The original
copied public and restricted inventories contained respectively 138 and 361
bound files, no nested manifests and no symlinks. An evidence-only challenge in
a fresh private copy added a benign unlisted nested manifest: the inherited
public verifier passed while strict relative-path inventory detected the extra.
This is a verifier limitation, not a product test or an assertion that the
original packets contained an extra. The additive peer verifier checks both
original inventories strictly and retains the unchanged inherited replay.

The delegate preserved six initially unresolved Git navigation lookups and
later corrected them, an object-probe and broken pipe, a failed metadata
uniqueness assertion corrected by exact position, and a truncated client view
followed by smaller registered complete displays. The peer displayed the first
1800 bytes of the public report during identity navigation before confirming
authorship; no fresh product source was displayed before that confirmation.
Two later metadata-inspection command errors were tool-visible but not separately
captured verbatim; they conferred no source credit and did not alter evidence.

The 440 reconstructed records, SOURCE004 and 73 nontext/no-positive-EOF
qualifications, and missing checkpoint 3821 remain unchanged. Normalized 774 is
not a substitute for missing pre-export originals. Recorded and fresh bounded
privacy scans cannot prove absence of unknown private values. The full replay
uses restricted same-machine evidence and an optional separately held q2812
anchor collection; these are recovery dependencies, not independent public
custody. No product code, builds, tests, macros or runtime probes were executed.
