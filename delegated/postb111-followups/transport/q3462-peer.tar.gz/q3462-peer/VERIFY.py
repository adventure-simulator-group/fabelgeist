#!/usr/bin/env python3
"""Read-only evidence verification. No product/native code is executed."""
import argparse,hashlib,io,json,os,pathlib,stat,subprocess,sys,tarfile,tomllib
P=pathlib.Path(__file__).resolve().parent
if sys.flags.optimize:raise RuntimeError('unoptimized interpreter required')
def req(x,s):
 if not x:raise ValueError(s)
def j(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def gitid(b):return hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()
def inventory(root,excluded):
 rows={}
 for f in sorted(root.rglob('*')):
  rel=f.relative_to(root).as_posix();req(not f.is_symlink(),'symlink')
  if f.is_file() and rel not in excluded:
   b=f.read_bytes();rows[rel]={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(f.stat().st_mode)}
  elif not f.is_file():req(f.is_dir(),'special file')
 return rows
m=j(P/'MANIFEST.json');req(inventory(P,{'MANIFEST.json'})==m['files'],'public manifest')
source=j(P/'SOURCE-CAPTURE.json')['rows']+j(P/'SOURCE-CAPTURE-2.json')['rows']+[j(P/'CALENDAR-CAPTURE.json')];byid={x['id']:x for x in source};req(len(source)==len(byid)==11,'source records')
for x in source:
 b=(P/x['object']).read_bytes();req(len(b)==x['bytes'] and sha(b)==x['sha256'] and gitid(b)==x['git_blob'] and len(b.decode().splitlines())==x['EOF'],'source bytes')
req(byid[0]['sha256']==byid[5]['sha256']==byid[6]['sha256'],'historical per-file identity')
n=j(P/'NATIVE-CAPTURE.json');member=j(P/'NATIVE-MEMBER-CAPTURE.json');archive=(P/'native/rand-0.9.5.crate').read_bytes();req(len(archive)==n['archive_bytes'] and sha(archive)==n['archive_sha256']=='b9ef1d0d795eb7d84685bca4f72f3649f064e6641543d3a8c415898726a57b41','native archive identity')
for x in n['git_files']:
 b=(P/x['file']).read_bytes();req(len(b)==x['bytes'] and sha(b)==x['sha256'] and gitid(b)==x['git_blob'] and len(b.decode().splitlines())==x['EOF'],'cargo source')
lock=tomllib.loads((P/'native/git-0').read_text());pkg=[x for x in lock['package'] if x['name']=='rand' and x['version']=='0.9.5'];req(len(pkg)==1 and pkg[0]['checksum']==n['archive_sha256'],'lock checksum')
manifest=tomllib.loads((P/'native/git-1').read_text());r=manifest['dependencies']['rand'];req(r['version']=='=0.9.5' and 'alloc' in r['features'],'manifest declaration')
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
 b=t.extractfile(member['member']).read();req(b==(P/'native/weighted_index.rs').read_bytes() and sha(b)==member['sha256'] and len(b)==member['bytes'] and len(b.decode().splitlines())==member['EOF'],'native member')
receipt=j(P/'READ-RECEIPT.json');req(len(receipt['views'])==18,'read count')
for v in receipt['views']:
 reg=j(P/v['registration']);req(any(all(v.get(k)==value for k,value in x.items()) for x in reg['views']),'prospective view')
 if 'source_id' in v:x=byid[v['source_id']];b=(P/x['object']).read_bytes()
 else:b=(P/v['source']).read_bytes()
 lines=b.decode().splitlines();lo,hi=v['lines'];req(1<=lo<=hi<=len(lines) and sha(b)==v['sha256'],'view bounds')
 expected=''.join(f'{i:4d} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();actual=(P/v['view_file']).read_bytes();req(actual==expected and sha(actual)==v['view_sha256'],'view bytes')
tr=j(P/'TRANSPORT-CAPTURE-v2.json');trans=j(P/'prior/TRANSPORT-MANIFEST.json');row=next(x for x in trans['bundles'] if x['file']=='role0058.tar.gz');raw=(P/'prior/role0058.tar.gz').read_bytes();req(sha(raw)==tr['archive_sha256']==row['archive_sha256'] and len(raw)==row['archive_bytes'],'prior archive')
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
 items=t.getmembers();want={x['path']:x for x in row['members']};req(len(items)==len(want)==143 and {x.name for x in items}==set(want),'prior member inventory')
 for x in items:
  r=want[x.name];req(x.isfile() and oct(x.mode)==r['mode'],'prior file mode');b=t.extractfile(x).read();req(len(b)==r['bytes'] and sha(b)==r['sha256'],'prior member')
 req(sha(t.extractfile(row['manifest_member']).read())==tr['source_manifest_sha256']==row['source_manifest_sha256'],'prior manifest')
 req(t.extractfile('REVIEW-L5.md').read()==(P/'prior/REVIEW-L5.md').read_bytes(),'prior review')
a=argparse.ArgumentParser();a.add_argument('--restricted',type=pathlib.Path);a.add_argument('--repo',type=pathlib.Path);args=a.parse_args();hist=j(P/'HISTORY-SUMMARY.json')
if args.restricted:
 q=args.restricted;cross=j(P/'RECONSTRUCTION.json')
 for x in cross['rows']:
  raw=(q/x['file']).read_bytes();out=(P/x['file']).read_bytes();req(sha(raw)==x['original_whole_file_sha256'] and sha(out)==x['public_whole_file_sha256'],'redaction identity');a1=json.loads(raw);a2=json.loads(out);a1['reviewer']='independent peer reviewer';req(a1==a2 and x['reconstructed_fields']==['/reviewer'],'redaction fields')
 for file,key in [('prior-0','original_queue_sha256'),('prior-1','reconstructed_queue_sha256'),('prior-2','original_ledger_sha256'),('prior-3','reconstructed_ledger_sha256')]:req(sha((q/'history'/file).read_bytes())==hist[key],'history whole stream')
 old=j(q/'history/prior-0');new=j(q/'history/prior-1')
 for row in hist['queue_selected']:
  i=row['index'];req(old['entries'][i]==new['entries'][i] and old['entries'][i]['contract_id']==row['contract_id'] and old['entries'][i]['lens']==row['lens'],'selected history')
 req(sha((q/'history/PL13-210-RECEIPT.json').read_bytes())==hist['historical_receipt_sha256'],'original receipt')
 prev=q/'prior-full';pm=j(prev/'MANIFEST.json');req(sha((prev/'MANIFEST.json').read_bytes())==hist['prior_private_manifest_sha256'],'prior private identity');req(inventory(prev,{'MANIFEST.json'})==pm['files'],'prior private file inventory');dirs={d.relative_to(prev).as_posix():stat.S_IMODE(d.stat().st_mode) for d in prev.rglob('*') if d.is_dir()};req(dirs==pm['directories'],'prior private directory inventory')
if args.repo:
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 for x in source:
  z=subprocess.run(['git','-C',str(args.repo),'rev-parse',x['revision']+':'+x['path']],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,check=True).stdout.decode().strip();req(z==x['git_blob'],'git source object')
 tree=subprocess.run(['git','-C',str(args.repo),'rev-parse','95e63628f9d70b8dd6e6fede64334696c6995009^{tree}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,check=True).stdout.decode().strip();req(tree=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','product tree')
 b=subprocess.run(['git','-C',str(args.repo),'show','5f6a6e829dca0f8b2a5efff9b6f17fab5db71ae0:delegated/postf2ec-followups/postfreeze-transport/role0058.tar.gz'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,check=True).stdout;req(b==(P/'prior/role0058.tar.gz').read_bytes(),'committed prior archive')
print(json.dumps({'result':'pass','source_objects':len(source),'registered_views':len(receipt['views']),'prior_public_members':tr['members_verified'],'restricted_history_checked':bool(args.restricted),'local_git_checked':bool(args.repo),'qualification':'Source-evidence identities and displayed ranges only; not product validation or semantic closure.'},sort_keys=True))
