#!/usr/bin/env python3
"""Read-only evidence integrity verifier; does not run or validate product."""
import argparse,hashlib,json,os,pathlib,subprocess,tarfile
if not __debug__:
 raise SystemExit('optimized Python is unsupported')
ROOT=pathlib.Path(__file__).resolve().parent

def readjson(name): return json.loads((ROOT/name).read_bytes())
def sh(b): return hashlib.sha256(b).hexdigest()
def obj(kind,b): return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def fail(cond,msg):
 if not cond: raise RuntimeError(msg)
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def tree_entries(b):
 result={};i=0
 while i<len(b):
  sp=b.index(b' ',i);nul=b.index(b'\0',sp);mode=b[i:sp].decode();name=b[sp+1:nul].decode();oid=b[nul+1:nul+21].hex();fail(len(oid)==40,'truncated tree');result[name]=(mode,oid);i=nul+21
 fail(i==len(b),'invalid tree length');return result
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=pathlib.Path);args=ap.parse_args()
m=readjson('MANIFEST.json');actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'MANIFEST.json'}
fail(actual==set(m['files']),'manifest inventory mismatch')
for name,info in m['files'].items():
 p=ROOT/name;fail(not p.is_symlink(),'symlink');b=p.read_bytes();fail(len(b)==info['bytes'] and sh(b)==info['sha256'] and (p.stat().st_mode&0o777)==info['mode'],'manifest '+name)
cap=readjson('CAPTURE-RESULT.json');extra=readjson('SUPPORT-CAPTURE.json');rows=cap['source_rows']+extra['source_rows'];fail(cap['tree_95e']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','root tree')
for row in rows:
 b=(ROOT/row['file']).read_bytes();fail(sh(b)==row['sha256'] and obj('blob',b)==row['blob'] and len(b.splitlines())==row['EOF'],'source identity '+row['path'])
primary=[r for r in rows if r['path']=='crates/strategic-web/src/routes/dialogue.rs'];fail(len(primary)==3 and len({r['blob'] for r in primary})==1 and len({r['sha256'] for r in primary})==1,'per-file equality')
archive=(ROOT/'prior/dialogue-route.tar.gz').read_bytes();fail(sh(archive)=='ca0aff00052514ca2c675bc7f7e9a1cf07665df1ea778379c2ad79e3effe62f8','predecessor transport')
with tarfile.open(ROOT/'prior/dialogue-route.tar.gz','r:gz') as tf:
 members=tf.getmembers();fail(all(x.isfile() and not x.issym() and not x.islnk() and not x.name.startswith('/') and '..' not in pathlib.PurePosixPath(x.name).parts for x in members),'unsafe prior member');byname={x.name:x for x in members};fail(len(byname)==len(members),'duplicate prior member')
 def member(name):
  f=tf.extractfile(byname[name]);fail(f is not None,'missing prior member');return f.read()
 pm=json.loads(member('MANIFEST.json'));fail(sh(member('MANIFEST.json'))=='e2da98288113303ada94fcf3d9d03457a92abd021cbb8e30fc48727e7323ae25','prior manifest');fail(set(byname)==set(pm['files'])|{'MANIFEST.json'},'prior member inventory')
 for name,info in pm['files'].items():
  b=member(name);mm=byname[name];fail(sh(b)==info['sha256'] and len(b)==info['bytes'] and mm.mode==info['mode'],'prior member '+name)
 chains=json.loads(member('SOURCE-003-RESULT.json'))['rows'];fail(len(chains)==3,'prior proof rows')
 for proof in chains:
  for link in proof['chain']:
   b=member('trees/'+link['tree']+'.tree');fail(obj('tree',b)==link['tree'],'tree object');entries=tree_entries(b);fail(link['component'] in entries and entries[link['component']][1]==link['oid'],'tree path')
  fail(proof['blob']==primary[0]['blob'],'tree/blob relation')
 fail(next(x for x in chains if x['label']=='95e')['chain'][0]['tree']==cap['tree_95e'],'current root bind')
 fail(sh(member('REVIEW-L1.md'))==sh((ROOT/'prior/REVIEW-L1.md').read_bytes()),'predecessor Lens 1 report')
reg=readjson('SOURCE-REGISTRATION.json');sup=readjson('SUPPORT-REGISTRATION.json');sup2=readjson('SUPPORT-REGISTRATION-2.json');receipt=readjson('SOURCE-READ-RECEIPT.json');registered={}
def add(path,ranges):
 s=registered.setdefault(path,set())
 for lo,hi in ranges:s.update(range(lo,hi+1))
for row in reg['source_displays']:add(row['path'],row['ranges'])
for row in sup['windows']:add(row['path'],row['ranges'])
add(sup2['path'],sup2['ranges']);observed={}
for view in receipt['views']:
 path=view['path'];lo,hi=view['range'];src=(ROOT/('source/95e__'+path.replace('/','__'))).read_text().splitlines();expected=''.join(f'{n:4} {src[n-1]}\n' for n in range(lo,hi+1)).encode();b=(ROOT/view['file']).read_bytes();fail(b==expected and sh(b)==view['sha256'],'display '+view['file']);observed.setdefault(path,set()).update(range(lo,hi+1))
fail(registered==observed and receipt['display_count']==len(receipt['views'])==26,'registered versus actual windows');target=observed[primary[0]['path']];unread={n for lo,hi in receipt['target_unread_complement'] for n in range(lo,hi+1)};fail(not target&unread and target|unread==set(range(1,1898)),'unread complement')
h=readjson('HISTORY-SELECTION.json');q=readjson('history/Q3353-selected.json');r=next(x for x in h['selection'] if x['pointer']=='/entries/3353');fail(q['lens']==1 and q['contract_id']=='OBLIGATION-ROOT-L3-EXT-0050-LENS-01' and sh(canon(q))==r['canonical_selected_sha256'],'selected q3353');fail(all(x['parsed_original_reconstruction_equal'] for x in h['selection']),'selected queue equality qualification')
if args.repo:
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 def git(*a):return subprocess.check_output(['git','-C',str(args.repo),*a],env=env)
 fail(git('rev-parse','95e63628f9d70b8dd6e6fede64334696c6995009^{tree}').decode().strip()==cap['tree_95e'],'commit-to-tree')
 for row in rows:
  fail(git('rev-parse',row['revision']+':'+row['path']).decode().strip()==row['blob'],'git blob locator');fail(git('show',row['revision']+':'+row['path'])==(ROOT/row['file']).read_bytes(),'git source bytes')
 print('optional supplied Git commit/source objects match')
print('PASS: public inventory, prior members and tree paths, source objects, registered displays, q3353 selection; source/evidence only')
