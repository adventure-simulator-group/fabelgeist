# Independent bounded review of q3353, dialogue producer propagation

**Verdict.** The three selected traces in the earlier Lens 1 report are
supported at the displayed source boundaries. The selected reducer entry also
looks up the prompt and invokes the membership guard before checking the
respondent and choices. These observations do not establish whole-file
coverage, supported malformed data, a runtime outcome, a unique issue count,
or queue or lens closure.

## Scope and attribution

Original 059 `/entries/3353` is `OBLIGATION-ROOT-L3-EXT-0050-LENS-01`,
requiring `crates/strategic-web/src/routes/dialogue.rs:1–1897` at the
pr-working 6533 snapshot and an e275 revisit. Its historical status requires
own-lens proof; it carries zero body credit. The independently attributed
original reviewer `wrapped_scope` prospectively registered and displayed the
full file at verified identical 6533/e275/95e source bytes for four named
lenses. This review selects **Lens 1 only** and does not transfer that read.

The independent reader `mhr_character` registered and personally displayed
95e route lines 240–310, 1220–1489 and 1650–1770, plus the precisely listed
support windows in `SOURCE-READ-RECEIPT.json`. Route lines 1–239, 311–1219,
1490–1649 and 1771–1897 were not personally read for this review. The 6533 and
e275 bodies were captured for object identity; there was no independent
historical source display. The file has Git blob
`12479288a7088740a84536807f5ab2d08ebc9dd8`, SHA-256
`c3dde45589069173a7b9c0b94f377424e3164e25dbdde70df99cc9d9870d3a56`,
and 1,897 lines at each revision. Equality is per file, not per tree; the
recorded pr-working snapshot had unrelated changes. The 95e tree is
`1eec97de340d9b7debbb30ca0c0fb2240a73b93f`.

The recovered historical producer supplement identifies Camera receipt
`CAM-PPS-DIALOGUE-040` and Rig receipt `RIG-PPS-033`, each on 6533 material
lines 24–62, 235–378 and 1320–1897; neither is a full-file read. Camera's
`CAM-PPS-SOCIAL-027` is a separate bounded social supplement. The original
059 and path-redacted reconstructed whole queues differ, although the eight
selected parsed records in `HISTORY-SELECTION.json` agree. Older 774 records,
059 records, original reviewer material, this new assessment and 5f6a
committed-ledger records retain their original authors and revisions. None
establishes the missing checkpoint 3821.

## Source observations

1. HTTP `NpcChatRequest` retains `SocialDuration` and `SocialActionId`
   (`routes/dialogue.rs:260–264`); their deserializers admit 15–480 minutes in
   15-minute increments and one to 96 ASCII alphanumeric, dash or underscore
   bytes (`routes/mod.rs:59–124`). The route compares a receipt and then emits
   the values into the reducer call as primitives
   (`routes/dialogue.rs:1259–1318`). The selected receiver accepts primitive
   arguments across that call and independently validates those same value
   constraints (`social.rs:468–487,640–665`). This is a demonstrated boundary,
   not a defect merely because typed values are serialized. Other producers,
   consumers and transport behavior remain unreviewed.
2. `answer` parses the submitted session and prompt-row text and tests the
   syntactic pair before transmitting the raw prompt-row string
   (`routes/dialogue.rs:1684–1756`). A typed pair could preserve that local
   relationship up to the native boundary, but the shown guard dominates this
   call. It does not by itself establish prompt existence or authorization.
   The selected native receiver looks up the prompt, invokes
   `require_session_member` with the stored session, compares the participant's
   respondent role, and checks catalog/session revision and choice shape
   (`dialogue_prompts.rs:390–444`). This review did not inspect the complete
   implementation of the membership guard or all answer producers.
3. `ResolvedTurn` carries resolved fragments and source references
   (`adventuresim-dialogue/src/lib.rs:386–431`). The selected producer resolves
   the turn, then encodes those vectors into event JSON columns
   (`dialogue_prompts.rs:253–280,282–304`); prompt choices and references are
   separately encoded at 319–353. The schema retains those columns and the
   gateway view copies them (`dialogue_schema.rs:194–229,351–378,465–510`).
   The web projection decodes them (`routes/dialogue.rs:1385–1390,1443–1448,
   1461–1477`). Event fragments, event source references, topic source,
   prompt choices and prompt sources have five separately recorded fallback
   operations: original q461–q465 and committed 5f6a ledger rows 758–762.
   The selected native answer decoder instead returns errors for invalid choice
   JSON (`dialogue_prompts.rs:430–433`). Whether malformed stored rows can
   arise, and the intended error and recovery policy, remain open. The topic writer,
   all other writers and transaction behavior were not established here.

The old q227/ledger123 concerns `SocialActionKind` and a private readmission;
it is not automatically the `SocialActionId` boundary above. q2721 and ledger
1085–1086 concern distinct ballot/order and claim-occurrence questions. No
alias or new defect count is decided. Any future repair direction must retain
independent admission at genuine transport boundaries and decide typed
retention and malformed-row policy after the wider audit; no repair or product
validation was performed.

## Recovery and process limits

The source review is static. No product, reducer, parser, macro, fixture,
browser, build, test or runtime probe was run. The prior packet records failed
object locators, a duplicate-contract-ID extraction failure, and a truncated
client display followed by separately registered smaller displays. Its later
Lens 6 attribution correction distinguishes registration owner Camera from an
unidentified subsequent reader; it is preserved, not applied as new credit.
This review's failed attribution-report locator, truncated filename inventory,
and capture script's no-op blob assertion are separately recorded. A new
read-only check recomputed each Git blob hash from its object bytes. Receipt
timestamps are recording times, not individual display times. Evidence replay
checks integrity and the declared source relationships; it cannot validate
semantic conclusions or product behavior.
