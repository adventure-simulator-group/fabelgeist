# Additional scratch-copy qualification

The restricted privacy-scanner inputs were copied into a newly created scratch
subdirectory using a tree copy whose individual file creations were not
exclusive. No individual pre-copy existence check was recorded. No other
writer is known to have used the private directory; unexpected same-name
scratch-file truncation cannot be independently excluded. No source, previous
evidence, publication or protected extraction was changed. The restricted
record gives the command and preserves the initial public candidate and scan.
