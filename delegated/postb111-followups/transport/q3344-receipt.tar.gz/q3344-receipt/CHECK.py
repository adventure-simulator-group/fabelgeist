#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument("--public",type=pathlib.Path);a.add_argument("--delivery",type=pathlib.Path);a=a.parse_args();m=json.loads((P/"MANIFEST.json").read_bytes())
 fs={p.relative_to(P).as_posix() for p in P.rglob("*") if p.is_file() and p!=P/"MANIFEST.json"};assert fs==set(m["files"]) and not any(p.is_symlink() for p in P.rglob("*"))
 for n,v in m["files"].items():p=P/n;assert h(p)==v["sha256"] and p.stat().st_size==v["bytes"] and p.stat().st_mode&0o777==v["mode"]
 for n in ("PUBLIC-SCAN.json","DELIVERY-SCAN.json"):
  s=json.loads((P/n).read_bytes());assert all(v==0 for v in s["counts"].values()) and not s["hits"]
 r=json.loads((P/"REPLAY-RESULT.json").read_bytes());assert all(x["returncode"]==0 for x in r.values())
 i=json.loads((P/"IDENTITIES.json").read_bytes())
 if a.public:assert h(a.public/"MANIFEST.json")==i["public_manifest_sha256"]
 if a.delivery:assert h(a.delivery/"MANIFEST.json")==i["delivery_manifest_sha256"] and h(a.delivery/"q3344-peer.tar.gz")==i["archive_sha256"]
 print(json.dumps({"result":"pass","public_bound":bool(a.public),"delivery_bound":bool(a.delivery),"qualification":"Binds recorded results and identities; finite scan does not establish universal privacy."},sort_keys=True))
if __name__=="__main__":
 try:main()
 except Exception as e:print("receipt check failed",type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
