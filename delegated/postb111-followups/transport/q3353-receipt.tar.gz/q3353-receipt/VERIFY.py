#!/usr/bin/env python3
import argparse,hashlib,json,pathlib
if not __debug__:raise SystemExit("optimized Python unsupported")
r=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument("--public",type=pathlib.Path);a=p.parse_args()
m=json.loads((r/"MANIFEST.json").read_bytes());files={str(x.relative_to(r)) for x in r.rglob("*") if x.is_file() and x!=r/"MANIFEST.json"}
if files!=set(m["files"]):raise RuntimeError("inventory")
for name,info in m["files"].items():
 f=r/name;b=f.read_bytes()
 if f.is_symlink() or len(b)!=info["bytes"] or hashlib.sha256(b).hexdigest()!=info["sha256"] or f.stat().st_mode&0o777!=info["mode"]:raise RuntimeError(name)
d=json.loads((r/"RECEIPT.json").read_bytes())
if a.public and hashlib.sha256((a.public/"MANIFEST.json").read_bytes()).hexdigest()!=d["public_manifest_sha256"]:raise RuntimeError("public binding")
print("PASS: receipt integrity and optional public manifest binding; no product validation")
