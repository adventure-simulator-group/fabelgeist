# Independent peer review: q3344 aggregate states

This is a bounded, independently attributed Lens 5 review of the original
role 0049 assessment. The original delegate and this reviewer performed
separate, preregistered source reads; neither transfers credit from earlier
lenses or from the other. The exact reviewer mapping is in restricted custody.
This is source assessment only, not an adopted ledger change or a queue, lens,
alias or defect-count conclusion.

The recovered 059 entry `/entries/3344` assigns
`OBLIGATION-ROOT-L3-EXT-0049-LENS-05` to
`crates/strategic-web/src/templates/interface_help.rs`, historical
`pr-working` revision `6533e444fa37552927070cc8d8190907fd3b413e`, lines
1–119 inclusive, EOF 119. Its e275 revisit requires the same lines and its
own-lens evidence. This reviewer read all 119 lines separately at 6533,
e275, and pinned working authority 95e63628f9d70b8dd6e6fede64334696c6995009.
The file bytes match at those three Git object identities, SHA-256
c78ba1ba7989dbb10ddda4b92fd1118f802fa26bb36d5e5623449ffb567af9c9 and
Git blob a7039e20b4b2e2fcc8805658a59cbe8847271080. This per-file match does
not establish a clean historical working tree or tree equivalence.

The original and reconstructed complete 059 queues differ as bytes, while
this selected parsed record matches its recovered original, reconstruction,
and the earlier published selection. The original delegate's extractor first
omitted the e275 requirement by looking up the wrong key; its separate
correction retains the full requirement. At observed commit
5f6a6e829dca0f8b2a5efff9b6f17fab5db71ae0, the differently shaped
reconciliation overlay records q3344 as unassessed. This is a bound snapshot,
not a claim about later publication state. No earlier evidence is promoted to
missing checkpoint 3821.

## Findings

- `interface_help.rs:76–93` independently accepts the region, reading,
  soundness value, and built bar. `character_health.rs:1192–1248,1260–1327,
  1368–1437` passes raw ordinal/name/slug tuples and computes `okay` for the
  selected reading and meter. The shown seven ordinal/name/slug pairings agree
  with `BodyRegion` and `BodyRegion::ALL` in `physiology.rs:192–217`; the
  selected caller coordinates reading, soundness, and bar. Differing helper
  inputs are representable, but no actually mismatched caller or supported
  incorrect state is demonstrated. The bounded inspection is not a global
  caller inventory.
- The delegate's original report said the applicant panel contains both label
  controls. Its separately sealed additive correction conditions this on
  both optional attributes and skills projections being present. This
  independent review corroborates the correction using
  `character_details.rs:39–66`, `character_health.rs:1189–1191`, and
  `character_skills.rs:1021–1025`; the clarification belongs to the original
  delegate and is not a new peer discovery.
- `recruitment.rs:329–363` provides a template; the selected callback in
  `party-recruitment.js:81–106` clones it and does not itself issue a mount
  event. `stats-panels.js:4–22` binds controls at its initial mount and on
  `strategic-page-mounted`. If controls are inserted after mount and no later
  mount or alternate binding occurs, this module gives those clones no
  listener. If both controls are mounted and choose the same nearest aside,
  each writes the same `data-stat-labels-visible` attribute despite distinct
  storage keys, so the last update determines that shared attribute and its
  descendant CSS selectors (`stats.css:13–14,21–24,33–39`). Host markup,
  event ordering, any alternate binding, CSS application, and user-visible
  impact remain open; the displayed `layout.rs:55–100` is a notice-page
  aside and does not establish the applicant's actual host.

## Historical relationships and remaining questions

Historical q2453 is a separate Lens 2 read; q3298 is a separate Lens 3 read.
Their 6533 personal reads and e275 same-lens identity qualifications are
not this review's credit. Original role 2394 preserves the earlier Lens 11
split range in `READ-L11-390`. Historical q197 and ledger row 785 concern
limb-projection availability, while ledger row 857 concerns injury-observation
availability; their first operations differ from the aggregate and conditional
control questions above. Relationships, aliases and any unique count remain
for central reconciliation.

The producer shape admits separately supplied leaves, but supported alternate
construction, an actual mismatched tuple, the intended control ownership and
normal lifecycle reachability are not established here. No product, browser,
fixture, test, build, macro, shader, or runtime probe was run. Source blobs are
retained for identity; only the registered line windows are this reviewer's
personal source-read scope. Public checks bind the evidence bytes and windows;
full queue, historical and Git commit/tree checks require the separately held
restricted packet. The recorded display and file chronology are not an
independently signed display or trusted timestamp.
