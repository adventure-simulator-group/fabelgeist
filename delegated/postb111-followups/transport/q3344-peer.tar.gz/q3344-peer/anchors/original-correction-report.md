# Additive correction: applicant statistics controls

The sealed role 0049 report says the applicant statistics panel “contains
both attribute and skill label controls.” That wording is too broad. The
selected panel can contain both controls **when both the attributes and skills
projections are present**. If attributes are absent, `party_attributes_rail`
returns empty (`character_health.rs:1189–1191`). If skills are absent,
`party_skills_rail` does not enter the branch that emits `skill_key`
(`character_skills.rs:1021–1025`). `character_stats_panel` passes the two
separate options (`character_details.rs:39–66`).

The report's later shared-aside scenario already conditions its analysis on
both controls being mounted. Both its shared-attribute conclusion and the
separate conditional missing-remount observation remain source-level questions;
page activation, lifecycle and browser behavior were not executed. This
correction changes no earlier receipt or attribution, claims no new source
read, and does not decide alias, unique count, queue or lens closure.

This is a later additive packet, outside the checkpoint frozen through role
0048. It binds the earlier role 0049 public manifest by whole-file SHA-256;
the exact prior packet remains unchanged.
