#!/usr/bin/env python3
"""Read-only evidence integrity and optional restricted-custody check."""
import argparse,hashlib,json,pathlib,subprocess,sys,tarfile
P=pathlib.Path(__file__).resolve().parent

def need(x,msg):
 if not x: raise ValueError(msg)
def sha(x):return hashlib.sha256(x).hexdigest()
def oid(kind,x):return hashlib.sha1(kind+b" "+str(len(x)).encode()+b"\0"+x).hexdigest()
def load(p):return json.loads(p.read_bytes())
def tree(data):
 i=0;out={}
 while i<len(data):
  sp=data.index(b" ",i);z=data.index(b"\0",sp+1);need(z+21<=len(data),"tree truncated")
  n=data[sp+1:z].decode();need(n not in out,"duplicate tree entry");out[n]=(data[i:sp].decode(),data[z+1:z+21].hex());i=z+21
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument("--restricted",type=pathlib.Path);a=ap.parse_args()
 manifest=load(P/"MANIFEST.json");files={p.relative_to(P).as_posix() for p in P.rglob("*") if p.is_file() and p!=P/"MANIFEST.json"}
 need(not any(p.is_symlink() for p in P.rglob("*")) and files==set(manifest["files"]),"public file set")
 for n,v in manifest["files"].items():
  q=P/n;b=q.read_bytes();need(sha(b)==v["sha256"] and len(b)==v["bytes"] and (q.stat().st_mode&0o777)==v["mode"],"public file "+n)
 rows=load(P/"SOURCE-CAPTURE.json")+load(P/"SOURCE-CAPTURE-005.json")
 regs=[]
 for e in load(P/"REG-004-SOURCE.json")["views"]:
  for rg in e["ranges"]:regs.append((pathlib.PurePosixPath(e["input"]).name,e["path"],rg))
 for e in load(P/"REG-005-SOURCE.json")["views"]:regs.append((pathlib.PurePosixPath(e["input"]).name,e["path"],e["range"]))
 need(len(rows)==20 and len(regs)==20,"own range count")
 for x in rows:
  need((x["capture"],x["path"],x["lines"]) in regs,"own preregistration")
  b=(P/"source"/x["capture"]).read_bytes();lines=b.decode().splitlines();lo,hi=x["lines"]
  need(sha(b)==x["source_sha256"] and len(lines)==x["EOF"] and 1<=lo<=hi<=len(lines),"source identity")
  w=(P/"source"/x["window"]).read_bytes();expect="".join(f"{i:4d} {lines[i-1]}\n" for i in range(lo,hi+1)).encode()
  need(w==expect and sha(w)==x["sha256"],"view bytes")
 c=load(P/"READ-CHRONOLOGY.json");need(len(c["rows"])==20 and all(x["registration_mtime_ns"]<=x["window_mtime_ns"] for x in c["rows"]),"local file chronology")
 q=load(P/"q3344-original-normalized.json");now=load(P/"q3344-observed-overlay.json")
 need(q["contract_id"]==now["contract_id"]=="OBLIGATION-ROOT-L3-EXT-0049-LENS-05" and q["lens"]==now["historical_lens"]==5 and now["current_reconciliation"]=="unassessed","selected queue IDs")
 need(sha((P/"anchors/original-manifest.json").read_bytes())=="793af46b057c42b9c117cc3de19cd82ef89ac6f740023051da928dd0e34715ea","original manifest")
 need(sha((P/"anchors/correction-manifest.json").read_bytes())=="1c76fa49aacd9fe15722d54bd4e07cd529ece17d458426854e118d60e54f4369","correction manifest")
 m=load(P/"anchors/correction-manifest.json");need(sha((P/"anchors/original-correction-report.md").read_bytes())==m["files"]["REPORT.md"]["sha256"],"correction report")
 full=False
 if a.restricted:
  r=a.restricted;old=r/"predecessor/original-restricted";pub=old/"public-transport"
  need(sha((old/"PRIVATE-MANIFEST.json").read_bytes())=="d08d5a727218db10361759f24e5c40e74a368806bc81928170dfcfd7bcb85548","restricted predecessor")
  for cmd in ([sys.executable,"-B",str(old/"verify-private.py")],[sys.executable,"-B",str(r/"correction/original-correction/verify.py"),"--prior",str(pub)]):
   p=subprocess.run(cmd,capture_output=True);need(p.returncode==0,"predecessor evidence check")
  for x in rows:need((P/"source"/x["capture"]).read_bytes()==(pub/"sources"/x["capture"]).read_bytes(),"source to Git proof")
  h=old/"historical"
  for name in ("queue-original-56f.json","queue-reconstructed-dac7d.json","queue-published-ede12.json"):need(load(h/name)["entries"][3344]==q,"historical selection")
  obs=r/"historical";b=(obs/"observed-commit.bin").read_bytes();need(oid(b"commit",b)=="5f6a6e829dca0f8b2a5efff9b6f17fab5db71ae0","observed commit")
  t=(obs/"observed-root-tree.bin").read_bytes();root=b.splitlines()[0].split()[1].decode();need(oid(b"tree",t)==root,"observed root tree")
  m,o=tree(t)["RECONCILIATION-059.json"];blob=(obs/"observed-queue.json").read_bytes();need(m=="100644" and oid(b"blob",blob)==o and load(obs/"observed-queue.json")["entries"][3344]==now,"observed queue binding")
  archive=r/"predecessor/published-help.tar.gz";need(sha(archive.read_bytes())=="77d965e748c3fcb879a2d9f126bc7b309b20ab826011a5aaddd69c6551760c7a","original published archive")
  with tarfile.open(archive,"r:gz") as tf:
   ms=tf.getmembers();need(all(x.isfile() and x.name.startswith("help/") for x in ms),"archive member types")
   actual={x.name:tf.extractfile(x).read() for x in ms};expected={"help/"+p.relative_to(pub).as_posix():p.read_bytes() for p in pub.rglob("*") if p.is_file()}
   need(len(ms)==len(actual) and actual==expected,"archive byte content")
  full=True
 print(json.dumps({"result":"pass","public_files":len(files),"source_windows":len(rows),"restricted_history_and_git_proofs_checked":full,"qualification":"Evidence integrity only; display is reviewer-reported, timestamps are local, no product execution or closure."},sort_keys=True))
if __name__=="__main__":
 try:main()
 except Exception as e:print("evidence check failed:",type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
