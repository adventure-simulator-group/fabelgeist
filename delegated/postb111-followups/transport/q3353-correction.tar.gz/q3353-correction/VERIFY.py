#!/usr/bin/env python3
import argparse,hashlib,json,pathlib
if not __debug__:raise SystemExit("optimized Python unsupported")
r=pathlib.Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument("--replay",type=pathlib.Path);a=p.parse_args();m=json.loads((r/"MANIFEST.json").read_bytes())
for name,x in m["files"].items():
 f=r/name;b=f.read_bytes()
 if hashlib.sha256(b).hexdigest()!=x["sha256"] or len(b)!=x["bytes"]:raise RuntimeError(name)
d=json.loads((r/"CORRECTION.json").read_bytes())
if a.replay and hashlib.sha256((a.replay/"MANIFEST.json").read_bytes()).hexdigest()!=d["verified_replay_manifest_sha256"]:raise RuntimeError("replay binding")
print("PASS: custody correction and optional replay binding")
