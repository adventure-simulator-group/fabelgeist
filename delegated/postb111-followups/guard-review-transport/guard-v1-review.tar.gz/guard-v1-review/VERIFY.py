#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,stat
p=Path(__file__).resolve().parent;m=json.loads((p/'MANIFEST.json').read_bytes());names=set()
for r in m['files']:
 assert '/' not in r['path'] and r['path'] not in names;names.add(r['path']);f=p/r['path'];assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),hashlib.sha256(b).hexdigest(),oct(stat.S_IMODE(f.stat().st_mode)))==(r['bytes'],r['sha256'],r['mode'])
assert {f.name for f in p.iterdir()}==names|{'MANIFEST.json'}
print('Verified bounded public review identities; restricted originals and independent custody remain separate.')
