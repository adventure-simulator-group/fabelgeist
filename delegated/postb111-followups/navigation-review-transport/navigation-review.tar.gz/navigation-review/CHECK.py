#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def need(x,m):
 if not x:raise ValueError(m)
try:
 ap=argparse.ArgumentParser();ap.add_argument("--restricted",type=Path);ap.add_argument("--prior",type=Path);a=ap.parse_args();m=load(P/"MANIFEST.json");fs={x.relative_to(P).as_posix() for x in P.rglob("*") if x.is_file() and x!=P/"MANIFEST.json"};need(fs==set(m["files"]) and not any(x.is_symlink() for x in P.rglob("*")),"public file set")
 for n,v in m["files"].items():
  p=P/n;b=p.read_bytes();need(sha(b)==v["sha256"] and len(b)==v["bytes"] and p.stat().st_mode&0o777==v["mode"],"public file")
 x=load(P/"DRAFT-v4.json");y=load(P/"DRAFT-v5.json");c=load(P/"CORRECTION.json");need(sha((P/"DRAFT-v4.json").read_bytes())==c["predecessor_sha256"]=="08722589f73bfddd7df95e77e0183558b7fb2a9120b1a3bfa19d2e2d1c9854db" and sha((P/"DRAFT-v5.json").read_bytes())==c["successor_sha256"]=="1212f4f29a5dbf2ed6d4faff7788d9df13ed744a69b7c7c1262548d3899d1fef","draft hashes")
 changes=[]
 def diff(a,b,path):
  if type(a)!=type(b):changes.append({"path":path,"before":a,"after":b});return
  if isinstance(a,dict):
   for k in sorted(a.keys()|b.keys()):
    if k not in a:changes.append({"path":path+"/"+k,"before":"<missing>","after":b[k]})
    elif k not in b:changes.append({"path":path+"/"+k,"before":a[k],"after":"<missing>"})
    else:diff(a[k],b[k],path+"/"+k)
  elif isinstance(a,list):
   if len(a)!=len(b):changes.append({"path":path,"before":a,"after":b})
   else:
    for i,(v,w) in enumerate(zip(a,b)):diff(v,w,path+"/"+str(i))
  elif a!=b:changes.append({"path":path,"before":a,"after":b})
 diff(x,y,"");need(changes==load(P/"RECURSIVE-DIFF.json") and {v["path"] for v in changes}=={"/schema","/predecessor_draft_sha256","/correction_qualification","/proposed_ledger_relationships/0/queue"} and x["counts_if_adopted"]==y["counts_if_adopted"] and y["proposed_ledger_relationships"][0]["queue"]==[0,61],"comparison")
 checked=False
 if a.restricted:
  cmd=[sys.executable,"-B",str(a.restricted/"CHECK-CORE-v2.py"),"--public",str(P)]
  if a.prior:cmd += ["--prior",str(a.prior)]
  r=subprocess.run(cmd,capture_output=True);need(r.returncode==0,"restricted check "+r.stderr.decode()[:250]);checked=True
 print(json.dumps({"result":"pass","files":len(fs),"restricted_checked":checked,"prior_full_history_checked":bool(checked and a.prior),"qualification":"Evidence-only metadata check; no source credit, alias, closure or product validation."},sort_keys=True))
except Exception as e:print("public check failed:",type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
