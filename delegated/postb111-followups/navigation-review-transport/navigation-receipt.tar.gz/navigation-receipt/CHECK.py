#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,sys
P=Path(__file__).resolve().parent
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 ap=argparse.ArgumentParser();ap.add_argument("--public",type=Path);ap.add_argument("--delivery",type=Path);a=ap.parse_args();m=json.loads((P/"MANIFEST.json").read_bytes());fs={x.relative_to(P).as_posix() for x in P.rglob("*") if x.is_file() and x!=P/"MANIFEST.json"};assert fs==set(m["files"]) and not any(x.is_symlink() for x in P.rglob("*"))
 for n,v in m["files"].items():x=P/n;assert h(x)==v["sha256"] and x.stat().st_size==v["bytes"] and x.stat().st_mode&0o777==v["mode"]
 for n in ("PUBLIC-SCAN.json","DELIVERY-SCAN.json"):
  z=json.loads((P/n).read_bytes());assert not z["hits"] and all(v==0 for v in z["counts"].values())
 r=json.loads((P/"REPLAY-RESULT.json").read_bytes());assert all(x["status"]==0 for x in r.values());i=json.loads((P/"IDENTITIES.json").read_bytes())
 if a.public:assert h(a.public/"MANIFEST.json")==i["public_manifest_sha256"]
 if a.delivery:assert h(a.delivery/"MANIFEST.json")==i["delivery_manifest_sha256"] and h(a.delivery/"v5-review.tar.gz")==i["archive_sha256"]
 print(json.dumps({"result":"pass","public_bound":bool(a.public),"delivery_bound":bool(a.delivery),"qualification":"Recorded evidence checks and finite scan only."},sort_keys=True))
except Exception as e:print("receipt check failed:",type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
