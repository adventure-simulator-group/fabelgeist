# Independent organization draft review

Read REPORT.md for the organization-only verdict and limitations. Run
`python3 -B VERIFY.py` for offline manifest, source and display checks. Optional
`--repo PATH` binds pinned source, b111 ledger and cited archives; optional
`--private PATH` checks exact draft and redaction inputs; `--history PATH`
checks separately preserved original 059 queues, and `--archives PATH` checks
locked native archive/member identities. Without those dependencies, the
corresponding bindings remain declared rather than independently replayed.
Evidence checks do not run product code or validate behavior.
