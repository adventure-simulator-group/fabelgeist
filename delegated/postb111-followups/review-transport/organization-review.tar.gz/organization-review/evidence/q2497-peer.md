# Independent q2497 admission review

The bounded peer review supports the delegate's conditional question. At pinned
95e, organization catalog validation accepts positive finite training weights
as f64 and checks their f64 sum; the retained `TrainingEntry.weight` is f32.
An otherwise valid list with weights 1.0 and 1e-50 satisfies those numerical
checks: the tiny addend is lost when added at one in binary64. If the selected
serialization and decoding path preserves a value of that scale until f32
conversion, it rounds to zero, below half the least positive binary32
subnormal. This is a conditional admission question, not an observed failure.

As a representable alternative, 0.5 and 0.5 are exact in both formats and sum
to one, assuming the other catalog fields are valid. That example does not
resolve what the authored weight policy should be. A general `TrainingEntry`
producer intentionally constructs unnormalized childhood weights; the catalog
sum-to-one check must not be promoted to a universal type invariant.

Independent source displays cover selected windows of organization.rs,
organization_catalog_validation.rs, build.rs, life_simulation.rs, and the
strategic character-skills preview. The relevant owners and consumers are
organization.rs:354–367 and 487–492; validation.rs:584–653; build.rs:407–455
and 496–501; life_simulation.rs:104–125 and 240–334; and
character_skills.rs:841–855. The build producer gives each document a source
label; a separate validator accepts paired slices through `zip`, but another
supported short-label caller has not been established.

The selected checksum-matching Serde, serde_json and formatter source traces
support the typed field and possible narrowing. The derive source treats the
non-flattened weight as a typed map value; the f32 visitor narrows an f64. The
serde_json decoder has a separate `float_roundtrip` branch, and its finite f64
serializer delegates to the locked formatter. Feature selection, the complete
formatter-to-parser behavior for this value, an actual authored occurrence,
supported input policy and downstream consequences remain open. No dependency
code or product code was executed.

Original 059 q2497 names pr-working organization.rs at 6533, with required
lines 1–498. The delegate independently displayed those current lines under
Lens 3; this peer independently displayed only the registered selected windows.
The 6533, e275 and 95e organization blobs match per file, not as complete
worktrees. The original and reconstructed q2497 element bytes match; their full
059 queue streams have distinct identities. The q2812 anchor collection and
full delegate replay were verified, and f2ec records q2497 as unassessed.

The recovered Lens 2 qualification identifies original supplier root, source
revision 6533 and metadata revision f82; it records prior 1–1251 and selected
same-lens 1–498, with zero fresh or current body credit from metadata. The
historical 6533 Lens 3 personal read of 1–633 is separate. The e275 Lens 3
record has no fresh current ranges and makes its same-lens reuse conditional on
frozen-source adoption, which remains pending. No reading credit transfers.
The delegate's related q3300, q3446 and q2491 references, and f2ec ledger rows
80, 84, 445 and 456, remain relationships to distinct first operations, not
established aliases or new counts.

The first delegate Git lookup failed for 95e; a separately captured commit and
tree fallback later verified the source. A formatter README request exceeded
EOF and failed before display; its corrected registered range is distinct.
The predecessor public privacy scan returned success but reported two
private-value candidates in the crosswalk. The successor removes one duplicate
tree and crosswalk entry; its recorded bounded scan has no candidates. Both
versions and scans remain in restricted custody. This peer also recorded two
initial missing-metadata locators and a later truncated scratch search; their
tool-visible outputs were not separately captured verbatim. They gave no source
reading credit.

The evidence-only verifier checks source and historical identities, registered
windows, locked archive members, the predecessor correction, and the inherited
receipt. It can also recheck the separately held q2812 anchors. Display events
are reader attestations, not independent telemetry. The full delegate replay
and original anchor modes require their separately preserved same-machine inputs;
this is not independent custody. Missing pre-export originals, SOURCE004, the
73 nontext/no-positive-EOF obligations and absent checkpoint 3821 remain
qualified. No product build, test, runtime probe, repair, unique count or lens
closure is claimed.
