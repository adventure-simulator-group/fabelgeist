# q2497: bounded Lens 3 admission review

This is a new, independently attributed source-only review of historical 059
entry q2497, `EXTENSION-L3-ROOT-L2-EXT-0055`, against pinned
95e63628f9d70b8dd6e6fede64334696c6995009, root tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. The original and reconstructed
q2497 element bytes match, while the whole queues have different identities.
The f2ec reconciliation records q2497 as unassessed; this packet proposes no
queue closure, unique-defect count or checkpoint 3821 recovery.

## Source scope and admission paths

The historical record names the pr-working organization.rs source at 6533,
SHA-256 `cb410372fbb5a1f8b61fad2bf447bcd93512725560fb69338ec024ed3135b0e1`,
EOF 1251, required lines 1–498. This reviewer prospectively registered and
personally displayed all five current 95e windows covering 1–498 under Lens 3.
The corresponding 6533 and e275 Git blobs have the same byte identity, but
that equality does not establish the state of any historical worktree. No
current 499–1251 reading or other-lens credit is claimed. The initial local
Git lookup failed for the 95e object; a separately registered captured
commit/tree/blob proof verified the exact fallback, and the failure is retained.
Display events are reader attestations rather than independent telemetry.

`OrganizationCatalog`, roles, chapters, requirements and activity types have
public fields and derived deserialization (organization.rs:20–34,89–126,
139–173,224–255,317–395). The selected ordinary producer loads organization
JSON values, creates one source entry per value, validates, then embeds the
original documents (build.rs:389–455,496–501). The catalog decodes the
embedded JSON through Serde (organization.rs:487–492). The selected validator
checks known reward variants, training target kinds and their named selector
lists (organization_catalog_validation.rs:584–648). It requires each authored
training weight to be positive and finite as f64 and requires a nonempty list's
f64 sum to be within 0.000001 of one (:594–607,650–653). The typed
`TrainingEntry.weight` field is f32 (organization.rs:362–367).

A source-supported conditional representation question follows. Given an
otherwise accepted authored list with weights `1.0` and `1e-50`, binary64
addition at one loses the tiny positive addend, so the selected f64 checks can
accept both and their total. If the tiny value remains of that scale through
the selected serialization and decoding path, it is below half the smallest
positive binary32 subnormal and rounds to zero in f32. The 95e Cargo.lock and
checksum-matched local Serde archives bind the static source trace: the
non-flattened weight uses MapAccess's typed next-value path (serde_derive
1.0.229 `src/de/struct_.rs:236–272`); Serde's f32 visitor narrows f64
(serde_core 1.0.229 `src/de/impls.rs:129–149,222–240,450–455`); the selected
serde_json 1.0.151 number path dispatches to that visitor, with a separate
float_roundtrip branch (`src/de.rs:109–128,319–354,509–512,567–671,
1341–1353,1508–1513`). Its value serializer delegates finite f64 formatting
to the checksum-bound zmij 1.0.23 formatter (`number.rs:372–394`,
`ser.rs:169–178,1716–1722`; zmij `lib.rs:1364–1366,1764–1769`). Feature
selection and complete formatter-to-decoder behavior for this input were not
executed or independently established. Actual authored occurrence, supported
input policy, reachability and practical consequences remain open. This is a
conditional admission question, not a demonstrated product failure.

The selected creation-time lifecycle normalizes catalog training after reading
its f32 weights (life_simulation.rs:155–165,240–258,302–334); the selected
web preview multiplies each f32 weight (character_skills.rs:841–855). The same
public TrainingEntry is also used for intentionally unnormalized childhood
entries of 0.25 and 0.20 before normalization (life_simulation.rs:104–125).
Thus the catalog's sum-to-one policy must not be asserted for every general
TrainingEntry producer. Public struct literals and derived decoders can express
other combinations; which alternate constructors are supported and what their
contracts should be remain open.

`validate_documents` iterates documents and source labels with `zip`
(organization_catalog_validation.rs:207–216). The selected ordinary builder
creates one label for each value, so it does not establish a short-label
witness (build.rs:407–431). Whether another supported caller can supply a
shorter source slice and what it should guarantee remain open; this observation
is not an asserted additional defect.

## Historical attribution and relationships

The exact previously missing inherited-Lens2 qualification was found in two
older collections and both copies matched the q2497 expected SHA-256
`bd94d9ee48850460d399a43ad162a05de0601918d3f4431e50417b63d4e408d6`.
Its row 0 records original supplier `root`, metadata revision f82adcabd9d89c4fa2dd7f99253a45297a0681ee,
original source identity pr-working at 6533, prior assessed 1–1251 and
selected same-Lens2 1–498. The metadata qualification claims zero fresh
personal and zero body/original/current credit from metadata. The metadata
revision is not the source revision. The independently recovered Lens3 6533
receipt records the historical Root personal 1–633 read; the e275 Lens3
receipt records no fresh current ranges, qualified 1–633 reuse and
`frozen_source_adoption_pending: true`. The latter adoption condition remains
unresolved. These are separate records and do not confer this reviewer's fresh
credit. The role0057 delegate's 1–633 read covered separately registered lenses
1, 2, 5 and 6; it is not this new Lens3 read.

Historical q3300 addresses practice cadence; q3446 addresses role optional
field shape; q2491 addresses profession Fame preview parity. They have distinct
first operations. The f2ec ledger's rows 80 and 84 concern equipment dimension
and quest-monster-weight narrowing in other domains; rows 445 and 456 concern
bestiary and religion selector ownership. Their existence does not establish
an alias to this candidate. Any connected repair planning should first decide
the authored weight policy and representation boundary, trace supported
producers and consumers and then consider either checked narrowing or a
consistent wider representation. Acceptance checks and implementation are
future work only.

The separate 73 nontext/no-positive-EOF obligations remain open; their count was
not independently re-established here. The initial formatter README range
registration exceeded EOF 42, so its capture failed before display; both the
failed attempt and separately registered corrected display are retained.
Recovered evidence, reconstructed records, historical summaries and this newly
assessed work remain distinct. No product code, dependency code, macros,
examples, build, test, fixture, runtime probe or repair was executed.
