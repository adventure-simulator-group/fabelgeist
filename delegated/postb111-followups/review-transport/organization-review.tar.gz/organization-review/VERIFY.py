#!/usr/bin/env python3
"""Read-only evidence replay; never execute source, macros or product."""
import argparse,hashlib,io,json,os,pathlib,subprocess,tarfile
if not __debug__:raise SystemExit('optimized Python unsupported')
R=pathlib.Path(__file__).resolve().parent
pa=argparse.ArgumentParser();pa.add_argument('--repo',type=pathlib.Path);pa.add_argument('--private',type=pathlib.Path);pa.add_argument('--history',type=pathlib.Path);pa.add_argument('--archives',type=pathlib.Path);a=pa.parse_args()
def j(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def ck(x,msg):
 if not x:raise RuntimeError(msg)
def manifest(root,name):
 d=j(root/name);actual={str(x.relative_to(root)) for x in root.rglob('*') if x.is_file() and x!=root/name};ck(actual==set(d['files']),'inventory')
 for rel,v in d['files'].items():
  f=root/rel;ck(not f.is_symlink(),'symlink');b=f.read_bytes();ck(sha(b)==v['sha256'] and len(b)==v['bytes'] and f.stat().st_mode&0o777==v['mode'],'manifest '+rel)
def obj(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
manifest(R,'MANIFEST.json');cap=j(R/'CAPTURE-RESULT.json');nat=j(R/'NATIVE-CAPTURE.json');reg=j(R/'SOURCE-REGISTRATION.json');nr=j(R/'NATIVE-REGISTRATION.json');read=j(R/'SOURCE-READ-RECEIPT.json');ck(cap['tree_95e']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','tree identity')
for row in cap['source_rows']:
 b=(R/('source/'+row['path'].replace('/','__'))).read_bytes();ck(sha(b)==row['sha256'] and obj('blob',b)==row['blob'] and len(b.splitlines())==row['EOF'],'product source')
for row in nat['packages']:
 b=(R/row['source_file']).read_bytes();ck(sha(b)==row['member_sha256'] and len(b.splitlines())==row['EOF'] and row['checksum']==row['archive_sha256'],'native source')
registered={}
def add(kind,path,ranges):
 s=registered.setdefault((kind,path),set())
 for lo,hi in ranges:s.update(range(lo,hi+1))
for x in reg['windows']:add('product',x['path'],x['ranges'])
for x in nr['package_sources']:add('native-package',x['member'],x['ranges'])
observed={}
for v in read['views']:
 kind,path=v['kind'],v['path'];lo,hi=v['range'];filename=('source/'+path.replace('/','__')) if kind=='product' else ('native/'+path.replace('/','__'));lines=(R/filename).read_text().splitlines();want=''.join(f'{n:4} {lines[n-1]}\n' for n in range(lo,hi+1)).encode();got=(R/v['file']).read_bytes();ck(got==want and sha(got)==v['sha256'],'source display');observed.setdefault((kind,path),set()).update(range(lo,hi+1))
ck(registered==observed and read['display_count']==len(read['views'])==37,'actual scopes')
compare=j(R/'evidence/ORGANIZATION-COMPARE.json');succ=j(R/'evidence/ORGANIZATION-v3-v4.json');ck(compare['v3']==succ['v3'] and succ['counts_unchanged'],'successor v3 identity/counts')
a3={x['index']:x for x in succ['v3']['assessments']};a4={x['index']:x for x in succ['v4']['assessments']};ck(set(a3)==set(a4)=={2497,2501,2503,2504},'organization indices')
for i in [2497,2501,2503,2504]:
 keys={k for k in set(a3[i])|set(a4[i]) if a3[i].get(k)!=a4[i].get(k)};ck(keys==({2497:{'assessment'},2501:{'limits'},2503:set(),2504:set()}[i]),'v4 assessment deltas')
ck(succ['v3']['relationships']==succ['v4']['relationships'] and len(succ['v4']['relationships'])==3,'v4 relationships');ck('nonempty training list' in a4[2497]['assessment'] and 'more than one document' in a4[2501]['limits'],'refinement wording');ck('ignores the optional leaf for ordinary skills' in a4[2503]['assessment'],'leaf refinement')
if a.private:
 p=a.private.resolve();manifest(p,'PRIVATE-MANIFEST.json')
 for x in j(R/'RECONSTRUCTION.json')['changes']:
  old=j(p/x['file']);new=j(R/x['file']);ck(sha((p/x['file']).read_bytes())==x['private_whole_sha256'] and sha((R/x['file']).read_bytes())==x['public_whole_sha256'],'redaction hashes');old[x['field'][1:]]='independent organization review';ck(old==new,'redaction delta')
 for n,expected in [('DRAFT-v2.json','3da8b74f6f80481c4e5c4ef153d2da5adceef930d4ff11b75696aea18d54e7de'),('DRAFT-v3.json','f35225aaabd5412603d259e1302e5221af144e33904940dfe8ba51641816c74a'),('DRAFT-v4.json','08722589f73bfddd7df95e77e0183558b7fb2a9120b1a3bfa19d2e2d1c9854db')]:ck(sha((p/'evidence'/n).read_bytes())==expected,'draft identity')
 selected=[2497,2501,2503,2504];rel=['relationship-organization-training-weight-narrowing-95e','relationship-organization-profession-list-authority-95e','relationship-organization-skill-requirement-shape-95e']
 def choose(d):return {'assessments':[x for x in d['assessments'] if x['index'] in selected],'relationships':[x for x in d['proposed_ledger_relationships'] if x['id'] in rel]}
 ck(choose(j(p/'evidence/DRAFT-v2.json'))==compare['v2'] and choose(j(p/'evidence/DRAFT-v3.json'))==succ['v3'] and choose(j(p/'evidence/DRAFT-v4.json'))==succ['v4'],'exact selected drafts');print('optional private drafts and reconstruction match')
if a.history:
 h=a.history.resolve();ck(sha((h/'PRIVATE-MANIFEST.json').read_bytes())=='26e9f48a0cbba8de7819a5d86f1299e944cd0ba02c383d188c6fa067cd15c533','prior history identity');cmp=j(R/'evidence/QUEUE-ELEMENT-COMPARISON.json');dec=json.JSONDecoder()
 for filename,label in [('QUEUE-ORIGINAL.json','original'),('QUEUE-RECONSTRUCTED.json','reconstructed')]:
  b=(h/'history'/filename).read_bytes();ck(sha(b)==cap['original_queue_sha256' if label=='original' else 'reconstructed_queue_sha256'],'queue full identity');s=b.decode();pos=s.index('[',s.index('"entries"'))+1;wanted={int(i) for i in cmp['selected']}
  for i in range(max(wanted)+1):
   while s[pos].isspace() or s[pos]==',':pos+=1
   start=pos;_,pos=dec.raw_decode(s,pos)
   if i in wanted:ck(sha(s[start:pos].encode())==cmp['selected'][str(i)][label]['sha256'],'queue element')
 print('optional exact 059 queue elements match')
if a.archives:
 for row in nat['packages']:
  file=a.archives/(row['package']+'.crate');data=file.read_bytes();ck(sha(data)==row['archive_sha256'],'native archive checksum')
  with tarfile.open(file,'r:gz') as tf:
   member=tf.extractfile(row['member']);ck(member is not None and member.read()==(R/row['source_file']).read_bytes(),'native member')
 print('optional native archive/member bytes match')
if a.repo:
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 def git(*args):return subprocess.check_output(['git','-C',str(a.repo),*args],env=env)
 rev='95e63628f9d70b8dd6e6fede64334696c6995009';b111='b111f7444ab7e3b13b2099d5ce9d59f08faf9424';ck(git('rev-parse',rev+'^{tree}').decode().strip()==cap['tree_95e'],'95e tree')
 for row in cap['source_rows']:ck(git('rev-parse',rev+':'+row['path']).decode().strip()==row['blob'] and git('show',rev+':'+row['path'])==(R/('source/'+row['path'].replace('/','__'))).read_bytes(),'Git product source')
 for old,oid in compare['per_file_git_blobs'].items():ck(git('rev-parse',old+':crates/adventuresim-core/src/organization.rs').decode().strip()==oid,'historic file blob')
 ck(sha(git('show',rev+':Cargo.lock'))==nat['cargo_lock_sha256'],'Cargo.lock identity');base=git('show',b111+':BASELINE-95E-20261110.json');ck(sha(base)==cap['b111_baseline_sha256'],'b111 baseline');entries=json.loads(base)['newly_assessed_ledger']['entries']
 for n,row in j(R/'evidence/B111-LEDGER-SUMMARY.json').items():ck(entries[int(n)]['id']==row['id'] and sha(canon(entries[int(n)]))==row['canonical_sha256'],'b111 ledger row')
 for row in j(R/'evidence/CITED-ARCHIVES.json')['rows']:
  data=git('show',b111+':'+row['path']);ck(sha(data)==row['sha256'] and obj('blob',data)==row['git_blob'],'cited archive')
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tf:
   for m in row['comparisons']:
    f=tf.extractfile(m['member']);ck(f is not None and f.read()==(R/'evidence'/m['local']).read_bytes(),'cited report')
 print('optional Git source, ledger, lock and cited reports match')
print('PASS: organization evidence and bounded source displays; no product validation')
