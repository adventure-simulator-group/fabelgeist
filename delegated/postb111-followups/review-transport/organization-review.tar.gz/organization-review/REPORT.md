# Independent organization-only review of central draft v2–v4

**Verdict.** The four selected organization assessments and their three
planning relationships are supported within their stated source limits. My
q2503 wording observation is addressed in v3; two narrower admission
conditions are addressed in v4. I found no remaining material wording issue
in this bounded organization portion. This is a source and evidence review,
not product validation, a new issue count, a ledger change or lens closure.

## Findings and successor corrections

- **q2497, Lens 3:** the validator reads each training weight as f64 and
  requires it to be positive and finite; for a nonempty list, its f64 total
  must be within 0.000001 of one (organization_catalog_validation.rs:594–607,
  650–653). The retained field is f32 (organization.rs:362–367). A value near
  1e-50 is positive in binary64 but below half the least positive binary32
  subnormal. If it remains at that scale until f32 conversion, it can round
  to zero; a 1.0 plus tiny-weight example has a binary64 total rounded to 1.0.
  The specific formatter/parser path, selected dependency features, authored
  occurrence, supported inputs, policy and effects remain unproved. Serde
  source text shows an f64 visitor cast for f32 and a separate serde_json
  `float_roundtrip` branch; no dependency code was run. The childhood producer
  uses unnormalized 0.25 and 0.20 weights (life_simulation.rs:104–125), so the
  catalog sum requirement is not a general TrainingEntry invariant. v4
  correctly adds the nonempty-list condition.
- **q2501, Lens 7:** `StartingProfession` names and its ID mapping
  (organization.rs:258–299) match the independent validator's ten accepted
  names (organization_catalog_validation.rs:389–416); a current mismatch is
  not shown. `StartingAgeTier::roster_size` is the peer's corrected consumer
  name (starting_character.rs:55–59). The separate ten-name coverage condition
  applies only when more than one document is validated (validation.rs:
  657–674), which v4 now states. The q540/ledger842 reward-to-text issue and
  q3450/ledger1105 alternate-instance promotion question have different first
  operations and no automatic alias to the name-list question.
- **q2503, Lens 9:** `Requirement::SkillRating` holds a string skill and
  optional leaf (organization.rs:340–347). The authored validator requires a
  recognized leaf for religion/bestiary and forbids a leaf field for other
  skills (validation.rs:132–173). The selected native `skill_hours` requires
  a recognized leaf for religion/bestiary and ignores the optional leaf for
  ordinary skill arms (stdb-module organization.rs:149–168,195–220). v2 could
  be read as requiring such a leaf for every skill; v3 and v4 make the
  distinction explicit. Supported alternate construction and policy remain
  open. Practice-disabled filtering and the apprenticeship early return do
  not establish q3300's zero-divisor witness; they are not a universal safety
  proof. q2493/ledger445/456 selector ownership and q3300 cadence remain
  related distinct questions.
- **q2504, Lens 10:** the personally displayed organization.rs:1–498 contains
  inherent impls and derives but no handwritten trait implementation to
  replace with a mechanically equivalent derive. No equivalent enum-assoc
  transformation preserving the const API, visibility, IDs and wire shape
  is established. Lines 499–1251, generated code and macros are unassessed.

The v3 organization relationships add conditional classifications and q2493
context without collapsing first operations. The v4 selected organization
relationships match v3, while only q2497's assessment and q2501's limits gain
these two textual conditions. The recorded counts-if-adopted are unchanged;
this check does not independently assess the other five draft assessments.

## Evidence and attribution

The original 059 q2497, q2501, q2503 and q2504 identify the 6533 pr-working
organization.rs:1–498, EOF 1251. Exact selected original/reconstructed element
bytes match; complete queue streams have distinct hashes. The 6533, e275 and
95e source blob is `5effbe40ad10f9f71153c63747ab71509af58da9`, SHA-256
`cb410372fbb5a1f8b61fad2bf447bcd93512725560fb69338ec024ed3135b0e1`;
file identity does not establish a clean historical tree. The earlier Lens 2
supplier was Root, with metadata at f82 and source at 6533; metadata gives no
new fresh/current reading credit. Historical e275 Lens 3 reuse remains
conditional on frozen-source adoption. Missing checkpoint 3821 remains absent.

`wrapped_scope` authored the q2497 and q2501/2503/2504 source packets;
`verifier_scope` authored their independent peer reviews. I independently
registered and displayed the current target 1–498 and selected connected
product and checksum-bound native windows for this draft review. My own earlier
role0057/q3450 source packet is a related underlying input; that authorship
limits independence for that relationship and grants no cross-lens credit.
The prior q2497 and peer failures and corrections remain in their original
packets; this packet also records failed metadata locators and a truncated
metadata listing. An initial v3 diff displayed six non-organization metadata
objects; they were not assessed and no source credit was assigned to them.

Evidence replay verifies content, source windows, history selections and
optional Git/locked-archive dependencies. It cannot verify reader attention,
selected runtime features, product behavior, or intended policy. No product,
macro, parser, fixture, build, test, runtime probe or repair was executed.
