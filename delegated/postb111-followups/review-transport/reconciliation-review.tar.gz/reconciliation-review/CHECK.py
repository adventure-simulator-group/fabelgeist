#!/usr/bin/env python3
"""Read-only check of public review evidence and optional restricted replay."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
def need(x,m):
 if not x:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
try:
 ap=argparse.ArgumentParser();ap.add_argument("--restricted",type=Path);a=ap.parse_args();m=load(P/"MANIFEST.json")
 files={x.relative_to(P).as_posix() for x in P.rglob("*") if x.is_file() and x!=P/"MANIFEST.json"};need(files==set(m["files"]) and not any(x.is_symlink() for x in P.rglob("*")),"file set")
 for n,v in m["files"].items():
  p=P/n;b=p.read_bytes();need(sha(b)==v["sha256"] and len(b)==v["bytes"] and p.stat().st_mode&0o777==v["mode"],"file "+n)
 d=load(P/"DRAFT.json");need(sha((P/"DRAFT.json").read_bytes())=="35c6367cf525f0919968c71873ba6c76804eaf2644da47189699862dae5f83b3","draft")
 d2=load(P/"DRAFT-v2.json");cor=load(P/"DRAFT-CORRECTION-v2.json");need(sha((P/"DRAFT-v2.json").read_bytes())=="3da8b74f6f80481c4e5c4ef153d2da5adceef930d4ff11b75696aea18d54e7de" and cor["predecessor_sha256"]==sha((P/"DRAFT.json").read_bytes()) and cor["successor_sha256"]==sha((P/"DRAFT-v2.json").read_bytes()) and d2["counts_if_adopted"]==d["counts_if_adopted"],"successor draft")
 d3=load(P/"DRAFT-v3.json");d4=load(P/"DRAFT-v4.json");c3=load(P/"DRAFT-CORRECTION-v3.json");c4=load(P/"DRAFT-CORRECTION-v4.json");need(sha((P/"DRAFT-v3.json").read_bytes())=="f35225aaabd5412603d259e1302e5221af144e33904940dfe8ba51641816c74a" and sha((P/"DRAFT-v4.json").read_bytes())=="08722589f73bfddd7df95e77e0183558b7fb2a9120b1a3bfa19d2e2d1c9854db" and c3["predecessor_sha256"]==sha((P/"DRAFT-v2.json").read_bytes()) and c4["predecessor_sha256"]==sha((P/"DRAFT-v3.json").read_bytes()) and d4["counts_if_adopted"]==d3["counts_if_adopted"]==d2["counts_if_adopted"],"v3/v4 drafts")
 qr=load(P/"Q0-REGISTRATION.json");qc=load(P/"Q0-ORIGINAL-CAPTURE.json");need(qr["archive_sha256"]==qc["archive_sha256"]=="312442e1294cfc405cbde54f3b4b9c1d48d8d0d3403068fa2bf16662f079e76b" and qc["report_sha256"]=="e28c2424522bfb8885145ed1f0f484790c25ef49580a659052c62294c309596f" and qc["report_bytes"]==9142,"separate q0 capture identity; exact report restricted")
 for name,k in [("REGISTRATION.json","registration_sha256"),("CAPTURE.json","report_capture_sha256"),("HISTORY-COMPARISON.json","history_comparison_sha256")]:need(sha((P/name).read_bytes())==d[k],"draft input")
 rows=load(P/"FRESH-SOURCE-CAPTURE.json");need(len(rows)==3,"source windows")
 for x in rows:
  b=(P/"views"/x["window"]).read_bytes();need(sha(b)==x["window_sha256"] and len(b.decode().splitlines())==x["lines"][1]-x["lines"][0]+1,"window identity")
 w=load(P/"WEDDING-SOURCE-CAPTURE.json");wb=(P/"views"/w["window"]).read_bytes();need(sha(wb)==w["window_sha256"] and len(wb.decode().splitlines())==w["range"][1]-w["range"][0]+1,"wedding window identity")
 ordinary=load(P/"ORDINARY-LEAF-CAPTURE.json");o=(P/"views"/ordinary["window"]).read_bytes();need(sha(o)==ordinary["window_sha256"],"ordinary leaf view")
 validators=load(P/"VALIDATOR-CONDITIONS-CAPTURE.json");need(len(validators)==2 and all(sha((P/"views"/x["window"]).read_bytes())==x["window_sha256"] for x in validators),"validator views")
 full=False
 if a.restricted:
  r=subprocess.run([sys.executable,"-B",str(a.restricted/"CHECK-CORE-v10.py"),"--public",str(P)],capture_output=True);need(r.returncode==0,"restricted core check "+r.stderr.decode()[:300]);full=True
 print(json.dumps({"result":"pass","files":len(files),"source_windows":len(rows)+4,"restricted_comparison_checked":full,"qualification":"Evidence integrity only; draft prose, product behavior and author attention are not certified."},sort_keys=True))
except Exception as e:print("public check failed:",type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
