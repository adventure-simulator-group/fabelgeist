#!/usr/bin/env python3
import argparse,hashlib,json,pathlib
if not __debug__:raise SystemExit("optimized Python unsupported")
r=pathlib.Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument("--public",type=pathlib.Path);a=p.parse_args();m=json.loads((r/"MANIFEST.json").read_bytes());actual={x.name for x in r.iterdir() if x.is_file() and x.name!="MANIFEST.json"}
if actual!=set(m["files"]):raise RuntimeError("inventory")
for n,x in m["files"].items():
 f=r/n;b=f.read_bytes()
 if f.is_symlink() or hashlib.sha256(b).hexdigest()!=x["sha256"] or len(b)!=x["bytes"] or f.stat().st_mode&0o777!=x["mode"]:raise RuntimeError(n)
d=json.loads((r/"RECEIPT.json").read_bytes())
if a.public and hashlib.sha256((a.public/"MANIFEST.json").read_bytes()).hexdigest()!=d["public_manifest_sha256"]:raise RuntimeError("public binding")
print("PASS: receipt integrity and optional public binding")
