#!/usr/bin/env python3
"""Evidence-only replay; does not import or execute product source."""
import argparse,hashlib,io,json,os,stat,subprocess,sys,tarfile,zlib
from pathlib import Path
if not __debug__:raise SystemExit('optimization prohibited')
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_bytes())
def check(root,name,expected=None):
 b=(root/name).read_bytes();assert expected is None or sha(b)==expected;m=json.loads(b);fs={};ds={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_dir():ds[n]=format(stat.S_IMODE(f.stat().st_mode),'04o')
  elif f.is_file() and n!=name:
   b=f.read_bytes();fs[n]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(f.stat().st_mode),'04o')}
  else:assert n==name
 assert fs==m['files'];assert 'directories' not in m or ds==m['directories']
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();key=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if key==name:return mode,oid
 raise AssertionError('missing tree member')
def history(r):
 info=j(r/'HISTORICAL-GIT-PROOF.json');objs={}
 for oid,m in info['objects'].items():
  b=(r/'historical-git-objects'/(oid+'.zlib')).read_bytes();assert sha(b)==m['stored_sha256'];raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid;head,body=raw.split(b'\0',1);kind,n=head.decode().split(' ');assert kind==m['type'] and len(body)==int(n)==m['size'] and sha(body)==m['sha256'];objs[oid]=(kind,body)
 out={}
 for p in info['proofs']:
  c=objs[p['revision']];assert c[0]=='commit';first=c[1].split(b'\n',1)[0];assert first.startswith(b'tree ');tree=first[5:].decode();trees=[];parts=p['path'].split('/')
  for i,n in enumerate(parts):
   trees.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],n)
   if i<len(parts)-1:assert int(mode,8)==int('40000',8);tree=oid
   else:assert int(mode,8) in (int('100644',8),int('100755',8)) and oid==p['blob'] and objs[oid][0]=='blob';body=objs[oid][1]
  assert [x['tree'] for x in p['chain']]==trees and p['chain'][-1]['child']==oid and sha(body)==p['sha256'] and len(body)==p['bytes'];out[(p['revision'],p['path'])]=body
 assert len(out)==4;return out
def selections(raw,ids):
 t=raw.decode();needle='"entries": [';pos=t.index(needle)+len(needle);dec=json.JSONDecoder();out={}
 for i in range(max(ids)+1):
  while t[pos] in ' \t\r\n,':pos+=1
  start=pos;value,pos=dec.raw_decode(t,pos)
  if i in ids:out[i]=(value,t[start:pos].encode())
 return out
def view(raw,p,lo,hi):
 lines=raw.decode().splitlines();assert 1<=lo<=hi<=len(lines);s=''.join(f'{i:5} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert s==p.read_bytes()
def anchors(a,ref):
 raw=(a/'ANCHOR-MANIFEST.json').read_bytes();assert sha(raw)=='e3262991171c1b8279952062621c01b95803d573fbb4a20cd05cb8b2cc794a2d' and raw==ref.read_bytes();m=json.loads(raw);want={x['file'] for x in m['anchors']}|set(m['support'])|{'ANCHOR-MANIFEST.json'};assert {f.name for f in a.iterdir()}==want and stat.S_IMODE(a.stat().st_mode)==0o700
 for x in m['anchors']:
  f=a/x['file'];assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['source_mode_octal']==x['preserved_mode_octal']
 for n,x in m['support'].items():
  f=a/n;b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['mode_octal']
def strict_delegate(root,expected,count):
 raw=(root/'MANIFEST.json').read_bytes();assert sha(raw)==expected;m=json.loads(raw);actual={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_file() and n!='MANIFEST.json':
   b=f.read_bytes();actual[n]={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(f.stat().st_mode)}
  else:assert f.is_dir() or n=='MANIFEST.json'
 assert actual==m['files'] and len(actual)==count

def archive(root,label,dest,want):
 raw=(root/(label+'.tar.gz')).read_bytes();assert sha(raw)==want;seen=set()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  for x in t:
   path=Path(x.name);assert not path.is_absolute() and '..' not in path.parts and path.parts[0]==label and len(path.parts)>1 and x.isfile() and x.name not in seen;seen.add(x.name);f=dest.joinpath(*path.parts[1:]);assert f.is_file() and not f.is_symlink() and t.extractfile(x).read()==f.read_bytes() and stat.S_IMODE(f.stat().st_mode)==x.mode
 assert seen=={label+'/'+f.relative_to(dest).as_posix() for f in dest.rglob('*') if f.is_file()}

def run(argv):
 z=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','GIT_OPTIONAL_LOCKS':'0'});assert z.returncode==0,z.stderr.decode(errors='replace')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--delegate-private',type=Path);ap.add_argument('--repository',type=Path);a=ap.parse_args();pub=Path(__file__).resolve().parent;check(pub,'MANIFEST.json');print('public manifest: PASS')
 if not a.private:assert not a.delegate_private and not a.repository;print('restricted replay not requested');return
 r=a.private.resolve();check(r,'MANIFEST-PRIVATE.json','9ff8a87a0edc928301d2de598c4be0a79de33bb469502289160da8ea3ea4d794');p=r/'delegate-public';rec=r/'delegate-receipt'
 strict_delegate(p,'5de58041eeb586e806718791f313a880c7e9f97f692a81a41345af62a4c08b6a',169);strict_delegate(rec,'9e44db8d9eefadb97a160eef5313a29a9342f0080fbea02b902e3b2b42707c01',6)
 archive(r,'character-details',p,'153aae1d09d9d5bf77a583d438d0ea78cba5f379cce34ba147e25367e100635f');archive(r,'character-details-receipt',rec,'e51dfc6671960506af42e70e614ae44baa60161ccb9a1cfcb5d139b5befe6cce')
 cmd=[sys.executable,'-B',str(p/'verify.py')]
 if a.delegate_private:cmd+=['--restricted',str(a.delegate_private.resolve())]
 if a.repository:cmd+=['--repository',str(a.repository.resolve())]
 run(cmd);run([sys.executable,'-B',str(rec/'verify.py'),'--public',str(p)])
 if a.delegate_private:
  d=a.delegate_private.resolve();assert sha((d/'PRIVATE-MANIFEST.json').read_bytes())=='f39120ab10781981d16f42ddecdae143871d3178b15d9f95ad531ed76ca45e27';cmd=[sys.executable,'-B',str(d/'verify-private.py'),'--public',str(p),'--receipt',str(rec)]
  if a.repository:cmd+=['--repository',str(a.repository.resolve())]
  run(cmd)
 reg=j(r/'REGISTRATION.json');assert reg['historical_queue']['index']==3368 and reg['historical_queue']['lens']==5 and reg['product_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009';dreg=j(p/'SOURCE-REGISTRATION.json');assert dreg['reviewer'].rsplit('/',1)[-1]=='mhr_character' and any(x['queue']==3368 and x['lens']==5 and x['skill']=='audit-aggregate-states' for x in dreg['assigned_own_lenses'])
 cap=j(r/'SOURCE-CAPTURE.json')['rows'];bind={x['peer_source_id']:x for x in j(r/'SOURCE-BINDING.json')['rows']};count=0;source={}
 for item in cap:
  i=item['id'];spec=reg['source_windows'][i];assert item['path']==spec['path'] and [x['range'] for x in item['views']]==spec['ranges'];b=(r/'sources'/f'{i}.source').read_bytes();source[i]=b;assert sha(b)==item['sha256']==bind[i]['sha256'] and len(b)==item['bytes'] and b==(p/bind[i]['delegate_source_file']).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==bind[i]['git_blob']
  for x in item['views']:
   f=r/x['file'];assert sha(f.read_bytes())==x['sha256'];view(b,f,*x['range']);count+=1
 assert count==12 and j(r/'READ-001.json')['displayed_untruncated']
 sup=j(r/'SUPPLEMENT-003.json')['views'];sr=j(r/'REGISTRATION-003.json');assert [x['range'] for x in sup]==sr['ranges']==[[65,165],[185,225]]
 for x in sup:
  f=r/x['file'];assert sha(f.read_bytes())==x['sha256'];view(source[0],f,*x['range']);count+=1
 assert count==14 and j(r/'READ-003.json')['displayed_untruncated']
 h=history(r);old='56f24f6457f6cec8ffcdc46f03f5ff26a8abb50e';new='dac7d0055716053f245139971eb67ddfd87fa462';q='baseline-059/queue.json';assert sha(h[(old,q)])=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and sha(h[(new,q)])=='3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173' and h[(old,q)]!=h[(new,q)]
 selected={};hist=j(r/'history/SELECTIONS.json')
 for rev,label in ((old,'original-56f'),(new,'reconstructed-dac7d')):
  vals=selections(h[(rev,q)],[192,3368]);selected[label]=vals
  for i in [192,3368]:assert vals[i][1]==(r/f'history/q{i}-{label}.json').read_bytes() and vals[i][0]==hist['rows'][str(i)]['records'][0 if rev==old else 1]
 for i in [192,3368]:assert selected['original-56f'][i][1]==selected['reconstructed-dac7d'][i][1]==(r/f'history/q{i}-published.json').read_bytes()
 q3368=selected['original-56f'][3368][0];identity=q3368['exact_source_identities_and_assessed_ranges'][0];assert q3368['lens']==5 and identity['required_ranges']==[[1,1065]] and identity['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and identity['source_sha256']==sha(source[0])
 q192=selected['original-56f'][192][0];e=q192['exact_source_identities_and_assessed_ranges'][2];assert q192['lens']==11 and e['revision_as_recorded'] is None and e['attribution_as_recorded'] is None
 assert sha((r/'history/early-READ-L11-385.json').read_bytes())=='051770b7513c96ff3e0f8146360e3bf4a68d79485d6d2355e1d3b7712aa4985d' and sha((r/'history/early-READ-L11-391.json').read_bytes())=='0398fa3d0606b40421fea5819ebeea540f55962635af8657b464de028a845582';assert hist['rows']['2378']['records'][0]['contract_id'].startswith('REVIEW-L11-ZIP') and hist['rows']['2397']['records'][0]['contract_id'].startswith('REVIEW-L11-ZIP')
 if a.delegate_private:
  d=a.delegate_private.resolve();hp=d/'historical';whole=[j(hp/n)['entries'] for n in ('queue-original-56f.json','queue-reconstructed-dac7d.json','queue-published.json')]
  for i,record in hist['rows'].items():assert [x[int(i)] for x in whole]==record['records']
  b=(hp/'baseline-committed.json').read_bytes();assert sha(b)=='a402d49eb6dab3cd9182e16db92d2ea91896c761d02c87b2fcdad9d50efa7276';led=json.loads(b)['newly_assessed_ledger']['entries'];assert all(led[int(i)]==x for i,x in hist['ledger'].items())
  for n in ['early-READ-L11-385.json','early-READ-L11-391.json']:assert (hp/n).read_bytes()==(r/'history'/n).read_bytes()
 print('strict transport archives, 14 independent source windows and historic Git-bound selections: PASS')
 print('delegate original and history replayed: '+str(bool(a.delegate_private))+'; external repository tree binding: '+str(bool(a.repository)))
 print('Recorded source and history only; no product behavior, global closure, unique count or independent custody.')
if __name__=='__main__':main()
