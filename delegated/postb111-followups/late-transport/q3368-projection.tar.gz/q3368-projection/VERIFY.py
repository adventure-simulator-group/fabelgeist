#!/usr/bin/env python3
"""Evidence-only replay; does not import or execute product source."""
import argparse,hashlib,io,json,os,stat,subprocess,sys,tarfile,zlib
from pathlib import Path
if not __debug__:raise SystemExit('optimization prohibited')
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_bytes())
def check(root,name,expected=None):
 b=(root/name).read_bytes();assert expected is None or sha(b)==expected;m=json.loads(b);fs={};ds={}
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink();n=f.relative_to(root).as_posix()
  if f.is_dir():ds[n]=format(stat.S_IMODE(f.stat().st_mode),'04o')
  elif f.is_file() and n!=name:
   b=f.read_bytes();fs[n]={'sha256':sha(b),'bytes':len(b),'mode':format(stat.S_IMODE(f.stat().st_mode),'04o')}
  else:assert n==name
 assert fs==m['files'];assert 'directories' not in m or ds==m['directories']
def child(tree,name):
 i=0
 while i<len(tree):
  sp=tree.index(b' ',i);nul=tree.index(b'\0',sp);mode=tree[i:sp].decode();key=tree[sp+1:nul].decode();oid=tree[nul+1:nul+21].hex();i=nul+21
  if key==name:return mode,oid
 raise AssertionError('missing tree member')
def history(r):
 info=j(r/'HISTORICAL-GIT-PROOF.json');objs={}
 for oid,m in info['objects'].items():
  b=(r/'historical-git-objects'/(oid+'.zlib')).read_bytes();assert sha(b)==m['stored_sha256'];raw=zlib.decompress(b);assert hashlib.sha1(raw).hexdigest()==oid;head,body=raw.split(b'\0',1);kind,n=head.decode().split(' ');assert kind==m['type'] and len(body)==int(n)==m['size'] and sha(body)==m['sha256'];objs[oid]=(kind,body)
 out={}
 for p in info['proofs']:
  c=objs[p['revision']];assert c[0]=='commit';first=c[1].split(b'\n',1)[0];assert first.startswith(b'tree ');tree=first[5:].decode();trees=[];parts=p['path'].split('/')
  for i,n in enumerate(parts):
   trees.append(tree);assert objs[tree][0]=='tree';mode,oid=child(objs[tree][1],n)
   if i<len(parts)-1:assert int(mode,8)==int('40000',8);tree=oid
   else:assert int(mode,8) in (int('100644',8),int('100755',8)) and oid==p['blob'] and objs[oid][0]=='blob';body=objs[oid][1]
  assert [x['tree'] for x in p['chain']]==trees and p['chain'][-1]['child']==oid and sha(body)==p['sha256'] and len(body)==p['bytes'];out[(p['revision'],p['path'])]=body
 assert len(out)==4;return out
def selections(raw,ids):
 t=raw.decode();needle='"entries": [';pos=t.index(needle)+len(needle);dec=json.JSONDecoder();out={}
 for i in range(max(ids)+1):
  while t[pos] in ' \t\r\n,':pos+=1
  start=pos;value,pos=dec.raw_decode(t,pos)
  if i in ids:out[i]=(value,t[start:pos].encode())
 return out
def view(raw,p,lo,hi):
 lines=raw.decode().splitlines();assert 1<=lo<=hi<=len(lines);s=''.join(f'{i:5} {lines[i-1]}\n' for i in range(lo,hi+1)).encode();assert s==p.read_bytes()
def anchors(a,ref):
 raw=(a/'ANCHOR-MANIFEST.json').read_bytes();assert sha(raw)=='e3262991171c1b8279952062621c01b95803d573fbb4a20cd05cb8b2cc794a2d' and raw==ref.read_bytes();m=json.loads(raw);want={x['file'] for x in m['anchors']}|set(m['support'])|{'ANCHOR-MANIFEST.json'};assert {f.name for f in a.iterdir()}==want and stat.S_IMODE(a.stat().st_mode)==0o700
 for x in m['anchors']:
  f=a/x['file'];assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['source_mode_octal']==x['preserved_mode_octal']
 for n,x in m['support'].items():
  f=a/n;b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and format(stat.S_IMODE(f.stat().st_mode),'04o')==x['mode_octal']
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path);ap.add_argument('--peer-private',type=Path);ap.add_argument('--peer-public',type=Path);ap.add_argument('--delegate-private',type=Path);ap.add_argument('--repository',type=Path);a=ap.parse_args();pub=Path(__file__).resolve().parent;check(pub,'MANIFEST.json');print('public manifest: PASS')
 if not a.private:assert not any([a.peer_private,a.peer_public,a.delegate_private,a.repository]);print('restricted replay not requested');return
 r=a.private.resolve();check(r,'MANIFEST-PRIVATE.json','c3b116633b46f54fce5bb42aa3ef5c265da7726e43337a2f2d83350605a0cc88');reg=j(r/'REGISTRATION.json');assert reg['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and reg['path']=='crates/adventuresim-stdb-module/src/organization.rs';b=(r/'organization.rs').read_bytes();assert sha(b)==reg['source_sha256'];rows=j(r/'CAPTURE.json')['views'];assert [x['range'] for x in rows]==reg['registered_ranges']==[[1,85],[86,115],[385,455],[456,535]]
 for x in rows:
  f=r/x['file'];assert sha(f.read_bytes())==x['sha256'];view(b,f,*x['range'])
 assert j(r/'READ.json')['displayed_untruncated'] and j(r/'READ.json')['windows']==4
 if a.peer_private or a.peer_public:
  assert a.peer_private and a.peer_public;pp=a.peer_private.resolve();ps=a.peer_public.resolve();assert sha((pp/'MANIFEST-PRIVATE.json').read_bytes())=='9ff8a87a0edc928301d2de598c4be0a79de33bb469502289160da8ea3ea4d794' and sha((ps/'MANIFEST.json').read_bytes())=='52d49c3282b9ec2dc82d6fd236acae3111323925c6cf550cdd95a8618a89b490' and b==(pp/'sources/3.source').read_bytes();cmd=[sys.executable,'-B',str(ps/'VERIFY.py'),'--private',str(pp)]
  if a.delegate_private:cmd+=['--delegate-private',str(a.delegate_private.resolve())]
  if a.repository:cmd+=['--repository',str(a.repository.resolve())]
  z=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','GIT_OPTIONAL_LOCKS':'0'});assert z.returncode==0,z.stderr.decode(errors='replace')
 else:assert not a.delegate_private and not a.repository
 print('Four separately registered source windows: PASS; prior peer replayed: '+str(bool(a.peer_private))+'; delegate history replayed: '+str(bool(a.delegate_private)))
 print('Source evidence only; no product behavior, supported reachability, closure, count or independent custody.')
if __name__=='__main__':main()
