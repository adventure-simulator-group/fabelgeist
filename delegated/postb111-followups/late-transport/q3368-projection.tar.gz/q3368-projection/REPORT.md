# q3368: additive backend membership projection check

This is a separately registered, bounded source-only follow-up to the q3368
Lens 5 peer review at product revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. It retains the original delegate's
and earlier peer's separate attribution.

The backend membership view requires the gateway sender identity and a
matching character-organization role assignment. It copies the stored status
and paid-through minute into the projection without a current-time lookup in
that function (`organization.rs:76–113`). A picker choice still requires a
returned row, a resolvable role and recognized current settlement, as described
in the earlier peer review. These are necessary source conditions, not evidence
that an expired active row occurs in a supported running system.

Separately, `settle_membership_dues` marks lapsed active rows suspended and
reconciles presentations when invoked (`organization.rs:425–444`). Whether
that routine runs before a particular view, whether a qualifying row is
reachable, and whether independently read values share a snapshot remain open.
The web handler, native execution and player-visible behavior were not tested.
This adds no alias decision, unique count, queue or lens closure, repair, build,
test, or runtime probe.

Four windows in `organization.rs` were registered before this peer displayed
them. Their stored bytes bind to the prior peer's proof-backed 95e capture; a
personal display record is an attestation rather than cognitive telemetry. Full
replay requires the separately held prior peer packet, its public verifier and,
for the strongest historical/commit replay, the original delegate collection.
That original is also encrypted in an earlier publication and needs its
separately held same-machine key. The archive's source-root mode and normalized
ownership/timestamps remain qualified. Same-machine custody is not independent
public recoverability; missing checkpoint 3821 remains missing.
