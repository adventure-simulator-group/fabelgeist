#!/usr/bin/env python3
"""Read-only evidence verifier. No product or fixture execution."""
import argparse,hashlib,json,os,pathlib,subprocess
if not __debug__:raise SystemExit('optimized Python is unsupported')
R=pathlib.Path(__file__).resolve().parent
pa=argparse.ArgumentParser();pa.add_argument('--repo',type=pathlib.Path);pa.add_argument('--history',type=pathlib.Path);pa.add_argument('--private',type=pathlib.Path);a=pa.parse_args()
def j(p):return json.loads(p.read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def ck(x,m):
 if not x:raise RuntimeError(m)
def check_manifest(root,name):
 d=j(root/name);fs={str(x.relative_to(root)) for x in root.rglob('*') if x.is_file() and x!=root/name};ck(fs==set(d['files']),'manifest inventory')
 for rel,v in d['files'].items():
  f=root/rel;ck(not f.is_symlink(),'symlink');b=f.read_bytes();ck(sh(b)==v['sha256'] and len(b)==v['bytes'] and f.stat().st_mode&0o777==v['mode'],'manifest '+rel)
check_manifest(R,'MANIFEST.json');cap=j(R/'CAPTURE-RESULT.json');rows=cap['rows'];ck(cap['tree_95e']=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','tree')
for row in rows:
 b=(R/row['file']).read_bytes();oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();ck(sh(b)==row['sha256'] and oid==row['blob'] and len(b.splitlines())==row['EOF'],'source identity')
target='crates/strategic-web/src/routes/dialogue.rs';primary=[x for x in rows if x['path']==target];ck(len(primary)==3 and len({x['blob'] for x in primary})==1 and len({x['sha256'] for x in primary})==1,'per-file equality')
reg=j(R/'SOURCE-REGISTRATION.json');more=j(R/'SOURCE-REGISTRATION-2.json');read=j(R/'SOURCE-READ-RECEIPT.json');registered={}
def add(path,ranges):
 s=registered.setdefault(path,set())
 for lo,hi in ranges:s.update(range(lo,hi+1))
for x in reg['windows']:add(x['path'],x['ranges'])
add(more['path'],more['ranges']);displayed={}
for v in read['views']:
 path=v['path'];lo,hi=v['range'];lines=(R/('source/95e__'+path.replace('/','__'))).read_text().splitlines();b=''.join(f'{n:4} {lines[n-1]}\n' for n in range(lo,hi+1)).encode();actual=(R/v['file']).read_bytes();ck(b==actual and sh(b)==v['sha256'],'display');displayed.setdefault(path,set()).update(range(lo,hi+1))
ck(read['lens']==2 and read['queue']==3354 and read['display_count']==len(read['views'])==25 and displayed==registered,'registered/displayed scope');unread={n for lo,hi in read['target_unread_complement'] for n in range(lo,hi+1)};ck(not unread&displayed[target] and unread|displayed[target]==set(range(1,1898)),'target complement')
h=j(R/'HISTORY-RESULT.json');q=j(R/'history/QUEUE-ORIGINAL.json.selected.json');qmeta=next(x for x in h['queue'] if x['pointer']=='/entries/3354');ck(q['lens']==2 and q['contract_id']=='OBLIGATION-ROOT-L3-EXT-0050-LENS-02' and sh(canon(q))==qmeta['selected_canonical_sha256'],'selected q3354')
if a.private:
 priv=a.private.resolve();check_manifest(priv,'PRIVATE-MANIFEST.json')
 for x in j(R/'RECONSTRUCTION.json')['changes']:
  old=j(priv/x['file']);new=j(R/x['file']);ck(sh((priv/x['file']).read_bytes())==x['private_whole_sha256'] and sh((R/x['file']).read_bytes())==x['public_whole_sha256'],'reconstruction hashes');old[x['field'][1:]]='independent reviewer: mhr_character';ck(old==new,'reconstruction delta')
 ck(j(priv/'prior/ORIGINAL-REVIEWER-PRIVATE.json')['reader']=='/root/wrapped_scope','original reviewer');print('optional restricted originals and redaction match')
if a.history:
 hist=a.history.resolve();ck(sh((hist/'PRIVATE-MANIFEST.json').read_bytes())=='26e9f48a0cbba8de7819a5d86f1299e944cd0ba02c383d188c6fa067cd15c533','history packet identity');od=hist/'history';ob=(od/'QUEUE-ORIGINAL.json').read_bytes();rb=(od/'QUEUE-RECONSTRUCTED.json').read_bytes();bb=(od/'BASELINE-5f6a.json').read_bytes();ck(sh(ob)==h['queue_original_sha256'] and sh(rb)==h['queue_reconstructed_sha256'] and sh(bb)==h['baseline_sha256'],'history full stream identities');oq=json.loads(ob)['entries'];rq=json.loads(rb)['entries'];lb=json.loads(bb)['newly_assessed_ledger']['entries']
 for x in h['queue']:
  i=int(x['pointer'].split('/')[-1]);ck(oq[i]==rq[i] and sh(canon(oq[i]))==x['selected_canonical_sha256'],'history selected queue')
 for x in h['ledger']:
  i=int(x['pointer'].split('/')[-1]);ck(lb[i]['id']==x['id'] and sh(canon(lb[i]))==x['selected_canonical_sha256'],'history selected ledger')
 prior=hist/'prior-originals/reviewer-private';ck(sh((prior/'MANIFEST.json').read_bytes())=='d10d86ab4e8988a917dc00d8eaf149c1ca24872ae61be53ef2b2a1910df01292','prior private manifest');b=(prior/'SOURCE-005-READ.json').read_bytes();ck(sh(b)=='75e09adc8b37c1c92dbd7db1e964a007f2ee3a66742a4bd594b4a6040c81cd61' and json.loads(b)['reader']=='/root/wrapped_scope','prior reviewer')
 frozen=prior/'historical/root-l2-extension-20261030__READ-ROOT-L2-EXT-045-051.json';current=prior/'historical/root-l2-extension-20261030__READ-ROOT-L2-CURRENT-010.json';ck(sh(frozen.read_bytes())=='ccf6822ca663a5db56dd1a452880d81c0ee2e0dff7bd3c0cb6a16bc8e97bd289' and sh(current.read_bytes())=='f145b107d970abd65a6ce35e01cdcaec888c4adc5d6bb32c73b0a5fd26df6a71','root historical receipts');fr=j(frozen)['rows'][2];cr=j(current)['rows'][2];ck(fr['fresh_personal_ranges']==[[1,1897]] and cr['fresh_personal_ranges']==[] and fr['source_sha256']==cr['source_sha256']==primary[0]['sha256'],'historical scope');print('optional 059/ledger/reviewer originals match')
if a.repo:
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 def git(*args):return subprocess.check_output(['git','-C',str(a.repo),*args],env=env)
 ck(git('rev-parse','95e63628f9d70b8dd6e6fede64334696c6995009^{tree}').decode().strip()==cap['tree_95e'],'pinned tree')
 for row in rows:
  ck(git('rev-parse',row['revision']+':'+row['path']).decode().strip()==row['blob'] and git('show',row['revision']+':'+row['path'])==(R/row['file']).read_bytes(),'git revision/source')
 print('optional Git revision and source match')
print('PASS: evidence only; no product validation or lens closure')
