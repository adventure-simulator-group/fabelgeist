# Independent q3354 existing-owner review

**Verdict.** The selected comparisons support the earlier reviewer’s Lens 2
assessment. The ordinary-social duration and ID predicates match at the shown
web and native admissions, but the selected dialogue-action ID accepts a wider
set. Reusing the social ID as the dialogue owner would therefore change the
accepted domain. No product behavior, global owner fit, unique defect count,
queue closure or lens closure is established.

## Scope, attribution and revision

The original 059 `/entries/3354` is
`OBLIGATION-ROOT-L3-EXT-0050-LENS-02`. It specifies the pr-working 6533
`crates/strategic-web/src/routes/dialogue.rs:1–1897`, plus an e275 revisit;
its historical row records pending own-lens proof and zero body credit. Its
selected original and reconstructed objects are equal when parsed, although
their complete queue streams have different hashes. Missing 3821 remains
missing.

The earlier reviewer `wrapped_scope` prospectively registered a full 1–1897
read for four named lenses and retained the per-revision distinctions. Root’s
older Lens 2 receipt records a fresh 6533 read of 1–1897; its e275 receipt
records same-lens reuse and zero fresh current read. Those reads remain theirs.
My earlier q3353 Lens 1 review is separate and supplies no Lens 2 read credit.

For this review, `mhr_character` separately registered and displayed 95e route
lines 1–430, 1259–1318, 1333–1480 and 1684–1757, plus the precise support
windows in SOURCE-READ-RECEIPT.json. Route lines 431–1258, 1319–1332,
1481–1683 and 1758–1897 were not read here. Historical 6533/e275 bodies were
captured for object identity only, without fresh historical displays. The file
is byte-identical at 6533, e275 and 95e: Git blob
`12479288a7088740a84536807f5ab2d08ebc9dd8`, SHA-256
`c3dde45589069173a7b9c0b94f377424e3164e25dbdde70df99cc9d9870d3a56`.
This is per-file identity, not whole-tree identity; the recorded pr-working
snapshot had unrelated changes.

## Owner comparisons and safeguards

- `SocialDuration` and `SocialActionId` already own the selected chat request
  (`routes/dialogue.rs:260–264`; `routes/mod.rs:59–124`). The native social
  reducer revalidates the same 15–480-minute, 15-minute-step and 1–96 ASCII
  alphanumeric/dash/underscore rules (`social.rs:468–487,640–653`). The route
  compares a prior receipt and sends the values across the reducer call
  (`dialogue.rs:1259–1318`). A shared policy owner is a candidate; dependency
  placement, other callers and wire compatibility are open, and authority
  boundaries still require admission.
- The separate native dialogue validator accepts nonempty IDs of at most 100
  bytes, disallowing control characters and colon
  (`dialogue_provenance.rs:292–300`); the answer reducer invokes it
  (`dialogue_prompts.rs:390–401`). For example, a period satisfies that shown
  predicate but the social owner rejects it. No runtime invocation or claim
  about a supported client producing that value is made. The selected
  `DialogueSessionId` and `DialoguePromptRowId` already represent a local
  syntactic parent check before the call (`dialogue.rs:1684–1756`); row
  existence and authority are separate concerns.
- `ResolvedFragment`, `ResolvedTurn`, `SourceRef` and `Choice` already own
  selected semantic data (`adventuresim-dialogue/src/lib.rs:386–431,455–463`;
  `prompt.rs:27–37`). The public `FragmentView`, `ChoiceView` and `EditSource`
  select different fields (`dialogue.rs:314–368`), while database records hold
  JSON text (`dialogue_schema.rs:194–229,351–378`). For instance, `Choice`
  contains effects and result turns whereas `ChoiceView` presents ID, label and
  an optional source. Wholesale substitution would alter the serialized shape;
  compatibility and intended disclosure need separate policy review.

The historical q227/5f6a ledger123 concerns `SocialActionKind`, not the
`SocialActionId` comparison. The five field-specific JSON decode fallbacks in
q461–q465 and 5f6a ledger758–762 remain separate historical relationships;
malformed-row reach and recovery policy remain open. Neither relation is
assigned a new count or alias here.

## Evidence and limits

The private packet and public transport reference exact prior immutable queue,
ledger and reviewer packets by manifest identity instead of copying large
archives. The original reviewer recorded failed locators, an exact-ID lookup
failure, and a truncated client display followed by registered smaller views;
those remain in the referenced original packet. This review used source text
and evidence checks only. Its replay verifies selected bytes, registrations,
read scope, source object hashes and optional prior/Git dependencies; it does
not validate semantic conclusions, reachability or product behavior.
