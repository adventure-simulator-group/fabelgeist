#!/usr/bin/env python3
"""Replay the bounded evidence review from separately held private bytes."""
import argparse, hashlib, importlib.util, json, os, pathlib, stat, subprocess, sys
if sys.flags.optimize:
    raise RuntimeError('Evidence assertions require an unoptimized interpreter')
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--private',required=True,type=pathlib.Path);p.add_argument('--git-checkout',type=pathlib.Path);a=p.parse_args();r=a.private
sha=lambda v:hashlib.sha256(v).hexdigest()
def require(value,message):
 if not value:raise ValueError(message)
def load(name):return json.loads((r/name).read_bytes())
manifest_bytes=(r/'PRIVATE-MANIFEST.json').read_bytes()
require(sha(manifest_bytes)=='0d41fe1f932e4666d8923b264a37bd5c45e72fd0bb303ddebbd4c7b9b6387587','private manifest identity')
manifest=json.loads(manifest_bytes);expected=set()
for item in manifest['files']:
 rel=pathlib.PurePosixPath(item['path']);require(not rel.is_absolute() and '..' not in rel.parts,'unsafe manifest entry')
 f=r.joinpath(*rel.parts);require(f.is_file() and not f.is_symlink(),'missing/nonregular evidence')
 raw=f.read_bytes();require(len(raw)==item['bytes'] and sha(raw)==item['sha256'],'evidence byte mismatch')
 expected.add(item['path'])
actual={f.relative_to(r).as_posix() for f in r.rglob('*') if f.is_file() and f.name!='PRIVATE-MANIFEST.json'}
require(expected==actual,'private file set differs')
name='TRANSFORM.py';spec=importlib.util.spec_from_file_location('evidence_transform_v1',r/name);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
before={n:(r/('BEFORE-'+n)).read_bytes() for n in m.NAMES};draft=(r/'DRAFT-v4.json').read_bytes();report=load('SYNTHETIC-UNADOPTED-REPORT.json');observation=load('MAIN-OBSERVATION.json')
require('SYNTHETIC PRIVATE EXERCISE ONLY; NOT ADOPTED' in report['adoption_qualification'],'synthetic report qualification')
out=m.transform(before,draft,report,observation)
require(all(out[n]==(r/'UNADOPTED-output-original'/n).read_bytes()==(r/'UNADOPTED-output-repeat'/n).read_bytes() for n in m.NAMES),'deterministic output bytes')
q=json.loads(before[m.NAMES[2]]);newq=json.loads(out[m.NAMES[2]]);base=json.loads(before[m.NAMES[0]]);newbase=json.loads(out[m.NAMES[0]])
ids=[0,19,2497,2501,2503,2504,2510,2521,2534];lenses=[8,11,3,7,9,10,4,3,4];d=json.loads(draft)
require([x['index'] for x in d['assessments']]==ids and [x['lens'] for x in d['assessments']]==lenses,'selected ids/lenses')
require(len(q['entries'])==len(newq['entries'])==3713,'queue length')
require(sum(x['current_reconciliation'].startswith('partial') for x in q['entries'])==1370 and sum(x['current_reconciliation']=='unassessed' for x in q['entries'])==2343,'before counts')
require(sum(x['current_reconciliation'].startswith('partial') for x in newq['entries'])==1379 and sum(x['current_reconciliation']=='unassessed' for x in newq['entries'])==2334,'after counts')
require(all(q['entries'][i]==newq['entries'][i] for i in range(3713) if i not in ids),'untouched queue rows')
old=base['newly_assessed_ledger']['entries'];new=newbase['newly_assessed_ledger']['entries'];require(len(old)==1106 and len(new)==1115 and old==new[:1106],'ledger preserved prefix')
oq=load('ORIGINAL-QUEUE.json');rq=load('RECONSTRUCTED-QUEUE.json'); selected=set(ids)
for relation,row in zip(d['proposed_ledger_relationships'],new[1106:]):
 selected.update(relation['queue']);require(row['id']==relation['id'],'relationship identity')
 require(row['historical_related_records']==['baseline-059/queue.json#/entries/'+str(i) for i in relation['queue']],'historical pointers')
 require(row['current_related_records']==['BASELINE-95E-20261110.json#/newly_assessed_ledger/entries/'+str(i) for i in relation['ledger']],'current pointers')
require(all(oq['entries'][i]==rq['entries'][i] for i in selected),'selected history equality')
response=load('MAIN-CONNECTOR-RESPONSE.json');main=json.loads(response['main']['structuredContent']['content']);branch=json.loads(response['branch']['structuredContent']['content'])
require(sha((r/'MAIN-CONNECTOR-RESPONSE.json').read_bytes())==observation['serialized_joint_response_sha256'],'main response hash')
require(main['commit']['sha']==observation['observed_revision'] and main['commit']['commit']['tree']['sha']==observation['observed_tree'],'main commit/tree')
require(response['before']==observation['before_utc'] and response['after']==observation['after_utc'] and branch['commit']['sha']==m.PARENT,'connector time/branch')
negative=subprocess.run([sys.executable,'-O','-B',str(r/name)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
require(negative.returncode!=0 and b'Evidence assertions require an unoptimized interpreter' in negative.stderr,'optimization guard')
mode='not rechecked'
if a.git_checkout:
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
 def git(*args):
  p=subprocess.run(['git',*args],cwd=a.git_checkout,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  require(p.returncode==0,'Git read failed');return p.stdout
 for n in m.NAMES:require(git('show',m.PARENT+':'+n)==before[n],'parent Git snapshot')
 for apath in {e for x in d['assessments'] for e in x['evidence']}:git('cat-file','-e',m.PARENT+':'+apath)
 hist=load('HISTORICAL-BASELINE.json')['historical_checkpoint_059'];commit=hist['commit']
 require(sha(git('show',commit+':'+hist['queue_path']))==sha((r/'ORIGINAL-QUEUE.json').read_bytes()),'original Git queue')
 require(sha(git('show',commit+':'+hist['ledger_path']))==sha((r/'ORIGINAL-LEDGER.json').read_bytes()),'original Git ledger')
 for n,path in [('RECONSTRUCTED-QUEUE.json','baseline-059/queue.json'),('RECONSTRUCTED-LEDGER.json','baseline-059/ledger.json')]:require(sha(git('show',m.PARENT+':'+path))==sha((r/n).read_bytes()),'reconstructed Git input')
 mode='verified against supplied Git objects'
print(json.dumps({'result':'pass','private_files':len(expected),'synthetic_unadopted':True,'original_queue_ids':len(selected),'old_ledger_rows_preserved':len(old),'git_binding':mode,'optimization_guard':'verified','qualification':'source-only, structural, same-machine evidence replay; no product execution or independent underlying authorship'},sort_keys=True))
