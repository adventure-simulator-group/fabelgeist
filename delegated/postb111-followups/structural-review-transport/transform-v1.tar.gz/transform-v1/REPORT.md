# Evidence transform v1: bounded structural review

The unmodified v1 evidence transform replayed successfully with a private,
explicitly synthetic and unadopted report. It selected the nine intended
historical records and lenses, changed their current states from unassessed to
partial, and preserved every other queue row and every preexisting ledger row
as parsed values. The queue counts changed from 1,370 partial / 2,343
unassessed to 1,379 / 2,334; the ledger grew from 1,106 to 1,115 entries.
No semantic queue or lens closure, accepted unique-defect increment, repair,
or product validation is implied. Product behavior was not executed or
validated.

The nine appended relationships resolve their recorded historical queue and
current ledger pointers in the captured b111 parent. The q0 qualification
names q61 and links ledger row 217, but v1 omits a direct q61 queue pointer.
This is a navigation observation; a later draft adds the pointer separately.
Foreign-lens historical relationships were not credited as new reads. The
reviewer authored the q0, q2510 and q2534 source packets and independently
reviewed several other packets, so this is a fresh structural review, not a
claim of independent underlying source authorship or a new semantic review.

The separately captured original 059 and reconstructed queue and ledger
streams have their respective expected hashes; selected queue records compare
equal as parsed values while the whole original and reconstructed streams
have different bytes. The original 059 is evidence of its own checkpoint,
not the missing checkpoint 3821. The normalized 774 catalog, missing
pre-export originals, SOURCE004 and 73 nontext/no-positive-EOF obligations
remain qualified in the draft. No historical body or lens credit is
transferred here.

The captured connector response's hash, main commit and tree, observation
interval, and publication branch commit match the staged observation and
parent. This was a point-in-time observation, not a fresh remote check; a
separate invocation or HTTP-verb transcript was not captured. The preceding
141-path recovery record is a same-machine receipt and does not prove
independent custody. The separately held key, historical Git objects, q2812
anchors and earlier ciphertexts remain dependencies of broader recovery.

The v1 transform rejects optimized Python. It does not itself validate the
contents of the independent-review and adoption-qualification fields, nor
bind the complete connector-response bytes; the private synthetic input used
an empty review list and passed. A final wrapper must bind the actual reviewed
report, reviewers and observation bytes before any adoption. The synthetic
literal status is required only by the function's input schema; neither that
input nor its output was adopted.

The reviewer first reported a spurious unary-plus blocker after misreading a
line break, then immediately corrected it after replay; the unchanged v1
succeeded. An initial reviewer checker also failed on a case-sensitive search
for the checkpoint text; its separately preserved successor passed. The
original notes, errors and corrected receipts remain in restricted evidence.

Run `python3 -B VERIFY.py --private PRIVATE_COLLECTION --git-checkout
EVIDENCE_GIT_CHECKOUT` for the strongest same-machine replay. The Git option
checks the parent files and evidence paths as well as the original and
reconstructed historical blobs; omit it only for the explicitly limited
snapshot replay. The complete private collection and its manifest are held
separately; the public verifier alone is not independent recovery custody.
