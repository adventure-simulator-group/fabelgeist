# Evidence transform successors and candidate review

The v2, v3 and v4 evidence transforms replayed successfully against captured
parent inputs with explicitly synthetic, unadopted reports. The v4 replay
rejects empty reviews, changed review identities or transport pointers, empty
qualifications, changed observation identities, changed draft bytes and
optimized Python. The three staged review/receipt transport pairs match their
recorded archives, members, modes and six manifest identities. These checks
verify evidence structure and selected identities; they do not prove source
reachability, runtime behavior, policy or independent custody.

The uninstalled candidate's report has SHA-256
`34433b69bbcbdc1df8fb816deb96a156501fe4a2d5a55761fc4b84dc063df434`.
Its four after-images exactly match a separate v4 transform replay. All 1,106
prior ledger rows and the 3,704 unselected queue rows are preserved as parsed
values. Nine selected records become partial; the queue counts are 1,379
partial and 2,334 unassessed, and the ledger has 1,115 entries. No semantic
queue or lens closure, accepted unique-defect increment, repair or product
validation follows. The candidate remains uninstalled: the report's literal
adoption status is a prospective input to the candidate, not proof of
publication.

Draft v5 adds q61 as a direct historical pointer on the already qualified q0
relationship. Original and reconstructed q61 records agree as parsed, and its
Lens 11 preparation/readiness identity matches existing ledger row 217. This
is a related but distinct question; it does not establish an alias or new
finding. The original 059 and reconstructed streams retain different whole
identities; missing checkpoint 3821, normalized 774, pre-export originals,
SOURCE004 and the 73 nontext/no-positive-EOF obligations remain qualified.

V2 adds bindings for the reconciliation and organization review identities and
the main observation. V3 changes the draft hash and schema to v5; v4 adds the
navigation review identity. The v4 directory retains a bootstrap that derives
v3 from v2 and does not regenerate the v4 navigation assertions. Preserve the
exact v4 transform bytes or supply a separately verified derivation. The final
wrapper must bind the actual report, all transport archives, captured
connector response and parent before-images; the transform alone cannot
establish independent custody or verify reader attention.

The reviewer authored the q0, q2510 and q2534 source packets and several
separate peer reviews. This work is a fresh structural check, not independent
authorship of those source packets. The reconciliation, organization and
navigation reviewers' own bounded scopes and prior overlaps remain recorded in
the candidate and their separately attributed packets.

An initial private successor checker incorrectly treated declared archive
directories as files; its corrected successor passed. An initial candidate
checker searched for a wording that was not literally in the report; its
corrected successor checked the actual sentence and passed. Both failures,
corrections and complete receipts remain in restricted evidence. The earlier
v1 review also preserves its corrected unary-plus false alarm.

For the strongest same-machine replay run `python3 -B VERIFY.py --private
SUCCESSOR_COLLECTION --prior V1_COLLECTION --git-checkout EVIDENCE_GIT_CHECKOUT`.
The prior restricted collection, historical Git objects, separately held keys
and prior encrypted archives remain dependencies. Omitting the Git option
limits the result to captured snapshots. No product code, tests, builds,
fixtures, repairs or runtime probes were executed.
