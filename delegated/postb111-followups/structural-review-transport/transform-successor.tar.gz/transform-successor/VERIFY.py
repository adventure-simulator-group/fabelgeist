#!/usr/bin/env python3
"""Read-only evidence replay; the supplied candidate remains uninstalled."""
import argparse,copy,hashlib,importlib.util,json,os,pathlib,subprocess,sys,tarfile
if sys.flags.optimize:raise RuntimeError('Evidence assertions require an unoptimized interpreter')
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--private',required=True,type=pathlib.Path);p.add_argument('--prior',required=True,type=pathlib.Path);p.add_argument('--git-checkout',type=pathlib.Path);a=p.parse_args();r=a.private;prior=a.prior
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
def check_manifest(root,expected):
 raw=(root/'PRIVATE-MANIFEST.json').read_bytes();require(sha(raw)==expected,'private manifest identity');m=json.loads(raw);names=set()
 for f in m['files']:
  rel=pathlib.PurePosixPath(f['path']);require(not rel.is_absolute() and '..' not in rel.parts,'manifest path');p=root.joinpath(*rel.parts);require(p.is_file() and not p.is_symlink(),'private file type');b=p.read_bytes();require(len(b)==f['bytes'] and sha(b)==f['sha256'],'private file identity');names.add(f['path'])
 require(names=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='PRIVATE-MANIFEST.json'},'private file set');return len(names)
count=check_manifest(r,'c48bbbf67a873d589c0ab38b35b20f8d9aafc456bb4622d646684d6e848a4c31');oldcount=check_manifest(prior,'0d41fe1f932e4666d8923b264a37bd5c45e72fd0bb303ddebbd4c7b9b6387587')
def load(n):return json.loads((r/n).read_bytes())
def module(v):
 sp=importlib.util.spec_from_file_location('evidence_successor_'+str(v),r/('TRANSFORM-v'+str(v)+'.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
expected={}
for group in ['review-transport','navigation-review-transport']:
 for bundle in load(group+'--MANIFEST.json')['bundles']:
  path=r/(group+'--'+bundle['file']);raw=path.read_bytes();require(len(raw)==bundle['archive_bytes'] and sha(raw)==bundle['archive_sha256'],'transport archive identity')
  with tarfile.open(fileobj=__import__('io').BytesIO(raw),mode='r:gz') as t:
   mem=t.getmembers();require(len(mem)==len({x.name for x in mem}),'duplicate archive member');members={m.name:m for m in mem};require(set(members)=={x['path'] for x in bundle['members']},'archive member set')
   for f in bundle['members']:
    m=members[f['path']];rel=pathlib.PurePosixPath(m.name);require(not rel.is_absolute() and '..' not in rel.parts and oct(m.mode)==f['mode'],'archive path or mode')
    if f['type']=='directory':require(m.isdir(),'archive directory type')
    elif f['type']=='file':
     require(m.isfile(),'archive file type');data=t.extractfile(m).read();require(len(data)==f['bytes'] and sha(data)==f['sha256'],'archive file identity')
    else:raise ValueError('unsupported archive type')
   payload=t.extractfile(members[bundle['manifest_member']]).read();require(sha(payload)==bundle['source_manifest_sha256'],'embedded review manifest');expected[bundle['label']]=sha(payload)
for v in [2,3,4]:
 m=module(v);draft=(r/('DRAFT-v4.json' if v==2 else 'DRAFT-v5.json')).read_bytes();report=load('SYNTHETIC-UNADOPTED-REPORT-v'+str(v)+'.json');obs=load('MAIN-OBSERVATION.json');before={n:(r/(('V3-BEFORE-' if v in [2,3] else 'V4-BEFORE-')+n)).read_bytes() for n in m.NAMES}
 require('not adopted' in report['adoption_qualification'].lower(),'synthetic qualification');out=m.transform(before,draft,report,obs)
 require(all(out[n]==(r/('SYNTHETIC-UNADOPTED-OUTPUT-v'+str(v))/n).read_bytes() for n in m.NAMES),'synthetic replay')
 altered=copy.deepcopy(report);altered['independent_reviews']={}
 try:m.transform(before,draft,altered,obs)
 except (AssertionError,KeyError,TypeError):pass
 else:raise ValueError('empty review accepted')
 p=subprocess.run([sys.executable,'-O','-B',str(r/('TRANSFORM-v'+str(v)+'.py'))],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'));require(p.returncode and b'Evidence assertions require an unoptimized interpreter' in p.stderr,'optimization guard')
m=module(4);draft=(r/'DRAFT-v5.json').read_bytes();report=load('CANDIDATE--root--ASSESSMENT-CENTRAL-FOLLOWUPS-21-95E.json');obs=load('CANDIDATE--root--MAIN-RECHECK-20261113-0655.json');meta=load('CANDIDATE--CANDIDATE.json');before={n:(r/('V4-BEFORE-'+n)).read_bytes() for n in m.NAMES}
require(meta['status']=='candidate only; not installed or published','candidate status');require(meta['report_sha256']=='34433b69bbcbdc1df8fb816deb96a156501fe4a2d5a55761fc4b84dc063df434' and sha((r/'CANDIDATE--root--ASSESSMENT-CENTRAL-FOLLOWUPS-21-95E.json').read_bytes())==meta['report_sha256'],'candidate report')
for who in ['reconciliation','organization','navigation']:
 x=report['independent_reviews'][who];require(x['public_manifest_sha256']==expected[who+'-review'] and x['receipt_manifest_sha256']==expected[who+'-receipt'] and x['qualification'],'review bindings')
out=m.transform(before,draft,report,obs)
for n in m.NAMES:
 raw=(r/('CANDIDATE--after--'+n)).read_bytes();require(raw==out[n] and sha(raw)==meta['after'][n]['sha256'] and len(raw)==meta['after'][n]['bytes'],'candidate after replay')
b0=json.loads(before[m.NAMES[0]])['newly_assessed_ledger']['entries'];b1=json.loads(out[m.NAMES[0]])['newly_assessed_ledger']['entries'];q0=json.loads(before[m.NAMES[2]])['entries'];q1=json.loads(out[m.NAMES[2]])['entries'];ids=[0,19,2497,2501,2503,2504,2510,2521,2534]
require(len(b0)==1106 and len(b1)==1115 and b0==b1[:1106],'preexisting ledger');require(all(q0[i]==q1[i] for i in range(3713) if i not in ids),'preexisting queue');require('baseline-059/queue.json#/entries/61' in b1[1106]['historical_related_records'],'direct q61 pointer')
orig=json.loads((prior/'ORIGINAL-QUEUE.json').read_bytes());recon=json.loads((prior/'RECONSTRUCTED-QUEUE.json').read_bytes());require(orig['entries'][61]==recon['entries'][61] and orig['entries'][61]['contract_id']=='ADLER-L11-RUNTIME-EQUIPMENT-FAILURE-OWNERSHIP' and orig['entries'][61]['lens']==11,'q61 historical identity')
git_binding='not rechecked'
if a.git_checkout:
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
 def git(*args):
  x=subprocess.run(['git',*args],cwd=a.git_checkout,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);require(x.returncode==0,'Git object read');return x.stdout
 for n in m.NAMES:require(git('show',m.PARENT+':'+n)==before[n],'parent Git file')
 for path in {e for z in json.loads(draft)['assessments'] for e in z['evidence']}:git('cat-file','-e',m.PARENT+':'+path)
 h=json.loads((prior/'HISTORICAL-BASELINE.json').read_bytes())['historical_checkpoint_059']
 for n,k in [('ORIGINAL-QUEUE.json','queue_path'),('ORIGINAL-LEDGER.json','ledger_path')]:require(sha(git('show',h['commit']+':'+h[k]))==sha((prior/n).read_bytes()),'historical Git object')
 git_binding='verified against supplied Git objects'
print(json.dumps({'result':'pass','successor_private_files':count,'prior_private_files':oldcount,'versions':[2,3,4],'review_manifest_pairs':3,'candidate_after_files':4,'old_ledger_rows':len(b0),'unselected_queue_rows':len(q0)-len(ids),'q61_pointer':True,'candidate_uninstalled':True,'git_binding':git_binding,'qualification':'source-only structural same-machine replay; no independent custody or product validation'},sort_keys=True))
