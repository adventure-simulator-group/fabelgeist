#!/usr/bin/env python3
"""Read-only verification of this review and optional named evidence inputs."""
import argparse,hashlib,json,stat,sys
from pathlib import Path
if sys.flags.optimize:raise RuntimeError("unoptimized interpreter required")
p=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument("--stage",type=Path);ap.add_argument("--restricted",type=Path);ap.add_argument("--history",type=Path);a=ap.parse_args()
sha=lambda b:hashlib.sha256(b).hexdigest()
def inventory(root,manifest,exclude):
 m=json.loads((root/manifest).read_bytes()); files={x.relative_to(root).as_posix() for x in root.rglob("*") if x.is_file() and x!=root/exclude}
 if files!=set(m["files"]):raise RuntimeError("inventory mismatch")
 for rel,row in m["files"].items():
  q=root/rel
  if q.is_symlink():raise RuntimeError("symlink")
  b=q.read_bytes()
  if len(b)!=row["bytes"] or sha(b)!=row["sha256"] or stat.S_IMODE(q.stat().st_mode)!=row["mode"]:raise RuntimeError("file identity mismatch")
inventory(p,"MANIFEST.json","MANIFEST.json");checks=["public packet"]
if a.stage:
 expected={'application/VERIFY.py': {'bytes': 7885, 'sha256': 'bdf933b6727b96749c71eeded6fd104979c6f98a8f14009ce0b6f94d0f945a4d'}, 'application/TRANSFORM.py': {'bytes': 13288, 'sha256': 'df135f3401e2a53cc765d5b068cec8d303cff04f4899624fe9d1f14bcaa6db05'}, 'application/RECORD.json': {'bytes': 3896, 'sha256': '03e8ca0a902c09844b8f80795ef2d9b2af1dd4070f1bad3a3184bba397f95e42'}, 'application/ADOPTION-CANDIDATE.json': {'bytes': 1367, 'sha256': '358cbc9a5fd8b9bad18c04277c7ace05634567843bace0c2b27b21e6c817d360'}, 'application/APPLICATION-EVIDENCE.tar.gz': {'bytes': 786665, 'sha256': '4bc8d7ec4433d25a210a491be00313f8999b1c7850400e61fd98dba2171e29a2'}, 'VERIFY.py': {'bytes': 5409, 'sha256': 'cf936d5045935d48bb36c50954a31561fc0fd6ed7ffb074c55df14699b2b1730'}, 'REMOTE-RECOVERY.json': {'bytes': 2970, 'sha256': 'bcef93fe7b3087b99fdbe91122a7d2c459d6162f90371f904c2bb71fe0df15ba'}, 'reconciliation-v5/DRAFT-v5.json': {'bytes': 19076, 'sha256': '1212f4f29a5dbf2ed6d4faff7788d9df13ed744a69b7c7c1262548d3899d1fef'}, 'review-transport/MANIFEST.json': {'bytes': 35146, 'sha256': 'ba57b9c5e66973929c20f34476198bab8b56142f69b814f1e8ab4cb0baaebc87'}, 'review-transport/VERIFY.py': {'bytes': 1682, 'sha256': '3ad1fb43f168814249a50baa4bd864eef618252284286e3bd431b46bf8fce873'}, 'review-transport/reconciliation-review.tar.gz': {'bytes': 23636, 'sha256': '31bef48a161aa90f0e99df4011978e364c1d61b5ba53a80781ded65a3a869786'}, 'review-transport/reconciliation-receipt.tar.gz': {'bytes': 2172, 'sha256': '8df180ffc315ff09d41fec1480d74dd7e98a50e0326d32e17bea83c542ea5ec6'}, 'review-transport/organization-review.tar.gz': {'bytes': 145654, 'sha256': 'a1ae36aadb8d87b5f4d3e9c70868b6e50b7d86306e2b07999f7027e965139f93'}, 'review-transport/organization-receipt.tar.gz': {'bytes': 1757, 'sha256': '26894ba97dc67a87eb04fa32d9ab2fc0339cb2155db5a2d1df0460dbd74d1e6c'}, 'navigation-review-transport/MANIFEST.json': {'bytes': 4604, 'sha256': '97841572d4cbcf2c8424b280074826492e5561f29328ee3577b3163186a95b86'}, 'navigation-review-transport/VERIFY.py': {'bytes': 1682, 'sha256': '3ad1fb43f168814249a50baa4bd864eef618252284286e3bd431b46bf8fce873'}, 'navigation-review-transport/navigation-review.tar.gz': {'bytes': 9886, 'sha256': '4905191344649f6811adeb56098ee07674ccca1bd371560cb97dd5421550a578'}, 'navigation-review-transport/navigation-receipt.tar.gz': {'bytes': 2129, 'sha256': 'c87e4894bcb9408a099e2852bd9ca0024a71754f3c4b47ea2a513d709462f9ff'}}
 for rel,row in expected.items():
  b=(a.stage/rel).read_bytes()
  if len(b)!=row["bytes"] or sha(b)!=row["sha256"]:raise RuntimeError("stage identity mismatch")
 readme=(a.stage/"application/README.md").read_bytes();rh=sha(readme)
 if rh not in ("e201be7f0c8fb7880d3bf60200f3396103de2c3ce0edfd69ebb6b73e3d6e4cfd","8e00ea8a23cd48623c8a5ed3d32219afd438a52e2c379e3f772f3bff64a5387a"):raise RuntimeError("unknown README")
 if rh.startswith("8e00"):
  raw=(a.stage/"application/README-CORRECTION.json").read_bytes()
  if sha(raw)!="ada7f2c1c78bbd595894ad9ddb611337f3ede43903c454441d366d2d14b1fd45":raise RuntimeError("README correction mismatch")
 checks.append("captured stage identities and known README")
if a.restricted:
 if sha((a.restricted/"PRIVATE-MANIFEST.json").read_bytes())!="8d75ab22a43213817b023a4e0c486bbc413abaca045324dfe6ad56332a2422e8":raise RuntimeError("restricted manifest mismatch")
 inventory(a.restricted,"PRIVATE-MANIFEST.json","PRIVATE-MANIFEST.json");checks.append("restricted review inventory")
if a.history:
 original=(a.history/"QUEUE-ORIGINAL.json").read_bytes(); reconstructed=(a.history/"QUEUE-RECONSTRUCTED.json").read_bytes()
 if sha(original)!="2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08" or sha(reconstructed)!="3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173":raise RuntimeError("history identity")
 x=json.loads(original)["entries"];y=json.loads(reconstructed)["entries"]
 ids=[0,19,2497,2501,2503,2504,2510,2521,2534]; lenses=[8,11,3,7,9,10,4,3,4]
 if any(x[i]!=y[i] or x[i]["lens"]!=lens for i,lens in zip(ids,lenses)):raise RuntimeError("history selection mismatch")
 checks.append("selected history equality; full streams distinct")
print(json.dumps({"checks":checks,"limits":"No product behavior, independent custody, decryption, closure or whole-stream historical equality is established."},indent=2))
