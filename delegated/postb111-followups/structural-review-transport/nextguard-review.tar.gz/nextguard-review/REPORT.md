# Independent checkpoint-guard review

This is an evidence-tooling and data review of the b111 successor candidate,
not a product validation or an adoption decision. The reviewer previously
authored the q0 peer, the q2497 and q2501/q2503/q2504 source packets, and the
v4/v5 reconciliation reviews. Independence is from the coordinator's current
structural proposal, not from every underlying packet or source trace.

The archived 17-member application evidence independently matched four b111
Git before-images, four candidate after-images and two candidate new root
files. Exactly q0, q19, q2497, q2501, q2503, q2504, q2510, q2521 and q2534
changed; the 1,106 old ledger entries are equal as parsed, with nine planning
relationships appended. The ledger is not a unique-defect count. Repair and
product validation remain not started/not performed; no queue item or lens is
closed by these changes.

The captured stage guard `VERIFY.py` and `application/VERIFY.py` were each
run in candidate-time, evidence-only mode and both passed. The former does not
invoke the latter. The application check used `--candidate`, with no separate
predecessor run: the latter's clean b111 HEAD and tree were observed separately
at one point in time, but its transitive snapshot-specific verifiers were not
rerun in this review. Neither candidate replay verifies installed-root state.
The application archive is bound by SHA-256
`4bc8d7ec4433d25a210a491be00313f8999b1c7850400e61fd98dba2171e29a2`;
the captured stage and application guard script identities are
`cf936d5045935d48bb36c50954a31561fc0fd6ed7ffb074c55df14699b2b1730` and
`bdf933b6727b96749c71eeded6fd104979c6f98a8f14009ce0b6f94d0f945a4d`.

The captured stage guard checked some remote-recovery receipt fields but did
not bind its full identity, all check names, or the logged outputs. The new
separate log-binding record identifies the exact receipt and reports a match
of 16 logs to authenticated same-machine restored evidence. That binding was
not yet invoked by the captured guard. The coordinator plans an additive
final guard that pins it and the full primary-restoration receipt. These are
recorded and planned checks, not independent custody or a fresh remote fetch.

The inspected installer v1 checks the destination's exact parent, tree and
clean worktree, four Git before-images, candidate target identities, and absent
new and temporary paths. It was not executed. It does not pin the complete
staged tree or itself run post-install guards, and its copy and replacements
are sequential without rollback. An interrupted or failed invocation can leave
an uncommitted partial installation. Capture the invocation's exit and output
as well as its action log: precondition failures occur before that log opens.
The coordinator plans a separately captured complete stage manifest and an
installer successor that checks it before and after copying. Those successors
are outside this sealed review.

The recorded primary restoration covers 42 collections and separately
qualifies an earlier delegate restore. Its key, earlier ciphertext, pinned Git
objects, q2812 anchors and nested keys are separately held dependencies. The
no-key guard checks encrypted payload identities; it does not decrypt or
restore. A supplemental recovery group was still being sealed during this
review and is not independently assessed here. Do not conflate these groups or
infer recovery of missing original checkpoint 3821. Original 059 material,
reconstructions, summaries, readers and revisions retain their qualifications.

The restricted packet preserves the exact reviewed evidence-tool snapshots,
comparison inputs, outputs, registration and failures. Its manifest SHA-256 is
`e4036fb93f000d0be24932500105e83aa029048db9e06787e4d4bfc413e51d12`;
the separately held replay receipt manifest is
`e7628b28e3575e8f888a8639c68c67dba0d3e3461751ec943d5ce55dafe76f8a`.
A portable replay and an optional Git-object replay passed. These public bytes
alone do not recover the restricted originals, keys or external anchors.
