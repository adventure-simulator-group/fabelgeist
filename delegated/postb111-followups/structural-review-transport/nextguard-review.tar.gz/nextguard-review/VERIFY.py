#!/usr/bin/env python3
"""Verify public report identities; does not establish its factual claims."""
from pathlib import Path,PurePosixPath
import hashlib,json,stat,sys
if sys.flags.optimize: raise RuntimeError('Assertions require an unoptimized interpreter')
p=Path(__file__).resolve().parent;m=json.loads((p/'MANIFEST.json').read_bytes());seen=set()
for r in m['files']:
 q=PurePosixPath(r['path']);assert not q.is_absolute() and '..' not in q.parts and q.as_posix() not in seen;seen.add(q.as_posix());f=p.joinpath(*q.parts);assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert (len(b),hashlib.sha256(b).hexdigest(),oct(stat.S_IMODE(f.stat().st_mode)))==(r['bytes'],r['sha256'],r['mode'])
assert {x.name for x in p.iterdir()}==seen|{'MANIFEST.json'}
print('Verified public report identities; restricted originals and Git anchors remain separately held. No product behavior, custody independence or audit closure is established.')
