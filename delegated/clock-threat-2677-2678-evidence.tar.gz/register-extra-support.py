from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();items=[('quest-unsigned','crates/adventuresim-core/src/quest_catalog_validation.rs',[[210,245]]),('logging-clock','crates/adventuresim-tactical-server/src/iteration/logging.rs',[[215,245]])];out=[]
for name,path,ranges in items:
 raw=g('show',rev+':'+path);n=len(raw.splitlines());assert all(1<=a<=z<=n for a,z in ranges);dest=f'support/{name}.rs';(b/dest).write_bytes(raw);out.append({'name':name,'revision':rev,'path':path,'archive':dest,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'ranges':ranges,'qualification':'bounded support, no ordered-role credit'})
(b/'extra-support-registration.json').write_text(json.dumps({'schema':'726-bounded-support-prospective-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out},indent=2)+'\n');print(json.dumps(out,indent=2))
