# Bounded source audit: historical roles 2677 and 2678

`REPORT.json` records the independently inspected clock and escalation limits,
scoped findings, open questions, and thirteen bounded lens perspectives.
`registration.json`, the two support registrations, and
`personal-read-receipt.json` distinguish prospective scope from actual displays.
Saved full source bytes are not a claim to have read outside those ranges.

The role 2677 object was recovered from the physical-p16 dirty snapshot through
f82 transport. Its a120 clean-base file and the pinned 95e file match the object
individually; this does not identify a dirty-snapshot commit. The role 2678
pr-working object matches its recorded 6533 per-file object and 95e file, while
the recorded pr-working snapshot had four unrelated modifications. Historical
059 and 774 records and prior current assessment retain their original readers,
revisions, ranges, statuses, and separate attributions. Selected standalone
registry and queue views are reconstructed, not original checkpoint 3821 files.

The later recovered P16 tracked patch and recovery report are included. The
tracked patch matches its recorded digest but excludes seven untracked files;
matching bytes do not prove the original diff command or continuous custody.
The report records a historical shorthand claim of no Serde alongside the
actual Serialize-only source and more precise original companion qualification.

Evidence verification is self-contained and read-only:

```
python3 verify-evidence.py
python3 verify-manifest.py
```

The build scripts are retained as provenance; recreating from the original
sources would require the original local stores. Verifiers require only this
packet. They check evidence, object identity, registered read scopes, and
attribution, not product behavior. No implementation, product build, test,
simulation, runtime probe, or product validation was performed.
