from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest(); registrations=['registration.json','support-registration.json','extra-support-registration.json'];out=[]
for rn in registrations:
 r=json.loads((b/rn).read_bytes());
 for e in r['entries']:
  ranges=e.get('prospective_personal_read_ranges',e.get('ranges',[]))
  if not ranges:continue
  chunks=[]
  for a,z in ranges:
   if z-a+1>70:
    if e.get('name') in ('current-iteration','p16-iteration'): chunks += [[a,55],[56,z]]
    elif e.get('name')=='current-elapsed': chunks += [[a,45],[46,z]]
    elif e.get('name')=='current-threat':chunks += [[1,70],[71,140],[141,205]]
    else:raise AssertionError(e)
   else:chunks.append([a,z])
  n=e['eof'];mask={i for a,z in ranges for i in range(a,z+1)};unread=[];start=None
  for i in range(1,n+2):
   if i<=n and i not in mask and start is None:start=i
   if (i>n or i in mask) and start is not None:unread.append([start,i-1]);start=None
  out.append({'role':e.get('role'),'kind':e.get('kind',e.get('name')),'revision':e['revision'],'sha256':e['sha256'],'archive':e['archive'],'registration':rn,'registration_sha256':sha((b/rn).read_bytes()),'actual_displayed_chunks':chunks,'actual_displayed_ranges':ranges,'unread_complement':unread,'attribution':'/root/rig_identity personal, independently displayed after registration','truncated':False})
(b/'personal-read-receipt.json').write_text(json.dumps({'schema':'726-personal-source-read-receipt-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out,'qualification':'Full archived bytes do not constitute reading outside displayed ranges; historical base and 6533 head are retained as object equality proofs and not personally displayed as separately credited source reads.'},indent=2)+'\n');print('recorded',len(out),'entries')
