from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent; repo='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
cur='95e63628f9d70b8dd6e6fede64334696c6995009';pr='6533e444fa37552927070cc8d8190907fd3b413e';base='a120390947c89b703dc74c4255a13c035d054c50';transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';items=[(2677,'crates/adventuresim-tactical-server/src/iteration/clock.rs','049de982e2d1650e4040a5bcc9ac4a4e85d8354d2352bfe0f91972df55512539',base),(2678,'crates/adventuresim-core/src/threat_escalation_limits.rs','f6fd77cd38865e477731cf06914d6e576b6498e4b2847c2a586368b378073929',pr)]
rows=[]
for i,path,expected,ref in items:
 tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+expected
 for kind,rev,gitpath in [('historical_object',transport,tp),('current',cur,path),('historical_base' if i==2677 else 'historical_head',ref,path)]:
  raw=g('show',rev+':'+gitpath);dest=f'sources/{i}-{kind}.rs';(b/dest).write_bytes(raw);n=len(raw.splitlines());rows.append({'role':i,'kind':kind,'revision':rev,'git_path':gitpath,'project_path':path,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'archive':dest,'prospective_personal_read_ranges':[[1,n]] if kind in ('historical_object','current') else [],'qualification':('f82 is transport of P16 dirty snapshot object, not P16 product commit' if i==2677 and kind=='historical_object' else 'a120 is recorded clean P16 base only, not dirty snapshot' if i==2677 and kind=='historical_base' else 'pr-working snapshot had other modifications; this object is proven independently' if i==2678 and kind in ('historical_object','historical_head') else 'pinned project revision')});
  if kind=='historical_object': assert sha(raw)==expected
out={'schema':'726-prospective-role-registration-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','reason':'roles 2677 and 2678; personally display historic and current bodies in full, base/6533 retained as equality proof only','entries':rows,'no_product_execution':True};(b/'registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
