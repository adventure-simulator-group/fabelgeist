from pathlib import Path
from datetime import datetime
import gzip,hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');reg=load('registration.json');r1=load('support-registration.json');r2=load('extra-support-registration.json');receipt=load('personal-read-receipt.json');report=load('REPORT.json')
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
origraw=gun('historical/registry.json.gz');assert sha(origraw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';orig=json.loads(origraw);manifest_raw=gun('historical/original-transport-manifest.json.gz');assert sha(manifest_raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';mi=json.loads(manifest_raw);idx={x['path']:x for x in mi['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2677,2678,2056,406]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==orig['files'][x['original_index']]
for x in sel['snapshots']:assert x in orig['snapshots']
p16=next(x for x in orig['snapshots'] if x['id']=='physical-p16');pr=next(x for x in orig['snapshots'] if x['id']=='pr-working');assert p16['base']==p16['head']=='a120390947c89b703dc74c4255a13c035d054c50' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
recovery=load('historical/p16-recovery.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';assert recovery['recovered_patch']['bytes']==524542 and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7};patch=(b/'historical/p16-tracked.patch').read_bytes();assert len(patch)==524542 and sha(patch)==p16['patch_sha256']
for x in reg['entries']+r1['entries']+r2['entries']:
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob'] and len(d.splitlines())==x['eof']
for role in (2677,2678):
 rows=[x for x in reg['entries'] if x['role']==role];assert len(rows)==3 and len({(b/x['archive']).read_bytes() for x in rows})==1;histrow=next(x for x in rows if x['kind']=='historical_object');assert histrow['sha256']==orig['files'][role]['sha256'] and histrow['eof']==orig['files'][role]['actual_line_count'] and histrow['prospective_personal_read_ranges']==orig['files'][role]['material_ranges']
assert orig['files'][2056]['sha256']==orig['files'][2677]['sha256'];assert next(x for x in r1['entries'] if x['name']=='p16-iteration')['sha256']==orig['files'][406]['sha256']
queue=json.loads(gun('historical/baseline-059-queue.json.gz'))['entries'];q=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in q['entries']]==[118,1753,1761]
for x in q['entries']:assert x['entry']==queue[x['original_index_zero_based']]
assert [queue[i]['contract_id'] for i in (118,1753,1761)]==['ADLER-L11-ITERATION-TIMEOUT-TICK-COUNT','Q-L12-7c8628fe66484e213a0a','Q-L12-1e2360d2b144a073b61b']
for x in hist['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
l11=load('historical/059/segovb/READ-L11-437.json');l12=load('historical/059/segovb/READ-L12-928.json');assert l12['root_personal_rereads']==[] and l12['new_findings']==[] and l12['current_source_reconciled'] is False
for i in (2677,2678):
 x=next(x for x in l11['sources'] if x['original_index']==i);y=next(x for x in l12['rows'] if x['original_index']==i);expected=orig['files'][i]['material_ranges'];assert x['fresh_personal_body_reads']==y['fresh_personal_body_reads']==expected and '/root/lens12_frontier' in y['attribution'] and y['unread_registered_ranges']==[]
assert next(x for x in load('historical/059/adler/READ-L11-320.json')['sources'] if x['original_index']==2056)['fresh_reads']==[[1,29]]
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
registrations=[json.loads(z) for z in gun('historical/774/native/admission03/source-range-registration.jsonl.gz').splitlines()];quals={x['id']:x for x in [json.loads(z) for z in gun('historical/774/native/admission03/source-qualifications-final-082.jsonl.gz').splitlines()]}
for i in (2677,2678):
 x=orig['files'][i]['admission03_scope_observations'][0];assert registrations[x['row_1based']-1]==x['original_record']
 for qual in x['local_qualifications']:assert quals[qual['id']]==qual
assert 'no rawfloatconstructor/Serde/Reflect' in quals['NATIVE-ADMISSION03-QUAL-027']['qualification'];assert 'Serialize-only' in gun('historical/774/native/admission03/contract-groups-052.json.gz').decode();assert b'Serialize)]' in (b/'sources/2677-current.rs').read_bytes() and b'Deserialize' not in (b/'sources/2677-current.rs').read_bytes()
prior=load('historical/prior-current-timeout-assessment.json');assert prior['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and prior['candidates'][0]['id']=='REVIEW-ITERATION-TIMEOUT-COUNT-001'
for a,x in zip(prior['current_sources'],hist['prior_current_sources']):
 data=(b/x['preserved']).read_bytes();raw=gzip.decompress(data);assert len(data)==x['bytes'] and sha(data)==x['sha256'] and len(raw)==x['uncompressed_bytes']==a['bytes'] and sha(raw)==x['uncompressed_sha256']==a['sha256'] and oid('blob',raw)==x['git_blob']==a['git_blob'] and x['prior_assessed_ranges']==a['ranges']
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==29
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
allregs={e['archive']:(r,e) for r in (reg,r1,r2) for e in r['entries'] if e.get('prospective_personal_read_ranges',e.get('ranges',[]))};assert len(receipt['entries'])==len(allregs)==14;cover={}
for e in receipt['entries']:
 rr,source=allregs[e['archive']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']);assert e['registration_sha256']==sha((b/e['registration']).read_bytes()) and e['sha256']==source['sha256'] and e['truncated'] is False
 chosen={i for a,z in e['actual_displayed_ranges'] for i in range(a,z+1)};chunks={i for a,z in e['actual_displayed_chunks'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert e['actual_displayed_ranges']==source.get('prospective_personal_read_ranges',source.get('ranges',[])) and chosen==chunks and chosen.isdisjoint(unread) and chosen|unread==set(range(1,source['eof']+1));cover[e['archive']]=chosen
assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   p=x['archive'];a,z=x['lines'];assert p in cover and set(range(a,z+1))<=cover[p] and x['sha256']==allregs[p][1]['sha256'] and x['revision']==allregs[p][1]['revision']
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','source_evidence':'historical objects, current project and base/head equality, prior 059/774 records and P16 patch verified','registered_personal_reads':len(receipt['entries']),'059_records':len(hist['records_059']),'774_original_records':len(hist['records_774']),'git_paths':len(proof['paths']),'lenses_bounded':len(report['lenses']),'product_validation':'not performed'},indent=2))
