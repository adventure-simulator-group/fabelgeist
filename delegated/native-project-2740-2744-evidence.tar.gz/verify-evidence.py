import datetime,gzip,hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);assert 'pinned-native-dependency' not in {x['id'] for x in registry['snapshots']};assert all(registry['files'][i]['snapshot']=='pinned-native-dependency' for i in range(2740,2745));trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue);sel=load('queue-selection-reconstructed.json');assert all(q['entries'][int(k)]==v for k,v in sel['entries'].items());sel=load('registry-selection-reconstructed.json');assert all(registry['files'][int(k)]==v for k,v in sel['roles'].items());assert sha((p/'reference/p16-tracked.patch').read_bytes())=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for n in ['reference-index.json','rules.json','skills.json']:
 for e in load(n)['records']:
  b=(p/e['file']).read_bytes();assert sha(b)==e['sha256'],e['file']
for n in ['','support','support2','support3']:
 rf=(n+'-registration.json') if n else 'registration.json';tf=(n+'-read-receipt.json') if n else 'personal-read-receipt.json';r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries']);
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'] and blob(body)==a['git_blob'];assert len(body.splitlines())==a['EOF'] and a['archive']==b['archive'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[n or 'assigned']=len(r['entries'])
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
archive=p/'native/spacetimedb-2.6.1.crate';pack=archive.read_bytes();assert sha(pack)=='b6eff5017248ff2e35e03564df947fdf3e963f7198be6ae1d9e894c2efb2ea15';m=load('native/MANIFEST.json');assert m['sha256']==sha(pack) and m['bytes']==len(pack)
with tarfile.open(archive,'r:gz') as t:member=t.extractfile('spacetimedb-2.6.1/src/lib.rs').read()
assert sha(member)=='b4c9d8460c2b511a8ddd6bac50546cb06ab9e83daab5df6007605e4b65c65a00' and member==(p/'source/2742-historical.rs').read_bytes()==(p/'source/2742-locked-native-package.rs').read_bytes();lines=(p/'support/lock.lock').read_text().splitlines();assert lines[9761]=='name = "spacetimedb"' and lines[9762]=='version = "2.6.1"' and 'b6eff5017248ff2e35e03564df947fdf3e963f7198be6ae1d9e894c2efb2ea15' in lines[9764]
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==43
report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13
print(json.dumps({'status':'pass','scope':'offline identity/read receipt/hash and raw Git tree proofs, original labels, native archive member and 95e lock checksum; no product validation','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
