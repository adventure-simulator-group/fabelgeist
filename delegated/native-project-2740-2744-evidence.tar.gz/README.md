# Bounded project and native source evidence, roles 2740–2744

This packet contains `/root/mhr_character`'s source-only assessment against
pinned project revision `95e63628f9d70b8dd6e6fede64334696c6995009` and the
exact original historical source objects. See `report.json` for observations,
conditional risk, nonfindings, open questions and thirteen bounded lens
perspectives. See registrations, personal receipts and
`read-scope-summary.json` for exact independent source displays and unread
complements; full source bytes do not confer full read coverage.

The original registry says `snapshot: pinned-native-dependency` for all five
rows, but has no snapshot table row with that name. Roles 2740–2741 also have
`pr-working` source IDs and paths; roles 2743–2744 have `physical-p16` source
IDs and paths. Their Camera registrations, 059 provenance, f82 recovered source
objects and raw Git proofs provide qualified identity evidence; no label is
silently corrected. All four project objects equal their respective a120, 6533
and 95e same-path blobs, and the P16 two also equal their 039 source objects;
these are individual file identities only. The pr-working and physical-p16
snapshots retain their recorded dirty qualifications. The P16 tracked patch was
later recovered, without proof of its original invocation or uninterrupted
custody. `f82` transports evidence, not a project revision.

Role 2742 is the spacetimedb 2.6.1 registry source member. Its archived package
SHA-256 equals the pinned 95e Cargo.lock checksum and the member equals the
original object. Only lines 1–41 were independently displayed; 42–1817 remain
unread. Neither the lock entry nor package contents establish selected features
or macro expansion. Test source in role 2743 was read only as text.

Historical Camera and 059 reviewer material is preserved with original scope
and chronology, including the pre-registration comparison qualification. Lens
12 prospective registrations are not body reads or proof of adoption. Other
reviewers and earlier current reports remain separately attributed; original
queue selections are reconstructed from the preserved queue. No checkpoint 3821,
whole-lens closure or unique-count decision is inferred.

Run `python3 verify-evidence.py` for offline evidence integrity and raw Git
object proofs; run `python3 verify-manifest.py` to verify all members, including
the nested native archive manifest. These are evidence verification only.
No product code, tests, build, macro, fixture, generation or probe was run.
