import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);selection=load('registry-selection-reconstructed.json');assert selection['roles']['2852']==registry['files'][2852];assert selection['snapshot']==[x for x in registry['snapshots'] if x['id']=='pr-working'];assert registry['files'][2852]['material_ranges']==[[1,32]] and registry['files'][2852]['snapshot']=='pr-working'
trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue);assert all(q['entries'][int(k)]==v for k,v in load('queue-selection-reconstructed.json')['entries'].items())
for n in ('reference-index.json','rules.json','skills.json'):
 for e in load(n)['records']:assert sha((p/e['file']).read_bytes())==e['sha256'],e['file']
groups=[('assigned','registration.json','personal-read-receipt.json'),('tail','tail-registration.json','tail-read-receipt.json')]+[(f'support{n or ""}',f'support{n or ""}-registration.json',f'support{n or ""}-read-receipt.json') for n in (0,2,3,4,5)]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'] and blob(body)==a['git_blob'] and len(body.splitlines())==a['EOF'] and a['archive']==b['archive'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[name]=len(r['entries'])
r=load('registration.json')
for e in r['entries']:
 row=registry['files'][e['original_index']];assert (e['source_id'],e['snapshot'],e['sha256'],e['EOF'],e['original_material_ranges'])==(row['source_id'],row['snapshot'],row['sha256'],row['actual_line_count'],row['material_ranges'])
assert all(v['equals_archived'] for c in r['comparisons'] for v in c['versions'].values())
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
hist=p/'history-059/segovb';receipt=json.loads((hist/'READ-L11-463.json').read_bytes());state=json.loads((hist/'STATE-L11-463.json').read_bytes());v=json.loads((hist/'VERIFY-L11-463.json').read_bytes());assert receipt['current_reconciled'] is False and receipt['accepted_unique_count_change']==0 and state['accepted_unique_count_change']==0 and v['gate'] is False;assert state['receipt_sha256']==sha((hist/'READ-L11-463.json').read_bytes())==v['receipt_sha256'];assert v['state_sha256']==sha((hist/'STATE-L11-463.json').read_bytes())
for num,scope in [(1773,[[1,32]]),(1774,[[33,34]]),(1775,[[35,36]])]:
 f=hist/f'REGISTRATION-SEGOVB-{num}.json';x=json.loads(f.read_bytes());src=[s for s in receipt['sources'] if s.get('registration_sha256')==sha(f.read_bytes())];assert len(src)==1 and src[0]['original_index']==2852 and src[0]['assessed_ranges']==src[0]['fresh_personal_body_reads']==x['ranges']==scope and x['sha256']==registry['files'][2852]['sha256'] and x['prospective']
e=load('registration-version-qualification.json');rec=registry['files'][2852]['scope_registration'][0];raw=gzip.decompress((p/e['transport_file']).read_bytes());lines=raw.splitlines();assert sha(raw)==e['transport_uncompressed_sha256']!=rec['sha256']==e['registry_recorded_whole_file_sha256'];assert json.loads(lines[rec['row_1based']-1])==rec['original_record'] and e['row_matches'] and not e['simple_prefix_matches']
for i in range(1,len(lines)+1):
 for sep in (b'\n',b'\r\n'):
  for end in (sep,b''):assert sha(sep.join(lines[:i])+end)!=rec['sha256']
x=json.loads(gzip.decompress((p/'history-774/root/admission03/new-parallel-admission-250.json.gz').read_bytes()));z=[a for a in x['source_roles'] if a['source_id']==registry['files'][2852]['source_id']];assert len(z)==1 and z[0]['actual_compared_ranges']==[[1,32]] and z[0]['qualified_material_ranges']==[[3,8],[25,29]]
quals=[json.loads(z) for z in gzip.decompress((p/'history-774/rig/initial06-type-ownership/qualifications.jsonl.gz').read_bytes()).splitlines()];assert [z['qualified_material_ranges'] for z in quals if z.get('registration_id')=='RIG-INITIAL06-REG-038']==[[[3,8],[25,29]]]
for e in load('prior-index.json')['records']:
 assert sha((p/e['manifest']).read_bytes())==e['manifest_sha256'] and sha((p/e['report']).read_bytes())==e['report_sha256'];m=json.loads((p/e['manifest']).read_bytes());d={x['path']:x for x in m['files']};r=(p/e['report']).read_bytes();assert (len(r),sha(r))==(d[pathlib.Path(e['report']).name]['bytes'],d[pathlib.Path(e['report']).name]['sha256'])
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==26;report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13;assert len(load('read-scope-summary.json')['scopes'])==sum(counts.values())
print(json.dumps({'status':'pass','scope':'Offline source and prospective registered reads/unread complements, original 059/774 and distinct extension receipts, original registration row/hash qualification, prior reviewer report bindings and raw Git tree proofs; no product validation.','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
