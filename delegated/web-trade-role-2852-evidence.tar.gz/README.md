# Trade facade source evidence: original role 2852

This packet records /root/mhr_character's independent source-only review of
original pr-working role 2852 against pinned current project revision
95e63628f9d70b8dd6e6fede64334696c6995009. The exact archived source object
individually matches its 6533 and 95e Git paths; the recorded pr-working tree
had unrelated changes. f82 transports historical evidence and is not the
project source revision.

`report.json` contains bounded findings, nonfindings, historical attribution,
open questions and thirteen perspectives. `read-scope-summary.json` binds actual
personal displays to prospective registrations: original role1–32 and separate
supplemental 33–54, independently at historical and current source. The full
union is not an expansion of the original registered role. All other source
complements remain unread unless shown by a separately recorded support receipt.

Original Segovb 059 evidence records three independent reads, 1–32 then 33–34
and 35–36; earlier Rig06 and Root03 qualified only material imports3–8 and
25–29. Registry-recorded historical registration whole-file hash differs from
the f82-transported full JSONL although row38 matches exactly; see
`registration-version-qualification.json`. Historical records, previous reviewer
reports and reconstructed registry/queue selections remain separately labeled.
No checkpoint 3821 or full lens closure is claimed.

`git-proofs.json` and `git-objects/` contain raw commit/tree membership proofs.
Run `python3 verify-evidence.py` and `python3 verify-manifest.py` only for
offline evidence integrity. No product, build, test, fixture, browser, generated
code execution, runtime probe or repair was performed. Central owns publication,
ledger and unique counts.
