# Bounded P16 geometry-error and interior-lighting evidence

This `/root/hair_ops` source-only review covers physical-P16 original roles
2478 and 2556 against `95e63628f9d70b8dd6e6fede64334696c6995009`. The
registry records a 159-path dirty P16 delta based on a120 and a full patch hash;
complete patch bytes remain unrecovered. A bounded search in specified older
collections found no matching patch, without establishing global absence. The
selected file objects match f82 transport, their 0393 catalog origin, a120,
6533 and 95e per file; that does not reconstruct the whole dirty snapshot.

The P16 and 95e bodies were separately displayed after prospective registration:
error 1–28 in one chunk per revision, field 1–110 and 111–206 per revision.
The original P16 material scopes were error 1–28 and field 130–142; the rest of
the newly reviewed field body is a separate extension. The older
`/root/lens12_frontier` connected field read used distinct ranges and was
root-adopted without root reread; Adler's earlier full field read was pr-working
6533. All original authors, revisions and scopes are retained.

`report.json` provides thirteen bounded perspectives, source citations,
conditions and open questions. Current field span arithmetic and the exposed
field/cardinality aggregate are already connected to prior findings. Earlier
shutter-origin matching, possible ambiguity and scene-window selection remain
separately attributed and conditional. Geometry adapters retain typed role,
axis and native direction failure categories in the inspected paths. No new
unique finding count or product effect is claimed.

`read-receipt.json`, `support-read-receipt.json`, `git-proofs.json` and
`git-objects/` record actual displays and per-file membership. Exact selected
059/774 records and the compressed source inventory are retained; selected
queue rows are reconstructed excerpts linked to the complete queue, never
checkpoint3821 evidence. Prior packet reports, one prior personal receipt and
manifests are hash-linked with their original authors.

`verify_evidence.py` checks evidence integrity and read windows only; run it in
a copy to preserve the timestamped frozen output. `verify_manifest.py` checks
the frozen set without writing. No product or renderer execution, builds,
tests, probes, simulations, repairs or source/publication edits occurred.
Central coordination owns aliases, the ledger and checkpoint publication.
