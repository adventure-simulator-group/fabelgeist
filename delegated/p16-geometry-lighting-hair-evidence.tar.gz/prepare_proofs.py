import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_bytes());names=['support-registration.json','support-registration-02.json'];sup=[x for n in names for x in json.loads((p/n).read_bytes())['sources']];hist=json.loads((p/'historical-manifest.json').read_bytes());objects={};proofs=[]
def obj(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  f='git-objects/'+oid+'.'+t+'.gz';(p/f).write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':sha(b),'archive':f}
 return b
def entries(b):
 d={};i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);d[b[a+1:z].decode()]=(b[i:a].decode(),b[z+1:z+21].hex());i=z+21
 return d
members=[]
for role in reg['roles']:
 for v in role['versions']:
  if v['present']:members.append({'revision':v['revision'],'git_path':role['path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob']})
 v=role['p16'];members.append({'revision':v['archive_revision'],'git_path':v['archive_path'],'local':v['local'],'sha256':v['sha256'],'git_blob':v['git_blob'],'qualification':'Archive object, not entire P16 patch or source snapshot head.'})
members+=sup
for x in hist['records']:
 if x['scope'] in ['adler-original-f82','prior-publication']:
  b=(p/x['copy']).read_bytes();members.append({'revision':x['revision'],'git_path':x['origin'],'local':x['copy'],'sha256':x['sha256'],'git_blob':blob(b),'qualification':x['scope']+' preserved prior record, no fresh personal read credit'})
for s in members:
 tree=obj('commit',s['revision']).splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in s['git_path'].split('/'):
  mode,child=entries(obj('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/s['local']).read_bytes();assert sha(b)==s['sha256'] and tree==s['git_blob']==blob(b);proofs.append({'revision':s['revision'],'path':s['git_path'],'archive':s['local'],'commit_tree':root,'chain':chain,'blob':tree,'qualification':s.get('qualification')})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'P16 registry records 159-path dirty delta at a120; f82 transports selected objects only. Whole patch remains unrecovered.','objects':objects,'proofs':proofs},indent=2)+'\n')
def comp(eof,w):
 a=set()
 for lo,hi in w:a.update(range(lo,hi+1))
 out=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in a and start is None:start=i
  if start is not None and (i==eof+1 or i in a):out.append([start,i-1]);start=None
 return out
reads=[]
for role in reg['roles']:
 i=role['original_index'];oe=role['p16']['prospective_range'][1];ce=role['versions'][-1]['prospective_range'][1];reads.append({'original_index':i,'p16_eof':oe,'p16_display_windows':([[1,110],[111,206]] if i==2556 else [[1,oe]]),'p16_unread_complement':[],'current_revision':role['versions'][-1]['revision'],'current_eof':ce,'current_display_windows':([[1,110],[111,206]] if i==2556 else [[1,ce]]),'current_unread_complement':[],'0393_a120_6533_personal_display_windows':[],'original_p16_material_range':[[1,28]] if i==2478 else [[130,142]],'fresh_p16_extension_ranges':[] if i==2478 else [[1,129],[143,206]],'other_reviewer_prior_support':'/root/rig_identity separately displayed current field ranges 1–160 and 157–206 as support in prior_shutters personal receipt; no transfer of reading credit.' if i==2556 else None})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registration_sha256':sha((p/'registration.json').read_bytes()),'roles':reads,'qualification':'P16 and current bodies personally displayed separately in bounded chunks after prospective registration. Test text read only; no execution. Other versions verified but not separately displayed.'},indent=2)+'\n')
r=[]
for s in sup:
 w=s['prospective_ranges'];r.append({'index':s['index'],'path':s['path'],'revision':s['revision'],'archive':s['local'],'sha256':s['sha256'],'eof':s['eof'],'actual_display_windows':w,'unread_complement':comp(s['eof'],w)})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','prospective_registrations':[{'path':n,'sha256':sha((p/n).read_bytes())} for n in names],'reads':r,'qualification':'Only recorded current support ranges personally displayed; navigation searches confer no complete body credit.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'support reads',len(sup))
