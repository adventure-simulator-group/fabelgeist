# Bounded source evidence: capability and tactical inventory

This packet records /root/mhr_character's independent bounded review of the
original registry roles 2810–2813. The pinned current project revision is
95e63628f9d70b8dd6e6fede64334696c6995009. Exact historical pr-working role
objects are transported by f82adcabd9d89c4fa2dd7f99253a45297a0681ee and are
individually identical to their paths at the recorded 6533e444f project HEAD
and 95e. This does not make the recorded dirty snapshot a clean tree. Future
physical-p16 role 2818 is a separate original role even where bytes coincide.

`report.json` contains findings, nonfindings, open questions, historical
relationships and thirteen bounded lens perspectives. `read-scope-summary.json`
is reconstructed from this reviewer's prospective registrations and personal
read receipts, which remain separately preserved. Role 2813's historical and
current lines 80–205 remain unread by this reviewer. Full source archives prove
identity and do not expand personal read scope.

`history-059/` contains byte-exact records matched to the recovered 059
transport manifest; `history-774/` contains original 774 records from the
transport Git tree. Historical scopes, authors and qualifications are not
reassigned to the new review or checkpoint 3821. `registration-version-
qualification.json` distinguishes earlier registry-recorded whole-file hashes
from the f82-transported JSONL files: matching rows do not recover the earlier
whole-file bytes. Registry and queue selections are explicitly reconstructed.
Earlier 95e assessments are copied in `reference/` and retain their authorship.

`git-proofs.json` and `git-objects/` provide independently verifiable raw
commit/tree paths. Run `python3 verify-evidence.py` and `python3
verify-manifest.py` only for offline evidence integrity. These checks do not run
or validate the product, tests, fixtures, shaders or simulations. The central
coordinator owns source-baseline decisions, reconciliation, aliases, repair ledger
and publication; this packet assigns no unique finding count or lens closure.
