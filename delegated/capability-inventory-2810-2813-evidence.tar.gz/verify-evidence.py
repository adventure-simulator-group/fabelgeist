import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw);selection=load('registry-selection-reconstructed.json');assert all(registry['files'][int(k)]==v for k,v in selection['roles'].items());assert selection['snapshot']==[x for x in registry['snapshots'] if x['id'] in ('pr-working','physical-p16')]
assert [registry['files'][i]['material_ranges'] for i in (2810,2811,2812,2813,2818)]==[[[1,41]],[[1,103]],[[1,21]],[[1,79]],[[1,78]]];assert [registry['files'][i]['snapshot'] for i in (2810,2811,2812,2813,2818)]==['pr-working']*4+['physical-p16'];assert registry['files'][2813]['sha256']==registry['files'][2818]['sha256']
trans=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(trans)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest={e['path']:e for e in json.loads(gzip.decompress(trans))['entries']};queue=gzip.decompress((p/'reference/queue.json.gz').read_bytes());assert sha(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue);assert all(q['entries'][int(k)]==v for k,v in load('queue-selection-reconstructed.json')['entries'].items())
for n in ('reference-index.json','rules.json','skills.json'):
 for e in load(n)['records']:assert sha((p/e['file']).read_bytes())==e['sha256'],e['file']
groups=[('assigned','registration.json','personal-read-receipt.json')]+[(f'support{n or ""}',f'support{n or ""}-registration.json',f'support{n or ""}-read-receipt.json') for n in (0,2,3,4,5,6,7)]
for name,rf,tf in groups:
 r=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes());assert datetime.datetime.fromisoformat(t['read_completed_utc'])>datetime.datetime.fromisoformat(r['registered_utc']);assert len(r['entries'])==len(t['entries'])
 for a,b in zip(r['entries'],t['entries']):
  body=(p/a['archive']).read_bytes();assert sha(body)==a['sha256']==b['sha256'] and blob(body)==a['git_blob'] and len(body.splitlines())==a['EOF'] and a['archive']==b['archive'];planned={i for lo,hi in a['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in b['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in b['unread_complement'] for i in range(lo,hi+1)};assert seen==planned and missing==set(range(1,a['EOF']+1))-seen and not seen.intersection(missing)
 counts[name]=len(r['entries'])
r=load('registration.json')
for e in r['entries']:
 row=registry['files'][e['original_index']];assert (e['source_id'],e['snapshot'],e['sha256'],e['EOF'],e['original_material_ranges'])==(row['source_id'],row['snapshot'],row['sha256'],row['actual_line_count'],row['material_ranges'])
assert all(v['equals_archived'] for c in r['comparisons'] for v in c['versions'].values())
for e in load('historical-index.json')['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':
  m=manifest[e['transport_path']];assert (m['bytes'],m['sha256'],m['git_blob'])==(len(b),sha(b),blob(b))
hist=p/'history-059/segovb';receipt=json.loads((hist/'READ-L11-457.json').read_bytes());state=json.loads((hist/'STATE-L11-457.json').read_bytes());v=json.loads((hist/'VERIFY-L11-457.json').read_bytes());assert receipt['current_reconciled'] is False and receipt['accepted_unique_count_change']==0 and state['accepted_unique_count_change']==0 and v['gate'] is False;assert state['receipt_sha256']==sha((hist/'READ-L11-457.json').read_bytes())==v['receipt_sha256'];assert v['state_sha256']==sha((hist/'STATE-L11-457.json').read_bytes())
for role,num,scope in [(2810,1731,[[1,41]]),(2811,1732,[[1,103]]),(2812,1733,[[1,21]]),(2813,1734,[[1,79]])]:
 f=hist/f'REGISTRATION-SEGOVB-{num}.json';x=json.loads(f.read_bytes());src=[s for s in receipt['sources'] if s['original_index']==role];assert len(src)==1 and src[0]['registration_sha256']==sha(f.read_bytes()) and src[0]['assessed_ranges']==src[0]['fresh_personal_body_reads']==x['ranges']==scope and x['sha256']==registry['files'][role]['sha256'] and x['prospective']
l12=json.loads((hist/'READ-ROOT-L12-694-ARMOR.json').read_bytes());row=[x for x in l12['rows'] if x['original_index']==2813][0];assert row['fresh_personal_body_reads']==[[1,205]] and row['ordered_credit_now']==0 and row['registration_sha256']==sha((hist/'REGISTRATION-ROOT-L12-694-ARMOR-2813.json').read_bytes());assert 'failed' in l12['additive_bookkeeping_correction']
qh=gzip.decompress((p/'history-774/root/parallel-scope-qualification-170.json.gz').read_bytes());assert sha(qh)=='6aa166f7a09a5a88127a8069fa434ec7dc4493affcec73096d5db0cb933bc21c';qualification=json.loads(qh);assert len(qualification['affected_source_ids'])==2 and 'StopIteration' in qualification['failure']
admission=json.loads(gzip.decompress((p/'history-774/root/admission03/new-parallel-admission-171.json.gz').read_bytes()));assert [x['actual_compared_ranges'] for x in admission['source_roles'][:4]]==[[[1,41]],[[1,103]],[[1,21]],[[1,79]]]
for role,rel in [(2810,'root/initial04-invariant-operations/source-range-registration.jsonl.gz'),(2811,'root/initial04-invariant-operations/source-range-registration.jsonl.gz'),(2812,'native/initial05-aggregate-states/source-range-registration.jsonl.gz'),(2813,'native/initial05-aggregate-states/source-range-registration.jsonl.gz'),(2818,'camera/initial07-redundant-authority/source-range-registration.jsonl.gz')]:
 rec=registry['files'][role]['scope_registration'][0];raw=gzip.decompress((p/'history-774'/rel).read_bytes());rows=[json.loads(z) for z in raw.splitlines()];assert sha(raw)!=rec['sha256'] and rows[rec['row_1based']-1]==rec['original_record']
assert all(z['embedded_row_equals_transport_row'] and not z['simple_line_prefix_sha_matches'] and z['registry_recorded_whole_file_sha256'] != z['f82_transported_uncompressed_sha256'] for z in load('registration-version-qualification.json')['records'])
x=json.loads(gzip.decompress((p/'history-774/native/initial05-aggregate-states/contract-groups-114.json.gz').read_bytes()));deps=[z for z in x['registered_direct_dependencies'] if z['source_id']==registry['files'][2813]['source_id']];assert len(deps)==1 and deps[0]['scoped_ranges_compared']==[[1,78]]
quals=[json.loads(z) for z in gzip.decompress((p/'history-774/camera/initial07-redundant-authority/qualifications.jsonl.gz').read_bytes()).splitlines()];a=[z for z in quals if z.get('registration_id')=='CAMERA-INITIAL07-REG032'];assert len(a)==1 and a[0]['effective_material_ranges']==[[1,78]]
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
assert len(proof['proofs'])==53
report=load('report.json');assert len(report['lens_perspectives'])==13 and len({x['lens'] for x in report['lens_perspectives']})==13;assert len(load('read-scope-summary.json')['scopes'])==sum(counts.values());assert load('support2-read-receipt.json')['entries'];assert load('support6-registration.json')['qualification'].startswith('Prospective')
print(json.dumps({'status':'pass','scope':'Offline source bytes, bounded prospective registrations and receipt-complement arithmetic, original 059 and 774 record hashes, registry/queue reconstructions and raw Git tree memberships. No product validation.','counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'history_records':len(load('historical-index.json')['records']),'lens_perspectives':13,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
