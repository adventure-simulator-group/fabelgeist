use adventuresim_stdb_client::{ConnectedPlayerItem, EquipmentBodyPart};
use adventuresim_tactical_core::prelude::{
    ArmorItem, ArmorSide, ArmorSlot, WeaponAppearance, WeaponHolderAppearance,
};

use super::tactical_covered_parts;

pub(super) fn projected_parametric_weapon(
    item: &ConnectedPlayerItem,
    parameters: adventuresim_core::combat::WeaponContactParameters,
) -> Option<adventuresim_core::equipment::ParametricWeaponCombatGeometry> {
    let Some(appearance) = item.weapon_appearance.as_ref() else {
        assert!(
            adventuresim_weapon_model::default_design(&item.item.id).is_none(),
            "strategic authority omitted a parametric weapon recipe"
        );
        return None;
    };
    parametric_combat_geometry(&item.item.id, appearance, parameters)
}

pub(super) fn parametric_combat_geometry(
    item_id: &str,
    appearance: &adventuresim_stdb_client::ConnectedWeaponAppearance,
    parameters: adventuresim_core::combat::WeaponContactParameters,
) -> Option<adventuresim_core::equipment::ParametricWeaponCombatGeometry> {
    use adventuresim_weapon_model::{GENERATOR_VERSION, decode, derive_properties, design_hash};
    assert_eq!(appearance.generator_version, GENERATOR_VERSION);
    let design = decode(&appearance.recipe).expect("strategic authority sent a decodable recipe");
    assert_eq!(design.catalog_id, item_id);
    assert_eq!(design_hash(&design).0.as_slice(), appearance.design_hash);
    let derived = derive_properties(&design).expect("strategic authority sent a valid recipe");
    adventuresim_core::equipment::ParametricWeaponCombatGeometry::new(
        derived.mass_kg,
        derived.length_m,
        derived.grip_to_tip_m,
        derived.striking_head_length_m,
        derived.moment_of_inertia_kg_m2,
        derived.balance,
        parameters.precision_for_design(&design).value(),
    )
}

pub(super) fn projected_weapon_appearance(item: &ConnectedPlayerItem) -> Option<WeaponAppearance> {
    item.weapon_appearance
        .as_ref()
        .map(|appearance| WeaponAppearance {
            generator_version: appearance.generator_version,
            design_hash: appearance
                .design_hash
                .as_slice()
                .try_into()
                .expect("validated weapon design hash"),
            recipe: appearance.recipe.clone(),
        })
}

pub(super) fn projected_holder_appearance(
    item: &ConnectedPlayerItem,
) -> Option<WeaponHolderAppearance> {
    item.weapon_holder_appearance
        .as_ref()
        .map(|appearance| WeaponHolderAppearance {
            generator_version: appearance.generator_version,
            design_hash: appearance
                .design_hash
                .as_slice()
                .try_into()
                .expect("validated holder design hash"),
            recipe: appearance.recipe.clone(),
        })
}

pub(super) fn projected_holder_mass(item: &ConnectedPlayerItem) -> Option<f32> {
    use adventuresim_weapon_model::{
        HOLDER_GENERATOR_VERSION, decode_holder, derive_holder_properties, holder_design_hash,
    };
    let appearance = item.weapon_holder_appearance.as_ref()?;
    assert_eq!(appearance.generator_version, HOLDER_GENERATOR_VERSION);
    let design = decode_holder(&appearance.recipe)
        .expect("strategic authority sent a decodable holder recipe");
    assert_eq!(design.catalog_id, item.item.id);
    assert_eq!(
        holder_design_hash(&design).0.as_slice(),
        appearance.design_hash
    );
    Some(
        derive_holder_properties(&design)
            .expect("strategic authority sent a valid holder recipe")
            .mass_kg,
    )
}

pub(super) fn projected_armor(item: &ConnectedPlayerItem) -> Option<ArmorItem> {
    let part = item.protected_body_parts.first()?;
    let definition = adventuresim_core::item_catalog::definition(&item.item.id)
        .expect("validated armor exists in authored catalog");
    let authored = definition
        .equipment
        .as_ref()
        .expect("validated armor has equipment metadata");
    let placement = authored
        .placements
        .iter()
        .find(|placement| Some(placement.id.as_str()) == item.selected_placement_id.as_deref())
        .expect("validated armor retains its authored placement");
    let slot = match part {
        EquipmentBodyPart::LeftArm => ArmorSlot::Arms(Some(ArmorSide::Left)),
        EquipmentBodyPart::RightArm => ArmorSlot::Arms(Some(ArmorSide::Right)),
        EquipmentBodyPart::LeftLeg => ArmorSlot::Legs(Some(ArmorSide::Left)),
        EquipmentBodyPart::RightLeg => ArmorSlot::Legs(Some(ArmorSide::Right)),
        EquipmentBodyPart::Head => ArmorSlot::Head,
        EquipmentBodyPart::Chest => ArmorSlot::Chest,
        EquipmentBodyPart::Stomach => ArmorSlot::Stomach,
    };
    let mut coverage_geometry = [None; 7];
    for protected in &placement.protection {
        let body_part = adventuresim_core::equipment::equipment_body_part(*protected);
        let geometry =
            adventuresim_core::combat::AuthoredArmorCoverage::from_placement(placement, body_part);
        let index = adventuresim_core::autoresolve::body_part_index(body_part);
        coverage_geometry[index] = Some(geometry);
    }
    Some(ArmorItem {
        material: authored.material.expect("validated armor has a material"),
        range_of_motion: item.item.range_of_motion,
        coverage: item.item.coverage,
        slot,
        resistance: item.item.resistance,
        padding: item.item.padding,
        flexibility: item.item.flexibility,
        covered_parts: tactical_covered_parts(&item.protected_body_parts),
        coverage_geometry,
        layer_order: placement
            .outermost_channel()
            .map(|channel| channel.order())
            .unwrap_or_default(),
    })
}
