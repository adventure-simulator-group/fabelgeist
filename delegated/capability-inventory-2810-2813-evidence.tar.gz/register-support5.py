import datetime,hashlib,json,pathlib,subprocess
p=pathlib.Path(__file__).parent
repo='<LOCAL_PATH_0>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009'
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
specs=[('catalog-detail','content/items/catalog.yaml',[[3045,3065],[3675,3725]]),('equipment-write','crates/adventuresim-stdb-module/src/character.rs',[[3000,3150]]),('equipment-occupancy','crates/adventuresim-stdb-module/src/character/occupancy.rs',[[1,100]]),('tactical-producer','crates/adventuresim-stdb-module/src/tactical.rs',[[260,330],[420,495]]),('equipment-core','crates/adventuresim-core/src/equipment.rs',[[180,255]])]
out=[]
for name,path,ranges in specs:
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);f='support/'+name+('.yaml' if path.endswith('.yaml') else '.rs');(p/f).write_bytes(b)
 n=len(b.splitlines());assert all(hi<=n for lo,hi in ranges),(name,n)
 out.append({'name':name,'revision':rev,'path':path,'archive':f,'sha256':sha(b),'git_blob':blob(b),'EOF':n,'registered_ranges':ranges})
x={'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':out,'qualification':'Independent prospective bounded support registration for current catalog example, equipment occupancy/admission and tactical projection; source text only, tests and product are not executed.'}
(p/'support5-registration.json').write_text(json.dumps(x,indent=2)+'\n');print('registration',sha((p/'support5-registration.json').read_bytes()));print([(e['name'],e['EOF']) for e in out])
