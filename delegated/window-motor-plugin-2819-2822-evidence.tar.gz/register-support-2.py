from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();p='crates/adventuresim-tactical-core/src/combat_config';specs=[('config-context',p+'.rs',[[1,80],[417,429],[710,735]]),('config-runtime',p+'/runtime.rs',[[1,98]])];entries=[]
for id,path,ranges in specs:
 raw=g('show',rev+':'+path);n=len(raw.splitlines());assert max(z for a,z in ranges)<=n;dest=f'support/{id}.rs';(b/dest).write_bytes(raw);entries.append({'id':id,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'prospective_personal_read_ranges':ranges,'qualification':'Independent current bounded support only; no source-role, other reviewer, feature-resolution or runtime credit.'})
r={'schema':'726-window-motor-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':entries};(b/'support-registration-2.json').write_text(json.dumps(r,indent=2)+'\n');print('registered',len(entries))
