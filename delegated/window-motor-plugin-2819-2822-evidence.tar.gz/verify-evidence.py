from pathlib import Path
from datetime import datetime
import gzip,hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());history=load('historical-attribution.json');report=load('REPORT.json');names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json'];groups={n:load(n) for n in names};regs={(n,e['id']):e for n,r in groups.items() for e in r['entries']}
for x in history['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
raw=gun('history/original-registry.json.gz');assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';registry=json.loads(raw)
raw=gun('history/original-transport-manifest.json.gz');assert sha(raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';idx={x['path']:x for x in json.loads(raw)['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[2819,2820,2821,2822]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==registry['files'][x['original_index']]
for x in sel['snapshots']:assert x in registry['snapshots']
pr=next(x for x in registry['snapshots'] if x['id']=='pr-working');p16=next(x for x in registry['snapshots'] if x['id']=='physical-p16');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4;assert p16['base']==p16['head']=='a120390947c89b703dc74c4255a13c035d054c50' and len(p16['status_porcelain'])==159
patch=(b/'history/p16-tracked.patch').read_bytes();recovery=load('history/p16-patch-recovery.json');assert len(patch)==524542 and sha(patch)==p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and recovery['recovered_patch']['sha256']==sha(patch);assert recovery['live_comparison']['original_report_sha256']!=recovery['live_comparison']['published_report_sha256']==sha((b/'history/p16-live-comparison-redacted.json').read_bytes())
for (name,id),x in regs.items():
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'] and oid('blob',d)==x['git_blob']
for role,ranges in [(2819,[[1,75]]),(2820,[[1,18]]),(2821,[[1,88]]),(2822,[[1,88]])]:
 old=regs[('registration.json',str(role)+'-historical')];cur=regs[('registration.json',str(role)+'-current')];assert old['sha256']==registry['files'][role]['sha256'] and old['original_registry_material_ranges']==ranges==registry['files'][role]['material_ranges'];assert old['individual_base_file_equal']
 if role in (2819,2820):assert old['sha256']==cur['sha256']
 else:assert old['sha256']!=cur['sha256']
assert regs[('registration.json','2821-historical')]['historical_snapshot']=='physical-p16' and regs[('registration.json','2822-historical')]['historical_snapshot']=='pr-working' and regs[('registration.json','2821-historical')]['sha256']==regs[('registration.json','2822-historical')]['sha256']
q=json.loads(gun('history/baseline-059-queue.json.gz'))['entries'];selection=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in selection['entries']]==[1399,1400,1560]
for x in selection['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[1560]['contract_id']=='Q-L12-1d38d69a4d3f33d858ec'
for x in history['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
for path,spec in [('history/059/segovb/READ-L11-458.json',[(2819,[[1,75]])]),('history/059/segovb/READ-L11-459.json',[(2820,[[1,18]]),(2821,[[1,88]]),(2822,[[1,88]])])]:
 r=load(path)
 for role,ranges in spec:
  e=next(x for x in r['sources'] if x['original_index']==role);assert e['fresh_personal_body_reads']==e['assessed_ranges']==ranges and e['sha256']==registry['files'][role]['sha256']
for x in history['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
for x in history['registration_file_hash_mismatches']:
 e=registry['files'][x['role']]['scope_registration'][0];p='history/774/'+e['record'].removeprefix('continuation/')+'.gz';raw=gun(p);rows=[json.loads(z) for z in raw.splitlines()];assert sha(raw)==x['f82_whole_file_sha256']!=e['sha256']==x['registry_recorded_whole_file_sha256'] and rows[e['row_1based']-1]==e['original_record']
camera='history/774/camera/initial07-redundant-authority/';quals=[json.loads(z) for z in gun(camera+'qualifications.jsonl.gz').splitlines()];qual=next(x for x in quals if x.get('id')=='CAMERA-INITIAL07-QUAL159');assert qual['new_material_effective_ranges']=={'CAMERA-INITIAL07-REG033':[[1,18]],'CAMERA-INITIAL07-REG034':[[1,88]],'CAMERA-INITIAL07-REG035':[[1,88]]}
c=[json.loads(z) for z in gun(camera+'contracts.jsonl.gz').splitlines()];assert all(any(x.get('id')==i for x in c) for i in ['CAMERA-INITIAL07-CONTRACT-181','CAMERA-INITIAL07-CONTRACT-191','CAMERA-INITIAL07-CONTRACT-248']);assert json.loads(gun('history/774/native/initial05-aggregate-states/contract-groups-124.json.gz'))['id']=='NATIVE-INITIAL05-GROUP-124'
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
assert len(proof['paths'])==32
coverage={}
def record(regname,id,chunks,unread,when,recorded_sha):
 x=regs[(regname,id)];assert datetime.fromisoformat(groups[regname]['at_utc'])<datetime.fromisoformat(when) and recorded_sha==x['sha256'];actual={i for a,z in chunks for i in range(a,z+1)};planned={i for a,z in x['prospective_personal_read_ranges'] for i in range(a,z+1)};remaining={i for a,z in unread for i in range(a,z+1)};assert actual==planned and actual.isdisjoint(remaining) and actual|remaining==set(range(1,x['eof']+1));coverage.setdefault(id,set()).update(actual)
a=load('read-receipt.json');assert a['registration_sha256']==sha((b/'registration.json').read_bytes())
for e in a['entries']:record('registration.json',e['id'],e['actual_display_chunks'],e['unread_complement'],a['at_utc'],e['sha256'])
s=load('support-read-receipt.json')
for x in s['registrations']:assert x['sha256']==sha((b/x['path']).read_bytes())
for e in s['entries']:record(e['registration'],e['id'],e['actual_display_chunks'],e['unread_complement'],s['at_utc'],e['sha256'])
assert len(regs)==len(coverage)==17
def inspect(x):
 if isinstance(x,dict):
  if all(k in x for k in ['id','archive','lines','sha256']):
   assert any(e['id']==x['id'] and e['sha256']==x['sha256'] and e['archive']==x['archive'] for e in regs.values());assert all(set(range(a,z+1))<=coverage[x['id']] for a,z in x['lines'])
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report);assert len(report['thirteen_lens_dispositions'])==13 and len({x['lens'] for x in report['thirteen_lens_dispositions']})==13
print(json.dumps({'status':'PASS','original_roles':[2819,2820,2821,2822],'personal_scopes':len(regs),'p16_and_pr_plugin_roles_distinct':True,'current_plugin_changed':True,'059_records_manifest_matched':len(history['records_059']),'774_records_git_proved':len(history['records_774']),'historical_registration_whole_file_mismatches':'preserved; selected rows match','git_paths_proved':len(proof['paths']),'p16_tracked_patch_digest_verified':True,'p16_reproduction_limit':'No original command, seven untracked files, uninterrupted custody or whole snapshot cleanliness implied','bounded_lenses':13,'product_build_test_fixture_simulation_probe_validation':'not performed'},indent=2))
