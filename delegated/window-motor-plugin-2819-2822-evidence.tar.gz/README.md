# Window, controller configuration and plugin roles 2819–2822

`REPORT.json` contains this bounded source audit, thirteen lens perspectives,
connections to earlier window/frame and motor contracts, and the unresolved
current presentation-solver scheduling question. It records no new accepted
unique count. No product, physics simulation, fixture, test, build or runtime
probe was performed, and no repair or publication source was edited.

The historical P16 and pr-working plugin roles are separate identities even
though their exact source bytes match. Both historical role bodies and both
current bodies were registered and personally displayed separately. The 95e
plugin has a changed presentation branch; the window and controller files have
unchanged individual bodies. P16 historical file bodies match individual files
at clean base `a120390947c89b703dc74c4255a13c035d054c50`; this does not make
the recorded dirty P16 snapshot that commit or a clean tree. Pr-working file
identities match `6533e444fa37552927070cc8d8190907fd3b413e`, whose recorded
working snapshot had unrelated changes. Current source is pinned at
`95e63628f9d70b8dd6e6fede64334696c6995009`; f82 is transport only.

`registration.json` and `read-receipt.json` retain independent historical and
current displays and original material ranges. `support-registration*.json`
and `support-read-receipt.json` preserve independently displayed current
support and its unread complements. Test bodies and fixture construction text
were inspected only as source, without execution.

`history/` retains the exact original recovered registry and extraction
manifest, selected 059 reviewer records, losslessly compressed historical 059
queue/ledger, exact 774 records, earlier window assessments, and the later
matching P16 tracked patch reproduction. Its SHA matches the original registry,
but this cannot prove the original invocation or uninterrupted custody and
excludes the seven separately archived untracked files. The preserved public
live-comparison record is a redacted reconstruction, with distinct original
and public hashes in the recovery report. Reconstructed row selections are
identified. Original selected 774 registration rows match embedded registry
records, while whole-file registration hashes differ; cause unknown. No record
is promoted to missing checkpoint 3821.

`git-proofs.json` and `git-objects/` retain exact Git commit/tree evidence for
assigned bodies, registered support, applicable rules and transported original
774 records. Run `python3 verify-evidence.py` and `python3 verify-manifest.py`
for evidence integrity only; they do not validate a product behavior.
