from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();p='crates/adventuresim-tactical-core/src/'
specs=[('motor',p+'physics.rs',[[320,430]]),('config',p+'combat_config.rs',[[220,310],[430,510]]),('window-pose',p+'scene_coordinates/window.rs',[[1,100]]),('server-window','crates/adventuresim-tactical-server/src/windows.rs',[[1,150]]),('direction','crates/adventuresim-building-generator/src/spatial_geometry/orientation.rs',[[110,142]])];entries=[]
for id,path,ranges in specs:
 raw=g('show',rev+':'+path);n=len(raw.splitlines());assert max(z for a,z in ranges)<=n;dest=f'support/{id}.rs';(b/dest).parent.mkdir(exist_ok=True);(b/dest).write_bytes(raw);entries.append({'id':id,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'prospective_personal_read_ranges':ranges,'qualification':'Independent 95e bounded support only, no assigned role, historical or past reviewer credit. No tests, fixtures or runtime executed.'})
out={'schema':'726-window-motor-support-prospective-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':entries};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print('registered',len(entries))
