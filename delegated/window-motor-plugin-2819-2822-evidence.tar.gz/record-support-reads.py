from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;names=['support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json'];spec={'motor':([[320,375],[376,430]],[[1,319],[431,1738]]),'config':([[220,310],[430,510]],[[1,219],[311,429],[511,779]]),'window-pose':([[1,100]],[[101,136]]),'server-window':([[1,75],[76,150]],[[151,294]]),'direction':([[110,142]],[[1,109]]),'config-context':([[1,80],[417,429],[710,735]],[[81,416],[430,709],[736,779]]),'config-runtime':([[1,98]],[]),'config-defaults':([[1,26]],[]),'grab':([[1,60]],[[61,132]])};entries=[];registrations=[]
for n in names:
 raw=(b/n).read_bytes();reg=json.loads(raw);registrations.append({'path':n,'sha256':hashlib.sha256(raw).hexdigest(),'at_utc':reg['at_utc']})
 for x in reg['entries']:
  chunks,unread=spec[x['id']];entries.append({'registration':n,'id':x['id'],'sha256':x['sha256'],'actual_display_chunks':chunks,'unread_complement':unread,'qualification':'Independently displayed registered bounded current support; test text only, no other reviewer or role credit.'})
r={'schema':'726-window-motor-support-actual-reads-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'registrations':registrations,'entries':entries};(b/'support-read-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('recorded',len(entries))
