import gzip,hashlib,json,pathlib
src=pathlib.Path('<LOCAL_PATH_0>');pub=pathlib.Path('<LOCAL_PATH_1>');out=pathlib.Path('<LOCAL_PATH_2>')
with gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt') as f:entries={e['path']:e for e in json.load(f)['entries']}
paths=['adler/READ-L11-385.json','adler/READ-L11-386.json','adler/STATE-L11-386.json','adler/VERIFY-L11-386.json','adler/REGISTRATION-ADLER-1251.json','adler/REGISTRATION-ADLER-1253.json','adler/READ-L11-394.json']
for i in [793,794]:paths += [f'segovb/READ-L12-{i}.json',f'segovb/REGISTRATION-SEGOVB-L12-{i}.json',f'segovb/VERIFY-L12-{i}.json',f'parallel-l12-20261029/PROPOSAL-L12-{i}.json']
paths+=['parallel-l12-20261029/REGISTRATION-PAR-L12-373.json','parallel-l12-20261029/REGISTRATION-PAR-L12-376.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-373-WINDOWS-ORIGINAL2381.json','parallel-l12-20261029/QUALIFIED-REUSE-PAR-L12-794-TERRAIN-OWNER.json']
rows=[];missing=[]
for path in paths:
 if path not in entries or not (src/path).is_file():missing.append(path);continue
 b=(src/path).read_bytes();e=entries[path];h=hashlib.sha256(b).hexdigest();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert (h,len(b),blob)==(e['sha256'],e['bytes'],e['git_blob']),path
 dst=out/'historical'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);rows.append({'original_transport_path':path,'bytes':len(b),'sha256':h,'git_blob':blob,'copy_path':'historical/'+path})
o={'schema':'delegated-recovered-historical-evidence-v1','qualification':'Exact copies from read-only original extraction checked against original transport SHA-256, length and Git blob. Preserve original reviewer, revision, scopes and open statuses; never promote to checkpoint3821 or current personal reads.','records':rows,'unavailable':missing};f=out/'historical-manifest.json';f.write_text(json.dumps(o,indent=2)+'\n');print('verified',len(rows),'missing',missing,'manifest',hashlib.sha256(f.read_bytes()).hexdigest())
ref=out/'reference';ref.mkdir(exist_ok=True)
refs=[('<LOCAL_PATH_3>','registry.json.gz','exact original registry'),('<LOCAL_PATH_4>','original-transport-manifest.json.gz','exact original transport manifest'),('<LOCAL_PATH_5>','queue-059.json.gz','losslessly compressed 059 queue, not checkpoint3821'),('<LOCAL_PATH_6>','strategic-web-AGENTS-95e.md','current governing rules'),('<LOCAL_PATH_7>','prior-web-residence-report.json','same agent earlier registered preview support but no personal display'),('<LOCAL_PATH_8>','prior-web-residence-support-registration-01.json','same agent earlier registered preview object only'),(str(pub/'ASSESSMENT-L1-INVENTORY-FRACTION.json'),'prior-assessment-inventory-fraction.json','prior c100 assessment; earlier bounded preview read 1–15'),(str(pub/'source-evidence/inventory-fraction/current/crates/strategic-web/src/routes/settlements/rest_preview.rs.gz'),'prior-rest-preview-c100.source.gz','prior c100 exact compressed preview source'),(str(pub/'ASSESSMENT-L01-ITINERARY-CLOCK-95E.json'),'prior-assessment-itinerary-clock-95e.json','prior current MAX clock nonprogress assessment'),(str(pub/'main-advance-95e/itinerary-sources/02.source.gz'),'prior-travel-clock-95e.source.gz','prior current exact compressed travel source'),(str(pub/'ASSESSMENT-SHORT-ROUTE-HEIGHTFIELD-95E.json'),'prior-assessment-short-route-95e.json','prior current same-snapped-node route assessment')]
rs=[]
for source,name,cl in refs:
 s=pathlib.Path(source)
 if not s.is_file():print('unavailable reference',source);continue
 b=s.read_bytes();(ref/name).write_bytes(b);rs.append({'source':source,'copy':'reference/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'classification':cl})
f=ref/'manifest.json';f.write_text(json.dumps({'records':rs},indent=2)+'\n');print('references',len(rs),'sha256',hashlib.sha256(f.read_bytes()).hexdigest())
