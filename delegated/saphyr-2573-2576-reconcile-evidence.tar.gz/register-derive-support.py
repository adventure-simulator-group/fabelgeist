import datetime,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();source=pathlib.Path('<LOCAL_PATH_0>');archive='source/serde_derive-1.0.229.crate';raw=source.read_bytes();(p/archive).write_bytes(raw);entries=[]
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
 for tag,member,ranges in [('derive-attr.rs','serde_derive-1.0.229/src/internals/attr.rs',[[1085,1102]]),('derive-de.rs','serde_derive-1.0.229/src/de.rs',[[755,780]]),('derive-struct.rs','serde_derive-1.0.229/src/de/struct_.rs',[[305,330]])]:
  b=tar.extractfile(member).read();dest='source/'+tag;(p/dest).write_bytes(b);entries.append({'kind':'native-support','tag':tag,'package_member':member,'archive':dest,'sha256':sha(b),'git_blob':blob(b),'EOF':len(b.splitlines()),'registered_ranges':ranges})
path='source/root-current.lock';body=(p/path).read_text().splitlines();starts=[i for i,x in enumerate(body) if x=='[[package]]'];matched=[]
for i,s in enumerate(starts):
 end=starts[i+1] if i+1<len(starts) else len(body);v=tomllib.loads('\n'.join(body[s:end]))['package'][0]
 if v['name']=='serde_derive' and v['version']=='1.0.229':
  while end>s and not body[end-1].strip():end-=1
  matched.append((v,[s+1,end]))
assert len(matched)==1 and matched[0][0]['checksum']==sha(raw);b=(p/path).read_bytes();entries.append({'kind':'project-lock-support','tag':'serde-derive-current-lock','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','path':'Cargo.lock','archive':path,'sha256':sha(b),'git_blob':blob(b),'EOF':len(body),'registered_ranges':[matched[0][1]],'metadata_package':matched[0][0]})
(p/'derive-support-registration.json').write_text(json.dumps({'author':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'package':{'name':'serde_derive','version':'1.0.229','archive':archive,'sha256':sha(raw),'bytes':len(raw)},'entries':entries,'qualification':'Independent source-only macro implementation support for the separately attributed Options default candidate. No macro, deserializer, parser or product executed; resolved features and an actual Options ingestion remain unproved.'},indent=2)+'\n');print('registration',sha((p/'derive-support-registration.json').read_bytes()),'lock range',matched[0][1],'package',sha(raw))
