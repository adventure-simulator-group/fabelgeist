# Bounded serde-saphyr reconciliation evidence

This packet supplements checkpoint 13 for original native roles 2573–2576.
Start with `report.json`, `registration.json`, the two read receipts, and
`unregistered-view-qualification.json`. Source files and crates are evidence:
only registered, personally displayed ranges have prospective read credit, and
one later accidental options.rs header view is expressly uncredited.

`059-reconstructed-selection.json` extracts three exact semantic queue records
and their journal references from the separately retained 059 queue and ledger;
`historical-index.json` identifies original 059 and f82-transferred 774 files.
The original and public-redacted representations are not interchangeable.
`history-pin-qualification.json` retains the historical registration mismatch.
Previous delegate reports and manifests are selected originals, with their own
reader and scope, rather than transferred credit. Project Git paths are proved
with raw commit/tree objects in `git-proofs.json`; native archive identities
are independently verified against selected lock metadata.

`verification.json` is an evidence-integrity check, not product validation.
Run `python3 verify-evidence.py` read-only for this packet's offline checks and
`python3 verify-manifest.py` for its frozen file inventory. No parser, product,
macro, test, build, fixture, renderer, simulation or probe is executed by these
checks. This packet neither closes a lens nor decides repair/alias counts.
It contains exact recovered local records, potentially including local paths;
publication must preserve the already documented redaction qualifications.
