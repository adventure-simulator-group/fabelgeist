import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes());counts={}
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and set(sel['roles'])=={'1530','2573','2574','2575','2576'} and all(v==reg['files'][int(k)] for k,v in sel['roles'].items())
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256'],e['file']
for label,rf,tf in [('initial','registration.json','read-receipt.json'),('derive_support','derive-support-registration.json','derive-support-read-receipt.json')]:
 a=load(rf);t=load(tf);assert t['registration_sha256']==sha((p/rf).read_bytes()) and datetime.datetime.fromisoformat(t['receipt_utc'])>datetime.datetime.fromisoformat(a['registered_utc']);assert len(a['entries'])==len(t['entries'])
 for e,v in zip(a['entries'],t['entries']):
  b=(p/e['archive']).read_bytes();assert sha(b)==e['sha256']==v['sha256'] and len(b.splitlines())==e['EOF'] and e['archive']==v['archive'] and blob(b)==e['git_blob'];planned={i for lo,hi in e['registered_ranges'] for i in range(lo,hi+1)};seen={i for lo,hi in v['displayed_chunks'] for i in range(lo,hi+1)};missing={i for lo,hi in v['unread_complement'] for i in range(lo,hi+1)};assert planned==seen and seen|missing==set(range(1,e['EOF']+1)) and not seen&missing
  if e.get('role'):assert e['sha256']==reg['files'][e['role']]['sha256'] and e['original_material_ranges']==reg['files'][e['role']]['material_ranges']
 counts[label]=len(a['entries'])
a=load('registration.json');d=load('derive-support-registration.json');packages={x['name']+'-'+x['version']:x for x in a['packages']+[d['package']]}
for package in packages.values():assert sha((p/package['archive']).read_bytes())==package['sha256']
for e in a['entries']+d['entries']:
 if 'package_member' in e:
  pkg=e.get('package','serde_derive-1.0.229');archive=(p/packages[pkg]['archive']).read_bytes()
  with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:assert t.extractfile(e['package_member']).read()==(p/e['archive']).read_bytes()
for e in a['entries']:
 if e['kind']=='project-lock':
  pkgs=tomllib.loads((p/e['archive']).read_text())['package']
  for m in e['metadata_packages']:
   x=[z for z in pkgs if z['name']==m['name'] and z['version']==m['version']];assert len(x)==1 and x[0]['source']==m['source'] and x[0]['checksum']==m['checksum']==packages[m['name']+'-'+m['version']]['sha256']
  if e['tag']=='root-current.lock':
   m=d['entries'][-1]['metadata_package'];x=[z for z in pkgs if z['name']==m['name'] and z['version']==m['version']];assert len(x)==1 and x[0]['source']==m['source'] and x[0]['checksum']==m['checksum']==packages[m['name']+'-'+m['version']]['sha256']
for label in ('hair','scalar'):
 x=load('prior-'+label+'-index.json');manifest=(p/('prior-'+label)/x['original_manifest']).read_bytes();assert sha(manifest)==x['manifest_sha256'];idx={z['path']:z for z in json.loads(manifest)['files']}
 for e in x['selected_files']:
  b=(p/('prior-'+label)/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(idx[e['path']]['bytes'],idx[e['path']]['sha256'])
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']}
hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for owner,lens,n in [('adler','L11',217),('segovb','L11',423),('segovb','L12',874)]:
 read=(p/f'history-059/{owner}/READ-{lens}-{n}.json').read_bytes();state=(p/f'history-059/{owner}/STATE-{lens}-{n}.json').read_bytes();v=load(f'history-059/{owner}/VERIFY-{lens}-{n}.json');assert v['receipt_sha256']==sha(read) and v['state_sha256']==sha(state)
read=load('history-059/segovb/READ-L11-423.json')
for e in read['sources']:
 rel=e['registration'].split('target/726-audit-adler-20261027/',1)[1];assert e['registration_sha256']==sha((p/'history-059'/rel).read_bytes())
read=load('history-059/segovb/READ-L12-874.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes())
for e in read['rows']:
 if e['original_index'] not in (2575,2576):continue
 assert e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes())
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());lraw=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());q=json.loads(qraw);l=json.loads(lraw);x=load('059-reconstructed-selection.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw) and all(q['entries'][int(i)]==v for i,v in x['queue_entries'].items()) and all(l['segovb_continuation']['lens12']['pending_connected_contracts'][int(i)]==v for i,v in x['journal_entries'].items())
pin=load('history-pin-qualification.json');rec=json.loads(gzip.decompress((p/'history-774/admission03-scope-reconciliation-046.json.gz').read_bytes()));assert rec['input_pins'][0]['sha256']==pin['earlier_046_registration_pin']!=sha((p/'history-774/reconstructed-first-18-registration.jsonl').read_bytes())==pin['later_registration_first_18_sha256'];assert rec['input_pins'][1]['sha256']==pin['earlier_046_qualification_pin']==sha((p/'history-774/reconstructed-first-10-qualification.jsonl').read_bytes())==pin['later_qualification_first_10_sha256'];assert sha(gzip.decompress((p/'history-774/admission03/source-range-registration.jsonl.gz').read_bytes()))==pin['later_f82_registration_whole_sha256'] and sha(gzip.decompress((p/'history-774/admission03/source-qualifications.jsonl.gz').read_bytes()))==pin['later_f82_qualification_whole_sha256']
unregistered=load('unregistered-view-qualification.json');assert unregistered['displayed_ranges']==[[1,5]] and unregistered['source_sha256']==sha((p/unregistered['source']).read_bytes());assert all(not (a<=1<=b) for e in a['entries'] if e.get('role')==2574 for a,b in e['registered_ranges'])
qual=load('reference/QUALIFICATION-13-SAPHYR-ARCHIVE.json');assert qual['original_sha256']==packages['serde-saphyr-1.2.0']['sha256'] and qual['published_reconstructed_sha256']=='79c59c039419ec677602b8fa34d04ab906c0f29bdd7692109ef9b0745690f63a' and qual['original_sha256']!=qual['published_reconstructed_sha256']
pubqual=load('reference/DELEGATED-CHECKPOINT-13-QUALIFICATION.json');matched=0
for z in pubqual['entries']:
 for rel in z['original_transport_paths']:
  candidate=p/'history-059'/rel
  if candidate.is_file():
   assert sha(candidate.read_bytes())==z['original_sha256'] and all(copy['public_sha256']!=z['original_sha256'] for copy in z['public_reconstructed_copies']);matched+=1
assert matched>=4
report=load('report.json');assert report['scope']['roles'][1]['actual_unseen_complement']==[[6,144],[171,239],[271,489],[536,760]]
quals={z['registration_id_resolved']:z['original_record'] for z in rec['role_qualifications'] if z.get('supplier')=='root' and 'registration_id_resolved' in z}
for role in report['scope']['roles']:
 for row in role['774_root_prospective_and_effective_material']:
  x=quals[row['registration']];assert x['original_prospective_ranges']==row['prospective'] and x['effective_material_ranges']==row['qualified']
rawreg=gzip.decompress((p/'history-774/admission03/source-range-registration.jsonl.gz').read_bytes());rawqual=gzip.decompress((p/'history-774/admission03/source-qualifications.jsonl.gz').read_bytes());assert b''.join(rawreg.splitlines(keepends=True)[:18])==(p/'history-774/reconstructed-first-18-registration.jsonl').read_bytes() and b''.join(rawqual.splitlines(keepends=True)[:10])==(p/'history-774/reconstructed-first-10-qualification.jsonl').read_bytes()
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==18 and len(report['lens_perspectives'])==13 and [z['queue_index'] for z in report['historical_relations']['selected_059_queue']]==[72,1303,1313]
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(hist['records']),'prior_packets':2,'lens_perspectives':13,'qualification':'Offline evidence integrity only: native archives/member identities, bounded personal displays and complements, selected 059/774 provenance, previous frozen manifest hashes, pin qualification and Git path proofs; no Cargo resolution, parsing, product execution, macro, tests or runtime.'},indent=2))
