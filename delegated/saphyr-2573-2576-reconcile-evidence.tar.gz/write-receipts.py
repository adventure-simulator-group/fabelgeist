import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def comp(n,ranges):
 nums=set(range(1,n+1))-{i for a,z in ranges for i in range(a,z+1)};out=[]
 for i in sorted(nums):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for reg,dst in [('registration.json','read-receipt.json'),('derive-support-registration.json','derive-support-read-receipt.json')]:
 x=json.loads((p/reg).read_bytes());rows=[]
 for e in x['entries']:
  chunks=[[260,305],[306,350]] if e['archive']=='source/2576.rs' else e['registered_ranges'];rows.append({'archive':e['archive'],'role':e.get('role'),'kind':e['kind'],'sha256':e['sha256'],'displayed_chunks':chunks,'unread_complement':comp(e['EOF'],chunks)})
 (p/dst).write_text(json.dumps({'author':'/root/mhr_character','receipt_utc':now,'registration':reg,'registration_sha256':sha((p/reg).read_bytes()),'entries':rows,'qualification':'Actual independent numbered untruncated displays after prospective registration. Archived bytes and metadata scans are not full-body personal reading; prior readers retain separate attribution.'},indent=2)+'\n')
