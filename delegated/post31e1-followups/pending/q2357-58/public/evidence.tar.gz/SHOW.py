import datetime,hashlib,json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent
name=sys.argv[1];lo=int(sys.argv[2]);hi=int(sys.argv[3]);regname=sys.argv[4]
reg=json.loads((p/regname).read_text());items=[x for x in reg["items"] if x["file"]==name and [lo,hi] in x["display_ranges"]]
if len(items)!=1:raise ValueError("window not registered")
raw=(p/name).read_bytes()
if hashlib.sha256(raw).hexdigest()!=items[0]["sha256"]:raise ValueError("source mismatch")
lines=raw.decode().splitlines()
if not 1<=lo<=hi<=len(lines):raise ValueError("out of bounds")
v="".join(f"{i:6}\t{lines[i-1]}\n" for i in range(lo,hi+1))
nameout=f"DISPLAY-V2-{pathlib.Path(name).stem}-{lo}-{hi}.txt"
with (p/nameout).open("x") as out:out.write(v)
r={"registration":regname,"source":name,"range":[lo,hi],"display":nameout,"view_sha256":hashlib.sha256(v.encode()).hexdigest(),"displayed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"truncated":False}
with (p/(nameout+".receipt.json")).open("x") as out:out.write(json.dumps(r,indent=2)+"\n")
print(v,end="")
