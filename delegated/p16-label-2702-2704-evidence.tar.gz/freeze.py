import gzip,hashlib,json,pathlib,shutil,subprocess,tarfile,datetime
p=pathlib.Path(__file__).parent;pub=pathlib.Path('<LOCAL_PATH_0>');old=pathlib.Path('<LOCAL_PATH_1>');git=lambda *x:subprocess.check_output(['git','-C',str(pub),*x]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();a='a120390947c89b703dc74c4255a13c035d054c50';c='039329518e264f19206cf5b0b98d177433f40c17';f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';(p/'reference').mkdir(exist_ok=True);idx=[]
for src,dst in [('recovered/original-registry-source-archive/registry.json.gz','registry.json.gz'),('recovered/original-registry-source-archive/objects.tar.gz','objects.tar.gz'),('recovered/original-registry-source-archive/MANIFEST.json','original-source-manifest.json'),('recovered/original-transport-manifest.json.gz','original-transport-manifest.json.gz'),('recovered/physical-p16-patch-recovery/tracked.patch','p16-tracked.patch'),('RECOVERY-PHYSICAL-P16-PATCH-20261111.json','p16-patch-recovery.json')]:
 b=(pub/src).read_bytes();(p/'reference'/dst).write_bytes(b);idx.append({'file':'reference/'+dst,'publication_path':src,'sha256':sha(b),'bytes':len(b)})
(p/'reference-index.json').write_text(json.dumps({'records':idx},indent=2)+'\n');raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';j=json.loads(raw);snap=next(x for x in j['snapshots'] if x['id']=='physical-p16');assert len(snap['status_porcelain'])==159 and snap['base']==snap['head']==a;manifest=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));mi={x['path']:x for x in manifest['entries']};(p/'history-059').mkdir(exist_ok=True);h059=[]
for rel in ['segovb/READ-L11-441.json','segovb/REGISTRATION-SEGOVB-1621.json','segovb/REGISTRATION-SEGOVB-1622.json','segovb/REGISTRATION-SEGOVB-1623.json','parallel-l12-20261029/REGISTRATION-PAR-L12-769.json','parallel-l12-20261029/PARTIAL-PAR-L12-940-001.json']:
 b=(old/rel).read_bytes();e=mi[rel];assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']);dst=p/'history-059'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);h059.append({'transport_path':rel,'file':str(dst.relative_to(p)),'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
(p/'git-objects').mkdir(exist_ok=True);objects={}
def data(t,oid):
 b=git('cat-file',t,oid);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=p/'git-objects'/f'{oid}.{t}.gz';dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'archive':str(dst.relative_to(p)),'bytes':len(b),'sha256':sha(b)}
 return b
def parse(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
def root(rev):return data('commit',rev).splitlines()[0].split()[1].decode()
def compare(oa,ob,prefix=''):
 left=parse(data('tree',oa)) if oa else {};right=parse(data('tree',ob)) if ob else {};out=[]
 for name in sorted(left.keys()|right.keys()):
  x,y=left.get(name),right.get(name);path=prefix+name
  if x==y:continue
  if (x is None or x[0]=='40000') and (y is None or y[0]=='40000'):
   out+=compare(x[1] if x else None,y[1] if y else None,path+'/');continue
  assert x is None or x[0]!='40000';assert y is None or y[0]!='40000';out.append({'path':path,'status':'A' if x is None else 'D' if y is None else 'M','old_mode':x[0] if x else None,'old_blob':x[1] if x else None,'new_mode':y[0] if y else None,'new_blob':y[1] if y else None})
 return out
rt_a=root(a);rt_c=root(c);changes=compare(rt_a,rt_c);expected={(('A' if x[:2]=='??' else x[:2].strip()),x[3:]) for x in snap['status_porcelain']};assert len(changes)==len(expected)==159 and {(x['status'],x['path']) for x in changes}==expected
lookup={}
for x in j['files']:
 if x.get('source_id','').startswith('physical-p16:') and x.get('sha256'):lookup.setdefault(x['source_id'].split(':',1)[1],set()).add(x['sha256'])
with tarfile.open(p/'reference/objects.tar.gz','r:gz') as tar:
 for x in changes:
  if x['status']=='D':continue
  candidates=lookup.get(x['path'],set());found=[]
  for h in candidates:
   b=tar.extractfile(h).read()
   if sha(b)==h and blob(b)==x['new_blob']:found.append(h)
  assert len(found)==1;x['registry_sha256']=found[0]
assert sum(x['status']!='D' for x in changes)==158
paths=[x[3:] for x in snap['status_porcelain'] if x[:2]!='??'];diff=git('diff','--binary',a,c,'--',*paths);(p/'reference/039-tracked-diff.patch.gz').write_bytes(gzip.compress(diff,mtime=0));recovered=(p/'reference/p16-tracked.patch').read_bytes();assert sha(recovered)==snap['patch_sha256']
def sections(d):return {x.split(b'\n',1)[0].decode():b'diff --git '+x for x in d.split(b'diff --git ')[1:]}
x,y=sections(diff),sections(recovered);assert len(x)==len(y)==152 and x.keys()==y.keys();different=sorted(k for k in x if x[k]!=y[k]);assert different==['a/Cargo.lock b/Cargo.lock'] and b'GIT binary patch' in y[different[0]] and b'GIT binary patch' not in x[different[0]]
proofs=[]
def prove(rev,path,archive,encoding=None):
 tree=root(rev);rootid=tree;chain=[]
 for name in path.split('/'):
  mode,obj=parse(data('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':obj});tree=obj
 b=(p/archive).read_bytes();b=gzip.decompress(b) if encoding=='gzip' else b;assert blob(b)==tree;proofs.append({'revision':rev,'path':path,'archive':archive,'encoding':encoding,'sha256':sha(b),'blob':tree,'commit_tree':rootid,'chain':chain})
(p/'source').mkdir(exist_ok=True)
for i in [2702,2703,2704]:
 row=j['files'][i];path=row['source_id'].split(':',1)[1];tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];b=git('show',f82+':'+tp);assert sha(b)==row['sha256'];dst=f'source/{i}.rs';(p/dst).write_bytes(b);prove(f82,tp,dst);prove(c,path,dst);prove(a,path,dst)
for path,dest in [('handoff/774/audit/reconcile-adler-20261023/recovered-sources/catalog.json','history-774/catalog.json.gz'),('handoff/774/adler-original/audit/continuation/root/admission03/source-range-registration.jsonl','history-774/root-range-registration.jsonl.gz'),('handoff/774/adler-original/audit/continuation/root/admission03/source-qualifications-final-current.jsonl','history-774/root-qualifications.jsonl.gz')]:
 b=git('show',f82+':'+path);dst=p/dest;dst.parent.mkdir(exist_ok=True);dst.write_bytes(gzip.compress(b,mtime=0));prove(f82,path,dest,'gzip')
(p/'git-proofs.json').write_text(json.dumps({'objects':objects,'proofs':proofs,'tree_comparison':{'base_revision':a,'base_tree':rt_a,'p16_preservation_revision':c,'preservation_tree':rt_c,'changes':changes},'qualification':'Comparison proves exact Git tree entries and source blob equality to archived registry objects; no source read, chronology, filesystem metadata or label equivalence follows automatically.'},indent=2)+'\n');cat=json.loads(gzip.decompress((p/'history-774/catalog.json.gz').read_bytes()));roles=[]
for i in [2702,2703,2704]:
 row=j['files'][i];catalog=next(x for x in cat['rows'] if x.get('scope_index')==i);assert catalog['source_id']==row['source_id'] and catalog['snapshot']==row['snapshot']=='p16' and catalog['expected_sha256']==row['sha256'];roles.append({'original_index':i,'original_registry_row':row,'original_catalog_row':catalog})
report={'schema':'726-p16-snapshot-label-investigation-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/mhr_character','finding':'The exact original roles use source_id physical-p16 but snapshot p16 and a SNAPSHOTS/p16 path; the snapshot list has physical-p16, not p16. Strong object, commit and 159-path evidence supports a common P16 historical material, but no explicit label mapping is established. Retain both spellings and qualify the inference.','roles':roles,'snapshot_list_ids':[x['id'] for x in j['snapshots']],'physical_p16_snapshot':snap,'preservation_commit':{'revision':c,'parent':a,'source':'raw commit in git-proofs.json','recorded_message':'Preserve #774 unfinished p16 work for developer handoff [skip ci]; recovery snapshot only, not source-complete, validated or integrated.'},'tree_comparison':{'proof':'git-proofs.json','path_statuses_match':159,'modified':151,'deleted':1,'added':7,'changed_existing_blob_sha256_match_original_registry':158,'unchanged_assigned_roles_match_base_and_preservation':3,'limits':'Names, statuses, Git tree modes and archived content identities only; historical actual filesystem modes, time, whole worktree custody or automatic label normalization are not inferred.'},'patch_format':{'recorded_tracked_sha256':sha(recovered),'recorded_tracked_bytes':len(recovered),'preservation_git_diff_sha256':sha(diff),'preservation_git_diff_bytes':len(diff),'both_changed_path_sections':152,'exact_section_matches':151,'different_section':'Cargo.lock','difference':'Recorded tracked patch expresses Cargo.lock as GIT binary patch, while the preservation-commit diff uses text hunks. Recorded 039 Cargo.lock blob matches the original registry SHA; patch streams are not byte-identical. Do not infer a source mismatch or an original command from this formatting difference.','qualification':'Neither patch was applied and no product was executed.'},'history_059':h059,'limitations':['No explicit original p16-to-physical-p16 snapshot-list normalization was found in inspected registry/catalog records.','f82 transports recovered source and review records; it is not the source revision.','Recorded historical P16 was dirty; 039 is a later preservation commit and not an original clean source HEAD.','The 059 1621–1623 records and READ-L11-441 retain original reviewer and material scopes, not transferred into 3821 or other lenses.','No product execution, test, build, repair, probe, simulation or modification of prior frozen packets.']};(p/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('changes',len(changes),'matched',sum(x['status']!='D' for x in changes),'proofs',len(proofs),'objects',len(objects),'patch',sha(diff))
