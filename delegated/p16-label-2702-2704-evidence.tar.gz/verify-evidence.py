#!/usr/bin/env python3
"""Offline evidence and Git-object integrity only; no product code."""
import gzip,hashlib,json,pathlib,tarfile
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda x:json.loads((p/x).read_bytes());checks=[]
for x in load('reference-index.json')['records']:
 b=(p/x['file']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';r=json.loads(raw);assert sha((p/'reference/objects.tar.gz').read_bytes())=='794e0b45957709e304ee8e7d9e98f1390c1786644ac4f02891dbaea75e025824' and sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';snap=next(x for x in r['snapshots'] if x['id']=='physical-p16');assert not any(x['id']=='p16' for x in r['snapshots']) and snap['base']==snap['head']=='a120390947c89b703dc74c4255a13c035d054c50' and len(snap['status_porcelain'])==159
assert [i for i,x in enumerate(r['files']) if x.get('snapshot')=='p16']==[2689,2690,2691,2702,2703,2704];checks.append('Original registry and exact mixed labels, physical-p16 base and dirty status, preserved archived objects')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];d=gzip.decompress((p/x['archive']).read_bytes());assert (len(d),sha(d),hashlib.sha1(x['type'].encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest())==(x['bytes'],x['sha256'],oid);return d
def entries(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
def root(rev):return data(rev).splitlines()[0].split()[1].decode()
def compare(oa,ob,prefix=''):
 left=entries(data(oa)) if oa else {};right=entries(data(ob)) if ob else {};out=[]
 for name in sorted(left.keys()|right.keys()):
  x,y=left.get(name),right.get(name);path=prefix+name
  if x==y:continue
  if (x is None or x[0]=='40000') and (y is None or y[0]=='40000'):
   out+=compare(x[1] if x else None,y[1] if y else None,path+'/');continue
  assert x is None or x[0]!='40000';assert y is None or y[0]!='40000';out.append({'path':path,'status':'A' if x is None else 'D' if y is None else 'M','old_mode':x[0] if x else None,'old_blob':x[1] if x else None,'new_mode':y[0] if y else None,'new_blob':y[1] if y else None})
 return out
for oid in gp['objects']:data(oid)
a='a120390947c89b703dc74c4255a13c035d054c50';c='039329518e264f19206cf5b0b98d177433f40c17';assert b'parent '+a.encode() in data(c).split(b'\n') and b'Preserve #774 unfinished p16 work' in data(c);tc=gp['tree_comparison'];assert (root(a),root(c))==(tc['base_tree'],tc['preservation_tree']);actual=compare(tc['base_tree'],tc['preservation_tree']);stored=tc['changes'];assert actual==[{k:v for k,v in x.items() if k!='registry_sha256'} for x in stored] and len(actual)==159;expected={(('A' if x[:2]=='??' else x[:2].strip()),x[3:]) for x in snap['status_porcelain']};assert {(x['status'],x['path']) for x in actual}==expected and [sum(x['status']==s for x in actual) for s in ['M','D','A']]==[151,1,7]
lookup={}
for x in r['files']:
 if x.get('source_id','').startswith('physical-p16:') and x.get('sha256'):lookup.setdefault(x['source_id'].split(':',1)[1],set()).add(x['sha256'])
with tarfile.open(p/'reference/objects.tar.gz','r:gz') as tar:
 for x in stored:
  if x['status']=='D':assert 'registry_sha256' not in x;continue
  h=x['registry_sha256'];assert h in lookup[x['path']];b=tar.extractfile(h).read();assert sha(b)==h and blob(b)==x['new_blob']
assert sum(x['status']!='D' for x in stored)==158;checks.append('Offline recursive Git tree comparison matches all 159 original status paths; 158 existing 039 blobs match original archived registry objects')
assert len(gp['proofs'])==12
for x in gp['proofs']:
 tree=root(x['revision']);assert tree==x['commit_tree']
 for y in x['chain']:
  assert tree==y['tree'] and entries(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Three original 774 roles individually match f82 transported source, 039 preservation and a120 base; 774 catalog and registration Git proofs')
cat=json.loads(gzip.decompress((p/'history-774/catalog.json.gz').read_bytes()));reg=[json.loads(x) for x in gzip.decompress((p/'history-774/root-range-registration.jsonl.gz').read_bytes()).splitlines()];quals=[json.loads(x) for x in gzip.decompress((p/'history-774/root-qualifications.jsonl.gz').read_bytes()).splitlines()];report=load('report.json')
for i,id in [(2702,'ROOT-ADMISSION03-REG-043'),(2703,'ROOT-ADMISSION03-REG-044'),(2704,'ROOT-ADMISSION03-REG-045')]:
 row=r['files'][i];c=next(x for x in cat['rows'] if x['scope_index']==i);a=next(x for x in reg if x['id']==id);q=next(x for x in quals if x['registration_id']==id);saved=next(x for x in report['roles'] if x['original_index']==i);assert saved['original_registry_row']==row and saved['original_catalog_row']==c and row['snapshot']==c['snapshot']==a['snapshot']=='p16' and row['source_id']==c['source_id']==a['source_id'] and row['path'].replace('\\','/')==c['path']==a['resolved_path'].replace('\\','/') and c['origin'].startswith('git:039329518e264f19206cf5b0b98d177433f40c17:') and q['effective_material_ranges']==row['material_ranges'] and row['sha256']==c['expected_sha256']==a['sha256']
mi={x['path']:x for x in json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()))['entries']}
for x in report['history_059']:
 b=(p/x['file']).read_bytes();e=mi[x['transport_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
rec=load('history-059/segovb/READ-L11-441.json')
for i,rr in [(2702,[[1,132]]),(2703,[[1,173]]),(2704,[[1593,1644],[2656,3327]])]:assert next(x for x in rec['sources'] if x['original_index']==i)['fresh_personal_body_reads']==rr
checks.append('Exact 774 mixed-label registry/catalog/registration and 059 reviewer/range identities; no normalized-label assertion')
old=(p/'reference/p16-tracked.patch').read_bytes();new=gzip.decompress((p/'reference/039-tracked-diff.patch.gz').read_bytes());x=report['patch_format'];assert sha(old)==x['recorded_tracked_sha256']==snap['patch_sha256'] and sha(new)==x['preservation_git_diff_sha256']=='05438bea55c87e3ba5ff6040c5e6321d7193a576821e1fd1bd108ccb5887ba23'
def sections(d):return {x.split(b'\n',1)[0].decode():b'diff --git '+x for x in d.split(b'diff --git ')[1:]}
a,b=sections(new),sections(old);different=sorted(k for k in a if a[k]!=b[k]);assert len(a)==len(b)==152 and a.keys()==b.keys() and different==['a/Cargo.lock b/Cargo.lock'] and b'GIT binary patch' in b[different[0]] and b'GIT binary patch' not in a[different[0]];checks.append('Tracked patch representations: 151 identical sections, Cargo.lock binary-vs-text exception, retained original digest')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence identity and read-only Git-object verification only; common P16 material is an evidence-supported inference, not an established label normalization or proof of original full snapshot custody. No patch application, product execution, test, build, repair or checkpoint3821 promotion.'},indent=2))
