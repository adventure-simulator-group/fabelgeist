# Historical P16 label reconciliation

The original registry rows 2702–2704 and original 774 registrations use
`physical-p16:` source IDs but record `snapshot: p16` and `SNAPSHOTS/p16`
paths. The registry snapshot list has a `physical-p16` entry and no `p16`
entry. Both spellings and the discrepancy remain in `report.json`.

The original 774 recovered-source catalog identifies commit `0393295…` as the
origin of the exact objects. Its raw commit names it as an unfinished P16
preservation snapshot and records `a120390…` as parent. Offline Git tree proofs
compare all 159 changed paths and match the original `physical-p16` status
inventory; the 158 extant changed objects match their archived registry hashes.
The three reviewed objects individually match the archive, the preservation
commit and its base. This is strong evidence of common historical material,
not a documented schema alias or proof of uninterrupted original custody.

The recorded tracked patch and a freshly generated base-to-preservation tracked
patch differ in bytes only in the Cargo.lock section: binary versus text patch
representation. The archived Cargo.lock content matches the preservation tree.
Neither patch was applied. Original 059 reviewer receipts and 774 registration,
qualification and catalog records retain their actual identities and ranges.

Run `python3 verify-evidence.py` for offline evidence and raw Git-tree
verification. Run `python3 verify-manifest.py` to check all packet members,
including any nested manifests. No product build, test, execution, simulation,
probe, repair, label normalization or checkpoint 3821 promotion is implied.
