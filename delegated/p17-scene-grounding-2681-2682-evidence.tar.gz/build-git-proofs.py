from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
r=json.loads((b/'registration.json').read_bytes())
for x in r['entries']:
 proof(x['revision'],x['git_path'],x['archive'],x['qualification'])
 if x['kind']=='p17':proof(x['transport_revision'],x['transport_path'],x['archive'],'Exact P17 object at f82 transport; not P17 source commit')
for f in ('support-registration.json','extra-support-registration.json','apron-registration.json','finite-registration.json'):
 for x in json.loads((b/f).read_bytes())['entries']:proof(x['revision'],x['path'],x['archive'],x['qualification'])
for name in ('p17-position','p17-finite'):
 x=next(x for f in ('support-registration.json','finite-registration.json') for x in json.loads((b/f).read_bytes())['entries'] if x['name']==name);proof('f82adcabd9d89c4fa2dd7f99253a45297a0681ee','handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],x['archive'],'Previously registered P17 historical support object at f82 transport; no ordered-role credit')
pr='6533e444fa37552927070cc8d8190907fd3b413e'
for path,archive in [('crates/adventuresim-tactical-core/src/scene_coordinates.rs','sources/2681-current.rs'),('crates/adventuresim-tactical-core/src/city_layout/grounding.rs','sources/2682-current.rs'),('crates/adventuresim-tactical-core/src/city_layout/grounding/single/apron.rs','support/current-apron.rs')]:proof(pr,path,archive,'Historical pr-working HEAD per-file match; unrelated modified files prevent clean snapshot claim')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(x['revision'],x['transport_path'],x['preserved'],'Exact historical 774 original record at f82 transport')
for x in json.loads((b/'historical-attribution.json').read_bytes())['prior_current_sources']:proof(x['revision'],x['git_path'],x['preserved'],'Prior current support-interval assessment source, retain original reader attribution')
root('18360adba0fb43add88c75dfbd2f45d7e71d8ace')
out={'schema':'726-p17-scene-grounding-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Git commit/tree membership verifies only specified source identity. f82 transports recovered P17 and earlier records; 90a is original clean P17 HEAD as recorded; 6533 is pr-working HEAD with unrelated dirty paths, not a clean snapshot.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('paths',len(proofs),'objects',len(objects))
