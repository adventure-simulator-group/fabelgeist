# Bounded P17 scene and grounding source audit

`REPORT.json` contains the scoped source observations, existing findings,
conditions, questions and thirteen bounded lens perspectives. The original
role 2681 P17 source 1–120 and 95e current source 1–122 were personally read.
Role 2682 covers grounding 1–110 for each revision. The separately registered
111–165 grounding support is not added to that ordered role; 166–407 was not
personally read. `personal-read-receipt.json` records every displayed range,
revision, author and unread complement. Archiving a complete file is not a
claim to have inspected all of it.

The original registry records clean report-p17 HEAD 90a and base 18360. Its two
source objects are corroborated by commit/tree/blob membership and f82 object
transport; f82 is not the P17 source commit. Independently reproduced read-only
`git diff <base> <head>` bytes match the registry's P17 patch digest and are
preserved as `historical/p17-base-to-head-reproduced.patch`. This proves the
recorded hash match, not the original invocation or current worktree cleanliness.
The pr-working snapshot and physical-p16 dirty snapshot remain distinct.

Original 059 and 774 records, P16 recovery, prior 95e interval evidence, and
the complete earlier capture agent packet retain their own scopes, original
attribution and conditions. Selected standalone registry and queue JSON files
are reconstructed extracts, not original checkpoint 3821 evidence. Prior report
source archives are not this agent's body-read credit. P16 tracked-patch bytes
exclude seven untracked objects and matching bytes do not establish historical
command or custody.

Both verification programs are self-contained, read-only evidence checks:

```
python3 verify-evidence.py
python3 verify-manifest.py
```

Build scripts are retained for provenance; rebuilding from original stores
requires the original local paths. The verifiers need only this packet. No
implementation, product build, test, rendering, simulation, runtime probe or
product validation was performed.
