from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');reg=load('registration.json');others=[load(x) for x in ('support-registration.json','extra-support-registration.json','apron-registration.json','finite-registration.json')];receipt=load('personal-read-receipt.json');report=load('REPORT.json')
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
origraw=gun('historical/registry.json.gz');assert sha(origraw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';orig=json.loads(origraw);manifest_raw=gun('historical/original-transport-manifest.json.gz');assert sha(manifest_raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';mi=json.loads(manifest_raw);idx={x['path']:x for x in mi['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[1803,1840,1907,2524,2681,2682,2687,2688]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==orig['files'][x['original_index']]
for x in sel['snapshots']:assert x in orig['snapshots']
p17=next(x for x in orig['snapshots'] if x['id']=='report-p17');p16=next(x for x in orig['snapshots'] if x['id']=='physical-p16');pr=next(x for x in orig['snapshots'] if x['id']=='pr-working');assert p17['base']=='18360adba0fb43add88c75dfbd2f45d7e71d8ace' and p17['head']=='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696' and p17['status_porcelain']==[] and p17['patch_sha256']=='3c72c8c4f9816b49ae6306994d55571ceeff420b5a47bb5ff8bcec3c6668c9cd';assert p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
patch=(b/'historical/p17-base-to-head-reproduced.patch').read_bytes();assert len(patch)==268281 and sha(patch)==p17['patch_sha256'];patchref=next(x for x in hist['references'] if x['preserved']=='historical/p17-base-to-head-reproduced.patch');assert patchref['base']==p17['base'] and patchref['head']==p17['head'] and patchref['personally_read_source_credit']==0
recovery=load('historical/p16-recovery.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7};p16patch=(b/'historical/p16-tracked.patch').read_bytes();assert len(p16patch)==524542 and sha(p16patch)==p16['patch_sha256']
for x in reg['entries']+[e for group in others for e in group['entries']]:
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob'] and len(d.splitlines())==x['eof']
for role in (2681,2682):
 rows=[x for x in reg['entries'] if x['role']==role];old=next(x for x in rows if x['kind']=='p17');current=next(x for x in rows if x['kind']=='current');assert old['sha256']==orig['files'][role]['sha256'] and old['eof']==orig['files'][role]['actual_line_count'] and old['prospective_personal_read_ranges']==orig['files'][role]['material_ranges']
 assert (old['sha256']==current['sha256'])==(role==2682)
old=(b/'sources/2681-p17.rs').read_bytes().splitlines();cur=(b/'sources/2681-current.rs').read_bytes().splitlines();assert [x for x in cur if x not in (b'pub use velocity::SceneVelocity;',b'mod velocity;')]==old and len(old)==120 and len(cur)==122
assert orig['files'][1907]['sha256']==sha((b/'sources/2681-current.rs').read_bytes());assert orig['files'][1803]['sha256']==orig['files'][2524]['sha256']==orig['files'][2682]['sha256'];assert orig['files'][1840]['sha256']==sha((b/'support/current-apron.rs').read_bytes());assert orig['files'][2687]['sha256']==sha((b/'support/p17-position.rs').read_bytes()) and orig['files'][2688]['sha256']==sha((b/'support/p17-finite.rs').read_bytes())
queue=json.loads(gun('historical/baseline-059-queue.json.gz'))['entries'];q=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in q['entries']]==[5,111,260,262,632,884,885,1527,1528,1574,2130,2240,2301,2302,3445]
for x in q['entries']:assert x['entry']==queue[x['original_index_zero_based']]
assert queue[111]['contract_id']=='ADLER-L11-SCENE-COORDINATES-EOF-PROVENANCE' and queue[260]['contract_id']=='SEGOVB-L12-APRON-FLOOR-INTERVAL-ELEVATION-ADMISSION' and queue[2240]['contract_id']=='L12-CLOSURE-SUPPORT-ELEVATION-SIGNED-ADMISSION'
for x in hist['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
l11=load('historical/059/segovb/READ-L11-438.json');l12=load('historical/059/segovb/READ-L12-930.json');assert l12['root_personal_rereads']==[] and l12['new_findings']==[] and l12['current_source_reconciled'] is False
for i in (2681,2682):
 x=next(x for x in l11['sources'] if x['original_index']==i);y=next(x for x in l12['rows'] if x['original_index']==i);expected=orig['files'][i]['material_ranges'];assert x['fresh_personal_body_reads']==y['fresh_personal_body_reads']==expected and '/root/lens12_frontier' in y['attribution'] and y['unread_registered_ranges']==[]
a=next(x for x in load('historical/059/adler/READ-L11-291.json')['sources'] if x['original_index']==1907);assert a['fresh_reads']==[[1,122]] and a['inherited_scope_extent_qualification']['excluded_nonexistent_ranges']==[[123,155]]
a=next(x for x in load('historical/059/segovb/READ-L12-603.json')['rows'] if x['original_index']==1840);assert a['fresh_personal_body_reads']==[[1,281]]
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
regs=[json.loads(z) for z in gun('historical/774/native/admission03/source-range-registration.jsonl.gz').splitlines()];quals={x['id']:x for x in [json.loads(z) for z in gun('historical/774/native/admission03/source-qualifications-final-082.jsonl.gz').splitlines()]}
for i in (2681,2682):
 x=orig['files'][i]['admission03_scope_observations'][0];assert regs[x['row_1based']-1]==x['original_record']
 for qual in x['local_qualifications']:assert quals[qual['id']]==qual
assert load('historical/059/segovb/READ-L12-857.json')['root_personal_rereads']==[]
group=json.loads(gun('historical/774/native/admission03/contract-groups-059.json.gz'));assert group['id']=='NATIVE-ADMISSION03-CONTRACT-GROUPS-059';roots=[json.loads(z) for z in gun('historical/774/root/admission03/qualifications.jsonl.gz').splitlines()];root=next(x for x in roots if x['id']=='ROOT-ADM-GEOMETRY-VISIBILITY-007');assert root['finding']['id']=='ROOT-ADM-F003'
prior=load('historical/prior-current-support-interval.json');assert prior['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and any(x['id']=='SEGOVB-L12-APRON-FLOOR-INTERVAL-ELEVATION-ADMISSION' for x in prior['conditional_findings'])
for a,x in zip(prior['current_supporting_sources'],hist['prior_current_sources']):
 data=(b/x['preserved']).read_bytes();raw=gzip.decompress(data);assert len(data)==x['bytes'] and sha(data)==x['sha256'] and len(raw)==x['uncompressed_bytes']==a['bytes'] and sha(raw)==x['uncompressed_sha256']==a['sha256'] and oid('blob',raw)==x['git_blob']==a['git_blob'] and x['prior_assessed_ranges']==a['ranges']
cap=hist['prior_p17_capture'];data=(b/cap['exact_local_archive']['preserved']).read_bytes();assert len(data)==cap['exact_local_archive']['bytes'] and sha(data)==cap['exact_local_archive']['sha256']
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
 m=t.extractfile('BUNDLE-MANIFEST.json').read();assert sha(m)==cap['original_manifest_sha256'];manifest=json.loads(m)
 for x in manifest['files']:
  d=t.extractfile(x['path']).read();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 d=t.extractfile('report.json').read();published=(b/'historical/prior-published-p17-capture-report.json').read_bytes();assert sha(d)==cap['original_report_sha256']==cap['published_report_sha256'] and d==published and cap['published_report_byte_identical_to_original'] and json.loads(d)['agent']=='/root/mhr_character'
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
assert set(proof['commits'])=={'18360adba0fb43add88c75dfbd2f45d7e71d8ace','90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696','95e63628f9d70b8dd6e6fede64334696c6995009','6533e444fa37552927070cc8d8190907fd3b413e','f82adcabd9d89c4fa2dd7f99253a45297a0681ee'}
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==45
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
allregs={e['archive']:(r,e) for r in [reg]+others for e in r['entries']};assert len(receipt['entries'])==len(allregs)==17;cover={}
for e in receipt['entries']:
 rr,source=allregs[e['archive']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']);assert e['registration_sha256']==sha((b/e['registration']).read_bytes()) and e['sha256']==source['sha256'] and e['truncated'] is False
 chosen={i for a,z in e['actual_displayed_ranges'] for i in range(a,z+1)};chunks={i for a,z in e['actual_displayed_chunks'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert e['actual_displayed_ranges']==source.get('prospective_personal_read_ranges',source.get('ranges',[])) and chosen==chunks and chosen.isdisjoint(unread) and chosen|unread==set(range(1,source['eof']+1));cover[e['archive']]=chosen
assert cover['sources/2682-p17.rs']==set(range(1,111)) and cover['support/p17-grounding-interval.rs']==set(range(111,166));assert cover['sources/2682-current.rs']==set(range(1,111)) and cover['support/current-grounding-interval.rs']==set(range(111,166))
assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   p=x['archive'];a,z=x['lines'];assert p in cover and set(range(a,z+1))<=cover[p] and x['sha256']==allregs[p][1]['sha256'] and x['revision']==allregs[p][1]['revision']
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','scope':'evidence identity, receipts, registered source coverage and original versus reconstructed records','p17_diff_sha256':sha(patch),'p17_diff_bytes':len(patch),'registered_personal_reads':len(receipt['entries']),'059_records':len(hist['records_059']),'774_original_records':len(hist['records_774']),'git_paths':len(proof['paths']),'prior_p17_capture_full_archive':True,'lenses_bounded':len(report['lenses']),'product_validation':'not performed'},indent=2))
