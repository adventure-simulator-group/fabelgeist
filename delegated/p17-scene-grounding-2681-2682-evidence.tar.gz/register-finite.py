from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);path='crates/adventuresim-building-generator/src/spatial_geometry/error.rs';out=[]
for n,rev in [('p17-finite','90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696'),('current-finite','95e63628f9d70b8dd6e6fede64334696c6995009')]:
 d=g('show',rev+':'+path);dest='support/'+n+'.rs';(b/dest).write_bytes(d);out.append({'name':n,'revision':rev,'path':path,'archive':dest,'sha256':hashlib.sha256(d).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest(),'bytes':len(d),'eof':len(d.splitlines()),'ranges':[[1,min(28,len(d.splitlines()))]],'qualification':'separate bounded support for Position XYZ finite admission'})
(b/'finite-registration.json').write_text(json.dumps({'schema':'726-bounded-support-prospective-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out},indent=2)+'\n');print(json.dumps(out,indent=2))
