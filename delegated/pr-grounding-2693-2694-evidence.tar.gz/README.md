# Bounded grounding source audit: roles 2693–2694

`report.json` contains the current source assessment, scoped thirteen-lens
perspectives, conditional area-cancellation candidate, open questions, prior
finding relationships, and original attribution. `registration.json` and the
three support registration files precede their respective personal source
reads; receipts and `read-scope-summary.json` distinguish exact displayed
ranges from preserved unread bytes. The source body lines 180–181 of role 2693
are newly read context beyond the historic material range 1–179.

The original `pr-working` snapshot recorded head 6533 and four unrelated
modifications. Both files individually equal their f82 transported original
objects, 6533 blobs, and pinned 95e blobs; this does not make the snapshot
clean. The original snapshot patch digest is recorded, not independently
recovered or verified here. f82 is an evidence transport commit. Separate
P16 qualifications do not alter these identities. Original 774 root, 059
Segovb Lens11, and `/root/lens12_frontier` Lens12 partial reads retain their
own exact ranges and revisions. The 935 proposal requires root adoption;
no adoption was found in the bounded local/manifest search. Historical
records are not checkpoint 3821.

`history-059` contains exact original bytes checked against the recovered
transport manifest. `history-774` holds gzip-compressed original transported
bytes with local equality evidence. `reference` preserves the original
registry, original transport manifest, original 059 queue, and prior current
assessments. Files named `*-selection-reconstructed.json` are reconstructed
selections, not original records. `git-proofs.json` and `git-objects` allow
independent Git tree membership verification without a live Git checkout.
Prior reports retain their original reviewer scopes; they do not confer new
personal source-read credit.

`python3 verify-evidence.py` checks the evidence identity, source-read scope,
Git proofs, historical attribution and reconstructed selections. Run
`python3 verify-manifest.py` to verify all bundle member hashes. These checks
are evidence integrity only; no product code, fixture, test, build, runtime,
repair, or product validation was performed. Central reconciliation owns
ledger IDs, duplicates and checkpoint publication.
