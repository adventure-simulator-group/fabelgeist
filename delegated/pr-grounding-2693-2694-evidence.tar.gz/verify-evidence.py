#!/usr/bin/env python3
"""Verify preserved evidence bytes, provenance and read ranges only; no product execution."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('personal-read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['recorded_utc'] and len(receipt['actual_displays'])==len(r['entries'])==4
for e,x in zip(r['entries'],receipt['actual_displays']):
 b=(p/x['source_archive']).read_bytes();assert x['source_archive']==e['source_archive'] and x['revision']==e['revision'] and (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['chunks']==e['planned_chunks'] and not x['unread_complement']
for i in [2693,2694]:
 a,b=[e for e in r['entries'] if e['original_index']==i];assert a['sha256']==b['sha256'] and a['git_blob']==b['git_blob'] and a['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and b['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009'
assert r['entries'][0]['original_material_ranges']==[[1,179]] and r['entries'][2]['original_material_ranges']==[[1,52]];checks.append('Four separately registered complete assigned body displays; historical original material ends at source 179')
scopes={}
for stem in ['support','extension','coverage']:
 sr=load(stem+'-registration.json');rc=load(stem+'-read-receipt.json');assert rc['registration_sha256']==sha((p/(stem+'-registration.json')).read_bytes()) and sr['registered_utc']<rc['recorded_utc'] and len(sr['entries'])==len(rc['actual_displays'])
 for e,x in zip(sr['entries'],rc['actual_displays']):
  b=(p/e['source_archive']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['displayed_chunks']==e['registered_ranges'] and x['source_archive']==e['source_archive'];d=scopes.setdefault(e['source_archive'],set())
  for a,z in e['registered_ranges']:d.update(range(a,z+1))
summary=load('read-scope-summary.json')
for file,e in summary['support'].items():
 actual={i for a,z in e['displayed_ranges'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert actual==scopes[file] and not actual&unread and actual|unread==set(range(1,e['EOF']+1))
checks.append('Independent current support registrations and exact read/unread range unions')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['original_registry_sha256_uncompressed']==sha(raw)
for x in sel['rows']:assert reg['files'][x['original_index']]==x['entry']
snap=next(x for x in reg['snapshots'] if x['id']=='pr-working');assert sel['pr_working_snapshot']==snap==r['pr_working'] and snap['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and snap['base']=='3a50b708381ad00c116445c2c999a49c3943088b' and len(snap['status_porcelain'])==4
for e in r['entries']:
 if e['original_material_ranges']:assert e['sha256']==reg['files'][e['original_index']]['sha256'] and not any(s[3:]==e['path'] for s in snap['status_porcelain'])
assert sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';manifest=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));entries={x['path']:x for x in manifest['entries']};hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==14 and sum(x['kind']=='historical-774' for x in hi['records'])==5
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
assert not any('segovb/'+t+'-L12-935.json' in entries for t in ['READ','VERIFY','STATE']) and len(load('recovery-search.json')['roots'])==2
checks.append('Original dirty pr-working registry, 059 transport-manifest identities, and five 774 records; adoption not inferred')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==18
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Eighteen raw project and f82 transport Git membership proofs')
l11=load('history-059/segovb/READ-L11-439.json')
for i,expected in [(2693,[[1,179]]),(2694,[[1,52]])]:assert next(x for x in l11['sources'] if x['original_index']==i)['fresh_personal_body_reads']==expected
assert load('history-059/segovb/STATE-L11-439.json')['next_original']==2695
for i,n,expected in [(2693,1,[[1,179]]),(2694,2,[[1,52]])]:
 d=load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-935-{n:03d}.json');x=next(x for x in d['rows'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected and '/root/lens12_frontier' in x['attribution']
assert 'root adoption required' in load('history-059/parallel-l12-20261029/PROPOSAL-L12-935.json')['kind']
reg774=gzip.decompress((p/'history-774/root/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines();cov=gzip.decompress((p/'history-774/root/admission03/coverage.jsonl.gz').read_bytes()).splitlines()
for j in (23,24):assert json.loads(reg774[j-1])['id']==f'ROOT-ADM-REG-{j:03d}'
for j in (209,210):assert json.loads(cov[j-1])['id']==f'ROOT-ADM-COVERAGE-{j:03d}'
assert json.loads(gzip.decompress((p/'history-774/root/admission03/foundation-source-admission-038.json.gz').read_bytes()))['finding']['id']=='ROOT-ADM-F010'
checks.append('774 exact registration/coverage and F010; 059 historical Lens11 and independent Lens12 partials with adoption qualification')
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert queue['entries'][int(n)]==e
for x in load('prior-evidence-index.json')['records']:
 b=(p/x['preserved_bytes']).read_bytes();assert (sha(b),len(b))==(x['sha256'],x['bytes'])
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
assert {x['number'] for x in load('report.json')['lenses']}==set(range(1,14));checks.append('Reconstructed queue selection, prior assessments, rules and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and source-read accounting only; no product validation, test, runtime probe, execution, implementation, checkpoint3821 promotion or inferred proposal adoption.'},indent=2))
