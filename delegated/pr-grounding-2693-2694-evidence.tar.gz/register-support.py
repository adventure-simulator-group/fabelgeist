from pathlib import Path
import datetime,hashlib,json,subprocess
p=Path(__file__).resolve().parent; pub=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);sha=lambda b:hashlib.sha256(b).hexdigest();(p/'support').mkdir(exist_ok=True)
base='crates/adventuresim-tactical-core/src/'
spec=[('polygon',base+'scene_coordinates/polygon.rs',[[1,160]]),('geometry',base+'city_layout/grounding/foundations/geometry.rs',[[1,155]]),('binding',base+'city_layout/grounding/enclosure/binding.rs',[[55,110]]),('floor',base+'city_layout/grounding/single/floor.rs',[[1,70]]),('foundation',base+'city_layout/grounding/foundations.rs',[[240,330]])]
entries=[]
for name,path,requested in spec:
 b=git('show',rev+':'+path);n=len(b.splitlines());ranges=[[a,min(z,n)] for a,z in requested if a<=n];fn='support/'+name+'.rs';(p/fn).write_bytes(b);entries.append({'name':name,'path':path,'revision':rev,'sha256':sha(b),'git_blob':git('rev-parse',rev+':'+path).decode().strip(),'bytes':len(b),'actual_EOF':n,'registered_ranges':ranges,'source_archive':fn})
r={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/mhr_character','kind':'Independent bounded current support; no ordered-role or prior-reader credit','entries':entries,'qualification':'Metadata-only symbol-location grep before registration; source bodies first displayed after registration. Full saved bytes do not imply full personal read.'};(p/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('sha',sha((p/'support-registration.json').read_bytes()));print([(e['name'],e['actual_EOF'],e['registered_ranges']) for e in entries])
