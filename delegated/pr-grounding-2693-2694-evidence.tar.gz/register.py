from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
p=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-C',str(pub),*a])
registry=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'))
snapshot=next(x for x in registry['snapshots'] if x['id']=='pr-working')
base='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
(p/'source').mkdir(exist_ok=True);entries=[]
for i in (2693,2694):
 row=registry['files'][i];path=row['source_id'].split(':',1)[1]
 tp='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256'];old=git('show',transport+':'+tp);basebytes=git('show',base+':'+path)
 assert sha(old)==row['sha256'] and len(old)==row['bytes'] and len(old.splitlines())==row['actual_line_count'] and old==basebytes
 assert not any(s[3:]==path for s in snapshot['status_porcelain'])
 for label,rev,b in [('historical',base,old),('current',cur,git('show',cur+':'+path))]:
  local=f'source/{i}-{label}.rs';(p/local).write_bytes(b);n=len(b.splitlines());chunks=[[j,min(j+119,n)] for j in range(1,n+1,120)]
  entries.append({'original_index':i,'source_id':row['source_id'] if label=='historical' else 'current:'+path,'snapshot':'pr-working dirty snapshot; individual archived file equals recorded HEAD' if label=='historical' else 'pinned current project','revision':rev,'path':path,'source_archive':local,'sha256':sha(b),'git_blob':git('rev-parse',rev+':'+path).decode().strip(),'bytes':len(b),'actual_EOF':n,'registered_ranges':[[1,n]],'planned_chunks':chunks,'original_material_ranges':row['material_ranges'] if label=='historical' else None,'transport_path':tp if label=='historical' else None})
r={'schema':'726-pr-grounding-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/mhr_character','entries':entries,'pr_working':snapshot,'qualification':'The recorded pr-working snapshot had unrelated modifications and is not a clean commit; each assigned file individually equals its recorded HEAD and recovered archived object. f82 is evidence transport, not project revision. Original reviewer material is not checkpoint 3821; original role 2693 material ends at 179, whereas 180–181 are newly registered contextual extension.','constraint':'Static source/evidence inspection only; no implementation, execution, tests, builds, probes or product validation.'}
(p/'registration.json').write_text(json.dumps(r,indent=2)+'\n');print('registration sha256',sha((p/'registration.json').read_bytes()));print('entries',[(x['original_index'],x['snapshot'],x['sha256'],x['git_blob'],x['actual_EOF'],x['planned_chunks']) for x in entries])
