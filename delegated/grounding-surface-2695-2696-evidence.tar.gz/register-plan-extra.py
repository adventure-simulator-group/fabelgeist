from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);rev='95e63628f9d70b8dd6e6fede64334696c6995009';items=[('polygon-arithmetic','crates/adventuresim-building-generator/src/plan_geometry.rs',[[220,245]]),('plot-containment','crates/adventuresim-tactical-core/src/city_layout/compound/region.rs',[[90,130]])];out=[]
for name,path,ranges in items:
 d=g('show',rev+':'+path);dest='support/'+name+'.rs';(b/dest).write_bytes(d);out.append({'name':name,'kind':'pinned project support','revision':rev,'path':path,'archive':dest,'sha256':hashlib.sha256(d).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest(),'bytes':len(d),'eof':len(d.splitlines()),'ranges':ranges,'qualification':'separately registered current arithmetic and containment support only'})
(b/'plan-extra-registration.json').write_text(json.dumps({'schema':'726-bounded-support-prospective-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out},indent=2)+'\n');print(json.dumps(out,indent=2))
