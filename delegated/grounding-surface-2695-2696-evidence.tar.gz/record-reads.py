from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();files=['registration.json','support-registration.json','numeric-support-registration.json','plan-extra-registration.json','mutation-support-registration.json','bevy-support-registration.json'];out=[]
for rn in files:
 r=json.loads((b/rn).read_bytes())
 for e in r['entries']:
  ranges=e.get('prospective_personal_read_ranges',e.get('ranges',[]));chunks=[];name=e.get('name');role=e.get('role')
  for a,z in ranges:
   if role==2695:chunks.extend([[1,55],[56,110],[111,157]])
   elif role==2696 and (a,z)==(1,299):chunks.extend([[1,60],[61,120],[121,180],[181,240],[241,299]])
   elif name=='mesh' and (a,z)==(1,75):chunks.extend([[1,40],[41,75]])
   elif name=='floor-region':chunks.extend([[1,39],[40,78]])
   elif name=='ground-triangle':chunks.extend([[1,50],[51,100]])
   elif name=='planar':chunks.extend([[1,42],[43,83]])
   elif name=='scene-polygon':chunks.extend([[1,50],[51,100]])
   elif name=='plan-polygon':chunks.extend([[1,55],[56,110],[111,160]])
   else:chunks.append([a,z])
  n=e['eof'];mask={i for a,z in ranges for i in range(a,z+1)};unread=[];start=None
  for i in range(1,n+2):
   if i<=n and i not in mask and start is None:start=i
   if (i>n or i in mask) and start is not None:unread.append([start,i-1]);start=None
  out.append({'role':role,'kind':e.get('kind',e.get('name')),'name':name,'revision':e.get('revision'),'native_package':e.get('package'),'native_version':e.get('version'),'sha256':e['sha256'],'archive':e['archive'],'registration':rn,'registration_sha256':sha((b/rn).read_bytes()),'actual_displayed_chunks':chunks,'actual_displayed_ranges':ranges,'unread_complement':unread,'attribution':'/root/rig_identity independently displayed after prospective registration','truncated':False})
(b/'personal-read-receipt.json').write_text(json.dumps({'schema':'726-personal-source-read-receipt-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out,'qualification':'Assigned role2695 unread 158–159; role2696 unread 300–304 and 312–313. Native package revision is not project Git; full archived bodies outside displayed ranges are not read credit.'},indent=2)+'\n');print('entries',len(out))
