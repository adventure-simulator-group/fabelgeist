from pathlib import Path
from datetime import datetime
import gzip,hashlib,io,json,tarfile,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads((b/p).read_bytes());gun=lambda p:gzip.decompress((b/p).read_bytes());hist=load('historical-attribution.json');reg=load('registration.json');others=[load(x) for x in ('support-registration.json','numeric-support-registration.json','plan-extra-registration.json','mutation-support-registration.json','bevy-support-registration.json')];receipt=load('personal-read-receipt.json');report=load('REPORT.json')
for x in hist['references']:
 d=(b/x['preserved']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
 if 'uncompressed_sha256' in x:
  raw=gzip.decompress(d);assert len(raw)==x['uncompressed_bytes'] and sha(raw)==x['uncompressed_sha256']
origraw=gun('historical/registry.json.gz');assert sha(origraw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';orig=json.loads(origraw);manifest_raw=gun('historical/original-transport-manifest.json.gz');assert sha(manifest_raw)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';mi=json.loads(manifest_raw);idx={x['path']:x for x in mi['entries']}
sel=load('registry-selection-reconstructed.json');assert [x['original_index'] for x in sel['rows']]==[1829,1846,2695,2696,2697]
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==orig['files'][x['original_index']]
for x in sel['snapshots']:assert x in orig['snapshots']
pr=next(x for x in orig['snapshots'] if x['id']=='pr-working');p16=next(x for x in orig['snapshots'] if x['id']=='physical-p16');p17=next(x for x in orig['snapshots'] if x['id']=='report-p17');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4 and p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and p17['head']=='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696'
recovery=load('historical/p16-recovery.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7};d=(b/'historical/p16-tracked.patch').read_bytes();assert len(d)==524542 and sha(d)==p16['patch_sha256']
for x in reg['entries']+[e for group in others for e in group['entries']]:
 d=(b/x['archive']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(d.splitlines())==x['eof'];
 if 'git_blob' in x:assert oid('blob',d)==x['git_blob']
for role in (2695,2696):
 rows=[x for x in reg['entries'] if x['role']==role];old=next(x for x in rows if x['kind']=='pr_head');current=next(x for x in rows if x['kind']=='current');assert old['sha256']==orig['files'][role]['sha256']==current['sha256'] and old['eof']==orig['files'][role]['actual_line_count'] and old['prospective_personal_read_ranges']==orig['files'][role]['material_ranges'];assert (b/old['archive']).read_bytes()==(b/current['archive']).read_bytes()
assert orig['files'][1829]['sha256']==sha((b/'support/mesh.rs').read_bytes());assert orig['files'][1846]['sha256']==sha((b/'support/surface.rs').read_bytes());assert orig['files'][2697]['sha256']==sha((b/'support/floor-region.rs').read_bytes())
queue=json.loads(gun('historical/baseline-059-queue.json.gz'))['entries'];q=load('queue-selection-reconstructed.json');assert [x['original_index_zero_based'] for x in q['entries']]==[103,260,632,884,885,1497,1500,1508,1518,1519,1534,1569,2240]
for x in q['entries']:assert x['entry']==queue[x['original_index_zero_based']]
assert queue[103]['contract_id']=='ADLER-L11-SUPPORT-GRADE-NUMERIC-ADMISSION' and queue[1518]['contract_id']=='Q-L12-1542c41f322277996bc9' and queue[260]['contract_id']=='SEGOVB-L12-APRON-FLOOR-INTERVAL-ELEVATION-ADMISSION'
for x in hist['records_059']:
 d=(b/x['preserved']).read_bytes();m=idx[x['original_path']];assert len(d)==x['bytes']==m['bytes'] and sha(d)==x['sha256']==m['sha256'] and oid('blob',d)==x['git_blob']==m['git_blob']
l11=load('historical/059/segovb/READ-L11-440.json');a=next(x for x in l11['sources'] if x['original_index']==2695);f=next(x for x in l11['sources'] if x['original_index']==2696);assert a['fresh_personal_body_reads']==[] and a['same_lens_prior']['entry']['fresh_reads']==[[1,157]] and a['same_lens_prior']['entry']['additional_original_frontier_credit']==0;assert f['fresh_personal_body_reads']==[[1,299],[305,311],[314,323]] and l11['fresh_bounded_windows']['1614']==[[1,150],[151,299],[305,311],[314,323]]
adler=load('historical/059/adler/READ-L11-279.json');entry=next(x for x in adler['connected_reinspection'] if x['original_index']==2695);assert entry['fresh_reads']==[[1,157]] and entry['additional_original_frontier_credit']==0
prior=load('historical/059/segovb/READ-L12-600.json');assert next(x for x in prior['rows'] if x['original_index']==1829)['fresh_personal_body_reads']==[[1,242]]
for x in hist['records_774']:
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['source_bytes'] and sha(raw)==x['source_sha256'] and oid('blob',raw)==x['git_blob']
regs=[json.loads(z) for z in gun('historical/774/root/admission03/source-range-registration.jsonl.gz').splitlines()];norms=[json.loads(z) for z in gun('historical/774/root/admission03/source-qualifications-final-current.jsonl.gz').splitlines()];norms={x['registration_id']:x for x in norms};qualrows=[json.loads(z) for z in gun('historical/774/root/admission03/source-qualifications.jsonl.gz').splitlines()]
for i in (2695,2696):
 for x in orig['files'][i]['admission03_scope_observations']:
  assert regs[x['row_1based']-1]==x['original_record']
  for qual in x['local_qualifications']:assert norms[qual['registration_id']]==qual
qual=next(x for x in qualrows if x.get('id')=='ROOT-ADM-QUAL-REG-030');assert qual['original_prospective_ranges']==[[300,313]] and qual['effective_material_ranges']==[[305,311]]
rootqual=[json.loads(z) for z in gun('historical/774/root/admission03/qualifications.jsonl.gz').splitlines()];g039=next(x for x in rootqual if x.get('id')=='ROOT-ADM-G039');assert 'regions.clear()' in g039['source_roles']['F010_supplement'];findings=[json.loads(z) for z in gun('historical/774/root/admission03/findings.jsonl.gz').splitlines()];assert next(x for x in findings if x['id']=='ROOT-ADM-F010')['classification']=='grounding_accepted_storage_mutable_backing_bypasses_predicates_and_indices'
prior=load('historical/prior-current-geography-grade.json');assert prior['source_revision']=='95e63628f9d70b8dd6e6fede64334696c6995009' and any(x['id']=='ADLER-L11-SUPPORT-GRADE-NUMERIC-ADMISSION' for x in prior['conditional_findings'])
for a,x in zip(prior['current_supporting_sources'],hist['prior_current_sources']):
 d=(b/x['preserved']).read_bytes();raw=gzip.decompress(d);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and len(raw)==x['uncompressed_bytes']==a['bytes'] and sha(raw)==x['uncompressed_sha256']==a['sha256'] and oid('blob',raw)==x['git_blob']==a['git_blob'] and x['prior_assessed_ranges']==a['ranges']
lockmeta=others[1]['lock'];lockraw=gun(lockmeta['archive']);assert len(lockraw)==lockmeta['bytes'] and sha(lockraw)==lockmeta['sha256'] and oid('blob',lockraw)==lockmeta['git_blob'];lock=tomllib.loads(lockraw.decode());packages={x['name']:x for x in lock['package'] if (x['name']=='glam' and x['version']=='0.32.1') or (x['name'] in ('bevy','bevy_internal','bevy_math') and x['version']=='0.19.1')};assert set(packages)=={'glam','bevy','bevy_internal','bevy_math'}
archives=[others[1]['package_archive']]+others[4]['package_archives'];byname={}
for x in archives:
 data=(b/x['path']).read_bytes();name=x.get('name','glam');assert len(data)==x['bytes'] and sha(data)==x['sha256']==packages[name]['checksum'];byname[name]=data
for group in (others[1],others[4]):
 for x in group['entries']:
  if x.get('kind')=='locked native package member':
   data=byname[x['package']];assert sha(data)==x['archive_checksum']
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:assert t.extractfile(x['member']).read()==(b/x['archive']).read_bytes()
assert 'bevy_internal' in packages['bevy']['dependencies'] and 'bevy_math' in packages['bevy_internal']['dependencies'] and 'glam 0.32.1' in packages['bevy_math']['dependencies']
prior=hist['prior_p17_scene_grounding'];data=(b/prior['exact_local_archive']['preserved']).read_bytes();assert len(data)==prior['exact_local_archive']['bytes'] and sha(data)==prior['exact_local_archive']['sha256']
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
 m=t.extractfile('MANIFEST.json').read();assert sha(m)==prior['original_manifest_sha256']=='2f4abcce109bc0b9d7369d7600a13b32b768757ae1dad1b504814341ad61e046';manifest=json.loads(m)
 for x in manifest['files']:
  raw=t.extractfile(x['path']).read();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
 assert sha(t.extractfile('REPORT.json').read())==prior['original_report_sha256']=='fe8af6834fb7dd0a9d42bf8d44dd2c1758c21a9bb926e077663393f6362a8079';patch=t.extractfile('historical/p17-base-to-head-reproduced.patch').read();assert len(patch)==268281 and sha(patch)==p17['patch_sha256']=='3c72c8c4f9816b49ae6306994d55571ceeff420b5a47bb5ff8bcec3c6668c9cd'
proof=load('git-proofs.json');objects={}
for k,x in proof['objects'].items():
 d=gun(x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objects[k]=d
for rev,x in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
assert len(proof['paths'])==61
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objects[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
allregs={e['archive']:(r,e) for r in [reg]+others for e in r['entries']};assert len(receipt['entries'])==len(allregs)==24;cover={}
for e in receipt['entries']:
 rr,source=allregs[e['archive']];assert datetime.fromisoformat(rr['at_utc'])<datetime.fromisoformat(receipt['recorded_at_utc']);assert e['registration_sha256']==sha((b/e['registration']).read_bytes()) and e['sha256']==source['sha256'] and e['truncated'] is False
 chosen={i for a,z in e['actual_displayed_ranges'] for i in range(a,z+1)};chunks={i for a,z in e['actual_displayed_chunks'] for i in range(a,z+1)};unread={i for a,z in e['unread_complement'] for i in range(a,z+1)};assert e['actual_displayed_ranges']==source.get('prospective_personal_read_ranges',source.get('ranges',[])) and chosen==chunks and chosen.isdisjoint(unread) and chosen|unread==set(range(1,source['eof']+1));cover[e['archive']]=chosen
for k in ('pr_head','current'):
 assert cover[f'sources/2695-{k}.rs']==set(range(1,158));assert cover[f'sources/2696-{k}.rs']==set(range(1,300))|set(range(305,312))|set(range(314,324))
assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
def inspect(x):
 if isinstance(x,dict):
  if 'archive' in x and 'lines' in x:
   p=x['archive'];a,z=x['lines'];source=allregs[p][1];assert set(range(a,z+1))<=cover[p] and x['sha256']==source['sha256'] and x['revision']==source.get('revision') and x['native_package']==source.get('package')
  for v in x.values():inspect(v)
 elif isinstance(x,list):
  for v in x:inspect(v)
inspect(report)
print(json.dumps({'status':'PASS','scope':'exact source identities, qualified historical ranges, native package archives and source receipts','registered_personal_reads':len(receipt['entries']),'059_records':len(hist['records_059']),'774_original_records':len(hist['records_774']),'git_paths':len(proof['paths']),'prior_full_packet_verified':True,'native_package_archives':len(byname),'lenses_bounded':len(report['lenses']),'product_validation':'not performed'},indent=2))
