from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();cur='95e63628f9d70b8dd6e6fede64334696c6995009';base='crates/adventuresim-tactical-core/src/city_layout/grounding/';items=[('mesh',base+'mesh.rs',[[1,75],[205,235]]),('surface',base+'surface.rs',[[1,65],[145,177]]),('floor-region',base+'surface/floor/region.rs',[[1,78]]),('ground-triangle',base+'foundations/geometry.rs',[[1,100]]),('planar',base+'planar.rs',[[1,83]])];out=[]
for name,path,ranges in items:
 raw=g('show',cur+':'+path);n=len(raw.splitlines());assert all(1<=a<=z<=n for a,z in ranges);dest=f'support/{name}.rs';(b/dest).write_bytes(raw);out.append({'name':name,'revision':cur,'path':path,'archive':dest,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'eof':n,'ranges':ranges,'qualification':'independent pinned current bounded support only, no ordered-role or historical read credit'})
(b/'support-registration.json').write_text(json.dumps({'schema':'726-bounded-support-prospective-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out},indent=2)+'\n');print(json.dumps(out,indent=2))
