from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);rev='95e63628f9d70b8dd6e6fede64334696c6995009';base='crates/adventuresim-tactical-core/src/city_layout/grounding/';items=[('surface-access',base+'surface.rs',[[66,110]]),('single-builder',base+'single.rs',[[55,110]])];out=[]
for name,path,ranges in items:
 d=g('show',rev+':'+path);dest='support/'+name+'.rs';(b/dest).write_bytes(d);out.append({'name':name,'kind':'pinned project support','revision':rev,'path':path,'archive':dest,'sha256':hashlib.sha256(d).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest(),'bytes':len(d),'eof':len(d.splitlines()),'ranges':ranges,'qualification':'separately registered current access/builder source; not assigned or old reviewer scope'})
(b/'mutation-support-registration.json').write_text(json.dumps({'schema':'726-bounded-support-prospective-v1','at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out},indent=2)+'\n');print(json.dumps(out,indent=2))
