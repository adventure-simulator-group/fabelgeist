import datetime,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json']
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};r=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):r.append([start,i-1]);start=None
 return r
reads=[]
for n in names[1:]:
 for x in json.loads((p/n).read_bytes())['sources']:
  ranges=[[1,100],[101,190]] if x['saved']=='support/05.rs' else x['prospective_ranges'];reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['eof'],'displayed':ranges,'unread_complement':complement(x['eof'],ranges),'qualification':'Current bounded support only; no earlier or ordered-role credit.'})
assigned=[{'role':2615,'pr_working_actual_display':[[1,95],[96,188]],'current_95e_actual_display':[[1,95],[96,188]],'unread_old_and_current':[]},{'role':2616,'pr_working_actual_display':[[1,71]],'current_95e_actual_display':[[1,75]],'unread_old_and_current':[]}]
o={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in names],'assigned':assigned,'other_revision':'6533 copies verified via byte/Git identity only and not separately displayed. Old pr-working and current 95e bodies were personally displayed separately.','prior_current':'ASSESSMENT-HELMET-FOOTWEAR-95E.json records earlier current support pierced_plate_domain.rs 1–180; its unnamed author and original scope remain separate from this independent new ordered role. The earlier /root/hair_ops 2610 packet separately records full 95e helmets.rs; this packet re-registers and displays 309–330 and 373–398 as support.','support':reads,'constraints':'Source and evidence inspection only. Any test text was not executed.'};(p/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n');print('receipt sha',h((p/'read-receipt.json').read_bytes()))
