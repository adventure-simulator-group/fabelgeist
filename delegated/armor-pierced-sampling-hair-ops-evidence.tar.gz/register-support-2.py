'''Prospective bounded support registration; no bodies displayed.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[('crates/adventuresim-character-creator/src/gown_plan.rs',[[1,190]]),('crates/adventuresim-character-creator/src/device_recipe_plan.rs',[[1,115]])];a=[]
for i,(path,ranges) in enumerate(paths,5):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Bounded current support only; no prior or ordered-role credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-2.json').write_text(json.dumps(o,indent=2)+'\n');print(hashlib.sha256((p/'support-registration-2.json').read_bytes()).hexdigest());print([(v['path'],v['eof'],v['prospective_ranges']) for v in a])
