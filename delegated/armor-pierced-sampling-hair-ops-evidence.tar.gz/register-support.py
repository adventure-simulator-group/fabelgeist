'''Prospective support registration; no source bodies displayed.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/fabelgeist-armor/src/helmets_visor_domain.rs',[[1,150]]),('crates/fabelgeist-armor/src/visor_breaths.rs',[[1,149]]),('crates/fabelgeist-armor/src/gpu/helmet/burgonet.rs',[[200,285]]),('crates/adventuresim-character-creator/src/cloth_triangle_budget.rs',[[1,90]]),('crates/fabelgeist-armor/src/helmets_close_design.rs',[[1,145]])]
a=[]
for i,(path,ranges) in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Bounded current support only; no ordered-role or previous reviewer credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration.json').write_text(json.dumps(o,indent=2)+'\n');print('registration sha',hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest());print(json.dumps([{k:x[k] for k in ('path','eof','prospective_ranges')} for x in a],indent=2))
