'''Prospective bounded support registration only.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[('crates/fabelgeist-armor/src/gpu/close_helmet.rs',[[130,180],[340,355],[375,385]]),('crates/fabelgeist-armor/src/helmets.rs',[[309,330],[373,398]])];a=[]
for i,(path,ranges) in enumerate(paths,7):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Fresh bounded current support only; no transfer from earlier 2610 full body.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-3.json').write_text(json.dumps(o,indent=2)+'\n');print('sha',hashlib.sha256((p/'support-registration-3.json').read_bytes()).hexdigest())
