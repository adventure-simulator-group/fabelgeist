# Bounded armor evidence: original roles 2615–2616

`REPORT.json` contains the source observations, thirteen bounded perspectives,
open questions and historical relationships. Prospective registrations and
`read-receipt.json` separate fresh old/current displays, prior review scopes and
unread support ranges. The pr-working objects individually match 6533. Only
2615 also matches 95e; the 2616 difference is retained as a diff. f82 is the
historical object transport, not source HEAD, and pr-working had unrelated
modifications.

`source/` and `support/` hold exact registered bytes; `git-objects/` and
`git-proofs.json` hold commit-to-blob membership evidence. The historical
manifest distinguishes exact copied 059 records, a reconstructed queue
selection, and hash-linked published 774 and current assessments. Prior
reviewers keep their actual scopes. The later dirty P16 patch recovery remains
separate from these pr-working roles and no old record becomes checkpoint 3821.

`python3 verify-evidence.py` checks evidence integrity, assuming linked evidence
remains at its recorded absolute paths. Relocated dependencies must be resolved
by the listed SHA-256. Verification reads source but does not execute or
validate product behavior. Tests and examples were source text only.
