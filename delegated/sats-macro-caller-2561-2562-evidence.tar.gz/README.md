# SATS derive admission and selected callers

This additive packet records fresh prospective source reads by
`/root/rig_identity` of native `spacetimedb-bindings-macro` 2.6.1 roles
2561–2562 and narrowly registered 95e call sites and support. `REPORT.json`
preserves the historical q131, q2332 and q3443 statuses, earlier authors and
source scopes, existing source-level admission concern, structural guards,
current encounter and disease construction safeguards, and open ingress and
feature questions.

Primary and supplemental registrations precede their displayed windows;
receipts retain exact ranges and unread complements. Package archives are bound
to their distinct package versions and lock checksums, not project Git source
revisions. f82 transports original historical objects only. Evidence archives
and raw Git objects establish identity, not additional personal source reads.

The 059 registry, queue and supporting records remain exact historical bytes;
selected queue and printed transcript values are labeled reconstructions. A
later printed q131 status is a partial normalized projection, not a complete
queue or checkpoint3821. P16 tracked patch reproduction retains its original
invocation, custody, untracked-file and filesystem metadata limitations.
Prior public attribution has eight local-path redactions and is not byte-equal
to the preserved original; public handling must retain both identities.

`python3 verify-evidence.py` and `python3 verify-manifest.py` are read-only
integrity checks. Construction scripts would rewrite the packet; do not run
them on the frozen copy. No macro, test, product, database, fixture, build,
probe, repair or lens clearance occurred.
