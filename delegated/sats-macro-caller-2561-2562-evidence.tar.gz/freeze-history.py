from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,tarfile
b=Path(__file__).resolve().parent;prior=Path('<LOCAL_PATH_0>');pub=Path('<LOCAL_PATH_1>');sha=lambda d:hashlib.sha256(d).hexdigest();w=lambda p,d:(b/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def receipt(regfile,dst):
 reg=json.loads((b/regfile).read_bytes());reads=[]
 for e in reg['entries']:
  covered=set(i for a,z in e['prospective_display_ranges'] for i in range(a,z+1));unread=[];start=None
  for i in range(1,e['eof']+2):
   if i<=e['eof'] and i not in covered:
    if start is None:start=i
   elif start is not None:unread.append([start,i-1]);start=None
  reads.append({'id':e['id'],'sha256':e['sha256'],'eof':e['eof'],'actual_display_ranges':e['prospective_display_ranges'],'unread_complement':unread})
 w(dst,{'recorded_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','registration':regfile,'registration_sha256':sha((b/regfile).read_bytes()),'reads':reads,'qualification':'Exact registered windows displayed with line numbers; archived complements and earlier readers do not confer personal read credit.'})
receipt('registration.json','personal-read-receipt.json');receipt('supplement-registration.json','supplement-read-receipt.json')
shutil.copytree(prior/'history',b/'history')
(b/'history/prior-current').mkdir(exist_ok=True)
for n in ['REPORT.json','registration.json','extra-registration.json','personal-read-receipt.json','historical-attribution.json','MANIFEST.json']:shutil.copyfile(prior/n,b/'history/prior-current'/n)
a=pub/'delegated/sats-semantic-queue-2561-2562-evidence.tar.gz';comparisons=[]
with tarfile.open(a,'r:gz') as t:
 for n in ['REPORT.json','registration.json','extra-registration.json','personal-read-receipt.json','historical-attribution.json','MANIFEST.json']:
  d=t.extractfile(n).read();original=(prior/n).read_bytes();dst='history/prior-current/public-'+n;(b/dst).write_bytes(d);comparisons.append({'member':n,'original':'history/prior-current/'+n,'published_copy':dst,'original_sha256':sha(original),'published_sha256':sha(d),'byte_identical':original==d})
w('history/prior-current/published-comparison.json',{'archive':'delegated/sats-semantic-queue-2561-2562-evidence.tar.gz','archive_sha256':sha(a.read_bytes()),'comparison':comparisons,'qualification':'Selected members only; original and published identities remain distinct. The earlier public historical-attribution member redacts local paths; exact original is retained here. Full published archive is hash-linked separately.'})
paths=['crates/adventuresim-stdb-module/src/disease.rs','crates/adventuresim-stdb-module/src/disease/exposure_sources.rs','crates/adventuresim-stdb-module/src/strategic/encounters.rs','crates/adventuresim-world-schema/src/basis_points.rs','crates/adventuresim-world-schema/src/lib.rs'];w('navigation-index.json',{'revision':'95e63628f9d70b8dd6e6fede64334696c6995009','operation':'git grep -l exact UnitBasisPoints or SignedUnitBasisPoints under the two named crate trees; output filenames only; separate line-number-only encounter inventory','paths':paths,'encounters_matched_lines':[173],'qualification':'Literal spelling and specified paths only; aliases, reexports, generated fields, other crates and runtime ingress are not ruled out.'})
print('prior history copied; selected published members',len(comparisons))
