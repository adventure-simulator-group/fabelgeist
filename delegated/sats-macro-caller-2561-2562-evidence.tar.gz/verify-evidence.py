#!/usr/bin/env python3
from pathlib import Path
import gzip,hashlib,json,tarfile,tomllib
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();read=lambda p:(b/p).read_bytes();js=lambda p:json.loads(read(p));jgz=lambda p:json.loads(gzip.decompress(read(p)))
reg=js('registration.json');supp=js('supplement-registration.json');rr={}
for file,receiptfile in [('registration.json','personal-read-receipt.json'),('supplement-registration.json','supplement-read-receipt.json')]:
 r=js(file);rec=js(receiptfile);assert rec['registration_sha256']==sha(read(file)) and rec['recorded_utc']>=r['registered_utc']
 by={x['id']:x for x in rec['reads']};assert len(by)==len(r['entries'])
 for e in r['entries']:
  d=read(e['archive']);x=by[e['id']];assert (len(d),sha(d),len(d.splitlines()))==(e['bytes'],e['sha256'],e['eof']);assert x['sha256']==e['sha256'] and x['eof']==e['eof'] and x['actual_display_ranges']==e['prospective_display_ranges'];yes=set(i for a,z in x['actual_display_ranges'] for i in range(a,z+1));no=set(i for a,z in x['unread_complement'] for i in range(a,z+1));assert not yes&no and yes|no==set(range(1,e['eof']+1));rr[e['id']]=x
for name,a in reg['archives'].items():
 assert sha(read(a['path']))==a['sha256']
 with tarfile.open(b/a['path'],'r:gz') as t:
  cargo=tomllib.loads(t.extractfile(name+'-2.6.1/Cargo.toml').read().decode());assert cargo['package']['name']==name and cargo['package']['version']==a['version']
  for e in reg['entries']:
   if e.get('package')==name:assert read(e['archive'])==t.extractfile(e['member']).read()
for e in reg['entries']:
 if e['id'].startswith('lock-'):
  data=tomllib.loads(read(e['archive']).decode())
  for name,a in reg['archives'].items():
   p=[x for x in data['package'] if x['name']==name and x['version']=='2.6.1'];assert len(p)==1 and p[0]['source']=='registry+https://github.com/rust-lang/crates.io-index' and p[0]['checksum']==a['sha256']
report=js('REPORT.json');assert [x['index'] for x in report['historical_queue_relationships']]==[131,2332,3443]
for a in report['assessments']:
 for ref in a['references']:
  covered=set(i for x,y in rr[ref['source']]['actual_display_ranges'] for i in range(x,y+1));assert all(i in covered for x,y in ref['lines'] for i in range(x,y+1))
gp=js('git-proofs.json');raw={}
for key,x in gp['objects'].items():
 d=gzip.decompress(read(x['preserved_bytes']));assert (len(d),sha(d),oid(x['type'],d))==(x['bytes'],x['sha256'],key);raw[key]=d
for rev,x in gp['commits'].items():assert raw[rev].splitlines()[0]==b'tree '+x['root_tree'].encode()
def ents(d):
 z={};i=0
 while i<len(d):
  j=d.index(b'\0',i);m,n=d[i:j].split(b' ',1);z[n.decode()]=(m.decode(),d[j+1:j+21].hex());i=j+21
 return z
for x in gp['paths']:
 d=read(x['preserved_bytes']);d=gzip.decompress(d) if x['preserved_bytes'].endswith('.gz') else d;assert (len(d),sha(d),oid('blob',d))==(x['bytes'],x['sha256'],x['git_blob']);cur=gp['commits'][x['revision']]['root_tree'];names=[]
 for y in x['path_chain']:
  assert cur==y['tree'];mode,child=ents(raw[cur])[y['name']];assert (mode,child)==(y['mode'],y['object']);cur=child;names.append(y['name'])
 assert '/'.join(names)==x['path'] and cur==x['git_blob']
registry=jgz('history/original-registry.json.gz');queue=jgz('history/baseline-059-queue.json.gz');transport=jgz('history/original-transport-manifest.json.gz');idx={x['path']:x for x in transport['entries']}
for path,file in [('evidence/audit05/original-scope-072.json','history/original-registry.json.gz'),('workflow-20261030/CLOSURE-QUEUE-100.json','history/baseline-059-queue.json.gz')]:
 d=gzip.decompress(read(file));assert (len(d),sha(d),oid('blob',d))==(idx[path]['bytes'],idx[path]['sha256'],idx[path]['git_blob'])
for x in js('history/registry-selection-reconstructed.json')['roles']:assert x['entry']==registry['files'][x['index']]
for x in js('history/queue-selection-reconstructed.json')['entries']:assert x['entry']==queue['entries'][x['index']]
assert queue['entries'][131]['status']=='open-reconciliation' and queue['entries'][2332]['status']=='open-source-reconciliation' and queue['entries'][3443]['status']=='open-source-reconciliation'
for n in [2561,2562]:assert registry['files'][n]['sha256']==next(x['sha256'] for x in reg['entries'] if x.get('role')==n)
h=js('history/prior-current/historical-attribution.json')
for x in h['records_059']:
 d=read(x['archive']);y=idx[x['original_path']];assert (len(d),sha(d),oid('blob',d))==(x['bytes'],x['sha256'],x['git_blob'])==(y['bytes'],y['sha256'],y['git_blob'])
for x in h['records_774']:
 p=read(x['archive']);d=gzip.decompress(p);assert (len(p),sha(p))==(x['bytes'],x['sha256']) and (len(d),sha(d),oid('blob',d))==(x['original_bytes'],x['original_sha256'],x['git_blob'])
for q in h['prior_packets']:
 manifest=next(x for x in q['copies'] if x['name']=='MANIFEST.json');m=js(manifest['archive']);mi={x['path']:x for x in m['files']};assert sha(read(manifest['archive']))==q['original_manifest_sha256']
 for x in q['copies']:
  d=read(x['archive']);assert (len(d),sha(d))==(x['bytes'],x['sha256']);
  if x['name']!='MANIFEST.json':assert mi[x['name']]['sha256']==x['sha256']
f=js('history/fragments-selected-reconstructed.json');i=jgz('history/fragments/EXTENDED-INDEX.json.gz');assert i['snapshot_sha256']==f['snapshot_sha256'];ids={'ADLER-L11-BASIS-POINTS-WIRE-ADMISSION','L12-CLOSURE-NATIVE-SATS-REFLECTION-ADAPTER-OWNERS','L12-CLOSURE-PHYSICAL-SATS-NAMESPACE'};assert f['index_hits']==[x for x in i['entries'] if x['contract_id'] in ids];keys={x['normalized_sha256'] for x in f['index_hits']};allvals=[json.loads(x) for x in gzip.decompress(read('history/fragments/PRINTED-VALUES.jsonl.gz')).splitlines()];assert f['values']==[x for x in allvals if x['normalized_sha256'] in keys]
for x in f['values']:assert sha((json.dumps(x['value'],indent=2,ensure_ascii=False)+'\n').encode())==x['normalized_sha256']
assert next(x['value']['status'] for x in f['values'] if x['normalized_sha256']=='74abcc32b987c41eb9cb8afcb378537d5ee592a221a83cfbd310f7d98964376b')=='source-discovery-complete-with-owned-repair'
r=js('history/p16-recovery.json');assert sha(read('history/p16-reproduced-tracked.patch'))==r['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
c=js('history/prior-current/published-comparison.json');m=js('history/prior-current/MANIFEST.json');mi={x['path']:x for x in m['files']}
for x in c['comparison']:
 o=read(x['original']);p=read(x['published_copy']);assert sha(o)==x['original_sha256'] and sha(p)==x['published_sha256'] and (o==p)==x['byte_identical'];
 if x['member']!='MANIFEST.json':assert mi[x['member']]['sha256']==sha(o)
print(json.dumps({'status':'passed','primary_registered_sources':len(reg['entries']),'supplement_registered_sources':len(supp['entries']),'three_distinct_native_archives':len(reg['archives']),'git_path_proofs':len(gp['paths']),'historical_059_records':len(h['records_059']),'historical_774_records':len(h['records_774']),'historical_queue_indices':[131,2332,3443],'normalized_partial_printed_values':len(f['values']),'product_execution':'none; evidence checks only','writes':'none'},indent=2))
