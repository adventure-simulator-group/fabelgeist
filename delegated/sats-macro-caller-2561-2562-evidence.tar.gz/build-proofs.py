from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();g=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  d=g('cat-file',t,k);assert oid(t,d)==k;p='git-objects/'+k+'.'+t+'.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(d,mtime=0));objects[k]={'type':t,'sha256':sha(d),'bytes':len(d),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def ents(raw):
 out={};i=0
 while i<len(raw):
  end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1);out[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());i=end+21
 return out
def root(rev):
 if rev not in commits:
  d=save('commit',rev);commits[rev]={'root_tree':d.splitlines()[0].split()[1].decode(),'parents':[x.split()[1].decode() for x in d.splitlines() if x.startswith(b'parent ')]}
 return commits[rev]['root_tree']
def proof(rev,path,file,kind):
 d=(b/file).read_bytes();d=gzip.decompress(d) if file.endswith('.gz') else d;cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=ents(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',d)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(d),'bytes':len(d),'git_blob':cur,'preserved_bytes':file,'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for x in json.loads((b/'registration.json').read_bytes())['entries']:
 if x.get('member'):proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],x['archive'],'native package member evidence transported by f82; package revision is its version/checksum')
 else:proof(x['revision'],x['git_path'],x['archive'],'project source or lock; source display windows separately receipted')
for x in json.loads((b/'supplement-registration.json').read_bytes())['entries']:proof(x['revision'],x['git_path'],x['archive'],'additional separately registered current source support')
for x in json.loads((b/'history/prior-current/historical-attribution.json').read_bytes())['records_774']:proof(f82,x['transport_path'],x['archive'],'original 774 supplier evidence transported by f82')
(b/'git-proofs.json').write_text(json.dumps({'schema':'726-sats-macro-caller-reconcile-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'Per-path object identity and transport only; package archive/lock supply native identity. No feature selection, runtime ingress, historical read transfer or whole-lens credit follows.'},indent=2)+'\n');print('paths',len(proofs),'objects',len(objects))
