from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();objects={};proofs=[]
def save(t,k):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,b)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(b,mtime=0));objects[k]={'type':t,'size':len(b),'sha256':h(b),'local':p}
 return b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);m,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return m.decode(),k
 raise KeyError(n)
def proof(rev,path,local,kind,encoding=None):
 b=(r/local).read_bytes();b=gzip.decompress(b) if encoding=='gzip' else b;root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for part in path.split('/'):
  mode,k=lookup(save('tree',tree),part);chain.append({'tree':tree,'name':part,'mode':mode,'object':k});tree=k
 assert tree==oid('blob',b),(rev,path,local);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'encoding':encoding,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(b)})
reg=json.loads((r/'registration.json').read_bytes());guard=json.loads((r/'guard-registration.json').read_bytes());a120='a120390947c89b703dc74c4255a13c035d054c50'
for e in reg['entries']:
 if 'original_index' in e:
  proof(e['historical_transport_revision'],e['historical_transport_path'],e['versions'][0]['path'],'original object via f82; transport only')
  if e['original_index']!=2577:
   proof(a120,e['project_path'],e['versions'][0]['path'],'individual P16 clean base file equality only')
   v=e['versions'][1];proof(v['revision'],e['project_path'],v['path'],'95e current individual file')
 elif 'project_path' in e:
  v=e['versions'][0];proof(v['revision'],e['project_path'],v['path'],'registered 95e support')
v=guard['versions'][0];proof(v['revision'],guard['project_path'],v['path'],'separately registered 95e holder validation support')
rev='eb407672813424d64ec31f208193969f5a62620c'
for path,local in [('handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json','recovered/original-059-queue.json.gz'),('handoff/726-audit-20261030-adler/evidence/continuation-segovb/ledger.json','recovered/original-059-ledger.json.gz')]:proof(rev,path,local,'original 059 checkpoint, not 3821','gzip')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-checkpoint13-four-roles-git-proofs-v1','objects':objects,'proofs':proofs,'qualification':'Per-file and archive equality do not prove snapshot clean, personal read, feature selection, runtime behavior or final 3821 adoption.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'sha',h((r/'git-proofs.json').read_bytes()))
