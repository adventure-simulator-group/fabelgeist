from pathlib import Path
import gzip,json,hashlib,shutil
r=Path(__file__).resolve().parent;src=Path('<LOCAL_PATH_0>'); user=Path('<LOCAL_PATH_1>');pub=Path('<LOCAL_PATH_2>');h=lambda b:hashlib.sha256(b).hexdigest()
for d in ['recovered','historical','prior']:(r/d).mkdir()
for n in ['MANIFEST.json','registry.json.gz','objects.tar.gz','original-059-queue.json.gz','original-059-ledger.json.gz'] :shutil.copyfile(src/n,r/'recovered'/n)
(r/'recovered/p16').mkdir();shutil.copyfile(src/'physical-p16-patch-recovery/tracked.patch',r/'recovered/p16/tracked.patch');shutil.copyfile(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json',r/'recovered/p16/RECOVERY.json')
q=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'));ledger=json.load(gzip.open(r/'recovered/original-059-ledger.json.gz','rt'));inds=[72,127,133,287,1663,2429];rows={str(i):q['entries'][i] for i in inds};findings={e['contract_id']:ledger['discovery_findings_and_dependencies'][e['contract_id']] for e in rows.values() if e['contract_id'] in ledger['discovery_findings_and_dependencies']}
(r/'historical/selections-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed selection from exact preserved original 059 queue and ledger, not original independent record or checkpoint3821.','queue_rows':rows,'ledger_findings':findings},indent=2,ensure_ascii=False)+'\n')
exact={}
for e in rows.values():
 for s in e.get('exact_source_identities_and_assessed_ranges',[]):
  rec=s.get('receipt')
  if rec:exact[rec['path']]=rec['sha256']
for name,digest in exact.items():
 b=(user/name).read_bytes();assert h(b)==digest;(r/'historical'/name).parent.mkdir(parents=True,exist_ok=True);(r/'historical'/name).write_bytes(b)
packets=[('mhr-placement','<LOCAL_PATH_3>','BUNDLE-MANIFEST.json',['report.json','read-receipt.json','support-read-receipt.json','historical-059/segovb/READ-L11-423.json','historical-059/segovb/READ-L11-424.json','historical-059/segovb/READ-L12-874.json','historical-059/segovb/READ-L12-875.json','historical-774/camera-registration-observed-first7.jsonl','historical-774/camera/admission03/placement-identity-admission-028.json.gz','historical-774/camera/admission03/source-range-registration.jsonl.gz','historical-774/root/admission03-scope-reconciliation-046.json.gz']),('hair-facing-terrain','<LOCAL_PATH_4>','MANIFEST.json',['REPORT.json','read-receipt.json','historical/059-READ-L12-712.json','historical/059-READ-CONNECTED-PAR-L12-TEAM021-COMPLETED-SOURCE-VIEWS-v2.json','historical/774-additional-sources.jsonl','historical/774-placement-identity-admission-028.json','historical/774-source-range-registration.jsonl','historical/774-terrain-pack-admission-042.json']),('hair-saphyr-options','<LOCAL_PATH_5>','MANIFEST.json',['REPORT.json','read-receipt.json','historical/774-source-range-registration.jsonl','historical/774-source-qualifications.jsonl'])]
index=[]
for label,path,mname,files in packets:
 p=Path(path);dest=r/'prior'/label;dest.mkdir();mb=(p/mname).read_bytes();m=json.loads(mb);mapping={e['path']:e['sha256'] for e in m['files']};(dest/mname).write_bytes(mb)
 for f in files:
  b=(p/f).read_bytes();assert mapping[f]==h(b),(label,f);out=dest/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 index.append({'label':label,'previous_directory':path,'manifest':mname,'manifest_sha256':h(mb),'copied_files':files})
info={'qualification':'Exact original 059 receipts verified against original queue source references. Prior copied members match frozen manifests. 774 root046 camera pin mismatch in original placement packet remains unresolved; matching later observed stream is not substituted for the historical pin. No prior verifier invoked, read credit transferred, or 3821 restored.','original_059_receipts':exact,'prior_packets':index}
(r/'historical/evidence-index.json').write_text(json.dumps(info,indent=2,ensure_ascii=False)+'\n');print('Direct 059 receipts',len(exact),'prior packet selections',len(index))
