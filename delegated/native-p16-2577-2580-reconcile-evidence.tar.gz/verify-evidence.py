from pathlib import Path
import gzip,hashlib,io,json,tarfile,tomllib
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
m=json.loads((r/'recovered/MANIFEST.json').read_bytes());rb=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());registry=json.loads(rb);assert h(rb)==m['registry_sha256'];assert h((r/'recovered/registry.json.gz').read_bytes())==m['registry_gzip_sha256'];assert h((r/'recovered/objects.tar.gz').read_bytes())==m['objects_archive_sha256']
reg=json.loads((r/'registration.json').read_bytes());guard=json.loads((r/'guard-registration.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());assert rec['registration_sha256']==h((r/'registration.json').read_bytes());assert rec['guard_registration_sha256']==h((r/'guard-registration.json').read_bytes())
archive=(r/'native/serde-saphyr-1.2.0.crate').read_bytes();lock=tomllib.loads((r/'support/current-lock.source').read_text());pkg=next(e for e in lock['package'] if e['name']=='serde-saphyr' and e['version']=='1.2.0');assert pkg['source']=='registry+https://github.com/rust-lang/crates.io-index' and pkg['checksum']==h(archive)
with tarfile.open(r/'recovered/objects.tar.gz') as objects,tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as native:
 for x in reg['entries']+[guard]:
  if 'original_index' in x:
   assert x['historical_registry_row']==registry['files'][x['original_index']];obj=objects.extractfile(x['historical_registry_row']['sha256']).read();assert h(obj)==x['historical_registry_row']['sha256'] and obj==(r/x['versions'][0]['path']).read_bytes()
   if x['original_index']==2577:assert native.extractfile('serde-saphyr-1.2.0/src/de/with_deserializer.rs').read()==obj
  elif x.get('archive_sha256'):
   assert x['archive_sha256']==h(archive) and native.extractfile(x['identity']).read()==(r/x['versions'][0]['path']).read_bytes()
  for v in x['versions']:
   b=(r/v['path']).read_bytes();assert h(b)==v['sha256'] and len(b.splitlines())==v['eof'];p=next(z for z in rec['reads'] if z['path']==v['path']);assert p['display_windows']==v['registered_windows'];observed=set();unread=set()
   for a,z in p['display_windows']:observed.update(range(a,z+1))
   for a,z in p['unread_complement']:unread.update(range(a,z+1))
   assert not observed.intersection(unread) and observed.union(unread)==set(range(1,v['eof']+1))
proof=json.loads((r/'git-proofs.json').read_bytes());objs={}
for k,v in proof['objects'].items():
 b=gzip.decompress((r/v['local']).read_bytes());assert len(b)==v['size'] and h(b)==v['sha256'] and oid(v['type'],b)==k;objs[k]=b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),k
 raise AssertionError(n)
for p in proof['proofs']:
 tree=objs[p['revision']].splitlines()[0].split()[1].decode();assert tree==p['root_tree']
 for c in p['chain']:
  assert tree==c['tree'];mode,k=lookup(objs[tree],c['name']);assert mode==c['mode'] and k==c['object'];tree=k
 assert p['path'].split('/')==[c['name'] for c in p['chain']];b=(r/p['local']).read_bytes();b=gzip.decompress(b) if p.get('encoding')=='gzip' else b;assert h(b)==p['sha256'] and oid('blob',b)==tree==p['blob']
queue=json.loads(gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes()));ledger=json.loads(gzip.decompress((r/'recovered/original-059-ledger.json.gz').read_bytes()));sel=json.loads((r/'historical/selections-reconstructed.json').read_bytes());idx=json.loads((r/'historical/evidence-index.json').read_bytes())
for i in [72,127,133,287,1663,2429]:
 row=queue['entries'][i];assert sel['queue_rows'][str(i)]==row
 if row['contract_id'] in sel['ledger_findings']:assert sel['ledger_findings'][row['contract_id']]==ledger['discovery_findings_and_dependencies'][row['contract_id']]
for p,digest in idx['original_059_receipts'].items():assert h((r/'historical'/p).read_bytes())==digest
for x in idx['prior_packets']:
 base=r/'prior'/x['label'];m=base/x['manifest'];assert h(m.read_bytes())==x['manifest_sha256'];m=json.loads(m.read_bytes());known={y['path']:y['sha256'] for y in m['files']}
 for p in x['copied_files']:assert h((base/p).read_bytes())==known[p]
patch=(r/'recovered/p16/tracked.patch').read_bytes();assert len(patch)==524542 and h(patch)==next(x['patch_sha256'] for x in registry['snapshots'] if x['id']=='physical-p16')
report=json.loads((r/'REPORT.json').read_bytes());assert len(report['reconciliations'])==6 and len(report['lens_perspectives'])==13
manifest=r/'MANIFEST.json'
if manifest.exists():
 files=json.loads(manifest.read_bytes())['files'];entries={e['path']:e for e in files};actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p!=manifest};assert set(entries)==actual
 for n,e in entries.items():b=(r/n).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],n
print('PASS: original registry/archive; native crate/lock/member; P16 and 95e Git proofs; separate personal scope partitions; exact 059 queue/ledger and receipts; prior manifest members; matching P16 tracked patch; thirteen bounded perspectives'+('; full manifest' if manifest.exists() else '; before manifest'))
print('Evidence-only: no parser, product, build, test, probe, repair or runtime validation executed.')
