# Checkpoint 13: roles 2577–2580

This additive source-only packet relates four original roles to six directly
connected 059 queue records. Native serde-saphyr 1.2.0 and dirty physical-P16
project sources retain their distinct identities; their actual fresh display
windows and unread complements are in `read-receipt.json`.

Original registry entries for roles 2578 and 2579 contain an inconsistent
snapshot label, preserved with the original P16 source IDs and camera records.
The historically pinned 774 camera registration digest mismatch is also retained
without substituting later observed bytes. Per-file equality with a120 or 95e
is not evidence that the full P16 snapshot is clean. The later matching tracked
patch excludes seven separately recorded untracked files.

The compressed 059 queue and ledger contain the exact old bytes and Git proofs;
selected queue/ledger excerpts are explicitly reconstructed. Exact original
059 receipts and selected prior frozen packets retain their own authors, dates,
ranges and limitations. No material is promoted to missing checkpoint 3821.

Run `python3 <LOCAL_PATH_0>
to verify this packet without writing to it. This checks evidence only and does
not execute product code, tests, fixtures or any earlier packet verifier.
