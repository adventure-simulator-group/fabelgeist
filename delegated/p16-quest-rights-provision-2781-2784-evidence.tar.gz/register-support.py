from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
specs=[('sampling-continuation','crates/adventuresim-core/src/quest_generation/sampling.rs',[[59,120]]),('witness-order','crates/adventuresim-core/src/quest_generation/solver.rs',[[585,605]]),('quest-model','crates/adventuresim-core/src/quest_generation/model.rs',[[300,335],[470,505]]),('quest-trace-validation','crates/adventuresim-core/src/quest_generation/validation.rs',[[715,745],[865,890]]),('herbalism-rights','crates/adventuresim-core/src/herbalism.rs',[[140,200]]),('travel-time','crates/adventuresim-core/src/strategic_time.rs',[[125,170],[305,325]]),('provision-forecast','crates/adventuresim-core/src/provisioning.rs',[[25,57]])]
entries=[];pending=[]
for name,path,ranges in specs:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(raw.splitlines());blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];local='support/'+name+'.rs';pending.append((local,raw));entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':eof,'planned_display_ranges':ranges,'local':local,'credit':'separately registered connected support; no ordered-role credit'})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Prospective exact current support after separately recorded navigation. Original excluded material never gains historical role credit.','entries':entries};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for loc,raw in pending:
 p=b/loc;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('SHA256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
