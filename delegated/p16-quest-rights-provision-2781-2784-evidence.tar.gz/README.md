# Bounded P16 source evidence: original roles 2781–2784

`REPORT.json` records source references, thirteen partial lens perspectives,
conditional relationships and open questions. Prospective registrations and
`read-receipt.json` distinguish old material, fresh current ranges, additional
support, navigation and unread complements. Stored bytes and other reviewers'
reads do not confer personal coverage.

The original physical-p16 snapshot was dirty and based at a120. A later
independently reproduced tracked patch matches the historical digest; seven
untracked objects are separately archived. Individual file matches do not
make the complete snapshot clean or transfer another snapshot's review. The
f82 revision transports original evidence and 039 is a cataloged per-file
origin, neither is the dirty P16 head.

`historical/` contains exact 059 receipts and 774 supplier records. The
registry source archive and original 059 queue/ledger are retained under
`recovered/`; its 774 catalog and `historical-selections-reconstructed.json`
are explicitly reconstructed records. `prior/` contains independent current
assessments and the earlier named delegate's report. No checkpoint 3821 or
whole-lens completion is claimed.

Run `python3 verify-evidence.py` for offline evidence integrity only. It does
not execute product or fixture code, generated code, macros, builds or tests.
The top-level manifest includes nested manifests.
