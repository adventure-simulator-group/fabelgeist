from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');nav={};navigation=[]
for name in ['navigation-quest.txt','navigation-rights.txt','navigation-calories.txt','navigation-model.txt','navigation-witness.txt','navigation-canonical.txt']:
 lines=(b/name).read_text().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line);assert m;nav.setdefault(m.group(1),set()).add(int(m.group(2)))
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2781:[[1,58]],2782:[[1,100],[101,216]],2783:[[1,90],[91,180],[181,274],[296,297],[719,796]],2784:[[3,3]]};assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];shown=nums(d);navonly=sorted(nav.get(row['path'],set())-shown) if j else []
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':navonly,'unread_after_assigned_and_navigation':comp(v['eof'],shown|set(navonly)),'qualification':'Additional current full-line support is separately recorded below; old exclusions remain outside historical role. Compare Git blobs and prior readers do not confer fresh reads.'})
body={'sampling-continuation':[[59,120],[121,155]],'witness-order':[[585,605]],'quest-model':[[300,335],[470,505]],'quest-trace-validation':[[715,745],[865,890]],'herbalism-rights':[[140,200]],'travel-time':[[125,170],[305,325]],'provision-forecast':[[25,57]],'quest-entry':[[1,60]]};support=[]
for x in load('support-registration.json')['entries']+load('entry-support-registration.json')['entries']:
 d=body[x['name']];shown=nums(d);earlier=[]
 for row in reg['rows']:
  if row['path']==x['path']:earlier=chunks[row['original_index']]
 earlier_set=nums(earlier);navonly=sorted(nav.get(x['path'],set())-shown-earlier_set)
 support.append({'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'previous_assigned_displays':earlier,'navigation_only_lines':navonly,'unread_complement_after_all_displays':comp(x['eof'],shown|earlier_set|set(navonly)),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Newly reconstructed exact personal source displays and navigation after prospective registrations. Incidental test text was not executed.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in ['registration.json','navigation-registration.json','navigation-registration-2.json','navigation-registration-3.json','support-registration.json','additional-support-registration.json','entry-support-registration.json']],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'limits':'No product, generated code, macro, test, fixture, build, runtime probe, repair or publication edit.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('sha256',h((b/'read-receipt.json').read_bytes()))
