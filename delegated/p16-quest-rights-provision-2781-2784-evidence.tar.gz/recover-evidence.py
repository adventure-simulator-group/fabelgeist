from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');orig=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');workspace=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/n,'recovered/'+n,'Exact original registry/archive/059 records; reconstructed catalog or later P16 patch recovery as labelled.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-core/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Applicable current rules; user source-only prohibition governs.')
for n in ['ASSESSMENT-L04-FOLLOWUP-WEIGHT-TOTAL-95E.json','ASSESSMENT-L04-LOCAL-PROBLEM-CAPS-95E.json','ASSESSMENT-L03-QUEST-WEIGHT-NARROWING-95E.json','ASSESSMENT-L01-QUEST-ID-95E.json','ASSESSMENT-L05-EVIDENCE-PROVENANCE-95E.json','ASSESSMENT-L02-GENERATED-AUTHORITY-95E.json','ASSESSMENT-L03-PREPARATION-RIGHTS-95E.json','ASSESSMENT-L03-RIGHTS-VALIDITY-95E.json','ASSESSMENT-SIM-TRAVEL-CUSTODY-95E.json','ASSESSMENT-L01-TRAVEL-WATER-FORECAST-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Prior published bounded assessment/recovery; preserve its named/unnamed reviewer, revision and ranges.')
for n in ['report.json','BUNDLE-MANIFEST.json']:
 copy(Path('<LOCAL_PATH_4>')/n,'prior/web-settlement-'+n,'Prior bounded /root/mhr_character evidence; do not transfer prior source-read credit.')
names=['segovb/READ-L11-453.json','segovb/READ-L11-454.json','segovb/READ-L11-482.json','segovb/OVERLAY-L11-NAVIGATION-001.json','evidence/continuation-segovb/audit-resume-20261027/lens11/batch-037-receipt.json','evidence/continuation-segovb/audit-resume-20261027/lens11/batch-038-receipt.json']+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in range(1701,1705)]
for n in names:copy(orig/n,'historical/059/'+n,'Exact original 059 receipt/registration/overlay; same-lens reuse is not a fresh display.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for owner,folder,names in [('camera','initial07-redundant-authority',['source-range-registration.jsonl','additional-sources.jsonl','qualifications.jsonl','contracts.jsonl','findings.jsonl']),('rig','initial06-type-ownership',['source-range-registration.jsonl','additional-sources.jsonl','qualifications.jsonl','contracts-054.json']),('root','initial04-invariant-operations',['source-range-registration.jsonl','contract-groups-054.json'])]:
 for n in names:
  gp=f'handoff/774/adler-original/audit/continuation/{owner}/{folder}/{n}';raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{owner}-{n}','git:'+rev+':'+gp,'Exact original 774 supplier record via f82 evidence transport.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw);selection={'kind':'Newly reconstructed selected rows from exact original registry; not an original standalone record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in range(2781,2785)},'snapshot_rows':[x for x in r['snapshots'] if x['id']=='physical-p16'],'qualification':'P16 dirty snapshot distinct from per-file base equality and 059/3821 historical stages.'};(b/'historical-selections-reconstructed.json').write_text(json.dumps(selection,indent=2)+'\n')
(b/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'No prior reviewer or lens credit transfer; f82 transports evidence only.'},indent=2)+'\n');print('records',len(records),'sha256',h((b/'historical-manifest.json').read_bytes()))
