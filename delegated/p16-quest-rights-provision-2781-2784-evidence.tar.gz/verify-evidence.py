'''Offline evidence-integrity verification only; no product, build, fixture or test execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,re,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');sel=load('historical-selections-reconstructed.json');proof=load('git-proofs.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files']
assert all(original[i]==sel['registry_rows'][str(i)] for i in range(2781,2785));assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id']=='physical-p16']
snapshot=sel['snapshot_rows'][0];patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['live_comparison']['status_counts']['??']==7
catalog=load('recovered/catalog-774.json')['rows'];expected={2781:[[1,58]],2782:[[1,216]],2783:[[1,274],[296,297],[719,796]],2784:[[3,3]]}
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];raw=(b/old['local']).read_bytes();assert t.extractfile(old['sha256']).read()==raw and h(raw)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256'];assert original[i]['material_ranges']==expected[i]==row['original_material_ranges'];assert catalog[i]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path'];assert (b/cur['local']).read_bytes()==raw and cur['equals_historical_object']
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==raw and c['display_planned']==False
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(x['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(rr):return [i for a,z in rr for i in range(a,z+1)]
def part(n,rr,lines):
 v=nums(rr)+lines;return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'] and set(nums(p['actual_display_chunks']))==set(nums(expected[row['original_index']]));assert part(v['eof'],p['actual_display_chunks']+p['unread_after_assigned_and_navigation'],p['navigation_only_lines_at_assigned_scope']);assert p['original_material_ranges']==(expected[row['original_index']] if j==0 else [])
planned={x['local']:x for n in ['support-registration.json','entry-support-registration.json'] for x in load(n)['entries']};extra=load('additional-support-registration.json')['entries'][0]
for p in rec['support']:
 e=planned[p['local']];raw=(b/p['local']).read_bytes();assert h(raw)==p['sha256']==e['sha256'] and len(raw.splitlines())==p['eof']==e['eof'] and p['ordered_role_credit']==0;assert part(p['eof'],p['full_line_body_displays']+p['previous_assigned_displays']+p['unread_complement_after_all_displays'],p['navigation_only_lines']);allowed=set(nums(e['planned_display_ranges']));allowed|=set(nums(extra['planned_display_ranges'])) if p['local']==extra['local'] else set();assert set(nums(p['full_line_body_displays']))<=allowed
nav={}
for x in rec['navigation_output_receipts']:
 raw=(b/x['output']).read_bytes();lines=raw.decode().splitlines();assert h(raw)==x['sha256'] and len(lines)==x['saved_output_lines'];displayed=nums(x['personally_displayed_output_lines']);unread=nums(x['unread_saved_output_lines']);assert set(displayed+unread)==set(range(1,len(lines)+1)) and len(displayed)+len(unread)==len(lines)
 for j in displayed:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):(.*)$',lines[j-1]);assert m;path,num,body=m.group(1),int(m.group(2)),m.group(3);nav.setdefault(path,set()).add(num)
  for p in rec['support']:
   if p['path']==path:assert (b/p['local']).read_text().splitlines()[num-1]==body
  for row in reg['rows']:
   if row['path']==path:assert (b/row['versions'][1]['local']).read_text().splitlines()[num-1]==body
assert {k:sorted(v) for k,v in nav.items()}==rec['navigation_actual_source_lines']
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()];camera=readjsonl('historical/774/camera-source-range-registration.jsonl');rig=readjsonl('historical/774/rig-source-range-registration.jsonl');root=readjsonl('historical/774/root-source-range-registration.jsonl')
for i in range(2781,2785):
 ob=original[i]['scope_registration'][0];rows=camera if i in [2781,2782] else rig if i==2783 else root;assert rows[ob['row_1based']-1]==ob['original_record']
quals=readjsonl('historical/774/camera-qualifications.jsonl');x=next(x for x in quals if x.get('registration_id')=='CAMERA-INITIAL07-REG011');assert x['effective_material_ranges']==[[1,216]] and x['context_only_excluded']==[[217,219]]
quals=readjsonl('historical/774/rig-qualifications.jsonl');x=next(x for x in quals if x.get('id')=='RIG-INITIAL06-QUAL-016');assert x['qualified_material_ranges']==expected[2783] and x['context_only_ranges']==[[275,275],[797,797]]
find=readjsonl('historical/774/camera-findings.jsonl');assert any(x.get('id')=='CAMERA-INITIAL07-F015' for x in find)
for i in range(2781,2785):
 r=load('historical/059/segovb/READ-L11-453.json' if i==2781 else 'historical/059/segovb/READ-L11-454.json');x=next(x for x in r['sources'] if x['original_index']==i);raw=(b/f'historical/059/segovb/REGISTRATION-SEGOVB-{i-1080}.json').read_bytes();assert x['fresh_personal_body_reads']==expected[i] and h(raw)==x['registration_sha256']
over=load('historical/059/segovb/READ-L11-482.json')['rows']
for i,rr in [(213,[[60,109]]),(214,[[591,597]]),(218,[[380,407]])]:
 x=next(x for x in over if x['overlay_index']==i);assert x['fresh_personal_body_reads']==[] and x['reused_ranges']==rr
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and len(proof['proofs'])==39
if (b/'MANIFEST.json').exists():
 seen=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert h(raw)==x['sha256'] and len(raw)==x['bytes'],x['path'];seen.add(x['path'])
 assert seen=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and p!=b/'MANIFEST.json'}
print('PASS: P16 roles2781–2784 original material and current personal displays; old exclusions, overlay reuse, current support, P16 patch qualification and 39 Git proofs; thirteen bounded perspectives; evidence only.')
