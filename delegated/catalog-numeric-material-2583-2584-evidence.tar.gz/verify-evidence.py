import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda f:json.loads((p/f).read_bytes())
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['registry_sha256']==sha(raw) and all(v==reg['files'][int(k)] for k,v in sel['roles'].items()) and sel['physical_p16_snapshot']==next(s for s in reg['snapshots'] if s['id']=='physical-p16')
for i in (2583,2584):assert reg['files'][i]['snapshot']=='physical-p16' and sha((p/f'source/p16-{i}.rs').read_bytes())==reg['files'][i]['sha256']
for name in ('reference-index.json','rules.json','skills.json'):
 for e in load(name)['records']:
  b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert sha(b)==e['sha256']
patch=(p/'reference/tracked.patch').read_bytes();recovery=load('reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert sha(patch)==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and len(patch)==recovery['recovered_patch']['bytes'] and recovery['live_comparison']['status_counts']['??']==7
r=load('registration.json');t=load('read-receipt.json');assert t['registration_sha256']==sha((p/'registration.json').read_bytes()) and datetime.datetime.fromisoformat(t['recorded_utc'])>datetime.datetime.fromisoformat(r['registered_utc']) and len(r['entries'])==len(t['entries'])==17
def nums(rs):return {i for lo,hi in rs for i in range(lo,hi+1)}
for e,v in zip(r['entries'],t['entries']):
 b=(p/e['archive']).read_bytes();assert e['tag']==v['tag'] and sha(b)==e['sha256']==v['sha256'] and blob(b)==e['git_blob'] and len(b.splitlines())==e['EOF'];seen=nums(v['displayed_chunks']);unseen=nums(v['unread_complement']);assert nums(e['registered_ranges'])==seen and seen|unseen==set(range(1,e['EOF']+1)) and not seen&unseen
x=load('drop-registration.json');v=load('drop-read-receipt.json');b=(p/x['archive']).read_bytes();assert v['registration_sha256']==sha((p/'drop-registration.json').read_bytes()) and datetime.datetime.fromisoformat(v['recorded_utc'])>datetime.datetime.fromisoformat(x['registered_utc']) and sha(b)==x['sha256']==v['sha256'] and blob(b)==x['git_blob'] and nums(v['displayed_chunks'])==nums(x['registered_ranges']) and nums(v['displayed_chunks'])|nums(v['unread_complement'])==set(range(1,x['EOF']+1)) and not nums(v['displayed_chunks'])&nums(v['unread_complement'])
packages={z['name']+'-'+z['version']:z for z in r['packages']}
for z in packages.values():assert sha((p/z['archive']).read_bytes())==z['sha256']
for e in r['entries']:
 if e['kind']=='native-package':
  with tarfile.open(fileobj=io.BytesIO((p/packages[e['package']]['archive']).read_bytes()),mode='r:gz') as tar:assert tar.extractfile(e['member']).read()==(p/e['archive']).read_bytes()
lock=tomllib.loads((p/'source/root.lock').read_text())['package']
for key,z in packages.items():
 found=[e for e in lock if e['name']==z['name'] and e['version']==z['version']];assert len(found)==1 and found[0]['source']=='registry+https://github.com/rust-lang/crates.io-index' and found[0]['checksum']==z['sha256']
qraw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());lraw=gzip.decompress((p/'reference/ledger.json.gz').read_bytes());q=json.loads(qraw);l=json.loads(lraw);x=load('059-selection-reconstructed.json');assert x['queue_source_sha256']==sha(qraw) and x['ledger_source_sha256']==sha(lraw) and all(q['entries'][int(i)]==v for i,v in x['entries'].items())
for path,v in x['journal_entries'].items():
 z=l
 for part in path.strip('/').split('/'):z=z[int(part)] if isinstance(z,list) else z[part]
 assert z==v
assert all(not q['entries'][i]['exact_source_identities_and_assessed_ranges'] and not q['entries'][i]['source_receipt_contexts'] for i in (602,604,1786)) and len(q['entries'][2433]['granular_contract_views'])==1 and len(q['entries'][2435]['granular_contract_views'])==2
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};hist=load('historical-index.json');assert not hist['unavailable_requested_records']
for e in hist['records']:
 b=(p/e['file']).read_bytes();b=gzip.decompress(b) if e.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])
 if e['kind']=='original-059':assert (idx[e['transport_path']]['bytes'],idx[e['transport_path']]['sha256'],idx[e['transport_path']]['git_blob'])==(len(b),sha(b),blob(b))
for lens,n in [('L11',424),('L12',876)]:
 read=(p/f'history-059/segovb/READ-{lens}-{n}.json').read_bytes();state=(p/f'history-059/segovb/STATE-{lens}-{n}.json').read_bytes();v=load(f'history-059/segovb/VERIFY-{lens}-{n}.json');assert v['receipt_sha256']==sha(read) and v['state_sha256']==sha(state)
read=load('history-059/segovb/READ-L11-424.json')
for e in read['sources']:
 if e['original_index'] not in (2583,2584):continue
 rel=e['registration'].split('target/726-audit-adler-20261027/',1)[1];assert e['registration_sha256']==sha((p/'history-059'/rel).read_bytes()) and e['sha256']==reg['files'][e['original_index']]['sha256']
read=load('history-059/segovb/READ-L12-876.json');assert read['root_personal_rereads']==[] and read['proposal_sha256']==sha((p/'history-059'/read['proposal']).read_bytes())
for e in read['rows']:
 if e['original_index'] not in (2583,2584):continue
 assert e['registration_sha256']==sha((p/'history-059'/e['registration']).read_bytes()) and e['identity_specific_windows_qualification']['sha256']==sha((p/'history-059'/e['identity_specific_windows_qualification']['path']).read_bytes()) and e['source_sha256']==reg['files'][e['original_index']]['sha256']
read=load('history-059/segovb/READ-L13-PARALLEL-173.json');assert read['root_personal_rereads']==[]
for k in ('delegated_receipt','delegated_verification','agent_validation_manifest'):
 e=read[k];rel=e['path'].split('target/726-audit-adler-20261027/',1)[-1];assert e['sha256']==sha((p/'history-059'/rel).read_bytes())
for n in (2433,2435):
 for v in q['entries'][n]['granular_contract_views']:
  a=v['root_adoption'];assert a['sha256']==sha((p/'history-059'/a['path']).read_bytes()) and a['verification_sha256']==sha((p/'history-059'/a['verification']).read_bytes())
  for e in v['exact_source_identities_and_assessed_ranges']:
   for k in ('receipt','prospective_registration'):
    if k in e and e[k].get('path') in idx:assert e[k]['sha256']==sha((p/'history-059'/e[k]['path']).read_bytes())
prior=load('prior-index.json');m=(p/'prior/MANIFEST.json').read_bytes();assert sha(m)==prior['original_manifest_sha256']=='01d10d487d6fc1b3b877cbe07f068a41bc666491ceacc96c3bee2a85c919dc80';idxprior={e['path']:e for e in json.loads(m)['files']}
for e in prior['selected_files']:
 b=(p/'prior'/e['path']).read_bytes();assert (len(b),sha(b))==(e['bytes'],e['sha256'])==(idxprior[e['path']]['bytes'],idxprior[e['path']]['sha256'])
pub=load('reference/DELEGATED-EVIDENCE-CHECKPOINT-14.json');entry=next(z for z in pub['bundles'] if z['bundle_id']=='p16-catalog-helpers-hair-ops');assert entry['archive_sha256']==prior['published_archive_sha256'];member=next(z for z in entry['members'] if z['path']=='REPORT.json');assert member['original_sha256']==sha((p/'prior/REPORT.json').read_bytes()) and member['published_sha256']==sha((p/'reference/published-prior-report.json').read_bytes())
pin=hist['rig_registration_pin_qualification'];rec=json.loads(gzip.decompress((p/'history-774/continuation/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));rreg=gzip.decompress((p/'history-774/continuation/rig/admission03/source-range-registration.jsonl.gz').read_bytes());rq=gzip.decompress((p/'history-774/continuation/rig/admission03/source-qualifications.jsonl.gz').read_bytes());assert rec['input_pins'][3]['sha256']==pin['root046_rig_registration_expected']!=sha(b''.join(rreg.splitlines(keepends=True)[:35]))==pin['later_first35_sha256'];assert rec['input_pins'][4]['sha256']==pin['root046_qualification_expected']==sha(b''.join(rq.splitlines(keepends=True)[:31]))==pin['later_first31_qualification_sha256']
quals={z['registration_id_resolved']:z['original_record'] for z in rec['role_qualifications'] if z.get('supplier')=='rig' and 'registration_id_resolved' in z}
for role,n in ((2583,16),(2584,17)):
 z=quals[f'RIG-ADMISSION03-REGISTER-{n:03}'];assert z['source_id']==reg['files'][role]['source_id'] and z['actual_material_body_ranges']==z['original_ranges']==reg['files'][role]['material_ranges']
proof=load('git-proofs.json');objs={}
for oid,e in proof['objects'].items():
 b=gzip.decompress((p/e['archive']).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and hashlib.sha1(e['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objs[oid]=(e['type'],b)
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in proof['proofs']:
 typ,c=objs[x['revision']];assert typ=='commit';tree=c.splitlines()[0].split()[1].decode();assert tree==x['commit_tree'];parts=x['path'].split('/');assert len(parts)==len(x['chain'])
 for name,link in zip(parts,x['chain']):
  assert link['tree']==tree and link['name']==name;typ,b=objs[tree];assert typ=='tree';mode,tree=entries(b)[name];assert mode==link['mode'] and tree==link['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert sha(b)==x['sha256'] and blob(b)==x['blob']==tree
report=load('report.json');assert len(proof['proofs'])==27 and len(report['lens_perspectives'])==13 and [z['index'] for z in report['related_history']['selected_059_queue']]==[602,604,1786,2433,2435]
print(json.dumps({'status':'pass','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_current_and_native_sources':18,'git_proofs':len(proof['proofs']),'git_objects':len(objs),'historical_records':len(hist['records']),'selected_queue_entries':5,'lens_perspectives':13,'qualification':'Evidence integrity only: personal windows and complements, package/lock member identity, 059/774 source attribution, earlier frozen manifest, dirty P16 patch qualification, public redaction metadata and Git objects. No feature resolution, parser, product, test, build, fixture or probe executed.'},indent=2))
