import datetime,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'registration.json').read_bytes());rows=[]
def comp(n,rs):
 unseen=set(range(1,n+1))-{i for a,b in rs for i in range(a,b+1)};out=[]
 for i in sorted(unseen):
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
for e in r['entries']:
 chunks=e['registered_ranges']
 if e['tag']=='validation':chunks=[[249,273],[301,310],[510,532],[637,685],[686,735]]
 if e['tag']=='root-lock':chunks=[[9397,9405],[9417,9430]]
 rows.append({'tag':e['tag'],'kind':e['kind'],'archive':e['archive'],'sha256':e['sha256'],'EOF':e['EOF'],'displayed_chunks':chunks,'unread_complement':comp(e['EOF'],chunks)})
(p/'read-receipt.json').write_text(json.dumps({'author':'/root/mhr_character','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration':'registration.json','registration_sha256':sha((p/'registration.json').read_bytes()),'entries':rows,'qualification':'Actual independent numbered untruncated source displays after registration. Native code is source only, lock metadata scan not full-body reading or Cargo feature resolution; no earlier read credit transferred.'},indent=2)+'\n')
