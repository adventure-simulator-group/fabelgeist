# Catalog numeric and material follow-up

`report.json` records the bounded checkpoint 14 assessment, current safeguards,
conditional representation questions, five selected historical queue records,
and open producer/consumer paths. `registration.json`, `drop-registration.json`
and their independent read receipts preserve exact personal displays and unread
complements. Native package sources are identified by archive and lock checksums;
lock metadata does not resolve enabled Cargo features.

`registry-selection-reconstructed.json` and `059-selection-reconstructed.json`
are exact selections from separately retained earlier source records.
`historical-index.json` inventories exact 059 and f82-transported 774 records,
while `prior/` retains selected independently attributed original delegate
records. The historical P16 adapter and current raw f32 schema are separate
revision scopes. Per-file equality does not establish clean historical trees.
The later matching tracked patch excludes seven separately checked untracked
paths and does not establish the original command.

`verification.json` is evidence-integrity verification only. Run
`python3 verify-evidence.py` and `python3 verify-manifest.py` for offline
checks of this packet; neither executes product, parsers, macros, builds, tests,
fixtures or probes. Some original records contain local paths, while checkpoint
metadata separately identifies public redactions and original hashes. No lens
closure, automatic alias, duplicate count or checkpoint3821 restoration follows.
