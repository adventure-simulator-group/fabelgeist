import gzip,hashlib,json,pathlib,shutil,subprocess
p=pathlib.Path(__file__).parent;pub=pathlib.Path('<LOCAL_PATH_0>');old=pathlib.Path('<LOCAL_PATH_1>');prior=pathlib.Path('<LOCAL_PATH_2>');sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();(p/'reference').mkdir(exist_ok=True);refs=[]
for src,dst in [('recovered/original-registry-source-archive/registry.json.gz','registry.json.gz'),('recovered/original-transport-manifest.json.gz','original-transport-manifest.json.gz'),('RECOVERY-PHYSICAL-P16-PATCH-20261111.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json'),('recovered/physical-p16-patch-recovery/tracked.patch','tracked.patch'),('DELEGATED-CHECKPOINT-14-QUALIFICATION.json','DELEGATED-CHECKPOINT-14-QUALIFICATION.json'),('DELEGATED-EVIDENCE-CHECKPOINT-14.json','DELEGATED-EVIDENCE-CHECKPOINT-14.json'),('delegated/p16-catalog-helpers-hair-ops-report.json','published-prior-report.json'),('ASSESSMENT-L03-CATALOG-DIMENSIONS-95E.json','ASSESSMENT-L03-CATALOG-DIMENSIONS-95E.json')]:
 b=(pub/src).read_bytes();(p/'reference'/dst).write_bytes(b);refs.append({'publication_path':src,'file':'reference/'+dst,'sha256':sha(b),'bytes':len(b)})
assert sha((p/'reference/tracked.patch').read_bytes())=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for name,expected in [('queue','2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'),('ledger','3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac')]:
 b=(pub/f'baseline-059/{name}.json').read_bytes();assert sha(b)==expected;(p/f'reference/{name}.json.gz').write_bytes(gzip.compress(b,mtime=0));refs.append({'publication_path':f'baseline-059/{name}.json','file':f'reference/{name}.json.gz','encoding':'gzip','sha256':sha(b),'bytes':len(b),'qualification':'Earlier reconstructed 059 data, not missing checkpoint3821.'});globals()[name]=json.loads(b)
qs=(602,604,1786,2433,2435);s=ledger['segovb_continuation'];journals={'/segovb_continuation/additional_pending_connected_contracts/52':s['additional_pending_connected_contracts'][52],'/segovb_continuation/additional_pending_connected_contracts/54':s['additional_pending_connected_contracts'][54],'/segovb_continuation/lens12/pending_connected_contracts/897':s['lens12']['pending_connected_contracts'][897],'/segovb_continuation/lens13/delegated_connected_contracts_pending_alias/281':s['lens13']['delegated_connected_contracts_pending_alias'][281]}
(p/'059-selection-reconstructed.json').write_text(json.dumps({'queue_source_sha256':sha((pub/'baseline-059/queue.json').read_bytes()),'entries':{str(i):queue['entries'][i] for i in qs},'ledger_source_sha256':sha((pub/'baseline-059/ledger.json').read_bytes()),'journal_entries':journals,'qualification':'Exact selection from complete earlier reconstructed 059 queue/ledger. Three pending entries have no source identities; entries2433/2435 retain explicitly attributed source views and both 2435 views. No implicit alias or closure.'},indent=2)+'\n');(p/'reference-index.json').write_text(json.dumps({'records':refs},indent=2)+'\n')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);(p/'registry-selection-reconstructed.json').write_text(json.dumps({'registry_sha256':sha(raw),'roles':{str(i):reg['files'][i] for i in (2583,2584)},'physical_p16_snapshot':next(s for s in reg['snapshots'] if s['id']=='physical-p16'),'qualification':'Exact registry fields; dirty physical-p16 is not clean a120.'},indent=2)+'\n')
m=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(m)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';idx={e['path']:e for e in json.loads(gzip.decompress(m))['entries']};wanted=set()
def walk(o):
 if isinstance(o,dict):
  for v in o.values():walk(v)
 elif isinstance(o,list):
  for v in o:walk(v)
 elif isinstance(o,str):
  rel=o.split('target/726-audit-adler-20261027/',1)[-1]
  if rel in idx:wanted.add(rel)
for i in qs:walk(queue['entries'][i])
for lens,n in [('L11',424),('L12',876)]:
 for prefix in ('READ','STATE','VERIFY'):wanted.add(f'segovb/{prefix}-{lens}-{n}.json')
wanted.update(['segovb/REGISTRATION-SEGOVB-1494.json','segovb/REGISTRATION-SEGOVB-1495.json','parallel-l12-20261029/REGISTRATION-PAR-L12-634.json','parallel-l12-20261029/REGISTRATION-PAR-L12-635.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-634-WINDOWS-ORIGINAL2583.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-635-WINDOWS-ORIGINAL2584.json','parallel-l12-20261029/PROPOSAL-L12-876.json','segovb/READ-L13-PARALLEL-173.json','parallel-l13-20261029/READ-PL13-175.json','parallel-l13-20261029/VERIFY-PL13-175.json','parallel-l13-20261029/REGISTRATION-PL13-175.json','parallel-l13-20261029/VALIDATION-PROPOSAL-PL13-173-175.json'])
records=[];missing=[]
for rel in sorted(wanted):
 if rel not in idx or not (old/rel).is_file():missing.append({'path':rel,'in_transport_manifest':rel in idx,'in_extraction':(old/rel).is_file()});continue
 b=(old/rel).read_bytes();e=idx[rel];assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']);dst=p/'history-059'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);records.append({'kind':'original-059','transport_path':rel,'file':str(dst.relative_to(p)),'sha256':sha(b),'bytes':len(b),'git_blob':blob(b)})
manifest=(prior/'MANIFEST.json').read_bytes();assert sha(manifest)=='01d10d487d6fc1b3b877cbe07f068a41bc666491ceacc96c3bee2a85c919dc80';(p/'prior').mkdir(exist_ok=True);(p/'prior/MANIFEST.json').write_bytes(manifest);pri={e['path']:e for e in json.loads(manifest)['files']};selected=[]
for rel in ['REPORT.json','registration.json','read-receipt.json','support-registration.json','support-registration-2.json','support-registration-3.json','historical-manifest.json','pr-file-comparison.json','git-proofs.json']:
 b=(prior/rel).read_bytes();assert (len(b),sha(b))==(pri[rel]['bytes'],pri[rel]['sha256']);(p/'prior'/rel).write_bytes(b);selected.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
(p/'prior-index.json').write_text(json.dumps({'author':'/root/hair_ops','original_manifest_sha256':sha(manifest),'selected_files':selected,'published_archive':'delegated/p16-catalog-helpers-hair-ops-evidence.tar.gz','published_archive_sha256':'c3743df2b3be49ca82cd74ef0f22389d565ecc2eaf3724e79af52742be7c19db','qualification':'Selected exact original bytes checked against frozen prior manifest, no prior verifier run; separately attributed reads not transferred. Public archive has redacted members as documented in checkpoint14 qualification.'},indent=2)+'\n')
for role in (2583,2584):
 rel=f'source/p16-{role}.rs';b=(prior/rel).read_bytes();assert (len(b),sha(b))==(pri[rel]['bytes'],pri[rel]['sha256'])==(reg['files'][role]['bytes'],reg['files'][role]['sha256']);(p/f'source/p16-{role}.rs').write_bytes(b)
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';paths=[]
oldindex=json.loads((prior/'historical-manifest.json').read_bytes())
for e in oldindex['exact_original_files']:
 if e['kind']=='exact historical 774 original':paths.append(e['git_path'])
paths += ['handoff/774/adler-original/audit/continuation/rig/admission03/contract-groups.jsonl','handoff/774/adler-original/audit/continuation/root/admission03-scope-reconciliation-046.json']
for path in paths:
 b=subprocess.check_output(['git','-C',str(pub),'show',f82+':'+path]);dst=p/'history-774'/(path.removeprefix('handoff/774/adler-original/audit/')+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(b,mtime=0));records.append({'kind':'historical-774','transport_path':path,'file':str(dst.relative_to(p)),'encoding':'gzip','sha256':sha(b),'bytes':len(b),'git_blob':blob(b)})
previous=json.loads(pathlib.Path('<LOCAL_PATH_3>').read_bytes());(p/'historical-index.json').write_text(json.dumps({'records':records,'unavailable_requested_records':missing,'rig_registration_pin_qualification':previous['qualifications'],'qualification':'Original 059 checked against transport manifest and historical 774 tree-proved independently. Prior and later tracked-patch evidence retain attribution; none is checkpoint3821.'},indent=2)+'\n')
for name in ('rules','skills'):shutil.copytree('<LOCAL_PATH_4>'+name,p/name)
for name in ('rules.json','skills.json','build-manifest.py','verify-manifest.py'):shutil.copyfile('<LOCAL_PATH_4>'+name,p/name)
print('059',len(wanted)-len(missing),'missing',missing,'774',len(paths))
