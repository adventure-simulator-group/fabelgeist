# Strategic place and generated client evidence

This source-only review by `/root/rig_identity` covers original roles 2720–2723
against pinned project revision `95e63628f9d70b8dd6e6fede64334696c6995009`.
Roles 2720–2722 are recovered physical-p16 objects; role 2723 is the separate
pr-working manifest. `REPORT.json` preserves the exact material scopes,
connected findings, nonfindings, open questions and thirteen bounded lens
perspectives. It does not assert whole-lens completion.

Prospective registration and personal-read receipts distinguish old and
current source displays, support windows and unread complements. Full retained
source bytes are not automatically read coverage. The previous 2718–2719
review belongs to `/root/mhr_character`; that complete exact local packet and
the earlier `/root/rig_identity` native-macro packet are preserved under
`history/` with their own manifests, revisions and authors. Neither supplies
fresh role credit to this packet.

The first three files and the separate manifest match individual a120, 6533
and pinned 95e file objects. Such per-file equality does not establish a clean
historical snapshot. f82 is evidence transport; a120 is the P16 base, not a
dirty project commit. The later reproduced tracked patch matches the original
P16 digest but excludes seven untracked paths and does not prove historical
invocation, uninterrupted custody or current worktree state.

The full recovered registry and original 059 transport manifest, selected exact
059 receipts and 774 original records are retained. Selected registry and
queue JSON files are explicitly reconstructed selections. Original 059 payload
Git-path proof was unavailable in inspected local stores; selected 059 bytes
are matched to the recovered original transport manifest. The preserved L13
proposal is a partial transcript extract; the complete packet, qualification
and adoption remain unrecovered. No record becomes checkpoint 3821.

Generated player/item records are read-only transport source. The manifest and
lock identify the declared SDK package without resolving features or invoking a
macro. Local paths and historical archives require publication review and any
redacted copy must retain separate original and redacted hashes.

Run `python3 verify-evidence.py` and `python3 verify-manifest.py` only for
integrity. They do not run product code, generated-client generation, builds,
tests, fixtures, macros, database, probes or runtime validation.
