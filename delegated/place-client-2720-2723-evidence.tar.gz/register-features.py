from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();spec=[('core-features','crates/adventuresim-core/Cargo.toml',[[1,45]]),('module-features','crates/adventuresim-stdb-module/Cargo.toml',[[1,30]])];rows=[]
for tag,path,ranges in spec:
 d=git('show',rev+':'+path);eof=len(d.splitlines());dest='support/'+tag+'.source';(b/dest).write_bytes(d);rows.append({'id':tag,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':[[a,min(z,eof)] for a,z in ranges],'qualification':'Source declarations only; no feature resolution, compilation or macro execution.'})
out={'schema':'726-prospective-feature-support-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'feature-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
