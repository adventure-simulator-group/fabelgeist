from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);objects={};commits={};proofs=[]
def save(t,k):
 if k not in objects:
  raw=git('cat-file',t,k);assert oid(t,raw)==k;p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objects[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
def root(rev):
 if rev not in commits:
  c=save('commit',rev);commits[rev]={'root_tree':c.splitlines()[0].split()[1].decode(),'commit_object':rev}
 return commits[rev]['root_tree']
def proof(rev,path,body,kind):
 p=b/body;raw=gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes();cur=root(rev);chain=[]
 for seg in path.split('/'):
  mode,child=entries(save('tree',cur))[seg];chain.append({'tree':cur,'name':seg,'mode':mode,'object':child});cur=child
 assert oid('blob',raw)==cur;proofs.append({'revision':rev,'path':path,'kind':kind,'sha256':sha(raw),'bytes':len(raw),'git_blob':cur,'preserved_bytes':body,'path_chain':chain})
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';base='a120390947c89b703dc74c4255a13c035d054c50';pr='6533e444fa37552927070cc8d8190907fd3b413e';origin='039329518e264f19206cf5b0b98d177433f40c17';cur='95e63628f9d70b8dd6e6fede64334696c6995009';e275='e2755a732c84e67296b5e3441a4259a84f461b2f';regs=json.loads((b/'registration.json').read_bytes())['entries']
for role in range(2720,2724):
 h=next(x for x in regs if x['id']==f'{role}-historical');c=next(x for x in regs if x['id']==f'{role}-current');proof(f82,h['git_path'],h['archive'],'f82 transport of exact recovered snapshot object, not project revision')
 for r,k in [(base,'P16 individual clean base file'),(pr,'pr-working 6533 individual file'),(cur,'pinned 95e source')]:proof(r,h['source_path'],h['archive'] if r!=cur else c['archive'],k)
 if role!=2723:proof(origin,h['source_path'],h['archive'],'059 catalog_origin per-file equality; not P16 dirty commit')
 if role==2720:proof(e275,h['source_path'],h['archive'],'previous 059 root L2 e275 per-file equality, original reviewer retained')
seen=set()
for name in ['support-registration.json','support2-registration.json','feature-registration.json']:
 for x in json.loads((b/name).read_bytes())['entries']:
  if x['git_path'] not in seen:proof(cur,x['git_path'],x['archive'],'independently displayed current support; read scopes in receipt');seen.add(x['git_path'])
proof(cur,'crates/adventuresim-core/AGENTS.md','core-AGENTS.md','applicable source rules')
for x in json.loads((b/'historical-attribution.json').read_bytes())['records_774']:proof(x['revision'],x['transport_path'],x['preserved'],'exact 774 historical reviewer record at f82')
out={'schema':'726-place-client-git-proofs-v1','commits':commits,'objects':objects,'paths':proofs,'qualification':'All paths prove exact file identity only; no snapshot cleanliness or package/native runtime feature resolution. f82 is transport, a120 P16 base; 039 catalog origin and e275 prior root read are separate revisions.'};(b/'git-proofs.json').write_text(json.dumps(out,indent=2)+'\n');print('git paths',len(proofs),'objects',len(objects))
