from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';git=lambda *a:subprocess.check_output(['git','-C',repo,*a]);sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest();(b/'support').mkdir(exist_ok=True)
spec=[('tactical-source','crates/adventuresim-stdb-module/src/tactical.rs',[[250,500]]),('spawn-admission','crates/adventuresim-tactical-server/src/player_projection/spawn_admission.rs',[[1,220]]),('player-projection','crates/adventuresim-tactical-server/src/player_projection.rs',[[510,650],[800,860]]),('equipment-projection','crates/adventuresim-tactical-server/src/player_projection/projection_equipment.rs',[[1,170]]),('world-event','crates/adventuresim-core/src/world_event.rs',[[280,380]]),('event-store','crates/adventuresim-stdb-module/src/world_events.rs',[[940,1000]]),('food-consumption','crates/adventuresim-stdb-module/src/food/consumption.rs',[[70,100]]),('foraging-place','crates/adventuresim-stdb-module/src/foraging.rs',[[400,425]]),('cargo-workspace','Cargo.toml',[[165,185]]),('cargo-lock','Cargo.lock',[[9970,10000]])]
rows=[]
for tag,path,ranges in spec:
 r=subprocess.run(['git','-C',repo,'show',rev+':'+path],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if r.returncode!=0:print('UNAVAILABLE',path);continue
 d=r.stdout;eof=len(d.splitlines());ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];dest='support/'+tag+'.source';(b/dest).write_bytes(d);rows.append({'id':tag,'revision':rev,'git_path':path,'archive':dest,'sha256':sha(d),'git_blob':oid(d),'bytes':len(d),'eof':eof,'prospective_personal_read_ranges':ranges,'qualification':'Independently registered bounded current support; earlier peer reads retain authorship, no role2718–2719 credit; no product execution.'})
out={'schema':'726-prospective-place-client-support-v1','author':'/root/rig_identity','at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows};(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
