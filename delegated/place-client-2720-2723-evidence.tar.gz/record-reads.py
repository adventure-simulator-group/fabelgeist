from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda x:hashlib.sha256(x).hexdigest();groups=['registration.json','support-registration.json','support2-registration.json','feature-registration.json'];chunks=lambda a,z,n=60:[[i,min(i+n-1,z)] for i in range(a,z+1,n)];actual={}
for suffix in ['historical','current']:
 actual['2720-'+suffix]=chunks(1,720);actual['2721-'+suffix]=[[1,55],[56,114]];actual['2722-'+suffix]=[[1,29]]
actual['2723-historical']=[[11,11]];actual['2723-current']=[[1,14]]
actual.update({'tactical-source':[[250,300],[301,350],[351,400],[401,450],[451,500]],'spawn-admission':[[1,55],[56,108]],'player-projection':[[510,560],[561,610],[611,650],[800,860]],'equipment-projection':[[1,50],[51,100],[101,139]],'world-event':[[280,330],[331,380]],'food-consumption':[[70,100]],'foraging-place':[[400,425]],'cargo-workspace':[[165,185]],'cargo-lock':[[9970,10000]],'world-event-prefix':[[1,35]],'event-store':[[290,340],[941,990],[991,1015]],'core-features':[[1,45]],'module-features':[[1,30]]})
def complement(eof,ranges):
 s={i for a,z in ranges for i in range(a,z+1)};out=[];start=None
 for i in range(1,eof+2):
  if i<=eof and i not in s and start is None:start=i
  if (i>eof or i in s) and start is not None:out.append([start,i-1]);start=None
 return out
rows=[]
for name in groups:
 r=json.loads((b/name).read_bytes())
 for e in r['entries']:
  ranges=actual[e['id']];rows.append({'id':e['id'],'registration':name,'registration_sha256':sha((b/name).read_bytes()),'archive':e['archive'],'revision':e['revision'],'sha256':e['sha256'],'actual_personal_display_chunks':ranges,'unread_complement':complement(e['eof'],ranges),'qualification':'Historic material and current support separate even when bytes equal. Existing tests/fixtures shown as text only; none were run.'})
out={'schema':'726-personal-read-receipt-v1','author':'/root/rig_identity','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'entries':rows,'navigation':'Earlier Git grep matches and unavailable plural world_events.rs were navigation only; correct singular event-store path separately registered; no unrelated path absence proof.','previous_review':'Independent 2718–2719 reviewer scopes remain theirs; our event-store/core-world-event windows are support only, no ordered credit.'};(b/'personal-read-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('read scopes',len(rows))
