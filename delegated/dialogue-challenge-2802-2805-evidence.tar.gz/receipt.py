from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent
h=lambda x:hashlib.sha256(x).hexdigest()
load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json')
nav={};navigation=[]
for name in ['navigation-challenge.txt','navigation-dialogue.txt','navigation-personality.txt']:
 lines=(b/name).read_text().splitlines()
 for line in lines:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line)
  assert m
  nav.setdefault(m.group(1),set()).add(int(m.group(2)))
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,len(lines)]] if lines else [],'unread_saved_output_lines':[],'ordered_role_credit':0})
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
def comp(n,used):
 out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
chunks={2802:[[54,69]],2803:[[181,263],[265,290]],2804:[[1,80]],2805:[[1,80]]}
assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  d=chunks[row['original_index']];shown=nums(d);navonly=sorted(nav.get(row['path'],set())-shown) if j else []
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned 95e'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':d,'original_material_ranges':row['original_material_ranges'] if j==0 else [],'navigation_only_lines_at_assigned_scope':navonly,'unread_after_assigned_and_navigation':comp(v['eof'],shown|set(navonly)),'qualification':'Current support body displays recorded separately below. Historical exclusion 2803:264 has no old-role credit. Distinct challenge role displays kept distinct even with identical bytes.'})
body={'personality':[[97,174]],'challenges':[[395,446],[842,869],[1420,1448],[1730,1755],[2285,2305]],'dialogue-bindings':[[940,1002],[1003,1065]],'dialogue-schema':[[516,538]],'core-social':[[162,205]],'starting-character':[[684,735],[736,787]],'challenges-retry':[[1280,1325],[1385,1425]]}
support=[]
for x in load('support-registration.json')['entries']+load('support-registration-extra.json')['entries']:
 d=body[x['name']];shown=nums(d);prior=[]
 for row in reg['rows']:
  if row['path']==x['path']:prior=chunks[row['original_index']]
 prior_set=nums(prior);navonly=sorted(nav.get(x['path'],set())-shown-prior_set)
 support.append({'path':x['path'],'revision':x['revision'],'local':x['local'],'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':d,'prior_assigned_displays_of_same_pinned_path':prior,'navigation_only_lines':navonly,'unread_complement_after_this_support_and_assigned':comp(x['eof'],shown|prior_set|set(navonly)),'qualification':'Other support entry for same path is separately displayed; this complement does not union other support entries.','ordered_role_credit':0})
names=['registration.json','navigation-registration.json','support-registration.json','support-registration-extra.json']
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Newly reconstructed exact personal source displays and navigation after prospective registrations. Navigation is match lines only; incidental fixture/test source was not executed.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in names],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'limits':'No product, generated code, macro, test, fixture, build, runtime probe, repair or publication edit.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n')
print('sha256',h((b/'read-receipt.json').read_bytes()))
