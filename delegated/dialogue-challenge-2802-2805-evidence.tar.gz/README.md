# Bounded source evidence: original roles 2802–2805

`REPORT.json` contains thirteen partial lens perspectives, actual source
references, historical relationships, conditional findings and open questions.
`registration.json`, support registrations and `read-receipt.json` distinguish
original material, current displays, support, navigation and unread complements.
Each historical challenge snapshot was displayed separately even though its
source bytes match; archived bytes or someone else's read do not grant credit.

The original physical-p16 snapshot was dirty and based at a120. A later
independently reproduced tracked patch matches the recorded digest; seven
untracked objects are separately qualified. The original generation command
and uninterrupted custody are unestablished. Pr-working is 6533-based with
unrelated modifications. Per-file equality does not make either snapshot
clean. The f82 revision transports original evidence and 039 is a recorded
per-file origin, neither is the dirty P16 head.

`historical/` preserves exact 059 receipts and 774 supplier records.
`recovered/` contains the original registry archive and 059 queue/ledger,
plus an explicitly reconstructed 774 catalog and later P16 recovery evidence.
`historical-selections-reconstructed.json` is newly reconstructed from exact
records. `prior/` retains bounded current and earlier delegate reports without
transferring their reviewer attribution. No checkpoint 3821 or whole-lens
completion is asserted. The top-level manifest includes nested manifests.

Run `python3 verify-evidence.py` for offline evidence integrity only; it does
not execute product, generated code, macro, fixture, builds, or tests.
