from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[
('personality','crates/adventuresim-stdb-module/src/personality.rs',[[97,174]]),
('challenges','crates/adventuresim-stdb-module/src/strategic/challenges.rs',[[395,446],[842,869],[1420,1448],[1730,1755],[2285,2305]]),
('dialogue-bindings','crates/adventuresim-stdb-module/src/strategic/dialogue_bindings.rs',[[940,1065]]),
('dialogue-schema','crates/adventuresim-stdb-module/src/strategic/dialogue_schema.rs',[[516,538]]),
('core-social','crates/adventuresim-core/src/social.rs',[[162,205]]),
]
entries=[]; pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path])
 blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':'support/'+name+'.rs'})
 pending.append((name,raw))
out={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Current bounded support only, exact ranges below; no original-role or prior-author attribution transfer. Archived full file bytes do not mean all lines were read.','entries':entries}
(b/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n')
for name,raw in pending:
 p=b/('support/'+name+'.rs');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(out,indent=2))
