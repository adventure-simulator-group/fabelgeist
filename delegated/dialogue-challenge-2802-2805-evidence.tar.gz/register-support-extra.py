from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009'
items=[('starting-character','crates/adventuresim-core/src/starting_character.rs',[[684,787]]),('challenges-retry','crates/adventuresim-stdb-module/src/strategic/challenges.rs',[[1280,1325],[1385,1425]])]
entries=[]; pending=[]
for name,path,ranges in items:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path])
 blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'ranges':ranges,'local':'support/'+name+'.rs'})
 pending.append((name,raw))
out={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Additional current support for existing historical generation-owner and challenge revision questions; not original-role coverage.','entries':entries}
(b/'support-registration-extra.json').write_text(json.dumps(out,indent=2)+'\n')
for name,raw in pending:
 p=b/('support/'+name+'.rs');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(out,indent=2))
