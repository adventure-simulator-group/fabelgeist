from pathlib import Path
import gzip,hashlib,json,tarfile
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
m=json.loads((r/'recovered/MANIFEST.json').read_bytes());registry_raw=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());registry=json.loads(registry_raw);assert h(registry_raw)==m['registry_sha256'];assert h((r/'recovered/registry.json.gz').read_bytes())==m['registry_gzip_sha256'];assert h((r/'recovered/objects.tar.gz').read_bytes())==m['objects_archive_sha256']
reg=json.loads((r/'registration.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());assert rec['registration_sha256']==h((r/'registration.json').read_bytes())
with tarfile.open(r/'recovered/objects.tar.gz') as tar:
 for x in reg['entries']:
  assert x['historical_registry_row']==registry['files'][x['original_index']];b=tar.extractfile(x['original_object_sha256']).read();assert h(b)==x['original_object_sha256']
  for v in x['versions']:
   data=(r/v['local']).read_bytes();assert data==b and h(data)==v['sha256'];assert len(data.splitlines())==v['eof'];q=next(e for e in rec['reads'] if e['original_index']==x['original_index'] and e['revision']==v['revision']);assert q['display_windows']==v['registered_display_ranges']
   expected=set();displayed=set()
   for a,z in v['registered_display_ranges']:expected.update(range(a,z+1))
   for a,z in q['display_windows']:displayed.update(range(a,z+1))
   rest=set()
   for a,z in q['unread_complement']:rest.update(range(a,z+1))
   assert displayed==expected and not displayed.intersection(rest) and displayed.union(rest)==set(range(1,v['eof']+1))
proof=json.loads((r/'git-proofs.json').read_bytes());objs={}
for k,v in proof['objects'].items():
 b=gzip.decompress((r/v['local']).read_bytes());assert len(b)==v['size'] and h(b)==v['sha256'] and oid(v['type'],b)==k;objs[k]=b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),k
 raise AssertionError(n)
for p in proof['proofs']:
 root=objs[p['revision']].splitlines()[0].split()[1].decode();assert root==p['root_tree'];tree=root
 for c in p['chain']:
  assert tree==c['tree'];mode,k=lookup(objs[tree],c['name']);assert mode==c['mode'] and k==c['object'];tree=k
 assert p['path'].split('/')==[c['name'] for c in p['chain']];b=(r/p['local']).read_bytes();b=gzip.decompress(b) if p.get('encoding')=='gzip' else b;assert h(b)==p['sha256'] and oid('blob',b)==tree==p['blob']
queue=json.loads(gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes()));ledger=json.loads(gzip.decompress((r/'recovered/original-059-ledger.json.gz').read_bytes()));sel=json.loads((r/'historical/selections-reconstructed.json').read_bytes());idx=json.loads((r/'historical/evidence-index.json').read_bytes())
for i in (404,406,408):
 row=queue['entries'][i];assert sel['queue_rows'][str(i)]==row;assert sel['ledger_findings'][row['contract_id']]==ledger['discovery_findings_and_dependencies'][row['contract_id']]
for name,digest in idx['historical_059_source_files'].items():assert h((r/'historical'/name).read_bytes())==digest
base=r/'prior/model';prior=json.loads((base/'packet-manifest.json').read_bytes());assert h((base/'packet-manifest.json').read_bytes())==idx['old_packet_manifest_sha256'];known={e['path']:e['sha256'] for e in prior['files']}
for p in idx['prior_model_members']:
 if p!='packet-manifest.json':assert h((base/p).read_bytes())==known[p]
for name,digest in idx['current_references'].items():assert h((r/'prior/current'/name).read_bytes())==digest
report=json.loads((r/'REPORT.json').read_bytes());assert [x['queue_index'] for x in report['contracts']]==[404,406,408];assert len(report['lens_perspectives'])==13
manifest=r/'MANIFEST.json'
if manifest.exists():
 entries=json.loads(manifest.read_bytes())['files'];records={e['path']:e for e in entries};actual={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p!=manifest};assert set(records)==actual
 for n,e in records.items():b=(r/n).read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256'],n
print('PASS: exact registry objects, 059 queue/ledger, 774 transport and 6533/95e Git proofs, 12 personal window partitions, exact historical PL13 hashes, previous manifest members, current assessment references and 13 bounded perspectives'+('; full top-level manifest' if manifest.exists() else '; before top-level manifest'))
print('Evidence integrity only; source behavior, repairs, builds, tests, probes and product validation were not run.')
