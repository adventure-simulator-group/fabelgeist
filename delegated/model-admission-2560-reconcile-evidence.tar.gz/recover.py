from pathlib import Path
import gzip,json,hashlib,shutil
r=Path(__file__).resolve().parent;origin=Path('<LOCAL_PATH_0>'); old=Path('<LOCAL_PATH_1>'); src=Path('<LOCAL_PATH_2>');pub=Path('<LOCAL_PATH_3>');h=lambda b:hashlib.sha256(b).hexdigest()
for d in ['recovered','historical','prior','prior/model','prior/current']:(r/d).mkdir()
for n in ['MANIFEST.json','registry.json.gz','objects.tar.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:
 shutil.copyfile(origin/n,r/'recovered'/n)
queue=json.load(gzip.open(r/'recovered/original-059-queue.json.gz','rt'));ledger=json.load(gzip.open(r/'recovered/original-059-ledger.json.gz','rt'));idx=[404,406,408];rows={str(i):queue['entries'][i] for i in idx};ids=[x['contract_id'] for x in rows.values()]
(r/'historical/selections-reconstructed.json').write_text(json.dumps({'kind':'Reconstructed indexed selection copied from the exact historical 059 queue and ledger; not original independent record or checkpoint3821.','queue_rows':rows,'ledger_findings':{i:ledger['discovery_findings_and_dependencies'][i] for i in ids}},indent=2,ensure_ascii=False)+'\n')
expected={}
for e in rows.values():
 for v in e['granular_contract_views']:
  proposal=v.get('proposal',{});name=Path(proposal['path']).name;expected[name]=proposal['sha256']
  for s in v.get('exact_source_identities_and_assessed_ranges',[]):
   for k in ['read','registration']:
    o=s.get(k)
    if o:expected[Path(o['path']).name]=o['sha256']
for name,digest in expected.items():
 data=(src/name).read_bytes();assert h(data)==digest,(name,h(data),digest);(r/'historical'/name).write_bytes(data)
prior=['packet-manifest.json','report.json','read-receipt.json','support-read-receipt.json','registration.json','historical/774/audit/continuation/native/initial05-aggregate-states/contract-groups-005.json','historical/774/audit-continuation/operations/contract-groups-614.json','historical/059/segovb/READ-L12-868.json']
man=json.loads((old/'packet-manifest.json').read_bytes()); known={e['path']:e['sha256'] for e in man['files']}
for name in prior:
 b=(old/name).read_bytes()
 if name!='packet-manifest.json':assert known[name]==h(b),name
 out=r/'prior/model'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
for name in ['ASSESSMENT-DELEGATED-RECONCILIATION-12D-95E.json','ASSESSMENT-DELEGATED-RECONCILIATION-12E-95E.json','delegated/p16-furniture-room-index-report.json','delegated/programme-church-partitions-2846-2848-report.json']:
 b=(pub/name).read_bytes();out=r/'prior/current'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
recs={'qualification':'Exact 059 PL13 receipts copied read-only from user-provided extracted collection, hashes match original queue proof pointers; identities remain at historical source revisions. No named human or agent inferred when the receipt only names a PL13 namespace. Reconstructed selection is explicitly distinct. Prior own packet members match frozen packet-manifest; current copied assessments preserve their own attribution.','historical_059_source_files':expected,'old_packet_manifest_sha256':h((old/'packet-manifest.json').read_bytes()),'prior_model_members':prior,'current_references':{n:h((pub/n).read_bytes()) for n in ['ASSESSMENT-DELEGATED-RECONCILIATION-12D-95E.json','ASSESSMENT-DELEGATED-RECONCILIATION-12E-95E.json','delegated/p16-furniture-room-index-report.json','delegated/programme-church-partitions-2846-2848-report.json']}}
(r/'historical/evidence-index.json').write_text(json.dumps(recs,indent=2,ensure_ascii=False)+'\n');print('Preserved',len(expected),'exact 059 receipts/proposals and prior bounded assessments')
