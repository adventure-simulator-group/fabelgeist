from pathlib import Path
import gzip,hashlib,json,tarfile,subprocess,datetime
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';e=Path('<LOCAL_PATH_1>'); f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';revs=['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009'];h=lambda b:hashlib.sha256(b).hexdigest(); old=json.load(gzip.open(e/'registry.json.gz','rt')); (r/'source').mkdir();entries=[]
windows={2560:[[12,168]],646:[[1,65],[293,402]],608:[[140,180]],619:[[1,45]],649:[[1,45]],610:[[1,98]]}
with tarfile.open(e/'objects.tar.gz') as t:
 for index,scope in windows.items():
  row=old['files'][index]; path=row['source_id'].split(':',1)[1]; frozen=t.extractfile(row['sha256']).read();assert h(frozen)==row['sha256'];assert frozen==subprocess.check_output(['git','-C',repo,'show',f82+':handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+row['sha256']])
  versions=[]
  for rev in revs:
   b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]); local=f'source/{index}-{rev[:4]}.rs';(r/local).write_bytes(b);assert b==frozen;versions.append({'revision':rev,'local':local,'sha256':h(b),'eof':len(b.splitlines()),'registered_display_ranges':scope})
  entries.append({'original_index':index,'role':'assigned original role only' if index==2560 else 'separately registered support only; no ordered-role credit','historical_registry_row':row,'path':path,'historical_f82_object':f'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/{row["sha256"]}','f82_transport':f82,'original_object_sha256':row['sha256'],'versions':versions})
reg={'schema':'726-prospective-model-admission-reconciliation-v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','entries':entries,'historic_source':'pr-working object at 6533-based snapshot with unrelated dirty files. Exact per-file matches do not establish snapshot cleanliness; f82 transports original object.','purpose':'Fresh bounded displays only, for relations to exact 059 q404, q406 and q408; prior independent role2560 full reads and historical authors remain separate.','exclusions':'Other lines and other source bodies unread in this packet; no lens completion or promoted checkpoint.'}
(r/'registration.json').write_text(json.dumps(reg,indent=2,ensure_ascii=False)+'\n');print('registration',h((r/'registration.json').read_bytes()),'files',len(entries),'registered per revision',sum(sum(b-a+1 for a,b in e['versions'][0]['registered_display_ranges']) for e in entries))
