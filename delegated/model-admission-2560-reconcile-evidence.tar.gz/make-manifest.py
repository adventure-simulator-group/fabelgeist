from pathlib import Path
import datetime,hashlib,json
r=Path(__file__).resolve().parent;out=r/'MANIFEST.json';files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p!=out:
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
out.write_text(json.dumps({'schema':'726-model-admission-reconciliation-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'qualification':'Includes every nested manifest; excludes only this top-level manifest. Presence is not personal read credit.'},indent=2)+'\n');print('manifest',hashlib.sha256(out.read_bytes()).hexdigest(),'files',len(files),'bytes',sum(x['bytes'] for x in files))
