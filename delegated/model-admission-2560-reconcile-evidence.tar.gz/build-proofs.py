from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();objects={};proofs=[]
def save(t,k):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,b)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(b,mtime=0));objects[k]={'type':t,'size':len(b),'sha256':h(b),'local':p}
 return b
def lookup(b,n):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);m,name=b[i:z].split(b' ',1);k=b[z+1:z+21].hex();i=z+21
  if name.decode()==n:return m.decode(),k
 raise KeyError(n)
def proof(rev,path,local,kind,encoding=None):
 b=(r/local).read_bytes();b=gzip.decompress(b) if encoding=='gzip' else b;root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for part in path.split('/'):
  mode,k=lookup(save('tree',tree),part);chain.append({'tree':tree,'name':part,'mode':mode,'object':k});tree=k
 assert tree==oid('blob',b),(rev,path,local);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'encoding':encoding,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(b)})
reg=json.loads((r/'registration.json').read_bytes())
for e in reg['entries']:
 proof(e['f82_transport'],e['historical_f82_object'],e['versions'][0]['local'],'f82 recovered old object; transport not historical source revision')
 for v in e['versions']:proof(v['revision'],e['path'],v['local'],'individual source file membership; no whole-tree clean implication')
rev='eb407672813424d64ec31f208193969f5a62620c'
for path,local in [('handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json','recovered/original-059-queue.json.gz'),('handoff/726-audit-20261030-adler/evidence/continuation-segovb/ledger.json','recovered/original-059-ledger.json.gz')]:proof(rev,path,local,'exact recovered checkpoint 059 bytes, not checkpoint3821','gzip')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-role2560-admission-git-proofs-v1','objects':objects,'proofs':proofs,'qualification':'Evidence-only Git object membership; equality does not transfer personal read, semantic coverage, source-snapshot cleanliness or checkpoint3821 adoption.'},indent=2)+'\n');print('proofs',len(proofs),'objects',len(objects),'sha',h((r/'git-proofs.json').read_bytes()))
