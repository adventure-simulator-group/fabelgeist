from pathlib import Path
import json,re
b=Path('<LOCAL_PATH_0>');r=json.loads((b/'REPORT.json').read_bytes());scopes={x['path']:x['actual_personally_displayed_current_ranges'] for x in r['original_roles']};scopes.update({x['path']:x['actual_current_personal_body_ranges'] for x in r['support_source_reads']});count=0
for item in r['findings_and_connected_questions']+r['nonfindings']:
 for ref in item.get('source',[]):
  p,spans=ref.rsplit(':',1);assert p in scopes,(item.get('id'),ref,'unregistered');ranges=scopes[p]
  for span in spans.split(','):
   m=re.fullmatch(r'(\d+)(?:-(\d+))?',span);assert m,ref;lo=int(m.group(1));hi=int(m.group(2) or lo)
   assert any(a<=lo<=hi<=z for a,z in ranges),(item.get('id'),ref,ranges);count+=1
print('Evidence-only source-reference scope check passed:',count,'cited line spans inside actual personal read unions. No product execution.')
