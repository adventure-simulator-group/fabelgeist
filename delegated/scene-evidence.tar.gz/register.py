from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');revs=['95e63628f9d70b8dd6e6fede64334696c6995009','6533e444fa37552927070cc8d8190907fd3b413e'];roles={2428:'crates/strategic-web/static/strategic-renderer.js',2429:'crates/strategic-web/static/strategic-scene-request.js',2430:'crates/strategic-web/static/strategic-scene.js'};entries=[];pending=[]
for i,p in roles.items():
 for rev in revs:
  raw=subprocess.check_output(['git','show',rev+':'+p]);entries.append({'original_role':i,'revision':rev,'path':p,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'planned_full_read':[1,len(raw.splitlines())]});pending.append((rev,p,raw))
r={'schema':'726-delegated-prospective-source-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity, scene source family','registration':'Prospective before assigned source body display. Independently display both pinned revision bodies in bounded chunks; earlier agent and prior support scopes remain distinct.','entries':entries};(b/'registration.json').write_text(json.dumps(r,indent=2)+'\n')
for rev,p,raw in pending:
 d=b/'sources'/rev[:4]/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('registration sha256',hashlib.sha256((b/'registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
