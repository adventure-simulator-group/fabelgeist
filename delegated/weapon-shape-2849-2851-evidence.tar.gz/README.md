# Weapon shape and attachment source evidence

This packet records an independent source-only review of original pr-working
roles 2849–2851 at pinned current project revision
95e63628f9d70b8dd6e6fede64334696c6995009. Their exact archived objects each
match same-path Git objects at the recorded 6533 head and current 95e. The
pr-working snapshot had unrelated dirty changes; f82 transports evidence and is
not the source revision.

`report.json` contains the bounded findings, nonfindings, historical relations,
open questions and thirteen perspectives. `read-scope-summary.json` is
reconstructed from prospective registrations and actual personal displays;
all assigned and support unread complements remain explicit. `history-059/`
preserves that Segovb's later Lens 11 batch adopted Adler's earlier scoped
reads of roles 2849 and 2851 and made no fresh personal body reads for them.
Context-only lines and inherited premature-read exclusions are also retained.

The earlier recorded whole-registration-file hashes differ from later f82
transported JSONL bytes; exact source rows match and the bounded prefix check
is documented in `registration-version-qualification.json`. The included
registry and queue selections are reconstructions. Earlier current assessments
retain their authors and do not transfer coverage. No checkpoint 3821 or lens
completion is claimed.

`git-proofs.json` and `git-objects/` contain raw commit and tree membership
proofs. Run `python3 verify-evidence.py` and `python3 verify-manifest.py` only
for offline evidence integrity. The audit did not run models, geometry, builds,
tests, fixtures or product validation. The central coordinator owns ledger,
publication and finding counts.
