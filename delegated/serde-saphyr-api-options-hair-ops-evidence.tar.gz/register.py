import datetime,gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('<LOCAL_PATH_0>'); pub=Path('<LOCAL_PATH_1>'); native=pub/'native-evidence/serde-saphyr-1.2.0'; ar=pub/'recovered/original-registry-source-archive'; repo=str(pub)
h=lambda b:hashlib.sha256(b).hexdigest()
raw=gzip.decompress((ar/'registry.json.gz').read_bytes()); assert h(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f'; reg=json.loads(raw)['files']; man=json.loads((ar/'MANIFEST.json').read_text()); assert h((ar/'objects.tar.gz').read_bytes())==man['objects_archive_sha256']
archive=native/'serde-saphyr-1.2.0.crate'; archash=h(archive.read_bytes()); assert archash=='3afb591f9cdb6223c88ba39269aff895620c7f0716dc42b705b5733d5c7c0823'
old='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'; cur='95e63628f9d70b8dd6e6fede64334696c6995009'
scopes={2573:[[1,180]],2574:[[1,180],[200,320],[450,560]]}; native_objs=[]
with tarfile.open(ar/'objects.tar.gz','r:gz') as tar,tarfile.open(archive,'r:gz') as pkg:
 for i in scopes:
  row=reg[i]; sha=row['sha256']; name=row['source_id'].split(':',1)[1]; b=tar.extractfile(sha).read(); assert h(b)==sha
  member=pkg.extractfile(name).read(); assert member==b
  objpath='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+sha
  recovered=subprocess.check_output(['git','-C',repo,'show',old+':'+objpath]); assert recovered==b
  cache=Path('<LOCAL_PATH_2>')/name; assert cache.read_bytes()==b
  native_objs.append({'role':i,'source_id':row['source_id'],'sha256':sha,'bytes':len(b),'lines':len(b.splitlines()),'original_registry':row,'prospective_personal_ranges':scopes[i],'recovered_archive_member':sha,'f82_transport_object':objpath,'package_member':name,'archive_sha256':archash,'native_registry_copy':str(cache),'qualification':'Identical package bytes across recovered 059 original role, f82 recovered object, local package archive and source cache; package is external native dependency, not project Git content. Archives and equality do not establish personal read.'})
proj=[]
for path,ranges in [('Cargo.lock',[[9370,9408]]),('crates/adventuresim-tactical-client/src/presentation/config.rs',[[1,150],[200,360]])]:
 b=subprocess.check_output(['git','-C',repo,'show',cur+':'+path]); blob=subprocess.check_output(['git','-C',repo,'rev-parse',cur+':'+path],text=True).strip(); proj.append({'path':path,'revision':cur,'git_blob':blob,'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'prospective_personal_ranges':ranges,'role':'bounded current project support; no ordered-role credit'})
doc={'schema':'726-prospective-native-audit-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','project_baseline':cur,'original_registry_sha256':h(raw),'original_source_archive_sha256':man['objects_archive_sha256'],'original_archive_manifest_sha256':h((ar/'MANIFEST.json').read_bytes()),'f82_transport_revision':old,'native_package':'serde-saphyr 1.2.0','native_archive_path':str(archive),'native_archive_sha256':archash,'native_roles':native_objs,'project_support':proj,'rule':'This registration precedes personal source displays; exact eventual read receipts distinguish ordered role material and support, unread complements, historical prior readers and tests-as-text.'}
with (root/'registration.json').open('x') as f: json.dump(doc,f,indent=2);f.write('\n')
(root/'source').mkdir();(root/'support').mkdir(); (root/'historical').mkdir()
with tarfile.open(ar/'objects.tar.gz','r:gz') as tar:
 for x in native_objs:
  b=tar.extractfile(x['sha256']).read();(root/'source'/('role-'+str(x['role'])+'.rs')).write_bytes(b)
for x in proj:
 b=subprocess.check_output(['git','-C',repo,'show',cur+':'+x['path']]); assert h(b)==x['sha256']; (root/'support'/('lock.source' if x['path']=='Cargo.lock' else 'config.source')).write_bytes(b)
(root/'historical/roles.json').write_text(json.dumps({'registry_sha256':h(raw),'roles':[{ 'index':i,'entry':reg[i]} for i in scopes]},indent=2)+'\n')
print('registered',doc['registered_utc'],'roles',[(x['role'],x['sha256'],x['lines']) for x in native_objs]);print('support',[(x['path'],x['sha256'],x['lines']) for x in proj])
