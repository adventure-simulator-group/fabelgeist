'''Integrity verification only. No package, product, build, test, macro or runtime execution.'''
import gzip,hashlib,json,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent; sha=lambda b:hashlib.sha256(b).hexdigest(); blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(); reg=json.loads((p/'registration.json').read_bytes());sp=json.loads((p/'support-registration.json').read_bytes());ft=json.loads((p/'feature-registration.json').read_bytes()); rec=json.loads((p/'read-receipt.json').read_bytes()); hist=json.loads((p/'historical-manifest.json').read_bytes());proof=json.loads((p/'git-proofs.json').read_bytes());
for link in hist['hash_links']:
 b=Path(link['path']).read_bytes(); assert len(b)==link['bytes'] and sha(b)==link['sha256']
archive=Path(reg['native_archive_path']); assert sha(archive.read_bytes())==reg['native_archive_sha256']
with tarfile.open(archive,'r:gz') as t:
 for x in reg['native_roles']:
  b=(p/'source'/('role-'+str(x['role'])+'.rs')).read_bytes(); assert sha(b)==x['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['lines'] and t.extractfile(x['package_member']).read()==b
for x in sp['native_support']:
 if x['name'].startswith('serde-saphyr'): a=archive
 else: a=Path(next(q['path'] for q in hist['hash_links'] if q['path'].endswith('/serde_core-1.0.229.crate')))
 assert sha(a.read_bytes())==x['package_archive_sha256']; b=(p/x['bytes_path']).read_bytes();assert sha(b)==x['sha256']
 with tarfile.open(a,'r:gz') as t:assert t.extractfile(x['name']).read()==b
for x in ft['native_support']:
 a=Path(x['archive']);assert sha(a.read_bytes())==x['archive_sha256'];b=(p/x['saved']).read_bytes();assert sha(b)==x['sha256']
 with tarfile.open(a,'r:gz') as t:assert t.extractfile(x['name']).read()==b
for x in hist['original_files']:
 b=(p/x['local']).read_bytes();assert sha(b)==x['sha256'] and len(b)==x['bytes']
for x in rec['prospective_registrations']:assert sha((p/x['path']).read_bytes())==x['sha256']
for x in rec['assigned_roles']:
 b=(p/x['source']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof']; ran=x.get('display_union',x.get('display_windows'));occ=[]
 for lo,hi in ran+x['unread_complement']:assert 1<=lo<=hi<=x['eof'];occ.extend(range(lo,hi+1))
 assert len(occ)==x['eof'] and set(occ)==set(range(1,x['eof']+1))
for x in rec['support_reads']:
 if 'unread_complement' not in x:continue
 b=(p/x['saved']).read_bytes();eof=len(b.splitlines());assert eof==x.get('eof',eof);ranges=x.get('display_union',x.get('display_windows'));occ=[]
 for lo,hi in ranges+x['unread_complement']:assert 1<=lo<=hi<=eof;occ.extend(range(lo,hi+1))
 assert len(occ)==eof and set(occ)==set(range(1,eof+1))
objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes()); assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 raise ValueError(name)
for x in proof['proofs']:
 commit=objects[x['revision']];current=commit.splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for st in x['chain']:
  assert current==st['tree'];mode,child=lookup(objects[current],st['name']);assert mode==st['mode'] and child==st['object'];current=child
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and sha(b)==x['sha256']
registrations=[json.loads(l) for l in (p/'historical/774-source-range-registration.jsonl').read_text().splitlines()];quals=[json.loads(l) for l in (p/'historical/774-source-qualifications.jsonl').read_text().splitlines()];rows=json.loads((p/'historical/roles.json').read_text())['roles']
for row in rows:
 for ob in row['entry']['admission03_scope_observations']:
  assert registrations[ob['row_1based']-1]==ob['original_record'] and all(q in quals for q in ob['local_qualifications'])
if (p/'MANIFEST.json').exists():
 manifest=json.loads((p/'MANIFEST.json').read_bytes())
 for f in manifest['files']:
  b=(p/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
print('Evidence checks passed:',len(reg['native_roles']),'native roles,',len(sp['native_support'])+len(ft['native_support']),'native support members,',len(proof['proofs']),'Git membership chains; read partitions and historical attributions preserved. No product/package/macro/test execution.')
