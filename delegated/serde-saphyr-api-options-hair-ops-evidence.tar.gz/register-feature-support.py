import datetime,hashlib,json,subprocess,tarfile
from pathlib import Path
r=Path('<LOCAL_PATH_0>'); pub=Path('<LOCAL_PATH_1>'); rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda b:hashlib.sha256(b).hexdigest()
req=[(pub/'native-evidence/serde-saphyr-1.2.0/serde-saphyr-1.2.0.crate','serde-saphyr-1.2.0/Cargo.toml','support/serde-saphyr-Cargo.toml'),(pub/'native-evidence/serde-derive-1.0.229/serde_derive-1.0.229.crate','serde_derive-1.0.229/src/de/struct_.rs','support/serde-derive-struct.rs'),(pub/'native-evidence/serde-derive-1.0.229/serde_derive-1.0.229.crate','serde_derive-1.0.229/src/internals/attr.rs','support/serde-derive-attr.rs'),(pub/'native-evidence/serde-derive-1.0.229/serde_derive-1.0.229.crate','serde_derive-1.0.229/src/de.rs','support/serde-derive-de.rs')];rows=[]
for archive,name,loc in req:
 with tarfile.open(archive,'r:gz') as t:b=t.extractfile(name).read()
 rows.append({'name':name,'archive':str(archive),'archive_sha256':h(archive.read_bytes()),'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'prospective_ranges':[[1,len(b.splitlines())]],'saved':loc})
project=[]
for path in ['Cargo.toml','crates/adventuresim-tactical-client/Cargo.toml']:
 b=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path]);project.append({'path':path,'revision':rev,'git_blob':subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+path],text=True).strip(),'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'prospective_ranges':[[1,len(b.splitlines())]],'saved':'support/project-'+('root' if path=='Cargo.toml' else 'client')+'-Cargo.toml'})
d={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','native_support':rows,'project_support':project,'additional_role_2574':{'sha256':'d38d24ae1ae19df025ec4073c774a3eea48fcb85a0dad024b392e8c6899c40a8','prospective_ranges':[[181,199],[321,449]]},'note':'Full windows registered for navigation and selective displays; final receipt records only actual displayed ranges, not all archived bytes. No ordered-role credit for support.'}
with (r/'feature-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for row in rows:
 with tarfile.open(row['archive'],'r:gz') as t:(r/row['saved']).write_bytes(t.extractfile(row['name']).read())
for row in project:(r/row['saved']).write_bytes(subprocess.check_output(['git','-C',str(pub),'show',rev+':'+row['path']]))
print(d['registered_utc']);print([(x['name'],x['sha256'],x['lines']) for x in rows]);print([(x['path'],x['sha256'],x['lines']) for x in project])
