import datetime,hashlib,json,tarfile
from pathlib import Path
r=Path('<LOCAL_PATH_0>'); pub=Path('<LOCAL_PATH_1>'); package=pub/'native-evidence/serde-saphyr-1.2.0/serde-saphyr-1.2.0.crate'; core=pub/'native-evidence/serde_core-1.0.229/serde_core-1.0.229.crate';h=lambda x:hashlib.sha256(x).hexdigest(); req=[('serde-saphyr-1.2.0/src/de/deserializer.rs','72b755ac168c5dd782c5b1bea90fce7488a9d4b9ba713fe26be33b553973362a',[[484,525],[577,675],[970,1000]]),('serde-saphyr-1.2.0/src/parse_scalars.rs','cf724ec89b4f506fa46193c9b2c1917b43356e02a342f11c9ccf45483dc3bebb',[[270,351]]),('serde-saphyr-1.2.0/src/de/with_deserializer.rs','c6304415acbe2cb08fe5a730da8625f2c4631d111b7dccde6dad44c2d5e34c95',[[120,160]])]; rows=[]
with tarfile.open(package,'r:gz') as t:
 for name,sha,ranges in req:
  b=t.extractfile(name).read();assert h(b)==sha;rows.append({'name':name,'sha256':sha,'bytes':len(b),'lines':len(b.splitlines()),'prospective_ranges':ranges,'package_archive_sha256':h(package.read_bytes()),'bytes_path':'support/'+name.split('/')[-1]+'.source'})
with tarfile.open(core,'r:gz') as t:
 name='serde_core-1.0.229/src/de/impls.rs';b=t.extractfile(name).read();rows.append({'name':name,'sha256':h(b),'bytes':len(b),'lines':len(b.splitlines()),'prospective_ranges':[[154,163],[450,456]],'package_archive_sha256':h(core.read_bytes()),'bytes_path':'support/serde-core-impls.source'})
doc={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'native support only; no ordered role credit','native_support':rows,'additional_current_project_support':[{'path':'crates/adventuresim-tactical-client/src/presentation/config.rs','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','sha256':'4b39a948e24517a32a421b021307c7d1d7dad7a152be348ac952a3c88384f961','ranges':[[151,199],[361,404]]}],'note':'The support registration precedes source displays; no feature resolution, parser operation, product test or runtime.'}
with (r/'support-registration.json').open('x') as f:json.dump(doc,f,indent=2);f.write('\n')
with tarfile.open(package,'r:gz') as t:
 for row in rows[:3]:(r/row['bytes_path']).write_bytes(t.extractfile(row['name']).read())
with tarfile.open(core,'r:gz') as t:(r/rows[3]['bytes_path']).write_bytes(t.extractfile(rows[3]['name']).read())
print(doc['registered_utc']);print([(x['name'],x['sha256'],x['prospective_ranges']) for x in rows])
