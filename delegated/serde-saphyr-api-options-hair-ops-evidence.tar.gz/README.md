# Bounded serde-saphyr source audit

`REPORT.json` covers original roles 2573–2574 as external serde-saphyr 1.2.0
native package sources and bounded 95e project support. Exact personal display
windows and unread complements appear in `read-receipt.json`; old root/Adler
attributions and historical records remain separate. Two documented findings
are existing-family support and a conditional upstream policy question, with
no new demonstrated product defect or feature-resolution claim.

The prospective registrations precede displayed source reads. `git-proofs.json`
and compressed Git objects prove the pinned project and f82 evidence-transport
memberships. Package archives and prior assessments are hash-linked rather than
duplicated; central publication must preserve those linked bytes or relink them
to verified identical evidence. `python3 verify-evidence.py` checks only
source/evidence identities and read partitions. No implementation, build, test,
parser, macro, product, viewer, renderer, fixture or runtime probe ran.
