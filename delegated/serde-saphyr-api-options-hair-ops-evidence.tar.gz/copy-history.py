import hashlib,json,subprocess
from pathlib import Path
r=Path('<LOCAL_PATH_0>');pub=Path('<LOCAL_PATH_1>');old=Path('<LOCAL_PATH_2>'); h=lambda b:hashlib.sha256(b).hexdigest(); f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'; items=[]
for n in ['source-range-registration.jsonl','source-qualifications.jsonl','source-qualifications-final-current.jsonl','findings.jsonl','qualifications.jsonl']:
 b=(old/n).read_bytes();gp='handoff/774/adler-original/audit/continuation/root/admission03/'+n;assert b==subprocess.check_output(['git','-C',str(pub),'show',f82+':'+gp]); (r/'historical'/('774-'+n)).write_bytes(b);items.append({'kind':'exact original historical file','local':'historical/774-'+n,'origin':str(old/n),'transport_revision':f82,'git_path':gp,'sha256':h(b),'bytes':len(b)})
reg=[json.loads(x) for x in (old/'source-range-registration.jsonl').read_text().splitlines()];qual=[json.loads(x) for x in (old/'source-qualifications.jsonl').read_text().splitlines()]; roles=json.loads((r/'historical/roles.json').read_text())['roles'];cmps=[]
for row in roles:
 for ob in row['entry']['admission03_scope_observations']:
  ix=ob['row_1based'];a=reg[ix-1];assert a==ob['original_record']
  for q in ob['local_qualifications']:
   assert q in qual
  cmps.append({'role':row['index'],'registration':a['id'],'original_row_1based':ix,'registration_matches_registry_inline':True,'qualification_matches_original':True})
receipt=Path('<LOCAL_PATH_3>');b=receipt.read_bytes();assert h(b)=='7f789f35339fe103021e274f5bdd69f2029db5d821c3ed7f4389bc055c3a06b5';(r/'historical/059-READ-L11-217.json').write_bytes(b);items.append({'kind':'exact original 059 historical receipt','local':'historical/059-READ-L11-217.json','origin':str(receipt),'sha256':h(b),'bytes':len(b),'reviewer':'Adler L11; exact original receipt identifies lens and batch, attribution not inferred from path alone'})
queue=pub/'baseline-059/queue.json';qb=queue.read_bytes();q=json.loads(qb);select={'source_path':str(queue),'source_sha256':h(qb),'kind':'reconstructed selection from recovered exact 059 queue; zero new source credit','rows':[{'index':i,'entry':q['entries'][i]} for i in [72,1303]]};(r/'historical/059-queue-selection-reconstructed.json').write_text(json.dumps(select,indent=2)+'\n')
cat=Path('<LOCAL_PATH_4>');cb=cat.read_bytes();c=json.loads(cb);sel={'source_path':str(cat),'source_sha256':h(cb),'kind':'reconstructed catalog-row selection, not a source read receipt','rows':[c['rows'][i] for i in [2573,2574]]};(r/'historical/774-catalog-selection-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n');
for i,row in zip([2573,2574],sel['rows']):assert row['expected_sha256']==roles[i-2573]['entry']['sha256'] and row['scope_index']==i
links=[]
for path in ['ASSESSMENT-GRAPHICS-CONFIG-ADMISSION-95E.json','ASSESSMENT-L01-AI-CONFIG-95E.json','ASSESSMENT-L01-HISTORICAL-1530-1534.json','native-evidence/serde-saphyr-1.2.0/MANIFEST.json','native-evidence/serde-saphyr-1.2.0/serde-saphyr-1.2.0.crate','native-evidence/serde_core-1.0.229/serde_core-1.0.229.crate','native-evidence/serde-derive-1.0.229/serde_derive-1.0.229.crate','recovered/original-registry-source-archive/MANIFEST.json','recovered/original-registry-source-archive/objects.tar.gz','recovered/original-registry-source-archive/registry.json.gz']:
 b=(pub/path).read_bytes();links.append({'path':str(pub/path),'sha256':h(b),'bytes':len(b),'qualification':'hash-linked prior evidence; archive bytes and earlier reader attributions do not grant fresh read credit'})
d={'original_files':items,'registration_equality_checks':cmps,'catalog_comparison':'Recovered 774 catalog and original cumulative registry align at indices 2573/2574 for source IDs and recorded SHA-256; no mismatch observed in these rows. Distinguish f82 evidence transport from external package provenance.','hash_links':links,'reconstructed_selections':['historical/059-queue-selection-reconstructed.json','historical/774-catalog-selection-reconstructed.json']}
(r/'historical-manifest.json').write_text(json.dumps(d,indent=2)+'\n');print('original exact files',len(items),'prior registration checks',cmps,'hash links',len(links))
