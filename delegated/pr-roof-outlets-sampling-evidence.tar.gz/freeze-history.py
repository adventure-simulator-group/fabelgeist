from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
old=Path('<LOCAL_PATH_0>')
pub=Path('<LOCAL_PATH_1>')
sha=lambda x:hashlib.sha256(x).hexdigest()
oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
rpath='recovered/original-registry-source-archive/registry.json.gz';mpath='recovered/original-transport-manifest.json.gz';r=json.load(gzip.open(pub/rpath,'rt'))
sel={'schema':'726-registry-selection-reconstructed-v1','qualification':'Reconstructed selection from 059 registry, not original record or checkpoint 3821. Source snapshots retain their original identity.','original_registry_sha256_uncompressed':sha(gzip.decompress((pub/rpath).read_bytes())),'rows':[{'original_index':i,**r['files'][i]} for i in (2544,2545)],'snapshots':[x for x in r['snapshots'] if x['id']=='pr-working']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n')
q=json.loads((pub/'baseline-059/queue.json').read_bytes());wanted=['Q-L11-bce132e12e6957398690','Q-L11-79313608252dade3ca16','L12-CLOSURE-ROOF-JUNCTION-GUTTER-ID-NAMESPACE','L12-CLOSURE-ROOF-OUTLET-STATION-COUNT-POLICY','L12-CLOSURE-ROOF-OUTLET-CLAMP-WALL-ADMISSION','L12-CLOSURE-ROOF-OUTLET-FALLBACK-ACCEPTANCE','L12-CLOSURE-ROOF-OUTLET-COLLECTOR-ID-DOMAIN']; selected=[e for e in q['entries'] if e.get('contract_id') in wanted]
(b/'historical-queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-queue-selection-reconstructed-v1','qualification':'059 historical selection; no source/current/status credit','entries':selected,'requested_missing':[n for n in wanted if n not in {e.get('contract_id') for e in selected}]},indent=2)+'\n')
m=json.load(gzip.open(pub/mpath,'rt'));idx={e['path']:e for e in m['entries']};paths=[]
for lens,n in [(11,420),(12,863),(12,864)]:
 for k in ['READ','VERIFY','STATE']: paths.append(f'segovb/{k}-L{lens}-{n}.json')
paths += [f'segovb/REGISTRATION-SEGOVB-{n}.json' for n in (1450,1451)] + [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json' for n in (575,576)]+[f'parallel-l12-20261029/PROPOSAL-L12-{n}.json' for n in (863,864)]+['parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-857-864.json']+[f'parallel-l12-20261029/PARTIAL-PAR-L12-863-00{n}.json' for n in range(1,6)]
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file():missing.append(p);continue
 raw=(old/p).read_bytes();e=idx[p];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(raw)==e['git_blob'];dst=b/'historical-059'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records.append({'original_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
prefix='handoff/774/adler-original/audit/continuation/'; paths774=[prefix+'native/root-roof-producer-followup/'+n for n in ['local-source-scope-extensions.jsonl','additional-sources.jsonl','coverage.jsonl','traces.jsonl','findings.jsonl','receiver-joins-001.json']]+[prefix+'root/producer-followup-acceptance-028.json',prefix+'root/producer-scope-extension-authority-022.json']
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records774=[]
for p in paths774:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+p]);assert oid(raw)==subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+p],text=True).strip();dst=b/'historical-774'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records774.append({'transport_revision':rev,'transport_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
refs=[]
for p in [rpath,mpath,'baseline-059/queue.json','baseline-059/ledger.json']:
 raw=(pub/p).read_bytes();refs.append({'repository_relative_path':p,'sha256':sha(raw),'bytes':len(raw),'qualification':'Previously published baseline historical evidence; no personal source read credit transferred.'})
(b/'published-references.json').write_text(json.dumps({'schema':'726-published-evidence-hash-links-v1','repository':'audit baseline publication','created_utc':datetime.now(timezone.utc).isoformat(),'entries':refs,'qualification':'Hash-linked existing complete evidence; pass publication repository to verifier.'},indent=2)+'\n')
prior=[]
for name,author in [('726-delegate-pr-roof-dormers-drainage','/root/rig_identity'),('726-delegate-physical-roof-geometry','/root/rig_identity'),('726-delegate-building-roof-abutments-hair-ops','/root/hair_ops')]:
 p=Path('/tmp')/name;target=b/'prior-delegate'/name;target.mkdir(parents=True,exist_ok=True);entries=[]
 for n in (['report.json','packet-manifest.json','read-receipt.json','support-read-receipt.json'] if author=='/root/hair_ops' else ['REPORT.json','MANIFEST.json','personal-read-receipt.json']):
  if not (p/n).exists():continue
  raw=(p/n).read_bytes();(target/n).write_bytes(raw);entries.append({'name':n,'sha256':sha(raw),'bytes':len(raw),'preserved_bytes':str((target/n).relative_to(b))})
 prior.append({'name':name,'author':author,'records':entries,'complete_source_packet_reference':str(p),'qualification':'Selected original report/manifest/receipt, no transferred credit. Prior packet remains hash-linked by its own manifest.'})
out={'schema':'726-original-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'original_059_records':records,'older_774_receipts':records774,'prior_delegate_selected_records':prior,'published_references':'published-references.json','missing_originals':missing,'qualification':'Recovered historic, reconstructed, and current evidence retain actual revision and reader. No promotion to checkpoint 3821.'}
(b/'original-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('059',len(records),'774',len(records774),'prior',len(prior),'missing',missing)
