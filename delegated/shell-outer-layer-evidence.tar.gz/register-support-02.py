import pathlib,subprocess,hashlib,json,datetime
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';(p/'support').mkdir(exist_ok=True);rows=[]
specs=[('crates/fabelgeist-shell/src/surface_contact.rs',[[89,155]]),('crates/fabelgeist-shell/src/shell.rs',[[245,299]])]
for i,(path,ranges) in enumerate(specs,6):
 b=subprocess.check_output(['git','-C',repo,'show',f'{rev}:{path}']);blob=subprocess.check_output(['git','-C',repo,'rev-parse',f'{rev}:{path}'],text=True).strip();rel=f'support/{i}.rs';(p/rel).write_bytes(b);rows.append(dict(path=path,revision=rev,sha256=hashlib.sha256(b).hexdigest(),blob=blob,bytes=len(b),eof=len(b.splitlines()),prospective_ranges=ranges,file=rel))
x=dict(author='/root/mhr_character',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='Production host-contact projection and shell schedule; replaces no prior planned test-source read.',navigation_qualification='Filename grep and metadata keyword line number lookup occurred before registration without printing source bodies.',rows=rows);(p/'support-registration-02.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
