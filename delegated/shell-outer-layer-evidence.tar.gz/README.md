# Shell outer layer: source-only evidence packet

This packet independently assesses original role 2658 against pinned current
95e and the recorded historical 6533 pr-working per-file identity. The report
contains source references, findings, historical attribution and thirteen
bounded lens perspectives.

`registration.json` and `read-receipt.json` record separate prospective and
actual old/current displays. Support registrations and receipts cover only
the specified windows: preserved whole bytes do not imply whole-file personal
reads. Historical 059 and 774 reviewers covered only lines 1–116; the current
reader also displayed test source lines 117–196, without executing tests.

`git-proofs.json` and `git-objects/` preserve raw Git membership proofs;
`historical-index.json` lists original recovered evidence. The queue extract is
reconstructed rather than an original standalone record. Verification uses the
publication directory containing the hash-linked registry, original transport
manifest, queue and previously published packets:

```
python3 verify-evidence.py /path/to/target/726-audit-baseline/publication
```

`verification.json` records evidence-integrity checks only. No product, build,
test, simulation, geometry query, GPU, fixture, probe, implementation or repair
ran. There is no checkpoint3821 or whole-lens completion claim.
