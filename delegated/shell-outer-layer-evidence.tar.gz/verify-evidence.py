#!/usr/bin/env python3
"""Read-only source/evidence hash, membership, and scope accounting; no product validation."""
import gzip,hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['timestamp_utc'] and len(receipt['actual_displays'])==2
for x in receipt['actual_displays']:
 row=next(y for y in r['rows'] if y['original_index']==x['role']);o=next(y for y in row['objects'] if y['label']==x['revision']);b=(p/o['local_file']).read_bytes();assert sha(b)==o['sha256'] and len(b.splitlines())==o['eof'];covered=set()
 for a,z in x['ranges']:covered.update(range(a,z+1))
 assert covered==set(range(1,o['eof']+1)) and not x['unread']
for row in r['rows']:assert row['objects'][0]['sha256']==row['registry_entry']['sha256']==row['objects'][1]['sha256']
checks.append('Two prospective separate historical/current displays cover the full assigned body; per-file identity only')
for suffix in ('','-02','-03','-04','-05'):
 sr=load('support-registration'+suffix+'.json');s=load('support-read-receipt'+suffix+'.json');assert s['registration_sha256']==sha((p/('support-registration'+suffix+'.json')).read_bytes()) and sr['at']<s['at'] and len(s['reads'])=={'':6,'-02':2,'-03':3,'-04':2,'-05':1}[suffix]
 for x in s['reads']:
  b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof']
  assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['prospective_ranges']==x['actual_ranges'] and y['file']==x['source_file'] for y in sr['rows'])
checks.append('Fourteen current support registrations were separately registered before the displayed windows')
arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==r['registry_uncompressed_sha256'];registry=json.loads(orig)
 trans=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in trans['entries']}
for x in r['rows']:assert x['registry_entry']==registry['files'][x['original_index']]
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==8 and sum(x['kind']=='historical-774' for x in hi['records'])==5
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original registry and eight exact 059 records match original transport manifest; five 774 files retained')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==22
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Twenty-two raw commit/tree/blob chains establish 6533, 95e and f82 transport identities')
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14))
for x in report['support_reads']:
 cov=set()
 for a,z in x['actual_ranges']:cov.update(range(a,z+1))
 missing=set()
 for a,z in x['unread_for_this_registration']:missing.update(range(a,z+1))
 assert not cov.intersection(missing) and cov.union(missing)==set(range(1,x['eof']+1))
old=gzip.decompress((p/'history-774/additional-contracts.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[106])['id']=='RIG-ADMISSION03-ADDITIONAL-121' and json.loads(old[117])['id']=='RIG-ADMISSION03-ADDITIONAL-132'
old=gzip.decompress((p/'history-774/source-range-registration.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[120])['id']=='RIG-ADMISSION03-REG-121' and json.loads(old[131])['id']=='RIG-ADMISSION03-REG-132'
old=gzip.decompress((p/'history-774/findings.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[98])['id']=='RIG-ADMISSION03-F090' and json.loads(old[56])['id']=='RIG-ADMISSION03-F054' and json.loads(old[88])['id']=='RIG-ADMISSION03-F082' and json.loads(old[89])['id']=='RIG-ADMISSION03-F083'
groups=json.loads(gzip.decompress((p/'history-774/contracts-014.json.gz').read_bytes()))['groups'];assert 'outer-layer-affine-samples-and-bounded-direction-distinction' in groups
old=load('history-059/READ-L12-919.json');assert old['root_personal_rereads']==[];row=next(x for x in old['rows'] if x['original_index']==2658);assert row['fresh_personal_body_reads']==[[1,116]] and '/root/lens12_frontier' in row['attribution']
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());q=load('queue-related-extract.json');assert sha((pub/'baseline-059/queue.json').read_bytes())==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'
for e in q['entries']:assert queue['entries'][e['zero_based_index']]==e['entry']
assert sha((pub/'ASSESSMENT-BVH-CLOTH-95E.json').read_bytes())=='e655e9b3b4de0755f03a95a9b15fc30650f7ebc23ef98a6fb9b8d54290e19d4b'
assert sha((pub/'delegated/xpbd-particles-evidence.tar.gz').read_bytes())=='cf1c7a386bc8bc97e1f7147985a3e8f0e232f620aed04cede82e28ffb5daf5c1' and sha((pub/'delegated/xpbd-particles-report.json').read_bytes())=='566417a3182f41910045d1190fbe5dca6929cf5949fb10915fbb97c4aa7393c7'
assert sha((pub/'delegated/shell-contact-evidence.tar.gz').read_bytes())=='824d7328963f0cc80c572eb85ca87daa1ccab05d10fe7040731c334f1896093f' and sha((pub/'delegated/shell-contact-report.json').read_bytes())=='7f4d2c1b20e54bb2011ebe8ed7125c7e4527bfec2b7d1161e75a4441c2cce186'
recovery=json.loads((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes());assert sha((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007' and sha((pub/recovery['recovered_patch']['path']).read_bytes())==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
checks.append('Thirteen bounded perspectives, support complements, original reader attribution, REG/ADDITIONAL-121/132 and F054/F082/F083/F090, queue extraction, prior published evidence and P16 recovery hash links')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and accounting only. No product execution, testing, build, probe, simulation, rendering, implementation, publication edit, whole-lens closure or checkpoint3821 promotion.'},indent=2))
