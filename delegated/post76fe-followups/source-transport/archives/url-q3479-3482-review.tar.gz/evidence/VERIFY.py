#!/usr/bin/env python3
"""Evidence-only packet, Git-tree and optional history verification."""
from pathlib import Path
import argparse,hashlib,json,os,stat,subprocess,sys
if sys.flags.optimize:raise RuntimeError("unoptimized interpreter required")
p=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument("--repo",type=Path);ap.add_argument("--history",type=Path);ap.add_argument("--restricted",type=Path);ap.add_argument("--original-object",type=Path);a=ap.parse_args()
def sh(b):return hashlib.sha256(b).hexdigest()
def require(ok,msg):
 if not ok:raise RuntimeError(msg)
def inventory(root,filename,expected=None):
 raw=(root/filename).read_bytes()
 if expected:require(sh(raw)==expected,"manifest identity")
 m=json.loads(raw);files={q.relative_to(root).as_posix() for q in root.rglob("*") if q.is_file() and q!=root/filename};require(files==set(m["files"]),"inventory")
 for rel,row in m["files"].items():
  q=root/rel;b=q.read_bytes();require(not q.is_symlink() and len(b)==row["bytes"] and sh(b)==row["sha256"] and stat.S_IMODE(q.stat().st_mode)==row["mode"],"file identity")
inventory(p,"MANIFEST.json")
b=(p/"source/current_95e.rs").read_bytes();require(b==(p/"source/historical_6533.rs").read_bytes(),"file equality");require(sh(b)=="cbe71f461a1ace891f293e332766a0d8028bbe81d0e8b9e2051fe74763ab7b78","source sha");require(hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()=="84736fae737f9c20928e6eb767f0dd522c80ef6b","git blob")
line=json.loads((p/"LINE-DISPOSITIONS.json").read_bytes());inv=json.loads((p/"STATIC-INVENTORY.json").read_bytes());require([x["line"] for x in line["lines"]]==list(range(1,149)) and len(line["declarations"])==89,"line scope");require(inv["declarations"]==89 and inv["arity_counts"]=={"0":14,"1":32,"2":19,"3":19,"4":5} and not inv["mismatches"],"census receipt")
def entries(raw):
 d={};i=0
 while i<len(raw):
  j=raw.index(b" ",i);k=raw.index(b"\0",j+1);d[raw[j+1:k].decode()]={"mode":raw[i:j].decode(),"oid":raw[k+1:k+21].hex()};i=k+21
 return d
proof=json.loads((p/"TREE-PROOFS.json").read_bytes())
for item in proof["proofs"]:
 oid=item["root_tree"]
 for step in item["chain"]:
  require(step["tree"]==oid,"tree chain");raw=(p/"proof/trees"/oid).read_bytes();require(hashlib.sha1(b"tree "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==oid,"tree identity");entry=entries(raw)[step["component"]];require(entry["mode"]==step["mode"] and entry["oid"]==step["child"],"tree member");oid=entry["oid"]
 require(oid==item["git_blob"],"final blob")
checks=["public inventory, source equality, line census receipt and tree path objects"]
if a.restricted:inventory(a.restricted,"PRIVATE-MANIFEST.json","cd8ac857bc32bb460e6006db0fceaf3694d2bdb6b3a9c1fb6ccc267da7b5bfba");checks.append("restricted packet inventory")
if a.original_object:require(a.original_object.read_bytes()==b,"original object");checks.append("original recovered object")
if a.history:
 meta=json.loads((p/"HISTORY-LEDGER-SUMMARY.json").read_bytes());rows=json.loads((p/"HISTORY-RECEIPT.json").read_bytes())["rows"]
 for role,fn,key in [("original","QUEUE-ORIGINAL.json","059_original_queue_sha256"),("reconstructed","QUEUE-RECONSTRUCTED.json","059_reconstructed_queue_sha256")]:
  data=(a.history/fn).read_bytes();require(sh(data)==meta[key],"history full stream")
  for row in rows:
   if row["kind"]==role:
    part=data[row["original_stream_byte_offset"]:row["end_exclusive"]];require(len(part)==row["byte_length"] and sh(part)==row["sha256"],"history selected bytes")
 checks.append("exact original/reconstructed streams and selected lexical hashes")
if a.repo:
 env={**os.environ,"GIT_OPTIONAL_LOCKS":"0"}
 def git(*args):return subprocess.check_output(["git","-C",str(a.repo),*args],env=env)
 cache={}
 for item in proof["proofs"]:
  require(git("rev-parse",item["revision"]+"^{tree}").decode().strip()==item["root_tree"],"commit root")
  require(git("rev-parse",item["revision"]+":"+item["path"]).decode().strip()==item["git_blob"],"commit path")
  data=git("show",item["revision"]+":"+item["path"]);cache[(item["revision"],item["path"])]=data
  require(hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==item["git_blob"],"git source blob")
  if item["path"].endswith("/patterns.rs"):require(data==b,"assigned source")
  if item["path"].endswith("/location_urls.rs"):require(data==(p/"source/support-owner-95e.rs").read_bytes(),"owner source")
 rev="95e63628f9d70b8dd6e6fede64334696c6995009"
 windows={"router-0170-0185":("crates/strategic-web/src/routes/settlements/router.rs",170,185),"router-0279-0290":("crates/strategic-web/src/routes/settlements/router.rs",279,290),"quest-0056-0088":("crates/strategic-web/src/templates/quest.rs",56,88),"strategic-place-0001-0065":("crates/adventuresim-core/src/strategic_place.rs",1,65)}
 for name,(path,start,end) in windows.items():require(b"".join(cache[(rev,path)].splitlines(keepends=True)[start-1:end])==(p/"views"/(name+".txt")).read_bytes(),"support window")
 meta=json.loads((p/"HISTORY-LEDGER-SUMMARY.json").read_bytes());baseline=git("show",meta["b111_commit"]+":BASELINE-95E-20261110.json");require(sh(baseline)==meta["b111_ledger_sha256"],"b111 ledger");entries_=json.loads(baseline)["newly_assessed_ledger"]["entries"]
 for i,row in meta["b111_selected_ledger"].items():require(entries_[int(i)]==row,"ledger row")
 q=git("show",meta["b111_commit"]+":RECONCILIATION-059.json");w=json.loads((p/"QUEUE-WRAPPERS-b111.json").read_bytes());require(sh(q)==w["source_sha256"],"b111 queue");rows_=json.loads(q)["entries"];require(all(rows_[int(i)]==x for i,x in w["selected"].items()),"wrapper rows");checks.append("Git commit anchors, full source objects, support windows and b111 references")
print(json.dumps({"checks":checks,"limits":"Tree proofs alone do not establish commit-to-tree bindings; Git anchors need --repo. Source text is not product execution, runtime validation, closure or independent custody."},indent=2))
