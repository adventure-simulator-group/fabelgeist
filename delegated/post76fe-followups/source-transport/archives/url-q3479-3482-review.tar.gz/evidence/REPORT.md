# Four-lens review of location-route patterns

The 148-line patterns file contains 89 named route declarations and no manual
trait or serialization implementations. The declaration source is byte-equal
at 6533, e275 and pinned 95e, and the original recovered object matches those
bytes. This is per-file identity: the recorded pr-working snapshot had other
modifications, and no whole-tree cleanliness or checkpoint 3821 is inferred.

The source was prospectively registered for q3479–q3482 and all four lenses.
This reviewer personally displayed both the 6533 and 95e bodies separately in
two complete chunks each. The e275 relationship is Git object identity only in
this review. Connected support was separately registered and is limited to the
ranges in the read receipt; stored support objects do not credit unread lines.

- **q3479, derivability:** `patterns.rs:1–148` has constants and an import,
  not handwritten implementations. `location_urls.rs:52–59` already derives
  `Clone` and `Copy` for `Route`; the adjacent `LocationKind` display and parse
  mapping at `:18–50` is semantic. No equivalent project derive for the latter
  was established, and the adjacent owner is support rather than this source
  obligation. No replacement derive is recommended from this bounded review.
- **q3480, granularity:** `Route<N>` fixes the number of supplied `Display`
  values (`location_urls.rs:52–75`) but does not name each argument's semantic
  role. The case-site and settlement constants at `patterns.rs:5–7,46`, and
  the party pattern at `:80`, have distinct identity roles. The selected owner
  match at `location_urls.rs:26–30` chooses the appropriate route; no actual
  swapped caller is shown. `CaseSiteId` retains an intentional site-specific
  distinction (`strategic_place.rs:17–35,43–57`). Whether stronger route
  argument roles are warranted across supported callers remains open.
- **q3481, strings:** Each declaration's route string is a named HTTP pattern;
  selected settlement routers consume `.pattern()` and a selected quest template
  calls `.url()` (`router.rs:170–185,279–290`; `quest.rs:56–88`). The formatter
  replaces brace fields by position and encodes each value (`location_urls.rs:
  65–91`), without using the placeholder name as a type check. The earlier
  role0059 conditional remains: source admission accepts `.` and `..` as
  case-site components and the encoder leaves dot bytes intact. If one reaches
  the selected pin/template, a dot-only segment is constructed. Stored-input
  reach, client normalization, native router behavior and policy remain open;
  this corroboration does not add a new finding count.
- **q3482, numeric primitives:** The only numeric literals in the assigned
  file are the `Route<0>` through `Route<4>` const-generic arities. A bounded
  textual census counted 14, 32, 19, 19 and 5 declarations respectively;
  all 89 have matching placeholder counts. `N: usize` fixes the array length
  accepted by the formatter, while the constructor does not prove the pattern's
  arity. This is a source census, not compilation, a test or native validation.

The line dispositions enumerate all 148 source lines and the four lens-specific
rubrics for each declaration. Remaining questions include all other route and
ID producers, exact client and framework behavior, and a policy for any stronger
path-segment boundary. No wrong-role caller, runtime failure, global alias,
unique defect count, repair or lens closure is claimed.

Historical q3297 is Root's separately attributed Lens 3 arity qualification;
it retains its service and native-URI questions. Original receipts record a
fresh 6533 Root Lens 3 read and an e275 same-lens reuse contingent on frozen
adoption, not a fresh e275 read. The earlier role0059 work by this reviewer
assessed lenses 1, 2, 5 and 6; it is not transferred to this review. The
independent role0047 support read had a truncated first full display and a
separate two-part reread; its later brace erratum remains attached. At committed
b111, the four current wrappers are unassessed; ledger entry 727/q454 concerns
service-string admission and entry 271 concerns venue/place identity. Their
relationships are contextual, not automatic aliases or new counts.

The initial text-census matcher failed on a Rust trailing comma; its original
failure and corrected successor are retained. A broad metadata difference
output was truncated, and the four current wrapper rows were then displayed in
a separate bounded call. An initial status-key lookup was corrected to use the
wrapper's `current_reconciliation` field. No product, browser, URI parser,
fixture, macro, test, build, runtime probe or repair was performed.
