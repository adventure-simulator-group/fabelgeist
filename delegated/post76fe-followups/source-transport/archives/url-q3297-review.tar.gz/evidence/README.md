# Location route admission review

This separate Lens 3 assessment rereads the registered current source and
traces selected service and chapter admissions. It is pending central review;
no historical record, lens, repair or unique-defect count is closed.

Run `python3 VERIFY.py --repository <evidence-checkout>` to replay source
identities, the textual declaration inventory and the selected original and
reconstructed checkpoint 059 queue record. Add `--restricted <directory>` to
verify exact registration and historical receipt hashes and the three recovered
historical source-object bytes. Those restricted files require separate custody.
The replay runs evidence checks only. It is same-machine evidence and does not
execute product code or recover the missing original checkpoint 3821.
