#!/usr/bin/env python3
"""Replay source/evidence identities and static declaration shapes only."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

if not __debug__:
    raise SystemExit('optimized interpreter is unsupported')
p = argparse.ArgumentParser()
p.add_argument('--repository', required=True)
p.add_argument('--restricted')
a = p.parse_args()
root = Path(__file__).resolve().parent
m = json.loads((root / 'MANIFEST.json').read_text())
actual = sorted(x.relative_to(root).as_posix() for x in root.rglob('*')
                if x.is_file() and x.name != 'MANIFEST.json')
assert actual == sorted(m['files'])
for name, row in m['files'].items():
    b = (root / name).read_bytes()
    assert len(b) == row['bytes'] and hashlib.sha256(b).hexdigest() == row['sha256']
    assert bool((root / name).stat().st_mode & 0o111) == row['executable']
r = json.loads((root / 'REPORT.json').read_text())
repo, rev = a.repository, r['baseline']['revision']
def git(*args):
    return subprocess.check_output(['git', '-C', repo, *args])
assert git('rev-parse', rev + '^{tree}').decode().strip() == r['baseline']['tree']
sources = {}
for item in r['scope']['source_identities']:
    data = git('show', rev + ':' + item['path'])
    assert hashlib.sha256(data).hexdigest() == item['sha256']
    assert len(data.splitlines()) == item['actual_eof']
    assert git('rev-parse', rev + ':' + item['path']).decode().strip() == item['git_blob']
    sources[item['path']] = data
text = sources[r['scope']['primary']].decode()
heads = re.findall(r'pub\s+const\s+([A-Z][A-Z_0-9]*)\s*:\s*Route\s*<\s*(\d+)\s*>', text)
values = re.findall(r'pub\s+const\s+([A-Z][A-Z_0-9]*)\s*:\s*Route\s*<\s*(\d+)\s*>\s*=\s*Route::new\s*\(\s*"([^"\\]*)"\s*,?\s*\)\s*;', text, re.S)
assert len(heads) == len(values) == 89
assert [h[0] for h in heads] == [v[0] for v in values]
inv = json.loads((root / 'STATIC-L3.json').read_text())
assert len(inv['rows']) == len(values) and not inv['invalid']
for row, (name, n, value) in zip(inv['rows'], values):
    slots = re.findall(r'\{([^{}]+)\}', value)
    rest = re.sub(r'\{([^{}]+)\}', '', value)
    assert row['name'] == name and row['arity'] == int(n) == len(slots)
    assert row['slot_count'] == len(slots) and row['balanced'] and row['absolute']
    assert not ('{' in rest or '}' in rest) and value.startswith('/')
old = git('show', 'eb407672813424d64ec31f208193969f5a62620c:handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json')
recon = (Path(repo) / 'baseline-059/queue.json').read_bytes()
assert hashlib.sha256(old).hexdigest() == r['historical']['original_059_queue_sha256']
assert hashlib.sha256(recon).hexdigest() == r['historical']['reconstructed_059_queue_sha256']
assert json.loads(old)['entries'][3297] == json.loads(recon)['entries'][3297]
if a.restricted:
    restricted = Path(a.restricted)
    regs = json.loads((root / 'REGISTRATIONS.json').read_text())['registrations']
    for i, reg in enumerate(regs, 1):
        assert hashlib.sha256((restricted / f'REGISTRATION-{i:03}.json').read_bytes()).hexdigest() == reg['original_restricted_sha256']
    for receipt in r['historical']['old_receipts']:
        assert hashlib.sha256((restricted / receipt['path']).read_bytes()).hexdigest() == receipt['sha256']
    for i, item in enumerate(r['historical']['historic_objects_sha256_and_pinned_equality']):
        b = (restricted / f'HISTORICAL-OBJECT-{i}.bin').read_bytes()
        assert hashlib.sha256(b).hexdigest() == item['sha256'] and item['equal_pinned_bytes']
        assert b in sources.values()
print('PASS: Lens 3 registered source identities, literal shapes and q3297 historical comparison')
print('LIMIT: no native execution, supported reach proof, lens closure or checkpoint 3821 recovery')
