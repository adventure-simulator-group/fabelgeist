#!/usr/bin/env python3
"""Evidence-only q3569 additive correction verifier."""
import argparse,hashlib,json,pathlib,stat,sys
if sys.flags.optimize:raise SystemExit('optimized Python is not supported')
def sha(b):return hashlib.sha256(b).hexdigest()
def need(x,m):
    if not x:raise ValueError(m)
def verify(root,filename):
    m=json.loads((root/filename).read_bytes());rows=m['files'];actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix()!=filename};need(not any(p.is_symlink() for p in root.rglob('*')),'symlink');need(actual=={x['path'] for x in rows} and len(rows)==len(actual),'inventory')
    for x in rows:
        q=pathlib.PurePosixPath(x['path']);need(not q.is_absolute() and '..' not in q.parts,'path');p=root.joinpath(*q.parts);b=p.read_bytes();need(len(b)==x['bytes'] and sha(b)==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==int(x['mode'],8),'member')
    return len(rows)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);ap.add_argument('--predecessor',type=pathlib.Path);ap.add_argument('--public-predecessor',type=pathlib.Path);a=ap.parse_args();root=pathlib.Path(__file__).resolve().parent;b=json.loads((root/'BINDING.json').read_bytes());out={'public_files':verify(root,'MANIFEST.json'),'historical_check':'not requested'}
    values=[a.private,a.predecessor,a.public_predecessor];need(not any(values) or all(values),'supply all predecessor paths')
    if all(values):
        pr=a.private;old=a.predecessor;op=a.public_predecessor;need(sha((pr/'PRIVATE-MANIFEST.json').read_bytes())==b['correction_private_manifest_sha256'],'correction private binding');n=verify(pr,'PRIVATE-MANIFEST.json');need(sha((old/'PRIVATE-MANIFEST.json').read_bytes())==b['predecessor_private_manifest_sha256'] and sha((op/'MANIFEST.json').read_bytes())==b['predecessor_public_manifest_sha256'],'predecessor identities')
        for f in ['Q3569-ORIGINAL.json','Q3569-RECONSTRUCTED.json','Q3569-B111.json','SUPPORT2-02-VIEW-0.txt','SUPPORT2-01-VIEW-0.txt']:need((pr/f).read_bytes()==(old/f).read_bytes(),'captured predecessor input')
        q=json.loads((pr/'Q3569-ORIGINAL.json').read_bytes());reconstructed=json.loads((pr/'Q3569-RECONSTRUCTED.json').read_bytes());wrapper=json.loads((pr/'Q3569-B111.json').read_bytes());need(q==reconstructed and 'status' not in q,'historical field absence');need('historical_status' in wrapper and wrapper['historical_status'] is None,'projected null');out.update({'historical_check':'passed','correction_private_files':n,'qualification':'Source evidence only; this does not independently prove runtime reach or custody.'})
    print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
