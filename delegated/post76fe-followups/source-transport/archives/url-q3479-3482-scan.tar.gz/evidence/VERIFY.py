#!/usr/bin/env python3
"""Verify bounded scan outputs and linked packet manifests without writes."""
from pathlib import Path
import argparse,hashlib,json,stat,sys
if sys.flags.optimize:raise RuntimeError("unoptimized interpreter required")
p=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument("--public",required=True,type=Path);ap.add_argument("--replay",required=True,type=Path);a=ap.parse_args()
def sh(b):return hashlib.sha256(b).hexdigest()
m=json.loads((p/"MANIFEST.json").read_bytes());actual={x.relative_to(p).as_posix() for x in p.rglob("*") if x.is_file() and x!=p/"MANIFEST.json"}
if actual!=set(m["files"]):raise RuntimeError("scan inventory")
for rel,row in m["files"].items():
 q=p/rel;b=q.read_bytes()
 if q.is_symlink() or len(b)!=row["bytes"] or sh(b)!=row["sha256"] or stat.S_IMODE(q.stat().st_mode)!=row["mode"]:raise RuntimeError("scan identity")
for root,expected in [(a.public,"8a1d3ced8cbbb5dc108bcbdffdd734231700ddef13b70f54053847a335a85e8e"),(a.replay,"b1f1fb19b5d029c2d89bc47125b7a218b46326f2a0b2fd3003b747bd618b5dde")]:
 if sh((root/"MANIFEST.json").read_bytes())!=expected:raise RuntimeError("linked manifest")
for name in ["059.json","q2332.json"]:
 x=json.loads((p/name).read_bytes())
 if x["matching_occurrences"] or x["exceptions"]:raise RuntimeError("digest scan")
for name in ["gpu-public.stdout","gpu-replay.stdout"]:
 x=json.loads((p/name).read_bytes())
 if x["forbidden_digest_total"] or x["other_candidate_counts"] or x["exceptions"]:raise RuntimeError("privacy scan")
print("Bounded scan records and linked manifests match; exclusions remain.")
