#!/usr/bin/env python3
"""Offline evidence-only identity and source-proof replay."""
import argparse,gzip,hashlib,json,pathlib,stat,sys
if sys.flags.optimize:raise SystemExit('optimized Python is not supported')
def ck(ok,label):
    if not ok:raise ValueError(label)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def files(root,manifest,exclude):
    rows=manifest['files'];names=[r['path'] for r in rows];ck(len(names)==len(set(names)),'duplicate paths')
    actual=set()
    for p in root.rglob('*'):
        ck(not p.is_symlink(),'symlink')
        if p.is_file() and p.relative_to(root).as_posix() not in exclude:actual.add(p.relative_to(root).as_posix())
    ck(actual==set(names),'file set')
    for row in rows:
        rel=pathlib.PurePosixPath(row['path']);ck(not rel.is_absolute() and '..' not in rel.parts,'unsafe path')
        p=root.joinpath(*rel.parts);b=p.read_bytes()
        ck(len(b)==row['bytes'] and sha(b)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8),'file identity/mode')
    if 'directories' in manifest:
        dirs={x['path']:int(x['mode'],8) for x in manifest['directories']}
        actualdirs={p.relative_to(root).as_posix():stat.S_IMODE(p.stat().st_mode) for p in root.rglob('*') if p.is_dir()}
        ck(len(dirs)==len(manifest['directories']) and dirs==actualdirs and stat.S_IMODE(root.stat().st_mode)==int(manifest['root_mode'],8),'directory set/mode')
    return len(rows)
def entries(raw):
    i=0
    while i<len(raw):
        s=raw.index(b' ',i);z=raw.index(b'\0',s+1);ck(z+21<=len(raw),'short tree')
        yield raw[i:s].decode(),raw[s+1:z].decode(),raw[z+1:z+21].hex();i=z+21
    ck(i==len(raw),'tree framing')
def obj(objects,oid,typ):
    ck(oid in objects and objects[oid][0]==typ,'object missing');return objects[oid][1]
def root_tree(objects,rev):
    line=obj(objects,rev,'commit').splitlines()[0];ck(line.startswith(b'tree '),'commit tree');return line[5:].decode()
def walk(objects,rev,path,chain=None):
    cur=root_tree(objects,rev);parts=path.split('/');ck(chain is None or len(parts)==len(chain),'chain length')
    for i,name in enumerate(parts):
        found=[v for v in entries(obj(objects,cur,'tree')) if v[1]==name];ck(len(found)==1,'tree member');mode,_,oid=found[0]
        ck(mode in (('40000','040000') if i<len(parts)-1 else ('100644',)),'tree mode')
        if chain is not None:
            row=chain[i];ck((row['tree'],row['name'],row['mode'],row['object'])==(cur,name,mode,oid),'chain entry')
        cur=oid
    return cur
def view(body,lo,hi):
    lines=body.decode().splitlines();ck(1<=lo<=hi<=len(lines),'view bounds')
    return ''.join(f'{n:4} {lines[n-1]}\n' for n in range(lo,hi+1)).encode()
def slices(raw,want):
    s=raw.decode();d=json.JSONDecoder();i=s.index('[',s.index('"entries"'))+1;out={}
    for n in range(max(want)+1):
        while s[i].isspace() or s[i]==',':i+=1
        start=i;_,i=d.raw_decode(s,i)
        if n in want:out[n]=s[start:i].encode()
    return out
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--private',type=pathlib.Path);args=ap.parse_args();pub=pathlib.Path(__file__).resolve().parent
    npublic=files(pub,load(pub/'MANIFEST.json'),{'MANIFEST.json'});result={'public_files_checked':npublic,'private_replay':'not requested'}
    if args.private is None:print(json.dumps(result,sort_keys=True));return
    r=args.private.resolve();binding=load(pub/'PRIVATE-BINDING.json');raw=(r/'PRIVATE-MANIFEST.json').read_bytes();ck(sha(raw)==binding['private_manifest_sha256'],'private manifest binding');m=json.loads(raw)
    nprivate=files(r,m,{'PRIVATE-MANIFEST.json'});ck(nprivate==binding['private_files_excluding_manifest'] and len(m['directories'])==binding['private_directories'],'private manifest counts')
    objects={};inventories=[('GIT-PROOFS.json','git-objects'),('SUPPORT-CAPTURE.json','support-git-objects'),('SUPPORT2-CAPTURE.json','support2-git-objects'),('SUPPORT3-CAPTURE.json','support3-git-objects'),('B111-GIT-PROOFS.json','b111-git-objects')]
    for file,store in inventories:
        for oid,meta in load(r/file)['object_inventory'].items():
            b=(r/store/oid).read_bytes();typ=meta['type'];ck(len(b)==meta['bytes'] and sha(b)==meta['sha256'],'Git evidence bytes');ck(hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid,'Git object hash');ck(oid not in objects or objects[oid]==(typ,b),'conflicting object');objects[oid]=(typ,b)
    path='crates/strategic-web/src/templates/challenge.rs';proofs=load(r/'GIT-PROOFS.json')['revision_proofs'];revs={'6533':'6533e444fa37552927070cc8d8190907fd3b413e','e275':'e2755a732c84e67296b5e3441a4259a84f461b2f','95e':'95e63628f9d70b8dd6e6fede64334696c6995009'};bodies=[]
    for label,rev in revs.items():
        row=proofs[label];ck(row['commit']==rev,'source revision');oid=walk(objects,rev,path,row['chain']);ck(oid==row['source_blob'],'source leaf');b=obj(objects,oid,'blob');ck(b==(r/f'PRIMARY-{label}.rs').read_bytes() and sha(b)==row['sha256'] and len(b.splitlines())==483,'source body');bodies.append(b)
    ck(len(set(bodies))==1 and bodies[0]==(r/'PRIOR-04').read_bytes() and sha(bodies[0])=='febe3f70bd476ace78551dba3e4492bebd3651c96b66d3515dc041e6f9bed05f','historical working body')
    ck(root_tree(objects,revs['95e'])=='1eec97de340d9b7debbb30ca0c0fb2240a73b93f','current tree');reg=load(r/'SOURCE-REGISTRATION.json');ck(reg['revision']==revs['95e'] and reg['lens']==11 and reg['source']==path and reg['range']==[1,332],'primary registration');ck((r/'VIEW-L11-PRIMARY.txt').read_bytes()==view(bodies[0],1,332),'primary registered view')
    windows=0
    for cap,registration,prefix in [('SUPPORT-CAPTURE.json','SUPPORT-REGISTRATION.json','SUPPORT'),('SUPPORT2-CAPTURE.json','SUPPORT2-REGISTRATION.json','SUPPORT2'),('SUPPORT3-CAPTURE.json','SUPPORT3-REGISTRATION.json','SUPPORT3')]:
        rows=load(r/cap)['rows'];spec=load(r/registration);ck(len(rows)==len(spec['windows']) and spec['revision']==revs['95e'],'support count or revision')
        for index,(row,requested) in enumerate(zip(rows,spec['windows'])):
            ck(row['path']==requested['path'] and row['lenses']==requested['lenses']==[11],'support registration');oid=walk(objects,spec['revision'],row['path'],row['chain']);ck(oid==row['blob'],'support leaf');b=obj(objects,oid,'blob');ck(b==(r/f'{prefix}-{index:02}.rs').read_bytes() and sha(b)==row['sha256'] and len(b.splitlines())==row['EOF'],'support body');ck([v['range'] for v in row['views']]==requested['ranges'],'support range')
            for v in row['views']:
                bview=(r/v['file']).read_bytes();ck(bview==view(b,*v['range']) and sha(bview)==v['sha256'],'support view');windows+=1
    ck(windows==21,'support window total')
    indices={2700,2823};streams={}
    for label,digest in [('ORIGINAL','2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'),('RECONSTRUCTED','3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173')]:
        b=(r/(label+'-QUEUE-FULL.json')).read_bytes();ck(sha(b)==digest,'historic whole stream');selected=slices(b,indices);streams[label]=selected
        for n,x in selected.items():ck((r/f'Q{n}-{label}.json').read_bytes()==x,'historic exact slice')
    for n,digest in [(2700,'684829b563a2043f759108002b908849dfb33df154b8f7768e8b7384d0354dac'),(2823,'ba8b26c5d2c0060934c90c133389129dc81b8da1999ab4737d21993fb1fbb6ca')]:ck(streams['ORIGINAL'][n]==streams['RECONSTRUCTED'][n] and sha(streams['ORIGINAL'][n])==digest,'historic selected byte equality')
    q2700=json.loads(streams['ORIGINAL'][2700]);q2823=json.loads(streams['ORIGINAL'][2823]);ck('status' not in q2700 and q2700['lens']==3,'q2700 absent status');ck(q2823['lens']==11 and q2823['status']=='own-lens-proof-qualification-or-read-pending','q2823 historical status')
    for i,index in [(0,1),(1,9),(2,7),(3,7)]:ck(load(r/f'PRIOR-{i:02}')['rows'][index]==load(r/f'PRIOR-{i:02}-ROW.json'),'historical receipt selection')
    old=load(r/'PRIOR-01-ROW.json');reuse=load(r/'PRIOR-03-ROW.json');ck(old['attribution']=='Root personal independent Lens3 prospective bounded untruncated body read' and old['fresh_personal_ranges']==[[1,483]] and reuse['fresh_personal_ranges']==[] and 'no current personal reread' in reuse['qualified_reuse_basis'],'historical reading qualification')
    f045=(r/'F045-RAW-LINE.json').read_bytes();matches=[x for x in gzip.decompress((r/'PRIOR-05').read_bytes()).splitlines() if b'NATIVE-INITIAL05-F045' in x];ck(matches==[f045] and json.loads(f045)==load(r/'PRIOR-06'),'normalized 774 selected record')
    parent='b111f7444ab7e3b13b2099d5ce9d59f08faf9424';bp=load(r/'B111-GIT-PROOFS.json');ck(bp['commit']==parent and root_tree(objects,parent)==bp['tree'],'b111 parent')
    for row in bp['rows']:
        oid=walk(objects,parent,row['path']);b=obj(objects,oid,'blob');ck(oid==row['blob'] and sha(b)==row['sha256'] and b==(r/('B111-'+row['path'])).read_bytes(),'b111 file proof')
    queue=load(r/'B111-RECONCILIATION-059.json')['entries'];ck(queue[2700]['current_reconciliation']=='unassessed' and queue[2700]['historical_lens']==3 and queue[2700]['historical_status'] is None,'q2700 b111');ck(queue[2823]['current_reconciliation']=='unassessed' and queue[2823]['historical_lens']==11 and queue[2823]['historical_status']==q2823['status'],'q2823 b111')
    ledger=load(r/'B111-BASELINE-95E-20261110.json')['newly_assessed_ledger']['entries'];loc=load(r/'LEDGER-LOCATOR.json');terms=loc['terms'];hits=[]
    for i,row in enumerate(ledger):
        s=json.dumps(row,sort_keys=True,ensure_ascii=False);matched=[t for t in terms if t.casefold() in s.casefold()]
        if matched:hits.append({'index':i,'id':row.get('id'),'matched_terms':matched})
    ck(len(ledger)==1106 and loc['row_count']==len(ledger) and loc['hits']==hits and not hits,'bounded ledger search')
    checks=[('PRIMARY-95e.rs','source/assigned.rs'),('SUPPORT-00.rs','source/route.rs'),('SUPPORT-01.rs','source/puzzle.rs'),('SUPPORT-02.rs','source/logic.rs'),('SUPPORT-03.rs','source/native-challenges.rs')]
    for ours,theirs in checks:ck((r/ours).read_bytes()==(r/'author-public'/theirs).read_bytes(),'author source equality')
    ck(sha((r/'author-public/MANIFEST.json').read_bytes())=='451065a31db9401a5a19bda0bfd0988e8aa25f35f7ac680358772a1a8b9b7a6a','author public manifest');ck(sha((r/'author-private/PRIVATE-MANIFEST.json').read_bytes())=='3b5069807345769ec798c5191f4bb537fd3c0e96e2ab22101ff0b30bcc08079a','author restricted manifest')
    result.update({'private_replay':'passed','private_files_checked':nprivate,'git_objects_checked':len(objects),'registered_support_windows':windows,'primary_views_checked':1,'historical_records_checked':len(indices),'b111_literal_hits':len(hits),'qualification':'Evidence identities and registered source views only; no runtime outcome, closure or independent custody proven.'});print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
