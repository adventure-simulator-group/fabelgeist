#!/usr/bin/env python3
"""Read-only q2823 evidence verifier; optional Git commit/tree anchor check."""
import argparse, hashlib, json, os, pathlib, subprocess, sys
P=pathlib.Path(__file__).resolve().parent

def need(ok,msg):
    if not ok: raise SystemExit('FAIL: '+msg)
def sha256(b): return hashlib.sha256(b).hexdigest()
def tree_object(oid):
    data=(P/'git-trees'/(oid+'.bin')).read_bytes()
    need(hashlib.sha1(b'tree '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,'Git tree object '+oid)
    out={};i=0
    while i<len(data):
        z=data.index(b'\0',i); header=data[i:z]; mode,name=header.split(b' ',1)
        oid2=data[z+1:z+21].hex(); need(len(oid2)==40,'truncated tree entry');out[name]=(mode,oid2);i=z+21
    need(i==len(data),'tree object trailing data'); return out

def main():
    p=argparse.ArgumentParser(); p.add_argument('--repo',help='optional external Git store for commit-to-tree binding');args=p.parse_args()
    manifest=json.loads((P/'MANIFEST.json').read_text()); listed={x['path']:x for x in manifest['files']}
    actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and not x.is_symlink() and x.name!='MANIFEST.json'}
    need(not any(x.is_symlink() for x in P.rglob('*')),'symlinks are not accepted')
    need(actual==set(listed),'public member inventory')
    for path,row in listed.items():
        f=P/path;b=f.read_bytes();need(sha256(b)==row['sha256'] and len(b)==row['bytes'],'member '+path)
    proof=json.loads((P/'GIT-TREE-PROOF.json').read_text())
    for row in proof['rows']:
        parts=row['path'].encode().split(b'/');tree=row['root_tree']
        for name in parts[:-1]:
            e=tree_object(tree);need(name in e,'tree path');mode,tree=e[name];need(mode in (b'40000',b'040000'),'tree directory mode')
        e=tree_object(tree);need(parts[-1] in e,'tree file');mode,blob=e[parts[-1]];need(mode in (b'100644',b'100755'),'source blob mode');need(blob==row['blob'],'tree blob reference')
        raw=(P/row['source_file']).read_bytes();need(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob,'source blob')
        if args.repo:
            a=subprocess.check_output(['git','-C',args.repo,'rev-parse',row['revision']+'^{tree}'],text=True).strip()
            b=subprocess.check_output(['git','-C',args.repo,'rev-parse',row['revision']+':'+row['path']],text=True).strip()
            need(a==row['root_tree'] and b==row['blob'],'external commit/tree anchor')
    coverage=json.loads((P/'COVERAGE.json').read_text());assigned=coverage['assigned_source_displays']['rows']
    for row in assigned:
        need(row['ranges']==[[1,80],[81,160],[161,240],[241,320],[321,400],[401,483]],'registered full assigned coverage')
    print(json.dumps({'result':'pass','public_files':len(listed),'tree_proofs':len(proof['rows']),'external_git_anchor':'checked' if args.repo else 'not checked; commit-to-tree mapping remains external','history':'raw original and reconstructed queue selections require restricted evidence; not checked here','product_execution':False}))
if __name__=='__main__': main()
