#!/usr/bin/env python3
"""Read-only member mode check for the q2823 public manifest."""
import json,pathlib,sys
p=pathlib.Path(sys.argv[1]);rows=json.loads((p/'MANIFEST.json').read_text())['files']
for r in rows:
 f=p/r['path']; actual=oct(f.stat().st_mode&0o777)
 if actual!=r['mode']:raise SystemExit('public file mode mismatch: '+r['path'])
print(json.dumps({'mode_checked_files':len(rows),'root_and_directory_modes':'not attested by the public manifest'}))
