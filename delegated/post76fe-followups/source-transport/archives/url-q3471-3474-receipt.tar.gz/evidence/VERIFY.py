#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
if not __debug__: raise SystemExit("optimized interpreter unsupported")
p=argparse.ArgumentParser();p.add_argument("--public",required=True);p.add_argument("--restricted");a=p.parse_args()
root=Path(__file__).resolve().parent;m=json.loads((root/"MANIFEST.json").read_text());actual=sorted(x.relative_to(root).as_posix() for x in root.rglob("*") if x.is_file() and x.name!="MANIFEST.json");assert actual==sorted(m["files"])
for name,row in m["files"].items():
 b=(root/name).read_bytes();assert len(b)==row["bytes"] and hashlib.sha256(b).hexdigest()==row["sha256"] and bool((root/name).stat().st_mode&0o111)==row["executable"]
x=json.loads((root/"REPLAY.json").read_text());s=json.loads((root/"PUBLIC-SCAN.json").read_text());assert x["exit"]==0 and hashlib.sha256((Path(a.public)/"MANIFEST.json").read_bytes()).hexdigest()==x["public_manifest_sha256"];assert s["candidate_hits"]==0 and all(v==0 for v in s["counts"].values())
if a.restricted: assert hashlib.sha256((Path(a.restricted)/"PRIVATE-MANIFEST.json").read_bytes()).hexdigest()==x["restricted_manifest_sha256"]
print("PASS: public receipt bindings; raw scan and source replay are separate evidence")
