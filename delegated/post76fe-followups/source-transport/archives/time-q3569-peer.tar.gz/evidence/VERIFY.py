#!/usr/bin/env python3
"""Read-only q3569 independent evidence verifier; no product execution."""
import argparse,hashlib,json,pathlib,subprocess
P=pathlib.Path(__file__).resolve().parent

def need(ok,msg):
    if not ok:raise SystemExit('FAIL: '+msg)
def tree(oid):
    b=(P/'git-trees'/(oid+'.bin')).read_bytes();need(hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid,'tree digest');out={};i=0
    while i<len(b):
        z=b.index(b'\0',i);mode,name=b[i:z].split(b' ',1);v=b[z+1:z+21];need(len(v)==20,'short tree');out[name]=(mode,v.hex());i=z+21
    need(i==len(b),'tree length');return out

def main():
    a=argparse.ArgumentParser();a.add_argument('--repo');args=a.parse_args();m=json.loads((P/'MANIFEST.json').read_text());rows={r['path']:r for r in m['files']}
    need(not any(x.is_symlink() for x in P.rglob('*')),'symlink');actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and x.relative_to(P)!=pathlib.Path('MANIFEST.json')};need(actual==set(rows),'complete inventory, including nested manifests')
    for name,row in rows.items():
        f=P/name;b=f.read_bytes();need(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'] and oct(f.stat().st_mode&0o777)==row['mode'],'member '+name)
    proofs=json.loads((P/'GIT-TREE-PROOF.json').read_text())['rows']
    for row in proofs:
        parts=row['path'].encode().split(b'/');oid=row['root_tree']
        for name in parts[:-1]:
            entries=tree(oid);need(name in entries,'directory name');mode,oid=entries[name];need(mode in (b'40000',b'040000'),'directory mode')
        entries=tree(oid);need(parts[-1] in entries,'filename');mode,blob=entries[parts[-1]];need(mode in (b'100644',b'100755') and blob==row['blob'],'source tree entry')
        b=(P/row['source_file']).read_bytes();need(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob,'source bytes')
        if args.repo:
            root=subprocess.check_output(['git','-C',args.repo,'rev-parse',row['revision']+'^{tree}'],text=True).strip();need(root==row['root_tree'],'commit/tree binding')
    delegate=json.loads((P/'delegate/MANIFEST.json').read_text())
    for row in delegate['files']:
        b=(P/'delegate'/row['path']).read_bytes();need(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'delegated reviewed member')
    need(10*((1<<16)-1)==655350,'sum bound');max_elapsed=(((1<<63)-1)*(365*24*60))//(7*24*60*60*1000000);need(max_elapsed==8015549508219 and max_elapsed+231*24*60==8015549840859,'official time arithmetic')
    print(json.dumps({'result':'pass','manifest_members':len(rows),'tree_proofs':len(proofs),'external_commit_anchor_checked':bool(args.repo),'original_queue_and_historical_receipts':'restricted peer collection required','product_execution':False}))
if __name__=='__main__':main()
