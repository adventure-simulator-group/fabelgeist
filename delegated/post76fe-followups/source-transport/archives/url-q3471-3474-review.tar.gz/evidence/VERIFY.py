#!/usr/bin/env python3
"""Replay bounded source and evidence identities; never execute product code."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

if not __debug__:
    raise SystemExit('optimized interpreter is unsupported')
p = argparse.ArgumentParser()
p.add_argument('--repository', required=True)
p.add_argument('--restricted')
a = p.parse_args()
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text())
actual = sorted(x.relative_to(root).as_posix() for x in root.rglob('*')
                if x.is_file() and x.name != 'MANIFEST.json')
assert actual == sorted(manifest['files'])
for name, item in manifest['files'].items():
    b = (root / name).read_bytes()
    assert len(b) == item['bytes']
    assert hashlib.sha256(b).hexdigest() == item['sha256']
    assert bool((root / name).stat().st_mode & 0o111) == item['executable']
report = json.loads((root / 'REPORT.json').read_text())
rev = report['baseline']['revision']
repo = a.repository

def git(*args):
    return subprocess.check_output(['git', '-C', repo, *args])

assert git('rev-parse', rev + '^{tree}').decode().strip() == report['baseline']['tree']
blobs = {}
for item in report['scope']['captures']:
    path = item['path']
    data = git('show', rev + ':' + path)
    assert hashlib.sha256(data).hexdigest() == item['sha256']
    assert git('rev-parse', rev + ':' + path).decode().strip() == item['git_blob']
    assert len(data.splitlines()) == item['actual_eof']
    blobs[path] = data
source = blobs[report['scope']['primary_path']].decode()
head = re.findall(r'pub\s+const\s+([A-Z][A-Z_0-9]*)\s*:\s*Route\s*<\s*(\d+)\s*>', source)
full = re.findall(r'pub\s+const\s+([A-Z][A-Z_0-9]*)\s*:\s*Route\s*<\s*(\d+)\s*>\s*=\s*Route::new\s*\(\s*"([^"\\]*)"\s*,?\s*\)\s*;', source, re.S)
assert len(head) == len(full) == 89
assert [h[0] for h in head] == [f[0] for f in full]
rows = json.loads((root / 'STATIC-INVENTORY.json').read_text())['rows']
assert len(rows) == len(full)
for row, (name, n, pattern) in zip(rows, full):
    tokens = re.findall(r'\{([^{}]+)\}', pattern)
    remainder = re.sub(r'\{([^{}]+)\}', '', pattern)
    assert row['name'] == name and row['declared_arity'] == int(n) == len(tokens)
    assert row['placeholders'] == tokens and not ('{' in remainder or '}' in remainder)
assert len({x[2] for x in full}) == len(full)
old_path = 'handoff/726-audit-20261030-adler/workflow-20261030/CLOSURE-QUEUE-100.json'
old = git('show', 'eb407672813424d64ec31f208193969f5a62620c:' + old_path)
recon = (Path(repo) / 'baseline-059/queue.json').read_bytes()
assert hashlib.sha256(old).hexdigest() == report['historical']['original_059_queue_sha256']
assert hashlib.sha256(recon).hexdigest() == report['historical']['reconstructed_059_queue_sha256']
x, y = json.loads(old), json.loads(recon)
for i in report['scope']['queue_indices']:
    assert x['entries'][i] == y['entries'][i]
if a.restricted:
    restricted = Path(a.restricted)
    regs = json.loads((root / 'REGISTRATIONS.json').read_text())['registrations']
    for i, reg in enumerate(regs, 1):
        assert hashlib.sha256((restricted / f'REGISTRATION-{i:03}.json').read_bytes()).hexdigest() == reg['original_restricted_sha256']
    for c in report['scope']['captures']:
        assert len(c['sha256']) == 64
print('PASS: bounded registered sources, static literal inventory, selected historical queue identities, and public manifest')
print('LIMIT: source inspection only; omitted windows, original checkpoint 3821, current reach and product validation remain open')
