# Bounded location route review

This packet records a prospective four-lens source review at the pinned
incomplete working audit baseline. It is pending central reconciliation and
makes no queue-closure or unique-defect claim. `REGISTRATIONS.json` is a
normalized public transcription; exact registrations, unshown source captures,
locator outputs, failures and the reviewer mapping are in restricted custody.

Run `python3 VERIFY.py --repository <evidence-checkout>` to replay the Git
source identities, textual declaration inventory and four selected historical
queue comparisons. Add `--restricted <restricted-directory>` to compare the
five exact original registration hashes. The checks inspect source bytes and
evidence only; no product code, test or runtime is executed. The original
role0059 source object equality and publication custody require separately
preserved evidence. This is a same-machine evidence replay, not independent
custody or the missing original checkpoint 3821.
