# Bounded location-route review: q3475–q3478

## Scope and evidence

This source-only review covers q3475 (Lens 6 type ownership), q3476 (Lens 7
redundant authority), q3477 (Lens 8 behavior preservation), and q3478 (Lens 9
enum and state shape). The reviewer is /root/verifier_scope. The pinned current
source is 95e63628f9d70b8dd6e6fede64334696c6995009, tree
1eec97de340d9b7debbb30ca0c0fb2240a73b93f. Each lens received a separate personal
display of the complete 148-line
`crates/strategic-web/src/location_urls/patterns.rs`. The four views contain the
same bytes; they are not four independent bodies.

The original 059 records identify the historical pr-working source at
6533e444fa37552927070cc8d8190907fd3b413e, and an
e2755a732c84e67296b5e3441a4259a84f461b2f revisit, each with zero own-lens body
credit and an own-lens obligation. The original working body, the three selected
Git blobs and the 95e file all have SHA-256
cbe71f461a1ace891f293e332766a0d8028bbe81d0e8b9e2051fe74763ab7b78. This is file
identity, not a claim that the historical working tree was clean or that
complete trees match. Original and reconstructed queue streams are separately
preserved; the selected elements agree. Historical status is null; the
time-bound b111 reconciliation records all four as unassessed.

Root personally read 6533 under Lens 3; the e275 Lens 3 receipt records
qualified reuse with frozen adoption pending, not a fresh e275 body read. Later,
/root/mhr_character independently reviewed role0059, including a separately
attributed q3475 Lens 6 read. The older 059 zero-credit field does not negate
that later work. Neither prior review supplies the present reviewer’s credit;
neither this packet nor any earlier source is promoted to the missing checkpoint
3821. A different reviewer’s Lens 10–13 work was not used for this assessment.

## Lens 6: type ownership

`patterns.rs:5–32,80–126` defines route-pattern values.
`location_urls.rs:12–31,52–76,159–174` distinguishes location kind, the
`Route<N>` HTTP pattern/argument-count owner, and settlement place alternatives.
The selected quest template turns a projected case-site ID into an output URL
(`templates/quest.rs:76–88`). These selected roles are distinct; the read does
not establish a misplaced or duplicate type owner. The generic displayable route
arguments do not by themselves establish the semantic type of an argument.
Deciding any future ID-to-path adapter or admission responsibility requires the
uninspected producer and consumer contract. The separately attributed role0059
Lens 6 assessment and its conditional dot-segment question remain related, not
newly proved here.

Historical q2450 records Lens 2 route/venue classification, and q3297 records
Lens 3 admission/arity work. Their recorded attributions and partially inherited
ranges remain their own. q213 and q217 are separate Lens 12 case-site
erasure/readmission operations; they do not establish an alias to this scope.

## Lens 7: repeated camp path authority

At 95e, `patterns.rs:53` declares `CAMP` as `/locations/camp`;
`routes/settlements/router.rs:221–223` registers that pattern. Separately, the
successful case-site travel branch writes the same literal in
`routes/quests.rs:360–378`. Under the `query.forage` branch,
`routes/settlements/camp.rs:419–427` passes that literal to
`routes/foraging.rs:382–388,417–425`, where it becomes the two dialog-close
hrefs. All selected strings agree at this revision. If the route owner alone
changes later, these independently written consumers could drift; this is a
conditional ownership and coordination question, not an existing mismatch or
runtime failure. Whether the selected branches occur under supported conditions
and whether additional producers share the authority remain open.

The b111 ledger’s row 865 concerns a camp planner’s active-leg/return timing;
row 271 concerns venue/place identity and relocation. They are related context
by domain only, with different first operations. No semantic-alias or uniqueness
conclusion follows from this bounded search.

## Lens 8: selected historical path change

At migration parent b97b09431a8e2d912bb159cf20a091a987e3c18f,
`routes/settlements/router.rs:342–348` registers `/camp`, the executed case-site
travel branch targets `/camp` (`routes/quests.rs:360–376`), and the selected
foraging dialog receives `/camp` (`routes/settlements/camp.rs:424–430`). Its
child d375e49ad333facf43bc71f84008a9fa4fb468fe declares `/locations/camp`
(`location_urls/patterns.rs:53`) and registers `paths::CAMP`
(`routes/settlements/router.rs:374–376`). The 95e selected redirect and dialog
argument use the new spelling. The change is visible in source configuration;
actual HTTP behavior, supported external links, user impact and whether any
difference is unintended have not been established. No compatibility mechanism
is inferred or proposed.

The assigned primary file and adjacent `location_urls.rs` have byte-identical
selected versions at 6533, e275 and 95e; that does not establish pre-refactor or
whole-program behavior equivalence. The old/new sample covers only the named
camp operations, not all changed routes, router composition, callers, feature
configurations, or clients.

## Lens 9: tag and payload shape

`templates/settlement/context.rs:12–20` stores `LocationKind` beside optional
religion, category, economy and active-building fields in one `LocationView`.
`routes/settlements/party/location_personal.rs:7–48` constructs selected
settlement and case-site views differently; `schedule_preview.rs:108–138`
supplies no settlement payload for its selected case-site view.
`context.rs:22–35,47–75` checks the tag for building validation and rendering,
while `:40–44` uses any stored active building when composing a query. The
struct shape can represent a case-site tag alongside fields that the selected
case-site producers leave empty, but these reads do not show a supported
producer of such a combination or a user-visible fault. They also do not prove
every missing settlement value is invalid; some options may be intentional.

Whether the tag should own distinct payloads depends on the uninspected
constructors, mutation paths, valid optionality and lifecycle. The b111 ledger
row 793 concerns an untagged selected-place component that may match multiple
namespaces; it is a related identity question with a different first operation,
not an automatic alias or issue count.

## Recovery and limits

The private collection contains the registered source windows, full captured
source blobs, raw Git membership objects, original and reconstructed historical
queue streams and selected records, historical read receipts, b111 queue and
ledger snapshots, and process records. Its manifest hash is bound by
`PRIVATE-BINDING.json`. The public verifier can check this packet alone, or
perform the stronger offline evidence replay with the separately retained
private collection. Git commit objects, complete queues, and private locator
paths remain restricted. A same-machine private directory, or a later encrypted
copy whose key is separately held on the same machine, is not independent
custody.

A combined rules display and an earlier metadata-only directory listing were
tool-truncated; their full emitted transcripts were not separately captured.
Complete rules and the necessary selected prior files were later captured. A
selected context view included `#[cfg(test)]` source text at lines 80–100; it
was not executed or used to infer production behavior, and its earlier scope
wording is corrected in the private packet. A later bounded metadata projection
was intentionally limited to 2,000 characters for each value; its exact emitted
transcript was not separately saved, while the original selected records were
preserved. Full stored blobs do not establish that unread complements were
inspected, and content hashes cannot independently prove a display.

This is a partial, time-bound source assessment with open policy and
reachability questions. It establishes no closure, repair, issue count, product
behavior, or absence of semantic aliases. No product, test, fixture, build,
macro, renderer, browser or runtime probe was executed.
