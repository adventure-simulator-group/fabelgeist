#!/usr/bin/env python3
"""Offline evidence integrity replay; never executes product or test code."""
import argparse,hashlib,json,pathlib,stat,sys
if sys.flags.optimize:
    raise SystemExit('optimized Python is not supported')

def sha(b):
    return hashlib.sha256(b).hexdigest()

def load(p):
    return json.loads(p.read_bytes())

def check(ok, label):
    if not ok:
        raise ValueError(label)

def checked_path(root, rel):
    q=pathlib.PurePosixPath(rel)
    check(not q.is_absolute() and '..' not in q.parts and rel not in ('', '.'), 'unsafe manifest path')
    p=root.joinpath(*q.parts)
    check(not p.is_symlink(), 'symlink in manifest')
    return p

def verify_file_manifest(root, manifest, exclude):
    rows=manifest['files']
    if isinstance(rows,dict):
        rows=[dict(v,path=k) for k,v in rows.items()]
    expected={row['path'] for row in rows}
    check(len(expected)==len(rows), 'duplicate file entry')
    actual=set()
    for p in root.rglob('*'):
        check(not p.is_symlink(), 'symlink in collection')
        if p.is_file() and p.relative_to(root).as_posix() not in exclude:
            actual.add(p.relative_to(root).as_posix())
    check(actual==expected, 'file set mismatch')
    for row in rows:
        p=checked_path(root,row['path']);b=p.read_bytes()
        check(len(b)==row['bytes'] and sha(b)==row['sha256'], 'file identity mismatch')
        if 'mode' in row:
            want=int(row['mode'],8) if isinstance(row['mode'],str) else row['mode']
            check(stat.S_IMODE(p.stat().st_mode)==want, 'file mode mismatch')
    if 'directories' in manifest:
        ds=manifest['directories'];want={r['path']:int(r['mode'],8) for r in ds}
        check(len(want)==len(ds), 'duplicate directory entry')
        got={p.relative_to(root).as_posix():stat.S_IMODE(p.stat().st_mode) for p in root.rglob('*') if p.is_dir()}
        check(want==got, 'directory mode or set mismatch')
        check(stat.S_IMODE(root.stat().st_mode)==int(manifest['root_mode'],8), 'root mode mismatch')
    return len(rows)

def tree_entries(raw):
    pos=0
    while pos<len(raw):
        s=raw.index(b' ',pos);z=raw.index(b'\0',s+1)
        check(z+21<=len(raw), 'short tree entry')
        yield raw[pos:s].decode(),raw[s+1:z].decode(),raw[z+1:z+21].hex()
        pos=z+21
    check(pos==len(raw), 'invalid tree length')

def get(objects,oid,typ):
    check(oid in objects and objects[oid][0]==typ, 'missing Git object')
    return objects[oid][1]

def root_tree(objects, commit):
    line=get(objects,commit,'commit').splitlines()[0]
    check(line.startswith(b'tree '), 'commit tree line')
    return line[5:].decode()

def walk(objects,commit,path):
    current=root_tree(objects,commit);parts=path.split('/')
    for index,name in enumerate(parts):
        found=[v for v in tree_entries(get(objects,current,'tree')) if v[1]==name]
        check(len(found)==1, 'tree member lookup')
        mode,_,oid=found[0]
        if index<len(parts)-1:
            check(mode in ('40000','040000'), 'non-tree path component')
        else:
            check(mode=='100644', 'unexpected source mode')
        current=oid
    return current

def verify_chain(objects,commit,path,chain,oid):
    current=root_tree(objects,commit);parts=path.split('/')
    check(len(parts)==len(chain), 'tree chain length')
    for part,row in zip(parts,chain):
        check(row['tree']==current and row['name']==part, 'tree chain pointer')
        found=[v for v in tree_entries(get(objects,current,'tree')) if v[1]==part]
        check(len(found)==1 and found[0][0]==row['mode'] and found[0][2]==row['object'], 'tree chain entry')
        current=row['object']
    check(current==oid and walk(objects,commit,path)==oid, 'tree leaf')

def expected_view(body,lo,hi):
    lines=body.decode().splitlines()
    check(1<=lo<=hi<=len(lines), 'source range')
    return ''.join(f'{n:4} {lines[n-1]}\n' for n in range(lo,hi+1)).encode()

def slices(raw, wanted):
    s=raw.decode();d=json.JSONDecoder();i=s.index('[',s.index('"entries"'))+1;out={}
    for n in range(max(wanted)+1):
        while s[i].isspace() or s[i]==',': i+=1
        start=i;_,i=d.raw_decode(s,i)
        if n in wanted: out[n]=s[start:i].encode()
    return out

def main():
    parser=argparse.ArgumentParser(description='Check published bytes and optional restricted source evidence.')
    parser.add_argument('--private',type=pathlib.Path,help='restored restricted collection root')
    args=parser.parse_args();public=pathlib.Path(__file__).resolve().parent
    pm=load(public/'MANIFEST.json')
    npublic=verify_file_manifest(public,pm,{'MANIFEST.json'})
    out={'public_files_checked':npublic,'private_replay':'not requested'}
    if args.private is None:
        print(json.dumps(out,sort_keys=True));return
    r=args.private.resolve();binding=load(public/'PRIVATE-BINDING.json');private_manifest_bytes=(r/'PRIVATE-MANIFEST.json').read_bytes()
    check(sha(private_manifest_bytes)==binding['private_manifest_sha256'], 'private manifest binding')
    private_manifest=json.loads(private_manifest_bytes)
    nprivate=verify_file_manifest(r,private_manifest,{'PRIVATE-MANIFEST.json'})
    check(nprivate==binding['private_files_excluding_manifest'] and len(private_manifest['directories'])==binding['private_directories'], 'private manifest counts')
    objects={};inventories=[('GIT-PROOFS.json','object_inventory','git-objects'),('SUPPORT-CAPTURE.json','object_inventory','support-git-objects'),('SUPPORT2-CAPTURE.json','object_inventory','support2-git-objects'),('HISTORIC-BEHAVIOR-CAPTURE.json','objects','behavior-git-objects'),('B111-GIT-PROOFS.json','object_inventory','b111-git-objects')]
    for file,key,store in inventories:
        for oid,meta in load(r/file)[key].items():
            b=(r/store/oid).read_bytes();typ=meta['type']
            check(len(b)==meta['bytes'] and sha(b)==meta['sha256'], 'object byte identity')
            check(hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid, 'Git object hash')
            check(oid not in objects or objects[oid]==(typ,b), 'conflicting Git objects')
            objects[oid]=(typ,b)
    source='crates/strategic-web/src/location_urls/patterns.rs';proof=load(r/'GIT-PROOFS.json')['revision_proofs']
    expected_revs={'6533':'6533e444fa37552927070cc8d8190907fd3b413e','e275':'e2755a732c84e67296b5e3441a4259a84f461b2f','95e':'95e63628f9d70b8dd6e6fede64334696c6995009'}
    bodies=[]
    for label,rev in expected_revs.items():
        row=proof[label];check(row['commit']==rev, 'primary revision')
        verify_chain(objects,rev,source,row['chain'],row['source_blob']);b=get(objects,row['source_blob'],'blob')
        check(b==(r/f'PRIMARY-{label}.rs').read_bytes() and sha(b)==row['sha256'] and len(b.splitlines())==148, 'primary source bytes')
        bodies.append(b)
    check(len(set(bodies))==1 and bodies[0]==(r/'HIST-PR-WORKING-BODY.rs').read_bytes(), 'historical working body')
    check(sha(bodies[0])=='cbe71f461a1ace891f293e332766a0d8028bbe81d0e8b9e2051fe74763ab7b78', 'primary source identity')
    for lens in (6,7,8,9):
        check((r/f'VIEW-L{lens}-PRIMARY.txt').read_bytes()==expected_view(bodies[0],1,148), 'primary lens display bytes')
    count_windows=0
    for capture,registration,prefix in [('SUPPORT-CAPTURE.json','SUPPORT-REGISTRATION.json','SUPPORT'),('SUPPORT2-CAPTURE.json','SUPPORT2-REGISTRATION.json','SUPPORT2'),('HISTORIC-BEHAVIOR-CAPTURE.json','HISTORIC-BEHAVIOR-REGISTRATION.json','BEHAVIOR')]:
        rows=load(r/capture)['rows'];reg=load(r/registration);check(len(rows)==len(reg['windows']), 'registered window count')
        for index,(row,want) in enumerate(zip(rows,reg['windows'])):
            rev=row.get('revision',reg.get('revision'));check(rev==want.get('revision',reg.get('revision')) and row['path']==want['path'], 'registered source identity')
            if 'lenses' in row:check(row['lenses']==want['lenses'], 'registered lens')
            verify_chain(objects,rev,row['path'],row['chain'],row['blob']);b=get(objects,row['blob'],'blob')
            check(b==(r/f'{prefix}-{index:02}.rs').read_bytes() and sha(b)==row['sha256'] and len(b.splitlines())==row['EOF'], 'support blob')
            check([v['range'] for v in row['views']]==want['ranges'], 'registered ranges')
            for view in row['views']:
                v=(r/view['file']).read_bytes();lo,hi=view['range']
                check(v==expected_view(b,lo,hi) and sha(v)==view['sha256'], 'registered source view')
                count_windows+=1
    owner='crates/strategic-web/src/location_urls.rs'
    for label,rev in expected_revs.items():
        b=get(objects,walk(objects,rev,owner),'blob')
        check(b==(r/f'BEHAVIOR-OWNER-{label if label!="95e" else "95e6"}.rs').read_bytes(), 'historical owner source')
        check(sha(b)=='4cdfe5103f103f2628c55f1f8d3f9dd407342458647215a44b5add07c03dcb14','historical owner hash')
    migration='d375e49ad333facf43bc71f84008a9fa4fb468fe';prior='b97b09431a8e2d912bb159cf20a091a987e3c18f'
    parents=[x[7:].decode() for x in get(objects,migration,'commit').splitlines() if x.startswith(b'parent ')]
    check(bool(parents) and parents[0]==prior, 'migration first parent')
    ids={213,217,1883,2450,3297,3475,3476,3477,3478};streams={}
    for label,expected in [('original','2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'),('reconstructed','3695264e6d4531a1137f0c3232e0d5163d941c49849cb4bddef31cd8403fd173')]:
        raw=(r/(label.upper()+'-QUEUE-FULL.json')).read_bytes();check(sha(raw)==expected, 'historical stream identity')
        selected=slices(raw,ids);streams[label]=selected
        for n,b in selected.items():
            name=(f'q{n}-{label}.json' if n>=3475 else f'RELATED-q{n}-{label}.json')
            check((r/name).read_bytes()==b, 'historical exact record slice')
    for n in ids:check(json.loads(streams['original'][n])==json.loads(streams['reconstructed'][n]), 'historical original/reconstruction selection')
    parent='b111f7444ab7e3b13b2099d5ce9d59f08faf9424';bp=load(r/'B111-GIT-PROOFS.json');check(bp['commit']==parent and bp['tree']==root_tree(objects,parent),'b111 root')
    for row in bp['rows']:
        oid=walk(objects,parent,row['path']);b=get(objects,oid,'blob')
        check(oid==row['blob'] and sha(b)==row['sha256'] and b==(r/('B111-'+row['path'])).read_bytes(),'b111 file binding')
    queue=load(r/'B111-RECONCILIATION-059.json')['entries']
    for n,lens in zip((3475,3476,3477,3478),(6,7,8,9)):
        old=json.loads(streams['original'][n]);now=queue[n]
        check(old['lens']==lens and old['body_or_population_credit']==0 and now['historical_lens']==lens and now['historical_status'] is None and now['current_reconciliation']=='unassessed', 'historical/current queue fields')
    ledger=load(r/'B111-BASELINE-95E-20261110.json')['newly_assessed_ledger']['entries'];selected=load(r/'LEDGER-SELECTED.json')
    for i,row in selected.items():check(ledger[int(i)]==row,'selected ledger row')
    for label in ('PR','E275'):
        whole=load(r/f'HIST-{label}-READ.json');row=load(r/f'HIST-{label}-READ-ROW2.json')
        check(whole['rows'][2]==row,'historical receipt selection')
    hist=load(r/'HIST-E275-READ-ROW2.json');check(hist['frozen_source_adoption_pending'] and hist['fresh_personal_ranges']==[],'historical reuse qualification')
    role=load(r/'ROLE0059-PUBLIC-MANIFEST.json')['files']
    for a,b in [('REPORT.md','ROLE0059-REPORT.md'),('ASSESSMENTS.json','ROLE0059-ASSESSMENTS.json')]:
        raw=(r/b).read_bytes();check(len(raw)==role[a]['bytes'] and sha(raw)==role[a]['sha256'],'prior role manifest binding')
    assessments=load(r/'ROLE0059-ASSESSMENTS.json');check(assessments['reviewer']=='/root/mhr_character' and any(x['queue']==3475 and x['lens']==6 for x in assessments['assessments']),'prior role attribution')
    out.update({'private_replay':'passed','private_files_checked':nprivate,'git_objects_checked':len(objects),'source_windows_checked':count_windows,'primary_lens_views_checked':4,'selected_queue_entries_checked':len(ids),'ledger_rows_checked':len(selected),'limitations':'Evidence identities and recorded views only; no product execution, runtime outcome, closure, or independent custody established.'})
    print(json.dumps(out,sort_keys=True))
if __name__=='__main__':
    main()
