from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, tarfile
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';base=Path(repo)/'recovered/original-registry-source-archive';registry=json.load(gzip.open(base/'registry.json.gz','rt'));original=registry['files'][2680]
path='crates/fabelgeist-geometry/src/length.rs';old='90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696';cur='95e63628f9d70b8dd6e6fede64334696c6995009';sha=lambda x:hashlib.sha256(x).hexdigest();rows=[];bodies=[]
for rev in [old,cur]:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 local='source/'+rev[:4]+'-length.rs';rows.append({'revision':rev,'path':path,'sha256':sha(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,len(raw.splitlines())]],'local':local});bodies.append((local,raw))
assert original['source_id']=='report-p17:'+path and rows[0]['sha256']==original['sha256'] and rows[0]['bytes']==original['bytes'] and rows[0]['eof']==original['actual_line_count']
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 hits=[x for x in t.getmembers() if x.isfile() and x.name.split('/')[-1]==original['sha256']];assert len(hits)==1;assert t.extractfile(hits[0]).read()==bodies[0][1]
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective role 2680 exact 90a/95e complete source display; each copy to be displayed separately.','source_id':original['source_id'],'original_registry_uncompressed_sha256':sha(gzip.decompress((base/'registry.json.gz').read_bytes())),'original_material_ranges':original['material_ranges'],'archive_member':hits[0].name,'versions':rows,'earlier_personal_read_qualification':'This same delegate had separately prospectively registered and displayed both 90a and 95e full length.rs 1–40 as support while working on role2679. Earlier support was not ordered role credit; it was not a pristine first exposure before this new registration. See prior frozen receipt and registration; no other agent read credit is transferred.','revision_qualification':'90a is original report-p17 source snapshot, f82 is 774 transport, 95e is pinned current; single file equality does not establish equivalence of entire snapshots.','constraints':'No repairs, builds, tests, product or fixture execution, probes, or publication edits.'}
(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for name,raw in bodies:
 p=b/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('registration_sha256',sha((b/'registration.json').read_bytes()))
