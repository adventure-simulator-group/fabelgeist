from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/fabelgeist-geometry/src/measurement.rs','crates/adventuresim-tactical-core/src/animation/measurement.rs','crates/adventuresim-tactical-core/src/animation/cadence_limit.rs','crates/adventuresim-building-generator/src/interior/navigation/portals.rs','crates/adventuresim-building-generator/src/furniture/spec.rs'];entries=[];pending=[]
for path in paths:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;local='support/'+path;entries.append({'revision':rev,'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,len(raw.splitlines())]],'local':local});pending.append((local,raw))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively registered connected source bodies; follow-up navigation and bounded actual displays do not grant ordered role credit.','earlier_exposure':'Geometry measurement.rs 1–104 was personally displayed as assigned current role2679 in immediately preceding packet, not a new pristine source. Some other files may have been independently seen in prior tasks; actual new displays and unread complements are separately recorded. Earlier other-agent read credits stay with those agents.','entries':entries};(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('sha256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
