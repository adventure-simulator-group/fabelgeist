# Role 2680: report-p17 positive length

`REPORT.json` contains the bounded assessment. Both original report-p17
`90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696` and pinned current
`95e63628f9d70b8dd6e6fede64334696c6995009` source bodies were separately
registered and displayed in full. The bodies have identical bytes; this does
not equate their snapshots or transfer reviewer credit.

The current delegate previously read both bodies as support under role 2679;
that earlier exposure is preserved explicitly, along with earlier independent
storey and navigation reads. `read-receipt.json` distinguishes those scopes
from the new role display and lists all current support displays and unread
complements. Any new-turn navigation before support registration listed only
paths, not source lines.

`historical/` contains exact 774 and 059 records; `recovered/` has the original
registry/archive, historical ledger/queue and older source-recovery catalogue.
`historical-selections-reconstructed.json` is explicitly a selection from those
full records and is not an original receipt. `git-proofs.json` and `git-objects/`
preserve raw commit/tree membership for historical, current, transport and
support sources. `prior/` retains individually hash-verified earlier reports,
receipts and manifests with their original authors and scopes.

P16 is a separate dirty a120-based snapshot and its complete patch remains
unrecovered. f82 is a historical evidence transport, not a source revision.
Checkpoint 3821 remains unrecovered and gets no promoted record or credit.
The storey-height question in this report is conditional; the source does not
establish supported plan reachability, whole-audit success or a unique new issue.

Run `python3 verify-evidence.py` to check evidence integrity offline. The root
`MANIFEST.json` covers every file except itself, including nested manifests.
No repairs, product builds, tests, runtime probes or fixture execution occurred.
