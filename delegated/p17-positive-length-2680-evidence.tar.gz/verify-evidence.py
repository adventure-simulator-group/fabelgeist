'''Verify frozen evidence only: no application, tests, fixture or runtime execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for e in hist['records']:
 raw=(b/e['local']).read_bytes();assert len(raw)==e['bytes'] and h(raw)==e['sha256'],e['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==sel['registry_uncompressed_sha256']==hist['original_registry_uncompressed_sha256'];rows=json.loads(rbytes)['files']
for i in [450,2270,2680]:assert rows[i]==sel['registry_rows'][str(i)] and rows[i]['sha256']==reg['versions'][0]['sha256']
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];q=json.loads(qbytes)['entries']
for i in [816,817]:assert q[i]==sel['queue_rows'][str(i)]
cat=load('recovered/catalog-774.json')['rows'][2680];assert cat['expected_sha256']==rows[2680]['sha256'] and cat['origin']=='git:'+reg['versions'][0]['revision']+':'+reg['versions'][0]['path']
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as tar:
 body=tar.extractfile(reg['archive_member']).read();assert body==(b/reg['versions'][0]['local']).read_bytes()==(b/reg['versions'][1]['local']).read_bytes() and h(body)==rows[2680]['sha256']
for x in rec['registrations']:
 assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
for x,display in zip(reg['versions'],rec['assigned']):
 raw=(b/x['local']).read_bytes();assert x['revision']==display['revision'] and len(raw.splitlines())==x['eof']==display['eof'] and h(raw)==x['sha256']==display['sha256'];assert display['displayed']==x['planned_display_ranges']==[[1,40]] and display['unread_complement']==[]
planned={}
for name in ['support-registration.json','storey-registration.json','height-registration.json','audit-registration.json']:
 for x in load(name)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];nums=[n for a,z in x['displayed']+x['unread_complement'] for n in range(a,z+1)];assert len(nums)==x['eof'] and set(nums)==set(range(1,x['eof']+1));assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
objs={}
for key,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved']).read_bytes());assert h(raw)==e['sha256'] and len(raw)==e['bytes'] and oid(e['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for e in proof['proofs']:
 tree=objs[e['revision']].splitlines()[0].split()[1].decode();assert tree==e['root_tree']
 for c in e['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/e['preserved']).read_bytes();assert tree==e['blob']==oid('blob',raw) and h(raw)==e['sha256']
r774=[json.loads(x) for x in (b/'historical/774/source-range-registration.jsonl').read_text().splitlines()];q774=[json.loads(x) for x in (b/'historical/774/source-qualifications-final-082.jsonl').read_text().splitlines()];ob=rows[2680]['admission03_scope_observations'][0];assert r774[35]==ob['original_record'] and q774[35]==ob['local_qualifications'][0] and r774[35]['material_ranges']==[[1,40]]
l11=load('historical/059/segovb/READ-L11-438.json');old=next(x for x in l11['sources'] if x['original_index']==2680);assert old['fresh_personal_body_reads']==[[1,40]] and h((b/'historical/059/segovb/REGISTRATION-SEGOVB-1597.json').read_bytes())==old['registration_sha256']
l12=load('historical/059/segovb/READ-L12-929.json');old=next(x for x in l12['rows'] if x['original_index']==2680);assert old['fresh_personal_body_reads']==[[1,40]] and '/root/lens12_frontier' in old['attribution'] and l12['root_personal_rereads']==[];assert h((b/'historical/059/parallel-l12-20261029/REGISTRATION-PAR-L12-744.json').read_bytes())==old['registration_sha256']
prior=load('prior/2679-MANIFEST.json');prior2554=load('prior/2554-packet-manifest.json')
for mf,mapping in [(prior,{'REPORT.json':'prior/2679-REPORT.json','read-receipt.json':'prior/2679-read-receipt.json','support-registration.json':'prior/2679-support-registration.json'}),(prior2554,{'report.json':'prior/2554-report.json','read-receipt.json':'prior/2554-read-receipt.json','support-read-receipt.json':'prior/2554-support-read-receipt.json'})]:
 for old,new in mapping.items():assert any(x['path']==old and x['sha256']==h((b/new).read_bytes()) for x in mf['files'])
assert h((b/'prior/2679-MANIFEST.json').read_bytes())=='fbce0796f5c21e5ec6c5b6985f50829986bc78d936630728ec915b6e2c220297'
assert h((b/'prior/2554-packet-manifest.json').read_bytes())=='87d563612fea067966b1fcb8349ae17a09396532a09b42fffde8471702392aea'
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and report['earlier_exposure']==rec['earlier_personal_exposure']
if (b/'MANIFEST.json').exists():
 listed=set()
 for e in load('MANIFEST.json')['files']:
  raw=(b/e['path']).read_bytes();assert len(raw)==e['bytes'] and h(raw)==e['sha256'],e['path'];listed.add(e['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: self-contained registry/source archive and 774 native record; separate 90a/95e displays after registration with earlier support exposure disclosed; exact 059 scopes and prior-packet identities; %d Git membership proofs and %d support partitions; thirteen partial perspectives. Evidence integrity only; no product execution, builds, tests, fixtures or probes.'%(len(proof['proofs']),len(rec['support'])))
