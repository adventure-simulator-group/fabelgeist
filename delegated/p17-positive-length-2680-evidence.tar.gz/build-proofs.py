from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objs={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objs:
  p=f'git-objects/{k}.{t}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objs[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind):
 raw=(b/local).read_bytes();root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw);proofs.append({'revision':rev,'path':path,'preserved':local,'kind':kind,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw)})
r=json.loads((b/'registration.json').read_bytes())
for x in r['versions']:proof(x['revision'],x['path'],x['local'],'separately personally displayed assigned source')
for n in ['support-registration.json','storey-registration.json','height-registration.json','audit-registration.json']:
 for x in json.loads((b/n).read_bytes())['entries']:proof(x['revision'],x['path'],x['local'],'bounded personal current support; see receipt for exact displayed and unread portions')
f82='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';proof(f82,'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+r['versions'][0]['sha256'],r['versions'][0]['local'],'774 object transport shared by identical source bytes; P17/P16/pr-working roles remain distinct')
for x in json.loads((b/'historical-manifest.json').read_bytes())['records']:
 if x.get('transport_revision'):proof(x['transport_revision'],x['git_path'],x['local'],'exact 774 native original record transport')
for rev in ['6533e444fa37552927070cc8d8190907fd3b413e','e2755a732c84e67296b5e3441a4259a84f461b2f']:
 proof(rev,r['versions'][0]['path'],r['versions'][0]['local'],'per-file identity only, not a new personal body display or whole-snapshot equivalence')
d={'schema':'726-role2680-raw-git-membership-v1','objects':objs,'proofs':proofs,'qualification':'90a original and 95e current pinned project commits, f82 original record transport, and other prior per-file matches are distinct roles and revisions. Read credit is only as in the separate receipt.'};(b/'git-proofs.json').write_text(json.dumps(d,indent=2)+'\n');print('proofs',len(proofs),'objects',len(objs),'sha256',h((b/'git-proofs.json').read_bytes()))
