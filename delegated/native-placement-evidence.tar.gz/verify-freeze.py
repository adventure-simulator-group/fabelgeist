import hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');m=json.loads((p/'BUNDLE-MANIFEST.json').read_text());rows={x['path']:x for x in m['files']};files={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file() and x.name!='BUNDLE-MANIFEST.json'};assert files==set(rows),(files-set(rows),set(rows)-files)
for n,e in rows.items():
 b=(p/n).read_bytes();assert (len(b),hashlib.sha256(b).hexdigest())==(e['bytes'],e['sha256']),n
print('verified files',len(rows),'manifest SHA-256',hashlib.sha256((p/'BUNDLE-MANIFEST.json').read_bytes()).hexdigest())
