import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());rec=json.loads((p/'read-receipt.json').read_text());sr=json.loads((p/'support-read-receipt.json').read_text());assert H((p/'registration.json').read_bytes())==rec['registration_sha256']
for x in sr['registrations']:assert H((p/x['file']).read_bytes())==x['sha256']
prior=json.loads((p/'prior-references.json').read_text());pr=pathlib.Path(prior['previous_packet']);manb=(p/prior['manifest_copy']).read_bytes();assert H(manb)==prior['manifest_sha256']=='098493349aa75bc5197e2156cf7186b6d3dfb54e0cedb6a67f0bd94b7bf1bd25';man=json.loads(manb);m={x['path']:x for x in man['files']}
for x in prior['references']:
 b=pathlib.Path(x['original_path']).read_bytes();assert (len(b),H(b))==(x['bytes'],x['sha256'])==(m[x['prior_manifest_path']]['bytes'],m[x['prior_manifest_path']]['sha256'])
for n in ['report.json','support-read-receipt.json','native-support-registration.json','native-support-registration-02.json']:
 b=(p/'prior-saphyr'/n).read_bytes();assert (len(b),H(b))==(m[n]['bytes'],m[n]['sha256'])
pkg=pathlib.Path(reg['package_archive_reference']['path']).read_bytes();assert H(pkg)==reg['package_archive_reference']['sha256']=='3afb591f9cdb6223c88ba39269aff895620c7f0716dc42b705b5733d5c7c0823';native=reg['native'];nb=(p/native['archive']).read_bytes()
with tarfile.open(fileobj=io.BytesIO(pkg),mode='r:gz') as t:assert t.extractfile(native['package_member']).read()==nb
assert (len(nb),len(nb.splitlines()),H(nb))==(native['bytes'],native['lines'],native['sha256']);lock=(pr/'source/current-Cargo.lock').read_bytes();match=[x for x in tomllib.loads(lock.decode())['package'] if x.get('name')=='serde-saphyr' and x.get('version')=='1.2.0'];assert len(match)==1 and match[0]['checksum']==H(pkg)
physical=reg['physical'];pb=(p/physical['archive']).read_bytes();assert (len(pb),len(pb.splitlines()),H(pb))==(physical['bytes'],physical['lines'],physical['sha256'])
lookup={};support=[x for n in ['support-registration.json','support-registration-02.json'] for x in json.loads((p/n).read_text())['sources']]
for x in reg['project']+support:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1']);lookup[x['revision'],x['path']]=x
 if 'name' in x:assert x['same_as_original_p16']==(b==pb)==True
def check(r,n):
 rr=r['actual_display_union'];u=r['unread_ranges'];assert all(1<=a<=b<=n for a,b in rr+u);read={i for a,b in rr for i in range(a,b+1)};unread={i for a,b in u for i in range(a,b+1)};assert not read&unread and read|unread==set(range(1,n+1));assert r['full_body_displayed']==(not unread);chunks={i for a,b in r['actual_display_chunks'] for i in range(a,b+1)};assert chunks==read
displays={}
for x in rec['reads']:
 if x['kind']=='native-package':y=native;key=('native-package','src/de/with_deserializer.rs')
 elif x['kind']=='historical-physical-p16':y=physical;key=('historical-physical-p16','crates/adventuresim-weapon-model/src/model/placement.rs')
 else:y=lookup[x['revision'],x['path']];key=('current-project',x['revision'],x['path'])
 check(x,y['lines']);displays[key]=x['actual_display_union']
for x in sr['reads']:
 y=lookup[x['revision'],x['path']];check(x,y['lines']);displays['current-project',x['revision'],x['path']]=x['actual_display_union']
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
def verify_proofs(root,proof,only=None):
 objects={}
 for oid,x in proof['objects'].items():
  b=gzip.decompress((root/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
 n=0
 for x in proof['proofs']:
  if only and not only(x):continue
  tree=objects[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
  for e in x['chain']:
   assert e['tree']==tree and entries(objects[tree])[e['name']]==(e['mode'],e['object']);tree=e['object']
  b=(root/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert tree==x['blob']==O('blob',b) and H(b)==x['sha256'];n+=1
 return n,len(objects)
proof=json.loads((p/'git-proofs.json').read_text());nproof,nobjects=verify_proofs(p,proof);previous=json.loads((pr/'git-proofs.json').read_text());nprior,_=verify_proofs(pr,previous,lambda x:x['kind']=='current-lock' and x['revision']==reg['current_revision'] and x['path']=='Cargo.lock');assert nprior==1
report=json.loads((p/'report.json').read_text());refs=0
for a in report['assessments']:
 for x in a['source_refs']:
  key=(x['source_kind'],x['path']) if x['source_kind'] in ['native-package','historical-physical-p16'] else (x['source_kind'],x['revision'],x['path']);rr=displays[key]
  for start,end in x['lines']:assert any(c<=start<=end<=d for c,d in rr),(key,start,end,rr);refs+=1
with gzip.open(pr/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((pr/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
r=json.load(gzip.open(pr/'reference/original-registry.json.gz','rt'))
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']:assert x['entry']==r['files'][x['index']]
assert native['original_registry_entry']==r['files'][2577] and physical['original_registry_entry']==r['files'][2578];assert r['files'][2115]['sha256']==physical['sha256'];assert physical['registry_snapshot_field']=='pinned-native-dependency' and physical['source_id'].startswith('physical-p16:')
old774=json.loads((p/'historical-774-index.json').read_text())
for x in old774['records']:
 b=gzip.decompress((p/x['copy']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
hq=old774['hash_qualifications'];assert H((p/'historical-774/camera-registration-observed-first7.jsonl').read_bytes())==hq['camera_later_registration_first7_sha256']!=hq['camera_046_prior_registration_sha256'];oldroot=json.loads(gzip.decompress((p/'historical-774/root/admission03-scope-reconciliation-046.json.gz').read_bytes()));assert next(x['sha256'] for x in oldroot['input_pins'] if x['supplier']=='camera')==hq['camera_046_prior_registration_sha256']
l11a=json.loads((p/'historical-059/segovb/READ-L11-423.json').read_text());l11b=json.loads((p/'historical-059/segovb/READ-L11-424.json').read_text());l12a=json.loads((p/'historical-059/segovb/READ-L12-874.json').read_text());l12b=json.loads((p/'historical-059/segovb/READ-L12-875.json').read_text());assert not l12a['root_personal_rereads'] and not l12b['root_personal_rereads']
x=next(z for z in l11a['sources'] if z.get('original_index')==2577);assert x['fresh_personal_body_reads']==[[120,147]] and H((p/'historical-059/segovb/REGISTRATION-SEGOVB-1486.json').read_bytes())==x['registration_sha256'];x=next(z for z in l11b['sources'] if z.get('original_index')==2578);assert x['fresh_personal_body_reads']==[] and H((p/'historical-059/segovb/REGISTRATION-SEGOVB-1489.json').read_bytes())==x['registration_sha256'];priorr=x['same_lens_prior'];assert H((p/'historical-059/adler/READ-L11-330.json').read_bytes())==priorr['receipt_sha256'] and H((p/'historical-059/adler/REGISTRATION-ADLER-964.json').read_bytes())==priorr['entry']['registration_sha256'] and priorr['entry']['fresh_reads']==[[1,156]]
for d,i,rr in [(l12a,2577,[[120,160]]),(l12b,2578,[[26,156]])]:
 x=next(z for z in d['rows'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==rr and H((p/'historical-059'/x['registration']).read_bytes())==x['registration_sha256'] and H((p/'historical-059'/x['identity_specific_windows_qualification']['path']).read_bytes())==x['identity_specific_windows_qualification']['sha256']
x=json.loads((p/'historical-059/parallel-l12-20261029/PARTIAL-CONNECTED-PAR-L12-875-WEAPON-001.json').read_text())['rows'][0];assert x['original_index']==2578 and x['fresh_personal_body_reads']==[[1,25]] and H((p/'historical-059'/x['registration']).read_bytes())==x['registration_sha256']
for x in json.loads((p/'later-hair-ops-reference.json').read_text())['files']:
 b=(p/'later-hair-ops'/x['name']).read_bytes();assert (len(b),H(b))==(x['bytes'],x['sha256'])
hair=json.loads((p/'later-hair-ops/p16-live-comparison.json').read_text());assert hair['recomputed_patch_sha256']==hair['recorded_patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and hair['patch_hash_exact_match'] and hair['patch_saved']==False and hair['head']==reg['dirty_p16_base'];assert len(report['perspectives'])==13
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','linked_native_archive_sha256':H(pkg),'linked_prior_manifest_sha256':prior['manifest_sha256'],'linked_prior_current_lock_proof':nprior,'own_git_path_proofs':nproof,'own_raw_git_objects':nobjects,'current_support_objects':len(support),'source_reference_ranges_within_personal_displays':refs,'original_059_exact_records':len(hist['records']),'older_774_exact_transport_records':len(old774['records']),'camera_046_registration_prefix_matches':False,'qualification':'Linked prior packet must remain available to recover package and registry/manifest objects. Evidence verification only, no product execution; bounded earlier camera registry pin remains unmatched.'};print(json.dumps(result,indent=2))
