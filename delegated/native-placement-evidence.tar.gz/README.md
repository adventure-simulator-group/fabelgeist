# Bounded YAML scope and weapon placement assessment

`report.json` records original roles 2577–2578, exact 95e source links,
conditional findings, historical relationships and thirteen scoped perspectives.
The native serde-saphyr archive, 95e Cargo.lock, original registry, queue and
transport manifest are **hash-linked to the previously frozen**
`<LOCAL_PATH_0> packet rather than duplicated. Both packets
must be retained or mapped together when publishing or restoring evidence.
The prior manifest copy and exact dependency hashes are in
`prior-references.json`; this packet contains the assigned native source bytes.

The physical-P16 placement source object is byte-equal to the same single
file at a120, 6533 and 95e, proven with Git paths. Its original registry
snapshot field says `pinned-native-dependency`, while its source ID, P16 path
and camera registration identify a physical dirty-snapshot source. f82 is its
transport, and per-file equality proves neither complete snapshot clean.

The present alias pose observation is conditional and relates to the existing
059 attachment-frame question; complete admitted input, intended alias policy,
and downstream behavior remain open. The earlier camera witness and identity
finding retain their original reviewer and revision. The 774 root046 camera
registration pin does not match the recovered later first seven rows; the
bounded search and independent 046/witness records preserve that qualification.
The later hair-ops tracked P16 patch reproduction is separately attributed and
covers neither original invocation proof nor the seven untracked files.

Run `python3 check-evidence.py` and `python3 verify-freeze.py` to verify source,
records, Git proofs and packet inventory. The first check requires the linked
prior packet. Both are evidence-only: no product, parser, fixture, build, test,
rendering, runtime probe or repair is performed.
