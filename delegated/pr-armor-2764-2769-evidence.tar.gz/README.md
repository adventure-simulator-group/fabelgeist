# Bounded source evidence: original roles 2764–2769

`REPORT.json` states this packet's scoped observations, thirteen partial lens
perspectives, conditions and open questions. `registration.json` and the
support and navigation registrations precede the actual displays reconstructed
in `read-receipt.json`. Stored source and navigation output bytes are not by
themselves evidence of a personal read. The receipt separates old material,
additional support and unread ranges, including unprinted navigation results.

`recovered/` retains the exact recovered registry and source archive, the
separately labelled reconstructed 774 catalog, and the original 059 queue and
ledger. `historical/` contains exact original receipts and the old 774 supplier
records. `prior/` contains independent assessments, including a previous
reviewer's report and its separate manifest. The new
`historical-selections-reconstructed.json` is a reconstruction, not an original
record. The per-file raw Git commit/tree proof package binds historical,
current and support source bytes without making the dirty historical snapshot
clean or treating the f82 evidence transport as a project revision.

Run `python3 verify-evidence.py` for offline evidence integrity only. It never
executes the product, fixtures, generators, macros, builds or tests. The top
level manifest includes nested manifests. `workspace-output-incident.json`
discloses the temporary workspace-root output redirection, retained bytes,
notification and uncertainty about any previous contents. No checkpoint 3821
or whole-lens completion is asserted.
