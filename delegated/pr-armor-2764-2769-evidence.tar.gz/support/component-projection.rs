//! Sample MHR identity and refit clothing with fixed vertex correspondence.

use super::*;
use adventuresim_character_creator::clothing::ClothingShell;
use adventuresim_core::character_morph::{IDENTITY_MORPH_STEP, IdentityMorph};
use adventuresim_core::skeletal_fit::SkeletalFitMorph;
use fabelgeist_mhr::character::{MeshVertexIndex, MeshVertexTable};

mod draped;
mod hair;

pub(super) struct MorphDelta {
    name: String,
    positions: Vec<[f32; 3]>,
    normals: Vec<[f32; 3]>,
}

pub(super) struct CharacterMorphs {
    pub samples: Vec<ForearmMorphSample>,
    pub body: Vec<MorphDelta>,
    reference_joints: fabelgeist_rig::RigJointTable<[f32; 8]>,
    joint_indices: fabelgeist_rig::PackedRigSkin<8>,
    joint_weights: MeshVertexTable<[f32; 8]>,
}

/// A piece's shells: its plates, and the bands along their edges.
pub(super) struct RiggedArmor<'a> {
    pub plate: Vec<RiggedShell<'a>>,
    pub trim: Vec<RiggedShell<'a>>,
}

impl MorphDelta {
    fn between(
        name: String,
        base_positions: &[[f32; 3]],
        base_normals: &[[f32; 3]],
        positions: &[[f32; 3]],
        normals: &[[f32; 3]],
    ) -> Result<Self> {
        anyhow::ensure!(
            base_positions.len() == positions.len() && base_normals.len() == normals.len(),
            "morph sample changed vertex correspondence"
        );
        let subtract = |base: &[[f32; 3]], sample: &[[f32; 3]]| {
            base.iter()
                .zip(sample)
                .map(|(base, sample)| std::array::from_fn(|axis| sample[axis] - base[axis]))
                .collect()
        };
        Ok(Self {
            name,
            positions: subtract(base_positions, positions),
            normals: subtract(base_normals, normals),
        })
    }

    pub(super) fn rigged(&self) -> RiggedMorphTarget<'_> {
        RiggedMorphTarget {
            name: &self.name,
            position_deltas: &self.positions,
            normal_deltas: &self.normals,
        }
    }
}

impl CharacterMorphs {
    pub(super) fn generate(
        model: &BodyModel,
        recipe: &CharacterRecipe,
        base: &GeneratedCharacter,
    ) -> Result<Self> {
        let mut samples = Vec::new();
        let mut body = Vec::new();
        for target in IdentityMorph::all() {
            let mut sample_recipe = recipe.clone();
            sample_recipe.identity[target.index()] += IDENTITY_MORPH_STEP;
            let sample = generate_character(model, &sample_recipe)?;
            body.push(MorphDelta::between(
                target.name(),
                &base.positions,
                &base.normals,
                &sample.positions,
                &sample.normals,
            )?);
            samples.push(ForearmMorphSample {
                name: target.name(),
                positions: sample.positions,
                normals: sample.normals,
                global_joint_states: sample.global_joint_states,
                device: Default::default(),
            });
        }
        for target in SkeletalFitMorph::ALL {
            let mut sample_recipe = recipe.clone();
            sample_recipe
                .proportions
                .set(target.proportion(), target.endpoint())
                .map_err(anyhow::Error::msg)?;
            let sample = generate_character(model, &sample_recipe)?;
            body.push(MorphDelta {
                name: target.name().into(),
                positions: vec![[0.0; 3]; base.positions.len()],
                normals: vec![[0.0; 3]; base.normals.len()],
            });
            samples.push(ForearmMorphSample {
                name: target.name().into(),
                positions: sample.positions,
                normals: sample.normals,
                global_joint_states: sample.global_joint_states,
                device: Default::default(),
            });
        }
        Ok(Self {
            samples,
            body,
            reference_joints: base.global_joint_states.clone(),
            joint_indices: model.mhr.character.skin_weights.indices().clone(),
            joint_weights: model.mhr.character.skin_weights.weights().clone(),
        })
    }

    pub(super) fn clothing(&self, shells: &[ClothingShell]) -> Result<Vec<Vec<MorphDelta>>> {
        shells
            .iter()
            .map(|base| {
                self.samples
                    .iter()
                    .map(|sample| {
                        let fitted = base
                            .refit(&sample.positions, &sample.normals)
                            .map_err(anyhow::Error::from)?;
                        let mut delta = MorphDelta::between(
                            sample.name.clone(),
                            &base.positions,
                            &base.normals,
                            &fitted.positions,
                            &fitted.normals,
                        )?;
                        remove_skeletal_translation(
                            &mut delta.positions,
                            sample,
                            &self.reference_joints,
                            &self.joint_indices,
                            self.joint_weights
                                .indexed()
                                .map(|(vertex, weights)| (vertex, *weights)),
                        );
                        Ok(delta)
                    })
                    .collect()
            })
            .collect()
    }
}

pub(super) fn correct_armor_fit(
    mut armor: GeneratedArmor,
    reference: &GeneratedCharacter,
    samples: &[ForearmMorphSample],
) -> GeneratedArmor {
    for target in &mut armor.morphs {
        if let Some(sample) = samples.iter().find(|sample| sample.name == target.name) {
            remove_skeletal_translation(
                &mut target.position_deltas,
                sample,
                &reference.global_joint_states,
                &armor.joint_indices,
                armor
                    .joint_weights
                    .iter()
                    .enumerate()
                    .map(|(vertex, weights)| {
                        (MeshVertexIndex::from_native_vertex_index(vertex), *weights)
                    }),
            );
        }
    }
    armor
}

pub(super) fn armor_targets(armor: &GeneratedArmor) -> Vec<RiggedMorphTarget<'_>> {
    armor
        .morphs
        .iter()
        .map(|target| RiggedMorphTarget {
            name: &target.name,
            position_deltas: &target.position_deltas,
            normal_deltas: &target.normal_deltas,
        })
        .collect()
}

/// Hardware has its own surface, regardless of the catalog's plate material.
pub(super) fn component_materials(
    armor: &GeneratedArmor,
    shells: &mut [RiggedShell<'_>],
) -> Result<()> {
    for (component, shell) in armor.components.iter().zip(shells) {
        if let Some(material) = component.material {
            shell.base_color = material.base_color;
            shell.metallic = material.metallic;
            shell.roughness = material.roughness;
            shell.textures = None;
            shell.surface = None;
            shell.plate_edges = &[];
        }
        if let Some(textile) = &component.textile {
            shell.textile_finish = Some(textile.finish);
            shell.textures =
                adventuresim_character_creator::textile_surface::textures(textile)?.map(Into::into);
        }
    }
    Ok(())
}

pub(super) fn rigged_clothing<'a>(
    shell: &'a ClothingShell,
    targets: &'a [RiggedMorphTarget<'a>],
) -> RiggedShell<'a> {
    let specification = &shell.specification;
    RiggedShell {
        textile_finish: None,
        surface: None,
        plate_edges: &[],
        textures: None,
        texcoords: None,
        hinge: None,
        name: specification.name.as_ref(),
        positions: &shell.positions,
        normals: &shell.normals,
        faces: &shell.faces,
        joint_indices: None,
        joint_weights: None,
        morph_targets: targets,
        base_color: specification.base_color,
        metallic: specification.metallic,
        roughness: specification.roughness,
    }
}

/// The shells of a piece, one per component, or `name` for the whole piece
/// and `trim_name` for its band.
pub(super) fn rigged_armor<'a>(
    name: &'a str,
    trim_name: &'a str,
    armor: &'a GeneratedArmor,
    faces: &'a [[u32; 3]],
    targets: &'a [RiggedMorphTarget<'a>],
) -> RiggedArmor<'a> {
    let shell = |name, faces, hinge| RiggedShell {
        textile_finish: None,
        plate_edges: &[],
        surface: None,
        textures: None,
        texcoords: Some(&armor.texcoords),
        name,
        hinge,
        positions: &armor.positions,
        normals: &armor.normals,
        faces,
        joint_indices: Some(&armor.joint_indices),
        joint_weights: Some(&armor.joint_weights),
        morph_targets: targets,
        base_color: [0.769, 0.776, 0.776, 1.0],
        metallic: 1.0,
        roughness: 0.20,
    };
    let triangles = |range: std::ops::Range<usize>| &faces[range.start / 3..range.end / 3];
    let mut rigged = RiggedArmor {
        plate: Vec::new(),
        trim: Vec::new(),
    };
    for surface in armor.surfaces() {
        let component = surface.component.map(|index| &armor.components[index]);
        let hinge = component.and_then(|component| component.hinge);
        rigged.plate.push(shell(
            component.map_or(name, |component| component.role.name()),
            triangles(surface.plate),
            hinge,
        ));
        if !surface.trim.is_empty() {
            rigged.trim.push(shell(
                component.map_or(trim_name, |component| component.role.trim_name()),
                triangles(surface.trim),
                hinge,
            ));
        }
    }
    rigged
}

/// Fit targets contain only the displacement not already produced by the bones.
fn remove_skeletal_translation(
    deltas: &mut [[f32; 3]],
    sample: &ForearmMorphSample,
    reference: &fabelgeist_rig::RigJointTable<[f32; 8]>,
    indices: &fabelgeist_rig::PackedRigSkin<8>,
    weights: impl IntoIterator<Item = (MeshVertexIndex, [f32; 8])>,
) {
    if SkeletalFitMorph::from_name(&sample.name).is_none() {
        return;
    }
    for (delta, (vertex, weights)) in deltas.iter_mut().zip(weights) {
        let skin = indices
            .weighted_vertex(vertex.native_vertex_index(), weights)
            .strongest_four();
        for (joint, weight) in skin.joints.into_iter().zip(skin.weights) {
            if weight == 0.0 {
                continue;
            }
            for (axis, value) in delta.iter_mut().enumerate() {
                *value -=
                    weight * (sample.global_joint_states[joint][axis] - reference[joint][axis]);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn skeletal_fit_corrects_surface_without_counting_bone_translation_twice() {
        let sample = ForearmMorphSample {
            name: SkeletalFitMorph::LongSpine.name().into(),
            positions: vec![],
            normals: vec![],
            global_joint_states: vec![[0.0, 0.1, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0]].into(),
            device: Default::default(),
        };
        let mut deltas = [[0.0, 0.12, 0.0]];
        remove_skeletal_translation(
            &mut deltas,
            &sample,
            &vec![[0.0; 8]].into(),
            &fabelgeist_rig::PackedRigSkin::from_native(
                vec![[0; 8]],
                sample.global_joint_states.joint_count(),
            )
            .unwrap(),
            [(
                MeshVertexIndex::from_native_vertex_index(0),
                [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            )],
        );
        assert!((deltas[0][1] - 0.02).abs() < 1e-6);
        assert!((deltas[0][1] + 0.1 - 0.12).abs() < 1e-6);
    }

    #[test]
    fn flexible_fit_reconstructs_the_direct_endpoint_with_exported_influences() {
        let indices = [0, 1, 2, 3, 4, 5, 6, 7];
        let weights = [0.04, 0.21, 0.12, 0.06, 0.27, 0.14, 0.10, 0.06];
        let reference: fabelgeist_rig::RigJointTable<_> =
            (0..8).map(|joint| [joint as f32 * 0.02; 8]).collect();
        let states: fabelgeist_rig::RigJointTable<_> = reference
            .iter()
            .enumerate()
            .map(|(joint, state)| {
                let mut state = *state;
                state[0] += joint as f32 * 0.03;
                state[1] -= (joint as f32 * 0.7).sin() * 0.05;
                state
            })
            .collect();
        let direct = [0.07, -0.12, 0.02];
        let mut residual = [direct];
        let sample = ForearmMorphSample {
            name: SkeletalFitMorph::ShortLowerLeg.name().into(),
            positions: vec![],
            normals: vec![],
            global_joint_states: states.clone(),
            device: Default::default(),
        };
        remove_skeletal_translation(
            &mut residual,
            &sample,
            &reference,
            &fabelgeist_rig::PackedRigSkin::from_native(vec![indices], reference.joint_count())
                .unwrap(),
            [(MeshVertexIndex::from_native_vertex_index(0), weights)],
        );
        let exported = fabelgeist_rig::RigInfluences {
            joints: indices.map(fabelgeist_rig::RigJointOrdinal::from),
            weights,
        }
        .strongest_four();
        let exported_indices = exported.joints;
        let exported_weights = exported.weights;
        for axis in 0..3 {
            let runtime = residual[0][axis]
                + exported_indices
                    .iter()
                    .zip(exported_weights)
                    .map(|(joint, weight)| {
                        weight * (states[*joint][axis] - reference[*joint][axis])
                    })
                    .sum::<f32>();
            assert!((runtime - direct[axis]).abs() < 1e-6);
        }
    }
}
