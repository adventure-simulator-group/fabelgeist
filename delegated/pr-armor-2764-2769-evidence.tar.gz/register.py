from pathlib import Path
from datetime import datetime, timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent
repo=Path('<LOCAL_PATH_0>')
base=repo/'recovered/original-registry-source-archive'
h=lambda x:hashlib.sha256(x).hexdigest()
r=json.load(gzip.open(base/'registry.json.gz','rt'))
rows=[];pending=[]
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 for index in range(2764,2770):
  x=r['files'][index];p=x['source_id'].split(':',1)[1];old=t.extractfile(x['sha256']).read()
  assert h(old)==x['sha256'] and len(old)==x['bytes'] and len(old.splitlines())==x['actual_line_count']
  local=f'source/{index}-pr-working.rs';pending.append((local,old))
  extras={2765:[[1,10],[29,100]],2766:[[143,177]]}.get(index,[])
  versions=[{'identity':'exact archived original pr-working object','revision_qualification':'6533-based snapshot with unrelated dirty paths; f82 transports evidence, not project head','sha256':h(old),'bytes':len(old),'eof':len(old.splitlines()),'local':local,'original_material_planned':x['material_ranges'],'extra_support_planned':extras}]
  comparison=[]
  for rev in ['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']:
   obj=subprocess.run(['git','-C',str(repo),'show',rev+':'+p],capture_output=True)
   if obj.returncode:
    d={'revision':rev,'path_absent':True,'stderr':obj.stderr.decode(errors='replace'),'display_planned':False}
    (versions if rev.startswith('95e') else comparison).append(d);continue
   raw=obj.stdout;blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+p],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
   n=f'source/{index}-{rev[:4]}.rs';pending.append((n,raw))
   d={'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':n,'equals_archived_file':raw==old}
   if rev.startswith('95e'):
    d['current_material_planned']=x['material_ranges'] if raw==old else [[1,len(raw.splitlines())]];d['extra_support_planned']=extras if raw==old else []
    versions.append(d)
   else:d['display_planned']=False;comparison.append(d)
  rows.append({'original_index':index,'source_id':x['source_id'],'path':p,'original_material_ranges':x['material_ranges'],'historical_scope_limits':x['scope_limits'],'versions':versions,'comparison_git_paths':comparison})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospective assigned original old and independently current material displays; separately planned support for excluded old/current context. 6533 objects identity-only. Each displayed chunk recorded after actual display; no credit from registration or byte equality.','original_registry_uncompressed_sha256':h(gzip.decompress((base/'registry.json.gz').read_bytes())),'snapshot_qualification':'pr-working is 6533-based with unrelated dirty files; per-file equality does not make it a clean tree. f82 transports original source archive, not project revision.','prior_current_traces':[{'role':2766,'assessment':'ASSESSMENT-L1-ARMOR-EVIDENCE.json','recorded_revision':'c100638b720a7281a5fc96f6a3c5c23d5dda85da','ranges':[[60,112],[155,176]],'qualification':'Prior published assessment records those ranges, 95e blob identical. Its author not named in assessment, no new ordered historical credit.'},{'role':2766,'assessment':'ASSESSMENT-L01-PROTECTIVE-CONTACT-95E.json','recorded_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','ranges':[[14,27],[67,112],[144,177]],'qualification':'Later published trace separately records personal selected 95e-identical c100 displays; attribution not named there, no ordered historical credit.'}],'rows':rows,'limits':'Static source/evidence only. No product, fixture, code-generation, macro or test execution, builds, probes, repairs or publication edits.'}
(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 q=b/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
print(json.dumps(d,indent=2));print('REGISTRATION_SHA256',h((b/'registration.json').read_bytes()))
