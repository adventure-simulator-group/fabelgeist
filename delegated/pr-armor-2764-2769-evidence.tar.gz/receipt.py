from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent; h=lambda x:hashlib.sha256(x).hexdigest(); load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');supports=load('support-registration.json')
nav_windows={'navigation-textile.txt':60,'navigation-coverage.txt':None,'navigation-mount.txt':None,'navigation-codes.txt':80,'navigation-schema.txt':None,'navigation-row-coverage.txt':None,'navigation-components.txt':80,'navigation-mount-global.txt':None,'navigation-grid.txt':None}
nav={};navigation=[]
for name,n in nav_windows.items():
 lines=(b/name).read_text().splitlines();n=min(n,len(lines)) if n is not None else len(lines);used=lines[:n]
 for line in used:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):',line)
  if m:nav.setdefault(m.group(1),set()).add(int(m.group(2)))
  else:raise ValueError((name,line))
 navigation.append({'output':name,'sha256':h((b/name).read_bytes()),'saved_output_lines':len(lines),'personally_displayed_output_lines':[[1,n]] if n else [],'unread_saved_output_lines':[[n+1,len(lines)]] if n<len(lines) else [],'ordered_role_credit':0})
def complement(n,used):
 used=set(used);out=[];a=None
 for i in range(1,n+2):
  if i<=n and i not in used and a is None:a=i
  if a is not None and (i==n+1 or i in used):out.append([a,i-1]);a=None
 return out
def nums(rr):return {i for a,z in rr for i in range(a,z+1)}
chunks={2764:{'old':[[1,90],[91,171]],'current':[[1,90],[91,171]]},2765:{'old':[[1,100]],'current':[[1,126]]},2766:{'old':[[1,90],[91,177]],'current':[[1,90],[91,177]]},2767:{'old':[[1,87]],'current':[[1,128]]},2768:{'old':[[1,16]],'current':[[1,16]]},2769:{'old':[[1,58]],'current':[[1,58]]}}
assigned=[]
for row in reg['rows']:
 i=row['original_index']
 for j,v in enumerate(row['versions']):
  key='old' if j==0 else 'current';display=chunks[i][key];body=nums(display);navonly=sorted(nav.get(row['path'],set())-body) if j else []
  material=row['original_material_ranges'] if j==0 else v['current_material_planned']
  extra=v.get('extra_support_planned',[])
  assigned.append({'original_index':i,'source_id':row['source_id'],'identity':v.get('identity','pinned current 95e source'),'revision':None if j==0 else v['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':display,'material_read_ranges':material,'separate_support_read_ranges':extra,'current_navigation_only_lines':navonly,'unread_complement':complement(v['eof'],body|set(navonly)),'qualification':'Old 6533 comparison bytes not separately displayed. Old excluded ranges are support only. Current changed body is current source scope, not credit for historical role. No attribution transfer.'})
body={'textile':[[1,22]],'textile-pattern':[[1,80],[175,245]],'textile-materials':[[1,105]],'textile-relief':[[1,100]],'component-projection':[[175,215]],'component-preview':[[75,125]],'coverage-schema':[[75,120]],'coverage-surface':[[1,47]],'coverage-validation':[[1,80],[81,145]],'coverage-profile':[[660,710]],'coverage-melee':[[310,365]],'coverage-contact':[[110,145]],'coverage-model':[[180,225],[325,363]],'helmet-packing':[[30,90]]}
support=[]
for x in supports['entries']:
 ranges=body[x['name']];n=nums(ranges);navonly=sorted(nav.get(x['path'],set())-n)
 support.append({'path':x['path'],'revision':x['revision'],'sha256':x['sha256'],'local':x['local'],'eof':x['eof'],'full_line_body_displays':ranges,'navigation_only_lines':navonly,'unread_complement':complement(x['eof'],n|set(navonly)),'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Reconstructed truthful actual line displays and navigation matches, after prospective registrations; archive bytes, comparison blobs and unprinted output lines are not personal reads.','registrations':[{'path':p,'sha256':h((b/p).read_bytes()),'created_utc':load(p)['created_utc']} for p in ['registration.json','navigation-registration.json','navigation-registration-2.json','navigation-registration-3.json','support-registration.json']],'assigned':assigned,'support':support,'navigation_output_receipts':navigation,'navigation_actual_source_lines':{p:sorted(v) for p,v in sorted(nav.items())},'limits':'Static source/evidence only; no code generation, macros, product, fixture, tests, builds, probes, repairs or publication edits.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
