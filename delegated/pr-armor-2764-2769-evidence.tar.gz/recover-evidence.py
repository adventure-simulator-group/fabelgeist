from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
orig=Path('<LOCAL_PATH_1>')
prev=Path('<LOCAL_PATH_2>')
workspace=Path('<LOCAL_PATH_3>')
h=lambda raw:hashlib.sha256(raw).hexdigest();records=[]
def save(raw,local,origin,kind,**extra):
 p=b/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':str(local),'sha256':h(raw),'bytes':len(raw),'kind':kind,**extra})
def copy(src,local,kind):save(Path(src).read_bytes(),local,src,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz']:
 copy(prev/n,'recovered/'+n,'Exact original registry/archive/059 queue and ledger, or explicitly reconstructed 774 catalog; inspect each origin.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/fabelgeist-armor/AGENTS.md','crates/adventuresim-core/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Current applicable rules; user source-only restrictions override validation and implementation workflows.')
for n in ['ASSESSMENT-L1-ARMOR-EVIDENCE.json','ASSESSMENT-L01-PROTECTIVE-CONTACT-95E.json','ASSESSMENT-EQUIPMENT-MESH-RIG-95E.json','ASSESSMENT-INSPECTION-REPORT-BOUNDARIES-95E.json','RECOVERY-PHYSICAL-P16-PATCH-20261111.json']:
 copy(pub/n,'prior/'+n,'Prior published current source assessment; preserve its stated revision, reader and scope; no fresh-read transfer.')
for n in ['REPORT.json','MANIFEST.json']:
 copy(Path('<LOCAL_PATH_4>')/n,'prior/rig-identity-catalog-'+n,'Related prior bounded P16/current packet by /root/rig_identity; exact author and scopes retained, no personal read transfer.')
for n in ['segovb/READ-L11-452.json','segovb/READ-L11-498.json','segovb/READ-L11-580.json','segovb/REGISTRATION-SEGOVB-1894.json','segovb/PLAN-L11-SHARED-498.json','evidence/shared-material-successor/source-extensions-196.json','parallel-l11-20261029/READ-044.json','parallel-l11-20261029/VERIFY-044.json','segovb/VALIDATE-INHERITED-044-ROOT-005-POSTINSPECTION.json']+[f'segovb/REGISTRATION-SEGOVB-{i}.json' for i in range(1684,1690)]:
 copy(orig/n,'historical/059/'+n,'Exact original historical registration, read, plan, or qualified adoption; retain each stated reader and revision.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
paths=[]
for owner,folder,names in [('rig','initial06-type-ownership',['source-range-registration.jsonl','additional-sources.jsonl','coverage.jsonl','contracts-015.json','contracts-019.json']),('camera','initial07-redundant-authority',['source-range-registration.jsonl','additional-sources.jsonl','contracts.jsonl'])]:
 for n in names:
  gp=f'handoff/774/adler-original/audit/continuation/{owner}/{folder}/{n}';raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{owner}-{n}','git:'+rev+':'+gp,'Exact original 774 record through evidence-transport Git; f82 is not source HEAD.',transport_revision=rev,git_path=gp)
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw)
selection={'kind':'New reconstruction of selected entries from exact recovered original registry, not a historical standalone record.','registry_uncompressed_sha256':h(rraw),'registry_rows':{str(i):r['files'][i] for i in range(2764,2770)},'snapshot_rows':[x for x in r['snapshots'] if x['id']=='pr-working'],'qualifications':'Snapshot base/dirty state distinct from per-file blob equality; historical 059 is not checkpoint 3821.'}
(b/'historical-selections-reconstructed.json').write_text(json.dumps(selection,indent=2)+'\n')
manifest={'created_utc':datetime.now(timezone.utc).isoformat(),'kind':'Exact retained prior records plus separately labelled reconstructed catalog and assessments.','registry_uncompressed_sha256':h(rraw),'records':records,'qualifications':'Do not credit historical or separately recorded current reads to this reviewer, a different lens, or checkpoint 3821.'}
(b/'historical-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('retained records',len(records),'historical_manifest_sha256',h((b/'historical-manifest.json').read_bytes()))
