'''Offline evidence-integrity verification only. Never executes product code or tests.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,re,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');sel=load('historical-selections-reconstructed.json');proof=load('git-proofs.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files']
assert all(original[i]==sel['registry_rows'][str(i)] for i in range(2764,2770))
assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id']=='pr-working']
catalog=load('recovered/catalog-774.json')['rows'];expected={2764:[[1,171]],2765:[[11,28]],2766:[[1,142]],2767:[[1,87]],2768:[[1,16]],2769:[[1,58]]}
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];body=(b/old['local']).read_bytes();other=(b/cur['local']).read_bytes()
  assert t.extractfile(old['sha256']).read()==body and h(body)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256']
  assert original[i]['material_ranges']==expected[i]==row['original_material_ranges']
  assert catalog[i]['origin']=='git:6533e444fa37552927070cc8d8190907fd3b413e:'+row['path']
  assert (other==body)==cur['equals_archived_file']==(i not in [2765,2767])
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==body and c['display_planned']==False
for x in rec['registrations']:
 assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(x['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(ranges):return [i for a,z in ranges for i in range(a,z+1)]
def partition(n,ranges,lines):
 v=nums(ranges)+lines;return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes();i=row['original_index']
  assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof']
  assert partition(v['eof'],p['actual_display_chunks']+p['unread_complement'],p['current_navigation_only_lines'])
  assert set(nums(expected[i] if j==0 else v['current_material_planned']))<=set(nums(p['actual_display_chunks']))
  assert p['separate_support_read_ranges']==v.get('extra_support_planned',[])
supportplan={x['local']:x for x in load('support-registration.json')['entries']}
for p in rec['support']:
 e=supportplan[p['local']];raw=(b/p['local']).read_bytes();assert h(raw)==p['sha256']==e['sha256'] and len(raw.splitlines())==e['eof']==p['eof'] and p['ordered_role_credit']==0
 assert partition(p['eof'],p['full_line_body_displays']+p['unread_complement'],p['navigation_only_lines'])
 assert set(nums(p['full_line_body_displays']))<=set(nums(e['display_ranges_planned']))
nav={}
for x in rec['navigation_output_receipts']:
 raw=(b/x['output']).read_bytes();lines=raw.decode().splitlines();assert h(raw)==x['sha256'] and len(lines)==x['saved_output_lines']
 displayed=nums(x['personally_displayed_output_lines']);unread=nums(x['unread_saved_output_lines']);assert set(displayed+unread)==set(range(1,len(lines)+1)) and len(displayed)+len(unread)==len(lines)
 for j in displayed:
  m=re.match(r'^95e63628f9d70b8dd6e6fede64334696c6995009:(.*?):(\d+):(.*)$',lines[j-1]);assert m;nav.setdefault(m.group(1),set()).add(int(m.group(2)))
  for p in rec['support']+rec['assigned']:
   if p.get('path')==m.group(1) and p.get('revision')=='95e63628f9d70b8dd6e6fede64334696c6995009':assert (b/p['local']).read_text().splitlines()[int(m.group(2))-1]==m.group(3)
assert {k:sorted(v) for k,v in nav.items()}==rec['navigation_actual_source_lines']
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
rig=readjsonl('historical/774/rig-source-range-registration.jsonl');camera=readjsonl('historical/774/camera-source-range-registration.jsonl')
for i in range(2764,2770):
 ob=original[i]['parallel_reached_registrations'][0];rows=camera if i==2766 else rig;assert rows[ob['row_1based']-1]==ob['original_record']
a=readjsonl('historical/774/camera-additional-sources.jsonl');c=next(x for x in a if x.get('id')=='CAMERA-INITIAL07-ADDITIONAL-003');assert c['fresh_material_read_ranges']==[[1,142]] and c['uncredited_premature_display_ranges']==[[1,150]]
r452=load('historical/059/segovb/READ-L11-452.json')
for i in range(2764,2770):
 row=next(x for x in r452['sources'] if x['original_index']==i);raw=(b/f'historical/059/segovb/REGISTRATION-SEGOVB-{i-1080}.json').read_bytes();assert row['fresh_personal_body_reads']==expected[i] and h(raw)==row['registration_sha256']
r498=load('historical/059/segovb/READ-L11-498.json')['rows'][3];assert r498['fresh_personal_body_reads']==[[1,171]] and r498['same_lens_reuse']==[]
r580=load('historical/059/segovb/READ-L11-580.json')['rows'][21];assert r580['revision']=='e2755a732c84e67296b5e3441a4259a84f461b2f' and r580['fresh_personal_body_ranges']==[] and r580['inherited_lens11_body_reuse']==True
incident=load('workspace-output-incident.json')
for x in incident['current_files']:
 raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned'] and len(proof['proofs'])==40
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: roles2764–2769 exact original material and independent 95e displays, separate exclusions/navigation and old authorship; archive and 40 raw Git membership proofs; 13 bounded perspectives. Evidence verification only, no product/build/test/probe.')
