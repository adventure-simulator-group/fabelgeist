from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
b=Path(__file__).resolve().parent
repo='<LOCAL_PATH_0>'
rev='95e63628f9d70b8dd6e6fede64334696c6995009'
specs=[
 ('textile','crates/fabelgeist-armor/src/textile.rs',[[1,80]]),
 ('textile-pattern','crates/fabelgeist-armor/src/textile_pattern.rs',[[1,80],[175,245]]),
 ('textile-materials','crates/adventuresim-character-creator/src/device_textile_materials.rs',[[1,105]]),
 ('textile-relief','crates/adventuresim-character-creator/src/device_textile_relief.rs',[[1,100]]),
 ('component-projection','crates/adventuresim-character-creator/src/character_morphs.rs',[[175,215]]),
 ('component-preview','crates/adventuresim-character-creator/src/preview.rs',[[75,125]]),
 ('coverage-schema','crates/adventuresim-core/src/item_catalog_schema.rs',[[75,120]]),
 ('coverage-surface','crates/adventuresim-core/src/item_catalog_surface.rs',[[1,60]]),
 ('coverage-validation','crates/adventuresim-core/src/item_catalog_validation_surface.rs',[[1,145]]),
 ('coverage-profile','crates/adventuresim-strategic-sim/src/profile.rs',[[660,710]]),
 ('coverage-melee','crates/adventuresim-core/src/autoresolve/melee_iteration.rs',[[310,365]]),
 ('coverage-contact','crates/adventuresim-core/src/autoresolve/melee_round/commitment.rs',[[110,145]]),
 ('coverage-model','crates/adventuresim-core/src/autoresolve/model.rs',[[180,225],[325,365]]),
 ('helmet-packing','crates/fabelgeist-armor/src/gpu/helmet/parts.rs',[[30,90]])
]
pending=[];entries=[]
for name,path,ranges in specs:
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(raw.splitlines()); blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();ranges=[[a,min(z,eof)] for a,z in ranges if a<=eof];assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 local='support/'+name+'.rs';pending.append((local,raw));entries.append({'name':name,'path':path,'revision':rev,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'eof':eof,'display_ranges_planned':ranges,'local':local,'credit':'connected support only, no ordered-role credit'})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','kind':'Prospective hash-identified bounded current body support displays, subsequent to separately recorded navigation matches. No product execution.','entries':entries}
(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 p=b/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps(d,indent=2));print('SHA256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest())
