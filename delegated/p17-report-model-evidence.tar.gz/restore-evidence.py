import hashlib,json,pathlib,shutil
p=pathlib.Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();a=pathlib.Path('<LOCAL_PATH_1>');b=pathlib.Path('<LOCAL_PATH_2>');paths=['crates/adventuresim-tactical-client/src/animation_viewer/report/mod.rs','crates/adventuresim-tactical-client/src/animation_viewer/report/model.rs'];records=[]
for path in paths:
 x=(a/'source/report-p17'/path).read_bytes();y=(b/'source/report-p17'/path).read_bytes();assert x==y;d=p/'older-continuation'/'report-p17'/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(x);records.append({'kind':'matching P17 source copy in 774 publication and older local collection','path':path,'archive':str(d.relative_to(p)),'bytes':len(x),'sha256':h(x)})
for name in ['contract-groups-588.json','contract-groups-589.json']:
 x=(a/name).read_bytes();y=(b/name).read_bytes();assert x==y;d=p/'older-continuation'/name;d.write_bytes(x);records.append({'kind':'774 operations original historical contract summary','archive':str(d.relative_to(p)),'bytes':len(x),'sha256':h(x)})
(p/'older-continuation-index.json').write_text(json.dumps({'qualification':'Exact independently compared old local copies; historical reviewer, revision and scope remain unchanged, not checkpoint3821.','records':records},indent=2)+'\n')
repo=pathlib.Path('<LOCAL_PATH_3>');src=repo/'crates/adventuresim-tactical-client/src/animation/AGENTS.md';dst=p/'reference/crates/adventuresim-tactical-client/src/animation/AGENTS.md';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
rules=[]
for path in ['reference/AGENTS.md','reference/crates/AGENTS.md','reference/crates/adventuresim-tactical-client/src/animation/AGENTS.md']:
 data=(p/path).read_bytes();rules.append({'archive':path,'sha256':h(data),'bytes':len(data)})
(p/'rules-evidence.json').write_text(json.dumps({'personally_read':rules,'qualification':'User explicit stop before product validation takes precedence over diagnostic instructions; no source edit, test, viewer or product run.'},indent=2)+'\n')
