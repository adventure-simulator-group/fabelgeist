# Roles 2461–2462: P17 report assembly and model source audit

This delegated packet retains newly assessed source, recovered 059 originals,
reconstructed navigation subsets, historical 774 records, and earlier agent
packets as separate evidence. It does not establish checkpoint 3821.

P17 is the recorded clean snapshot
`90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696`; pinned current is
`95e63628f9d70b8dd6e6fede64334696c6995009`. The parent report and model
bodies were independently registered and personally displayed in full at both
revisions, including test source text, which was not executed. Both files exist
at current. Exact source bytes, Git commits/trees, hashes, historical snapshot
copies, and bounded support receipts are included.

The existing artifact-run certification finding is corroborated by a fresh
current trace from the reusable output directory to screenshot callback,
unit-returning native save, retained path, metadata check and acceptance.
A previous nonempty image can conditionally satisfy that individual check if
new conversion fails before replacement; no capture or full report was run.
The separate view-key propagation record is reconnected without automatically
merging it with artifact persistence. Exact earlier 059 author and revision
qualifications remain intact.

The cached `bevy_render-0.19.1` crate archive matches the checksum in pinned
Cargo.lock, and its screenshot source member matches the personally displayed
native source. The initial registered lock window showed a different package;
a second registration records the actual bevy_render stanza and both reads.
This is source and evidence verification, not execution.

Original 059 receipts and registrations are checked against the extracted
transport manifest. Full original registry and queue are compressed in
`reference/`; the selected entries are reconstructed navigation only. Older
774 original and path-normalized export records are distinct. Prior agent
packets and their manifests are archived with authorship and scope intact.
`check-evidence.py` verifies the packet, including Git object paths, native
package checksum and member, historical records and prior packets. No product,
viewer, build, test, runtime probe, simulation, or repair occurred.
