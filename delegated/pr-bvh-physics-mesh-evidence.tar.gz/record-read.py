from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256((b/p).read_bytes()).hexdigest();regs=['support-registration.json']+[f'support-registration-{i:02d}.json' for i in range(2,4)];reg=json.loads((b/'registration.json').read_bytes());sr=[json.loads((b/p).read_bytes()) for p in regs]
def complement(n,ranges):
 used={i for a,z in ranges for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if (i>n or i in used) and start is not None:out.append([start,i-1]);start=None
 return out
assigned=[]
for e in reg['entries']:
 n=e['eof'];r=e['original_role'];assigned.append({'role':r,'path':e['path'],'source_identity':e['source_identity'],'revision':e['revision'],'sha256':e['sha256'],'actual_eof':n,'contiguously_displayed_ranges':[[1,n]],'not_contiguously_displayed_ranges':[],'display_chunks':[[1,130],[131,260],[261,376]] if r==2550 else [[1,110],[111,205]],'original_material_ranges':e['original_material_ranges'],'original_registry_material_ranges':([[27,42],[62,138],[175,299]] if r==2550 else [[1,205]]),'separately_accounted_nonmaterial_ranges':(complement(n,[[27,42],[62,138],[175,299]]) if r==2550 else []),'source_archive':e['source_archive'],'qualification':'Separate personal historical and current bounded full displays, despite byte identity. Per-file equality proves neither a clean whole pr-working snapshot nor transfer of previous credit.'})
support=[]
for regname,r in zip(regs,sr):
 for e in r['entries']:
  seen=e['planned_ranges'];chunks=seen
  support.append({'registration':regname,'path':e['path'],'revision':e['revision'],'sha256':e['sha256'],'actual_eof':e['eof'],'contiguously_displayed_ranges':seen,'not_contiguously_displayed_ranges':complement(e['eof'],seen),'display_chunks':chunks,'source_archive':e['archive'],'qualification':'A separate bounded support read. Complements apply to this registration; other registrations for the same file are accounted independently.'})
x={'schema':'726-pr-bvh-physics-mesh-personal-read-receipt-v1','reader':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registrations':[{'path':p,'sha256':h(p)} for p in ['registration.json']+regs],'assigned_personal_reads':assigned,'support_personal_reads':support,'qualification':'Registrations precede all displayed product bodies. 059/774 and previous delegate receipts retain their own original readers and ranges. Text-only source inspection.'}
(b/'personal-read-receipt.json').write_text(json.dumps(x,indent=2)+'\n');print('assigned',len(assigned),'support',len(support))
