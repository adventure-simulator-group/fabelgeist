# Bounded GPU BVH and physics mesh source evidence

This packet contains `/root/rig_identity`'s source-only assessment of original
roles 2550 and 2551 at current revision
`95e63628f9d70b8dd6e6fede64334696c6995009`. The 059 pr-working registry
objects match the individual files at recorded head
`6533e444fa37552927070cc8d8190907fd3b413e`, recovered objects carried by
`f82adcabd9d89c4fa2dd7f99253a45297a0681ee`, and the pinned current files.
The recorded pr-working snapshot contains four unrelated modified paths; no
whole-snapshot cleanliness or historical promotion into checkpoint 3821 is
asserted.

`registration.json` precedes separate historical and current source displays;
`support-registration*.json` precedes the bounded supporting reads, including
shader text. Both roles were personally displayed in full, but original role
2550's ordered material is only lines 27–42, 62–138 and 175–299. Additional
lines are explicitly recorded as support. Archived full bytes do not imply a
full supporting read; see `personal-read-receipt.json` for exact scopes.
`REPORT.json` contains the source-level conditions, open questions, nonfindings,
thirteen bounded perspectives and historical relationships.

`historical-059/` and `historical-774/` retain exact original record bytes and
authors, including the rig supplier's distinct registrations and the native
reconciliation evidence. Registry/queue selections are labeled reconstructed.
`prior-delegate/` preserves selected reports, registrations, manifests, receipts
and the correction from earlier reviewers without transferring their read
credit. `published-references.json` hash-links the complete published 059
registry, transport manifest, queue and ledger.

`git-proofs.json` and compressed commit/tree objects prove source, support,
transport and 774 record membership. Run `python3 verify-manifest.py` and
`python3 verify-evidence.py [publication-repository-path]`; the latter is
read-only unless invoked with `--record` before freezing.
`evidence-verification.json` records an evidence-only pass. Checks verify source
identity, scopes and cited ranges, not product behavior or reachability.

No source/publication edits, implementation, builds, shader compilation or
execution, tests, fixtures, simulations, GPU queries or runtime probes occurred.
Central owns final reconciliation, the ledger and publication.
