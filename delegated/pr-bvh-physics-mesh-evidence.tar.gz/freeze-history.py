from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
old=Path('<LOCAL_PATH_0>')
pub=Path('<LOCAL_PATH_1>')
sha=lambda x:hashlib.sha256(x).hexdigest()
oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
rpath='recovered/original-registry-source-archive/registry.json.gz';mpath='recovered/original-transport-manifest.json.gz';r=json.load(gzip.open(pub/rpath,'rt'))
sel={'schema':'726-registry-selection-reconstructed-v1','qualification':'Reconstructed selection from 059 registry, not original record or checkpoint 3821. Source snapshots retain their original identity.','original_registry_sha256_uncompressed':sha(gzip.decompress((pub/rpath).read_bytes())),'rows':[{'original_index':i,**r['files'][i]} for i in (2550,2551)],'snapshots':[x for x in r['snapshots'] if x['id']=='pr-working']}
(b/'registry-selection-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n')
q=json.loads((pub/'baseline-059/queue.json').read_bytes());wanted=['SEGOVB-L12-PHYSICS-MESH-TRIANGLES-EMPTY-REASON','SEGOVB-L12-PHYSICS-MESH-TRIANGLE-VERTEX-INDEX-REASON','SEGOVB-L12-PHYSICS-MESH-VERTEX-UPDATE-COUNT-REASON','SEGOVB-L12-CONNECTED-PHYSICS-COLLIDER-NATIVE-COUNT-ADMISSION','PAR-L12-GPU-SHADER-PARAMETER-NAME-PROPAGATION','ADLER-L11-RAY-BOX-EMPTY-CONTRACT','ADLER-L11-BVH-RAY-ENDPOINT-ADMISSION']; selected=[e for e in q['entries'] if e.get('contract_id') in wanted]
(b/'historical-queue-selection-reconstructed.json').write_text(json.dumps({'schema':'726-queue-selection-reconstructed-v1','qualification':'059 historical selection; no source/current/status credit','entries':selected,'requested_missing':[n for n in wanted if n not in {e.get('contract_id') for e in selected}]},indent=2)+'\n')
m=json.load(gzip.open(pub/mpath,'rt'));idx={e['path']:e for e in m['entries']};paths=[]
for lens,n in [(11,421),(12,865)]:
 for k in ['READ','VERIFY','STATE']: paths.append(f'segovb/{k}-L{lens}-{n}.json')
paths += [f'segovb/REGISTRATION-SEGOVB-{n}.json' for n in (1456,1457,1467)] + ['adler/READ-L11-373.json','adler/REGISTRATION-ADLER-1193.json','segovb/READ-L12-CONNECTED-TEAM-006.json','segovb/READ-L12-CONNECTED-TEAM-020.json'] + [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json' for n in (592,593)] + ['parallel-l12-20261029/PROPOSAL-L12-865.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-865-BVH-GAPS-RESOLVED-STATE.json','parallel-l12-20261029/REGISTRATION-PAR-L12-297-CONNECTED-ORIGINAL2551.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-769-COLLISION-OWNERS.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-297-LOCATOR-ORIGINAL2551.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-865-FUTURE-ORIGINAL2551.json']
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file():missing.append(p);continue
 raw=(old/p).read_bytes();e=idx[p];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(raw)==e['git_blob'];dst=b/'historical-059'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records.append({'original_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
prefix='handoff/774/adler-original/audit/continuation/'; paths774=[prefix+'rig/owner-reached-producer-followup/'+n for n in ['additional-sources.jsonl','source-qualifications.jsonl','coverage.jsonl','coverage-errata.jsonl','traces.jsonl','findings.jsonl','findings-errata.jsonl','completion-001.json','repair-targets.json']]+[prefix+'root/producer-followup-acceptance-028.json',prefix+'root/producer-scope-extension-authority-022.json',prefix+'native/producer-registry-reconciliation/candidate-002.json',prefix+'native/producer-registry-reconciliation/summary-002.json']+['handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/producer-supplement-after-owner/rig/findings.jsonl','handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/producer-supplement-after-owner/rig/traces.jsonl']
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records774=[]
for p in paths774:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+p]);assert oid(raw)==subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+p],text=True).strip();dst=b/'historical-774'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records774.append({'transport_revision':rev,'transport_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
refs=[]
for p in [rpath,mpath,'baseline-059/queue.json','baseline-059/ledger.json']:
 raw=(pub/p).read_bytes();refs.append({'repository_relative_path':p,'sha256':sha(raw),'bytes':len(raw),'qualification':'Previously published baseline historical evidence; no personal source read credit transferred.'})
(b/'published-references.json').write_text(json.dumps({'schema':'726-published-evidence-hash-links-v1','repository':'audit baseline publication','created_utc':datetime.now(timezone.utc).isoformat(),'entries':refs,'qualification':'Hash-linked existing complete evidence; pass publication repository to verifier.'},indent=2)+'\n')
prior=[]
for name,author in [('726-delegate-physics-contact','/root/rig_identity'),('726-delegate-physics-collider-count','/root/rig_identity')]:
 p=Path('/tmp')/name;target=b/'prior-delegate'/name;target.mkdir(parents=True,exist_ok=True);entries=[]
 for n in (['REPORT.json','MANIFEST.json','registration.json','support-registration-3.json'] if name=='726-delegate-physics-contact' else ['REPORT.json','MANIFEST.json','personal-read-receipt.json','ATTRIBUTION-CORRECTION.json']):
  if not (p/n).exists():continue
  raw=(p/n).read_bytes();(target/n).write_bytes(raw);entries.append({'name':n,'sha256':sha(raw),'bytes':len(raw),'preserved_bytes':str((target/n).relative_to(b))})
 prior.append({'name':name,'author':author,'records':entries,'complete_source_packet_reference':str(p),'qualification':'Selected original report/manifest/receipt, no transferred credit. Prior packet remains hash-linked by its own manifest.'})
out={'schema':'726-original-attribution-v1','created_utc':datetime.now(timezone.utc).isoformat(),'original_059_records':records,'older_774_receipts':records774,'prior_delegate_selected_records':prior,'published_references':'published-references.json','missing_originals':missing,'qualification':'Recovered historic, reconstructed, and current evidence retain actual revision and reader. No promotion to checkpoint 3821.'}
(b/'original-attribution.json').write_text(json.dumps(out,indent=2)+'\n');print('059',len(records),'774',len(records774),'prior',len(prior),'missing',missing)
