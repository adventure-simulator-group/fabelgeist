from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,sys
b=Path(__file__).resolve().parent;args=[x for x in sys.argv[1:] if x!='--record'];pub=Path(args[0]) if args else Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();refs=json.loads((b/'published-references.json').read_bytes())
for e in refs['entries']:
 raw=(pub/e['repository_relative_path']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'],e['repository_relative_path']
reg=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));assigned=json.loads((b/'registration.json').read_bytes())['entries'];receipt=json.loads((b/'personal-read-receipt.json').read_bytes());proof=json.loads((b/'git-proofs.json').read_bytes());report=json.loads((b/'REPORT.json').read_bytes());man=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in man['entries']}
for e in assigned:
 raw=(b/e['source_archive']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and len(raw.splitlines())==e.get('actual_eof',e.get('eof')) and oid('blob',raw)==e['git_blob']
 if e['original_material_ranges'] is not None:
  row=reg['files'][e['original_role']];assert e['sha256']==row['sha256'] and e['bytes']==row['bytes'] and e['original_material_ranges']==row['material_ranges']
for role in (2550,2551):
 rows=[e for e in assigned if e['original_role']==role];assert len(rows)==2 and rows[0]['sha256']==rows[1]['sha256'] and rows[0]['git_blob']==rows[1]['git_blob']
s=next(x for x in reg['snapshots'] if x['id']=='pr-working');assert s['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and s['patch_sha256']=='dba7a85bb2105ccdf0587c4713fdc2a33b374600457f5c05e9c5f29d087193b1' and len(s['status_porcelain'])==4
selection=json.loads((b/'registry-selection-reconstructed.json').read_bytes());assert s in selection['snapshots']
for row in selection['rows']:
 i=row['original_index'];assert {k:v for k,v in row.items() if k!='original_index'}==reg['files'][i]
q=json.loads((pub/'baseline-059/queue.json').read_bytes());qi={e.get('contract_id'):e for e in q['entries']};qs=json.loads((b/'historical-queue-selection-reconstructed.json').read_bytes());assert not qs['requested_missing']
for e in qs['entries']:assert e==qi[e['contract_id']]
old=json.loads((b/'original-attribution.json').read_bytes());assert not old['missing_originals']
for e in old['original_059_records']:
 raw=(b/e['preserved_bytes']).read_bytes();orig=idx[e['original_path']];assert sha(raw)==e['sha256']==orig['sha256'] and len(raw)==orig['bytes'] and oid('blob',raw)==orig['git_blob']==e['git_blob']
for e in old['older_774_receipts']:
 raw=(b/e['preserved_bytes']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and oid('blob',raw)==e['git_blob']
for p in old['prior_delegate_selected_records']:
 rec={}
 for e in p['records']:
  raw=(b/e['preserved_bytes']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'];rec[e['name']]=raw
 prior=json.loads(rec.get('packet-manifest.json') or rec.get('MANIFEST.json'));mi={e['path']:e for e in prior['files']}
 for n in rec:
  if n not in ('packet-manifest.json','MANIFEST.json'):
   assert n in mi and sha(rec[n])==mi[n]['sha256'] and len(rec[n])==mi[n]['bytes']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
objects={}
for key,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,e in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==e['root_tree']
for p in proof['paths']:
 curr=proof['commits'][p['revision']]['root_tree'];parts=p['path'].split('/');assert len(parts)==len(p['path_chain'])
 for name,step in zip(parts,p['path_chain']):
  assert step['tree']==curr and step['name']==name;mode,child=entries(objects[curr])[name];assert mode==step['mode'] and child==step['object'];curr=child
 raw=(b/p['preserved_bytes']).read_bytes();assert oid('blob',raw)==curr==p['git_blob'] and sha(raw)==p['sha256'] and len(raw)==p['bytes']
assert len(receipt['assigned_personal_reads'])==4 and len(receipt['support_personal_reads'])==13 and len(report['lenses'])==13
for entry in receipt['registrations']:
 raw=(b/entry['path']).read_bytes();assert sha(raw)==entry['sha256']
 stamp=json.loads(raw)['created_utc'];assert datetime.fromisoformat(stamp)<datetime.fromisoformat(receipt['recorded_utc'])
for row in receipt['assigned_personal_reads']:
 matches=[e for e in assigned if e['original_role']==row['role'] and e['revision']==row['revision']];assert len(matches)==1
 e=matches[0];assert row['path']==e['path'] and row['sha256']==e['sha256'] and row['source_archive']==e['source_archive'] and row['contiguously_displayed_ranges']==e['planned_ranges']
for row in receipt['support_personal_reads']:
 x=json.loads((b/row['registration']).read_bytes());matches=[e for e in x['entries'] if e['path']==row['path'] and e['revision']==row['revision']];assert len(matches)==1
 e=matches[0];assert row['sha256']==e['sha256'] and row['source_archive']==e['archive'] and row['contiguously_displayed_ranges']==e['planned_ranges']
for e in receipt['assigned_personal_reads']+receipt['support_personal_reads']:
 seen=set();absent=set()
 for a,z in e['contiguously_displayed_ranges']:
  assert 1<=a<=z<=e.get('actual_eof',e.get('eof'));seen.update(range(a,z+1))
 for a,z in e['not_contiguously_displayed_ranges']:
  assert 1<=a<=z<=e.get('actual_eof',e.get('eof'));absent.update(range(a,z+1))
 chunks={i for a,z in e['display_chunks'] for i in range(a,z+1)};assert chunks==seen
 assert seen.isdisjoint(absent) and len(seen)+len(absent)==e.get('actual_eof',e.get('eof'))
for e in receipt['assigned_personal_reads']:assert e['contiguously_displayed_ranges']==([[1,376]] if e['role']==2550 else [[1,205]])
for e in receipt['assigned_personal_reads']:
 row=reg['files'][e['role']];assert e['original_registry_material_ranges']==row['material_ranges']
 material={i for a,z in row['material_ranges'] for i in range(a,z+1)};extra={i for a,z in e['separately_accounted_nonmaterial_ranges'] for i in range(a,z+1)};assert material.isdisjoint(extra) and material|extra==set(range(1,e['actual_eof']+1))
scopes={}
for e in receipt['support_personal_reads']:
 scopes.setdefault(e['path'],set()).update(i for a,z in e['contiguously_displayed_ranges'] for i in range(a,z+1))
for e in receipt['assigned_personal_reads']:
 if e['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009':scopes.setdefault(e['path'],set()).update(range(1,e.get('actual_eof',e.get('eof'))+1))
def visit(x):
 if isinstance(x,dict):
  if x.get('revision')=='95e63628f9d70b8dd6e6fede64334696c6995009' and 'ranges' in x:
   assert x['path'] in scopes
   for a,z in x['ranges']:assert set(range(a,z+1))<=scopes[x['path']],(x['path'],a,z)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Hash-linked 059 registry, transport manifest, queue and ledger match','Recorded pr-working per-file objects match 6533, f82 recovered transport, and 95e; four unrelated modified snapshot paths remain qualified','Raw commit/tree chains prove exact per-file and bounded support membership, plus f82 transported older 774 receipts','Original 059 bytes match transport manifest; reconstructed registry and queue rows match originals; earlier delegate reports and personal receipts match their own manifests','Four full assigned revision displays, thirteen separately registered bounded support entries, cited current source ranges and thirteen bounded perspectives checked'],'scope':'Evidence hashes, Git chains, source scopes and citations only. No product validation, testing, fixtures or runtime probes.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw) if '--record' in sys.argv else None;print('PASS',sha(raw),'proofs',len(proof['paths']),'059',len(old['original_059_records']),'published links',len(refs['entries']))
