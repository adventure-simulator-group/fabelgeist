'''Read-only verification of this reconciliation's evidence links and object identities.'''
import gzip,hashlib,json,subprocess,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;report=json.loads((p/'RECONCILIATION.json').read_bytes());s=report['sources'];h=lambda b:hashlib.sha256(b).hexdigest()
def check(x):
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
for k in ['checkpoint10','registry_archive','source_archive','baseline_ledger','baseline_queue','reconciliation']:check(s[k])
for k in ['earlier_059_receipts','current_prior_assessments']:
 for x in s[k]:check(x)
for x in report['exact_local_assigned_registrations']:check(x['original']);assert x['original']['sha256']==x['receipt_original_registration_sha256']!=x['public_member_sha256']
registry=gzip.decompress(Path(s['registry_archive']['path']).read_bytes());assert h(registry)==s['registry_uncompressed_sha256'];records=json.loads(registry)['files']; pub=Path(s['baseline_ledger']['path']).parent
with tarfile.open(s['source_archive']['path'],'r:gz') as t:
 for x in report['roles']:
  orig=records[x['index']];b=t.extractfile(x['original_registry_sha256']).read();assert h(b)==orig['sha256']==x['original_registry_sha256'] and len(b.splitlines())==x['eof'];path=x['source_id'].split(':',1)[1]
  for rev in x['per_file_git_equal']:assert subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path])==b
  assert subprocess.check_output(['git','-C',str(pub),'show','f82adcabd9d89c4fa2dd7f99253a45297a0681ee:'+x['f82_evidence_transport_path']])==b
checkpoint=json.loads(Path(s['checkpoint10']['path']).read_bytes());bundles={x['bundle_id']:x for x in checkpoint['bundles']}
for x in report['public_transport']:
 check(x['archive']);check(x['report']);entry=bundles[x['bundle']]; mm={m['path']:m for m in entry['members']}
 with tarfile.open(x['archive']['path'],'r:gz') as tar:
  manifest=json.load(tar.extractfile(x['original_packet_manifest_member'])); assert len(manifest['files'])==x['manifest_entries'];diff=[]
  for m in manifest['files']:
   b=tar.extractfile(m['path']).read();pubm=mm[m['path']];assert h(b)==pubm['published_sha256'] and len(b)==pubm['published_bytes'] and m['sha256']==pubm['original_sha256'] and m['bytes']==pubm['original_bytes']
   if h(b)!=m['sha256'] or len(b)!=m['bytes']:diff.append(m['path'])
  assert diff==[v['path'] for v in x['public_member_differences']]
if (p/'MANIFEST.json').exists():
 for x in json.loads((p/'MANIFEST.json').read_bytes())['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
print('PASS: 5 original P16 objects, 4 per-path Git revision identities plus f82 transport, historical/ledger links, original assigned registrations, and 14/13 checkpoint10 redaction mappings. Evidence-only; no product validation.')
