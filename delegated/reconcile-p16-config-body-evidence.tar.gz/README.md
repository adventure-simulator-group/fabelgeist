# P16 configuration and body-response reconciliation

`RECONCILIATION.json` is a proposed, bounded central reconciliation of
checkpoint-10 roles 2483–2487. It preserves the original camera metadata-only
registration, earlier Segovb, Adler, native and delegated reviewer scopes,
new personal receipts, per-file identities, prior findings and open questions.
It does not adopt ledger entries or close a lens.

The packet hash-links existing archives rather than duplicating them. The
published checkpoint-10 per-member mapping distinguishes original bytes from
path-redacted public reconstructions; the two exact original assigned
registrations are still held in their original temporary packets. Original
manifests describe pre-redaction bytes, not every reconstructed public member.

`python3 verify_evidence.py` checks the linked identities without running
product code. The included generation script repeats the source-object and
receipt comparisons but would generate a new timestamped report; do not run it
against this frozen packet when byte identity matters. No product source,
publication, builds, tests, execution, probes, rendering, repairs, validation or
deletions occurred.
