import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=['crates/adventuresim-core/src/book.rs','crates/adventuresim-core/src/skill.rs','crates/adventuresim-core/src/strategic_schedule.rs','crates/adventuresim-stdb-module/src/time/schedule.rs','crates/strategic-web/src/schedule.rs','crates/strategic-web/src/templates/settlement/character_details.rs','crates/strategic-web/static/training-schedule.js']
rows=[]
for path in paths:
 b=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True,check=True).stdout; (out/'source'/('support-'+path.replace('/','__'))).write_bytes(b)
 rows.append({'path':path,'revision':rev,'range':[1,len(b.splitlines())],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
o={'schema':'delegated-support-prospective-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Bounded support tracing skill-meter nonfinite admission, reading preview, and faith context; only separately recorded personally displayed ranges count.','registered_sources':rows,'qualification':'Full objects retained for reproducibility, not a claim of full display or ordered-role/other-lens credit.'}
f=out/'support-registration-01.json';f.write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256(f.read_bytes()).hexdigest());print('\n'.join(x['path']+' '+str(x['range']) for x in rows))
