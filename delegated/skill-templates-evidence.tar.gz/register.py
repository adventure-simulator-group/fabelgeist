import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>'); repo='<LOCAL_PATH_1>'
revisions=['6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']
paths=[(2402,'crates/strategic-web/src/templates/settlement/character_skills.rs'),(2403,'crates/strategic-web/src/templates/settlement/character_skills/rank.rs')];rows=[]
for i,path in paths:
 vs=[]
 for rev in revisions:
  x=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True)
  if x.returncode: vs.append({'revision':rev,'present':False});continue
  b=x.stdout; sha=hashlib.sha256(b).hexdigest(); blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();(out/'source'/(rev[:4]+'-'+pathlib.Path(path).name)).write_bytes(b)
  vs.append({'revision':rev,'present':True,'lines':[1,len(b.splitlines())],'bytes':len(b),'sha256':sha,'git_blob':blob})
 rows.append({'original_index':i,'path':path,'versions':vs})
o={'schema':'delegated-audit-prospective-source-registration-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'agent':'/root/hair_ops','purpose':'Register exact old/current assigned skill-template bodies before any full source display; record actual personal displays separately.','qualification':'One source display can account for identical bytes only after independent Git byte comparison; preserve historical reviewer and earlier partial support credit separately.','constraint':'No product edits, repairs, builds, tests, browser use, runtime probes or simulations.','ordered_roles':rows}
f=out/'registration.json';f.write_text(json.dumps(o,indent=2)+'\n');print('registration sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(rows,indent=2))
