#!/usr/bin/env python3
"""Evidence identities, scoped source-read accounting and Git proofs only."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
def vals(r):return {i for lo,hi in r for i in range(lo,hi+1)}
scope=load('read-scope-summary.json')
for regfile,receipt,section in [('registration.json','personal-read-receipt.json','assigned')]+[(f'support{x}-registration.json',f'support{x}-read-receipt.json','support') for x in ['',2,3,4,5,6]]:
 reg=load(regfile);rc=load(receipt);assert sha((p/regfile).read_bytes())==rc['registration_sha256'] and reg['registered_utc']<rc['recorded_utc'] and len(reg['entries'])==len(rc['actual_displays'])
 for e,x in zip(reg['entries'],rc['actual_displays']):
  d=(p/e['source_archive']).read_bytes();assert (sha(d),blob(d),len(d),len(d.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['EOF']) and x['source_archive']==e['source_archive'] and e['planned_chunks']==x['displayed_chunks'] and vals(e['planned_chunks'])==vals(e['registered_ranges']);s=scope[section][e['source_archive']];assert s['displayed_ranges']==e['registered_ranges'] and s['unread_complement']==x['unread_complement'] and not vals(s['displayed_ranges'])&vals(s['unread_complement']) and vals(s['displayed_ranges'])|vals(s['unread_complement'])==set(range(1,e['EOF']+1))
reg=load('registration.json');assert len(reg['entries'])==4 and len(scope['support'])==12
for i,rr in [(2718,[[1,49]]),(2719,[[1,151],[245,398]])]:
 old,cur=[e for e in reg['entries'] if e['original_index']==i];cmp=next(x for x in reg['comparisons'] if x['original_index']==i);base=(p/cmp['base_archive']).read_bytes();assert old['original_material_ranges']==old['registered_ranges']==cur['registered_ranges']==rr and (p/old['source_archive']).read_bytes()==(p/cur['source_archive']).read_bytes()==base and cmp['historical_equals_base_individual_file'] and not cmp['status_porcelain'] and (sha(base),blob(base))==(cmp['base_sha256'],cmp['base_blob'])
assert scope['assigned']['source/2719-historical.rs']['unread_complement']==scope['assigned']['source/2719-current.rs']['unread_complement']==[[152,244],[399,620]] and 'test source text' in scope['qualification'];checks.append('Separate P16/current assigned displays, exact original 2719 exclusions, twelve bounded supports and test-source qualifications')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';j=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert all(sel['roles'][str(i)]==j['files'][i] for i in [2718,2719]);snap=next(x for x in j['snapshots'] if x['id']=='physical-p16');assert sel['physical_p16']==snap and snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and len(snap['status_porcelain'])==159 and sha((p/'reference/p16-tracked.patch').read_bytes())==snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
raw=(p/'reference/original-transport-manifest.json.gz').read_bytes();assert sha(raw)=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';entries={x['path']:x for x in json.loads(gzip.decompress(raw))['entries']};hist=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hist['records'])==14 and sum(x['kind']=='historical-774' for x in hist['records'])==10
for x in hist['records']:
 d=(p/x['file']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (len(d),sha(d),blob(d))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
search=load('recovery-search.json');assert len(search['roots'])==2 and len(search['filenames'])==3 and not search['results'] and not search['errors'] and not search['transport_manifest_matches'] and not any(pathlib.PurePosixPath(x).name in search['filenames'] for x in entries);checks.append('Dirty P16 registry, recovered tracked patch, 14 original 059 and 10 historical 774 records; bounded proposal948 search')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];d=gzip.decompress((p/x['archive']).read_bytes());assert (len(d),sha(d),hashlib.sha1(x['type'].encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest())==(x['bytes'],x['sha256'],oid);return d
def trees(d):
 out={};i=0
 while i<len(d):
  s=d.index(b' ',i);z=d.index(b'\0',s);out[d[s+1:z].decode()]=(d[i:s].decode(),d[z+1:z+21].hex());i=z+21
 return out
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==30
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 d=(p/x['archive']).read_bytes();d=gzip.decompress(d) if x.get('encoding')=='gzip' else d;assert (sha(d),blob(d),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Thirty offline Git membership proofs covering f82 transport, a120, 6533, 95e and bounded support')
reg774=[json.loads(x) for x in gzip.decompress((p/'history-774/native/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines()];qs=[json.loads(x) for x in gzip.decompress((p/'history-774/native/admission03/camera-support/source-qualifications-011.jsonl.gz').read_bytes()).splitlines()]
for number,role,rr in [(82,2718,[[1,49]]),(88,2719,[[1,151],[245,398]])]:
 id=f'NATIVE-ADMISSION03-REG-{number:03d}';x=next(x for x in reg774 if x['id']==id);z=next(x for x in qs if x['registration_id']==id);assert x['material_ranges']==z['qualified_material_ranges']==rr and x['sha256']==j['files'][role]['sha256']
root=json.loads(gzip.decompress((p/'history-774/root/initial04-invariant-operations/contract-groups-017.json.gz').read_bytes()));assert root['id']=='ROOT-INITIAL04-CONTRACT-017' and 'NaN' in root['groups']['food-floating-port'];findings=json.loads(gzip.decompress((p/'history-774/native/findings.json.gz').read_bytes()));assert any(x['id']=='NATIVE-CONT-WORLD-F001' for x in findings);l11=load('history-059/segovb/READ-L11-443.json')
for i,rr in [(2718,[[1,49]]),(2719,[[1,151],[245,398]])]:assert next(x for x in l11['sources'] if x['original_index']==i)['fresh_personal_body_reads']==rr
for i,role,rr in [(1,2718,[[1,49]]),(2,2719,[[1,151]]),(3,2719,[[245,398]])]:
 row=next(x for x in load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-948-{i:03d}.json')['rows'] if x['original_index']==role);assert row['fresh_personal_body_reads']==rr and '/root/lens12_frontier' in row['attribution']
assert 'root adoption required' in load('history-059/parallel-l12-20261029/PROPOSAL-L12-948.json')['kind'];checks.append('Original Native material qualifications and historical event observations, separately attributed Segovb and frontier proposal scopes')
prior=load('prior-terrain-index.json');m=(p/'prior-terrain/BUNDLE-MANIFEST.json').read_bytes();assert sha(m)==prior['manifest_sha256']=='e398e4751aa4221b354d14dfdd95e5c52e646197e53aea7518f05cd6f9d281ed';members={x['path']:x for x in json.loads(m)['files']}
for x in prior['selected_records']:
 b=(p/x['file']).read_bytes();e=members[x['prior_member']];assert (len(b),sha(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256'])
pr=load('prior-terrain/support4-read-receipt.json');assert pr['actual_displays'][0]['displayed_ranges']==[[1,140]];raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert e==queue['entries'][int(n)]
for x in load('reference-index.json')['records']:
 d=(p/x['file']).read_bytes();assert (sha(d),len(d))==(x['sha256'],x['bytes'])
for file in ['rules.json','skills.json']:
 for x in load(file)['records']:assert sha((p/x['file']).read_bytes())==x['sha256']
search_calls=load('bounded-call-search.json');assert [(x['path'],x['line']) for x in search_calls['results']]==[('crates/adventuresim-stdb-module/src/food/consumption.rs',81),('crates/adventuresim-stdb-module/src/world_event.rs',941)]
report=load('report.json');assert report['scope']['roles']==[2718,2719] and {x['number'] for x in report['lenses']}==set(range(1,14));checks.append('Nested prior manifest and separately attributed coordinate read; original queue, prior assessment and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and read accounting only; no product, tests, fixtures, builds, probes, simulation, repair, validation, checkpoint3821 promotion, proposal948 adoption or whole-lens closure.'},indent=2))
