import datetime,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';args=['git','-C',repo,'grep','-n','-F','commit_food_water_infection',rev,'--','crates/adventuresim-stdb-module/src'];q=subprocess.run(args,capture_output=True,text=True);assert q.returncode==0;rows=[]
for x in q.stdout.splitlines():
 v,path,line,_=x.split(':',3);rows.append({'revision':v,'path':path,'line':int(line)})
(p/'bounded-call-search.json').write_text(json.dumps({'searched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revision':rev,'method':'git grep -n -F exact symbol scoped to crates/adventuresim-stdb-module/src; saved only names and line numbers','results':rows,'qualification':'Syntactic occurrence search, not proof of absence of alias, macro-generated, indirect or runtime calls. Bodies were independently prospectively displayed under support registrations.'},indent=2)+'\n');print('symbol occurrences',len(rows))
