# Roles 2456–2457: P17 guard liveness and height source audit

This packet preserves newly assessed source separately from recovered 059
original records, reconstructed navigation selections, older 774 records, and
prior independently attributed agent packets. It does not establish or
reconstruct checkpoint 3821.

The clean P17 snapshot is `90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696`.
Pinned current is `95e63628f9d70b8dd6e6fede64334696c6995009`. Both assigned
P17 bodies were personally displayed in full after registration: guard
liveness lines 1–108 and height lines 1–254. Neither exact path exists in the
current tree; raw commit/tree membership and nonmembership proofs are included.
Current inlined metric functions, plan selection, and consumers were freshly
registered and displayed only in the bounded support ranges. The read receipts
and original registrations give exact hashes and scopes.

`report.json` records thirteen bounded perspectives, evidence, conditions,
nonfindings, and open policy questions. The nested terrain warmup independently
corroborates `/root/rig_identity`'s conditional finding; actual observed wraps,
cycle requirements and runtime impact are not established. Liveness applicability
and partial data coverage are unresolved questions, not a new accepted finding.
The earlier continuity and metrics packets are archived with original author,
source scope, manifest verification, and qualifications.

`historical-059/` holds exact extraction bytes checked against the original
transport manifest. Registry and queue selections are derived navigation only;
their original full inputs are compressed in `reference/`. `older-774/`
contains distinct original and path-normalized exports; `older-continuation/`
preserves independent matching snapshot copies and original contract summaries.
No old reviewer, revision, summary or read is transferred into a new checkpoint.

`check-evidence.py` verifies source/archive hashes, registered personal ranges,
Git object membership and absence, historical receipts, older source copies,
and prior packet archives. It verifies evidence integrity only. No repair,
build, test, viewer, simulation, runtime probe or product validation occurred.
