import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=p/'historical-059';H=lambda b:hashlib.sha256(b).hexdigest()
def check(n,sha):
 n=n.removeprefix('target/726-audit-adler-20261027/');assert H((h/n).read_bytes())==sha,n
x=json.loads((h/'segovb/READ-L11-421.json').read_text());rows=[r for r in x['sources'] if r['original_index'] in [2552,2553]];assert len(rows)==2
for r in rows:check(r['registration'],r['registration_sha256']);assert r['fresh_personal_body_reads']==([[1,12]] if r['original_index']==2552 else [[1,45]])
x=json.loads((h/'segovb/READ-L12-866.json').read_text());check(x['proposal'],x['proposal_sha256']);check(x['validated_bundle']['path'],x['validated_bundle']['sha256']);assert not x['root_personal_rereads'];rows=[r for r in x['rows'] if r.get('original_index') in [2552,2553]];assert len(rows)==2
for r in rows:check(r['registration'],r['registration_sha256']);assert r['fresh_personal_body_reads']==([[1,12]] if r['original_index']==2552 else [[1,45]])
x=json.loads((h/'segovb/READ-L12-CONNECTED-TEAM-017.json').read_text());check(x['manifest']['path'],x['manifest']['sha256']);assert not x['root_personal_rereads']
for z in x['evidence_refs']:check(z['path'],z['sha256'])
for r in x['checked_rows']:
 if r.get('original_index')==2501:check(r['registration'],r['registration_sha256']);check(r['receipt']['path'],r['receipt']['sha256'])
for n in [49,51,60]:
 x=json.loads((h/f'parallel-l13-20261029/READ-PL13-{n:03}.json').read_text());check(x['registration']['path'],x['registration']['sha256'])
queue=json.loads((p/'historical-queue-selected.json').read_text());room=next(z['entry'] for z in queue['entries'] if z['index']==404);check(room['metadata_proposals'][0]['path'],room['metadata_proposals'][0]['sha256'])
for e in room['granular_contract_views'][0]['exact_source_identities_and_assessed_ranges']:
 check(e['read']['path'],e['read']['sha256']);check(e['registration']['path'],e['registration']['sha256'])
for x in json.loads((p/'prior-references.json').read_text())['packets']:
 o=pathlib.Path(x['prior_location']);assert H((o/x['manifest_name']).read_bytes())==x['manifest_sha256'];m=json.loads((o/x['manifest_name']).read_text());r={v['path']:v for v in m['files']}
 for c in x['copies']:
  z=p/c['path'];assert H(z.read_bytes())==c['sha256']
  if z.name==x['report_name']:assert r[x['report_name']]['sha256']==c['sha256']
result={'schema':'726-evidence-link-verification-v1','status':'passed','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'Exact 059 L11 and L12 registrations/receipts, L12 bundle and connected builder adoption, L13 room-queue proposal, original receipt and registration hashes, and both previous report/manifest hashes.','qualification':'Original attribution, scope, and separate previous packets retained; full prior archives separately hash-linked. Evidence-only checks, no product validation.'};(p/'evidence-links-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
