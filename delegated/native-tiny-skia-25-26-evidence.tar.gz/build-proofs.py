from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();objects={};proofs=[]
def save(t,k):
 raw=subprocess.check_output(['git','-C',repo,'cat-file',t,k]);assert oid(t,raw)==k
 if k not in objects:
  p=f'git-objects/{k}.{t}.gz';(r/p).parent.mkdir(parents=True,exist_ok=True);(r/p).write_bytes(gzip.compress(raw,mtime=0));objects[k]={'type':t,'bytes':len(raw),'sha256':h(raw),'preserved':p}
 return raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise KeyError(n)
def proof(rev,path,local,kind):
 raw=(r/local).read_bytes();root=save('commit',rev).splitlines()[0].split()[1].decode();tree=root;chain=[]
 for n in path.split('/'):
  mode,child=lookup(save('tree',tree),n);chain.append({'tree':tree,'name':n,'mode':mode,'object':child});tree=child
 assert tree==oid('blob',raw);proofs.append({'revision':rev,'path':path,'local':local,'kind':kind,'root_tree':root,'chain':chain,'blob':tree,'sha256':h(raw)})
reg=json.loads((r/'registration.json').read_bytes());hist=json.loads((r/'historical-manifest.json').read_bytes())
for x in reg['rows']+[reg['historical_lock']]:proof(x['transport_revision'],x['transport_path'],x['local'],'f82 recovered-object transport; no project revision or whole historical snapshot assertion')
for x in reg['current_support']:proof(x['revision'],x['path'],x['local'],'pinned project support; only registered displayed ranges read')
for x in hist['records']:
 if x.get('transport_revision'):proof(x['transport_revision'],x['git_path'],x['local'],'exact original rig record transported via f82')
(r/'git-proofs.json').write_text(json.dumps({'schema':'726-tiny-skia-git-proof-v1','objects':objects,'proofs':proofs,'qualification':'Native crates.io package identity is independent from f82 transport and 95e project source.'},indent=2)+'\n');print('chains',len(proofs),'objects',len(objects),'sha256',h((r/'git-proofs.json').read_bytes()))
