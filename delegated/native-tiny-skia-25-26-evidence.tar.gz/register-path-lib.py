from pathlib import Path
import datetime,hashlib,json,tarfile
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();d0=json.loads((r/'path-support-registration.json').read_bytes());p=Path(d0['archive']);assert h(p.read_bytes())==d0['package_sha256']
with tarfile.open(p,'r:gz') as t:b=t.extractfile('tiny-skia-path-0.11.4/src/lib.rs').read()
d={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','package':'tiny-skia-path 0.11.4','archive_sha256':h(p.read_bytes()),'member':'tiny-skia-path-0.11.4/src/lib.rs','local':'support/native-path-lib.rs','sha256':h(b),'eof':len(b.splitlines()),'prospective_ranges':[[50,70]],'qualification':'Earlier match-only navigation disclosed separately; this registration precedes the bounded source display. Not original role credit.'}
with (r/'path-lib-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
(r/d['local']).write_bytes(b);print(d['registered_utc'],h((r/'path-lib-registration.json').read_bytes()),d['sha256'],d['eof'])
