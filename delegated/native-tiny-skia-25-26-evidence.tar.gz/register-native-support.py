from pathlib import Path
import datetime,hashlib,json,tarfile,tomllib
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();lock=(r/'support/project-0.source').read_bytes();packages=tomllib.loads(lock.decode())['package'];row=next(x for x in packages if x['name']=='bytemuck' and x['version']=='1.25.2');cache=Path('<LOCAL_PATH_0>');bytearchive=cache/'bytemuck-1.25.2.crate';raw=bytearchive.read_bytes();assert h(raw)==row['checksum'];tiny=Path(json.loads((r/'registration.json').read_bytes())['package']['archive']);specs=[(tiny,'tiny-skia-0.11.4/src/color.rs',[[70,125]]),(bytearchive,'bytemuck-1.25.2/src/lib.rs',[[390,440],[490,535]]),(bytearchive,'bytemuck-1.25.2/src/internal.rs',[[230,290],[340,406]])];entries=[];contents={}
for i,(ar,member,ranges) in enumerate(specs):
 with tarfile.open(ar,'r:gz') as t:b=t.extractfile(member).read()
 local=f'support/native-{i}.rs';contents[local]=b;entries.append({'package_archive':str(ar),'package_sha256':h(ar.read_bytes()),'package_member':member,'sha256':h(b),'eof':len(b.splitlines()),'local':local,'prospective_ranges':ranges,'qualification':'External native support only, never original ordered-role credit.'})
lines=lock.splitlines();n=next(i for i,x in enumerate(lines,1) if x==b'name = "bytemuck"');window=[n-1,n+10]
d={'schema':'726-tiny-skia-support-v1','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','entries':entries,'current_lock_additional_range':window,'current_lock_local':'support/project-0.source','lock_sha256':h(lock),'qualification':'Separate prospective native helper and current lock support. Package checksums bind evidence, not source execution or target feature resolution.'}
with (r/'native-support-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
for path,b in contents.items():(r/path).write_bytes(b)
print('registered',d['registered_utc'],h((r/'native-support-registration.json').read_bytes()),'lock',window)
for x in entries:print(x['package_member'],x['eof'],x['sha256'],x['prospective_ranges'])
