'''Offline evidence checks only; no image or product code is run.'''
from pathlib import Path
import gzip,hashlib,json,tarfile,tomllib
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();oid=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((r/'registration.json').read_bytes());ns=json.loads((r/'native-support-registration.json').read_bytes());ps=json.loads((r/'path-support-registration.json').read_bytes());pl=json.loads((r/'path-lib-registration.json').read_bytes());hist=json.loads((r/'historical-manifest.json').read_bytes());rec=json.loads((r/'read-receipt.json').read_bytes());selected=json.loads((r/'historical-selections-reconstructed.json').read_bytes());proof=json.loads((r/'git-proofs.json').read_bytes());report=json.loads((r/'REPORT.json').read_bytes())
for x in hist['records']:
 b=(r/x['local']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
for x in rec['registrations']:assert h((r/x['path']).read_bytes())==x['sha256']
rr=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());assert h(rr)==reg['registry_decompressed_sha256'];registry=json.loads(rr);recovery=json.loads((r/'recovered/MANIFEST.json').read_bytes());assert h((r/'recovered/objects.tar.gz').read_bytes())==reg['recovered_archive_sha256']==recovery['objects_archive_sha256'];assert h((r/'recovered/registry.json.gz').read_bytes())==recovery['registry_gzip_sha256']
qr=gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes());queue=json.loads(qr);assert selected['registry_uncompressed_sha256']==h(rr) and selected['queue_uncompressed_sha256']==h(qr)
for i,x in selected['registry_rows'].items():assert x==registry['files'][int(i)]
for i,x in selected['queue_rows'].items():assert x==queue['entries'][int(i)]
tiny=r/'native/tiny-skia-0.11.4.crate';byte=r/'native/bytemuck-1.25.2.crate';path=r/'native/tiny-skia-path-0.11.4.crate';assert h(tiny.read_bytes())==reg['package']['sha256']
with tarfile.open(tiny,'r:gz') as pkg,tarfile.open(r/'recovered/objects.tar.gz','r:gz') as original:
 for x in reg['rows']:
  b=(r/x['local']).read_bytes();assert h(b)==x['sha256']==registry['files'][x['original_index']]['sha256'] and len(b)==x['bytes'] and len(b.splitlines())==x['eof'];assert pkg.extractfile(x['package_member']).read()==b==original.extractfile(x['sha256']).read()
 assert original.extractfile(reg['historical_lock']['sha256']).read()==(r/'support/pr-working-Cargo.lock').read_bytes()
for i,x in enumerate(ns['entries']):
 p=tiny if i==0 else byte;assert h(p.read_bytes())==x['package_sha256'];b=(r/x['local']).read_bytes();assert h(b)==x['sha256'] and len(b.splitlines())==x['eof']
 with tarfile.open(p,'r:gz') as t:assert t.extractfile(x['package_member']).read()==b
assert h(path.read_bytes())==ps['package_sha256']==pl['archive_sha256']
with tarfile.open(path,'r:gz') as t:
 for x,key in [(ps,'package_member'),(pl,'member')]:
  b=(r/x['local']).read_bytes();assert h(b)==x['sha256'] and t.extractfile(x[key]).read()==b
for lock in ['support/project-0.source','support/pr-working-Cargo.lock']:
 d=tomllib.loads((r/lock).read_text());entries=[x for x in d['package'] if x['name']=='tiny-skia' and x['version']=='0.11.4'];assert len(entries)==1 and entries[0]['checksum']==h(tiny.read_bytes()) and entries[0]['source']=='registry+https://github.com/rust-lang/crates.io-index'
d=tomllib.loads((r/'support/project-0.source').read_text())
for name,version,pkg in [('bytemuck','1.25.2',byte),('tiny-skia-path','0.11.4',path)]:
 x=next(x for x in d['package'] if x['name']==name and x['version']==version);assert x['checksum']==h(pkg.read_bytes())
for x in rec['assigned_roles']+rec['support_reads']:
 b=(r/x['source']).read_bytes();assert len(b.splitlines())==x['eof'];occ=[]
 for lo,hi in x['display_union']+x['unread_complement']:
  assert 1<=lo<=hi<=x['eof'];occ.extend(range(lo,hi+1))
 assert len(occ)==x['eof'] and set(occ)==set(range(1,x['eof']+1))
for x in rec['assigned_roles']:
 a=next(y for y in reg['rows'] if y['original_index']==x['index']);assert x['display_union']==a['prospective_ranges']
for x in reg['current_support'][1:]:assert next(y for y in rec['support_reads'] if y['source']==x['local'])['display_union']==x['prospective_ranges']
for x in ns['entries']:assert next(y for y in rec['support_reads'] if y['source']==x['local'])['display_union']==x['prospective_ranges']
for x in [ps,pl]:assert next(y for y in rec['support_reads'] if y['source']==x['local'])['display_union']==x['prospective_ranges']
rows=[json.loads(l) for l in (r/'historical/774/00-additional-sources.jsonl').read_text().splitlines()];assert rows[86]['source_id']==reg['rows'][1]['source_id'] and rows[87]['source_id']==reg['rows'][0]['source_id'];assert rows[86]['read_ranges']==rec['assigned_roles'][1]['historical_rig_owner'] and rows[87]['read_ranges']==rec['assigned_roles'][0]['historical_rig_owner']
coverage=[json.loads(l) for l in (r/'historical/059/evidence/audit11/inherited-coverage.jsonl').read_text().splitlines()];assert coverage[25]['ranges']==[[46,47]] and coverage[26]['ranges']==[[155,182],[385,430]]
adler=json.loads((r/'historical/059/adler/READ-L11-328.json').read_bytes());a=next(x for x in adler['connected_reinspection'] if x.get('original_index')==26);assert a['fresh_reads']==[[155,182],[385,430]] and a['additional_original_frontier_credit']==0
objs={}
for k,x in proof['objects'].items():
 b=gzip.decompress((r/x['preserved']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'] and oid(x['type'],b)==k;objs[k]=b
def lookup(b,name):
 i=0
 while i<len(b):
  z=b.index(b'\0',i);mode,n=b[i:z].split(b' ',1);child=b[z+1:z+21].hex();i=z+21
  if n.decode()==name:return mode.decode(),child
 raise KeyError(name)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for node in x['chain']:
  assert tree==node['tree'];mode,child=lookup(objs[tree],node['name']);assert mode==node['mode'] and child==node['object'];tree=child
 b=(r/x['local']).read_bytes();assert oid('blob',b)==tree==x['blob'] and h(b)==x['sha256']
assert len(report['lens_perspectives'])==13 and report['implementation']=='not started'
if (r/'MANIFEST.json').exists():
 manifest=json.loads((r/'MANIFEST.json').read_bytes());files={str(x.relative_to(r)) for x in r.rglob('*') if x.is_file() and x!=r/'MANIFEST.json'};assert files=={x['path'] for x in manifest['files']}
 for x in manifest['files']:
  b=(r/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
print('PASS: 3 native archive/lock identities, 2 original native roles, historical source/reader scopes, 13 offline Git membership chains, exact read partitions and 13 bounded perspectives; packet manifest when present. No image/product execution.')
