from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');old=Path('<LOCAL_PATH_1>');prev=Path('<LOCAL_PATH_2>');ws=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def save(raw,local,origin,kind,**kw):
 p=r/local;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);records.append({'origin':str(origin),'local':local,'sha256':h(raw),'bytes':len(raw),'kind':kind,**kw})
def cp(p,local,kind):save(Path(p).read_bytes(),local,p,kind)
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz']:cp(prev/'recovered'/n,'recovered/'+n,'Recovered original registry and queue bytes in retained transport; catalog and gzip wrapper may be reconstructed.')
archives=[('tiny-skia-0.11.4',pub/'native-evidence/tiny-skia-0.11.4/tiny-skia-0.11.4.crate'),('bytemuck-1.25.2',Path('<LOCAL_PATH_4>')),('tiny-skia-path-0.11.4',Path('<LOCAL_PATH_5>'))]
for name,src in archives:cp(src,'native/'+name+'.crate','Exact native archive bound to 95e Cargo.lock checksum; source archive not executed.')
for n in ['evidence/audit11/inherited-coverage.jsonl','adler/READ-L11-328.json','adler/REGISTRATION-ADLER-977.json']:
 cp(old/n,'historical/059/'+n,'Exact original 059 material; original reader, scope and revision retained.')
for n in ['COVERAGE-L01-ROLES.json','ASSESSMENT-WEAPON-IDENTITY-95E.json']:
 cp(pub/n,'prior/'+n,'Central earlier source assessment/coverage; no independent-read attribution transferred.')
prior=Path('<LOCAL_PATH_6>')
for n in ['REPORT.json','MANIFEST.json','personal-read-receipt.json']:cp(prior/n,'prior/screen-armor/'+n,'Earlier /root/rig_identity packet; no reading credit transferred.')
for n in ['AGENTS.md','crates/AGENTS.md']:cp(ws/n,'rules/'+n,'Repository rules; user prohibition of product validation remains controlling.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';base='handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/'
paths=['audit-existing-type-owners/rig/additional-sources.jsonl','audit-existing-type-owners/rig/contracts.jsonl','audit-existing-type-owners/rig/findings.jsonl','producer-supplement-after-owner/rig/traces.jsonl','producer-supplement-after-owner/rig/findings.jsonl']
for i,n in enumerate(paths):
 gp=base+n;raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+gp]);save(raw,f'historical/774/{i:02d}-{Path(n).name}','git:'+rev+':'+gp,'Exact original 774 rig record; f82 is evidence transport only.',transport_revision=rev,git_path=gp)
rr=gzip.decompress((r/'recovered/registry.json.gz').read_bytes());reg=json.loads(rr);qr=gzip.decompress((r/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qr);cat=json.loads((r/'recovered/catalog-774.json').read_bytes());cov=json.loads((r/'prior/COVERAGE-L01-ROLES.json').read_bytes());ids=[25,26,497];qs=[123,124,1791]
selected={'kind':'Newly reconstructed navigation selection, not an original record. Original queue, registry and catalog are retained.','registry_uncompressed_sha256':h(rr),'queue_uncompressed_sha256':h(qr),'registry_rows':{str(i):reg['files'][i] for i in ids},'catalog_rows':{str(i):cat['rows'][i] for i in [25,26]},'coverage_rows':{str(i):cov['roles'][i] for i in [25,26]},'queue_rows':{str(i):q['entries'][i] for i in qs},'qualification':'Earlier historical findings and scopes are not checkpoint3821; f82 only transports evidence.'}
(r/'historical-selections-reconstructed.json').write_text(json.dumps(selected,indent=2)+'\n')
(r/'historical-manifest.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'qualification':'Original records, recovered archives and newly reconstructed selections are distinct; no audit coverage follows from byte recovery alone.'},indent=2)+'\n')
cmds=[['git','-C',str(pub),'grep','-l','-e','tiny_skia','-e','PixmapRef','-e','PixmapMut','95e63628f9d70b8dd6e6fede64334696c6995009','--','crates',':!crates/adventuresim-stdb-client/src'],['git','-C',str(pub),'grep','-n','-F','.pixel(','95e63628f9d70b8dd6e6fede64334696c6995009','--','crates/adventuresim-weapon-model'],['rg','-n','-F','LengthU32','<LOCAL_PATH_7>','--glob','*.rs']]
nav=[]
for cmd in cmds:
 x=subprocess.run(cmd,capture_output=True,text=True);assert x.returncode in (0,1);nav.append({'argv':cmd,'exit_code':x.returncode,'stdout':x.stdout,'stderr':x.stderr})
(r/'navigation-results.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':nav,'qualification':'Match-only/filename navigation; no body read credit and no exclusion of aliases, generated sources or external callers.'},indent=2)+'\n')
print('retained',len(records),'historical manifest',h((r/'historical-manifest.json').read_bytes()))
