from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
r=Path(__file__).resolve().parent
d={'registered_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','revision':'95e63628f9d70b8dd6e6fede64334696c6995009','scope':'filename-only literal search for direct project tiny_skia, PixmapRef and PixmapMut references, plus match-only search for .pixel( in weapon-model; symbol-name navigation in exact pinned bytemuck and tiny-skia color source; no body/role credit','qualification':'Search cannot prove absence through aliases, macros, generated sources, dependency callers or renamed receiver types. Any later full-body display must be separately registered.'}
with (r/'navigation-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
print(d['registered_utc'],hashlib.sha256((r/'navigation-registration.json').read_bytes()).hexdigest())
