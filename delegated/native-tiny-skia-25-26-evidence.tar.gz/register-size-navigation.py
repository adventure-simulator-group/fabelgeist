from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
r=Path(__file__).resolve().parent;d={'registered_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Filename and line-number navigation only in exact tiny-skia-path 0.11.4 package to locate LengthU32 owner; any full-body displays separately registered.','qualification':'Search results do not imply whole-file or ordered-role coverage.'}
with (r/'size-navigation-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
print(d['registered_utc'],hashlib.sha256((r/'size-navigation-registration.json').read_bytes()).hexdigest())
