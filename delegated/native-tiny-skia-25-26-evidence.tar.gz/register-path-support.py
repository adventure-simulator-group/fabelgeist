from pathlib import Path
import datetime,hashlib,json,tarfile,tomllib
r=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();archive=Path('<LOCAL_PATH_0>');lock=(r/'support/project-0.source').read_bytes();row=next(x for x in tomllib.loads(lock.decode())['package'] if x['name']=='tiny-skia-path' and x['version']=='0.11.4');assert h(archive.read_bytes())==row['checksum']
with tarfile.open(archive,'r:gz') as t:b=t.extractfile('tiny-skia-path-0.11.4/src/size.rs').read()
d={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reader':'/root/hair_ops','package':'tiny-skia-path 0.11.4','archive':str(archive),'package_sha256':h(archive.read_bytes()),'package_member':'tiny-skia-path-0.11.4/src/size.rs','local':'support/native-path-size.rs','sha256':h(b),'eof':len(b.splitlines()),'prospective_ranges':[[1,len(b.splitlines())]],'current_lock_local':'support/project-0.source','current_lock_additional_range':[10490,10503],'qualification':'Pinned dependency support only, no original ordered-role credit. No source or image execution.'}
with (r/'path-support-registration.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
(r/d['local']).write_bytes(b);print(d['registered_utc'],h((r/'path-support-registration.json').read_bytes()),d['sha256'],d['eof'])
