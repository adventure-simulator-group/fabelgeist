# Delegated MHR and mesh metadata audit

This evidence packet covers assigned historical roles 2312–2315 at current
revision `95e63628f9d70b8dd6e6fede64334696c6995009` and historical revision
`6533e444fa37552927070cc8d8190907fd3b413e`. See `report.json` for bounded
findings, source references, thirteen lens perspectives, open questions, and
historical relationships. This packet does not assert lens closure, ordered
role credit, repair ownership, or checkpoint 3821 provenance.

The assigned manifests and README were personally displayed in full at both
revisions. Both complete Cargo.lock files were archived with exact bytes,
hashes, and Git membership proofs, but personal display covered only 198 of
7,102 current lines and 195 of 7,093 historical lines. Consequently, 6,904
current lines and 6,898 historical lines remain unread in this assessment.
`lock-read-coverage.json` distinguishes actual displays from unread ranges;
`lock-package-index.json` records a separate metadata-only location scan.
Archival, hashing, Git membership, and scanning do not confer read credit.
Prospective registrations and actual receipts are retained separately.

Support files are separately registered and receive credit only for the
personally displayed ranges recorded in their receipts. Three source bodies
from intermediate revision `e2755a732c84e67296b5e3441a4259a84f461b2f`
are preserved for historical comparison, not newly credited as full personal
displays. The original 059 records and the complete original compressed queue,
registry, and transport manifest remain distinct from derived navigation
subsets. Earlier historical full lock reads retain the original reviewers,
revisions, and partial-receipt ranges; they do not expand this assessment's
personal read scope or establish checkpoint 3821 content. Older 774 originals
and distinct normalized exports retain their separate hashes and attribution.
Prior model-audit material is included only as linked earlier evidence.

`evidence-verification.json` records evidence-only verification, and
`BUNDLE-MANIFEST.json` inventories packet files by SHA-256 and size. Git object
proofs establish archived bodies' membership in their stated revisions. No
product implementation, Cargo command, build, test, fixture, runtime probe,
browser, simulation, or product validation was performed. Historical materials
may contain local paths and require review and appropriate redaction before
external publication, while preserving original hashes and provenance.
