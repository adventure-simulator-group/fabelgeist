import gzip,hashlib,json,pathlib,re
p=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
reg=json.loads((p/'registration.json').read_text());sreg=json.loads((p/'support-registration.json').read_text());extra=json.loads((p/'extra-support-registration.json').read_text());archive=json.loads((p/'archive-support-registration.json').read_text());e275=json.loads((p/'historical-e275-archive-index.json').read_text());entries=sum((x['sources'] for x in [reg,sreg,extra,archive,e275]),[])
for e in entries:
 b=(p/e['source_file']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob_sha1'],e['bytes'],e['lines'])
for a,b in [('registration.json','read-receipt.json'),('support-registration.json','support-read-receipt.json'),('extra-support-registration.json','extra-support-read-receipt.json'),('fs-context-registration.json','fs-context-read-receipt.json'),('archive-support-registration.json','archive-support-read-receipt.json')]:
 x=json.loads((p/a).read_text());y=json.loads((p/b).read_text());
 for e,z in zip(x['sources'],y['actual_source_displays'],strict=True):
  assert all(e[k]==z[k] for k in ('kind','revision','path','source_file','sha256')); assert z['ranges']==e['planned_display_ranges']
lock=json.loads((p/'lock-registration.json').read_text());rr=json.loads((p/'read-receipt.json').read_text())
for e,z in zip(lock['sources'],rr['additional_lock_displays'],strict=True):
 assert all(e[k]==z[k] for k in ('kind','revision','path','source_file','sha256'));assert e['planned_display_ranges']==z['ranges']
allowed={}
for fname in ['read-receipt.json','support-read-receipt.json','extra-support-read-receipt.json','fs-context-read-receipt.json','archive-support-read-receipt.json']:
 r=json.loads((p/fname).read_text());allreads=r['actual_source_displays']+r.get('additional_lock_displays',[])
 for e in allreads:
  if e['revision']=='95e63628f9d70b8dd6e6fede64334696c6995009':allowed.setdefault(e['path'],[]).extend(e['ranges'])
report=json.loads((p/'report.json').read_text());refs=[]
def walk(x):
 if isinstance(x,dict):
  if {'revision','path','lines'}<=x.keys() and isinstance(x['lines'],list):refs.append(x)
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(report)
for r in refs:
 assert r['revision']==report['current_revision'] and r['path'] in allowed,r
 for lo,hi in r['lines']:assert any(a<=lo<=hi<=b for a,b in allowed[r['path']]),r
cov=json.loads((p/'lock-read-coverage.json').read_text())
for c in cov['sources']:
 r=next(x for x in reg['sources'] if x['kind']==c['kind'] and x['original_role_index']==2313);l=next(x for x in lock['sources'] if x['kind']==c['kind']);intervals=sorted(r['planned_display_ranges']+l['planned_display_ranges']);merged=[]
 for lo,hi in intervals:
  if merged and lo<=merged[-1][1]+1:merged[-1][1]=max(merged[-1][1],hi)
  else:merged.append([lo,hi])
 assert merged==c['personally_displayed_union'];remaining=[];pos=1
 for lo,hi in merged:
  if pos<lo:remaining.append([pos,lo-1])
  pos=hi+1
 if pos<=r['lines']:remaining.append([pos,r['lines']])
 assert remaining==c['unread_ranges'] and sum(b-a+1 for a,b in remaining)==c['unread_lines']
ix=json.loads((p/'lock-package-index.json').read_text())
for rec in ix['package_blocks']:
 lines=(p/f"{rec['kind']}-2313.source").read_text().splitlines();a,b=rec['lines'];assert lines[a-1]=='[[package]]' and f"name = \"{rec['package_name']}\"" in lines[a-1:b];assert b==len(lines) or lines[b]=='[[package]]'
proof=json.loads((p/'git-proofs.json').read_text());cache={}
for f in (p/'git-objects').iterdir():
 oid,typ=f.name.split('.');b=f.read_bytes();assert hashlib.sha1((typ+' '+str(len(b))+'\0').encode()+b).hexdigest()==oid;cache[(oid,typ)]=b
def tree_entries(data):
 pos=0;d={}
 while pos<len(data):
  nul=data.index(b'\0',pos);mode,name=data[pos:nul].split(b' ',1);oid=data[nul+1:nul+21].hex();d[name.decode()]=(mode.decode(),oid);pos=nul+21
 assert pos==len(data);return d
for e in proof['proofs']:
 assert cache[(e['revision'],'commit')].split(b'\n',1)[0]==b'tree '+e['commit_tree'].encode();tree=e['commit_tree'];names=[]
 for a in e['membership']:
  assert a['parent_tree']==tree and tree_entries(cache[(tree,'tree')])[a['entry']]==(a['mode'].lstrip('0'),a['object']);tree=a['object'];names.append(a['entry'])
 assert '/'.join(names)==e['path'];assert tree==e['blob_sha1']==blob((p/e['source_file']).read_bytes())
assert len(proof['proofs'])==len(entries)
h=json.loads((p/'historical-059-index.json').read_text());mr=(p/'historical-inputs/original-transport-manifest.json.gz').read_bytes();assert sha(mr)==h['transport_manifest_sha256'];lookup={e['path']:e for e in json.loads(gzip.decompress(mr))['entries']}
for e in h['records']:
 b=(p/e['copy']).read_bytes();assert (sha(b),blob(b),len(b))==(e['sha256'],e['git_blob'],e['bytes']);assert all(lookup[e['path']][k]==e[k] for k in ('sha256','git_blob','bytes'))
raw=(p/'historical-inputs/original-registry.json.gz').read_bytes();dec=gzip.decompress(raw);original=json.loads(dec);sub=json.loads((p/'historical-registry-subset.json').read_text());assert (sha(raw),sha(dec))==(sub['source_registry_gzip_sha256'],sub['source_registry_decompressed_sha256'])
for i in (2312,2313,2314,2315):
 assert original['files'][i]==sub['roles'][str(i)];assert next(e for e in reg['sources'] if e['kind']=='historical' and e['original_role_index']==i)['sha256']==original['files'][i]['sha256']
qb=gzip.decompress((p/'historical-inputs/059-queue-original-bytes.json.gz').read_bytes());q=json.loads(qb);qs=json.loads((p/'historical-queue-subset.json').read_text());assert sha(qb)==qs['source_sha256']
for e in qs['entries']:assert e['entry']==q['entries'][e['queue_index']]
o=json.loads((p/'older-774/INDEX.json').read_text());mraw=(p/o['export_manifest_copy']).read_bytes();assert sha(mraw)==o['export_manifest_sha256'];ol={z['file']:z for z in json.loads(mraw)['files']}
for e in o['records']:
 assert ol[e['manifest_entry']['file']]==e['manifest_entry'];assert sha((p/e['original_copy']).read_bytes())==e['original_sha256']==e['manifest_entry']['original_record_sha256']
 if e['export_differs']:assert sha((p/e['normalized_copy']).read_bytes())==e['normalized_sha256']==e['manifest_entry']['published_export_sha256']
prior=json.loads((p/'prior-support-index.json').read_text())
for e in prior['records']:
 b=(p/e['copy']).read_bytes();assert sha(b)==e['sha256'] and len(b)==e['bytes']
oldmanifest=json.loads((p/'prior-model-audit/BUNDLE-MANIFEST.json').read_text());oldrows={x['path']:x for x in oldmanifest['files']}
for e in prior['records']:
 if e['original_path']!='BUNDLE-MANIFEST.json':assert oldrows[e['original_path']]['sha256']==e['sha256']
result={'kind':'Evidence-only consistency verification','status':'passed','ordered_archived_bodies':len(reg['sources']),'current_support_bodies':len(sreg['sources'])+len(extra['sources'])+len(archive['sources']),'historical_e275_archival_bodies':len(e275['sources']),'report_source_refs_within_actual_displays':len(refs),'lock_current_unread_lines':next(x['unread_lines'] for x in cov['sources'] if x['kind']=='current'),'lock_historical_unread_lines':next(x['unread_lines'] for x in cov['sources'] if x['kind']=='historical'),'git_membership_proofs':len(proof['proofs']),'git_commit_tree_objects':len(cache),'original_059_records':len(h['records']),'historical_queue_selected_entries':len(qs['entries']),'older_774_originals':len(o['records']),'distinct_normalized_exports':sum(x['export_differs'] for x in o['records']),'prior_audit_selected_records':len(prior['records']),'qualification':'Evidence-only checks. No product implementation, Cargo command, build, test, fixture, runtime probe, browser, simulation or product validation.'}
(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
