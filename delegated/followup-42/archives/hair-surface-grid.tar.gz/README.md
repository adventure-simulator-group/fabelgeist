# Hair surface and grid evidence transport

This local stage carries a privacy-reconstructed copy of the frozen review of
original roles 2643 and 2644. The report, read receipts, source bytes, historical
records and Git proofs retain their revisions and authors. The original packet
manifest is a historical identity: it does not validate redacted public bytes.
`EVIDENCE-IDENTITIES.json` and `HISTORICAL-ASSERTION-CROSSWALK.json` record
original and public identities and the path substitutions. Exact originals are
retained in a separate restricted collection, not included here.

`HISTORICAL-RELATIONSHIPS.json` preserves the 774 rig records, the two different
059 queue snapshots, working and committed baseline observations, and the
unchecked temporary-helper pathname incident. Older findings are not promoted
to checkpoint 3821. Alias, count, producer reachability and full audit closure
remain open.

The five exact Git commit objects under `proof-metadata/` retain author and
committer identifiers. Three were previously matched against a locally retained
published archive; the public status of the other two was not independently
checked. `GIT-COMMIT-METADATA.json` gives the recorded qualification.

Run `python3 verify-transport.py` for a read-only check of this stage only.
Twenty Git proofs have exact public leaf bytes; the older 059 queue leaf is
redacted, so its original tree relationship is a qualified crosswalk. The
original packet scripts are included solely as evidence text and are not the
public verifier. A separate restricted verifier compares the exact originals to
the reconstructed members. Verification does not execute or validate product
behavior, prove privacy completeness, or prove source-level conclusions.
