#!/usr/bin/env python3
"""Write the manifest for this new stage only."""
import pathlib,json,datetime,hashlib
P=pathlib.Path(__file__).resolve().parent
files=[]
for p in sorted(P.rglob('*')):
 assert not p.is_symlink()
 if p.is_file() and p!=P/'MANIFEST.json':
  d=p.read_bytes();files.append({'path':p.relative_to(P).as_posix(),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
x={'schema':'726-hair-surface-grid-public-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_manifest_sha256':'a630eef1c5146230b2a8a299b6e7af632f51d5271a2d10bfa1e5b0e570370a45','files':files,'qualification':'Public stage identity, not an assertion that redacted members equal their restricted originals. The manifest excludes itself.'}
d=(json.dumps(x,indent=2)+'\n').encode()
with (P/'MANIFEST.json').open('xb') as f:f.write(d)
print(json.dumps({'manifest_sha256':hashlib.sha256(d).hexdigest(),'manifest_members':len(files)}))
