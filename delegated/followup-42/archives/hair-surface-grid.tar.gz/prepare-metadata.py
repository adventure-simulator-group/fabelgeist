#!/usr/bin/env python3
"""Generate public crosswalk metadata in the new public stage only."""
import pathlib,json,hashlib
P=pathlib.Path(__file__).resolve().parent
idx=json.loads((P/'EVIDENCE-IDENTITIES.json').read_bytes());rows=[r for r in idx['members'] if r['redactions']]
assert len(rows)==7
assertions={
 'REPORT.json':['bundle/MANIFEST.json#/files'],
 'build-git-proofs.py':['bundle/MANIFEST.json#/files'],
 'create-report.py':['bundle/MANIFEST.json#/files'],
 'registration-builder.py':['bundle/MANIFEST.json#/files'],
 'historical/prior-059-selected-records-reconstructed.json':['bundle/MANIFEST.json#/files','bundle/reference/prior-MANIFEST.json#/files'],
 'reference/prior-historical-manifest.json':['bundle/MANIFEST.json#/files','bundle/reference/prior-MANIFEST.json#/files'],
 'historical/baseline-059-queue-committed-2e1f.json.gz':['bundle/MANIFEST.json#/files','bundle/git-proofs.json#/proofs','bundle/historical/prior-059-selected-records-reconstructed.json#/queue_sha256']}
cross={'schema':'726-hair-surface-grid-historical-assertion-crosswalk-v1','source_manifest_sha256':idx['source_manifest_sha256'],'qualification':'Original assertions continue to refer to exact restricted originals; public reconstructions are not byte-identical. The public verifier checks the stored crosswalk and retained Git tree identity, but without restricted originals cannot independently reproduce or prove the redacted-byte transformation. The restricted verifier checks it locally.','members':[]}
for r in rows:
 assert r['source_path'] in assertions
 cross['members'].append({'source_path':r['source_path'],'public_path':r['public_path'],'original_stored_sha256':r['original_stored_sha256'],'original_decoded_sha256':r['original_decoded_sha256'],'public_stored_sha256':r['public_stored_sha256'],'public_decoded_sha256':r['public_decoded_sha256'],'original_assertion_locations':assertions[r['source_path']],'redaction_count':len(r['redactions'])})
p=P/'HISTORICAL-ASSERTION-CROSSWALK.json'
with p.open('x') as f:json.dump(cross,f,indent=2);f.write('\n')
