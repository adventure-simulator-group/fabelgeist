#!/usr/bin/env python3
"""Read-only packet integrity and provenance checks. No Git, old packet or product code is run."""
import gzip,hashlib,json,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def fail(m):raise ValueError(m)
def read(rel):
 p=pathlib.PurePosixPath(rel)
 if p.is_absolute() or '..' in p.parts:fail('unsafe relative path')
 q=P.joinpath(*p.parts)
 if q.is_symlink() or not q.is_file():fail('missing or linked file: '+rel)
 return q.read_bytes()
def load(rel):return json.loads(read(rel))
def obj(oid,typ):
 m=g['objects'][oid]; assert m['type']==typ
 d=gzip.decompress(read(m['file'])); assert len(d)==m['bytes'] and H(d)==m['sha256']
 assert hashlib.sha1((typ+' '+str(len(d))+'\0').encode()+d).hexdigest()==oid
 return d
def parse_tree(raw):
 out={};i=0
 while i<len(raw):
  j=raw.index(b' ',i);k=raw.index(b'\0',j+1);mode=raw[i:j].decode('ascii');name=raw[j+1:k].decode('utf-8');oid=raw[k+1:k+21].hex()
  assert len(raw[k+1:k+21])==20 and name not in out
  out[name]=(mode,oid);i=k+21
 return out
m=load('MANIFEST.json'); expected={x['path']:x for x in m['files']};assert len(expected)==len(m['files']);actual=set()
for p in P.rglob('*'):
 assert not p.is_symlink(), 'symlink is outside evidence scope'
 if p.is_file() and p!=P/'MANIFEST.json':actual.add(p.relative_to(P).as_posix())
assert actual==set(expected),(sorted(set(expected)-actual),sorted(actual-set(expected)))
for p,entry in expected.items():
 d=read(p);assert len(d)==entry['bytes'] and H(d)==entry['sha256'],p
reg=load('registration.json'); ext=load('registration-support-extension.json'); receipt=load('personal-read-receipt.json')
assert len(receipt['sources'])==len(reg['sources'])+len(ext['sources'])
for q in receipt['registrations']:assert H(read(q['path']))==q['sha256']
for r in reg['sources']:
 d=read(r['source_file'])
 if r['kind']=='774-historical-records':
  assert H(d)==r['stored_sha256'];d=gzip.decompress(d);assert H(d)==r['decoded_sha256']
 else:assert H(d)==r['sha256']
 assert len(d.splitlines())==r['eof']
 for a,b in r['registered_ranges']:assert 1<=a<=b<=r['eof']
for r in ext['sources']:
 d=read(r['source_file']);assert H(d)==r['sha256'] and len(d.splitlines())==r['eof']
 assert hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()==r['git_blob_sha1']
 for a,b in r['ranges']:assert 1<=a<=b<=r['eof']
for r in receipt['sources']:
 assert r['registered_ranges']==r['personally_displayed_ranges']
 covered=set(j for a,b in r['registered_ranges'] for j in range(a,b+1))
 d=read(r['source_file']);d=gzip.decompress(d) if r['source_file'].endswith('.gz') else d
 complement=set(j for a,b in r['unread_complement'] for j in range(a,b+1))
 assert not covered.intersection(complement) and covered.union(complement)==set(range(1,len(d.splitlines())+1))
g=load('git-proofs.json')
for oid,v in g['objects'].items():obj(oid,v['type'])
for proof in g['proofs']:
 commit=obj(proof['revision'],'commit'); first=commit.split(b'\n',1)[0].decode();assert first.startswith('tree '); tree=first[5:]
 names=proof['path'].split('/');assert len(names)==len(proof['chain'])
 for i,(name,step) in enumerate(zip(names,proof['chain'])):
  assert step['tree']==tree and step['name']==name
  mode,oid=parse_tree(obj(tree,'tree'))[name];assert mode==step['mode'] and oid==step['object']
  assert (i==len(names)-1 and mode in ('100644','100755')) or (i<len(names)-1 and mode=='40000')
  tree=oid
 d=read(proof['local']);d=gzip.decompress(d) if proof['compression']=='gzip' else d
 assert H(d)==proof['sha256'] and hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()==tree==proof['blob']
registry=json.loads(gzip.decompress(read('historical/original-registry.json.gz')))
for role in (2643,2644):
 rr=next(x for x in reg['sources'] if x.get('role')==role and x['identity'].startswith('recovered'))
 old=registry['files'][role];assert old['snapshot']=='pr-working' and old['sha256']==rr['sha256'] and old['material_ranges']==rr['original_material']
prior=load('reference/prior-MANIFEST.json');assert H(read('reference/prior-MANIFEST.json'))==reg['prior_manifest_sha256']
prior_map={x['path']:x for x in prior['files']};checked=0
for p in (P/'historical').glob('prior-*'):
 prior_path='historical/'+p.name[len('prior-'):];assert prior_path in prior_map
 d=p.read_bytes();assert len(d)==prior_map[prior_path]['bytes'] and H(d)==prior_map[prior_path]['sha256'];checked+=1
for name in ('REPORT.json','read-receipt.json','registration.json','historical-manifest.json','git-proofs.json'):
 d=read('reference/prior-'+name);q=prior_map[name];assert len(d)==q['bytes'] and H(d)==q['sha256'];checked+=1
oldq=json.loads(gzip.decompress(read('historical/baseline-059-queue-committed-2e1f.json.gz')))['entries'];newq=json.loads(gzip.decompress(read('historical/baseline-059-queue-committed-d7.json.gz')))['entries']
sel=load('historical/prior-059-selected-records-reconstructed.json');comparison=load('selected-queue-comparison.json')
assert H(gzip.decompress(read('historical/baseline-059-queue-committed-2e1f.json.gz')))==sel['queue_sha256']==comparison['old_decoded_sha256']
assert H(gzip.decompress(read('historical/baseline-059-queue-committed-d7.json.gz')))==comparison['later_decoded_sha256']
assert len(sel['queue_rows'])==len(comparison['rows'])==7
for s,c in zip(sel['queue_rows'],comparison['rows']):
 n=s['index'];assert n==c['index'] and s['entry']==oldq[n]==newq[n] and c['id']==oldq[n]['contract_id'] and c['equal_json_value']
w=gzip.decompress(read('reference/working-baseline.json.gz'));c=gzip.decompress(read('reference/committed-baseline.json.gz'))
assert H(w)==reg['working_baseline']['decoded_sha256'] and H(c)==reg['committed_baseline']['decoded_sha256'] and w!=c
ww=json.loads(w)['newly_assessed_ledger']['entries'];cc=json.loads(c)['newly_assessed_ledger']['entries']
for relation in reg['selected_ledger_relations']:
 a=int(relation['working_pointer'].split('/')[-1]);b=int(relation['committed_pointer'].split('/')[-1]);assert ww[a]==cc[b] and ww[a]['id']==relation['id'] and relation['selected_entry_equal']
for id in ('REVIEW-HAIR-SURFACE-ZERO-AREA-SHARE-95E','QUESTION-HAIR-SURFACE-BOUNDARY-STEP-FLOOR-95E'):
 assert not any(x.get('id')==id for x in ww) and not any(x.get('id')==id for x in cc)
print(json.dumps({'status':'PASS','manifest_files':len(expected),'raw_git_objects':len(g['objects']),'independent_git_proofs':len(g['proofs']),'prior_manifest_members_checked':checked,'selected_historical_queue_rows_equal':len(comparison['rows']),'selected_current_entries_equal':len(reg['selected_ledger_relations']),'qualification':'Integrity/identity only; source reasoning, read claims, privacy, caller reachability and product behavior are not validated.'},indent=2))
