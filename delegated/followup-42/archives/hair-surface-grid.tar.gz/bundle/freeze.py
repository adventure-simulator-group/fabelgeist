#!/usr/bin/env python3
"""Build manifest for this fresh packet only; do not run on frozen prior packets."""
import datetime,hashlib,json,pathlib
P=pathlib.Path(__file__).resolve().parent
files=[]
for p in sorted(P.rglob('*')):
 if p.is_symlink():raise ValueError('symlink not allowed')
 if p.is_file() and p!=P/'MANIFEST.json':
  d=p.read_bytes();files.append({'path':p.relative_to(P).as_posix(),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
x={'schema':'726-followup-evidence-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/hair_ops','files':files,'qualification':'This local packet retains original source and historical records, commit author metadata and local path references. Privacy review is required before public transport. The manifest does not include itself.'}
d=(json.dumps(x,indent=2)+'\n').encode();(P/'MANIFEST.json').write_bytes(d)
print(json.dumps({'files':len(files),'manifest_sha256':hashlib.sha256(d).hexdigest()}))
