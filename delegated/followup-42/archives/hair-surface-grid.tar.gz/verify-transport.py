#!/usr/bin/env python3
"""Read-only public evidence integrity and qualified proof checks; no product code."""
import gzip,hashlib,json,pathlib
P=pathlib.Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def read(rel):
 p=pathlib.PurePosixPath(rel);assert not p.is_absolute() and '..' not in p.parts
 q=P.joinpath(*p.parts);assert q.is_file() and not q.is_symlink();return q.read_bytes()
def load(rel):return json.loads(read(rel))
def tree_entries(raw):
 out={};i=0
 while i<len(raw):
  j=raw.index(b' ',i);k=raw.index(b'\0',j+1);name=raw[j+1:k].decode('utf-8');mode=raw[i:j].decode('ascii');oid=raw[k+1:k+21].hex();assert name not in out and len(raw[k+1:k+21])==20;out[name]=(mode,oid);i=k+21
 return out
manifest=load('MANIFEST.json');ms={x['path']:x for x in manifest['files']};assert len(ms)==len(manifest['files']);actual=set()
for p in P.rglob('*'):
 assert not p.is_symlink()
 if p.is_file() and p!=P/'MANIFEST.json':actual.add(p.relative_to(P).as_posix())
assert actual==set(ms)
for path,v in ms.items():
 d=read(path);assert len(d)==v['bytes'] and H(d)==v['sha256']
index=load('EVIDENCE-IDENTITIES.json');source_manifest=load('bundle/MANIFEST.json');assert H(read('bundle/MANIFEST.json'))==index['source_manifest_sha256']=='a630eef1c5146230b2a8a299b6e7af632f51d5271a2d10bfa1e5b0e570370a45'
orig={x['path']:x for x in source_manifest['files']};rows=index['members'];by={x['source_path']:x for x in rows};assert len(by)==len(rows)==98 and set(by)==set(orig)|{'MANIFEST.json'}
numops=0;changed=0
for r in rows:
 if r['source_path'] in orig:
  old=orig[r['source_path']];assert r['source_manifest_bound'] and r['original_stored_sha256']==old['sha256'] and r['original_stored_bytes']==old['bytes']
 else:assert r['source_top_manifest'] and r['original_stored_sha256']==index['source_manifest_sha256']
 raw=read(r['public_path']);assert len(raw)==r['public_stored_bytes'] and H(raw)==r['public_stored_sha256'];d=gzip.decompress(raw) if r['encoding']=='gzip' else raw
 assert len(d)==r['public_decoded_bytes'] and H(d)==r['public_decoded_sha256']
 if not r['redactions']:
  assert r['status']=='exact-copy' and r['original_stored_sha256']==r['public_stored_sha256'] and r['original_decoded_sha256']==r['public_decoded_sha256']
 else:
  changed+=1;assert r['status']=='privacy-reconstructed';delta=0;end=-1
  for op in r['redactions']:
   orig_start=op['original_decoded_offset_0based'];assert orig_start>=end;token=op['public_placeholder'].encode();position=op['public_decoded_offset_0based'];assert position==orig_start-delta and d[position:position+len(token)]==token;end=orig_start+op['original_decoded_bytes'];delta+=op['original_decoded_bytes']-len(token);numops+=1
  assert len(d)==r['original_decoded_bytes']-delta
assert changed==7 and numops==57
cross=load('HISTORICAL-ASSERTION-CROSSWALK.json');crossmap={x['source_path']:x for x in cross['members']};assert set(crossmap)=={r['source_path'] for r in rows if r['redactions']}
for name,q in crossmap.items():
 r=by[name];assert all(q[x]==r[x] for x in ['public_path','original_stored_sha256','original_decoded_sha256','public_stored_sha256','public_decoded_sha256']) and q['redaction_count']==len(r['redactions'])
g=load('bundle/git-proofs.json')
def git_obj(oid,typ):
 v=g['objects'][oid];assert v['type']==typ;r=by[v['file']];assert r['status']=='exact-copy';raw=gzip.decompress(read(r['public_path']));assert len(raw)==v['bytes'] and H(raw)==v['sha256'];assert hashlib.sha1((typ+' '+str(len(raw))+'\0').encode()+raw).hexdigest()==oid;return raw
for oid,v in g['objects'].items():git_obj(oid,v['type'])
qualified=[];exact=0
for proof in g['proofs']:
 commit=git_obj(proof['revision'],'commit');header=commit.split(b'\n',1)[0].decode();assert header.startswith('tree ');tree=header[5:];names=proof['path'].split('/');assert len(names)==len(proof['chain'])
 for i,(name,step) in enumerate(zip(names,proof['chain'])):
  assert step['tree']==tree and step['name']==name;mode,oid=tree_entries(git_obj(tree,'tree'))[name];assert step['mode']==mode and step['object']==oid
  assert (i==len(names)-1 and mode in ('100644','100755')) or (i<len(names)-1 and mode=='40000');tree=oid
 r=by[proof['local']];assert proof['blob']==tree
 if r['status']=='exact-copy':
  raw=read(r['public_path']);d=gzip.decompress(raw) if proof['compression']=='gzip' else raw;assert H(d)==proof['sha256'] and hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()==tree;exact+=1
 else:
  assert r['source_path']=='historical/baseline-059-queue-committed-2e1f.json.gz' and r['original_decoded_sha256']==proof['sha256'];qualified.append(r['source_path'])
assert exact==20 and qualified==['historical/baseline-059-queue-committed-2e1f.json.gz']
prior=load('bundle/reference/prior-MANIFEST.json');prior_map={x['path']:x for x in prior['files']};checked=0
for name,r in by.items():
 if name.startswith('historical/prior-'):
  prior_path='historical/'+name[len('historical/prior-'):];q=prior_map[prior_path];assert r['original_stored_sha256']==q['sha256'] and r['original_stored_bytes']==q['bytes'];checked+=1
for n in ('REPORT.json','read-receipt.json','registration.json','historical-manifest.json','git-proofs.json'):
 q=prior_map[n];r=by['reference/prior-'+n];assert r['original_stored_sha256']==q['sha256'] and r['original_stored_bytes']==q['bytes'];checked+=1
reg=load('bundle/registration.json');registry=json.loads(gzip.decompress(read(by['historical/original-registry.json.gz']['public_path'])))
for role in (2643,2644):
 r=next(z for z in reg['sources'] if z.get('role')==role and z['identity'].startswith('recovered'));row=registry['files'][role];assert row['snapshot']=='pr-working' and row['sha256']==r['sha256'] and row['material_ranges']==r['original_material'];assert by[r['source_file']]['status']=='exact-copy' and by[r['source_file']]['original_stored_sha256']==r['sha256']
hist=load('HISTORICAL-RELATIONSHIPS.json');stream=gzip.decompress(read(hist['original_774_stream']['public_path']));lines=stream.splitlines()
for r in hist['original_774_findings']:
 d=read(r['exact_public_line']);assert d==lines[r['line_1based']-1] and H(d)==r['line_sha256_without_terminator'];a=json.loads(d);assert a['id']==r['id'] and r['source_ids_as_recorded']==a.get('source_ids',[a['source_id']] if 'source_id' in a else [])
old=json.loads(gzip.decompress(read(by['historical/baseline-059-queue-committed-2e1f.json.gz']['public_path'])))['entries'];new=json.loads(gzip.decompress(read(by['historical/baseline-059-queue-committed-d7.json.gz']['public_path'])))['entries']
sel=load('bundle/historical/prior-059-selected-records-reconstructed.json'); comp=load('bundle/selected-queue-comparison.json')
assert len(hist['selected_059_rows'])==len(sel['queue_rows'])==len(comp['rows'])==7
for i,(z,a,b) in enumerate(zip(sel['queue_rows'],comp['rows'],hist['selected_059_rows'])):
 n=z['index'];assert n==a['index']==b['index'] and z['entry']==old[n]==new[n] and a['equal_json_value'] and a['id']==b['id']==old[n]['contract_id']
for a in hist['historical_queues']:
 r=next(z for z in rows if z['public_path']==a['public_path']);assert all(a[k]==r[k] for k in ('original_stored_sha256','original_decoded_sha256','public_stored_sha256','public_decoded_sha256','status'))
w=json.loads(gzip.decompress(read(by['reference/working-baseline.json.gz']['public_path'])))['newly_assessed_ledger']['entries'];c=json.loads(gzip.decompress(read(by['reference/committed-baseline.json.gz']['public_path'])))['newly_assessed_ledger']['entries']
for q in reg['selected_ledger_relations']:
 a=int(q['working_pointer'].split('/')[-1]);b=int(q['committed_pointer'].split('/')[-1]);assert w[a]==c[b] and w[a]['id']==q['id']
meta=load('GIT-COMMIT-METADATA.json');assert len(meta['members'])==5 and all(by[x['original_path']]['public_path']==x['public_path'] and by[x['original_path']]['public_stored_sha256']==x['stored_sha256'] for x in meta['members'])
print(json.dumps({'status':'PASS','stage_manifest_members':len(ms),'source_members':len(rows),'reconstructed_members':changed,'recorded_path_redactions':numops,'raw_git_objects':len(g['objects']),'git_proofs_exact_leaf':exact,'git_proofs_qualified_crosswalk_leaf':len(qualified),'retained_prior_manifest_members_bound':checked,'exact_original_774_finding_lines':len(hist['original_774_findings']),'selected_equal_059_records':len(sel['queue_rows']),'selected_equal_current_ledger_entries':len(reg['selected_ledger_relations']),'qualification':'Read-only integrity, original-manifest binding and qualified source-proof crosswalks only. Does not verify transformation of restricted original bytes, reachability, privacy completeness, source analysis or product behavior.'},indent=2))
