# Hair collider reconciliation transport

This bounded source-only packet concerns original role 2645. The public report
preserves historical attribution, read scopes, conditional observations and
nonclosure. It does not authorize or validate a product change.

`TRANSPORT-MAP.json` identifies every original file and its public copy. Two
helper scripts contain substituted scratch paths and no longer match their
original hashes; exact originals remain in restricted local custody. All six
helper-script names have an inert `.txt` suffix. The original manifest remains
an attributed historical record under `evidence/`; the root manifest covers
this transport.

Run `python3 verify-public.py` and `python3 privacy-check.py` for read-only
evidence verification. Optional `--git` and `--extraction` check separately
available Git and original extraction. Revision-to-root links require those
external anchors; no raw commit-author objects were added.
