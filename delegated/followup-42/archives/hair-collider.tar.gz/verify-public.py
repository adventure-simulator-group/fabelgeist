#!/usr/bin/env python3
"""Read-only transport and source-evidence verification; no product execution."""
import argparse,datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent;p=root/'evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
gitblob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
load=lambda n:json.loads((p/n).read_bytes())
number=lambda r:{i for a,z in r for i in range(a,z+1)}
ap=argparse.ArgumentParser();ap.add_argument('--git',action='store_true');ap.add_argument('--extraction');args=ap.parse_args()
public=json.loads((root/'PUBLIC-MANIFEST.json').read_bytes())
actual={f.relative_to(root).as_posix() for f in root.rglob('*') if f.is_file() and f.relative_to(root).as_posix()!='PUBLIC-MANIFEST.json'}
assert len(public['files'])==public['file_count'] and actual=={x['path'] for x in public['files']}
for x in public['files']:
 f=root/x['path'];assert not f.is_symlink();b=f.read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
mp=json.loads((root/'TRANSPORT-MAP.json').read_bytes());entries=mp['entries'];assert len(entries)==mp['original_file_count']==111 and mp['script_path_renames']==6 and mp['content_transformed_files']==2 and mp['path_substitution_occurrences']==3
assert len({x['original_path'] for x in entries})==len({x['public_path'] for x in entries})==111
changed=[]
for x in entries:
 assert x['public_path']=='evidence/'+x['original_path']+('.txt' if x['original_path'].endswith('.py') else '')
 b=(root/x['public_path']).read_bytes();assert (len(b),sha(b))==(x['public_bytes'],x['public_sha256'])
 if x['transformation'].startswith('local scratch'):changed.append(x['original_path']);assert sha(b)!=x['original_sha256']
 else:assert (len(b),sha(b))==(x['original_bytes'],x['original_sha256'])
assert sorted(changed)==['recover-evidence.py','register.py']
m=load('BUNDLE-MANIFEST.json');assert sha((p/'BUNDLE-MANIFEST.json').read_bytes())==mp['original_manifest_sha256']=='1dbb895c8b5415cd6c8ea0c9a5ba8f75de96eeb419fc86f400bef3846ba9360c'
org={x['original_path']:x for x in entries};assert len(m['files'])==m['file_count']==110 and set(org)=={x['path'] for x in m['files']}|{'BUNDLE-MANIFEST.json'}
for x in m['files']:
 a=org[x['path']];assert (a['original_bytes'],a['original_sha256'])==(x['bytes'],x['sha256'])
scan=json.loads((root/'PUBLIC-PRIVACY-SCAN.json').read_bytes());assert not scan['hits'] and not scan['exceptions']
views={};role={}
for regfile,receiptfile in [('REGISTRATION.json','READ-RECEIPT.json'),('REGISTRATION-MORE.json','READ-RECEIPT-MORE.json'),('REGISTRATION-THIRD.json','READ-RECEIPT-THIRD.json')]:
 regbytes=(p/regfile).read_bytes();reg=json.loads(regbytes);rec=load(receiptfile);assert rec['registration_sha256']==sha(regbytes) and rec['registration_file']==regfile and datetime.datetime.fromisoformat(reg['registered_utc'])<datetime.datetime.fromisoformat(rec['recorded_utc']);assert len(rec['reads'])==len(reg['entries'])
 for e in reg['entries']:
  v=next(x for x in rec['reads'] if x['tag']==e['tag']);b=(p/e['archive']).read_bytes();assert (len(b),sha(b),gitblob(b),len(b.splitlines()))==(e['bytes'],e['sha256'],e['git_blob'],e['eof']);assert v['sha256']==e['sha256'] and v['revision']==e['revision'];seen=number(v['displayed_chunks']);missing=number(v['unread_complement']);assert seen==number(e['registered_ranges']) and not seen&missing and seen|missing==set(range(1,e['eof']+1));assert e['tag'] not in views;views[e['tag']]=seen
  if e.get('role')==2645:role[e['tag']]=e
assert len(views)==15 and len(role)==2 and (p/'source/old-role.rs').read_bytes()==(p/'source/current-role.rs').read_bytes()
reg=load('history/registry-selection.json');raw=gzip.decompress((p/'history/registry-original.json.gz').read_bytes());whole=json.loads(raw);assert (sha(raw),gitblob(raw),sha((p/'history/registry-original.json.gz').read_bytes()))==(reg['original_registry_sha256'],reg['registry_git_blob_of_uncompressed_bytes'],reg['stored_transport_gzip_sha256']);assert whole['files'][2645]==reg['row'] and reg['row']['sha256']==role['old-role']['sha256'] and reg['snapshot']['id']=='pr-working' and reg['snapshot']['head']==role['old-role']['revision'] and len(reg['snapshot']['status_porcelain'])==4
prior=load('prior/selected-index.json');assert prior['archive_sha256']=='eeebeb5d7de665b18760a18fb4e87c2d2ae275a739d083b700a3642b15545ef1' and prior['checkpoint_index_sha256']=='012df221f17211e027cd1d9f15f9424ae0d3186f44dd9aa4e0ac0b12229076c9'
for x in prior['selected_members']:
 b=(p/x['archive']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['original_sha256'])
 if x['changed']:
  q=(p/x['published_variant_archive']).read_bytes();assert sha(q)==x['published_sha256'] and sha(gzip.decompress(b))==x['original_uncompressed_sha256'] and sha(gzip.decompress(q))==x['published_uncompressed_sha256']
 else:assert x['original_sha256']==x['published_sha256']
for name in ['historical-059/ORIGINAL-VERIFICATION.json','historical-059/FIELD-VERIFICATION.json']:
 for x in load(name)['records']:
  b=(p/x['archive']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
  if x.get('git_blob_of_bytes'):assert gitblob(b)==x['git_blob_of_bytes']
  if args.extraction:assert (Path(args.extraction)/x['transport_path']).read_bytes()==b
for x in load('historical-774/SELECTED.json')['records']:
 b=gzip.decompress((p/x['file']).read_bytes());line=b.splitlines(keepends=True)[x['row_1based']-1];assert sha(b)==x['source_uncompressed_sha256'] and sha(line)==x['line_sha256_including_terminator'] and json.loads(line)==x['record']
variant=load('historical-774/VARIANT-COMPARISON.json');a=gzip.decompress((p/'historical-774/contract-groups.jsonl.gz').read_bytes());b=gzip.decompress((p/'prior/published-variants/history-774/contract-groups.jsonl.gz').read_bytes());assert sha(a)==variant['original_plain_sha256'] and sha(b)==variant['published_plain_sha256'];i=variant['original_byte_offset'];j=variant['published_byte_offset'];assert a[:i]==b[:j] and a[i+variant['original_segment_bytes']:]==b[j+variant['published_segment_bytes']:];line=a.splitlines(keepends=True)[variant['selected_row_1based']-1];assert line==b.splitlines(keepends=True)[variant['selected_row_1based']-1] and sha(line)==variant['selected_line_sha256']
l=load('history/ledger-selection.json');q=load('history/queue-selection.json');assert l['selected_entries_equal'] and l['committed']['entries']==l['working_observed']['entries'] and l['committed']['sha256']!=l['working_observed']['sha256'];assert q['selected_56f_d7_equal'] and q['selected_d7_working_equal'] and q['committed_56f_original']['entries']==q['committed_d7_reconstructed']['entries']==q['working_observed']['entries'] and q['committed_56f_original']['sha256']!=q['committed_d7_reconstructed']['sha256']
proof=load('TREE-PROOFS.json');trees={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b))==(x['bytes'],x['sha256']) and hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;trees[oid]=b
def entries(b):
 out={};i=0
 while i<len(b):
  sp=b.index(b' ',i);nul=b.index(b'\0',sp);out[b[sp+1:nul].decode()]=(b[i:sp].decode(),b[nul+1:nul+21].hex());i=nul+21
 return out
for x in proof['proofs']:
 tree=x['root_tree'];assert proof['roots'][x['revision']]==tree and prior['external_commit_anchors'][x['revision']]['root_tree']==tree
 for name,c in zip(x['path'].split('/'),x['chain']):
  assert c['tree']==tree and c['name']==name;mode,oid=entries(trees[tree])[name];assert int(mode,8)==int(c['mode'],8) and oid==c['object'];tree=oid
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),gitblob(b))==(x['bytes'],x['sha256'],x['git_blob']) and tree==x['git_blob']
assert len(proof['proofs'])==26
for x in load('rules/RULES.json')['records']:assert sha((p/x['archive']).read_bytes())==x['sha256']
r=load('REPORT.json');assert len(r['lens_perspectives'])==13
for obs in r['fresh_observations']:
 for ref in obs['trace']:assert number(ref['ranges'])<=views[ref['tag']]
if args.git:
 g=lambda *a:subprocess.check_output(['git','--no-replace-objects',*a])
 for rev,tree in proof['roots'].items():assert g('rev-parse',rev+'^{tree}').decode().strip()==tree
 idx=g('show',prior['checkpoint_revision']+':'+prior['checkpoint_index_path']);assert sha(idx)==prior['checkpoint_index_sha256'];ci=json.loads(idx);bundle=next(x for x in ci['bundles'] if x['bundle_id']=='hair-collider');archive=g('show',prior['checkpoint_revision']+':'+bundle['archive']);assert sha(archive)==prior['archive_sha256'];members={x['path']:x for x in bundle['members']};assert all(members[x['source_member']]['original_sha256']==x['original_sha256'] and members[x['source_member']]['published_sha256']==x['published_sha256'] for x in prior['selected_members'])
 committed=l['committed'];data=g('show',committed['revision']+':'+committed['path']);assert (len(data),sha(data),gitblob(data))==(committed['bytes'],committed['sha256'],committed['git_blob']);doc=json.loads(data);assert all(next(x for x in doc['newly_assessed_ledger']['entries'] if x['id']==k)==v for k,v in committed['entries'].items())
 for key in ['committed_56f_original','committed_d7_reconstructed']:
  x=q[key];data=g('show',x['revision']+':baseline-059/queue.json');assert (len(data),sha(data),gitblob(data))==(x['bytes'],x['sha256'],x['git_blob']);doc=json.loads(data);assert all(doc['entries'][int(k)]==v for k,v in x['entries'].items())
 cp35=g('show',variant['cp35_proposal_git_revision']+':'+variant['cp35_proposal_path']);assert sha(cp35)==variant['cp35_proposal_sha256'];fa=g('show','d7b14a15ef132422eca86e7d898b47423af92779:ASSESSMENT-L01-HAIR-FIELD-95E.json');assert fa==(p/'history/hair-field-assessment.json').read_bytes()
print('PASS: evidence manifest, 15 separately registered source scopes, 26 tree paths with qualified external commit anchors, original 059/774 provenance, two distinct 774 representations, selected committed/working states and 13 bounded perspectives'+('; Git and prior archive identities checked' if args.git else '')+('; original 059 extraction bytes checked' if args.extraction else '')+'. No product behavior validated.')
