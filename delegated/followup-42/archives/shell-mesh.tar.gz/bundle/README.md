# Bounded shell source reconciliation

`REPORT.json` records the current/historical source conclusions, safeguards,
reader attributions, open questions, and thirteen bounded perspectives.
`REGISTRATION.json` and `READ-RECEIPT.jsonl` identify the prospective and actual
personal displays. Full source bytes outside those windows are evidence only.

`HISTORY-INDEX.json` distinguishes exact historical originals, newly constructed
gzip wrappers and selected-record reconstructions. The full committed and
working baseline captures differ and remain separately qualified. `proofs/`
contains Git commit and tree object bytes and historical source bindings.

Run `python3 verify.py` for read-only evidence verification. It does not run any
prior verifier or product code. The manifest covers every packet file apart from
itself. This is a local, not yet privacy-reviewed public packet: original records
or scripts may include local paths and raw Git commits disclose their authors'
names and email fields. No product execution, repair, build, test or probe was
performed.
