#!/usr/bin/env python3
import json,pathlib,hashlib,datetime,sys
D=pathlib.Path(__file__).resolve().parent;R=json.loads((D/'REGISTRATION.json').read_bytes());entry=next(x for x in R['entries'] if x['name']==sys.argv[1]);lo=int(sys.argv[2]);hi=int(sys.argv[3]);assert [lo,hi] in entry['prospective_display_windows'];raw=(D/entry['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['sha256'];lines=raw.splitlines(keepends=True);part=b''.join(lines[lo-1:hi]);print(f"--- {entry['name']} {entry['path']} {entry['revision']} {lo}-{hi} ---")
for i,b in enumerate(lines[lo-1:hi],lo):print(f'{i:4} {b.decode().rstrip()}')
sys.stdout.flush();receipt={'name':entry['name'],'path':entry['path'],'revision':entry['revision'],'sha256':entry['sha256'],'displayed_range':[lo,hi],'displayed_source_bytes_sha256':hashlib.sha256(part).hexdigest(),'displayed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/rig_identity'}
with (D/'READ-RECEIPT.jsonl').open('a') as f:f.write(json.dumps(receipt)+'\n')
