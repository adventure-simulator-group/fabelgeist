#!/usr/bin/env python3
"""Read-only evidence verifier; does not invoke the product or any prior verifier."""
import pathlib,json,hashlib,gzip,datetime
P=pathlib.Path(__file__).resolve().parent; H=lambda b:hashlib.sha256(b).hexdigest();git=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();L=lambda n:json.loads((P/n).read_bytes());m=L('MANIFEST.json');actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() or x.is_symlink()}-{'MANIFEST.json'};assert actual==set(m['files'])
for name,x in m['files'].items():
 p=P/name;assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert (H(b),len(b))==(x['sha256'],x['bytes']),name
reg=L('REGISTRATION.json');entries={x['name']:x for x in reg['entries']};receipts=[json.loads(x) for x in (P/'READ-RECEIPT.jsonl').read_bytes().splitlines()];start=datetime.datetime.fromisoformat(reg['registered_utc']);expected={(x['name'],tuple(w)) for x in reg['entries'] for w in x['prospective_display_windows']};observed={(r['name'],tuple(r['displayed_range'])) for r in receipts};assert len(receipts)==len(expected)==21 and observed==expected
for r in receipts:
 x=entries[r['name']];raw=(P/x['file']).read_bytes();lines=raw.splitlines(keepends=True);lo,hi=r['displayed_range'];assert (H(raw),len(raw),len(lines),git('blob',raw))==(x['sha256'],x['bytes'],x['lines'],x['git_blob']);assert H(b''.join(lines[lo-1:hi]))==r['displayed_source_bytes_sha256'] and datetime.datetime.fromisoformat(r['displayed_utc'])>=start and r['author']=='/root/rig_identity'
assert entries['mesh-old']['sha256']==entries['mesh-current']['sha256'] and entries['lib-old']['sha256']==entries['lib-current']['sha256'];assert entries['lib-old']['original_material_ranges']==[[1,56]]

def get_objects(label):
 root=P/'proofs'/label;d=json.loads((root/'git-proofs.json').read_bytes());out={}
 for oid,x in d['objects'].items():
  q=root/(x.get('archive') or x['preserved_bytes']);raw=gzip.decompress(q.read_bytes());assert (H(raw),len(raw),git(x['type'],raw))==(x['sha256'],x['bytes'],oid);out[oid]=(x['type'],raw)
 return d,out
shell,so=get_objects('shell');cloth,co=get_objects('cloth')
def tree_entries(raw):
 out={};i=0
 while i<len(raw):
  end=raw.index(b'\0',i);mode,name=raw[i:end].split(b' ',1);oid=raw[end+1:end+21].hex();out[name.decode()]=(mode.decode(),oid);i=end+21
 assert i==len(raw);return out
def check_path(row,objects,raw,chainkey,blobkey):
 revision=row['revision'];chain=row[chainkey];typ,commit=objects[revision];assert typ=='commit';root=commit.split(b'\n',1)[0].decode().split(' ')[1];assert chain[0]['tree']==root and '/'.join(x['name'] for x in chain)==row['path']
 for i,z in enumerate(chain):
  typ,tree=objects[z['tree']];assert typ=='tree' and tree_entries(tree)[z['name']]==(z['mode'],z['object']);assert i==len(chain)-1 or z['object']==chain[i+1]['tree']
 assert chain[-1]['object']==row[blobkey]==git('blob',raw) and (H(raw),len(raw))==(row['sha256'],row['bytes'])
for x in reg['entries']:
 raw=(P/x['file']).read_bytes();d,objects=(cloth,co) if x['name']=='garment-current' else (shell,so);chainkey='chain' if d is cloth else 'path_chain';blobkey='blob' if d is cloth else 'git_blob';revision='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' if x['name'].endswith('-old') else '95e63628f9d70b8dd6e6fede64334696c6995009';matches=[z for z in d['paths'] if z['revision']==revision and z['sha256']==x['sha256'] and (z['path']==x['path'] or (revision.startswith('f82') and z['path'].endswith(x['sha256'])))];assert len(matches)==1,(x['name'],len(matches));check_path(matches[0],objects,raw,chainkey,blobkey)
for n in ['mesh','lib']:
 x=entries[n+'-old'];raw=(P/x['file']).read_bytes();old=next(z for z in shell['paths'] if z['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and z['path']==x['path']);check_path(old,so,raw,'path_chain','git_blob')
# Equality proof for old Shell support does not assert a historical personal read.
x=entries['shell-current'];raw=(P/x['file']).read_bytes();old=next(z for z in shell['paths'] if z['revision']=='6533e444fa37552927070cc8d8190907fd3b413e' and z['path']==x['path']);check_path(old,so,raw,'path_chain','git_blob')
for label,items in [('shell',[('REPORT.json','history/prior-shell-report.json'),('registration.json','history/prior-shell-registration.json'),('personal-read-receipt.json','history/prior-shell-personal-receipt.json'),('historical-attribution.json','history/prior-shell-historical-attribution.json')]),('cloth',[('REPORT.json','history/prior-cloth-report.json'),('REGISTRATION.json','history/prior-cloth-registration.json'),('READ-RECEIPT.json','history/prior-cloth-read-receipt.json')])]:
 m=json.loads((P/'proofs'/label/'prior-MANIFEST.json').read_bytes())['files'];listed={x['path']:(x['sha256'],x['bytes']) for x in m} if isinstance(m,list) else {k:(v['sha256'],v['bytes']) for k,v in m.items()}
 for original,copied in items:
  b=(P/copied).read_bytes();assert (H(b),len(b))==listed[original]
for suffix,file in [('initial06-type-ownership/findings.jsonl','history/774-initial06-findings.jsonl.gz'),('initial06-type-ownership/contracts-013.json','history/774-initial06-contracts-013.json.gz'),('admission03/additional-contracts.jsonl','history/774-admission03-additional.jsonl.gz'),('admission03/source-range-registration.jsonl','history/774-admission03-registration.jsonl.gz')]:
 row=next(z for z in cloth['paths'] if z['path'].endswith(suffix));check_path(row,co,gzip.decompress((P/file).read_bytes()),'chain','blob')
f=L('proofs/f083-extra-proof.json');raw=gzip.decompress((P/f['file']).read_bytes());frow={'revision':f['revision'],'path':f['path'],'chain':f['chain'],'blob':f['git_blob'],'sha256':f['decoded_sha256'],'bytes':f['decoded_bytes']};check_path(frow,co,raw,'chain','blob')
# Publication HEAD proof binds committed baseline only, never the observed working copy.
pub=L('proofs/publication/PROOF.json');po={}
for x in pub['objects']:
 raw=gzip.decompress((P/x['file']).read_bytes());assert (H(raw),len(raw),git(x['type'],raw))==(x['raw_sha256'],x['raw_bytes'],x['oid']);po[x['oid']]=raw
assert po[pub['commit_oid']].split(b'\n',1)[0]==b'tree '+pub['root_tree'].encode();assert tree_entries(po[pub['root_tree']])[pub['baseline_path']][1]==pub['baseline_blob']
committed=gzip.decompress((P/'history/baseline-committed.json.gz').read_bytes());working=gzip.decompress((P/'history/baseline-observed-working.json.gz').read_bytes());capture=L('history/BASELINE-CAPTURE.json');assert git('blob',committed)==pub['baseline_blob']==capture['committed_git_blob'] and H(committed)==capture['committed_sha256'] and H(working)==capture['working_observed_sha256'];assert capture['publication_head_before']==capture['publication_head_after']==pub['commit_oid']
# Recovered 059 transport identities and exact records versus newly reconstructed selections.
trans=gzip.decompress((P/'history/059-transport-manifest.json.gz').read_bytes());assert H(trans)=='c3e04095a9e4cb3e2da6ee2a4f561c811ebeca445a50461ddb63b2d426ed6858';t={x['path']:x for x in json.loads(trans)['entries']};idx=L('HISTORY-INDEX.json');docs={}
for name in ('queue','registry'):
 x=idx['059'][name];z=(P/f'history/059-original-{name}.json.gz').read_bytes();raw=gzip.decompress(z);e=t[x['transport_path']];assert (H(z),H(raw),len(raw),git('blob',raw))==(x['gzip_transport_sha256'],e['sha256'],e['bytes'],e['git_blob']);docs[name]=json.loads(raw)
for x in idx['exact_059_records']:
 b=(P/x['archive']).read_bytes();e=t[x['original_path']];assert (H(b),len(b),git('blob',b))==(x['sha256'],x['bytes'],x['git_blob'])==(e['sha256'],e['bytes'],e['git_blob'])
for x in L('history/059-queue-selected-reconstructed.json')['entries']:
 i=int(x['json_pointer'].rsplit('/',1)[1]);assert x['value']==docs['queue']['entries'][i]
for x in L('history/059-registry-selected-reconstructed.json')['rows']:assert x['value']==docs['registry']['files'][x['original_index']]
b=json.loads(committed);w=json.loads(working)
for x in L('history/current-ledger-selection-reconstructed.json')['rows']:
 i=int(x['committed_pointer'].rsplit('/',1)[1]);j=int(x['observed_working_pointer'].rsplit('/',1)[1]);assert x['committed_value']==b['newly_assessed_ledger']['entries'][i] and x['observed_working_value']==w['newly_assessed_ledger']['entries'][j] and x['row_values_equal']==(x['committed_value']==x['observed_working_value'])
print('Verified review manifest, 21 prospective displays, historical/current Git source and 774 paths, 059 original transport/selected records, and distinct committed/observed baseline copies. No product code was executed.')
