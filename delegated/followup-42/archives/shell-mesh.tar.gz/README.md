# Public shell evidence transport

This is a privacy-reconstructed transport of the frozen 2646–2647 shell audit
packet, not a byte-identical copy. `PUBLICATION-QUALIFICATION.json` and
`INDEX.json` preserve original and public stored/decoded hashes, source and
reader attribution, committed versus observed baselines, and the 059/774/P16
limits. No new finding count, alias, source-read credit or product validation is
asserted.

The decoded 059 queue and the historical recovery helper contain path
substitutions. Their exact original stored bytes are separately retained in a
local access-restricted directory. The registry remains an exact copy of this
packet's gzip; a separately published wrapper has a different stored hash and
the same decoded bytes. 059 transport original tuples are links to historical
identities, not direct public-byte matches. `bundle/verify.py` is the unchanged
original checker and expects original bytes; `bundle/recover-evidence.py` is a
reconstruction and must not be treated as its original executable. Run
`python3 verify-public.py` for public source/Git/transport checks. Add
`--private-root <restricted-originals>` to replay each redaction against exact
stored originals and verify local permissions. All checks are evidence-only and
read-only; no old verifier or product code is executed.

Raw Git commit objects are deliberately preserved for identity verification and
retain author and committer names and emails. Their prior publication and
cached-reference qualifications appear in `PUBLICATION-QUALIFICATION.json` and
`PRIOR-PUBLIC-CROSSWALK.json`. The privacy scan is bounded and does not prove
absence of all sensitive material.
