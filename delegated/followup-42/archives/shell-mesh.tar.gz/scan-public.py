#!/usr/bin/env python3
"""Read-only, bounded path/account/credential survey of the public stage."""
import pathlib,json,gzip,re,hashlib,collections
P=pathlib.Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();slash=b'/'
policy=json.loads((P/'PRIVACY-POLICY.json').read_bytes());agents={slash+b'root/'+x.encode() for x in policy['agent_identifiers']};semantic=set(policy['semantic_fragment_sha256']);regexsafe=set(policy['known_literal_regex_sha256']);root=slash+rb'(?:home|users|tmp|root|mnt|workspace|workspaces|private|var/(?:tmp|folders))/[^\s"\x27<>\x00\\]+';win=rb'[A-Za-z]:[\\/]+(?:Users|Documents and Settings)[\\/]+[^\s"\x27<>\x00]+';pathrx=re.compile(rb'(?:(?<![A-Za-z0-9_])|\\[nrt])('+root+rb'|'+win+rb')',re.I);secret=re.compile(rb'gh[pousr]_[A-Za-z0-9_]{25,}|github_pat_[A-Za-z0-9_]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}|-----BEGIN (?:RSA |DSA |OPENSSH |EC |ENCRYPTED )?PRIVATE KEY-----|AKIA[0-9A-Z]{16}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|AIza[0-9A-Za-z_-]{35}|glpat-[0-9A-Za-z_-]{20,}|npm_[0-9A-Za-z]{30,}|eyJ[A-Za-z0-9_-]{18,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}|(?:Bearer\s+)[A-Za-z0-9._~+/-]{24,}|https?://[^\s/@:]+:[^\s/@]+@',re.I);email=re.compile(rb'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}');homes=pathlib.Path('/'+'home');users=[x.name.encode() for x in homes.iterdir() if x.is_dir() and len(x.name)>=6] if homes.exists() else [];counts=collections.Counter();issues=[];email_locations=[]
for f in sorted(P.rglob('*')):
 if not f.is_file():continue
 name=str(f.relative_to(P));raw=f.read_bytes();payloads=[('stored',raw)]
 if raw.startswith(b'\x1f\x8b'):payloads.append(('decoded',gzip.decompress(raw)))
 for rep,data in payloads:
  norm=re.sub(rb'(?i)\\u002f',slash,data.replace(b'\\/',slash));counts['payloads']+=1;counts['bytes']+=len(norm)
  for z in pathrx.finditer(norm):
   tok=z.group(1);bare=tok.rstrip(b'.,;:!?`');pre=norm[max(0,z.start()-180):z.start()].lower()
   if bare in agents:counts['agent-identifiers']+=1;continue
   if H(tok) in semantic or H(bare) in semantic:counts['semantic-fingerprint-exemptions']+=1;continue
   if H(tok) in regexsafe:counts['regex-fingerprint-exemptions']+=1;continue
   if bare==slash+b'tmp/726' and b'paths' in norm[z.end():z.end()+25].lower():counts['literal-example-exemptions']+=1;continue
   if bare.startswith(slash+b'root/') and pre.endswith(b'..') and b'"path"' in pre:counts['root-relative-exemptions']+=1;continue
   issues.append({'file':name,'representation':rep,'kind':'path','sha256':H(tok)})
  for z in secret.finditer(norm):issues.append({'file':name,'representation':rep,'kind':'secret','sha256':H(z.group())})
  for user in users:
   for z in re.finditer(re.escape(user),norm,re.I):issues.append({'file':name,'representation':rep,'kind':'local-account-name','sha256':H(z.group())})
  matches=email.findall(norm)
  if matches:email_locations.append({'file':name,'representation':rep,'count':len(matches),'raw_git_commit':name.endswith('.commit.gz')})
print(json.dumps({'schema':'726-shell-public-privacy-scan-v1','counts':dict(counts),'unclassified_count':len(issues),'unclassified':issues,'email_locations':email_locations,'qualification':'Pattern- and host-bounded scan only. Raw Git commit author/committer metadata is retained and explicitly disclosed; this scan does not establish universal privacy.'},indent=2))
