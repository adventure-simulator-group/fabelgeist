import datetime,difflib,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());unzip=lambda n:gzip.decompress((p/n).read_bytes());reg=load('registration.json');orig=json.loads(unzip('reference/registry.json.gz'));cat=json.loads(unzip('reference/older-source-catalog.json.gz'));gp=load('git-proofs.json');checks=[]
s=next(x for x in orig['snapshots'] if x['id']=='physical-p16');assert s['base']==s['head']=='a120390947c89b703dc74c4255a13c035d054c50' and s['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and s['status_porcelain'] and s['changed_variants']==159;assert reg['snapshot_authority']['status_porcelain']==s['status_porcelain'];checks.append('historical P16 dirty status, base and recorded patch hash match registry; patch bytes not claimed recovered')
r=reg['role'];o=orig['files'][2490];c=cat['rows'][2490];assert r['source_id']==o['source_id']==c['source_id'] and r['requested_historical_material_ranges']==o['material_ranges'];v=r['versions'][0];b=(p/v['local_path']).read_bytes();assert (len(b),sha(b),blob(b),len(b.splitlines()))==(v['bytes'],o['sha256'],v['git_blob'],v['registered_range'][1]);assert pathlib.Path(r['recovered_object_path']).read_bytes()==b and c['expected_sha256']==sha(b);assert subprocess.check_output(['git','-C',repo,'show',r['evidence_archive_revision']+':'+r['evidence_archive_path']])==b
for x in r['versions'][1:]:
 assert x.get('present',True);t=(p/x['local_path']).read_bytes();assert t==subprocess.check_output(['git','-C',repo,'show',x['revision']+':'+x['path']]) and (len(t),sha(t),blob(t),len(t.splitlines()))==(x['bytes'],x['sha256'],x['git_blob'],x['registered_range'][1]);assert (t==b)==(x['kind']!='current')
checks.append('P16 source matches original registry/catalog/f82 archive, equals a120/039/6533 paths, differs from pinned 95e path')
names=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json'];sup=[x for n in names for x in load(n)['sources']]
for x in sup:
 b=(p/x['local_path']).read_bytes();assert (len(b),sha(b),blob(b),len(b.splitlines()))==(x['bytes'],x['sha256'],x['git_blob'],x['registered_range'][1]);assert b==subprocess.check_output(['git','-C',repo,'show',x['revision']+':'+x['path']])
assert len(sup)==16;checks.append('16 separately registered current support bodies match exact Git identity')
def tree_entries(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);z=b.index(b'\0',j);d[b[j+1:z].decode()]=(b[i:j].decode(),b[z+1:z+21].hex());i=z+21
 return d
def obj(oid):
 v=gp['objects'][oid];b=unzip(v['archive']);t=v['type'];assert (len(b),sha(b))==(v['bytes'],v['sha256']) and hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;return b
for oid in gp['objects']:obj(oid)
for x in gp['proofs']:
 tree=obj(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for e in x['chain']:assert e['tree']==tree and tree_entries(obj(tree))[e['name']]==(e['mode'],e['object']);tree=e['object']
 assert tree==x['blob']==blob((p/x['archive']).read_bytes())
assert len(gp['proofs'])==21;checks.append('21 archived raw Git commit/tree/blob membership proofs verified; f82 proves evidence object only')
rr=load('read-receipt.json');assert sha((p/'registration.json').read_bytes())==rr['prospective_registration']['sha256']
for label in ['p16','current']:
 covered=set();unread=set()
 for a,b in rr[label+'_actual_display_ranges']:assert 1<=a<=b<=rr['eof'];covered.update(range(a,b+1))
 for a,b in rr[label+'_unread_ranges']:assert 1<=a<=b<=rr['eof'];unread.update(range(a,b+1))
 assert covered.isdisjoint(unread) and len(covered|unread)==rr['eof']
assert not rr['base_actual_display_ranges'] and not rr['older_origin_actual_display_ranges'] and not rr['pr_working_actual_display_ranges'];sr=load('support-read-receipt.json');assert len(sr['reads'])==16
for x in sr['reads']:
 for a,b in x['actual_display_ranges']:assert 1<=a<=b<=x['eof']
for x in sr['prospective_registrations']:assert sha((p/x['path']).read_bytes())==x['sha256']
checks.append('actual P16/current displays and unread complements partition source; supports bounded and earlier revision bodies not credited')
a=(p/'source/2490-p16.rs').read_text().splitlines(keepends=True);b=(p/'source/2490-current.rs').read_text().splitlines(keepends=True);ops=[{'tag':t,'old_range':[i+1,j],'current_range':[k+1,l]} for t,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if t!='equal'];diff=load('diff-index.json');assert ops==diff['hunks'] and len(ops)==2 and ops[0]['old_range']==[111,111] and ops[1]['old_range']==[2969,2969] and sha((p/diff['diff']).read_bytes())==diff['sha256'];checks.append('independently compared exact P16/current bodies differ at only lines 111 and 2969')
trans={x['path']:x for x in json.loads(unzip('reference/original-transport-manifest.json.gz'))['entries']};h=load('historical-manifest.json');assert not h['unavailable']
for x in h['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
checks.append(f"{len(h['records'])} recovered 059 records match transport sizes, SHA256 and Git blob")
old=load('reference/older-selection.json');ix={x['path']:x for x in json.loads(unzip('reference/older-774-handoff-manifest.json.gz'))['files']};b=unzip(old['copy']);assert (len(b),sha(b))==(old['bytes'],old['sha256'])==(ix[old['path']]['bytes'],ix[old['path']]['sha256']);lines=b.splitlines()
for i in [212,554]:
 row=json.loads(lines[i]);assert row['source_id']=='pr-working:'+r['path'] and row['observed_sha256']==o['sha256'];assert row['read_ranges']==[[1,2973]] and row['read_complete']
checks.append('774 supplier initial/closure rows match pr-working role hash and full main coordinator scope; tests child remains separate')
for x in load('reference/prior-selection.json')['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
 for y in x['source_records']:
  z=(p/y['copy']).read_bytes();body=gzip.decompress(z);assert sha(z)==y['compressed_sha256'] and sha(body)==y['sha256'] and body==subprocess.check_output(['git','-C',repo,'show',y['revision']+':'+y['path']])
checks.append('4 earlier central assessments and 20 exact associated current source payloads verified without author/read transfer')
for x in load('reference/rules.json')['rules']:assert sha((p/x['copy']).read_bytes())==x['sha256']
q=json.loads(unzip('reference/queue-059.json.gz'))['entries'];rep=load('report.json');assert len(rep['lenses'])==13 and {x['number'] for x in rep['lenses']}==set(range(1,14));assert all(q[x['zero_based_index']]['contract_id']==x['contract_id'] and q[x['zero_based_index']]['status']==x['status'] for x in rep['historical_queue']);assert q[1177]['contract_id']=='Q-L12-d1a66d7adfc25f474dda';oldl12=load('historical/segovb/READ-L12-391.json');assert any(x.get('original_index')==1382 and 'Signed configured steps can fail' in json.dumps(x) for x in oldl12['rows']);checks.append('13 bounded perspectives, original queue and earlier signed-step observation preserved')
out={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','checks':checks,'qualification':'Evidence identity/accounting only. No product or viewer execution, builds, tests, probes, simulated fixtures, implementation, repair or product validation.'};(p/'evidence-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
