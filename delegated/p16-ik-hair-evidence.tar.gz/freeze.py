import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='packet-manifest.json':
  b=f.read_bytes();files.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','scope':'Physical-p16 role 2490 and separately bounded 95e current/support evidence.','qualification':'Evidence bytes only; full P16 patch unrecovered, earlier author and actual display scope retained.','files':files};b=(json.dumps(m,indent=2)+'\n').encode();(p/'packet-manifest.json').write_bytes(b);print('files',len(files),'manifest_sha256',hashlib.sha256(b).hexdigest(),'report_sha256',hashlib.sha256((p/'report.json').read_bytes()).hexdigest())
