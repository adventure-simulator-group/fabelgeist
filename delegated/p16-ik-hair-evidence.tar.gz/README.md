# Delegated physical-p16 IK coordinator source evidence

This packet covers original source role 2490 by `/root/hair_ops`. `report.json`
records thirteen bounded lens perspectives, historical attributions, a
conditional source-level configuration connection, and open policies. Exact
personal displays and unread complements are in `read-receipt.json`; support
scopes are in `support-read-receipt.json`.

Physical-p16 is a dirty snapshot based on
`a120390947c89b703dc74c4255a13c035d054c50`. The registry's recorded patch
SHA256 is `fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7`;
full patch bytes were not recovered and the hash is retained as a historical
assertion. The role's exact recovered object matches the registry, 774 catalog
and f82 archived evidence object. That path happens to match a120, 039 and 6533;
95e differs at exactly lines 111 and 2969. These path-specific facts do not
reconstruct the whole dirty snapshot.

The agent separately displayed P16 lines 1–370 and 2935–2973, and 95e lines
1–370, 1540–1620, 2480–2550 and 2935–2973. Remaining coordinator lines and
the separate tests module are unread; archived bytes do not confer read credit.
Earlier 059/774 and central reviewer source identities, scopes and attribution
remain distinct; no historical evidence is promoted to checkpoint 3821.

`git-proofs.json` and `git-objects/` contain membership evidence for the exact
archive, clean source objects and registered current support. The recovered
historical records and prior source payloads are indexed by the associated
manifests. `evidence-verification.json` contains only identity/accounting
checks. No product, viewer, build, test, runtime probe, simulated fixture,
implementation, repair or product validation was performed.
