import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';older=pathlib.Path('<LOCAL_PATH_2>');handoff=pathlib.Path('<LOCAL_PATH_3>');catalog=json.loads((older/'reconcile-adler-20261023/recovered-sources/catalog.json').read_text());revs=['cbbbca08c89a8768926799371f54cf6057312e5e','6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009'];paths=['crates/adventuresim-character-creator/src/export.rs','crates/adventuresim-character-creator/src/export/shell.rs','crates/adventuresim-tactical-client/examples/armor_browser_probe.rs'];roles=[]
for idx,path in zip([2470,2471,2472],paths):
 versions=[]
 for rev in revs:
  x=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True)
  if x.returncode:
   tree=subprocess.run(['git','-C',repo,'ls-tree','-r','--name-only',rev,'--',path],capture_output=True,check=True).stdout.decode().splitlines();assert path not in tree;versions.append({'revision':rev,'present':False,'absence_proof':'exact Git tree lookup excludes file','tree_exact_lookup':tree});continue
  b=x.stdout;local=f'source/{idx}-{rev[:4]}.rs';(out/local).write_bytes(b);h=hashlib.sha256(b).hexdigest();row={'revision':rev,'present':True,'local_path':local,'bytes':len(b),'lines':[1,len(b.splitlines())],'sha256':h,'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
  if rev==revs[0]:
   c=catalog['rows'][idx];assert c['source_id']=='rig-quality:'+path and c['origin']=='git:'+rev+':'+path and c['expected_sha256']==h and pathlib.Path(c['object']).read_bytes()==b;archive=older/'reconcile-adler-20261023/audit-continuation/operations/source/rig-quality'/path;other=handoff/'audit/reconcile-adler-20261023/audit-continuation/operations/source/rig-quality'/path;assert archive.read_bytes()==b==other.read_bytes();row.update({'frozen_catalog_object':c['object'],'archive_local':str(archive),'handoff_archive':str(other)})
  versions.append(row)
 roles.append({'original_index':idx,'path':path,'versions':versions})
f=out/'registration.json';f.write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','scope':'Prospective exact rig-quality cbbb, pr-working 6533 and pinned current 95e bodies; only personally displayed bounded ranges confer read credit.','qualification':'Old cbbb clean snapshot retains distinct revision and reviewer; historical is not checkpoint3821. Example is source text only.','constraint':'Source and evidence integrity only; no product, viewer, browser, test, build, runtime probe, simulation or repair.','roles':roles},indent=2)+'\n');print('sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(roles,indent=1))
