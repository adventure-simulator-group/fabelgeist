import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());unzip=lambda n:gzip.decompress((p/n).read_bytes());reg=load('registration.json');orig=json.loads(unzip('reference/registry.json.gz'));cat=json.loads(unzip('reference/older-source-catalog.json.gz'));gp=load('git-proofs.json');rh=load('read-receipt.json');sr=load('support-read-receipt.json');supp=[s for n in ['support-registration.json','support-registration-02.json','support-registration-03.json'] for s in load(n)['sources']];checks=[]
assert orig['snapshots'][1]['id']=='rig-quality' and orig['snapshots'][1]['head']==gp['rig_quality_commit']=='cbbbca08c89a8768926799371f54cf6057312e5e' and orig['snapshots'][1]['base']=='6533e444fa37552927070cc8d8190907fd3b413e' and orig['snapshots'][1]['status_porcelain']==[] and gp['direct_parents']==['6533e444fa37552927070cc8d8190907fd3b413e']; checks.append('059 original rig-quality snapshot head, direct parent, clean status metadata match raw commit proof')
for r in reg['roles']:
 row=orig['files'][r['original_index']];assert row['snapshot']=='rig-quality' and row['path']==r['path'] and row['sha256']==r['versions'][0]['sha256'] and row['base_sha256']==r['versions'][1]['sha256']; assert len({v['git_blob'] for v in r['versions']})==3
 c=[x for x in cat['rows'] if x['source_id']=='rig-quality:'+r['path']];assert len(c)==1 and c[0]['expected_sha256']==r['versions'][0]['sha256'];old=r['versions'][0];b=(p/old['local_path']).read_bytes();assert all(pathlib.Path(old[k]).read_bytes()==b for k in ['frozen_catalog_object','archive_local','handoff_archive'])
 for v in r['versions']:
  b=(p/v['local_path']).read_bytes();assert (len(b),sha(b),blob(b),len(b.splitlines()))==(v['bytes'],v['sha256'],v['git_blob'],v['lines'][1]);assert subprocess.check_output(['git','-C',repo,'show',v['revision']+':'+r['path']])==b
checks.append('3 roles x 3 revisions exist, exact nine bodies differ per role; match 059 registry, older catalog/object, both frozen source archives and git show')
for s in supp:
 b=(p/s['local_path']).read_bytes();assert (len(b),sha(b),blob(b),len(b.splitlines()))==(s['bytes'],s['sha256'],s['git_blob'],s['registered_range'][1]);assert subprocess.check_output(['git','-C',repo,'show',s['revision']+':'+s['path']])==b
checks.append('all 15 separately registered support source byte/hash/blob identities verified')
def tree_entries(b):
 d={};i=0
 while i<len(b):
  j=b.index(b' ',i);z=b.index(b'\0',j);d[b[j+1:z].decode()]=(b[i:j].decode(),b[z+1:z+21].hex());i=z+21
 return d
def object_data(oid):
 v=gp['objects'][oid];b=unzip(v['archive']);t=v['type'];assert len(b)==v['bytes'] and sha(b)==v['sha256'] and hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;return b
for oid in gp['objects']:object_data(oid)
for proof in gp['proofs']:
 commit=object_data(proof['revision']);root=commit.splitlines()[0].split()[1].decode();assert root==proof['commit_tree'];tree=root
 for e in proof['chain']:
  assert e['tree']==tree and tree_entries(object_data(tree))[e['name']]==(e['mode'],e['object']);tree=e['object']
 assert tree==proof['blob']==blob((p/proof['archive']).read_bytes())
assert len(gp['proofs'])==24 and b'parent 6533e444fa37552927070cc8d8190907fd3b413e\n' in object_data(gp['rig_quality_commit']);checks.append('all 24 commit/tree/blob membership chains independently verified from archived raw objects')
for rr in rh['roles']:
 r=next(x for x in reg['roles'] if x['original_index']==rr['original_index'])
 for label,i in [('rig_quality',0),('pr_working',1),('current',2)]:
  end=r['versions'][i]['lines'][1];read=rr[label+'_actual_display_ranges'];unread=rr[label+'_unread_ranges'];covered=set();missing=set()
  for a,b in read:assert 1<=a<=b<=end;covered.update(range(a,b+1))
  for a,b in unread:assert 1<=a<=b<=end;missing.update(range(a,b+1))
  assert covered.isdisjoint(missing) and len(covered|missing)==end
assert all(not rr['pr_working_actual_display_ranges'] for rr in rh['roles']);assert all(1<=a<=b<=row['eof'] for row in sr['reads'] for a,b in row['actual_body_display_ranges']);assert len(sr['reads'])==15 and sr['reads'][3]['actual_body_display_ranges']==[] and sr['reads'][8]['actual_body_display_ranges']==[];checks.append('personal roles have exact complete read/unread partition; 6533 unread and support windows bounded; identical cbbb validation not credited')
trans={e['path']:e for e in json.loads(unzip('reference/original-transport-manifest.json.gz'))['entries']};h=load('historical-manifest.json');assert not h['unavailable']
for x in h['records']:
 b=(p/x['copy_path']).read_bytes();e=trans[x['original_transport_path']];assert (len(b),sha(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append(f"{len(h['records'])} original 059 records match exact transport bytes/SHA256/Git blob")
old=load('reference/older-774-selection.json');oldbytes=unzip(old['manifest_compressed']);assert sha(oldbytes)==old['manifest_uncompressed_sha256'];oldindex={e['path']:e for e in json.loads(oldbytes)['files']}
for x in old['records']:
 b=unzip(x['compressed_copy']);e=oldindex[x['manifest_path']];assert (len(b),sha(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256'])
 if x['merged_copy']:assert pathlib.Path(x['merged_copy']).read_bytes()==b
cov=next(x for x in old['records'] if x['manifest_path'].endswith('rig/coverage.jsonl'));lines=unzip(cov['compressed_copy']).splitlines()
for i,n in [(2470,90),(2471,89),(2472,91)]:
 row=json.loads(lines[n]);source=reg['roles'][i-2470]['path'];assert source in json.dumps(row);assert orig['files'][i]['owner_contract_proofs'][0]['row']==n
assert orig['files'][2470]['owner_contract_proofs'][0]['read_status']=='current-lens-shared-identical-lines-plus-complete-distinct-line-read';checks.append('12 older 774 selections, including exact recorded dependencies, match frozen handoff manifest; supplier rows and non-reread qualification verified')
for x in load('reference/prior-current-selection.json')['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
 for y in x['source_records']:
  z=(p/y['copy']).read_bytes();b=gzip.decompress(z);assert sha(z)==y['compressed_sha256'] and sha(b)==y['sha256'] and subprocess.check_output(['git','-C',repo,'show',y['revision_as_recorded']+':'+y['path']])==b
assert len(load('reference/prior-current-selection.json')['records'][0]['source_records'])==10;checks.append('4 prior central assessments and all 10 originally preserved body-normal source payloads match original revisions; no personal credit transferred')
q=json.loads(unzip('reference/queue-059.json.gz'))['entries'];ids={165:'ADLER-L11-MHR-TOPOLOGY-ADMISSION',460:'SEGOVB-L13-COMPACT-SURFACE-UV-CORRESPONDENCE',572:'Q-L11-e31c308c19ce6c3f591d',637:'Q-L11-2db61fd95b1d48c9a8d2',1919:'Q-L12-061880ab84522c0a38f8',1920:'Q-L12-dbade442cb664f05c51d'}
assert all(q[i]['contract_id']==name for i,name in ids.items());report=load('report.json');assert len(report['lenses'])==13 and {x['number'] for x in report['lenses']}==set(range(1,14));assert [x['contract_id'] for x in report['historical_queue']]==[ids[i] for i in ids];checks.append('6 recovered 059 IDs/status preserved and 13 individually bounded perspectives recorded')
for x in load('diff-index.json')['diffs']:assert sha((p/x['path']).read_bytes())==x['sha256']
for x in load('reference/rules-index.json')['rules']:
 b=(p/x['copy']).read_bytes();assert sha(b)==x['sha256']
checks.append('archived comparison hashes and copied governing-rule hashes match')
out={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','checks':checks,'qualification':'Evidence identity and accounting verification only. No product execution, build, test, probe, simulation, implementation or product validation.'};(p/'evidence-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
