import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');out=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='packet-manifest.json':
  b=f.read_bytes();out.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','scope':'Bounded rig-quality original roles 2470–2472; historical cbbb distinct from 6533 and current 95e.','qualification':'Manifest identifies evidence bytes; no additional personal body read, checkpoint3821 promotion, product validation, or whole-lens clearance.','files':out};b=(json.dumps(m,indent=2)+'\n').encode();(p/'packet-manifest.json').write_bytes(b);print('files',len(out),'manifest_sha256',hashlib.sha256(b).hexdigest(),'report_sha256',hashlib.sha256((p/'report.json').read_bytes()).hexdigest())
