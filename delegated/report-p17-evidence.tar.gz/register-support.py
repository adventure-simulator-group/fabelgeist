from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');plan={'95e63628f9d70b8dd6e6fede64334696c6995009':['crates/adventuresim-tactical-client/src/animation_viewer/capture.rs','crates/adventuresim-tactical-client/src/animation_viewer/report/model.rs','crates/adventuresim-tactical-client/src/animation/procedural/ik/state.rs'],'90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696':['crates/adventuresim-tactical-core/src/animation/authored_angle.rs','crates/adventuresim-tactical-core/src/animation/measurement.rs','crates/adventuresim-tactical-core/src/animation/value_error.rs','crates/adventuresim-tactical-client/src/animation_viewer/capture.rs']}; entries=[]; pending=[]
for rev,paths in plan.items():
 for p in paths:
  raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_maximum_range':[1,len(raw.splitlines())],'scope':'support only; no original ordered-role or prior-review credit; actual line displays will be listed separately'});pending.append((rev,p,raw))
r={'schema':'726-report-p17-prospective-support-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','purpose':'Trace finite-value admission, diagnostics, and call-order conditions; read only bounded relevant source ranges, record actual read scope.','entries':entries};(b/'support-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for rev,p,raw in pending:
 d=b/'support'/rev[:4]/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('support registration sha256',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
