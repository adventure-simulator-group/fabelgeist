from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/AGENTS.md','crates/adventuresim-tactical-core/AGENTS.md','crates/adventuresim-tactical-client/src/animation/AGENTS.md'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'prospective_read':[1,len(raw.splitlines())],'scope':'governing guidance for assigned/support families, no ordered-role credit'});pending.append((p,raw))
r={'schema':'726-report-p17-prospective-rules-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','entries':entries};(b/'rules-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'support'/'95e6'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('rules registration sha256',hashlib.sha256((b/'rules-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
