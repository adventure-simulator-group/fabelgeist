from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>'); old=json.loads((b/'old-registration.json').read_text()); rev='95e63628f9d70b8dd6e6fede64334696c6995009';entries=[];pending=[]
for oldrow in old['entries']:
 p=oldrow['path']; result=subprocess.run(['git','show',rev+':'+p],capture_output=True)
 if result.returncode:
  entries.append({'original_role':oldrow['original_role'],'path':p,'revision':rev,'status':'absent_at_current','planned_personal_body_ranges':[],'qualification':'Git lookup failed; absence requires tree proof and no current body is claimed.'});continue
 raw=result.stdout;sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();actual=subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();assert blob==actual
 entries.append({'original_role':oldrow['original_role'],'path':p,'revision':rev,'status':'present','sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_line_count':len(raw.splitlines()),'planned_personal_body_ranges':[[1,len(raw.splitlines())]],'byte_equal_to_original_90a':sha==oldrow['sha256'],'qualification':'Prospective full current source read, distinct from old personal and historical reviewer scopes.'});pending.append((p,raw))
r={'schema':'726-report-p17-prospective-current-source-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity, report-p17 capture','registration':'Created before any current source display, after independently proving and freezing original 90a objects and historical attribution.','entries':entries};(b/'current-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'sources'/'95e6'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('current registration sha256',hashlib.sha256((b/'current-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
