#!/usr/bin/env python3
"""Read-only source/evidence hash, membership, and scope accounting; no product validation."""
import gzip,hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('usage: verify-evidence.py PUBLICATION_DIRECTORY')
pub=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['timestamp_utc'] and len(receipt['actual_displays'])==4
for x in receipt['actual_displays']:
 row=next(y for y in r['rows'] if y['original_index']==x['role']);o=next(y for y in row['objects'] if y['label']==x['revision']);b=(p/o['local_file']).read_bytes();assert sha(b)==o['sha256'] and len(b.splitlines())==o['eof'];covered=set()
 for a,z in x['ranges']:covered.update(range(a,z+1))
 assert covered==set(range(1,o['eof']+1)) and not x['unread']
for row in r['rows']:assert row['objects'][0]['sha256']==row['registry_entry']['sha256']==row['objects'][1]['sha256']
checks.append('Four prospective separate historical/current displays cover both full assigned bodies; per-file identity only')
sr=load('support-registration.json');s=load('support-read-receipt.json');assert s['registration_sha256']==sha((p/'support-registration.json').read_bytes()) and sr['at']<s['at'] and len(s['reads'])==5
for x in s['reads']:
 b=(p/x['source_file']).read_bytes();assert sha(b)==x['sha256'] and len(b.splitlines())==x['eof']
 assert any(y['path']==x['path'] and y['revision']==x['revision'] and y['prospective_ranges']==x['actual_ranges'] and y['file']==x['source_file'] for y in sr['rows'])
checks.append('Five current support files were separately registered before the displayed windows')
arc=pub/'delegated/sdk-noiz-sats-hair-evidence.tar.gz';assert sha(arc.read_bytes())=='421ed4b801935c1995a630147c88af97cebd478fb7ea05a33cda143dcc99998a'
with tarfile.open(arc,'r:gz') as t:
 orig=gzip.decompress(t.extractfile('reference/registry.json.gz').read());assert sha(orig)==r['registry_uncompressed_sha256'];registry=json.loads(orig)
 trans=json.loads(gzip.decompress(t.extractfile('reference/original-transport-manifest.json.gz').read()));entries={x['path']:x for x in trans['entries']}
for x in r['rows']:assert x['registry_entry']==registry['files'][x['original_index']]
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==12 and sum(x['kind']=='historical-774' for x in hi['records'])==5
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original registry and twelve exact 059 records match original transport manifest; five 774 files retained')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==16
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Sixteen raw commit/tree/blob chains establish 6533, 95e and f82 transport identities')
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
report=load('report.json');assert {x['number'] for x in report['lenses']}==set(range(1,14))
for x in report['support_reads']:
 cov=set()
 for a,z in x['actual_ranges']:cov.update(range(a,z+1))
 missing=set()
 for a,z in x['unread_for_this_registration']:missing.update(range(a,z+1))
 assert not cov.intersection(missing) and cov.union(missing)==set(range(1,x['eof']+1))
old=gzip.decompress((p/'history-774/additional-contracts.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[89])['id']=='RIG-ADMISSION03-ADDITIONAL-104' and json.loads(old[90])['id']=='RIG-ADMISSION03-ADDITIONAL-105'
old=gzip.decompress((p/'history-774/findings.jsonl.gz').read_bytes()).splitlines();assert json.loads(old[88])['id']=='RIG-ADMISSION03-F082' and json.loads(old[90])['id']=='RIG-ADMISSION03-F073-SUPPLEMENT-001' and json.loads(old[68])['id']=='RIG-ADMISSION03-F065'
assert 'xpbd-particle-packing-and-shared-gpu-boundary' in json.loads(gzip.decompress((p/'history-774/contracts-012.json.gz').read_bytes()))['groups']
old=load('history-059/READ-L12-913.json');assert old['root_personal_rereads']==[];rr={x['original_index']:x for x in old['rows']};assert rr[2648]['fresh_personal_body_reads']==[[1,169]] and rr[2649]['fresh_personal_body_reads']==[[1,100]] and all('/root/lens12_frontier' in rr[i]['attribution'] for i in (2648,2649))
queue=json.loads((pub/'baseline-059/queue.json').read_bytes());q=load('queue-entry-3138.json');assert sha((pub/'baseline-059/queue.json').read_bytes())==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08' and queue['entries'][3138]==q['entry'] and q['entry']['contract_id']=='L12-CLOSURE-PARTICLE-UPLOAD-REASON-FACETS'
assert sha((pub/'ASSESSMENT-GARMENT-FIT-95E.json').read_bytes())=='dee9866a5c7b74847fa7baaacaf81cf4c6100642c770051931ccfee548453502'
assert sha((pub/'delegated/xpbd-solver-evidence.tar.gz').read_bytes())=='c05836fc02c2ada48438a626b0c90c767f5af2d6d34fb27f57cee96f62634fe6' and sha((pub/'delegated/xpbd-solver-report.json').read_bytes())=='e95700ad5fb5f39ce9342b6bcbd4da42fb236d6b3e9007c8fe671ce4ed4dae13'
recovery=json.loads((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes());assert sha((pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007' and sha((pub/recovery['recovered_patch']['path']).read_bytes())==recovery['recovered_patch']['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
checks.append('Thirteen bounded perspectives, support complements, original reader attribution, F082/F073/F065, queue extraction, prior published evidence and P16 recovery hash links')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and accounting only. No product execution, testing, build, probe, simulation, rendering, implementation, publication edit, whole-lens closure or checkpoint3821 promotion.'},indent=2))
