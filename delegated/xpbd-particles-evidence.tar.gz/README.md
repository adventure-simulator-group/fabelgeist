# XPBD particles: source-only evidence packet

This packet independently assesses original roles 2648–2649 at the pinned
current 95e project revision and the recorded historical 6533 pr-working
per-file source identities. `report.json` gives findings, exact references,
historical attribution and thirteen scoped lens perspectives.

`registration.json` and `read-receipt.json` record separate prospective and
actual old/current body displays; the corresponding support files record only
bounded current windows. Preserved whole support bytes do not constitute
whole-file personal reads. Earlier 059 and 774 records retain their own
reviewers, ranges, timestamps and project/transport qualifications.

`git-proofs.json` and `git-objects/` preserve raw commit/tree membership proof;
`historical-index.json` describes exact recovered bytes. `queue-entry-3138.json`
is a reconstructed extract, not an original document. The verification script
requires the indicated publication directory for hash-linked original registry,
original-transport manifest, queue and separately published previous packets:

```
python3 verify-evidence.py /path/to/target/726-audit-baseline/publication
```

`verification.json` records the result of evidence-integrity verification only.
No product, build, test, solver, GPU, simulation, fixture, probe, implementation
or repair ran. The packet makes no checkpoint3821 or whole-lens completion claim.
