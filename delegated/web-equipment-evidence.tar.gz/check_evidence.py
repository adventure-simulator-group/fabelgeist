import gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';cur='95e63628f9d70b8dd6e6fede64334696c6995009'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(rev,path):return subprocess.run(['git','-C',repo,'show',rev+':'+path],stdout=subprocess.PIPE,check=True).stdout
reg=json.loads((p/'registration.json').read_text());report=json.loads((p/'report.json').read_text())
for x in reg['ordered_roles']:
 for v in x['versions']:
  b=(p/'source'/(v['revision'][:4]+'-'+pathlib.Path(x['path']).name)).read_bytes()
  assert v['present'] and (len(b),len(b.splitlines()),sha(b),blob(b))==(v['bytes'],v['lines'][1],v['sha256'],v['git_blob'])
  assert b==git(v['revision'],x['path']),x['path']
 assert x['versions'][0]['sha256']==x['versions'][1]['sha256']
assert report['registration']['sha256']==sha((p/'registration.json').read_bytes())
count=0
for x in report['support']:
 name=x['registration'];assert x['sha256']==sha((p/name).read_bytes());s=json.loads((p/name).read_text())
 assert set(x['actual_personal_ranges'])==set(row['path'] for row in s['registered_sources'])
 for row in s['registered_sources']:
  b=(p/'source'/('support-'+row['path'].replace('/','__'))).read_bytes()
  assert (len(b),len(b.splitlines()),sha(b),blob(b))==(row['bytes'],row['range'][1],row['sha256'],row['git_blob'])
  assert b==git(cur,row['path']),row['path']
  assert all(1<=a<=z<=row['range'][1] for a,z in x['actual_personal_ranges'][row['path']]);count+=1
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:transport={x['path']:x for x in json.load(f)['entries']}
h=json.loads((p/'historical-manifest.json').read_text());assert not h['unavailable']
for x in h['records']:
 b=(p/x['copy_path']).read_bytes();e=transport[x['original_transport_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
assert report['historical_manifest']['sha256']==sha((p/'historical-manifest.json').read_bytes())
refs=json.loads((p/'reference/manifest.json').read_text())
for x in refs['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
q=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()))
for x in report['historical_queue']:assert q['entries'][x['index']]['contract_id']==x['id'] and q['entries'][x['index']].get('status')==x['status_as_recovered']
assert report['reference_archives']['sha256']==sha((p/'reference/manifest.json').read_bytes())
assert len(report['lens_notes'])==13
print('Evidence integrity passed:',len(reg['ordered_roles']),'identical historic/current assigned objects,',count,'registered current support objects,',len(h['records']),'transport-verified original records,',len(report['historical_queue']),'exact 059 queue identities, and reference archives.')
print('Git object reads, evidence hashes and JSON/gzip parsing only; no product build, test, browser, runtime probe, product algorithm or simulated fixture.')
