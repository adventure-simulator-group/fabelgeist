import datetime,gzip,hashlib,json,pathlib,shutil,subprocess
b=pathlib.Path('<LOCAL_PATH_0>');prev=pathlib.Path('<LOCAL_PATH_1>');old=pathlib.Path('<LOCAL_PATH_2>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest();rev='6533e444fa37552927070cc8d8190907fd3b413e';entries=[];pending=[]
for reg in ['support-registration.json','support-registration-2.json']:
 for e in json.load(open(b/reg))['entries']:
  p=e['path'];v=subprocess.run(['git','show',f'{rev}:{p}'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  if v.returncode:entries.append({'revision':rev,'path':p,'status':'absent_in_historical_revision','current_sha256':e['sha256']});continue
  raw=v.stdout;entries.append({'revision':rev,'path':p,'sha256':sha(raw),'git_blob':oid(raw),'bytes':len(raw),'current_sha256':e['sha256'],'byte_identical':sha(raw)==e['sha256'],'planned_personal_body_read':'none'});pending.append((p,raw))
r={'schema':'726-historical-support-prospective-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'purpose':'Compare historical bytes and build Git proofs only; no historical support body display or personal audit-read credit. Registration precedes saved artifacts.','entries':entries};(b/'historical-support-6533-registration.json').write_text(json.dumps(r,indent=2)+'\n')
for p,raw in pending:
 d=b/'historical-support-6533'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
for n in ['original-059-ledger.json.gz','original-059-queue.json.gz','original-registry.json.gz','original-transport-manifest.json.gz']:shutil.copyfile(prev/n,b/n)
registry=json.load(gzip.open(b/'original-registry.json.gz','rt'));selection={'kind':'reconstructed selection from exact original registry; not a replacement','exact_registry_gzip':'original-registry.json.gz','exact_registry_gzip_sha256':sha((b/'original-registry.json.gz').read_bytes()),'rows':[{'original_index':i,**registry['files'][i]} for i in range(2409,2413)]};(b/'registry-selection-reconstructed.json').write_text(json.dumps(selection,indent=2)+'\n')
m=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));idx={e['path']:e for e in m['entries']}
paths=[f'adler/{kind}-L11-{n}.json' for n in [395,396] for kind in ['READ','VERIFY','STATE']]+[f'adler/REGISTRATION-ADLER-{n}.json' for n in range(1287,1291)]+['adler/READ-L11-385.json']
paths += [f'segovb/{kind}-L11-467.json' for kind in ['READ','VERIFY','STATE']]+['segovb/REGISTRATION-SEGOVB-1779.json','segovb/READ-L12-CONNECTED-TEAM-008.json']
paths += [f'segovb/{kind}-L12-{n}.json' for n in [808,809] for kind in ['READ','VERIFY','STATE']]+[f'segovb/REGISTRATION-SEGOVB-L12-{n}.json' for n in [808,809]]+[f'parallel-l12-20261029/PROPOSAL-L12-{n}.json' for n in [808,809]]+[f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json' for n in [415,416,417,418]]+['parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-808-810.json']
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file():missing.append(p);continue
 raw=(old/p).read_bytes();e=idx[p];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(raw)==e['git_blob'],p;d=b/'historical-059'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw);records.append({'original_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(d.relative_to(b)),'qualification':'Exact 059 transport bytes, original attribution/range retained; no checkpoint3821 promotion.'})
r='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';base='handoff/774/adler-original/audit/records/final-acceptance-20261021/wave-01/';local=pathlib.Path('<LOCAL_PATH_3>');older=[]
rels=['audit-existing-type-owners/camera/coverage.jsonl','audit-existing-type-owners/camera/additional-sources.jsonl','audit-existing-type-owners/rig/coverage.jsonl','audit-existing-type-owners/rig/additional-sources.jsonl','producer-supplement-after-owner/camera/traces.jsonl','producer-supplement-after-owner/rig/traces.jsonl']
for rel in rels:
 for prefix,folder,mode in [(base,'historical-774','original'),('handoff/774/historical-family-execution/final-acceptance-20261021/wave-01/','historical-774-variant','variant')]:
  path=prefix+rel;raw=subprocess.check_output(['git','show',r+':'+path]);
  if mode=='original':assert (local/rel).read_bytes()==raw
  d=b/folder/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw);older.append({'transport_revision':r,'transport_path':path,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(d.relative_to(b)),'qualification':('Local older original byte-compared to f82 adler-original' if mode=='original' else 'Distinct historical-family-execution variant; no substitution')+'; f82 is transport, not source revision.'})
for rel in ['continuation/camera/traces.jsonl','continuation/rig/web-request-reconciliation-039.json','continuation/rig/source-scope-reconciliation-044.json']:
 path='handoff/774/adler-original/audit/'+rel;raw=subprocess.check_output(['git','show',r+':'+path]);d=b/'historical-774'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw);older.append({'transport_revision':r,'transport_path':path,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(d.relative_to(b)),'qualification':'Original continuation bytes copied from f82 transport; no local collection comparison or fresh historical source-read implied.'})
prior=[]
for name,agent in [('726-delegate-web-equipment','/root/hair_ops'),('726-delegate-web-medical','/root/rig_identity'),('726-delegate-web-quest-templates','/root/rig_identity')]:
 src=pathlib.Path('/tmp')/name;names=[p for p in ['report.json','REPORT.json','registration.json','support-read-receipt.json'] if (src/p).exists()]+[p.name for p in sorted(src.glob('support-registration*.json'))]
 for p in names:
  raw=(src/p).read_bytes();d=b/'prior-current'/name/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw);prior.append({'previous_agent':agent,'original_path':str(src/p),'preserved_bytes':str(d.relative_to(b)),'sha256':sha(raw),'bytes':len(raw),'qualification':'Previous independently authored current report or prospective registration; no reader or ordered-credit transfer.'})
 for p in sorted((src/'source').glob('*')):
  if not p.is_file():continue
  raw=p.read_bytes();d=b/'prior-current'/name/'source'/p.name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw);prior.append({'previous_agent':agent,'original_path':str(p),'preserved_bytes':str(d.relative_to(b)),'sha256':sha(raw),'bytes':len(raw),'qualification':'Exact prior source artifact; only prior report recorded personal ranges count.'})
x={'schema':'726-delegated-trade-templates-history-v1','original_transport_manifest_sha256':sha((b/'original-transport-manifest.json.gz').read_bytes()),'original_059_records':records,'unavailable_original_records':missing,'older_774_receipts':older,'prior_current_agent_records':prior,'qualification':'Distinct historical source/transport and prior-current attribution retained; never promote to checkpoint3821.'};(b/'history-manifest.json').write_text(json.dumps(x,indent=2)+'\n');print('059 records',len(records),'missing',missing,'774 originals/variants',len(older),'prior-current records',len(prior));print('historical support changed or absent:',[(e['path'],e.get('status','changed')) for e in entries if not e.get('byte_identical')]);print('historical registration sha',sha((b/'historical-support-6533-registration.json').read_bytes()))
