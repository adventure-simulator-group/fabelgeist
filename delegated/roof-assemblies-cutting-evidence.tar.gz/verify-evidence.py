from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json
b=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();reg=json.load(gzip.open(b/'original-registry.json.gz','rt'));assigned=json.loads((b/'registration.json').read_bytes())['entries'];receipt=json.loads((b/'personal-read-receipt.json').read_bytes());proof=json.loads((b/'git-proofs.json').read_bytes());report=json.loads((b/'REPORT.json').read_bytes());man=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in man['entries']}
for e in assigned:
 raw=(b/e['source_archive']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and len(raw.splitlines())==e['actual_eof']
 if e['revision'].startswith('6533'):
  row=reg['files'][e['original_role']];assert e['sha256']==row['sha256'] and e['bytes']==row['bytes'] and e['original_material_ranges']==row['material_ranges']
for role in (2494,2495):
 rows=[e for e in assigned if e['original_role']==role];assert len(rows)==2 and rows[0]['sha256']==rows[1]['sha256'] and rows[0]['git_blob']==rows[1]['git_blob']
old=json.loads((b/'original-attribution.json').read_bytes());assert not old['missing_originals']
for e in old['original_059_records']:
 raw=(b/e['preserved_bytes']).read_bytes();orig=idx[e['original_path']];assert sha(raw)==e['sha256']==orig['sha256'] and len(raw)==orig['bytes'] and oid('blob',raw)==orig['git_blob']==e['git_blob']
for e in old['older_774_receipts']:
 raw=(b/e['preserved_bytes']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'] and oid('blob',raw)==e['git_blob']
prior=b/'prior-roof-packet';assert sha((prior/'MANIFEST.json').read_bytes())==old['prior_roof_packet_manifest_sha256'];pm=json.loads((prior/'MANIFEST.json').read_bytes())
for e in pm['files']:
 raw=(prior/e['path']).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
objects={}
for key,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==key;objects[key]=raw
for rev,e in proof['commits'].items():assert objects[rev].splitlines()[0].split()[1].decode()==e['root_tree']
for p in proof['paths']:
 curr=proof['commits'][p['revision']]['root_tree'];parts=p['path'].split('/');assert len(parts)==len(p['path_chain'])
 for name,step in zip(parts,p['path_chain']):
  assert step['tree']==curr and step['name']==name;mode,child=entries(objects[curr])[name];assert mode==step['mode'] and child==step['object'];curr=child
 raw=(b/p['preserved_bytes']).read_bytes();assert oid('blob',raw)==curr==p['git_blob'] and sha(raw)==p['sha256'] and len(raw)==p['bytes']
assert len(receipt['assigned_personal_reads'])==4 and len(receipt['support_personal_reads'])==14 and len(report['lenses'])==13
for e in receipt['assigned_personal_reads']:assert e['contiguously_displayed_ranges']==[[1,e['actual_eof']]] and not e['not_displayed_ranges']
for e in receipt['support_personal_reads']:
 seen=set();absent=set()
 for a,z in e['contiguously_displayed_ranges']:
  assert 1<=a<=z<=e['actual_eof'];seen.update(range(a,z+1))
 for a,z in e['not_contiguously_displayed_ranges']:
  assert 1<=a<=z<=e['actual_eof'];absent.update(range(a,z+1))
 assert seen.isdisjoint(absent) and len(seen)+len(absent)==e['actual_eof']
scopes={e['path']:e['contiguously_displayed_ranges'] for e in receipt['support_personal_reads']}
for e in receipt['assigned_personal_reads']:
 if e['revision'].startswith('95e6'):scopes[e['path']]=e['contiguously_displayed_ranges']
def visit(x):
 if isinstance(x,dict):
  if x.get('revision')=='95e63628f9d70b8dd6e6fede64334696c6995009' and 'ranges' in x:
   assert x['path'] in scopes
   for a,z in x['ranges']:assert any(a>=lo and z<=hi for lo,hi in scopes[x['path']]),(x['path'],a,z)
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
out={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'result':'pass','checks':['Historical roles match registry SHA, bytes and line count; each has an identical current Git object','Original 059 and 774 records independently match transport manifest or Git blob','Prior frozen packet and all files match prior manifest, preserving original support attribution','Raw Git commit/tree/blob chains prove source, support and 774 transport membership','Four full assigned personal displays, support subranges and current source citations checked; thirteen bounded lenses present'],'scope':'Evidence structure and hashes only, not product validation or arithmetic execution.'};raw=(json.dumps(out,indent=2)+'\n').encode();(b/'evidence-verification.json').write_bytes(raw);print('PASS',sha(raw),'paths',len(proof['paths']),'059',len(old['original_059_records']))
