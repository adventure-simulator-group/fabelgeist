from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-building-generator/src/generator/occupied_storeys.rs','crates/adventuresim-building-generator/src/generator/layout.rs'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();e={'revision':rev,'path':p,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw),'actual_eof':len(raw.splitlines()),'planned_ranges':[[1,len(raw.splitlines())]],'source_archive':'support/95e6/'+p,'qualification':'Prospective upstream gate support; only displayed subranges credited.'};entries.append(e);pending.append((e['source_archive'],raw))
r={'schema':'726-prospective-support-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'support-registration-03.json').write_bytes(raw)
for p,x in pending:
 d=b/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(x)
print('sha',hashlib.sha256(raw).hexdigest(),'EOF',[(e['path'],e['actual_eof']) for e in entries])
