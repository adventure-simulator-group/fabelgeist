from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');files=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and str(p.relative_to(b))!='MANIFEST.json':
  x=p.read_bytes();files.append({'path':str(p.relative_to(b)),'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest()})
r={'schema':'726-bounded-evidence-manifest-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'file_count':len(files),'files':files,'qualification':'Hashes cover source bytes, scope and attribution, historic records, Git objects and prior packet; this is not product validation.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'MANIFEST.json').write_bytes(raw);print('manifest',hashlib.sha256(raw).hexdigest(),'files',len(files))
