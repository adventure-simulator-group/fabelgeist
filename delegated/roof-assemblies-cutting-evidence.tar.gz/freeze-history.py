from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,shutil,subprocess
b=Path('<LOCAL_PATH_0>');prev=Path('<LOCAL_PATH_1>');old=Path('<LOCAL_PATH_2>');sha=lambda x:hashlib.sha256(x).hexdigest();oid=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
assert sha((prev/'MANIFEST.json').read_bytes())=='de2140592f9b4c65972a713f7316d15f8ee1ce5425b7c695e8cef1087f6ce1d6';pm=json.loads((prev/'MANIFEST.json').read_bytes());pidx={e['path']:e for e in pm['files']}
# Preserve the earlier packet with its manifest and every byte independently checked.
d=b/'prior-roof-packet';d.mkdir()
for n,e in pidx.items():
 raw=(prev/n).read_bytes();assert sha(raw)==e['sha256'] and len(raw)==e['bytes'];dst=d/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
(d/'MANIFEST.json').write_bytes((prev/'MANIFEST.json').read_bytes())
for n in ['original-registry.json.gz','original-transport-manifest.json.gz','original-059-queue.json.gz','original-059-ledger.json.gz']:shutil.copyfile(prev/n,b/n)
r=json.load(gzip.open(b/'original-registry.json.gz','rt'));sel={'schema':'726-registry-selection-reconstructed-v1','qualification':'Reconstructed from original 059 registry; not original evidence or checkpoint3821','original_registry_sha256_uncompressed':sha(gzip.decompress((b/'original-registry.json.gz').read_bytes())),'rows':[{'original_index':i,**r['files'][i]} for i in [2494,2495]],'snapshot':next(x for x in r['snapshots'] if x['id']=='pr-working')};(b/'registry-selection-reconstructed.json').write_text(json.dumps(sel,indent=2)+'\n')
m=json.load(gzip.open(b/'original-transport-manifest.json.gz','rt'));idx={x['path']:x for x in m['entries']};paths=[]
for lens,n in [(11,414),(12,847),(12,848)]:
 for k in ['READ','VERIFY','STATE']:paths.append(f'segovb/{k}-L{lens}-{n}.json')
for n in [1396,1397]:paths.append(f'segovb/REGISTRATION-SEGOVB-{n}.json')
for n,i in [(512,2494),(513,2495)]:
 paths += [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json',f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{n}-WINDOWS-ORIGINAL{i}.json']
for n in [847,848]:paths.append(f'parallel-l12-20261029/PROPOSAL-L12-{n}.json')
paths += ['segovb/READ-L12-CONNECTED-TEAM-019.json','segovb/VERIFY-L12-CONNECTED-TEAM-019.json','parallel-l12-20261029/READ-CONNECTED-PAR-L12-865-ROOF-OWNED-ERROR-POLICY.json','parallel-l12-20261029/REGISTRATION-PAR-L12-583.json','parallel-l12-20261029/PROPOSAL-L12-861.json','parallel-l12-20261029/REGISTRATION-PAR-L12-569.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-857-864.json']
records=[];missing=[]
for p in paths:
 if p not in idx or not (old/p).is_file():missing.append(p);continue
 raw=(old/p).read_bytes();e=idx[p];assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(raw)==e['git_blob'];dst=b/'historical-059'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records.append({'original_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
refs=['handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/read-plan.json','handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/coverage.jsonl','handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/traces.jsonl','handoff/774/adler-original/audit/continuation/native/root-roof-producer-followup/findings.jsonl','handoff/774/adler-original/audit/continuation/root/producer-followup-acceptance-028.json','handoff/774/adler-original/audit/continuation/producer-followup-scope-extensions-020.json'];rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';records774=[]
for p in refs:
 raw=subprocess.check_output(['git','show',rev+':'+p]);assert oid(raw)==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();dst=b/'historical-774'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);records774.append({'transport_revision':rev,'transport_path':p,'sha256':sha(raw),'bytes':len(raw),'git_blob':oid(raw),'preserved_bytes':str(dst.relative_to(b))})
r={'schema':'726-original-attribution-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'original_059_records':records,'older_774_receipts':records774,'missing_originals':missing,'prior_roof_packet_manifest_sha256':sha((prev/'MANIFEST.json').read_bytes()),'prior_roof_packet_report_sha256':sha((prev/'REPORT.json').read_bytes()),'qualification':'Prior packet copied byte-for-byte and original historical records preserved with their own source revision and reviewer; f82 is transport and none is checkpoint3821.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'original-attribution.json').write_bytes(raw);print('059',len(records),'774',len(records774),'missing',missing,'sha',sha(raw))
