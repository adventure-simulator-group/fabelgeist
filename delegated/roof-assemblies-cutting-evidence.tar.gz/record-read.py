from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');base='crates/adventuresim-building-generator/src/'
scopes={base+'generator/orchestration.rs':([[1,196]],[]),base+'generator/roof_derivation.rs':([[1,265]],[]),base+'generator/roof_dormers.rs':([[1,40],[245,305]],[171]),base+'generator/roof_resolution.rs':([[1,26],[103,116],[172,198],[332,402]],[]),base+'generator/church_apse.rs':([[1,75]],[]),base+'audit/roofs.rs':([[1,45],[1210,1290]],[77,100,123,214,216,250,266,430,759,948,983,1047,1065,1130,1133,1134,1291,1295,1298,1311,1312,1323,1324,1326,1344,1346,1347,1358,1361,1363,1381,1478,1480,1482]),base+'generator/architectural_envelope.rs':([[4,67]],[]),base+'model/layout.rs':([[89,96],[168,200],[269,291],[340,410]],[]),'crates/AGENTS.md':([[21,86],[143,153]],[]),base+'generator/tower_derivation.rs':([[1,120],[185,225]],[141,243]),base+'generator/occupied_storeys.rs':([[1,157]],[]),base+'generator/layout.rs':([[1,40]],[90,91,94,95,167,234]),'crates/fabelgeist-geometry/src/cuboid.rs':([[1,80]],[]),base+'generator/roof_geometry.rs':([[56,269]],[])}
def missing(n,spans):
 covered={i for lo,hi in spans for i in range(lo,hi+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in covered:
   if start is None:start=i
  elif start is not None:out.append([start,i-1]);start=None
 return out
assigned=[]
for e in json.loads((b/'registration.json').read_bytes())['entries']:
 assigned.append({'role':e['original_role'],'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'actual_eof':e['actual_eof'],'contiguously_displayed_ranges':[[1,e['actual_eof']]],'not_displayed_ranges':[],'registration':'registration.json','qualification':'Fresh this assignment; prior current support remains separately recorded.'})
support=[]
for fn in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json','support-registration-05.json']:
 for e in json.loads((b/fn).read_bytes())['entries']:
  ranges,snips=scopes[e['path']];support.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'actual_eof':e['actual_eof'],'contiguously_displayed_ranges':ranges,'isolated_search_snippets_outside_ranges':snips,'not_contiguously_displayed_ranges':missing(e['actual_eof'],ranges),'registration':fn,'qualification':'Separate support only; no assigned-role or other-lens credit. Search snippets do not constitute body-read ranges.'})
r={'schema':'726-personal-read-receipt-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'/root/rig_identity','assigned_personal_reads':assigned,'support_personal_reads':support,'prior_attribution':{'earlier_packet':'prior-roof-packet/personal-read-receipt.json; same delegate earlier support at 95e roof_assemblies 1–50,115–165,255–277 and roof_cutting 60–165,365–410. Earlier readings remain distinct; full earlier packet frozen by its manifest.', '774_native':'NATIVE-ROOF-PPS-SOURCE-003 historical 6533 roof_assemblies1–277 and SOURCE-004 roof_cutting1–484; bounded producer roles, fresh native supplier body reads. Root reconciled narratives in producer-followup-acceptance-028; no cross-lens/current transfer.', '059_segovb_l11':'READ-L11-414 REG1396 roof_assemblies1–277 and REG1397 roof_cutting1–484 fresh bounded historical reads.', '059_delegated_l12':'READ-L12-847 PAR512 roof_assemblies1–277 and READ-L12-848 PAR513 roof_cutting1–484 fresh /root/lens12_frontier reads; root personal rereads empty; source revision 6533.'},'execution':'Source/evidence inspection and mathematical reasoning only; no product, geometry or renderer execution, fixtures, simulations, builds, tests, probes, repairs or source edits.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'personal-read-receipt.json').write_bytes(raw);print('receipt',hashlib.sha256(raw).hexdigest(),'assigned',len(assigned),'support',len(support))
