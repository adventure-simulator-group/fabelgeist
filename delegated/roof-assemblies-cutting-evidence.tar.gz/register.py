from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');reg=json.load(gzip.open('<LOCAL_PATH_1>','rt'))['files'];entries=[];pending=[]
for i in [2494,2495]:
 row=reg[i];p=row['source_id'].split(':',1)[1]
 for label,rev in [('6533','6533e444fa37552927070cc8d8190907fd3b413e'),('95e6','95e63628f9d70b8dd6e6fede64334696c6995009')]:
  raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip()
  if label=='6533':assert sha==row['sha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['actual_line_count']
  dest=f'sources/{label}/{p}';pending.append((dest,raw));entries.append({'original_role':i,'revision':rev,'path':p,'original_source_id':row['source_id'],'original_registry_locator':row['path'],'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_eof':len(raw.splitlines()),'planned_personal_ranges':[[1,len(raw.splitlines())]],'original_material_ranges':row['material_ranges'] if label=='6533' else None,'source_archive':dest,'qualification':'Exact file identity only; original pr-working tree had unrelated modified files, not assumed clean. Prior bounded current support reads retain separate attribution.'})
record={'schema':'726-prospective-roof-assemblies-cutting-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','registration':'Prospective full old/current source bodies before any assigned body display.','entries':entries};raw=(json.dumps(record,indent=2)+'\n').encode();(b/'registration.json').write_bytes(raw)
for p,raw in pending:
 d=b/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('registration sha',hashlib.sha256((b/'registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
