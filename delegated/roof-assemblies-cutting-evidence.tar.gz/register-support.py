from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=['crates/adventuresim-building-generator/src/generator/orchestration.rs','crates/adventuresim-building-generator/src/generator/roof_derivation.rs','crates/adventuresim-building-generator/src/generator/roof_dormers.rs','crates/adventuresim-building-generator/src/generator/roof_resolution.rs','crates/adventuresim-building-generator/src/generator/church_apse.rs','crates/adventuresim-building-generator/src/audit/roofs.rs','crates/adventuresim-building-generator/src/generator/architectural_envelope.rs','crates/adventuresim-building-generator/src/model/layout.rs','crates/AGENTS.md'];entries=[];pending=[]
for p in paths:
 raw=subprocess.check_output(['git','show',rev+':'+p]);sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==subprocess.check_output(['git','rev-parse',rev+':'+p],text=True).strip();dest='support/95e6/'+p;pending.append((dest,raw));entries.append({'revision':rev,'path':p,'sha256':sha,'git_blob':blob,'bytes':len(raw),'actual_eof':len(raw.splitlines()),'planned_ranges':[[1,len(raw.splitlines())]],'source_archive':dest,'qualification':'Prospective support scope only; receipt will distinguish exact displayed subranges from unread and previous packet evidence.'})
r={'schema':'726-prospective-support-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f UTC'),'reader':'/root/rig_identity','entries':entries};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'support-registration.json').write_bytes(raw)
for p,raw in pending:
 d=b/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('sha',hashlib.sha256((b/'support-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
