import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());support=json.loads((p/'support-registration.json').read_text());rec=json.loads((p/'read-receipt.json').read_text());srec=json.loads((p/'support-read-receipt.json').read_text());assert H((p/'registration.json').read_bytes())==rec['registration_sha256'];assert H((p/'support-registration.json').read_bytes())==srec['registration_sha256']
pkg=(p/reg['package_archive']['path']).read_bytes();assert H(pkg)==reg['package_archive']['sha256']=='9b76c3d056da3e299b84652ccf914c487b786857225d8ffbc8fc9509441a9e6b'
with tarfile.open(fileobj=io.BytesIO(pkg),mode='r:gz') as t:
 for x in reg['sources']:
  b=(p/x['source_archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b))==(x['bytes'],x['lines'],x['sha256']);assert t.extractfile(x['package_member']).read()==b
lock=(p/reg['current_lock']['archive']).read_bytes();x=reg['current_lock'];assert (len(lock),len(lock.splitlines()),H(lock),O('blob',lock))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1']);matches=[z for z in tomllib.loads(lock.decode())['package'] if z.get('name')=='bevy_reflect' and z.get('version')=='0.19.1'];assert len(matches)==1 and matches[0]['checksum']==H(pkg)
for x in support['sources']:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1'])
lookup={(x['revision'],x['path']):x for x in support['sources']};lookup[reg['current_lock']['revision'],'Cargo.lock']=reg['current_lock'];displays={}
def check(r,n):
 rr=r['actual_display_union'];u=r['unread_ranges'];assert all(1<=a<=b<=n for a,b in rr+u);read={i for a,b in rr for i in range(a,b+1)};unread={i for a,b in u for i in range(a,b+1)};assert not read&unread and read|unread==set(range(1,n+1));assert r['full_body_displayed']==(not unread)
for x in rec['reads']:
 if x['kind']=='current-lock':y=reg['current_lock'];key=('current-lock',x['revision'],x['path'])
 else:y=next(z for z in reg['sources'] if z['original_role']==x['original_role']);key=('native-package',y['package_member'].split('bevy_reflect-0.19.1/')[1])
 check(x,y['lines']);assert x['actual_display_union']==y['planned_display'];displays[key]=x['actual_display_union']
for x in srec['reads']:
 y=lookup[x['revision'],x['path']];check(x,y['lines']);assert x['actual_display_union']==y['planned_display'];displays['current-project',x['revision'],x['path']]=x['actual_display_union']
proof=json.loads((p/'git-proofs.json').read_text());objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in proof['proofs']:
 tree=objects[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for e in x['chain']:
  assert e['tree']==tree and entries(objects[tree])[e['name']]==(e['mode'],e['object']);tree=e['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert tree==x['blob']==O('blob',b) and H(b)==x['sha256']
 if x['kind'] in ['current-lock','current-project-support']:assert tree==lookup[x['revision'],x['path']]['git_blob_sha1']
report=json.loads((p/'report.json').read_text());refs=0
for a in report['assessments']:
 for x in a['source_refs']:
  key=('native-package',x['path']) if x['source_kind']=='native-package' else (x['source_kind'],x['revision'],x['path']);rr=displays[key]
  for start,end in x['lines']:assert any(c<=start<=end<=d for c,d in rr),(key,start,end,rr);refs+=1
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((p/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
r=json.load(gzip.open(p/'reference/original-registry.json.gz','rt'))
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']:assert x['entry']==r['files'][x['index']]
for x in reg['sources']:assert x['original_registry_entry']==r['files'][x['original_role']] and x['sha256']==r['files'][x['original_role']]['sha256']
old774=json.loads((p/'historical-774-index.json').read_text())
for x in old774['records']:
 b=gzip.decompress((p/x['copy']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
hq=old774['hash_qualifications'];assert H((p/'historical-774/registration-observed-first13.jsonl').read_bytes())==hq['root044_later_registry_first13_sha256']!=hq['root044_prior_registration_sha256'];assert H((p/'historical-774/qualification-pin-matching-first13.jsonl').read_bytes())==hq['root044_qualification_expected_sha256']==hq['root044_later_qualification_first13_sha256'];assert hq['later_registration_file_sha256']!=hq['completion112_registry_expected_sha256']
oldlock=json.loads((p/'historical-059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-873-REFLECT-YAML-LOCK-AUTHORITY.json').read_text());locks=json.loads((p/'historical-locks-index.json').read_text())['records']
for x in locks:
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1']);item=next(z for z in oldlock['rows'] if z['original_index']==x['original_role']);assert item['source_sha256']==x['sha256'];assert H((p/'historical-059'/item['registration']).read_bytes())==item['registration_sha256'];match=[z for z in tomllib.loads(b.decode())['package'] if z.get('name')=='bevy_reflect' and z.get('version')=='0.19.1'];assert len(match)==1 and match[0]['checksum']==H(pkg)
l11=json.loads((p/'historical-059/segovb/READ-L11-422.json').read_text());l12=json.loads((p/'historical-059/segovb/READ-L12-873.json').read_text());assert not l12['root_personal_rereads']
for i,rg,mat,l12rg in [(2571,1478,[[494,496],[504,506],[534,540],[547,549],[574,576]],[[489,506],[534,560],[574,576]]),(2572,1479,[[881,911]],[[881,919]])]:
 x=next(z for z in l11['sources'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==mat and H((p/f'historical-059/segovb/REGISTRATION-SEGOVB-{rg}.json').read_bytes())==x['registration_sha256'];row=next(z for z in l12['rows'] if z.get('original_index')==i);assert row['fresh_personal_body_reads']==l12rg;assert H((p/'historical-059'/row['registration']).read_bytes())==row['registration_sha256'];assert H((p/'historical-059'/row['identity_specific_windows_qualification']['path']).read_bytes())==row['identity_specific_windows_qualification']['sha256'];assert row['package_archive_sha256']==H(pkg)
assert H((p/'historical-059/parallel-l12-20261029/PROPOSAL-L12-873.json').read_bytes())==l12['proposal_sha256'];mutable=json.loads((p/'historical-059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-873-REFLECT-MUTABLE-NATIVE-PORT.json').read_text())['rows'][0];assert mutable['fresh_personal_body_reads']==[[584,586]] and H((p/'historical-059'/mutable['registration']).read_bytes())==mutable['registration_sha256']
for x in json.loads((p/'prior-references.json').read_text())['references']:
 assert H((p/x['manifest']).read_bytes())==x['manifest_sha256'] and H((p/x['report']).read_bytes())==x['report_sha256'];man=json.loads((p/x['manifest']).read_text());assert next(z['sha256'] for z in man['files'] if z['path']=='report.json')==x['report_sha256']
assert len(report['perspectives'])==13
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','native_archive_sha256':H(pkg),'assigned_members':len(reg['sources']),'current_support_objects':len(support['sources']),'git_path_proofs':len(proof['proofs']),'raw_git_objects':len(objects),'assessment_source_ranges_within_personal_displays':refs,'original_059_exact_records':len(hist['records']),'historical_locks':len(locks),'older_774_exact_transport_records':len(old774['records']),'root044_registration_prefix_match':False,'root044_qualification_prefix_match':True,'qualification':'Source/archive/Git/record integrity verification only; earlier root044 pinned registry bytes remain unverified in bounded search. No product or test execution.'};print(json.dumps(result,indent=2))
