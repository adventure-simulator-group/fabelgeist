import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_text());sup=json.loads((p/'support-registration.json').read_text());
def comp(rr,n):
 k=1;out=[]
 for a,b in rr:
  if k<a:out.append([k,a-1])
  k=b+1
 if k<=n:out.append([k,n])
 return out
reads=[]
for x in reg['sources']:
 rr=x['planned_display'];reads.append({'original_role':x['original_role'],'kind':'native-package','path':x['package_member'],'archive':x['source_archive'],'actual_display_union':rr,'unread_ranges':comp(rr,x['lines']),'full_body_displayed':False,'qualification':'Personally displayed after registration; other source bytes archived but not read.'})
x=reg['current_lock'];rr=x['planned_display'];reads.append({'kind':'current-lock','revision':x['revision'],'path':x['path'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':comp(rr,x['lines']),'full_body_displayed':False,'qualification':'Current lock package clause personally displayed; other clauses unread.'})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':h((p/'registration.json').read_bytes()),'reads':reads},indent=2)+'\n')
reads=[]
for x in sup['sources']:
 rr=x['planned_display'];u=comp(rr,x['lines']);reads.append({'kind':'current-project','path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':u,'full_body_displayed':not u})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':h((p/'support-registration.json').read_bytes()),'reads':reads},indent=2)+'\n')
print('native reads',[(x['original_role'],x['actual_display_union'],x['unread_ranges']) for x in json.loads((p/'read-receipt.json').read_text())['reads'] if 'original_role'in x])
