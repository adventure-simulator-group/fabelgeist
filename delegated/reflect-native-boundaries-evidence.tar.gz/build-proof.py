import datetime,gzip,hashlib,json,pathlib,re,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());C=reg['current_lock']['revision'];F='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';support=[dict(x,kind='current-project-support') for x in json.loads((p/'support-registration.json').read_text())['sources']];lock=dict(reg['current_lock'],kind='current-lock');native=[]
for x in reg['sources']:
 b=(p/x['source_archive']).read_bytes();native.append({'kind':'native-object-archive-transport','revision':F,'path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],'archive':x['source_archive'],'sha256':x['sha256'],'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
hist=json.loads((p/'historical-774-index.json').read_text())['records'];historical=[{'kind':'historical-record-transport','revision':x['git_transport_revision'],'path':x['git_transport_path'],'archive':x['copy'],'sha256':x['sha256'],'git_blob_sha1':x['git_blob_sha1'],'encoding':'gzip'} for x in hist];locks=[{'kind':'historical-lock-transport' if x['original_role']==39 else 'historical-pr-working-lock','revision':x['revision'],'path':x['git_path'],'archive':x['archive'],'sha256':x['sha256'],'git_blob_sha1':x['git_blob_sha1'],'encoding':'gzip'} for x in json.loads((p/'historical-locks-index.json').read_text())['records']];records=[lock]+support+native+historical+locks;d=p/'git-objects';d.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=d/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 commit=get('commit',x['revision']);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b
 assert tree==x['git_blob_sha1'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'kind':x['kind'],'revision':x['revision'],'path':x['path'],'archive':x['archive'],'encoding':x.get('encoding','raw'),'commit_tree':root,'chain':chain,'blob':tree,'sha256':x['sha256']})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Current project and lock path membership; old lock sources at separately recorded transports; f82 stores native object/old records only, never package origin or project revision. Native package archive checksum and members are independently verified.','objects':objects,'proofs':proof},indent=2)+'\n')
