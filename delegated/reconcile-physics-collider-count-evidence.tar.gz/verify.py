from pathlib import Path
import gzip,hashlib,json
b=Path(__file__).resolve().parent;x=json.loads((b/'RECONCILIATION.json').read_bytes());pub=Path(x['links']['publication_root']);h=lambda d:hashlib.sha256(d).hexdigest()
for e in x['links']['publication']:
 data=(pub/e['path']).read_bytes();assert len(data)==e['bytes'] and h(data)==e['sha256'],e['path']
for e in x['links']['local_packet']:
 data=Path(e['path']).read_bytes();assert len(data)==e['bytes'] and h(data)==e['sha256'],e['path']
r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'));q=json.loads((pub/'baseline-059/queue.json').read_bytes())
for e in x['source_roles']:
 row=r['files'][e['original_index']];assert row['source_id']==e['registry_source_id'] and row['sha256']==e['sha256'] and row['actual_line_count']==e['actual_eof'] and row['material_ranges']==e['original_registry_material_ranges']
assert x['source_roles'][1]['original_registry_material_ranges']==[[1,133],[212,218]] and x['source_roles'][1]['separately_registered_personal_connected_support_ranges']==[[134,211]]
for e in x['related_original_queue']:assert q['entries'][e['index_zero_based']]['contract_id']==e['contract_id']
assert len(x['rows'])==len({e['id'] for e in x['rows']})==7
print('PASS: point-in-time evidence links, original scope partitions and 059 queue mapping. No product execution.')
