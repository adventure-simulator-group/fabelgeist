# Physics collider/count reconciliation proposal

`RECONCILIATION.json` maps frozen checkpoint 10 role evidence to the existing
059 and central assessment records and identifies conditional distinct candidate
contracts for central adjudication. Role 2482 original material is `1–133` and
`212–218`; `134–211` is separately read connected support. Historical
reviewers, original revision and transport, corrected 774 attribution, and
checkpoint 10 path-redacted members remain qualified in the proposal.

Run `python3 verify.py` to check the point-in-time evidence links and scope
mapping. If central reconciliation advances a linked mutable file, its saved
hash describes the earlier observed state, and this check will flag the new
state rather than recast it as identical. No product code is run.
