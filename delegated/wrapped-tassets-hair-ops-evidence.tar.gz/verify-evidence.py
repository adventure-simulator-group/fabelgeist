'''Evidence-integrity verification only; no product execution or validation.'''
import gzip,hashlib,json,tarfile
from datetime import datetime
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json')
for x in hist['hash_links']:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
for x in hist['exact_original_files']:
 b=(p/x['local']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'] and Path(x['source_path']).read_bytes()==b,x['local']
for x in rec['registrations']:
 assert h((p/x['path']).read_bytes())==x['sha256'];assert datetime.fromisoformat(load(x['path'])['registered_utc'])<=datetime.fromisoformat(rec['recorded_utc'])
registry=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/registry.json.gz')));rb=gzip.decompress(registry.read_bytes());assert h(rb)==reg['registry_uncompressed_sha256'];original=json.loads(rb)['files']
archive=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/objects.tar.gz')));assert h(archive.read_bytes())==reg['source_archive_sha256']
with tarfile.open(archive,'r:gz') as t:
 for x in reg['rows']:
  old=(p/x['old_archive']).read_bytes();prev=(p/f"source/{x['role']}-6533.rs").read_bytes();new=(p/f"source/{x['role']}-95e6.rs").read_bytes()
  assert original[x['role']]==x['original_registry_record'] and h(old)==x['old_sha256'] and old==prev==new==t.extractfile(x['old_sha256']).read()
  assert len(old.splitlines())==x['old_lines'] and h(new)==x['git_comparisons'][reg['current_revision']]['sha256']
  rr=next(v for v in rec['assigned'] if v['role']==x['role']);assert rr['unread_old_and_current']==[]
  for key,pk,n in [('pr_working_actual_display','pr_working',len(old.splitlines())),('current_95e_actual_display','current95e',len(new.splitlines()))]:
   assert [i for a,z in rr[key] for i in range(a,z+1)]==list(range(1,n+1))
   for a,z in rr[key]:assert any(c<=a<=z<=d for c,d in x['prospective_display'][pk])
planned={}
for n in [x['path'] for x in rec['registrations'] if x['path'].startswith('support-registration')]:
 for x in load(n)['sources']:assert x['saved'] not in planned;planned[x['saved']]=x
for x in rec['support']:
 s=planned[x['saved']];b=(p/x['saved']).read_bytes();assert h(b)==x['sha256']==s['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==x['eof']==s['eof'];used=[]
 for a,z in x['displayed']+x['unread_complement']:assert 1<=a<=z<=x['eof'];used.extend(range(a,z+1))
 assert len(used)==x['eof'] and set(used)==set(range(1,x['eof']+1))
 for a,z in x['displayed']:assert any(c<=a<=z<=d for c,d in s['prospective_ranges'])
objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 raise ValueError(name)
for x in proof['proofs']:
 current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for s in x['chain']:
  assert current==s['tree'] and lookup(objects[current],s['name'])==(s['mode'],s['object']);current=s['object']
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and h(b)==x['sha256']
prior=hist['prior_774_records_in_published_archive']['archive']
with tarfile.open(prior,'r:gz') as t:
 rr=[json.loads(v) for v in t.extractfile('historical/774-rig-source-range-registration.jsonl').read().splitlines()];add=[json.loads(v) for v in t.extractfile('historical/774-rig-additional-contracts.jsonl').read().splitlines()];x=reg['rows'][0]
 for ob in x['original_registry_record']['admission03_scope_observations']:assert rr[ob['row_1based']-1]==ob['original_record']
 a=next(v for v in add if v['id']=='RIG-ADMISSION03-ADDITIONAL-074');assert a['sha256']==x['old_sha256'] and a['actual_source_ranges']==[[1,54]]
l11=load('historical/059--segovb--READ-L11-428.json');primary=next(v for v in l11['sources'] if v['registration'].endswith('REGISTRATION-SEGOVB-1540.json'));ext=next(v for v in l11['sources'] if v['registration'].endswith('REGISTRATION-SEGOVB-1541.json'));assert primary['original_index']==2625 and primary['fresh_personal_body_reads']==[[1,54]] and ext['fresh_personal_body_reads']==[[55,56]]
l12=load('historical/059--segovb--READ-L12-898.json');assert l12['root_personal_rereads']==[] and l12['delegated_attribution_preserved'];row=next(v for v in l12['rows'] if v['original_index']==2625);assert row['source_sha256']==reg['rows'][0]['old_sha256'] and row['fresh_personal_body_reads']==[[1,54]] and '/root/lens12_frontier' in row['attribution']
team=load('historical/059--segovb--READ-L12-CONNECTED-TEAM-023.json');row=next(v for v in team['exact_source_rows'] if v['original_index']==2625);assert row['fresh_personal_ranges']==[[55,56]] and '/root/lens12_frontier' in row['read_attribution']
prior=next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/ASSESSMENT-L01-TASSET-NODE-95E.json'));obj=json.loads(Path(prior).read_bytes());row=next(v for v in obj['current_sources'] if v['path']=='crates/fabelgeist-armor/src/wrapped_tassets.rs');assert row['ranges']==[[1,62]]
prior=next(x['path'] for x in hist['hash_links'] if x['path'].endswith('armor-anime-helmets-hair-ops-evidence.tar.gz'))
with tarfile.open(prior,'r:gz') as t:
 oldrec=json.load(t.extractfile('read-receipt.json'));row=next(v for v in oldrec['support'] if v['path']=='crates/adventuresim-character-creator/src/runtime_equipment/warmup.rs');assert oldrec['agent']=='/root/hair_ops' and row['displayed']==[[1,85]]
sel=load(hist['reconstructed_selection']);qb=Path(sel['queue_path']).read_bytes();lb=Path(sel['ledger_path']).read_bytes();assert h(qb)==sel['queue_sha256'] and h(lb)==sel['ledger_sha256'];q=json.loads(qb)['entries'];ledger=json.loads(lb)['segovb_continuation']['lens13']['delegated_connected_contracts_pending_alias']
for x in sel['queue_rows']:assert q[x['index']]==x['entry']
for x in sel['ledger_rows']:assert ledger[x['index']]==x['entry']
nav=(p/'tasset-side-navigation.txt').read_text().splitlines();assert len(nav)==2 and all('TassetSide' in v for v in nav)
if (p/'MANIFEST.json').exists():
 for x in load('MANIFEST.json')['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
print(f"PASS: full separate old/current assigned reads; {len(proof['proofs'])} Git membership proofs; {len(rec['support'])} support partitions; original 774/059 receipts, reconstructed queue and ledger links. Evidence integrity only; no product execution or validation.")
