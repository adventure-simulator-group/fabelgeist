'''Prospective support continuation; no product execution.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';paths=[('crates/adventuresim-character-creator/src/device_wrapped_tasset.rs',[[221,250]]),('crates/fabelgeist-armor/src/lib.rs',[[130,150]])];a=[]
for i,(path,ranges) in enumerate(paths,8):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':len(b.splitlines()),'saved':saved,'prospective_ranges':ranges,'qualification':'Fresh bounded current support only, no earlier or ordered-role credit.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-2.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-2.json').read_bytes()).hexdigest())
