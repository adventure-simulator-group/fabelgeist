# Bounded armor evidence: original role 2625

`REPORT.json` records the source observations, thirteen bounded perspectives,
open questions and prior evidence relationships. The registered pr-working and
95e bodies were personally displayed separately. Their per-file bytes equal the
6533 file, but that copy was not separately displayed. The pr-working snapshot
had unrelated modifications; f82 is evidence transport, not source HEAD.

`source/` and `support/` hold the exact registered bytes, and `git-objects/`
with `git-proofs.json` preserve commit-to-blob proofs. The historical manifest
identifies exact 059 records, a reconstructed queue/ledger selection and
hash-linked prior published 774/current assessments. The original 774 scope was
1–54; later 059 closing-line reads are separately attributed and do not include
TassetSide. A prior 95e assessment already read the whole current body. P16 patch
recovery is separate and no earlier record becomes checkpoint 3821.

`python3 verify-evidence.py` checks evidence integrity, assuming linked evidence
remains at the recorded absolute paths; relocated dependencies must be resolved
by SHA-256. It does not execute or validate product code. Any shader/test text
is source only and was not compiled or run.
