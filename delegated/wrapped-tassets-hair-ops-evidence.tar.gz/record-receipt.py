import datetime,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;h=lambda b:hashlib.sha256(b).hexdigest();names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json']
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};r=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):r.append([start,i-1]);start=None
 return r
reads=[]
for n in names[1:]:
 for x in json.loads((p/n).read_bytes())['sources']:
  ranges=[[1,110],[111,220]] if x['saved']=='support/03.rs' else x['prospective_ranges'];reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['eof'],'displayed':ranges,'unread_complement':complement(x['eof'],ranges),'qualification':'Fresh current bounded support; no prior or ordered-role credit. Shader/test text not executed or compiled.'})
assigned=[{'role':2625,'pr_working_actual_display':[[1,62]],'current_95e_actual_display':[[1,62]],'unread_old_and_current':[]}]
o={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in names],'assigned':assigned,'other_revision':'6533 copies verified by byte/Git identity only, not separately displayed. pr-working and 95e bodies personally displayed separately.','prior_current':'Earlier ASSESSMENT-L01-TASSET-NODE-95E records current 1–62 and full device_wrapped_tasset.rs 1–339; its report names no individual reviewer. The earlier /root/hair_ops armor-anime-helmets packet records warmup.rs 1–85 as support. These earlier reads remain separately attributed; this packet independently registered and displayed its support windows.','support':reads,'constraints':'Source and evidence inspection only; no tests, shader compilation or product execution.'};(p/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n');print('receipt sha256',h((p/'read-receipt.json').read_bytes()))
