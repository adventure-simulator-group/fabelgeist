from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile,io
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');g=lambda *a:subprocess.check_output(['git','-C',str(pub),*a]);sha=lambda d:hashlib.sha256(d).hexdigest();(b/'support').mkdir(exist_ok=True)
rows=[]
for label,rev in [('pr-base','6533e444fa37552927070cc8d8190907fd3b413e'),('current','95e63628f9d70b8dd6e6fede64334696c6995009')]:
 for path,ranges in [('crates/fabelgeist-fbx/Cargo.toml',None),('crates/fabelgeist-fbx/src/array_encoding.rs',None),('crates/fabelgeist-fbx/src/lib.rs',[[420,480]])]:
  raw=g('show',rev+':'+path);eof=len(raw.splitlines());rng=ranges or [[1,eof]];assert all(1<=a<=z<=eof for a,z in rng);name=f'support/{label}-{Path(path).name}';(b/name).write_bytes(raw);rows.append({'kind':'project support, no ordered-role credit','label':label,'revision':rev,'path':path,'git_blob':g('rev-parse',rev+':'+path).decode().strip(),'archive':name,'sha256':sha(raw),'eof':eof,'registered_ranges':rng})
for pkg in ['num_enum','num_enum_derive']:
 cr=Path('<LOCAL_PATH_1>')/(pkg+'-0.7.6.crate');raw=cr.read_bytes();expect={'num_enum':'5d0bca838442ec211fa11de3a8b0e0e8f3a4522575b5c4c06ed722e005036f26','num_enum_derive':'680998035259dcfcafe653688bf2aa6d3e2dc05e98be6ab46afb089dc84f1df8'}[pkg];assert sha(raw)==expect
 if pkg=='num_enum':(b/'metadata/num_enum-0.7.6.crate').write_bytes(raw)
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  for member,ranges in ([('Cargo.toml',[[47,51],[85,88]]),('src/lib.rs',[[1,53]])] if pkg=='num_enum' else [('Cargo.toml',None)]):
   content=t.extractfile(pkg+'-0.7.6/'+member).read();eof=len(content.splitlines());rng=ranges or [[1,eof]];assert all(1<=a<=z<=eof for a,z in rng);name=f'support/{pkg}-{Path(member).name}';(b/name).write_bytes(content);rows.append({'kind':'native package support, no ordered-role credit','package':pkg,'version':'0.7.6','archive_sha256':sha(raw),'member':pkg+'-0.7.6/'+member,'archive':name,'sha256':sha(content),'eof':eof,'registered_ranges':rng})
data={'schema':'726-num-enum-support-prospective-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','purpose':'Inspect package feature declarations/reexport and bounded FBX declaration and use; metadata is not Cargo feature resolution or execution. Historical and current support separately displayed.','entries':rows};(b/'support-registration.json').write_text(json.dumps(data,indent=2)+'\n');print('registration sha256',sha((b/'support-registration.json').read_bytes()));print(json.dumps(rows,indent=2))
