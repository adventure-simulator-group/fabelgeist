from pathlib import Path
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda d:hashlib.sha256(d).hexdigest();out=[]
for name,local,files in [('p16-catalog-occupancy-surface','<LOCAL_PATH_1>',['MANIFEST.json','git-proofs.json','historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl','historical-774-compressed/additional-contracts.jsonl.gz','historical-774-compressed/contract-groups.jsonl.gz','historical-774-compressed-attribution.json']),('p16-main-validator-serde','<LOCAL_PATH_2>',['MANIFEST.json','REPORT.json','registration.json','git-proofs.json','metadata/p16-dirty-Cargo.lock.gz'])]:
 p=pub/(name+'-evidence.tar.gz');d=p.read_bytes();members=[]
 with tarfile.open(p,'r:gz') as t:
  for f in files:
   x=t.extractfile(f).read();y=(Path(local)/f).read_bytes();entry={'member':f,'published_sha256':sha(x),'local_sha256':sha(y),'published_bytes':len(x),'local_bytes':len(y),'byte_identical':x==y}
   if x!=y:
    assert f.endswith('contract-groups.jsonl.gz');a=gzip.decompress(x);c=gzip.decompress(y);aa=a.splitlines();cc=c.splitlines();assert len(aa)==len(cc)
    rows=[]
    for i in (649,652):
     assert aa[i-1]==cc[i-1];rows.append({'row_1based':i,'id':json.loads(aa[i-1])['id'],'sha256_of_exact_row_bytes':sha(aa[i-1]),'byte_identical':True})
    entry.update({'published_uncompressed_sha256':sha(a),'local_original_uncompressed_sha256':sha(c),'first_different_row_1based':next(i for i,(z,w) in enumerate(zip(aa,cc),1) if z!=w),'selected_rows':rows,'qualification':'Published checkpoint14 reconstructed public copy redacts paths; not the exact original full file. Original locally retained separately and f82 transport membership remains proof.'})
   members.append(entry)
 out.append({'published_archive':str(p),'sha256':sha(d),'bytes':len(d),'local_original_bundle':local,'checked_members':members})
(b/'published-prior-packet-links.json').write_text(json.dumps({'schema':'726-published-prior-packet-recovery-v1','archives':out,'qualification':'Selected historical rows compared byte for byte. Published reconstructed full-file copy is separately labeled; preserve original and published hashes/attribution.'},indent=2)+'\n');print([(x['published_archive'],x['sha256']) for x in out])
