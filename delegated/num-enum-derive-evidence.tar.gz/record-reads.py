from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();load=lambda n:json.loads((b/n).read_text());reg=load('registration.json');support=load('support-registration.json');helper=load('helper-registration.json')
def complement(eof,rs):
 x={i for a,z in rs for i in range(a,z+1)}; missing=sorted(set(range(1,eof+1))-x);out=[]
 for i in missing:
  if not out or i>out[-1][1]+1:out.append([i,i])
  else:out[-1][1]=i
 return out
chunks={2626:[[190,260]],2627:[[1,20],[62,181],[182,301],[302,406],[408,447],[506,533]],2628:[[1,120],[121,210]]};reads=[]
for x in reg['roles']:
 ranges=x['registered_ranges'];c=chunks[x['role']];assert {i for a,z in ranges for i in range(a,z+1)}=={i for a,z in c for i in range(a,z+1)}
 reads.append({'kind':'assigned original material','role':x['role'],'source_id':x['source_id'],'archive':x['preserved_source'],'sha256':x['sha256'],'actual_eof':x['eof'],'registration':'registration.json','actual_display_ranges':ranges,'actual_display_chunks':c,'unread_complement_at_this_assigned_read':complement(x['eof'],ranges),'actual_read_qualification':'All stated chunks displayed without tool truncation after registration; adjacent planned 60-line chunks were coalesced into at most 120-line displays. Full archived bytes are not whole-file read credit.'})
for x in support['entries']:
 rs=x['registered_ranges'];reads.append({'kind':x['kind'],'archive':x['archive'],'sha256':x['sha256'],'revision':x.get('revision'),'package':x.get('package'),'actual_eof':x['eof'],'registration':'support-registration.json','actual_display_ranges':rs,'actual_display_chunks':rs,'unread_complement_at_this_support_read':complement(x['eof'],rs),'actual_read_qualification':'Displayed after distinct registration, no original role credit.'})
reads.append({'kind':'separate package path-helper support','archive':helper['source'],'sha256':helper['sha256'],'package':helper['package'],'actual_eof':helper['eof'],'registration':'helper-registration.json','actual_display_ranges':helper['registered_ranges'],'actual_display_chunks':helper['registered_ranges'],'unread_complement_at_this_support_read':complement(helper['eof'],helper['registered_ranges']),'actual_read_qualification':'Extra lines 534–574 are separately registered support, not original role credit or Cargo feature resolution.'})
regs=[]
for f in ['registration.json','support-registration.json','helper-registration.json']:
 z=(b/f).read_bytes();regs.append({'path':f,'sha256':sha(z),'registered_utc':json.loads(z)['registered_utc']})
x={'schema':'726-num-enum-personal-read-receipt-v1','author':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registration_hashes':regs,'reads':reads,'scope_qualification':'Actual displayed chunks are recorded rather than planned chunk partition. Old 774 and 059 reads remain independently attributed, no cross-lens or checkpoint3821 transfer.'};(b/'personal-read-receipt.json').write_text(json.dumps(x,indent=2)+'\n');print('reads',len(reads),'sha256',sha((b/'personal-read-receipt.json').read_bytes()))
