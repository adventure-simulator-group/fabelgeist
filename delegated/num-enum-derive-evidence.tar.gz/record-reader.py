from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda x:hashlib.sha256(x).hexdigest();a=(b/'personal-read-receipt-initial.json').read_bytes();r=json.loads(a);z=(b/'reader-registration.json').read_bytes();reg=json.loads(z);now=datetime.now(timezone.utc).isoformat();assert datetime.fromisoformat(reg['registered_utc'])<datetime.fromisoformat(now)
r['initial_receipt']={'path':'personal-read-receipt-initial.json','sha256':sha(a),'qualification':'Initial 13 personal reads retained unchanged; later reader support added prospectively.'};r['recorded_utc']=now;r['registration_hashes'].append({'path':'reader-registration.json','sha256':sha(z),'registered_utc':reg['registered_utc']})
for x in reg['entries']:
 r['reads'].append({'kind':x['kind'],'archive':x['archive'],'sha256':x['sha256'],'revision':x['revision'],'actual_eof':x['eof'],'registration':'reader-registration.json','actual_display_ranges':x['registered_ranges'],'actual_display_chunks':x['registered_ranges'],'unread_complement_at_this_support_read':[[1,221],[248,x['eof']]],'actual_read_qualification':'Separate support display after registration; complements describe this specific support registration, other registered reads remain separate.'})
(b/'personal-read-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('reads',len(r['reads']),'sha256',sha((b/'personal-read-receipt.json').read_bytes()))
