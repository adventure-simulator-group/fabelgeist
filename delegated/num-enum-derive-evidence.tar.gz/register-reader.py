from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;rows=[]
for label,rev in [('pr-base','6533e444fa37552927070cc8d8190907fd3b413e'),('current','95e63628f9d70b8dd6e6fede64334696c6995009')]:
 p=f'support/{label}-lib.rs';raw=(b/p).read_bytes();rows.append({'archive':p,'revision':rev,'path':'crates/fabelgeist-fbx/src/lib.rs','sha256':hashlib.sha256(raw).hexdigest(),'eof':len(raw.splitlines()),'registered_ranges':[[222,247]],'kind':'separate reader support; no ordered role credit'})
x={'schema':'726-num-enum-reader-support-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows};(b/'reader-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(hashlib.sha256((b/'reader-registration.json').read_bytes()).hexdigest())
