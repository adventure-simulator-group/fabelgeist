from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent;p=Path('<LOCAL_PATH_0>');out=[]
for n in ['MANIFEST.json','REPORT.json','registration.json','git-proofs.json','metadata/p16-dirty-Cargo.lock.gz']:
 d=(p/n).read_bytes();out.append({'path':str(p/n),'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'qualification':'Earlier packet; original P16 dirty lock transported by f82, source-only structured package selection, no 3821 transfer.'})
(b/'prior-lock-evidence-links.json').write_text(json.dumps({'schema':'726-prior-p16-lock-hash-links-v1','links':out},indent=2)+'\n');print('links',len(out))
