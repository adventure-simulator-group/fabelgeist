from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,sys,tarfile,tomllib
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda t,d:hashlib.sha1(t.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();load=lambda p:json.loads(Path(p).read_bytes());gun=lambda p:gzip.decompress(Path(p).read_bytes())
links=load(b/'evidence-links.json')['links']
for x in links:
 d=Path(x['path']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes'],x['path']
r=load(b/'registration.json');sr=load(b/'support-registration.json');rec=load(b/'personal-read-receipt.json');report=load(b/'REPORT.json');original=json.loads(gun(pub/'recovered/original-registry-source-archive/registry.json.gz'));sel=load(b/'registry-selection-reconstructed.json');
assert sha(gun(pub/'recovered/original-registry-source-archive/registry.json.gz'))=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f'
for x in sel['rows']:assert {k:v for k,v in x.items() if k!='original_index'}==original['files'][x['original_index']]
for x in sel['snapshots']:assert x in original['snapshots']
pr=next(x for x in original['snapshots'] if x['id']=='pr-working');assert pr['head']=='6533e444fa37552927070cc8d8190907fd3b413e' and len(pr['status_porcelain'])==4
p16=next(x for x in original['snapshots'] if x['id']=='physical-p16');assert p16['base']=='a120390947c89b703dc74c4255a13c035d054c50' and p16['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load(pub/'RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==p16['patch_sha256'] and recovery['recovered_patch']['bytes']==524542 and recovery['live_comparison']['status_counts']=={' M':151,' D':1,'??':7}
crate=(b/r['package_archive']['preserved']).read_bytes();assert sha(crate)==r['package_archive']['sha256']=='680998035259dcfcafe653688bf2aa6d3e2dc05e98be6ab46afb089dc84f1df8'
with tarfile.open(fileobj=io.BytesIO(crate),mode='r:gz') as t:
 for x in r['roles']:
  d=(b/x['preserved_source']).read_bytes();o=original['files'][x['role']];assert d==t.extractfile(x['archive_member']).read() and sha(d)==x['sha256']==o['sha256'] and len(d)==x['bytes']==o['bytes'] and len(d.splitlines())==x['eof']==o['actual_line_count'] and x['registered_ranges']==o['material_ranges']
for e in r['lock_metadata']:
 d=gun(b/e['preserved_gzip']);assert sha(d)==e['sha256'];pkgs=[x for x in tomllib.loads(d.decode())['package'] if x['name'] in ('num_enum','num_enum_derive')];assert pkgs==e['records']
 assert next(x for x in pkgs if x['name']=='num_enum_derive')['checksum']==sha(crate)
p=r['p16_dirty_lock_reference'];d=Path(p['path']).read_bytes();assert sha(d)==p['compressed_sha256'] and sha(gzip.decompress(d))==p['uncompressed_sha256'];pkgs=[x for x in tomllib.loads(gzip.decompress(d).decode())['package'] if x['name'] in ('num_enum','num_enum_derive')];assert pkgs==p['records'] and next(x for x in pkgs if x['name']=='num_enum_derive')['checksum']==sha(crate)
for x in sr['entries']:
 d=(b/x['archive']).read_bytes();assert sha(d)==x['sha256'] and len(d.splitlines())==x['eof']
 if x['kind'].startswith('native'):
  cr=(b/f"metadata/{x['package']}-0.7.6.crate").read_bytes();assert sha(cr)==x['archive_sha256']
  with tarfile.open(fileobj=io.BytesIO(cr),mode='r:gz') as t:assert t.extractfile(x['member']).read()==d
  for lock in r['lock_metadata']+[p]:assert next(y for y in lock['records'] if y['name']==x['package'])['checksum']==sha(cr)
for tail,idx in [('Cargo.toml',2251),('array_encoding.rs',2254),('lib.rs',2257)]:
 a=(b/('support/pr-base-'+tail)).read_bytes();c=(b/('support/current-'+tail)).read_bytes();assert a==c and sha(a)==original['files'][idx]['sha256']
 assert not any(s[3:]==original['files'][idx]['source_id'].split(':',1)[1] for s in pr['status_porcelain'])
q=load(pub/'baseline-059/queue.json')['entries']
for x in load(b/'queue-selection-reconstructed.json')['entries']:assert x['entry']==q[x['original_index_zero_based']]
assert q[2942]['contract_id']=='L12-CLOSURE-FBX-NUM-ENUM-NATIVE-ADAPTER'
at=load(b/'historical-attribution.json');assert not at['missing'];mi=json.loads(gun(pub/'recovered/original-transport-manifest.json.gz'));idx={x['path']:x for x in mi['entries']}
for x in at['records_059']:
 d=(b/x['preserved_bytes']).read_bytes();m=idx[x['original_path']];assert sha(d)==x['sha256']==m['sha256'] and len(d)==x['bytes']==m['bytes'] and oid('blob',d)==x['git_blob']==m['git_blob']
l11=load(b/'historical-059/segovb/READ-L11-429.json')
for i,n in [(2626,899),(2627,900),(2628,901)]:
 x=next(x for x in l11['sources'] if x['original_index']==i);y=next(x for x in load(b/f'historical-059/segovb/READ-L12-{n}.json')['rows'] if x['original_index']==i);expect=original['files'][i]['material_ranges'];assert x['fresh_personal_body_reads']==y['fresh_personal_body_reads']==expect and '/root/lens12_frontier' in y['attribution']
old=Path('<LOCAL_PATH_1>');src=old/'historical-774/handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl';lines=[json.loads(x) for x in src.read_bytes().splitlines()]
for i in [2626,2627,2628]:
 for x in original['files'][i]['admission03_scope_observations']:assert lines[x['row_1based']-1]==x['original_record']
for name,want in [('additional-contracts.jsonl.gz',{'RIG-ADMISSION03-ADDITIONAL-080','RIG-ADMISSION03-ADDITIONAL-081','RIG-ADMISSION03-ADDITIONAL-082','RIG-ADMISSION03-ADDITIONAL-083'}),('contract-groups.jsonl.gz',{'RIG-ADMISSION03-CONTRACT-649','RIG-ADMISSION03-CONTRACT-652'})]:
 data=gun(old/'historical-774-compressed'/name);entries=[json.loads(x) for x in data.splitlines()];assert want<={x['id'] for x in entries}
 # The prior packet's separately linked provenance binds the uncompressed exact file to f82 transport.
 proof=load(old/'historical-774-compressed-attribution.json');p=next(x for x in proof['records'] if x['preserved_gzip'].endswith(name));assert sha(data)==p['sha256'] and len(data)==p['bytes'] and oid('blob',data)==p['git_blob']
proof=load(b/'git-proofs.json');objs={}
for k,x in proof['objects'].items():
 d=gun(b/x['preserved_bytes']);assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid(x['type'],d)==k;objs[k]=d
for rev,x in proof['commits'].items():assert objs[rev].splitlines()[0].split()[1].decode()==x['root_tree']
def entries(raw):
 out={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);out[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return out
for x in proof['paths']:
 cur=proof['commits'][x['revision']]['root_tree'];parts=x['path'].split('/');assert len(parts)==len(x['path_chain'])
 for name,s in zip(parts,x['path_chain']):
  assert s['tree']==cur and s['name']==name;mode,child=entries(objs[cur])[name];assert mode==s['mode'] and child==s['object'];cur=child
 p=b/x['preserved_bytes'];d=gun(p) if str(p).endswith('.gz') else p.read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256'] and oid('blob',d)==x['git_blob']==cur
# Independently verify the earlier packets' raw Git path proofs for the linked 774 files and P16 lock.
for x in load(b/'prior-lock-evidence-links.json')['links']:
 d=Path(x['path']).read_bytes();assert sha(d)==x['sha256'] and len(d)==x['bytes']
assert original['files'][39]['source_id']=='physical-p16:Cargo.lock' and original['files'][39]['sha256']==r['p16_dirty_lock_reference']['uncompressed_sha256']
for prior_base, suffixes in [(old,['/source-range-registration.jsonl','/additional-contracts.jsonl','/contract-groups.jsonl']), (Path('<LOCAL_PATH_2>'),['/1191ee1e830f870d16ebaa30e6d84953656acaed04cf9c2a0367bbbcb1f78201'])]:
 gp=load(prior_base/'git-proofs.json'); prev={}
 for k,x in gp['objects'].items():
  d=gun(prior_base/x['preserved_bytes']);assert sha(d)==x['sha256'] and len(d)==x['bytes'] and oid(x['type'],d)==k;prev[k]=d
 for suffix in suffixes:
  match=[x for x in gp['paths'] if x['path'].endswith(suffix)];assert len(match)==1;p=match[0];cur=gp['commits'][p['revision']]['root_tree'];assert p['revision']=='f82adcabd9d89c4fa2dd7f99253a45297a0681ee' and prev[p['revision']].splitlines()[0].split()[1].decode()==cur
  for name,step in zip(p['path'].split('/'),p['path_chain']):
   assert step['tree']==cur and step['name']==name;mode,child=entries(prev[cur])[name];assert mode==step['mode'] and child==step['object'];cur=child
  source=prior_base/p['preserved_bytes'];d=gun(source) if str(source).endswith('.gz') else source.read_bytes();assert sha(d)==p['sha256'] and oid('blob',d)==p['git_blob']==cur
# Check published copies separately; the one path-redacted reconstructed member is not exact original.
for packet in load(b/'published-prior-packet-links.json')['archives']:
 data=Path(packet['published_archive']).read_bytes();assert sha(data)==packet['sha256'] and len(data)==packet['bytes']
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
  for member in packet['checked_members']:
   a=t.extractfile(member['member']).read();c=(Path(packet['local_original_bundle'])/member['member']).read_bytes();assert sha(a)==member['published_sha256'] and sha(c)==member['local_sha256'] and (a==c)==member['byte_identical']
   if not member['byte_identical']:
    aa=gzip.decompress(a);cc=gzip.decompress(c);assert sha(aa)==member['published_uncompressed_sha256'] and sha(cc)==member['local_original_uncompressed_sha256'];oldrows=cc.splitlines();newrows=aa.splitlines();assert len(oldrows)==len(newrows)
    assert next(i for i,(x,y) in enumerate(zip(newrows,oldrows),1) if x!=y)==member['first_different_row_1based']
    for row in member['selected_rows']:
     i=row['row_1based'];assert newrows[i-1]==oldrows[i-1] and sha(oldrows[i-1])==row['sha256_of_exact_row_bytes'] and json.loads(oldrows[i-1])['id']==row['id']
for x in rec['registration_hashes']:
 d=(b/x['path']).read_bytes();assert sha(d)==x['sha256'] and datetime.fromisoformat(json.loads(d)['registered_utc'])<datetime.fromisoformat(rec['recorded_utc'])
initial=(b/rec['initial_receipt']['path']).read_bytes();assert sha(initial)==rec['initial_receipt']['sha256']
scopes={}
for x in rec['reads']:
 data=(b/x['archive']).read_bytes();assert sha(data)==x['sha256'] and len(data.splitlines())==x['actual_eof'];rng=x['actual_display_ranges'];chunk=x['actual_display_chunks']
 regdata=load(b/x['registration'])
 if x['registration']=='registration.json':matches=[z for z in regdata['roles'] if z['preserved_source']==x['archive'] and z['role']==x['role']]
 elif x['registration']=='helper-registration.json':matches=[regdata] if regdata['source']==x['archive'] else []
 else:matches=[z for z in regdata['entries'] if z['archive']==x['archive'] and z.get('revision')==x.get('revision')]
 assert len(matches)==1 and matches[0]['sha256']==x['sha256'] and matches[0]['registered_ranges']==rng
 covered={i for a,z in rng for i in range(a,z+1)};assert covered=={i for a,z in chunk for i in range(a,z+1)};complement=x.get('unread_complement_at_this_support_read',x.get('unread_complement_at_this_assigned_read'));other={i for a,z in complement for i in range(a,z+1)};assert not covered&other and covered|other==set(range(1,x['actual_eof']+1));scopes.setdefault((x['archive'],x['sha256']),set()).update(covered)
assert len(rec['reads'])==15 and sum(x['kind']=='assigned original material' for x in rec['reads'])==3
assert len(report['lenses'])==13 and len({x['lens'] for x in report['lenses']})==13
def visit(x):
 if isinstance(x,dict):
  if all(k in x for k in ('archive','lines','sha256')):
   a,z=x['lines'];assert set(range(a,z+1))<=scopes[(x['archive'],x['sha256'])],x
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(report)
result={'schema':'726-evidence-only-verification-v1','checked_utc':datetime.now(timezone.utc).isoformat(),'result':'pass','counts':{'original_roles':3,'personal_read_entries':15,'raw_git_path_proofs':len(proof['paths']),'original_059_records':len(at['records_059']),'bounded_lens_perspectives':len(report['lenses'])},'checks':['Native package archive checksums, matching registered f82 original member bytes and structured old/current/P16 lock records','Raw Git commit/tree path membership for f82 source transport, project support and Cargo.lock','Reconstructed original 059 registry and queue selections, original recovered 059 records against transport manifest, and linked 774 registrations/contracts','Prospective personal registrations and actual scoped read partitions with cited lines verified','Later P16 tracked-patch and original dirty-snapshot qualifications preserved; no checkpoint3821 promotion','Evidence/source verification only; no product, macro, compiler, build, test, fixture, simulation or runtime validation.']};raw=(json.dumps(result,indent=2)+'\n').encode()
if '--record' in sys.argv:(b/'evidence-verification.json').write_bytes(raw)
print('PASS',sha(raw),result['counts'])
