# Bounded num_enum_derive source evidence

This packet records the independent `/root/rig_identity` source-only review of
original roles 2626–2628. `REPORT.json` describes the scoped thirteen
perspectives, nonfindings, existing connected contracts, historical attribution,
open questions and boundaries. It is not a complete-lens verdict or product
validation.

`registration.json` preceded the personal role displays; separate registrations
cover FBX and native-package supports. `personal-read-receipt.json` records the
actual displayed ranges and complements. Full native source bytes and the two
small Cargo archives are preserved without treating all archived bytes as read.
Old and current FBX support is separately recorded even where the individual
files match. `git-proofs.json` contains raw compressed Git objects and membership
chains for transport and project files. Cargo lock parsing proves only package
selection/checksum, not features or execution.

`historical-059/` contains original bytes authenticated against the published
original transport manifest. The registry and queue selections are labeled
reconstructions. Original 774 registration and contract files and the original
P16 dirty lock are hash-linked to their prior local packets, with their prior raw
Git proofs. `published-prior-packet-links.json` points to the earlier published
bundles and compares their relevant members. One published contract-groups member
is a path-redacted reconstruction, not an exact full original: the specified
rows 649 and 652 match byte-for-byte, while full-file hashes differ. The original
exact locally retained bytes and f82 transport remain separately identified.
The dirty P16 base and later patch recovery do not establish checkpoint 3821.

Run `python3 verify-evidence.py` for an evidence-only check, followed by
`python3 verify-manifest.py`. The evidence check requires the hash-linked prior
packets and published baseline at the recorded absolute paths; retain or rebase
those dependencies for archival recovery. The evidence check parses source and
metadata and verifies cryptographic membership. It never compiles or executes
product code, macros, tests or fixtures.
