from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile,io,tomllib
b=Path(__file__).resolve().parent
pub=Path('<LOCAL_PATH_0>')
g=lambda *a: subprocess.check_output(['git','-C',str(pub),*a])
sha=lambda x: hashlib.sha256(x).hexdigest()
r=json.load(gzip.open(pub/'recovered/original-registry-source-archive/registry.json.gz','rt'))
old='6533e444fa37552927070cc8d8190907fd3b413e';current='95e63628f9d70b8dd6e6fede64334696c6995009';transport='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';pre='handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'
(b/'sources').mkdir(exist_ok=True);(b/'metadata').mkdir(exist_ok=True)
crate=Path('<LOCAL_PATH_1>').read_bytes();(b/'metadata/num_enum_derive-0.7.6.crate').write_bytes(crate)
rows=[]
with tarfile.open(fileobj=io.BytesIO(crate),mode='r:gz') as t:
 for i in [2626,2627,2628]:
  row=r['files'][i]; raw=g('show',transport+':'+pre+row['sha256']); path=row['source_id'].split('0.7.6/',1)[1]; member='num_enum_derive-0.7.6/'+path
  assert raw==t.extractfile(member).read() and sha(raw)==row['sha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['actual_line_count']
  chunks=[]
  for lo,hi in row['material_ranges']:
   assert 1<=lo<=hi<=row['actual_line_count']
   for a in range(lo,hi+1,60):chunks.append([a,min(a+59,hi)])
  name=f'sources/{i}-{Path(path).name}';(b/name).write_bytes(raw)
  rows.append({'role':i,'source_id':row['source_id'],'native_identity':'crates.io num_enum_derive 0.7.6; not project Git','archive_member':member,'transport_revision':transport,'transport_path':pre+row['sha256'],'preserved_source':name,'sha256':sha(raw),'bytes':len(raw),'eof':len(raw.splitlines()),'registered_ranges':row['material_ranges'],'planned_personal_display_chunks':chunks,'old_material_ranges':row['material_ranges']})
locks=[]
for label,rev in [('pr-working-base',old),('current',current)]:
 raw=g('show',rev+':Cargo.lock'); allpkgs=tomllib.loads(raw.decode())['package']; selected=[x for x in allpkgs if x['name'] in ('num_enum','num_enum_derive')]; name='metadata/'+label+'-Cargo.lock.gz';(b/name).write_bytes(gzip.compress(raw,mtime=0));
 for pkg in selected:
  if pkg['name']=='num_enum_derive' and pkg['version']=='0.7.6':assert pkg['checksum']==sha(crate)
 locks.append({'label':label,'revision':rev,'path':'Cargo.lock','git_blob':g('rev-parse',rev+':Cargo.lock').decode().strip(),'sha256':sha(raw),'preserved_gzip':name,'records':selected})
p16=Path('<LOCAL_PATH_2>');z=p16.read_bytes();raw=gzip.decompress(z); entries=[x for x in tomllib.loads(raw.decode())['package'] if x['name'] in ('num_enum','num_enum_derive')]
for pkg in entries:
 if pkg['name']=='num_enum_derive' and pkg['version']=='0.7.6':assert pkg['checksum']==sha(crate)
result={'schema':'726-num-enum-derive-prospective-registration-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','roles':rows,'package_archive':{'preserved':'metadata/num_enum_derive-0.7.6.crate','sha256':sha(crate),'bytes':len(crate),'qualification':'Cargo archive file matches each original registered native source member and matching lock checksum where selected; not a project Git revision.'},'lock_metadata':locks,'p16_dirty_lock_reference':{'path':str(p16),'compressed_sha256':sha(z),'uncompressed_sha256':sha(raw),'records':entries,'qualification':'Prior separately retained dirty P16 lock based on a120; later recovered patch does not promote this to checkpoint3821.'},'limits':'Prospective personal reads only at listed chunks; archive includes unread complements. Source inspection only; no macro execution, build, tests, or feature resolution inferred. Recorded pr-working snapshot had unrelated modifications.'}
(b/'registration.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'registration_sha256':sha((b/'registration.json').read_bytes()),'package_sha256':sha(crate),'roles':[(x['role'],x['registered_ranges'],x['planned_personal_display_chunks']) for x in rows],'lock_records':[(x['label'],x['records']) for x in locks], 'p16_records':entries},indent=2))
