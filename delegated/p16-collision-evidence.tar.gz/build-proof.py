import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());names=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json'];support=[x for n in names for x in json.loads((p/n).read_text())['sources']];arch=[]
for x in reg['sources']:
 if x['kind']=='physical-p16':
  arch.append({'kind':'archive-transport-only','revision':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],'archive':x['archive'],'sha256':x['sha256'],'git_blob_sha1':x['git_blob_sha1'],'qualification':'This proves archived object membership in f82 transport; f82 is not physical-P16 clean HEAD.'})
records=reg['sources']+support+arch;d=p/'git-objects';d.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=d/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();assert tree==x['git_blob_sha1'];assert hashlib.sha256(b).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'kind':x['kind'],'revision':rev,'path':x['path'],'archive':x['archive'],'commit_tree':root,'chain':chain,'blob':tree})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw Git commit/tree objects and archived exact bytes prove path membership only: f82 is transport, a120 recorded base, current 95e authoritative; equality holds individually and never identifies the whole dirty P16 snapshot with clean a120.','objects':objects,'proofs':proof},indent=2)+'\n')
rows=[]
for x in reg['sources']:
 rows.append({'role':x['original_role'],'kind':x['kind'],'revision':x['revision'],'path':x['path'],'archive':x['archive'],'actual_display_ranges':x['planned_display_chunks'],'actual_display_union':[[1,x['lines']]],'unread_ranges':[],'full_body_displayed':True,'planned_deviation':'none'})
(p/'read-receipt.json').write_text(json.dumps({'schema':'726-assigned-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest(),'reads':rows,'qualification':'Full listed assigned historical/current body displays are new source assessment, never claim historical reviewer credit or checkpoint3821.'},indent=2)+'\n')
ranges={0:[[1,53]],1:[[1,25],[335,447]],2:[[275,335]],3:[[1,98]],4:[[1,98]],5:[[1,142]],6:[[1,126]],7:[[1,393]],8:[[1,80]],9:[[355,390]],10:[[1,60]],11:[[1,29]],12:[[1,55]],13:[[1,60]],14:[[1,33]],15:[[1,85],[138,149],[175,184]],16:[[1,110],[230,242]],17:[[1,54]],18:[[1,110],[175,205]],19:[[1,147]]}
# The prior scoped rg invocations displayed matching text lines as navigation.
# Include each actually printed line, even when outside a subsequently read window.
import re
patterns=[(range(0,9),r'struct BuildingPlan|struct ResolvedGeometry|struct ResolvedSolid|struct ResolvedItemId|struct WallAssembly|host_solids|pub.*solids|pub.*resolved_geometry|impl.*Deserialize|struct SpatialBounds|struct RigidRotation|struct CuboidDimensions|from_metres\(|fn corners|fn ground_contact|fn union|fn from_quaternion'),(range(9,15),r'struct ResolvedGeometry|pub.*solids|host_solids|collision\.bounds|collision\.cuboids|collision:|compile_building_collision|validate|resolve|bounds\.'),(range(15,18),r'ArchitecturalPlanProjection|from_placement|collision\.bounds|local_origin|bounds\.'),(range(18,20),r'struct .*Bar|fn compile_window_bars|size_metres|centre:|yaw_radians:')]
nav={}
for indexes,pattern in patterns:
 for i in indexes:
  lines=(p/f'source/support-{i:02}.source').read_text().splitlines();matches=[n for n,line in enumerate(lines,1) if re.search(pattern,line)];nav[str(i)]=matches
  spans=ranges[i]+[[n,n] for n in matches];spans.sort();merged=[]
  for a,b in spans:
   if merged and a<=merged[-1][1]+1:merged[-1][1]=max(b,merged[-1][1])
   else:merged.append([a,b])
  ranges[i]=merged
(p/'navigation-exposures.json').write_text(json.dumps({'qualification':'Actual incidental printed search-result lines, displayed after registration; included in support receipt but not treated as complete function reads.','lines_by_support_index':nav},indent=2)+'\n')

def complement(rr,n):
 out=[];k=1
 for a,b in rr:
  if k<a:out.append([k,a-1])
  k=b+1
 if k<=n:out.append([k,n])
 return out
reads=[]
for i,x in enumerate(support):
 rr=ranges[i];assert all(1<=a<=b<=x['lines'] for a,b in rr);reads.append({'path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':complement(rr,x['lines']),'full_body_displayed':sum(b-a+1 for a,b in rr)==x['lines'],'planned_deviation':'Selected windows only; unopened lines remain unread, including test sources where applicable.'})
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'path':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in names],'reads':reads,'qualification':'Prospective permission for wider support body does not imply display; exact printed windows and unread complement above. Occasional search-result navigation lines are covered by windows; no ordered-role credit. Test text shown only, never run.'},indent=2)+'\n');print('git proofs',len(proof),'objects',len(objects),'assigned',len(rows),'support',len(reads))
