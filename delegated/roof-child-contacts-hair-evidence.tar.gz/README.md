# Bounded roof-child and contact evidence

This is /root/hair_ops's source-only review of original roles 2536 and 2537
against current revision `95e63628f9d70b8dd6e6fede64334696c6995009`. The
complete 6533 bodies (78 and 106 lines) and 95e counterparts were separately
personally displayed after registration. The 059 source inventory and recovered
objects match f82 transport and both Git versions per file. The recorded
pr-working snapshot is 6533 HEAD plus four other modified paths; it is not
claimed to be a clean snapshot. The f82 copies were verified but not separately
personally displayed.

`report.json` contains thirteen bounded perspectives, source citations,
conditional findings, nonfindings, open questions and historical relationships.
The wall-host predicate admits the wall centreline under its geometric bounds,
which is narrower than its adjacent exterior-face comment suggests. A separate
contact decision uses yaw-only AABBs even for crossfall weathering. The packet
does not establish a supported station, retained incorrect bond, later audit
result or product effect for either observation. The child ID source trace
narrows historical 059 q2257 without closing it; parent-surface fallback and
retained raw roof points keep their earlier native and reviewer attribution.

`read-receipt.json` and `support-read-receipt.json` distinguish actual reads
from archived bytes and prior support-only reads. `git-proofs.json` and
`git-objects/` contain independent commit/tree/blob evidence. Exact selected
059/774 records are retained; the exact 059 source inventory is stored in gzip
with original uncompressed hash, and the selected queue row is expressly a
reconstructed excerpt linked to its complete original. Earlier full roof
packets are hash-linked and only their compact reports copied, with their
original reviewer identities.

`verify_evidence.py` checks evidence integrity, source-read windows and
available prior hash links only. Re-running it changes the timestamped output;
use a copy to preserve the frozen manifest. No geometry or product execution,
builds, tests, runtime probes, simulations, repairs or publication/source edits
occurred. Central coordination owns aliases, ledger and checkpoint publication.
