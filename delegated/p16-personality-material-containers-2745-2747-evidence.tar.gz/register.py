from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
b=Path(__file__).resolve().parent;repo=Path('<LOCAL_PATH_0>');base=repo/'recovered/original-registry-source-archive'
h=lambda x:hashlib.sha256(x).hexdigest();r=json.load(gzip.open(base/'registry.json.gz','rt'));rows=[];pending=[]
def complement(n,ranges):
 used={i for a,z in ranges for i in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):out.append([start,i-1]);start=None
 return out
with tarfile.open(base/'objects.tar.gz','r:gz') as t:
 for index in range(2745,2748):
  x=r['files'][index];p=x['source_id'].split(':',1)[1];old=t.extractfile(x['sha256']).read();assert h(old)==x['sha256'] and len(old)==x['bytes'] and len(old.splitlines())==x['actual_line_count']
  local=f'source/{index}-physical-p16.rs';pending.append((local,old))
  versions=[{'identity':'original physical-p16 archived object','revision_qualification':'dirty a120-based P16; f82 transports evidence, not project head','sha256':h(old),'bytes':len(old),'eof':len(old.splitlines()),'local':local,'original_assigned_planned':x['material_ranges'],'unplanned_complement':complement(len(old.splitlines()),x['material_ranges'])}]
  comparisons=[]
  for rev in ['a120390947c89b703dc74c4255a13c035d054c50','6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009']:
   obj=subprocess.run(['git','-C',str(repo),'show',rev+':'+p],capture_output=True)
   if obj.returncode:
    d={'revision':rev,'path_absent':True,'stderr':obj.stderr.decode(errors='replace'),'display_planned':False}
    if rev.startswith('95e6'):versions.append(d)
    else:comparisons.append(d)
    continue
   raw=obj.stdout;blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+p],text=True).strip();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
   n=f'source/{index}-{rev[:4]}.rs';pending.append((n,raw))
   d={'revision':rev,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'local':n,'equals_archived_file':raw==old}
   if rev.startswith('95e6'):
    d['current_body_planned']=x['material_ranges'] if raw==old else [[1,len(raw.splitlines())]]
    versions.append(d)
   else:d['display_planned']=False;comparisons.append(d)
  rows.append({'original_index':index,'source_id':x['source_id'],'path':p,'original_material_ranges':x['material_ranges'],'versions':versions,'comparison_git_paths':comparisons})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','scope':'Prospectively register old P16 exact original union material and independent 95e material if identical; where changed, register current full body but disclose actual display/unread partitions. No excluded historical context has role credit. a120/6533 copies identity-only. Related supports registered before display.','original_registry_uncompressed_sha256':h(gzip.decompress((base/'registry.json.gz').read_bytes())),'snapshot_qualification':'physical-p16 dirty a120-based; later recovered tracked patch matches recorded hash with seven untracked objects separately archived. f82 transports evidence, not project head. Per-file equality does not equate snapshots or personal reads.','rows':rows,'limits':'Static source/evidence only; no product, macro, fixture or test execution, builds, probes, repairs or publication edits.'}
(b/'registration.json').write_text(json.dumps(d,indent=2)+'\n')
for n,raw in pending:
 q=b/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
print(json.dumps(d,indent=2));print('REGISTRATION_SHA256',h((b/'registration.json').read_bytes()))
