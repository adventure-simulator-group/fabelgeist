from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo=Path('<LOCAL_PATH_0>')
workspace=Path('<LOCAL_PATH_1>');orig=Path('<LOCAL_PATH_2>')
prev=Path('<LOCAL_PATH_3>');h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def copy(src,dest,kind):
 raw=Path(src).read_bytes();out=b/dest;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw);records.append({'origin':str(src),'local':dest,'sha256':h(raw),'bytes':len(raw),'kind':kind})
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/'recovered'/n,'recovered/'+n,'Exact retained original registry/archive or 059 records; reconstructed catalog or later tracked patch labelled.')
for n in ['RECOVERY-PHYSICAL-P16-PATCH-20261111.json','SEARCH-P16-PATCH-20261111.json','ASSESSMENT-L01-HISTORICAL-931-936.json','ASSESSMENT-L01-HISTORICAL-954-960.json']:
 copy(repo/n,'prior/'+n,'Published current-session historical scope summary or patch recovery evidence; not original prior reviewer reread.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/adventuresim-core/AGENTS.md']:copy(workspace/n,'rules/'+n,'Current applicable repository rules; user excludes implementation, build and test execution.')
names=['segovb/READ-L11-448.json','segovb/READ-L11-449.json','segovb/READ-L11-450.json','parallel-l13-20261029/READ-PL13-256.json','parallel-l13-20261029/REGISTRATION-PL13-256.json','segovb/READ-L13-PARALLEL-254.json','parallel-l13-20261029/VALIDATION-PROPOSAL-PL13-255-262.json','parallel-l13-20261029/READ-PL13-179.json','parallel-l13-20261029/REGISTRATION-PL13-179.json','segovb/READ-L13-PARALLEL-177.json']
for i in range(1664,1667):names.append(f'segovb/REGISTRATION-SEGOVB-{i}.json')
for i,j in [(811,2745),(812,2746),(813,2747)]:
 names += [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json',f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{i}-ORIGINAL{j}.json']
for n in names:copy(orig/n,'historical/059/'+n,'Exact original 059 historical read, registration, qualification or delegation/adoption; do not infer read from registration.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';prefix='handoff/774/adler-original/audit/continuation/camera/admission03/'
paths=[
 ('camera-range-registration.jsonl',prefix+'source-range-registration.jsonl'),
 ('camera-final-qualifications.jsonl',prefix+'source-qualifications-final-current.jsonl'),
 ('camera-additional-sources.jsonl',prefix+'additional-sources.jsonl'),
 ('camera-contracts.jsonl',prefix+'contracts.jsonl'),
 ('camera-findings.jsonl',prefix+'findings.jsonl'),
 ('camera-qualifications.jsonl',prefix+'qualifications.jsonl')
]
for n,p in paths:
 raw=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+p]);out=b/'historical/774'/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 records.append({'origin':'git:'+rev+':'+p,'local':str(out.relative_to(b)),'sha256':h(raw),'bytes':len(raw),'kind':'Exact original 774 historical record via f82 evidence transport, not P16 source head.','transport_revision':rev,'git_path':p})
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw)
qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw)['entries']
d={'kind':'Newly reconstructed selections from exact recovered original registry and 059 queue; not historical standalone records.','registry_uncompressed_sha256':h(rraw),'queue_uncompressed_sha256':h(qraw),'registry_rows':{str(i):r['files'][i] for i in [932,954,2745,2746,2747]},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ['pr-working','physical-p16']],'queue_rows':{str(i):q[i] for i in [1877,2298,2318,2321,2334,2335]}}
(b/'historical-selections-reconstructed.json').write_text(json.dumps(d,indent=2)+'\n')
d={'kind':'Exact historical records and separately labelled earlier assessments and reconstructed catalogue','registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'Dirty P16 is a120-based, tracked diff independently reproduced later with untracked files separate; pr-working is distinct 6533-based dirty snapshot. No checkpoint3821 promotion or reader/scope transfer.'}
(b/'historical-manifest.json').write_text(json.dumps(d,indent=2)+'\n')
print('historical_records',len(records),'manifest_sha256',h((b/'historical-manifest.json').read_bytes()))
