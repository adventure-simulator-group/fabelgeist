# Bounded P16 personality, material, and containment evidence

This packet assesses physical-p16 original roles 2745–2747 and pinned project
revision 95e63628f9d70b8dd6e6fede64334696c6995009. REPORT.json gives the
source findings, exact conditions, thirteen bounded perspectives, historical
reviewers, and open questions. Historical and new source reads are separate.

P16 is the unfinished dirty a120-based state. A later reproduced tracked patch
matches the recorded hash; seven untracked sources are separately archived.
Per-file equality with a120, 6533, 039, or 95e does not equate snapshots or
transfer read credit. f82 transports evidence and 039 is the catalogued
per-file byte origin; neither is asserted to be the dirty P16 project head.

Role 2746's original union is 1–73, 204–387, 452–614, 707–1197 and
1253–1382. Both versions were personally displayed in those ranges; the old
excluded gaps remain unread. Selected current gaps were later registered as
support. Role 2747 is 1–175, with 176–256 unread in the assigned pass.
Regex navigation outputs and their exact displayed lines are listed in
read-receipt.json; other uninspected lines remain explicit.

The old camera supplier's full comparison ranges are distinguished from its
specifically named fresh critical reads. The existing Lens13 measured-zero
and material-quantization questions retain original authorship and are not
recounted as new issues. arithmetic-evidence.json is a new integer-only
analysis; no physical input or product behavior was executed or observed.

Run `python3 verify-evidence.py` from any directory to check offline evidence
integrity, original source objects, read partitions, 059/774 attributions,
tracked-patch qualification, integer reasoning, and raw Git membership.
It does not execute product code or fixtures. MANIFEST.json includes every
packet file except the top-level manifest itself, including nested manifests.
