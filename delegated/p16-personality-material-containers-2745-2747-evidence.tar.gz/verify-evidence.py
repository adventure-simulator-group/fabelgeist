'''Offline evidence-integrity checks only; no product, build, fixture or test execution.'''
from pathlib import Path
from datetime import datetime
import gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files']
assert all(original[i]==sel['registry_rows'][str(i)] for i in [932,954,2745,2746,2747])
assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id'] in ['physical-p16','pr-working']]
snapshot=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes()
assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['recovered_patch']['bytes']==len(patch) and recovery['live_comparison']['status_counts']['??']==7
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows'];expected={2745:[[1,204]],2746:[[1,73],[204,387],[452,614],[707,1197],[1253,1382]],2747:[[1,175]]}
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];body=(b/old['local']).read_bytes()
  assert t.extractfile(old['sha256']).read()==body and h(body)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256']
  assert original[i]['material_ranges']==expected[i]==row['original_material_ranges']
  assert catalog[i]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path']
  assert (b/cur['local']).read_bytes()==body
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==body and c['display_planned']==False
for x in rec['registrations']:
 assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(ranges):return [i for a,z in ranges for i in range(a,z+1)]
def partition(n,ranges):
 v=nums(ranges);return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes()
  assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof']
  assert partition(v['eof'],p['actual_display_chunks']+p['unread_in_this_assigned_pass'])
  assert nums(p['actual_display_chunks'])==nums(expected[row['original_index']])
  assert p['original_material_ranges']==(expected[row['original_index']] if j==0 else [])
planned={}
for n in ['support-registration.json','more-support-registration.json','item-support-registration.json']:
 for x in load(n)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'] and x['ordered_role_credit']==0
 assert partition(x['eof'],x['full_line_body_displays']+x['navigation_only_line_displays']+x['previous_assigned_displays_in_this_packet']+x['unread_complement_after_all_personal_displays'])
 displayed=x['full_line_body_displays']+x['navigation_only_line_displays'];assert set(nums(displayed))<=set(nums(e['planned_display_ranges']))
 nav=x['navigation_output']
 if nav:
  names=nav if isinstance(nav,list) else [nav];all_lines=set()
  for n in names:
   for line in (b/n).read_text().splitlines():
    a,text=line.split(':',1);no=int(a);assert raw.decode().splitlines()[no-1]==text;all_lines.add(no)
  body=set(nums(x['full_line_body_displays']))
  assert set(nums(x['navigation_only_line_displays']))==all_lines-body
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
assert len(proof['proofs'])==31
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
camera=readjsonl('historical/774/camera-range-registration.jsonl');quals=readjsonl('historical/774/camera-final-qualifications.jsonl')
for i in [2745,2746,2747]:
 for ob in original[i]['admission03_scope_observations']:
  assert camera[ob['row_1based']-1]==ob['original_record']
  q=next(x for x in quals if x['registration_id']==ob['registration_id']);assert q==ob['local_qualifications'][0]
additional=readjsonl('historical/774/camera-additional-sources.jsonl');contracts=readjsonl('historical/774/camera-contracts.jsonl');q164=readjsonl('historical/774/camera-qualifications.jsonl');findings=readjsonl('historical/774/camera-findings.jsonl')
x=next(x for x in additional if x.get('id')=='CAMERA-ADM03-ADDITIONAL047');assert 'freshcriticalconstructorbodies' in x['read_status'] and x['read_ranges']!=expected[2746]
x=next(x for x in contracts if x.get('id')=='CAMERA-ADM03-150');assert '21-73/235-252/269-289/465-485/551-585/953-1032' in x['actual_source_proof']
x=next(x for x in q164 if x.get('id')=='CAMERA-ADM03-QUAL164');assert 'Fresh P16 private graph20-47/77-145' in x['actual_proof']
assert any(x.get('id')=='CAMERA-ADM03-F027' for x in findings) and any(x.get('id')=='CAMERA-ADM03-F028' for x in findings)
for i,n,rn in [(2745,448,1664),(2746,449,1665),(2747,450,1666)]:
 p=load(f'historical/059/segovb/READ-L11-{n}.json');x=next(x for x in p['sources'] if x['original_index']==i)
 assert x['fresh_personal_body_reads']==expected[i] and h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{rn}.json').read_bytes())==x['registration_sha256']
for i,n in [(2745,811),(2746,812),(2747,813)]:
 p=load(f'historical/059/parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json');assert p['original_index']==i and p['original_record']==original[i]
for n,adopt,original_index,ranges in [(179,177,954,[[1,1869]]),(256,254,1119,[[1,1451]])]:
 p=load(f'historical/059/parallel-l13-20261029/READ-PL13-{n}.json');a=load(f'historical/059/segovb/READ-L13-PARALLEL-{adopt}.json')
 row=next(x for x in p['rows'] if x['original']==original_index)
 assert row['fresh_personal_assessed_ranges']==ranges and a['root_personal_rereads']==[]
 assert h((b/f'historical/059/parallel-l13-20261029/READ-PL13-{n}.json').read_bytes())==a['delegated_receipt']['sha256']
 assert h((b/f'historical/059/parallel-l13-20261029/REGISTRATION-PL13-{n}.json').read_bytes())==p['registration']['sha256']
math=load('arithmetic-evidence.json');upper=1<<64;k=4722366482869645
assert upper*256-k*1000000==213696 and 213696<1024*256 and int(math['difference_milligrams'])==834
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: P16 roles2745–2747 original material and 95e independently displayed, exact exclusions/navigation recorded; 774 comparison versus fresh scopes and 059 readers retained; P16 patch qualification, bounded integer reasoning and %d raw Git proofs verified. Thirteen partial perspectives; no product/build/test/probe.'%len(proof['proofs']))
