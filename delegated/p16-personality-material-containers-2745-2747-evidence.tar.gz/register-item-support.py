from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest()
spec=['crates/adventuresim-core/src/item_catalog_schema.rs','crates/adventuresim-core/src/item_catalog.rs','crates/adventuresim-stdb-module/src/item.rs']
entries=[]
for i,path in enumerate(spec):
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc=f'support/item-{i}.source';(b/loc).write_bytes(raw)
 entries.append({'revision':rev,'path':path,'local':loc,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,len(raw.splitlines())]],'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','purpose':'Prospective navigation of authored item alcohol/exterior default and native projection into graph. Exact later line displays and unread complements recorded; registration alone grants no body read credit.','entries':entries}
(b/'item-support-registration.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2));print('SHA256',h((b/'item-support-registration.json').read_bytes()))
