'''Integer-only mathematical evidence; no product type, runtime, build, test or fixture is executed.'''
from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent
upper=1<<64
k=(upper*256)//1_000_000
numerator=upper*256-k*1_000_000
assert k==4722366482869645 and numerator==213696
# k/256 kg is binary64-representable; exact scaled milligrams upper - 834.75.
# The predecessor of 2**64 is 2**64-2048; 834.75 < 1024, so binary64 multiplication rounds to 2**64.
assert numerator<1024*256
nearest_integer=upper-835
cast_max=upper-1
d={'kind':'New integer-arithmetic explanation, not product execution or a historical record','source_revision':'95e63628f9d70b8dd6e6fede64334696c6995009','source':'crates/adventuresim-core/src/material.rs:20–35; P16 file bytes identical','input_kilograms_exact':'4722366482869645 / 256','input_binary64_representable':'k has 53 or fewer binary significand bits and exponent permits k/256 exactly','exact_scaled_milligrams':'2^64 - 213696/256 = 2^64 - 834.75','distance_to_2_pow_64_milligrams':'834.75','distance_to_binary64_predecessor_milligrams':'1213.25 (predecessor is 2^64 - 2048)','binary64_scaled_rounding':'2^64, under ordinary IEEE-754 round-to-nearest','u64_max_as_f64':'2^64','source_comparison':'greater-than comparison is false for equality, then round preserves 2^64 and Rust float-to-u64 cast saturates at u64::MAX','nearest_integer_to_exact_scaled_milligrams':str(nearest_integer),'cast_value':str(cast_max),'difference_milligrams':cast_max-nearest_integer,'qualification':'This is source/math reasoning for an extreme input; no supported producer, physical plausibility, intended quantization policy, actual sample or product outcome established. Existing 059 READ-L11-449 and Lens13 PL13-179 already raise the boundary; do not assign a duplicate.'}
(b/'arithmetic-evidence.json').write_text(json.dumps(d,indent=2)+'\n');print('SHA256',hashlib.sha256((b/'arithmetic-evidence.json').read_bytes()).hexdigest())
