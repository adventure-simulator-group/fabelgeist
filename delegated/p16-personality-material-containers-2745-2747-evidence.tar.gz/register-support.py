from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo=Path('<LOCAL_PATH_0>')
rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest()
spec=[
 ('crates/adventuresim-stdb-module/src/inventory_container.rs','navigation and bounded producer context for core containment and measured amount'),
 ('crates/adventuresim-stdb-module/src/inventory_amount.rs','navigation and bounded amount/whole-ml projection context'),
 ('crates/adventuresim-stdb-module/src/personality.rs','navigation and bounded caller context for stable/random personality factories'),
 ('crates/fabelgeist-determinism/src/stream.rs','bounded deterministic shuffle/index contract')
]
entries=[]
for i,(path,purpose) in enumerate(spec):
 raw=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',str(repo),'rev-parse',rev+':'+path],text=True).strip();loc=f'support/{i}.source';q=b/loc;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 ranges=[[1,len(raw.splitlines())]] if i<3 else [[34,67],[96,100]]
 entries.append({'kind':'current first-party source support','revision':rev,'path':path,'local':loc,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':ranges,'reason':purpose,'ordered_role_credit':0})
x=json.loads((b/'registration.json').read_bytes())['rows'][1]['versions'][1]
entries.append({'kind':'current same-file excluded-context support','revision':rev,'path':'crates/adventuresim-core/src/material.rs','local':x['local'],'sha256':x['sha256'],'git_blob':x['git_blob'],'bytes':x['bytes'],'eof':x['eof'],'planned_display_ranges':[[74,203],[1198,1252]],'reason':'Milliliters representation and separately excluded retry digest route; no old historical role expansion.','ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','description':'Prospective full navigation registrations for three connected current support files; display only selected needed lines and record navigation and unread complements. Same-file current support contexts separately registered.','entries':entries}
(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2));print('SHA256',h((b/'support-registration.json').read_bytes()))
