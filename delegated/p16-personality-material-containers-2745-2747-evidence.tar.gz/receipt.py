from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');s=load('support-registration.json');more=load('more-support-registration.json')
chunks={
 2745:[[1,110],[111,204]],
 2746:[[1,73],[204,300],[301,387],[452,535],[536,614],[707,806],[807,906],[907,1006],[1007,1105],[1106,1197],[1253,1320],[1321,1382]],
 2747:[[1,90],[91,175]]
}
def complement(n,ranges):
 used={k for a,z in ranges for k in range(a,z+1)};out=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):out.append([start,i-1]);start=None
 return out
assigned=[]
for row in reg['rows']:
 i=row['original_index'];old,cur=row['versions']
 for j,v in enumerate([old,cur]):
  assigned.append({'original_index':i,'source_id':row['source_id'],'identity':old['identity'] if j==0 else 'pinned 95e source','revision':None if j==0 else cur['revision'],'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'actual_display_chunks':chunks[i],'original_material_ranges':row['original_material_ranges'] if j==0 else [],'unread_in_this_assigned_pass':complement(v['eof'],chunks[i]),'qualification':'No old excluded context or previous reviewer/lens credit transferred; separately registered current material support may read selected excluded current lines.'})
navfiles={
 'support/0.source':'navigation-inventory-container.txt',
 'support/1.source':'navigation-inventory-amount.txt',
 'support/2.source':['navigation-personality.txt','navigation-personality-neutral.txt'],
 'support/more-0.source':'navigation-measurement.txt',
 'support/more-1.source':'navigation-catalog.txt',
 'support/item-0.source':['navigation-item-schema.txt','navigation-capabilities.txt'],
 'support/item-1.source':['navigation-item-catalog.txt','navigation-catalog-loader.txt'],
 'support/item-2.source':['navigation-item-native.txt','navigation-item-projection.txt']
}
body={
 'support/0.source':[[920,1020]],
 'support/1.source':[[1,110],[111,205]],
 'support/2.source':[[105,135],[245,310],[600,678]],
 'support/3.source':[[34,67],[96,100]],
 'source/2746-95e6.rs':[[74,203],[1198,1252]],
 'support/more-0.source':[[1,120]],
 'support/more-1.source':[[325,365]],
 'support/item-0.source':[[1,100],[480,515]],
 'support/item-1.source':[[1,43],[44,90],[91,125]],
 'support/item-2.source':[[60,165],[166,239],[240,280],[285,318],[330,355]]
}
supports=[]
item=load('item-support-registration.json')
for x in s['entries']+more['entries']+item['entries']:
 loc=x['local'];nav=navfiles.get(loc);numbers=[]
 if nav:
  names=nav if isinstance(nav,list) else [nav]
  numbers=sorted({int(line.split(':',1)[0]) for n in names for line in (b/n).read_text().splitlines() if re.match(r'^\d+:',line)})
 displayed=body[loc];displayed_nums={i for a,z in displayed for i in range(a,z+1)}
 nav_only=[[i,i] for i in numbers if i not in displayed_nums]
 elsewhere=chunks[2746] if loc=='source/2746-95e6.rs' else []
 all_scopes=displayed+nav_only+elsewhere
 supports.append({'kind':x.get('kind','current first-party source support'),'revision':x['revision'],'path':x['path'],'local':loc,'sha256':x['sha256'],'eof':x['eof'],'full_line_body_displays':displayed,'navigation_output':nav,'navigation_only_line_displays':nav_only,'previous_assigned_displays_in_this_packet':elsewhere,'unread_complement_after_all_personal_displays':complement(x['eof'],all_scopes),'registration':'support-registration.json' if x in s['entries'] else ('more-support-registration.json' if x in more['entries'] else 'item-support-registration.json'),'ordered_role_credit':0,'qualification':'Navigation lines are exact regex output, including any source-test text; no source or tests executed. Current material assigned lines remain separately credited to assigned pass.'})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','method':'Newly reconstructed actual line-numbered source display and regex-navigation receipt, after prospective timestamped registrations. Archived bytes alone do not prove a read.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in ['registration.json','support-registration.json','more-support-registration.json','item-support-registration.json']],'assigned':assigned,'support':supports,'limits':'No product, macro, fixture, tests, builds, runtime probes, repairs or publication edits.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('SHA256',h((b/'read-receipt.json').read_bytes()),d['created_utc'])
