from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda x:hashlib.sha256(x).hexdigest()
spec=['crates/adventuresim-core/src/inventory_measurement.rs','content/items/catalog.yaml']
entries=[]
for i,path in enumerate(spec):
 raw=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);blob=subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip();loc=f'support/more-{i}.source';(b/loc).write_bytes(raw)
 entries.append({'revision':rev,'path':path,'local':loc,'sha256':h(raw),'git_blob':blob,'bytes':len(raw),'eof':len(raw.splitlines()),'planned_display_ranges':[[1,len(raw.splitlines())]],'ordered_role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','purpose':'Prospective navigation and bounded display of fixed-point amount owner and authored apple volume for existing 059 q2334; full bodies registered as a source search scope, but actual reads and complements will be reported. No product/test/fixture execution.','entries':entries}
(b/'more-support-registration.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2));print('SHA256',h((b/'more-support-registration.json').read_bytes()))
