# P16 daily allocation and activity evidence

This source-only packet covers original physical-P16 roles 2675 and 2676 and
their current counterparts at `95e63628f9d70b8dd6e6fede64334696c6995009`.
The P16 snapshot is dirty and based on
`a120390947c89b703dc74c4255a13c035d054c50`. Both assigned files individually
match the base and current objects; this does not make the overall P16
snapshot clean. F82 is historical evidence transport, not a project revision.

`registration.json` preceded the four separate source displays in
`personal-read-receipt.json`: full allocation lines 1–364 at each revision and
activity line 28 only. Other activity lines are preserved but unread for this
review. Original test text in allocation was read, never run. The five support
registrations and receipts list exact current caller, state and operation
windows plus unread complements. `navigation-receipt.json` qualifies the
bounded exact-spelling source search. `report.json` records existing and
conditional source findings, related but distinct repair contracts, thirteen
bounded perspectives, open questions and reviewer attribution.

`history-059/` preserves exact registrations, partials, proposals and receipts;
`history-774/` holds losslessly compressed original native, camera and root
records, each bound to f82 transport. The original modified P16 simulation
writer is preserved under `historical-support/` without a personal historical
body read. `reference/` stores the complete original registry and transport
manifest, recovered 059 queue, the later P16 recovery record and tracked patch,
and a prior current aggregate assessment. Reconstructed selections are labeled.
The `git-proofs.json` and archived commit/tree objects prove exact source and
transport membership without transferring prior reviewers' source credit.

Run `python3 verify-evidence.py` for self-contained evidence integrity and
read-scope accounting, and `python3 verify-manifest.py` for packet member
hashes. Neither check executes product, builds, tests, fixture generation,
simulation, runtime probes, or validation. No repair, source or publication
edit, checkpoint 3821 promotion, or whole-lens completion is claimed.
