#!/usr/bin/env python3
"""Self-contained evidence integrity/recorded read scopes; never executes product."""
import gzip,hashlib,json,pathlib
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();load=lambda n:json.loads((p/n).read_bytes());checks=[]
r=load('registration.json');receipt=load('personal-read-receipt.json');assert receipt['registration_sha256']==sha((p/'registration.json').read_bytes()) and r['registered_utc']<receipt['recorded_utc'] and len(receipt['reads'])==len(r['entries'])==4
for x in receipt['reads']:
 e=next(y for y in r['entries'] if y['original_index']==x['original_index'] and y['snapshot']==x['snapshot']);b=(p/x['archive']).read_bytes();assert (sha(b),blob(b),len(b),len(b.splitlines()))==(e['sha256'],e['git_blob'],e['bytes'],e['actual_EOF']) and x['actual_display_chunks']==e['planned_chunks'] and x['actual_display_ranges']==e['registered_ranges']
 cov={i for a,z in x['actual_display_chunks'] for i in range(a,z+1)};unread={i for a,z in x['unread_complement'] for i in range(a,z+1)};assert not cov&unread and cov|unread==set(range(1,e['actual_EOF']+1));assert x['actual_display_ranges']==([[1,364]] if x['original_index']==2675 else [[28,28]])
for i in [2675,2676]:
 es=[e for e in r['entries'] if e['original_index']==i];assert len(es)==2 and es[0]['sha256']==es[1]['sha256']
checks.append('Assigned full allocation and single-line activity separately registered/displayed at each revision; exact unread complements')
receipts=[]
for key,count in [('support',5),('extra',3),('writer',1),('total',1),('sum',1)]:
 sr=load(key+'-registration.json');rc=load(key+'-read-receipt.json');assert rc['registration_sha256']==sha((p/(key+'-registration.json')).read_bytes()) and sr['at']<rc['at'] and len(rc['reads'])==count;receipts.extend(rc['reads'])
 for x in rc['reads']:
  e=next(e for e in sr['rows'] if e['file']==x['source_file']);b=(p/e['file']).read_bytes();assert (sha(b),blob(b),len(b.splitlines()))==(e['sha256'],e['blob'],e['eof']) and e['prospective_ranges']==x['actual_ranges'];a={i for f,t in x['actual_ranges'] for i in range(f,t+1)};u={i for f,t in x['unread_for_this_registration'] for i in range(f,t+1)};assert not a&u and a|u==set(range(1,e['eof']+1))
checks.append('Eleven current support bodies registered before bounded displays, each unread complement retained')
raw=gzip.decompress((p/'reference/registry.json.gz').read_bytes());assert sha(raw)=='d1c798df997434ae8e89e433237f798de5c87a38d634f3a7d2f1b0f8af9b1f0f';reg=json.loads(raw);sel=load('registry-selection-reconstructed.json');assert sel['original_registry_sha256_uncompressed']==sha(raw)
for x in sel['rows']:assert reg['files'][x['original_index']]==x['entry']
snap=next(x for x in reg['snapshots'] if x['id']=='physical-p16');assert sel['physical_p16_snapshot']==snap and snap['base']=='a120390947c89b703dc74c4255a13c035d054c50' and snap['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for i in [2675,2676]:assert not any(x[3:]==reg['files'][i]['source_id'].split(':',1)[1] for x in snap['status_porcelain'])
assert sha((p/'reference/p16-tracked.patch').read_bytes())==snap['patch_sha256'];assert sha((p/'reference/RECOVERY-PHYSICAL-P16-PATCH-20261111.json').read_bytes())=='30184a296be0ff10031776e078f1b639f273f77e7387534f5a4eb5d5b4aa8007'
h=load('historical-support-unread.json');assert h['registry_role']==256 and reg['files'][256]['sha256']==h['sha256'] and any(x==' M crates/adventuresim-stdb-module/src/simulation.rs' for x in snap['status_porcelain']);b=(p/h['preserved_bytes']).read_bytes();assert (len(b),sha(b),blob(b))==(h['bytes'],h['sha256'],h['blob']) and 'not personally display' in h['qualification']
assert sha((p/'reference/original-transport-manifest.json.gz').read_bytes())=='7e45ce9d858f93e0c5e5d50f360f79ed8941e28049f305053f1fd2bdda364834';trans=json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()));entries={x['path']:x for x in trans['entries']}
hi=load('historical-index.json');assert sum(x['kind']=='original-059' for x in hi['records'])==28 and sum(x['kind']=='historical-774' for x in hi['records'])==9
for x in hi['records']:
 b=(p/x['file']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
 if x['kind']=='original-059':
  e=entries[x['transport_path']];assert (e['bytes'],e['sha256'],e['git_blob'])==(x['bytes'],x['sha256'],x['git_blob'])
checks.append('Original dirty P16 registry/patch, separately unread modified historical writer, 28 exact 059 records and nine 774 records')
gp=load('git-proofs.json')
def data(oid):
 x=gp['objects'][oid];b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),sha(b),hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest())==(x['bytes'],x['sha256'],oid);return b
def trees(b):
 d={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);d[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return d
for oid in gp['objects']:data(oid)
assert len(gp['proofs'])==27
for x in gp['proofs']:
 tree=data(x['revision']).splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
 for y in x['chain']:
  assert y['tree']==tree and trees(data(tree))[y['name']]==(y['mode'],y['object']);tree=y['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b;assert (sha(b),blob(b),tree)==(x['sha256'],x['blob'],x['blob'])
checks.append('Twenty-seven raw commit/tree/blob paths prove exact project and f82 transport membership')
l11=load('history-059/segovb/READ-L11-437.json')
for i,expected in [(2675,[[1,364]]),(2676,[[28,28]])]:
 x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected
assert l11['fresh_bounded_windows']['1592']==[[1,140],[141,280],[281,364]] and l11['fresh_bounded_windows']['1593']==[[28,28]]
for i,batch,regnum,parts,expected in [(2675,927,739,[1,2],[[1,195],[196,364]]),(2676,928,740,[1],[[28,28]])]:
 registration=load(f'history-059/parallel-l12-20261029/REGISTRATION-PAR-L12-{regnum}.json');proposal=load(f'history-059/parallel-l12-20261029/PROPOSAL-L12-{batch}.json');adopt=load(f'history-059/segovb/READ-L12-{batch}.json');assert adopt['root_personal_rereads']==[];allranges=[]
 for j in parts:
  record=load(f'history-059/parallel-l12-20261029/PARTIAL-PAR-L12-{batch}-{j:03d}.json');row=next(x for x in record['rows'] if x['original_index']==i);assert row['registered_at']==registration['registered_at'] and row['registered_at']<record['at']<proposal['at']<adopt['at'] and '/root/lens12_frontier' in row['attribution'];allranges.extend(row['fresh_personal_body_reads'])
 assert allranges==expected
l13=load('history-059/parallel-l13-20261029/READ-PL13-210.json');assert next(x for x in l13['rows'] if x['original']==1014)['fresh_personal_assessed_ranges']==[[1,364]] and load('history-059/segovb/READ-L13-PARALLEL-208.json')['root_personal_rereads']==[]
native=gzip.decompress((p/'history-774/native/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines();camera=gzip.decompress((p/'history-774/camera/admission03/source-range-registration.jsonl.gz').read_bytes()).splitlines()
for n in [24,25,115,119]:assert json.loads(native[n-1])['id']==f'NATIVE-ADMISSION03-REG-{n:03d}'
assert json.loads(camera[7])['id']=='CAMERA-ADM03-REG-008';follow=json.loads(gzip.decompress((p/'history-774/native/admission03/camera-lower-followthrough/schedule-contracts-001.json.gz').read_bytes()));assert 'NATIVE-LOWER-ADM03-F001' in follow['findings'];assert 'ROOT-ADM-F005' in json.loads(gzip.decompress((p/'history-774/root/admission03/schedule-admission-021.json.gz').read_bytes()))['findings']
checks.append('Original 774 native/camera/root scopes and independent 059 Lens11/12/13 reader chronology preserved')
raw=gzip.decompress((p/'reference/queue.json.gz').read_bytes());q=load('queue-selection-reconstructed.json');assert sha(raw)==q['source_queue_sha256']=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';queue=json.loads(raw)
for n,e in q['entries'].items():assert queue['entries'][int(n)]==e
assert [q['entries'][str(n)]['contract_id'] for n in [2494,3301,3444]]==['L2-SAVED-SCHEDULE-NATIVE-ADMISSION-QUESTION','REVIEW-L3-SAVED-SCHEDULE-WRITE-ADMISSION','L12-CLOSURE-PHYSICAL-SCHEDULE-ORGANIZATION-IDENTITY']
assert sha((p/'reference/ASSESSMENT-L05-SCHEDULE-AGGREGATE-95E.json').read_bytes())=='69df0143c35c003e807f4a7f9e23747f639f16c5dc7111eeb2364d1c60b69251'
for x in load('rules.json')['records']:assert sha((p/x['copy']).read_bytes())==x['sha256']
rep=load('report.json');assert {x['number'] for x in rep['lenses']}==set(range(1,14)) and rep['support_reads']==receipts
checks.append('Exact selected historical queue entries, prior current assessment, applicable rules and thirteen bounded perspectives')
print(json.dumps({'result':'PASS','checks':checks,'qualification':'Evidence integrity and recorded read scopes only. No product execution, fixture generation, simulations, builds, tests, probes, repairs, validation or checkpoint 3821 promotion.'},indent=2))
