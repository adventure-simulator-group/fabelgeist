import pathlib,subprocess,hashlib,json,datetime
p=pathlib.Path(__file__).parent;repo='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';(p/'support').mkdir(exist_ok=True);rows=[]
specs=[('crates/adventuresim-stdb-module/src/simulation.rs',[[340,495]])]
for i,(path,ranges) in enumerate(specs):
 b=subprocess.check_output(['git','-C',repo,'show',f'{rev}:{path}']);blob=subprocess.check_output(['git','-C',repo,'rev-parse',f'{rev}:{path}'],text=True).strip();rel=f'support/writer-{i}.rs';(p/rel).write_bytes(b);rows.append(dict(path=path,revision=rev,sha256=hashlib.sha256(b).hexdigest(),blob=blob,bytes=len(b),eof=len(b.splitlines()),prospective_ranges=ranges,file=rel))
x=dict(author='/root/mhr_character',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='Current alternate simulation-owned schedule write source only; never execute or generate a fixture.',navigation_qualification='Keyword line-number lookup and EOF metadata occurred before registration without printing source bodies.',rows=rows);(p/'writer-registration.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
