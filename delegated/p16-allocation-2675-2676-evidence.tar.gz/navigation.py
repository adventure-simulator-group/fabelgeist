import datetime,json,pathlib,subprocess
p=pathlib.Path(__file__).parent;pub='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';terms=['validate_daily_allocation','DailySchedulePlan','OrganizationAllocation::Scheduled','ValidatedSchedule::try_from','effective_at('];roots=['crates/adventuresim-core','crates/adventuresim-stdb-module','crates/strategic-web'];out=[]
for t in terms:
 r=subprocess.run(['git','-C',pub,'grep','-n','-F',t,rev,'--',*roots],stdout=subprocess.PIPE,text=True);assert r.returncode in [0,1];matches=[]
 for line in r.stdout.splitlines():
  path,num,_=line[len(rev)+1:].split(':',2);matches.append({'path':path,'line':int(num)})
 out.append({'literal_query':t,'matches':matches})
(p/'navigation-receipt.json').write_text(json.dumps({'author':'/root/mhr_character','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revision':rev,'roots':roots,'results':out,'qualification':'Exact-spelling pinned tracked-source metadata navigation only, not semantic caller completeness. Earlier metadata lookup before support registration initially extracted paths without line numbers; corrected metadata lookup preceded support registration. This repeat preserves names and line numbers only, no source body display or product execution.'},indent=2)+'\n')
