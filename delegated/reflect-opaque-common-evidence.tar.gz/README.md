# Bounded Bevy opaque reflection assessment

`report.json` records roles 2565–2566, source observations, open questions,
prior reviewer attribution and thirteen bounded perspectives. The cached
`bevy_reflect_derive-0.19.1.crate` archive matches the pinned 95e Cargo.lock
checksum. Both assigned source members also match the 059 archived objects and
the local native package. The package is not a project Git revision.

Both assigned native files were personally displayed in full, after
registration. The original 774 material scope of common.rs remains
1–80 and 82–172; the additional personally displayed lines are new work.
Project and native support receipts record all bounded reads and unread
complements. Other package bodies and feature activation are not established.

The recovered later 774 rig source-registration file and its first 13 rows do
not match the historical 044 registration pin. Its first 13 qualification
rows do match their historical pin. The mismatch and bounded search are retained
in `historical-774-index.json`; no later file is substituted for the earlier
unrecovered bytes. The 059 and 774 records remain separately attributed and
are not checkpoint 3821 credit.

For read-only evidence integrity checks, run:

```sh
python3 check-evidence.py
python3 verify-freeze.py
```

These verify archive members, checksums, preserved source paths, receipt scopes
and packet inventory. They do not invoke a macro, compile, run tests, execute a
product, probe a runtime, or validate product behavior.
