import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());sr=json.loads((p/'support-read-receipt.json').read_text());rec=json.loads((p/'read-receipt.json').read_text());assert H((p/'registration.json').read_bytes())==rec['registration_sha256']
for x in sr['registrations']:assert H((p/x['file']).read_bytes())==x['sha256']
project=[x for n in ['support-registration.json','support-registration-02.json'] for x in json.loads((p/n).read_text())['sources']];native=reg['sources']+json.loads((p/'native-support-registration.json').read_text())['sources'];pkg=(p/reg['package_archive']['path']).read_bytes();assert H(pkg)==reg['package_archive']['sha256']=='5fc5f820ee52afeca6d3bb83f15c1bf61ea6196c840a761a21a8bc266a3b166e'
with tarfile.open(fileobj=io.BytesIO(pkg),mode='r:gz') as t:
 for x in native:
  b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b))==(x['bytes'],x['lines'],x['sha256']);assert t.extractfile(x['package_member']).read()==b
lock=(p/reg['current_lock']['archive']).read_bytes();assert (len(lock),len(lock.splitlines()),H(lock),O('blob',lock))==(reg['current_lock']['bytes'],reg['current_lock']['lines'],reg['current_lock']['sha256'],reg['current_lock']['git_blob_sha1']);matches=[x for x in tomllib.loads(lock.decode())['package'] if x.get('name')=='bevy_reflect_derive' and x.get('version')=='0.19.1'];assert len(matches)==1 and matches[0]['checksum']==H(pkg)
for x in project:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1'])
lookup={(x['revision'],x['path']):x for x in project}; lookup[reg['current_lock']['revision'],'Cargo.lock']=reg['current_lock'];nd={x['path'] if 'path' in x else x['package_member'].split('bevy_reflect_derive-0.19.1/')[1]:x for x in native};displays={}
def check(r,n):
 rr=r['actual_display_union'];un=r['unread_ranges'];assert all(1<=a<=b<=n for a,b in rr+un);seen={i for a,b in rr for i in range(a,b+1)};missing={i for a,b in un for i in range(a,b+1)};assert not seen&missing and seen|missing==set(range(1,n+1));assert r['full_body_displayed']==(not missing)
for x in rec['reads']:
 if x['kind']=='current-lock-support':y=reg['current_lock'];key=('current-lock',x['revision'],x['path'])
 else:y=next(z for z in reg['sources'] if z['original_role']==x['original_role']);key=('native-package',y['package_member'].split('bevy_reflect_derive-0.19.1/')[1])
 check(x,y['lines']);displays[key]=x['actual_display_union']
for x in sr['project_reads']:
 y=lookup[x['revision'],x['path']];check(x,y['lines']);displays['current-project',x['revision'],x['path']]=x['actual_display_union']
for x in sr['native_reads']:
 y=nd[x['path']];check(x,y['lines']);displays['native-package',x['path']]=x['actual_display_union']
proof=json.loads((p/'git-proofs.json').read_text());objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in proof['proofs']:
 root=objects[x['revision']].splitlines()[0].split()[1].decode();assert root==x['commit_tree'];tree=root
 for e in x['chain']:
  assert e['tree']==tree and entries(objects[tree])[e['name']]==(e['mode'],e['object']);tree=e['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert tree==x['blob']==O('blob',b) and H(b)==x['sha256']
 if x['kind'] in ['current-lock','current-project-support']:assert tree==lookup[x['revision'],x['path']]['git_blob_sha1']
report=json.loads((p/'report.json').read_text());refs=0
for a in report['assessments']:
 for x in a['source_refs']:
  key=('native-package',x['path']) if x['source_kind']=='native-package' else (x['source_kind'],x['revision'],x['path']);rr=displays[key]
  for start,end in x['lines']:assert any(c<=start<=end<=d for c,d in rr),(key,start,end,rr);refs+=1
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((p/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
r=json.load(gzip.open(p/'reference/original-registry.json.gz','rt'))
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']:assert x['entry']==r['files'][x['index']]
for x in reg['sources']:assert x['original_registry_entry']==r['files'][x['original_role']] and x['sha256']==r['files'][x['original_role']]['sha256']
old774=json.loads((p/'historical-774-index.json').read_text());
for x in old774['records']:
 b=gzip.decompress((p/x['copy']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
hq=old774['hash_qualifications'];assert H((p/'historical-774/registration-observed-first13.jsonl').read_bytes())==hq['root044_later_registry_first13_sha256']!=hq['root044_prior_registration_sha256'];assert H((p/'historical-774/qualification-pin-matching-first13.jsonl').read_bytes())==hq['root044_qualification_expected_sha256']==hq['root044_later_qualification_first13_sha256'];assert hq['later_registration_file_sha256']!=hq['completion112_registry_expected_sha256']
locks=json.loads((p/'historical-locks-index.json').read_text())['records']; oldlock=json.loads((p/'historical-059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-869-MACRO-LOCK-AUTHORITY.json').read_text())
for x in locks:
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1']);item=next(z for z in oldlock['rows'] if z['original_index']==x['original_role']);assert item['source_sha256']==x['sha256']; assert H((p/'historical-059'/item['registration']).read_bytes())==item['registration_sha256'];match=[z for z in tomllib.loads(b.decode())['package'] if z.get('name')=='bevy_reflect_derive' and z.get('version')=='0.19.1'];assert len(match)==1 and match[0]['checksum']==H(pkg)
l11=json.loads((p/'historical-059/segovb/READ-L11-422.json').read_text());l12=json.loads((p/'historical-059/segovb/READ-L12-870.json').read_text());assert not l12['root_personal_rereads']
for i,rg,mat,l12rg in [(2565,1472,[[1,131]],[[1,131]]),(2566,1473,[[1,80],[82,172]],[[1,174]])]:
 x=next(z for z in l11['sources'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==mat and H((p/f'historical-059/segovb/REGISTRATION-SEGOVB-{rg}.json').read_bytes())==x['registration_sha256'];row=next(z for z in l12['rows'] if z.get('original_index')==i);assert row['fresh_personal_body_reads']==l12rg;assert H((p/'historical-059'/row['registration']).read_bytes())==row['registration_sha256'];assert H((p/'historical-059'/row['identity_specific_windows_qualification']['path']).read_bytes())==row['identity_specific_windows_qualification']['sha256'];assert row['package_archive_sha256']==H(pkg)
assert H((p/'historical-059/parallel-l12-20261029/PROPOSAL-L12-870.json').read_bytes())==l12['proposal_sha256']
for x in json.loads((p/'prior-references.json').read_text())['references']:
 assert H((p/x['copied_manifest']).read_bytes())==x['manifest_sha256'] and H((p/x['copied_report']).read_bytes())==x['report_sha256'];man=json.loads((p/x['copied_manifest']).read_text());assert next(z['sha256'] for z in man['files'] if z['path']=='report.json')==x['report_sha256']
assert len(report['perspectives'])==13
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','native_package_checksum_verified':H(pkg),'native_assigned_members':len(reg['sources']),'native_support_members':len(native)-len(reg['sources']),'current_project_support_objects':len(project),'git_membership_proofs':len(proof['proofs']),'raw_git_commit_tree_objects':len(objects),'assessment_source_ranges_inside_actual_display':refs,'original_059_records':len(hist['records']),'historical_lock_objects':len(locks),'older_774_exact_archive_records':len(old774['records']),'root044_registry_pin_match':False,'root044_qualification_prefix_pin_match':True,'qualification':'Evidence hashing, TOML/JSON/gzip/tar parsing and raw Git path verification only; earlier 774 registry bytes not recovered to match historical pin; no product/test/build/macro execution.'};print(json.dumps(result,indent=2))
