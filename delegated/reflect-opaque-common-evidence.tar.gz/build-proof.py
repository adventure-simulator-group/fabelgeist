import datetime,gzip,hashlib,json,pathlib,re,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());C=reg['current_lock']['revision'];F='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';support=[x for n in ['support-registration.json','support-registration-02.json'] for x in json.loads((p/n).read_text())['sources']];lock=dict(reg['current_lock'],kind='current-lock');native=[]
for x in reg['sources']:
 b=(p/x['archive']).read_bytes();native.append({'kind':'native-object-archive-transport','revision':F,'path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+x['sha256'],'archive':x['archive'],'sha256':x['sha256'],'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
hist=json.loads((p/'historical-774-index.json').read_text())['records'];historical=[{'kind':'historical-record-transport','revision':x['git_transport_revision'],'path':x['git_transport_path'],'archive':x['copy'],'sha256':x['sha256'],'git_blob_sha1':x['git_blob_sha1'],'encoding':'gzip'} for x in hist];locks=[{'kind':'historical-lock-transport' if x['original_role']==39 else 'historical-pr-working-lock','revision':x['revision'],'path':x['git_path'],'archive':x['archive'],'sha256':x['sha256'],'git_blob_sha1':x['git_blob_sha1'],'encoding':'gzip'} for x in json.loads((p/'historical-locks-index.json').read_text())['records']];records=[lock]+support+native+historical+locks;d=p/'git-objects';d.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=d/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 commit=get('commit',x['revision']);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b
 assert tree==x['git_blob_sha1'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'kind':x['kind'],'revision':x['revision'],'path':x['path'],'archive':x['archive'],'encoding':x.get('encoding','raw'),'commit_tree':root,'chain':chain,'blob':tree,'sha256':x['sha256']})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Current project and lock path membership; old lock sources at separately recorded transports; f82 stores native object/old records only, never package origin or project revision. Native package archive checksum and members are independently verified.','objects':objects,'proofs':proof},indent=2)+'\n')
def complement(rr,n):
 out=[];k=1
 for a,b in rr:
  if k<a:out.append([k,a-1])
  k=b+1
 if k<=n:out.append([k,n])
 return out
def merge(spans):
 out=[]
 for a,b in sorted(spans):
  if out and a<=out[-1][1]+1:out[-1][1]=max(b,out[-1][1])
  else:out.append([a,b])
 return out
reads=[]
for x in reg['sources']:
 rr=[[1,x['lines']]];reads.append({'original_role':x['original_role'],'kind':x['kind'],'path':x['package_member'],'archive':x['archive'],'actual_display_ranges':x['planned_display_chunks'],'actual_display_union':rr,'unread_ranges':[],'full_body_displayed':True,'qualification':'Personal complete source-only read after registration; native original role 2566 remains historically limited to 1–80 and 82–172.'})
rr=[[2521,2537]];reads.append({'kind':'current-lock-support','revision':C,'path':'Cargo.lock','archive':reg['current_lock']['archive'],'actual_display_union':rr,'unread_ranges':complement(rr,reg['current_lock']['lines']),'full_body_displayed':False,'qualification':'Matching package clause plus next header/version only; remainder not read.'})
(p/'read-receipt.json').write_text(json.dumps({'schema':'726-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':hashlib.sha256((p/'registration.json').read_bytes()).hexdigest(),'reads':reads,'qualification':'Full archived package and Cargo.lock do not by themselves grant source read credit.'},indent=2)+'\n')
pranges={0:[[1,14]],1:[[1,14]],2:[[1,131]],3:[[1,97]],4:[[1,70]],5:[[1,48]],6:[[70,185]],7:[[1,85]]};pnav={str(i):[] for i in range(8)}
for line in (p/'navigation-project.txt').read_text().splitlines():
 m=re.match(r'.*support-(\d+)\.source:(\d+):',line)
 if m:pnav[str(int(m.group(1)))].append(int(m.group(2)))
project=[]
for i,x in enumerate(support):
 rr=merge(pranges[i]+[[n,n] for n in pnav[str(i)]]);project.append({'path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':complement(rr,x['lines']),'full_body_displayed':rr==[[1,x['lines']]]})
native_support=json.loads((p/'native-support-registration.json').read_text())['sources'];nranges={0:[[60,118]],1:[[1,60]],2:[[21,215]],3:[[275,310],[329,351],[465,482]]};nnav={str(i):[] for i in range(4)}
for line in (p/'navigation-native.txt').read_text().splitlines():
 m=re.match(r'.*native-support-(\d+)\.source:(\d+):',line)
 if m:nnav[str(int(m.group(1)))].append(int(m.group(2)))
nreads=[]
for i,x in enumerate(native_support):
 rr=merge(nranges[i]+[[n,n] for n in nnav[str(i)]]);nreads.append({'package':x['package'],'version':x['package_version'],'path':x['path'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':complement(rr,x['lines']),'full_body_displayed':rr==[[1,x['lines']]],'qualification':'Exact bounded display plus individually exposed navigation lines; no inferred whole package coverage.'})
(p/'navigation-exposures.json').write_text(json.dumps({'project':pnav,'native_package':nnav,'qualification':'Initial native navigation output was truncated; exact complete stored navigation was then displayed without truncation before these exposures were recorded.'},indent=2)+'\n')
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'file':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in ['support-registration.json','support-registration-02.json','native-support-registration.json']],'project_reads':project,'native_reads':nreads},indent=2)+'\n');print('git proofs',len(proof),'raw objects',len(objects),'project support',len(project),'native support',len(nreads),'native nav exposed lines',sum(len(v) for v in nnav.values()))
