from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).resolve().parent;pub=Path('<LOCAL_PATH_0>');sha=lambda x:hashlib.sha256(x).hexdigest();old='6533e444fa37552927070cc8d8190907fd3b413e';cur='95e63628f9d70b8dd6e6fede64334696c6995009';specs=[('layout',cur,'crates/fabelgeist-armor/src/gpu/part/layout.rs',[[1,150],[200,250]]),('recipe',cur,'crates/fabelgeist-armor/src/gpu/recipe.rs',[[1,85],[140,175]]),('limb-build',cur,'crates/fabelgeist-armor/src/gpu/limb_build.rs',[[1,46]]),('sampling',cur,'crates/fabelgeist-armor/src/sampling.rs',[[1,75]]),('part',cur,'crates/fabelgeist-armor/src/gpu/part.rs',[[40,105]])];rows=[]
for name,rev,path,rs in specs:
 raw=subprocess.check_output(['git','-C',str(pub),'show',rev+':'+path]);eof=len(raw.splitlines());assert all(1<=a<=z<=eof for a,z in rs);archive='support/'+name+'.rs';(b/archive).write_bytes(raw);chunks=[]
 for a,z in rs:
  for s in range(a,z+1,65):chunks.append([s,min(s+64,z)])
 blob=subprocess.check_output(['git','-C',str(pub),'rev-parse',rev+':'+path]).decode().strip();rows.append({'revision':rev,'path':path,'archive':archive,'sha256':sha(raw),'bytes':len(raw),'git_blob':blob,'actual_eof':eof,'registered_ranges':rs,'planned_chunks':chunks,'qualification':'Independent bounded support only; no original-role credit or previous authorship transfer.'})
x={'schema':'726-besagew-budget-support-prospective-v1','registered_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':rows};raw=(json.dumps(x,indent=2)+'\n').encode();(b/'budget-registration.json').write_bytes(raw);print('sha256',sha(raw));print([(x['archive'],x['registered_ranges'],x['planned_chunks']) for x in rows])
