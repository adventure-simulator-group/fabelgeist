from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).parent;sha=lambda x:hashlib.sha256(x).hexdigest();names=['registration.json','support-registration.json','chart-registration.json','plain-chart-registration.json','units-registration.json','budget-registration.json','export-registration.json','owner-default-registration.json','editor-registration.json','input-registration.json'];reads=[]
def comp(n,ranges):
 seen={i for a,z in ranges for i in range(a,z+1)};missing=[];lo=None
 for i in range(1,n+2):
  if i<=n and i not in seen and lo is None:lo=i
  if (i>n or i in seen) and lo is not None:missing.append([lo,i-1]);lo=None
 return missing
for j,n in enumerate(names):
 data=json.loads((b/n).read_bytes())
 for e in data['entries']:
  reads.append({'kind':'assigned' if j==0 else 'separately registered support','registration':n,'role':e.get('role'),'revision':e['revision'],'path':e['path'],'archive':e['archive'],'sha256':e['sha256'],'actual_eof':e['actual_eof'],'actual_display_ranges':e['registered_ranges'],'actual_display_chunks':e['planned_chunks'],'unread_complement_for_this_registration':comp(e['actual_eof'],e['registered_ranges']),'original_registry_ranges':e.get('original_registry_ranges'),'qualification':'Untruncated source display as shown in listed chunks. Support complements can overlap separate registrations; shader source was inspected only and never compiled or run; sampling.rs 60–75 contains test source text, never executed.'})
r={'schema':'726-besagew-radial-personal-read-v1','reader':'/root/rig_identity','recorded_utc':datetime.now(timezone.utc).isoformat(),'registrations':[{'path':n,'sha256':sha((b/n).read_bytes())} for n in names],'reads':reads,'qualification':'Historical material scope, current source and separately registered support are distinct. Exact bytes are retained, and unread complements are not coverage. No product or source execution.'};(b/'personal-read-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('assigned',sum(x['kind']=='assigned' for x in reads),'support',sum(x['kind']!='assigned' for x in reads))
