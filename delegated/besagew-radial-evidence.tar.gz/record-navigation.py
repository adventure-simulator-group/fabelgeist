from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path(__file__).parent;p='<LOCAL_PATH_0>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';specs=[('navigation-owners.txt','BesagewDesign|RadialFluting|\\.besagew|besagew\\(|\\.columns\\(',['crates/fabelgeist-armor/src']),('navigation-shape.txt','fn shape\\(|\\.validate\\(\\)\\?|spaulder\\(|MINIMUM_COLUMNS',['crates/fabelgeist-armor/src/gpu/limb.rs','crates/fabelgeist-armor/src/limb_armor.rs']),('navigation-units.txt','struct (Permille|Milliradians)|fn (unit|metres|radians)',['crates/fabelgeist-armor/src/design.rs'])];out=[]
for name,pattern,paths in specs:
 x=subprocess.run(['git','-C',p,'grep','-n','-E',pattern,rev,'--',*paths],capture_output=True);assert x.returncode in [0,1];(b/name).write_bytes(x.stdout);out.append({'path':name,'sha256':hashlib.sha256(x.stdout).hexdigest(),'pattern':pattern,'paths':paths,'revision':rev,'qualification':'Singleton search navigation only; no contiguous body credit.'})
root=[]
for path in ['crates/AGENTS.md','crates/fabelgeist-armor/AGENTS.md','crates/adventuresim-character-creator/AGENTS.md']:
 raw=Path('<LOCAL_PATH_1>',path).read_bytes();git=subprocess.check_output(['git','-C',p,'show',rev+':'+path]);assert raw==git;root.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'workspace_bytes_equal_pinned':True})
(b/'navigation-and-rules.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'navigation':out,'rules':root,'qualification':'Applicable rules personally read previously; the evidence-only review does not invoke a modeling or validation cycle. The earlier broad creator source search was truncated and is not an exhaustive inventory. Search is not read credit.'},indent=2)+'\n');print('navigation',len(out),'rules',len(root))
