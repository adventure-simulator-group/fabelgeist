from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();out=[]
for rn in ('registration.json','support-registration.json'):
 r=json.loads((b/rn).read_bytes())
 for e in r['entries']:
  ranges=e.get('prospective_personal_read_ranges',e.get('ranges',[]));chunks=[]
  for a,z in ranges:
   if z-a+1>70:
    midpoint=70 if e.get('role')==2687 else 49 if 'bounds' in e['archive'] else 45 if 'geometry-error' in e['archive'] else None
    assert midpoint and a<=midpoint<z,e;chunks += [[a,midpoint],[midpoint+1,z]]
   else:chunks.append([a,z])
  n=e['eof'];mask={i for a,z in ranges for i in range(a,z+1)};unread=[];start=None
  for i in range(1,n+2):
   if i<=n and i not in mask and start is None:start=i
   if (i>n or i in mask) and start is not None:unread.append([start,i-1]);start=None
  out.append({'role':e.get('role'),'kind':e.get('kind',e.get('name')),'revision':e['revision'],'sha256':e['sha256'],'archive':e['archive'],'registration':rn,'registration_sha256':sha((b/rn).read_bytes()),'actual_displayed_chunks':chunks,'actual_displayed_ranges':ranges,'unread_complement':unread,'attribution':'/root/rig_identity personal independent display after prospective registration','truncated':False})
(b/'personal-read-receipt.json').write_text(json.dumps({'schema':'726-personal-source-read-receipt-v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'author':'/root/rig_identity','entries':out,'qualification':'This fresh assigned read is distinct from the previous packet partial support 2687 1–110 and 2688 1–28; the latter retains its own attribution and role, not transferred.'},indent=2)+'\n');print('entries',len(out))
