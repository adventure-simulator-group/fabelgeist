import gzip,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>'); old=pathlib.Path('<LOCAL_PATH_1>'); pub=pathlib.Path.cwd()
manifest=json.load(gzip.open(pub/'recovered/original-transport-manifest.json.gz','rt')); lookup={x['path']:x for x in manifest['entries']}
sha=lambda x:hashlib.sha256(x).hexdigest()
blob=lambda x:hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
paths=['adler/READ-L11-374.json','adler/VERIFY-L11-374.json','adler/STATE-L11-374.json','adler/READ-L11-180.json','adler/VERIFY-L11-180.json','adler/STATE-L11-180.json','adler/REGISTRATION-ADLER-146.json','adler/REGISTRATION-ADLER-147.json']
paths += [f'adler/REGISTRATION-ADLER-{i}.json' for i in range(1197,1201)]
paths += [f'segovb/{kind}-L12-{n}.json' for n in (364,768,770,771) for kind in ('READ','VERIFY','STATE')]
paths += ['segovb/PLAN-L12-364.json','segovb/REGISTRATION-SUPPORT-L12-364-001.json','segovb/REGISTRATION-SUPPORT-L12-364-002.json']
paths += [f'segovb/REGISTRATION-SEGOVB-L12-{n}.json' for n in (233,234,235)]
paths += [f'parallel-l12-20261029/REGISTRATION-PAR-L12-{n}.json' for n in range(300,304)]
paths += ['parallel-l12-20261029/PROPOSAL-L12-770.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-769-779-AUDIT-ONLY-HEADERS.json']
records=[];missing=[]
for path in paths:
 if path not in lookup or not (old/path).is_file():missing.append(path);continue
 b=(old/path).read_bytes(); expected=lookup[path]; assert sha(b)==expected['sha256'] and len(b)==expected['bytes'] and blob(b)==expected['git_blob'],path
 target=out/'historical-059'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 records.append({'path_as_recorded':path,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'preserved_bytes':str(target.relative_to(out)),'verification':'Exact original against original 059 transport manifest; preserves author, revision and scoped qualifications; not evidence of checkpoint3821'})
old774=pathlib.Path('<LOCAL_PATH_2>')
more=[]
for dirname,filename in [('audit-producer-propagation','sources.json'),('audit-existing-type-owners','coverage.jsonl')]:
 p=old774/dirname/'rig'/filename; b=p.read_bytes(); gitpath=f'handoff/774/historical-family-execution/final-acceptance-20261021/wave-01/{dirname}/rig/{filename}'; gitbytes=subprocess.check_output(['git','show','f82adcabd9d89c4fa2dd7f99253a45297a0681ee:'+gitpath]); assert b==gitbytes
 target=out/'historical-774'/dirname/'rig'/filename; target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 more.append({'earlier_collection':'original final-acceptance-20261021 wave-01 historical 774','git_revision':'f82adcabd9d89c4fa2dd7f99253a45297a0681ee','git_path':gitpath,'sha256':sha(b),'bytes':len(b),'git_blob':blob(b),'preserved_bytes':str(target.relative_to(out)),'verification':'Older local copy byte-identical to exact f82 Git path; not checkpoint3821 or current read credit'})
d={'schema':'726-delegated-rig-identity-historical-evidence-v1','original_059_transport_manifest_sha256':sha((pub/'recovered/original-transport-manifest.json.gz').read_bytes()),'original_059_records':records,'original_059_records_unavailable':missing,'older_774_records':more,'qualification':'All original records preserve their own attribution, revision, scope and historical status. Historical read coverage does not transfer to the present delegate or to other lenses. No checkpoint3821 promotion.'}
(out/'history-manifest.json').write_text(json.dumps(d,indent=2)+'\n');print('059 copied',len(records),'missing',missing,'774 exact',len(more))
