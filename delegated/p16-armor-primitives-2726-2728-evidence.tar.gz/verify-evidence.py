'''Offline evidence-integrity verification only; no product, armor, fixture, build or test execution.'''
from pathlib import Path
from datetime import datetime
import difflib,gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files']
assert all(original[i]==sel['registry_rows'][str(i)] for i in [2175,2608,2609,2726,2727,2728])
assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id'] in ['physical-p16','pr-working']]
snapshot=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes()
assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['recovered_patch']['bytes']==len(patch) and recovery['live_comparison']['status_counts']['??']==7
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows'];expected={2726:[[1,99]],2727:[[1,56]],2728:[[1,22],[33,66]]}
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];body=(b/old['local']).read_bytes()
  assert t.extractfile(old['sha256']).read()==body and h(body)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256']
  assert original[i]['material_ranges']==expected[i] and row['original_material_ranges']==expected[i]
  assert catalog[i]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path']
  for c in row['comparison_git_paths']:
   assert c['display_planned']==False
   assert ((b/c['local']).read_bytes()==body)==(c['revision'].startswith('a120') or i in [2726,2727])
  assert ((b/cur['local']).read_bytes()==body)==(i in [2726,2727])
a=(b/'source/2728-physical-p16.rs').read_text().splitlines(keepends=True);c=(b/'source/2728-95e6.rs').read_text().splitlines(keepends=True)
assert ''.join(difflib.unified_diff(a,c,fromfile='physical-p16 archived object',tofile='95e current source'))==(b/'2728-old-current.diff').read_text()
for x in rec['registrations']:
 assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def nums(ranges):return [i for a,z in ranges for i in range(a,z+1)]
def partition(n,ranges):
 v=nums(ranges);return len(v)==n and set(v)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes()
  assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof']
  assert partition(v['eof'],p['original_assigned_displays']+p['separately_registered_context_displays']+p['unread_complement'])
  assert p['unread_complement']==[] and nums(p['actual_display_chunks'])==list(range(1,v['eof']+1))
  assert p['original_assigned_displays']==(expected[row['original_index']] if j==0 else [])
planned={x['local']:x for x in load('support-registration.json')['entries']}
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof']
 assert partition(x['eof'],x['displayed']+x['unread_complement']) and x['displayed']==e['planned_display_ranges'] and x['ordered_role_credit']==0
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:
  assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
assert len(proof['proofs'])==34
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()]
native=readjsonl('historical/774/native-range-registration.jsonl');nf=readjsonl('historical/774/native-final-qualifications.jsonl');nq=readjsonl('historical/774/native-camera-qualifications.jsonl');rig=readjsonl('historical/774/rig-range-registration.jsonl');ncontract=load('historical/774/native-p16-armor-admission.json')
for i in [2726,2727,2728]:
 ob=original[i]['admission03_scope_observations'][0];assert native[ob['row_1based']-1]==ob['original_record']
 qual=next(x for x in nf if x['registration_id']==ob['registration_id']);assert qual==ob['local_qualifications'][0]
 assert nq[i-2724]==qual['qualification_history'][0]['payload'];assert ncontract['registered_sources'][i-2724]==ob['original_record']
assert nf[41]['context_or_excluded_within_registration']==[[100,100]]
for i in [2608,2609]:
 for ob in original[i]['admission03_scope_observations']:assert rig[ob['row_1based']-1]==ob['original_record']
rfind=readjsonl('historical/774/rig-findings.jsonl');nfind=readjsonl('historical/774/native-findings.jsonl')
rf=next(x for x in rfind if x.get('id')=='RIG-ADMISSION03-F049');nfound=next(x for x in nfind if x.get('id')=='NATIVE-ADMISSION03-F007')
assert 'anime_design.rs' in rf['source_id'] and 'quest_generation/model.rs' in nfound['source_id'] and 'F007/RigF049' in ncontract['counterexample_or_qualification']
assert 'u16MAX' in ncontract['counterexample_or_qualification'] and 'release wraps andlater rejects' in ncontract['counterexample_or_qualification']
l11=load('historical/059/segovb/READ-L11-445.json')
for i,number in [(2726,1645),(2727,1646),(2728,1647)]:
 x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected[i] and h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{number}.json').read_bytes())==x['registration_sha256']
for i,number,ranges in [(2608,1520,[[1,100],[102,131],[147,150]]),(2609,1521,[[1,56]])]:
 x=next(x for x in load('historical/059/segovb/READ-L11-427.json')['sources'] if x['original_index']==i)
 assert x['fresh_personal_body_reads']==ranges and h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{number}.json').read_bytes())==x['registration_sha256']
for i,n,ranges in [(2608,890,[[1,100],[102,131],[147,150]]),(2609,891,[[1,56]])]:
 p=load(f'historical/059/segovb/READ-L12-{n}.json');x=next(x for x in p['rows'] if x['original_index']==i)
 assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution'] and p['root_personal_rereads']==[]
 assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-952.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False
for i,ranges in [(2726,[[1,100]]),(2727,[[1,56]]),(2728,[[1,22],[33,66]])]:
 x=next(x for x in p['rows'] if x['original_index']==i);assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution']
 assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
 q=x['identity_specific_windows_qualification'];assert h((b/'historical/059'/q['path']).read_bytes())==q['sha256']
for x in p['partial_read_receipts']:assert h((b/'historical/059'/x['path']).read_bytes())==x['sha256']
p=load('prior/design-fluting-read-receipt.json');assert p['author']=='/root/mhr_character';x=[x for x in p['reads'] if x['original_index']==2608]
assert len(x)==2 and {z['revision'] for z in x}=={'6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009'} and all(z['actual_display_ranges']==[[1,100],[101,150]] for z in x)
p=load('prior/anime-helmets-read-receipt.json');assert p['agent']=='/root/hair_ops';x=next(x for x in p['assigned'] if x['role']==2609)
assert x['pr_working_actual_display']==x['current_95e_actual_display']==[[1,56]]
for label,filename in [('p16-armor-admission','REPORT.json'),('anime-helmets','REPORT.json'),('design-fluting','report.json')]:
 manifest=load('prior/'+label+'-MANIFEST.json');row=next(x for x in manifest['files'] if x['path']==filename)
 raw=(b/('prior/'+label+'-'+filename)).read_bytes();assert row['sha256']==h(raw) and row['bytes']==len(raw)
prior_support=load('prior-support-index.json')
assert len(prior_support['entries'])==8
for x in prior_support['entries']:
 raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and len(raw.splitlines())==x['eof'] and x['fresh_current_task_read']==False and x['role_credit']==0
 if x['reader']=='/root/hair_ops':
  receipt=load('prior/p16-armor-admission-read-receipt.json');row=next(z for z in receipt['support'] if z['path']==x['path']);manifest=load('prior/p16-armor-admission-MANIFEST.json')
  assert row['displayed']==x['prior_displayed']
 else:
  assert x['reader']=='/root/mhr_character';receipt=load('prior/design-fluting-support-read-receipt.json');row=next(z for z in receipt['reads'] if z['path']==x['path']);manifest=load('prior/design-fluting-MANIFEST.json')
  assert row['actual_ranges']==x['prior_displayed']
 assert row['sha256']==x['sha256'] and row['revision']==x['revision']
 entry=next(z for z in manifest['files'] if z['path']==x['original_packet_member'])
 assert entry['sha256']==x['sha256'] and entry['bytes']==x['bytes']
for x in load('prior/design-fluting-support-read-receipt.json')['registrations']:
 assert h((b/('prior/design-fluting-'+x['file'])).read_bytes())==x['sha256']
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: P16 roles2726/2727/2728 and 95e independently displayed; original context exclusions and 059/774 personal attributions retained; tracked-patch qualification, Native-F007/Rig-F049 conflict and historical MAX wrapping rejection-site refinement preserved; %d offline raw Git membership proofs. Thirteen bounded perspectives; no product/build/test/probe.'%len(proof['proofs']))
