from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
b=Path(__file__).resolve().parent
prev=Path('<LOCAL_PATH_0>')
h=lambda x:hashlib.sha256(x).hexdigest()
spec=[
 ('source/2724-physical-p16.rs','support/p16-lib.rs','crates/fabelgeist-armor/src/lib.rs',None,[[86,155]],'archived dirty physical-p16 support; earlier original2724 role already separately read by this agent'),
 ('source/2724-95e6.rs','support/current-lib.rs','crates/fabelgeist-armor/src/lib.rs','95e63628f9d70b8dd6e6fede64334696c6995009',[[163,239]],'current support; prior same-agent role2724 full current display'),
 ('source/2725-95e6.rs','support/current-breastplate-design.rs','crates/fabelgeist-armor/src/breastplate_design.rs','95e63628f9d70b8dd6e6fede64334696c6995009',[[1,128]],'current support; prior same-agent role2725 full current display')
]
entries=[]
for old,loc,path,rev,ranges,qual in spec:
 raw=(prev/old).read_bytes(); out=b/loc;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 entries.append(dict(local=loc,path=path,revision=rev,identity=qual,sha256=h(raw),bytes=len(raw),eof=len(raw.splitlines()),planned_display_ranges=ranges,ordered_role_credit=0))
d=dict(created_utc=datetime.now(timezone.utc).isoformat(),reader='/root/hair_ops',description='Prospectively registered bounded independent support displays. Historical/current prior receipts remain separately attributed; source bytes copied exactly from previous packet before display.',entries=entries)
(b/'support-registration.json').write_text(json.dumps(d,indent=2)+'\n')
print(h((b/'support-registration.json').read_bytes()),d['created_utc'])
