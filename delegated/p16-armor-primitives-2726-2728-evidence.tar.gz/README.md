# Bounded physical-p16 armor primitives evidence

New source assessment by /root/hair_ops, roles 2726–2728, compared against
pinned project revision 95e63628f9d70b8dd6e6fede64334696c6995009.
See REPORT.json for source findings, all thirteen bounded perspectives, original
authors, open questions, and historical relationships. The packet contains
original source objects and retained historical records, reconstructed selection
and read receipts, newly assessed findings, and raw Git membership proofs.

P16 is a dirty a120-based snapshot, not the f82 transport commit. A later
reproduced tracked patch matches the registry's recorded SHA-256; seven
untracked objects are separate. Per-file equality to a120, 6533, 039 or 95e
does not equate snapshots, reviewers, or credit. The registry's qualified
historical ranges exclude 2726 line 100 and 2728 lines 23–32 and 67–166.
Those additional old lines are independently registered context here.

Registration, receipt, raw archives, raw Git commit/tree objects, original 059
and 774 records, earlier reports, and the exact source bytes behind selected prior support
receipts are preserved alongside REPORT.json. Prior support remains attributed
to the original reader and is not a fresh display or ordered-role credit.
historical-selections-reconstructed.json is newly reconstructed from recovered
originals; it is not an original historical record. The 059 Lens12 proposal
952 states that it did not write the authoritative ledger; no root adoption was
found at the two checked extraction paths. This is not proof of absence
everywhere and does not establish 3821.
The historical native F007/RigF049 label conflict and its MAX wrapping claim
are retained and qualified in the new report; they are not rewritten.

Run `python3 verify-evidence.py` from any working directory to check the
self-contained evidence. The check verifies hashes, raw Git membership proofs,
archived object identity, source/read partitions, historical registrations,
historical labels, and reconstructed selections. It does not execute the
product or fixtures. MANIFEST.json lists every file except itself, including
the nested recovered/MANIFEST.json.
