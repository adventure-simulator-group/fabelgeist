from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
b=Path(__file__).resolve().parent
h=lambda x:hashlib.sha256(x).hexdigest()
p=Path('<LOCAL_PATH_0>')
m=Path('<LOCAL_PATH_1>')
for n in ['support-registration.json','support-registration-02.json']:
 raw=(m/n).read_bytes();(b/'prior'/('design-fluting-'+n)).write_bytes(raw)
spec=[
 (p,'/root/hair_ops','read-receipt.json','crates/adventuresim-character-creator/src/design_input.rs','prior-support/hair-design-input.rs'),
 (p,'/root/hair_ops','read-receipt.json','crates/adventuresim-character-creator/src/runtime_equipment/warmup.rs','prior-support/hair-warmup.rs'),
 (p,'/root/hair_ops','read-receipt.json','crates/adventuresim-character-creator/src/runtime_equipment.rs','prior-support/hair-runtime-equipment.rs'),
 (p,'/root/hair_ops','read-receipt.json','crates/adventuresim-character-creator/src/armor_recipes.rs','prior-support/hair-armor-recipes.rs'),
 (p,'/root/hair_ops','read-receipt.json','crates/adventuresim-character-creator/src/device_torso.rs','prior-support/hair-device-torso.rs'),
 (p,'/root/hair_ops','read-receipt.json','crates/fabelgeist-armor/src/gpu/breastplate/mod.rs','prior-support/hair-device-breastplate.rs'),
 (m,'/root/mhr_character','support-read-receipt.json','crates/fabelgeist-armor/src/gpu/bracer.rs','prior-support/mhr-device-bracer.rs'),
 (m,'/root/mhr_character','support-read-receipt.json','crates/fabelgeist-armor/src/gpu/chart.rs','prior-support/mhr-chart.rs')
]
entries=[]
for folder,reader,receipt,name,dest in spec:
 d=json.loads((folder/receipt).read_bytes())
 row=next(x for x in d.get('support',d.get('reads',[])) if x['path']==name)
 orig=row.get('local',row.get('source_file'));raw=(folder/orig).read_bytes()
 assert h(raw)==row['sha256']
 out=b/dest;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 entries.append({'reader':reader,'revision':row['revision'],'path':name,'local':dest,'sha256':h(raw),'bytes':len(raw),'eof':row['eof'],'original_packet':str(folder),'original_packet_member':orig,'prior_displayed':row.get('displayed',row.get('actual_ranges')),'fresh_current_task_read':False,'role_credit':0})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'kind':'Recovered exact source bytes behind earlier delegated support receipts, no new display or ordered-role credit','entries':entries}
(b/'prior-support-index.json').write_text(json.dumps(d,indent=2)+'\n')
print('archived support',len(entries),'index',h((b/'prior-support-index.json').read_bytes()))
