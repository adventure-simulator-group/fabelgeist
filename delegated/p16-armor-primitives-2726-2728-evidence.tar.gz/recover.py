from pathlib import Path
import difflib,gzip,hashlib,json,subprocess
b=Path(__file__).resolve().parent
repo=Path('<LOCAL_PATH_0>')
workspace=Path('<LOCAL_PATH_1>')
orig=Path('<LOCAL_PATH_2>')
prev=Path('<LOCAL_PATH_3>')
h=lambda x:hashlib.sha256(x).hexdigest();records=[]
def copy(src,dest,kind):
 raw=Path(src).read_bytes();out=b/dest;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 records.append({'origin':str(src),'local':dest,'sha256':h(raw),'bytes':len(raw),'kind':kind})
for n in ['registry.json.gz','objects.tar.gz','MANIFEST.json','catalog-774.json','original-059-queue.json.gz','original-059-ledger.json.gz','physical-p16-patch-recovery/tracked.patch','physical-p16-patch-recovery/live-comparison-redacted.json']:
 copy(prev/'recovered'/n,'recovered/'+n,'Retained exact recovered registry/archive, original 059 ledger/queue, older reconstructed catalogue, or later recovered P16 tracked patch.')
for n in ['RECOVERY-PHYSICAL-P16-PATCH-20261111.json','SEARCH-P16-PATCH-20261111.json']:
 copy(repo/n,'prior/'+n,'Later P16 patch recovery and prior bounded search are separate historical records.')
for label,folder,ns in [
 ('p16-armor-admission',prev,['REPORT.json','MANIFEST.json','registration.json','support-registration.json','read-receipt.json']),
 ('anime-helmets',Path('<LOCAL_PATH_4>'),['REPORT.json','MANIFEST.json','registration.json','support-registration.json','read-receipt.json']),
 ('design-fluting',Path('<LOCAL_PATH_5>'),['report.json','MANIFEST.json','registration.json','read-receipt.json','support-read-receipt.json'])
]:
 for n in ns:copy(folder/n,'prior/'+label+'-'+n,'Exact earlier report, registration, receipt, or manifest; original reader and scope retained.')
for n in ['AGENTS.md','crates/AGENTS.md','crates/fabelgeist-armor/AGENTS.md']:
 copy(workspace/n,'rules/'+n,'Applicable current source rules. User excludes product validation and shape-review execution.')
names=[
 'segovb/READ-L11-427.json','segovb/READ-L11-445.json',
 'segovb/REGISTRATION-SEGOVB-1520.json','segovb/REGISTRATION-SEGOVB-1521.json',
 'segovb/REGISTRATION-SEGOVB-1645.json','segovb/REGISTRATION-SEGOVB-1646.json','segovb/REGISTRATION-SEGOVB-1647.json',
 'segovb/READ-L12-890.json','segovb/READ-L12-891.json',
 'parallel-l12-20261029/PROPOSAL-L12-890.json','parallel-l12-20261029/PROPOSAL-L12-891.json',
 'parallel-l12-20261029/REGISTRATION-PAR-L12-675.json','parallel-l12-20261029/REGISTRATION-PAR-L12-676.json',
 'parallel-l12-20261029/PROPOSAL-L12-952.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-949-956.json'
]
for i in [792,793,794]:
 names.append(f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json')
for i,j in [(792,2726),(793,2727),(794,2728)]:
 names.append(f'parallel-l12-20261029/QUALIFICATION-PAR-L12-{i}-ORIGINAL{j}.json')
for i in [1,2,3]:
 names.append(f'parallel-l12-20261029/PARTIAL-PAR-L12-952-{i:03}.json')
for n in names:
 copy(orig/n,'historical/059/'+n,'Exact historical receipt, adoption or proposal with no root adoption located in the checked extraction; no 3821 promotion.')
rev='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
paths=[
 ('native-range-registration.jsonl','handoff/774/adler-original/audit/continuation/native/admission03/source-range-registration.jsonl'),
 ('native-final-qualifications.jsonl','handoff/774/adler-original/audit/continuation/native/admission03/source-qualifications-final-current.jsonl'),
 ('native-camera-qualifications.jsonl','handoff/774/adler-original/audit/continuation/native/admission03/camera-support/source-qualifications-022.jsonl'),
 ('native-p16-armor-admission.json','handoff/774/adler-original/audit/continuation/native/admission03/camera-support/p16-armor-admission-021.json'),
 ('native-findings.jsonl','handoff/774/adler-original/audit/continuation/native/admission03/findings.jsonl'),
 ('rig-range-registration.jsonl','handoff/774/adler-original/audit/continuation/rig/admission03/source-range-registration.jsonl'),
 ('rig-additional-contracts.jsonl','handoff/774/adler-original/audit/continuation/rig/admission03/additional-contracts.jsonl'),
 ('rig-findings.jsonl','handoff/774/adler-original/audit/continuation/rig/admission03/findings.jsonl')
]
for n,p in paths:
 raw=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+p])
 out=b/'historical/774'/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 records.append({'origin':'git:'+rev+':'+p,'local':str(out.relative_to(b)),'sha256':h(raw),'bytes':len(raw),'kind':'Exact 774 historical record via f82 transport, not a P16 source head.','transport_revision':rev,'git_path':p})
rraw=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());r=json.loads(rraw)
qraw=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());q=json.loads(qraw)['entries']
d={'kind':'Newly reconstructed selections from exact original registry and 059 queue, not historical standalone records.','registry_uncompressed_sha256':h(rraw),'queue_uncompressed_sha256':h(qraw),'registry_rows':{str(i):r['files'][i] for i in [2175,2608,2609,2726,2727,2728]},'snapshot_rows':[x for x in r['snapshots'] if x['id'] in ['pr-working','physical-p16']],'queue_rows':{str(i):q[i] for i in [608,641,1814,1815,1818,3141]}}
(b/'historical-selections-reconstructed.json').write_text(json.dumps(d,indent=2)+'\n')
d={'kind':'Exact original records, reconstructed catalogue and separately attributed prior assessments','registry_uncompressed_sha256':h(rraw),'records':records,'qualification':'Physical-p16 is a dirty a120-based snapshot; a later independently reproduced tracked diff matches the recorded hash, with seven untracked objects separately archived. Distinct pr-working snapshot is 6533-based and dirty. Do not transfer source roles, revision, read attribution, or promote to missing checkpoint3821.'}
(b/'historical-manifest.json').write_text(json.dumps(d,indent=2)+'\n')
a=(b/'source/2728-physical-p16.rs').read_text().splitlines(keepends=True);c=(b/'source/2728-95e6.rs').read_text().splitlines(keepends=True)
(b/'2728-old-current.diff').write_text(''.join(difflib.unified_diff(a,c,fromfile='physical-p16 archived object',tofile='95e current source')))
print('historical_records',len(records),'historical_manifest_sha256',h((b/'historical-manifest.json').read_bytes()),'diff_sha256',h((b/'2728-old-current.diff').read_bytes()))
