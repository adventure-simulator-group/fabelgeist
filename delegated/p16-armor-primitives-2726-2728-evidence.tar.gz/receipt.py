from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
r=load('registration.json');s=load('support-registration.json')
part={
 2726:([[1,99]],[[100,150]],[[1,150]]),
 2727:([[1,56]],[],[[1,56]]),
 2728:([[1,22],[33,66]],[[23,32],[67,166]],[[1,88],[89,166]])
}
currentchunks={2726:[[1,150]],2727:[[1,56]],2728:[[1,94],[95,183]]}
assigned=[]
for x in r['rows']:
 i=x['original_index']; old,cur=x['versions'];a,c,ch=part[i]
 assigned.append(dict(original_index=i,source_id=x['source_id'],identity=old['identity'],revision=None,sha256=old['sha256'],local=old['local'],eof=old['eof'],actual_display_chunks=ch,original_assigned_displays=a,separately_registered_context_displays=c,unread_complement=[]))
 assigned.append(dict(original_index=i,source_id=x['source_id'],identity='pinned current source',revision=cur['revision'],sha256=cur['sha256'],local=cur['local'],eof=cur['eof'],actual_display_chunks=currentchunks[i],original_assigned_displays=[],separately_registered_context_displays=currentchunks[i],unread_complement=[]))
supports=[]
for x in s['entries']:
 ranges=x['planned_display_ranges'];n=x['eof'];used={k for a,z in ranges for k in range(a,z+1)}
 missing=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):missing.append([start,i-1]);start=None
 supports.append(dict(path=x['path'],revision=x['revision'],identity=x['identity'],local=x['local'],sha256=x['sha256'],eof=n,displayed=ranges,unread_complement=missing,registration='support-registration.json',ordered_role_credit=0))
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','method':'Newly reconstructed receipt of actual bounded line-numbered source displays after prospective registrations; no execution. Source archive bytes alone do not establish personal reads.','registrations':[{'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']} for n in ['registration.json','support-registration.json']],'assigned':assigned,'support':supports,'prior_disclosure':r['prior_read_disclosure'],'qualification':'Old assigned material and separate historical context partition archived body; full current displays use current line positions and are not historical role credit. P16, pr-working, 6533, 95e and reviewers remain distinct.','runtime_validation':'None; no product, GPU, geometry, fixture, tests, builds, macro execution, probes or repairs.'}
(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt',h((b/'read-receipt.json').read_bytes()),d['created_utc'])
