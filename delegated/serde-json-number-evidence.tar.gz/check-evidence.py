import datetime,gzip,hashlib,io,json,pathlib,tarfile,tomllib
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());ns=json.loads((p/'native-support-registration.json').read_text());ps=json.loads((p/'project-support-registration.json').read_text());rec=json.loads((p/'read-receipt.json').read_text());sr=json.loads((p/'support-read-receipt.json').read_text());assert H((p/'registration.json').read_bytes())==rec['registration_sha256']
for x in sr['registrations']:assert H((p/x['file']).read_bytes())==x['sha256']
prior=json.loads((p/'prior-references.json').read_text());manifests={}
for label,x in prior['packets'].items():
 b=(p/x['manifest_copy']).read_bytes();assert H(b)==x['manifest_sha256'];manifests[label]={z['path']:z for z in json.loads(b)['files']}
for x in prior['references']:
 b=pathlib.Path(x['original_path']).read_bytes();e=manifests[x['packet']][x['manifest_path']];assert (len(b),H(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256'])
for n in ['REPORT.json','read-receipt.json']:
 b=(p/'prior-hair'/n).read_bytes();assert (len(b),H(b))==(manifests['hair'][n]['bytes'],manifests['hair'][n]['sha256'])
for x in prior['published_objects']:
 b=pathlib.Path(x['path']).read_bytes();assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
pkg=(p/reg['package_archive']['path']).read_bytes();assert H(pkg)==reg['package_archive']['sha256']=='c841b55ecdae098c80dcae9cf767f6f8a0c2cdb3416bbef72181df4d0fe73f14';core=pathlib.Path(ns['package_archive_reference']['path']).read_bytes();assert H(core)==ns['package_archive_reference']['sha256']=='67dca2c9c51e58a4791a4b1ed58308b39c64224d349a935ab5039aa360942a48';assert next(x['sha256'] for x in prior['published_objects'] if 'serde_json-' in x['git_path'])==H(pkg)
for package,rows in [(pkg,reg['sources']),(core,ns['sources'])]:
 with tarfile.open(fileobj=io.BytesIO(package),mode='r:gz') as t:
  for x in rows:
   b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b))==(x['bytes'],x['lines'],x['sha256']);assert t.extractfile(x['package_member']).read()==b
saphyr=pathlib.Path(prior['packets']['saphyr']['path']);lock=(saphyr/'source/current-Cargo.lock').read_bytes();assert H(lock)==reg['current_lock_reference']['sha256']==ns['current_lock_reference']['sha256'];l=tomllib.loads(lock.decode())
for name,version,expected in [('serde_json','1.0.151',H(pkg)),('serde_core','1.0.229',H(core))]:
 m=[x for x in l['package'] if x.get('name')==name and x.get('version')==version];assert len(m)==1 and m[0]['checksum']==expected
lookup={}
for x in ps['sources']:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1']);lookup[x['revision'],x['path']]=x
def check(x,n):
 rr=x['actual_display_union'];un=x['unread_ranges'];assert all(1<=a<=b<=n for a,b in rr+un);read={i for a,b in rr for i in range(a,b+1)};missing={i for a,b in un for i in range(a,b+1)};assert not read&missing and read|missing==set(range(1,n+1));assert x['full_body_displayed']==(not missing)
displays={}
for x in rec['reads']:
 if x['kind']=='current-lock':y=reg['current_lock_reference'];key=('current-lock',x['revision'],x['path']);expected=sorted(reg['current_lock_reference']['planned_display']+ns['current_lock_reference']['planned_display'])
 else:y=next(z for z in reg['sources'] if z['original_role']==x['original_role']);key=('native-package','serde_json',y['package_member'].split('serde_json-1.0.151/')[1]);expected=y['planned_display']
 check(x,y['lines']);assert x['actual_display_union']==expected;displays[key]=x['actual_display_union']
for x in sr['reads']:
 if x['kind']=='native-package-support':y=ns['sources'][0];key=('native-package','serde_core',y['package_member'].split('serde_core-1.0.229/')[1])
 else:y=lookup[x['revision'],x['path']];key=('current-project',x['revision'],x['path'])
 check(x,y['lines']);assert x['actual_display_union']==y['planned_display'];displays[key]=x['actual_display_union']
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
def verify_proofs(root,proof,only=None):
 objects={}
 for oid,x in proof['objects'].items():
  b=gzip.decompress((root/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
 n=0
 for x in proof['proofs']:
  if only and not only(x):continue
  tree=objects[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['commit_tree']
  for e in x['chain']:
   assert e['tree']==tree and entries(objects[tree])[e['name']]==(e['mode'],e['object']);tree=e['object']
  b=(root/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert tree==x['blob']==O('blob',b) and H(b)==x['sha256'];n+=1
 return n,len(objects)
proof=json.loads((p/'git-proofs.json').read_text());nproof,nobjects=verify_proofs(p,proof);prevproof=json.loads((saphyr/'git-proofs.json').read_text());nprev,_=verify_proofs(saphyr,prevproof,lambda x:x['kind']=='current-lock' and x['revision']==reg['current_lock_reference']['revision'] and x['path']=='Cargo.lock');assert nprev==1
report=json.loads((p/'report.json').read_text());refs=0
for a in report['assessments']:
 for x in a['source_refs']:
  key=('native-package',x['package'],x['path']) if x['source_kind']=='native-package' else (x['source_kind'],x['revision'],x['path']);rr=displays[key]
  for start,end in x['lines']:assert any(c<=start<=end<=d for c,d in rr),(key,start,end,rr);refs+=1
with gzip.open(saphyr/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((saphyr/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
r=json.load(gzip.open(saphyr/'reference/original-registry.json.gz','rt'))
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']:assert x['entry']==r['files'][x['index']]
for x in reg['sources']:assert x['original_registry_entry']==r['files'][x['original_role']] and x['registry_snapshot']=='pinned-cargo'
assert ns['sources'][0]['sha256']==r['files'][2588]['sha256']
old774=json.loads((p/'historical-774-index.json').read_text())
for x in old774['records']:
 b=gzip.decompress((p/x['copy']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
cat=pathlib.Path(prior['packets']['catalog']['path']);hq=json.loads((cat/'historical-774-index.json').read_text())['hash_qualifications'];assert hq['root046_rig_registration_expected']!=hq['later_first35_sha256'] and not hq['registration_prefix_matches'] and hq['root046_qualification_expected']==hq['later_first31_qualification_sha256'] and hq['qualification_prefix_matches']
l11=json.loads((p/'historical-059/segovb/READ-L11-425.json').read_text());l12a=json.loads((p/'historical-059/segovb/READ-L12-879.json').read_text());l12b=json.loads((p/'historical-059/segovb/READ-L12-880.json').read_text());assert not l12a['root_personal_rereads'] and not l12b['root_personal_rereads']
for i,rg,l11rg,d,l12rg in [(2589,1500,[[169,193],[313,313]],l12a,[[169,194],[310,314]]),(2590,1501,[[535,580],[582,600],[602,618]],l12b,[[535,580],[582,619]])]:
 x=next(z for z in l11['sources'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==l11rg and H((p/f'historical-059/segovb/REGISTRATION-SEGOVB-{rg}.json').read_bytes())==x['registration_sha256'];x=next(z for z in d['rows'] if z.get('original_index')==i);assert x['fresh_personal_body_reads']==l12rg and H((p/'historical-059'/x['registration']).read_bytes())==x['registration_sha256'] and H((p/'historical-059'/x['identity_specific_windows_qualification']['path']).read_bytes())==x['identity_specific_windows_qualification']['sha256']
for d,n in [(l12a,'879'),(l12b,'880')]:assert H((p/f'historical-059/parallel-l12-20261029/PROPOSAL-L12-{n}.json').read_bytes())==d['proposal_sha256']
auth=json.loads((p/'historical-059/parallel-l12-20261029/READ-CONNECTED-PAR-L12-879-SERDE-LOCK-AUTHORITY.json').read_text())
for x in auth['rows']:
 assert H((p/'historical-059'/x['registration']).read_bytes())==x['registration_sha256'];b=gzip.decompress((saphyr/f"historical-059/lock-{x['original_index']}.source.gz").read_bytes());assert H(b)==x['source_sha256'];pkgs=tomllib.loads(b.decode())['package']
 for name,version,expected in [('serde_json','1.0.151',H(pkg)),('serde_core','1.0.229',H(core))]:assert next(z['checksum'] for z in pkgs if z.get('name')==name and z.get('version')==version)==expected
patch=next(x for x in prior['published_objects'] if x['git_path'].endswith('tracked.patch'));assert patch['sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7' and patch['bytes']==524542;assert len(report['perspectives'])==13
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','serde_json_archive_sha256':H(pkg),'serde_core_archive_sha256':H(core),'assigned_members':len(reg['sources']),'support_native_members':len(ns['sources']),'current_support_objects':len(ps['sources']),'git_path_proofs':nproof,'raw_git_objects':nobjects,'linked_current_lock_proofs':nprev,'source_reference_ranges_within_personal_displays':refs,'original_059_exact_records':len(hist['records']),'older_774_exact_transport_records':len(old774['records']),'rig_046_registration_prefix_match':False,'rig_046_qualification_prefix_match':True,'qualification':'Hash-linked prior packets and published objects must be retained. Evidence verification only, no product/decoder execution. Historical rig registry pin remains unmatched in bounded search.'};print(json.dumps(result,indent=2))
