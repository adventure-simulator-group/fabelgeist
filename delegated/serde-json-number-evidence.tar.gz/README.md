# Bounded serde_json numeric dispatch assessment

`report.json` assesses original native roles 2589–2590 at serde_json 1.0.151,
with independently registered serde_core and current 95e catalog support. The
normal owned-Value path sends an f64 to an f32 visitor without field-specific
finite or positive validation. The current catalog source checks f64 physical
values before a discarded f32 typed preflight; the related narrowing condition
is a source-only continuation of historical and independently assessed
findings. Actual feature selection, runtime parsing and downstream outcomes
remain open. No issue count or automatic alias is assigned.

The serde_json archive is preserved here and also hash-linked to published
native evidence. The serde_core archive, recovered tracked P16 patch, and the
original registry/transport/queue and earlier reviewer packets are hash-linked
in `prior-references.json`; retain or map those dependencies when recovering
this packet. The earlier hair-ops patch reproduction and the later saved patch
retain their different timestamps and attribution. The tracked patch does not
cover the seven separately recovered untracked files and its historical command
is not proven.

Actual personal ranges and their unread complements are in the two receipts.
The original roles record `pinned-cargo`, not a project Git revision. f82 and
0083173b are evidence transports. Root046's rig registration mismatch, its
matching qualification prefix and bounded recovery search are retained via the
prior catalog packet; no later bytes are substituted for the earlier pin.

Run `python3 check-evidence.py` and `python3 verify-freeze.py` for source,
archive, Git path and packet integrity. The first requires the linked prior
packets and published evidence. No product, parser, build, test, fixture,
rendering, runtime probe or repair is performed.
