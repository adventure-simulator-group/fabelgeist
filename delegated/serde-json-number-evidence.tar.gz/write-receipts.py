import datetime,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();reg=json.loads((p/'registration.json').read_text());ns=json.loads((p/'native-support-registration.json').read_text());ps=json.loads((p/'project-support-registration.json').read_text())
def comp(rr,n):
 k=1;o=[]
 for a,b in rr:
  if k<a:o.append([k,a-1])
  k=b+1
 if k<=n:o.append([k,n])
 return o
reads=[]
for x in reg['sources']:
 rr=x['planned_display'];reads.append({'kind':'native-package','original_role':x['original_role'],'path':x['package_member'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':comp(rr,x['lines']),'full_body_displayed':False})
lock=reg['current_lock_reference'];rr=sorted(lock['planned_display']+ns['current_lock_reference']['planned_display']);reads.append({'kind':'current-lock','revision':lock['revision'],'path':'Cargo.lock','archive_reference':lock['path'],'actual_display_union':rr,'unread_ranges':comp(rr,lock['lines']),'full_body_displayed':False,'qualification':'Only two matching package stanzas personally displayed, from prior frozen lock bytes.'})
(p/'read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':h((p/'registration.json').read_bytes()),'reads':reads},indent=2)+'\n');support=[]
for x in ns['sources']:
 rr=x['planned_display'];support.append({'kind':'native-package-support','path':x['package_member'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':comp(rr,x['lines']),'full_body_displayed':False,'qualification':'Independently registered support, not ordered role credit; earlier hair_ops scope separately attributed.'})
for x in ps['sources']:
 rr=x['planned_display'];support.append({'kind':'current-project','revision':x['revision'],'path':x['path'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':comp(rr,x['lines']),'full_body_displayed':False})
(p/'support-read-receipt.json').write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'file':n,'sha256':h((p/n).read_bytes())} for n in ['native-support-registration.json','project-support-registration.json']],'reads':support},indent=2)+'\n');print('assigned',[(x['original_role'],x['actual_display_union'],x['unread_ranges']) for x in reads if 'original_role'in x],'support',len(support))
