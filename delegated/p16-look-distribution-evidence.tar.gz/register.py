import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>')
repo='<LOCAL_PATH_1>'
origin=pathlib.Path('<LOCAL_PATH_2>')
r=json.load(gzip.open('<LOCAL_PATH_3>','rt'))
i=2559; e=r['files'][i]; snap=r['snapshots'][3]; H='a120390947c89b703dc74c4255a13c035d054c50'; C='95e63628f9d70b8dd6e6fede64334696c6995009'; path='crates/adventuresim-tactical-client/src/animation/procedural.rs'
assert snap['head']==H
b=(origin/e['sha256']).read_bytes(); assert hashlib.sha256(b).hexdigest()==e['sha256'] and len(b)==e['bytes']
g=subprocess.run(['git','-C',repo,'show',f'{H}:{path}'],capture_output=True);base_equal=g.returncode==0 and g.stdout==b
rows=[]
for kind,revision,data in [('physical-p16',H,b),('current',C,None)]:
 if data is None: data=subprocess.check_output(['git','-C',repo,'show',f'{revision}:{path}'])
 n=len(data.splitlines()); dst=p/f'source/{kind}-{i}.source';dst.write_bytes(data)
 spans=[[1,min(260,n)],[620,min(760,n)]]
 rows.append({'original_role':i,'kind':kind,'revision':revision,'revision_qualification':'Recorded P16 dirty snapshot, base HEAD only; per-file equality does not establish whole-snapshot identity.' if kind=='physical-p16' else 'Pinned current source','path':path,'archive':str(dst.relative_to(p)),'bytes':len(data),'lines':n,'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'base_path_bytes_equal':base_equal if kind=='physical-p16' else None,'original_extracted_object':str(origin/e['sha256']) if kind=='physical-p16' else None,'planned_display_ranges':spans})
(p/'registration.json').write_text(json.dumps({'schema':'726-prospective-source-registration-v1','agent':'/root/mhr_character','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Role 2559 registered bounded production and look-distribution/consumer windows before personal display; full body copied solely as hash-verifiable evidence, not full read credit. Historical scopes retain attribution.','original_registry_entry':e,'historical_snapshot':snap,'qualification':'P16 is dirty and not the clean base, f82 is archive transport, recorded patch remains unrecovered.','sources':rows,'constraints':'No product execution, viewer, tests, builds, fixtures, simulations, probes, repairs or product/publication edits.'},indent=2)+'\n')
print([(x['kind'],x['bytes'],x['lines'],x['sha256'],x['base_path_bytes_equal'],x['planned_display_ranges']) for x in rows])
