import datetime,difflib,gzip,hashlib,json,pathlib,re,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';reg=json.loads((p/'registration.json').read_text());all_support=[]
for n in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json']:
 all_support += [x for x in json.loads((p/n).read_text())['sources'] if x['kind']=='current-support']
old=reg['sources'][0];current=reg['sources'][1];F='f82adcabd9d89c4fa2dd7f99253a45297a0681ee';R='6533e444fa37552927070cc8d8190907fd3b413e';arch={'kind':'archive-transport-only','revision':F,'path':'handoff/774/audit/reconcile-adler-20261023/recovered-sources/objects/'+old['sha256'],'archive':old['archive'],'sha256':old['sha256'],'git_blob_sha1':old['git_blob_sha1']};pr={'kind':'pr-working-identical-per-file','revision':R,'path':old['path'],'archive':old['archive'],'sha256':old['sha256'],'git_blob_sha1':old['git_blob_sha1']};hist=json.loads((p/'historical-774-index.json').read_text())['records']; historical=[{'kind':'historical-record-transport-only','revision':x['git_transport_revision'],'path':x['git_transport_path'],'archive':x['copy'],'sha256':x['sha256'],'git_blob_sha1':x['git_blob_sha1'],'encoding':'gzip'} for x in hist]; bridge={'kind':'059-l11-recorded-git-provenance-per-file','revision':'039329518e264f19206cf5b0b98d177433f40c17','path':old['path'],'archive':old['archive'],'sha256':old['sha256'],'git_blob_sha1':old['git_blob_sha1']}; records=reg['sources']+all_support+[arch,pr,bridge]+historical;d=p/'git-objects';d.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dst=d/(oid+'.'+t+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dst.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 commit=get('commit',x['revision']);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x.get('encoding')=='gzip' else b
 assert tree==x['git_blob_sha1'] and hashlib.sha256(b).hexdigest()==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'kind':x['kind'],'revision':x['revision'],'path':x['path'],'archive':x['archive'],'encoding':x.get('encoding','raw'),'commit_tree':root,'chain':chain,'blob':tree,'sha256':x['sha256']})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw commit/tree objects prove exact path membership. f82 is evidence archive transport, not source commit; a120 is recorded dirty-snapshot base; 6533 match applies only to this file.','objects':objects,'proofs':proof},indent=2)+'\n')
a=(p/old['archive']).read_text().splitlines();b=(p/current['archive']).read_text().splitlines();delta=[]
for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
 if tag!='equal':delta.append({'tag':tag,'old_range':[i+1,j],'current_range':[k+1,l]})
(p/'comparison-metadata.json').write_text(json.dumps({'method':'Whole-object line equality navigation only, no source-body display credit; all differing ranges were independently registered and personally displayed.','old_sha256':old['sha256'],'current_sha256':current['sha256'],'opcodes':delta},indent=2)+'\n')
def complement(rr,n):
 out=[];k=1
 for a,b in rr:
  if k<a:out.append([k,a-1])
  k=b+1
 if k<=n:out.append([k,n])
 return out
reads=[]
for x in reg['sources']:
 rr=[[1,260],[535,760]];reads.append({'role':2559,'kind':x['kind'],'revision':x['revision'],'path':x['path'],'archive':x['archive'],'actual_display_ranges':[[1,130],[131,260],[535,565],[566,619],[620,760]],'actual_display_union':rr,'unread_ranges':complement(rr,x['lines']),'full_body_displayed':False,'qualifications':'Additional 535–565 and 566–619 were prospectively registered separately; role material remains 157–230 and 669–716. Archived full object and metadata comparison do not imply full reading.'})
(p/'read-receipt.json').write_text(json.dumps({'schema':'726-assigned-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'file':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in ['registration.json','support-registration.json','support-registration-03.json']],'reads':reads},indent=2)+'\n')
windows={0:[[1,60],[115,146],[160,180]],1:[[1,66]],2:[[1,110]],3:[[125,150]],4:[[450,475]],5:[[610,665]],6:[[25,55]],7:[[55,100]],8:[[175,235],[1080,1182],[1365,1425]],9:[[85,107]],10:[[1,25],[80,111]]};nav={str(i):[] for i in range(11)}
for n in ['navigation.txt','navigation-02.txt','navigation-03.txt','navigation-04.txt']:
 for line in (p/n).read_text().splitlines():
  m=re.match(r'.*support-(\d+)\.source:(\d+):',line)
  if m:nav[str(int(m.group(1)))].append(int(m.group(2)))
reads=[]
for i,x in enumerate(all_support):
 spans=sorted(windows[i]+[[n,n] for n in nav[str(i)]]);rr=[]
 for a,b in spans:
  if rr and a<=rr[-1][1]+1:rr[-1][1]=max(b,rr[-1][1])
  else:rr.append([a,b])
 assert all(1<=a<=b<=x['lines'] for a,b in rr)
 reads.append({'kind':'current-support','path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':rr,'unread_ranges':complement(rr,x['lines']),'full_body_displayed':rr==[[1,x['lines']]],'qualification':'Direct bounded display plus singleton navigation exposures only. Source-only test lines in navigation are not executed and are not full test body reads.'})
(p/'navigation-exposures.json').write_text(json.dumps({'lines_by_support_index':nav,'qualification':'Exact matching lines exposed by post-registration navigation; only singleton read exposure, including any test lines.'},indent=2)+'\n')
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registrations':[{'file':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in ['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json']],'reads':reads},indent=2)+'\n');print('proofs',len(proof),'raw objects',len(objects),'assigned',len(reg['sources']),'support',len(reads),'diff metadata',delta)
