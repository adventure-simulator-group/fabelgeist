import datetime,gzip,hashlib,json,pathlib,shutil,subprocess
p=pathlib.Path('<LOCAL_PATH_0>'); original=pathlib.Path('<LOCAL_PATH_1>'); prior=pathlib.Path('<LOCAL_PATH_2>'); reference=p/'reference';reference.mkdir(exist_ok=True); h=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(); repo='<LOCAL_PATH_3>';F='f82adcabd9d89c4fa2dd7f99253a45297a0681ee'
for n in ['original-registry.json.gz','original-transport-manifest.json.gz','059-queue-original-bytes.json.gz','AGENTS.md','crates/AGENTS.md']:
 d=reference/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(prior/'reference'/n,d)
f=pathlib.Path('<LOCAL_PATH_4>');d=reference/'crates/adventuresim-tactical-client/src/animation/AGENTS.md';d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,d)
t={x['path']:x for x in json.load(gzip.open(reference/'original-transport-manifest.json.gz','rt'))['entries']}
names=['segovb/READ-L11-421.json','segovb/REGISTRATION-SEGOVB-1465.json','adler/READ-L11-185.json','adler/REGISTRATION-ADLER-171.json','segovb/READ-L12-868.json','parallel-l12-20261029/PROPOSAL-L12-868.json','parallel-l12-20261029/PARTIAL-PAR-L12-868-001.json','parallel-l12-20261029/REGISTRATION-PAR-L12-604.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-604-WINDOWS-ORIGINAL2559.json','parallel-l12-20261029/PROPOSAL-BUNDLE-PAR-L12-865-872.json']; records=[];missing=[]
for n in names:
 if n not in t or not (original/n).is_file():missing.append(n);continue
 b=(original/n).read_bytes();e=t[n];assert (len(b),h(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']),n
 d=p/'historical-059'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);records.append({'original_path':n,'copy':str(d.relative_to(p)),'bytes':len(b),'sha256':h(b),'git_blob':blob(b)})
(p/'historical-059-index.json').write_text(json.dumps({'records':records,'unavailable':missing,'qualification':'Exact original transport bytes and hashes, original attribution and revision remain; no checkpoint3821 credit.'},indent=2)+'\n')
q=json.load(gzip.open(reference/'059-queue-original-bytes.json.gz','rt'));(p/'historical-queue-selected.json').write_text(json.dumps({'qualification':'Verbatim entry copies under exact original indices, not new review credit or alias.', 'entries':[{'index':i,'entry':q['entries'][i]} for i in [39,45,1151,2131]]},indent=2)+'\n')
r=json.load(gzip.open(reference/'original-registry.json.gz','rt'));(p/'historical-registry-selected.json').write_text(json.dumps({'qualification':'Original registry identities, metadata roles, distinct ranges; never P16 whole-snapshot proof.','roles':[{'index':i,'entry':r['files'][i]} for i in [1356,2559]]},indent=2)+'\n')
old=pathlib.Path('<LOCAL_PATH_5>'); older=['root/owner-definition-producer-authority-036.json']+['camera/owner-definition-producer-fixedpoint/'+n for n in ['additional-sources.jsonl','completion-001.json','completion-002.json','coverage.jsonl','findings-supplement-002.json','findings.jsonl','progress.jsonl','qualification-supplement-002.json','source-range-registration.jsonl','traces.jsonl']]+['camera/admission03/contracts.jsonl','camera/admission03/coverage.jsonl'];oldrows=[]
for n in older:
 b=(old/n).read_bytes();gitpath='handoff/774/adler-original/audit/continuation/'+n;g=subprocess.check_output(['git','-C',repo,'show',F+':'+gitpath]);assert g==b,n
 d=p/('historical-774/'+n+'.gz');d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(gzip.compress(b,mtime=0));oldrows.append({'original_local_path':str(old/n),'git_transport_revision':F,'git_transport_path':gitpath,'copy':str(d.relative_to(p)),'encoding':'gzip','bytes':len(b),'sha256':h(b),'git_blob_sha1':blob(b),'qualification':'Exact recovered 774 record bytes and f82 archive path; f82 transports evidence and is not the P16 source revision.'})
comp=json.loads(gzip.decompress((p/'historical-774/camera/owner-definition-producer-fixedpoint/completion-002.json.gz').read_bytes()))
for n,sha in comp['files'].items():
 b=gzip.decompress((p/('historical-774/camera/owner-definition-producer-fixedpoint/'+n+'.gz')).read_bytes());assert h(b)==sha,n
(p/'historical-774-index.json').write_text(json.dumps({'records':oldrows,'completion_002_hash_pins_verified':len(comp['files']),'qualification':'Historical supplier records, qualification and root authority retain their original status. Admission03 row843 is a separately attributed actual historical read. No automatic canonical alias or checkpoint3821 promotion.'},indent=2)+'\n')
refs=[]
for name,which in [('body-values-sample-rate','<LOCAL_PATH_6>'),('animation','<LOCAL_PATH_7>'),('body-target-hair-ops','<LOCAL_PATH_8>')]:
 root=pathlib.Path(which);manifest=root/('packet-manifest.json' if name=='body-target-hair-ops' else 'BUNDLE-MANIFEST.json'); report=root/'report.json';n=p/'prior-records'/name;n.mkdir(parents=True,exist_ok=True)
 for f in [manifest,report]:shutil.copyfile(f,n/f.name)
 refs.append({'name':name,'original_packet':str(root),'manifest_path':str(manifest),'manifest_sha256':h(manifest.read_bytes()),'report_sha256':h(report.read_bytes()),'copied_manifest':str((n/manifest.name).relative_to(p)),'copied_report':str((n/report.name).relative_to(p)),'qualification':'Referenced prior assessment retains original reviewer/scope/revision; no transferred personal read or automatic aliases.'})
(p/'prior-references.json').write_text(json.dumps({'references':refs},indent=2)+'\n');print('059 records',len(records),'missing',missing,'774 exact',len(oldrows),'completion pins',len(comp['files']),'prior links',len(refs))
