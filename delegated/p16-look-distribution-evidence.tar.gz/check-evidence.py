import datetime,difflib,gzip,hashlib,json,pathlib
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest();reg=json.loads((p/'registration.json').read_text());ns=['support-registration.json','support-registration-02.json','support-registration-03.json','support-registration-04.json'];sup=[x for n in ns for x in json.loads((p/n).read_text())['sources'] if x['kind']=='current-support'];rec=json.loads((p/'read-receipt.json').read_text());sr=json.loads((p/'support-read-receipt.json').read_text());
for z in rec['registrations']+sr['registrations']:assert H((p/z['file']).read_bytes())==z['sha256']
allsource=reg['sources']+sup;sources={(x['revision'],x['path']):x for x in allsource};displays={}
for x in rec['reads']+sr['reads']:
 y=sources[x['revision'],x['path']];rr=x['actual_display_union'];un=x['unread_ranges'];assert all(1<=a<=b<=y['lines'] for a,b in rr+un);coverage={i for a,b in rr for i in range(a,b+1)};missing={i for a,b in un for i in range(a,b+1)};assert not coverage.intersection(missing) and coverage|missing==set(range(1,y['lines']+1));assert x['full_body_displayed']==(not missing);displays[x['revision'],x['path']]=rr
for x in allsource:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1'])
proof=json.loads((p/'git-proofs.json').read_text());objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in proof['proofs']:
 root=objects[x['revision']].splitlines()[0].split()[1].decode();assert root==x['commit_tree'];tree=root
 for e in x['chain']:
  assert e['tree']==tree and entries(objects[tree])[e['name']]==(e['mode'],e['object']);tree=e['object']
 b=(p/x['archive']).read_bytes();b=gzip.decompress(b) if x['encoding']=='gzip' else b;assert tree==x['blob']==O('blob',b) and H(b)==x['sha256']
 if x['kind'] in ['physical-p16','current','current-support']:assert tree==sources[x['revision'],x['path']]['git_blob_sha1']
report=json.loads((p/'report.json').read_text());refs=0
for f in report['findings_and_questions']:
 for ref in f['source_refs']:
  rr=displays[ref['revision'],ref['path']]
  for a,b in ref['lines']:assert any(c<=a<=b<=d for c,d in rr),(ref,a,b,rr);refs+=1
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((p/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
r=json.load(gzip.open(p/'reference/original-registry.json.gz','rt'));assert r['snapshots'][3]==reg['historical_snapshot'];assert r['snapshots'][3]['head']=='a120390947c89b703dc74c4255a13c035d054c50';assert r['snapshots'][3]['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7'
for x in json.loads((p/'historical-registry-selected.json').read_text())['roles']:assert x['entry']==r['files'][x['index']]
old,current=reg['sources'];assert old['sha256']==r['files'][2559]['sha256'] and old['base_path_bytes_equal'] and old['sha256']!=current['sha256'];a=(p/old['archive']).read_text().splitlines();b=(p/current['archive']).read_text().splitlines();assert len(a)==len(b)==1813
for start,end in [[157,230],[669,716]]:assert a[start-1:end]==b[start-1:end]
delta=[{'tag':t,'old_range':[i+1,j],'current_range':[k+1,l]} for t,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if t!='equal'];assert delta==json.loads((p/'comparison-metadata.json').read_text())['opcodes']
old774=json.loads((p/'historical-774-index.json').read_text())['records']
for x in old774:
 b=gzip.decompress((p/x['copy']).read_bytes());assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob_sha1'])
cp=json.loads(gzip.decompress((p/'historical-774/camera/owner-definition-producer-fixedpoint/completion-002.json.gz').read_bytes()))
for n,sha in cp['files'].items():assert H(gzip.decompress((p/('historical-774/camera/owner-definition-producer-fixedpoint/'+n+'.gz')).read_bytes()))==sha
l11=json.loads((p/'historical-059/segovb/READ-L11-421.json').read_text());x=next(z for z in l11['sources'] if z.get('original_index')==2559);assert x['fresh_personal_body_reads']==[[157,230],[669,716]] and x['sha256']==old['sha256'];assert H((p/'historical-059/segovb/REGISTRATION-SEGOVB-1465.json').read_bytes())==x['registration_sha256']; prior=x['same_lens_prior'];assert H((p/'historical-059/adler/READ-L11-185.json').read_bytes())==prior['receipt_sha256'];assert H((p/'historical-059/adler/REGISTRATION-ADLER-171.json').read_bytes())==prior['entry']['registration_sha256']
registration=json.loads((p/'historical-059/segovb/REGISTRATION-SEGOVB-1465.json').read_text());assert '039329518e264f19206cf5b0b98d177433f40c17' in registration['provenance'];l12=json.loads((p/'historical-059/segovb/READ-L12-868.json').read_text());row=next(z for z in l12['rows'] if z.get('original_index')==2559);assert row['fresh_personal_body_reads']==[[157,230],[669,716]] and not l12['root_personal_rereads'];assert H((p/'historical-059/parallel-l12-20261029/REGISTRATION-PAR-L12-604.json').read_bytes())==row['registration_sha256'];assert H((p/'historical-059/parallel-l12-20261029/QUALIFICATION-PAR-L12-604-WINDOWS-ORIGINAL2559.json').read_bytes())==row['identity_specific_windows_qualification']['sha256'];assert H((p/'historical-059/parallel-l12-20261029/PROPOSAL-L12-868.json').read_bytes())==l12['proposal_sha256']
for x in json.loads((p/'prior-references.json').read_text())['references']:
 assert H((p/x['copied_manifest']).read_bytes())==x['manifest_sha256'] and H((p/x['copied_report']).read_bytes())==x['report_sha256']; manifest=json.loads((p/x['copied_manifest']).read_text()); assert next(z['sha256'] for z in manifest['files'] if z['path']=='report.json')==x['report_sha256']
assert len(report['perspectives'])==13
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','assigned_source_revision_bodies':len(reg['sources']),'support_source_archives':len(sup),'git_membership_proofs':len(proof['proofs']),'raw_git_commit_tree_objects':len(objects),'finding_source_ranges_inside_actual_display':refs,'original_059_records':len(hist['records']),'selected_queue_entries':len(json.loads((p/'historical-queue-selected.json').read_text())['entries']),'older_774_exact_archive_records':len(old774),'completion_002_pins':len(cp['files']),'qualified_unread_assigned_ranges':[[261,534],[761,1813]],'qualification':'Evidence hashing, JSON/gzip parsing and raw Git path verification only. Recorded P16 patch hash not verified against patch bytes; no product execution, test or validation.'};print(json.dumps(result,indent=2))
