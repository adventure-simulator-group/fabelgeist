# P16 role 2559: bounded look-propagation assessment

The source audit and evidence qualification are in `report.json`. Original
role material is historical P16 lines 157–230 and 669–716. The independently
registered old and current bodies were personally displayed only at 1–260 and
535–760. Lines 261–534 and 761–1813 remain unread in this assessment. Full
archived bytes and machine comparison do not grant read coverage.

The 774 original registration, raw semantic look-pair finding, superseding
qualification, completion pins and separate admission assessment are preserved
as compressed exact records. The 059 L11 and L12 receipts retain their actual
reviewers, registration, provenance and windows. Historical evidence remains
at its recorded revision; none is checkpoint 3821 credit. P16 is a dirty
snapshot, `a120` is its recorded base, `f82` is archive transport and its full
patch bytes are unrecovered.

`registration.json` and `support-registration*.json` precede source displays;
`read-receipt.json`, `support-read-receipt.json` and
`navigation-exposures.json` delimit actual views. `git-proofs.json` and
`git-objects/` prove individual recorded object paths. `prior-references.json`
hash-links separately authored prior packets; it does not transfer their reads.

For evidence integrity only, run:

```sh
python3 check-evidence.py
python3 verify-freeze.py
```

Both verifiers are read-only after freeze. Neither invokes product code,
fixtures, tests, builds, simulations, or runtime validation.
