import datetime,gzip,hashlib,json,pathlib,shutil
p=pathlib.Path('<LOCAL_PATH_0>');orig=pathlib.Path('<LOCAL_PATH_1>');base=pathlib.Path('<LOCAL_PATH_2>'); h=lambda b:hashlib.sha256(b).hexdigest(); blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
refs=p/'reference';refs.mkdir(exist_ok=True)
for f in ['059-queue-original-bytes.json.gz','original-transport-manifest.json.gz','original-registry.json.gz']:shutil.copyfile(base/'historical-inputs'/f,refs/f)
trans={x['path']:x for x in json.load(gzip.open(refs/'original-transport-manifest.json.gz','rt'))['entries']}; names=[]
for i in [381,382]:
 for t in ['READ','STATE','VERIFY']:names.append(f'adler/{t}-L11-{i}.json')
for i in [1231,1237]:names.append(f'adler/REGISTRATION-ADLER-{i}.json')
for i in [781,783]:
 for t in ['READ','STATE','VERIFY','REGISTRATION']:names.append(f'segovb/{t}-L12-{i}.json' if t!='REGISTRATION' else f'segovb/REGISTRATION-SEGOVB-L12-{i}.json')
 names.append(f'parallel-l12-20261029/PROPOSAL-L12-{i}.json')
for i in [345,351]:names.append(f'parallel-l12-20261029/REGISTRATION-PAR-L12-{i}.json')
for name in ['parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-779-781.json','parallel-l12-20261029/ADOPTION-MANIFEST-PAR-L12-782-786.json','parallel-l12-20261029/QUALIFICATION-PAR-L12-769-779-AUDIT-ONLY-HEADERS.json']:
 if name in trans:names.append(name)
rows=[];missing=[]
for n in names:
 if n not in trans or not (orig/n).is_file():missing.append(n);continue
 b=(orig/n).read_bytes();e=trans[n];assert (len(b),h(b),blob(b))==(e['bytes'],e['sha256'],e['git_blob']),n
 dest=p/'historical-059'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append({'original_path':n,'copy':str(dest.relative_to(p)),'bytes':len(b),'sha256':h(b),'git_blob':blob(b)})
q=json.load(gzip.open(refs/'059-queue-original-bytes.json.gz','rt'));inds=[183,184,187,210,242,*range(466,476),913,914,2322];(p/'historical-queue-selected.json').write_text(json.dumps({'qualification':'Derived navigation subset of original 059 queue; no read credit or checkpoint3821 promotion.','entries':[{'index':i,'entry':q['entries'][i]} for i in inds]},indent=2)+'\n')
r=json.load(gzip.open(refs/'original-registry.json.gz','rt'));(p/'historical-registry-selected.json').write_text(json.dumps({'qualification':'Derived navigation subset; original scope and owners intact.','roles':[{'index':i,'entry':r['files'][i]} for i in [2363,2369]]},indent=2)+'\n')
(p/'historical-059-index.json').write_text(json.dumps({'schema':'726-historical-transport-extract-v1','records':rows,'unavailable':missing,'qualification':'Exact extracted original bytes independently verified against original transport manifest; no scope/status promotion.'},indent=2)+'\n')
# Preserve the original and distinct path-normalized 774 export separately.
old=pathlib.Path('<LOCAL_PATH_3>');oldorig=old/'semantic-goal/pr774-plan-execution-20261020';oldexp=old/'774-publication-branch/handoff/774/adler-original/audit';manifest=json.loads((oldexp/'EXPORT-MANIFEST.json').read_text()); me={x['file']:x for x in manifest['files'] if isinstance(x,dict)} if isinstance(manifest.get('files'),list) else None
shutil.copyfile(oldexp/'EXPORT-MANIFEST.json',p/'older-774-export-manifest.json'); print('manifest keys',list(manifest),'records',len(rows),'missing',missing)
