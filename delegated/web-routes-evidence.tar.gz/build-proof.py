import datetime,gzip,hashlib,json,pathlib,subprocess
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';records=json.loads((p/'registration.json').read_text())['sources']+json.loads((p/'support-registration.json').read_text())['sources'];objdir=p/'git-objects';objdir.mkdir(exist_ok=True);objects={};proof=[]
def get(t,oid):
 b=subprocess.check_output(['git','-C',repo,'cat-file',t,oid]);assert hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 if oid not in objects:
  dest=objdir/(oid+'.'+t+'.gz');dest.write_bytes(gzip.compress(b,mtime=0));objects[oid]={'type':t,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'archive':str(dest.relative_to(p))}
 return b
def entries(b):
 out={};i=0
 while i<len(b):
  s=b.index(b' ',i);z=b.index(b'\0',s);out[b[s+1:z].decode()]=(b[i:s].decode(),b[z+1:z+21].hex());i=z+21
 return out
for x in records:
 rev=x['revision'];commit=get('commit',rev);tree=commit.splitlines()[0].split()[1].decode();root=tree;chain=[]
 for name in x['path'].split('/'):
  mode,child=entries(get('tree',tree))[name];chain.append({'tree':tree,'name':name,'mode':mode,'object':child});tree=child
 assert tree==x['git_blob_sha1'];b=(p/x['archive']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==tree
 proof.append({'revision':rev,'path':x['path'],'archive':x['archive'],'commit_tree':root,'chain':chain,'blob':tree})
(p/'git-proofs.json').write_text(json.dumps({'qualification':'Raw Git commit/tree objects and exact archived blob bytes verify path membership only, not source display credit.','objects':objects,'proofs':proof},indent=2)+'\n')
ranges={0:[[1,350]],1:[[1,104]],2:[[1,75],[130,225]],3:[[60,145],[310,435],[770,825]],4:[[45,250],[675,725],[775,1205]],5:[[220,275],[395,445]],6:[[1,105],[150,180]],7:[[185,205]]};s=json.loads((p/'support-registration.json').read_text());reads=[]
for i,x in enumerate(s['sources']): reads.append({'path':x['path'],'revision':x['revision'],'archive':x['archive'],'actual_display_union':ranges[i]})
(p/'support-read-receipt.json').write_text(json.dumps({'schema':'726-support-personal-display-receipt-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/mhr_character','registration_sha256':hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest(),'reads':reads,'qualification':'Only these line ranges were personally displayed. Metadata-only symbol locations and whole archived bytes confer no other personal source coverage or ordered role credit.'},indent=2)+'\n');print('proofs',len(proof),'objects',len(objects),'support receipts',len(reads))
