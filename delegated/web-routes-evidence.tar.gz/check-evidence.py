import gzip,hashlib,json,pathlib,datetime
p=pathlib.Path('<LOCAL_PATH_0>');H=lambda b:hashlib.sha256(b).hexdigest();O=lambda t,b:hashlib.sha1(t.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
reg=json.loads((p/'registration.json').read_text());sup=json.loads((p/'support-registration.json').read_text());receipt=json.loads((p/'read-receipt.json').read_text());sr=json.loads((p/'support-read-receipt.json').read_text());assert receipt['registration_sha256']==H((p/'registration.json').read_bytes());assert sr['registration_sha256']==H((p/'support-registration.json').read_bytes())
allsource=reg['sources']+sup['sources'];sources={(x['revision'],x['path']):x for x in allsource};displays={}
for x in receipt['reads']:
 y=sources[x['revision'],x['path']];assert x['actual_display_ranges'][0][0]==1 and x['actual_display_ranges'][-1][1]==y['lines'];assert all(a[1]+1==b[0] for a,b in zip(x['actual_display_ranges'],x['actual_display_ranges'][1:]));displays[x['revision'],x['path']]=x['actual_display_ranges']
for x in sr['reads']:displays[x['revision'],x['path']]=x['actual_display_union']
for x in allsource:
 b=(p/x['archive']).read_bytes();assert (len(b),len(b.splitlines()),H(b),O('blob',b))==(x['bytes'],x['lines'],x['sha256'],x['git_blob_sha1'])
proof=json.loads((p/'git-proofs.json').read_text());objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert (len(b),H(b),O(x['type'],b))==(x['bytes'],x['sha256'],oid);objects[oid]=b
def entries(b):
 d={};i=0
 while i<len(b):
  sp=b.index(b' ',i);z=b.index(b'\0',sp);d[b[sp+1:z].decode()]=(b[i:sp].decode(),b[z+1:z+21].hex());i=z+21
 return d
for x in proof['proofs']:
 commit=objects[x['revision']];root=commit.splitlines()[0].split()[1].decode();assert root==x['commit_tree'];t=root
 for c in x['chain']:
  assert c['tree']==t and entries(objects[t])[c['name']]==(c['mode'],c['object']);t=c['object']
 assert t==x['blob']==sources[x['revision'],x['path']]['git_blob_sha1']
report=json.loads((p/'report.json').read_text());refs=0
for finding in report['findings_and_reconciliations']:
 for ref in finding['source_refs']:
  spans=displays[ref['revision'],ref['path']]
  for a,b in ref['lines']:assert any(c<=a<=b<=d for c,d in spans),(ref['path'],a,b,spans);refs+=1
with gzip.open(p/'reference/original-transport-manifest.json.gz','rt') as f:trans={x['path']:x for x in json.load(f)['entries']}
hist=json.loads((p/'historical-059-index.json').read_text());assert not hist['unavailable']
for x in hist['records']:
 b=(p/x['copy']).read_bytes();e=trans[x['original_path']];assert (len(b),H(b),O('blob',b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
queue=gzip.decompress((p/'reference/059-queue-original-bytes.json.gz').read_bytes());assert H(queue)=='2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08';q=json.loads(queue)
for x in json.loads((p/'historical-queue-selected.json').read_text())['entries']:assert x['entry']==q['entries'][x['index']]
manifest=json.loads((p/'older-774-export-manifest.json').read_text());entries774={x['file']:x for x in manifest['files']}
old=json.loads((p/'older-774-index.json').read_text())
for x in old['records']:
 e=entries774['records/'+x['path']];assert H((p/x['original_copy']).read_bytes())==e['original_record_sha256']==x['original_sha256'];assert H((p/x['normalized_copy']).read_bytes())==e['published_export_sha256']==x['normalized_export_sha256']
for d,rn,ranges in [('726-delegate-strategic-web','support-registration-03.json',[[1,170]]),('726-delegate-web-data','support-registration-01.json',[[75,112]])]:
 z=p/'prior-traces'/d;rr=json.loads((z/'report.json').read_text());registration=json.loads((z/rn).read_text());s=[s for s in registration['registered_sources'] if s['path'].endswith('/routes/missions.rs')][0];b=(z/'source/support-crates__strategic-web__src__routes__missions.rs').read_bytes();assert H(b)==s['sha256'];record=next(r for r in rr['support'] if r['registration']==rn);assert record['sha256']==H((z/rn).read_bytes()) and record['actual_personal_ranges'][s['path']]==ranges
result={'schema':'726-evidence-only-verification-v1','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','assigned_source_revision_bodies':len(reg['sources']),'current_support_archives':len(sup['sources']),'git_membership_proofs':len(proof['proofs']),'raw_git_commit_tree_objects':len(proof['objects']),'finding_source_ranges_within_actual_displays':refs,'original_059_records':len(hist['records']),'selected_queue_entries':len(json.loads((p/'historical-queue-selected.json').read_text())['entries']),'older_774_original_export_pairs':len(old['records']),'prior_distinct_95e_mission_traces':2,'qualification':'Evidence hashing, JSON/gzip parsing and Git object path verification only; no product execution or validation.'};(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
