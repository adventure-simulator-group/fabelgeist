import datetime,hashlib,json,pathlib,subprocess
out=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';older=pathlib.Path('<LOCAL_PATH_2>');handoff=pathlib.Path('<LOCAL_PATH_3>');catalog=json.loads((older/'reconcile-adler-20261023/recovered-sources/catalog.json').read_text());revs=['90a422a453cd990ebc7f0ecf2ad5ed3e2d57d696','6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009'];paths=['crates/adventuresim-tactical-client/src/animation_viewer/mod.rs','crates/adventuresim-tactical-client/src/animation_viewer/report/acceptance_limits.rs'];roles=[]
for idx,path in zip([2444,2445],paths):
 versions=[]
 for rev in revs:
  x=subprocess.run(['git','-C',repo,'show',rev+':'+path],capture_output=True)
  if x.returncode:versions.append({'revision':rev,'present':False});continue
  b=x.stdout;local=f'source/{idx}-{rev[:4]}.rs';(out/local).write_bytes(b);h=hashlib.sha256(b).hexdigest();row={'revision':rev,'present':True,'local_path':local,'bytes':len(b),'lines':[1,len(b.splitlines())],'sha256':h,'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
  if rev==revs[0]:
   c=catalog['rows'][idx];assert c['source_id']=='report-p17:'+path and c['origin']=='git:'+rev+':'+path and c['expected_sha256']==h and pathlib.Path(c['object']).read_bytes()==b;archive=older/'reconcile-adler-20261023/audit-continuation/operations/source/report-p17'/path;other=handoff/'audit/reconcile-adler-20261023/audit-continuation/operations/source/report-p17'/path;row['frozen_catalog_object']=c['object'];row['archive_local_present']=archive.is_file();row['handoff_archive_present']=other.is_file()
   if archive.is_file():assert archive.read_bytes()==b;row['archive_local']=str(archive)
   if other.is_file():assert other.read_bytes()==b;row['handoff_archive']=str(other)
  versions.append(row)
 roles.append({'original_index':idx,'path':path,'versions':versions})
f=out/'registration.json';f.write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','scope':'Register complete original P17, pr-working and pinned current bodies before fresh role displays. Each distinct body displayed separately, with actual revision and ranges recorded.','qualification':'P17 object verified against original frozen source catalog and available archives; source archives alone confer no body credit. My previous current mod.rs support read remains separate.','constraint':'Source/evidence only; no implementation, repairs, builds, tests, viewer execution, runtime probes or simulation.','roles':roles},indent=2)+'\n');print('sha256',hashlib.sha256(f.read_bytes()).hexdigest());print(json.dumps(roles,indent=1))
