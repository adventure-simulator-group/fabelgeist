import gzip,hashlib,json,pathlib,subprocess,difflib
p=pathlib.Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(r,path):return subprocess.run(['git','-C',repo,'show',r+':'+path],capture_output=True,check=True).stdout
def checkref(obj):assert sha((p/obj['path']).read_bytes())==obj['sha256']
def complete(ranges,n):return bool(ranges) and ranges[0][0]==1 and all(ranges[i][1]+1==ranges[i+1][0] for i in range(len(ranges)-1)) and ranges[-1][1]==n
report=json.loads((p/'report.json').read_text());checkref(report['registration']);reg=json.loads((p/'registration.json').read_text());catalog=json.loads(gzip.decompress((p/'reference/older-source-catalog.json.gz').read_bytes()))
for row,read in zip(reg['roles'],report['role_records']):
 bs=[]
 for v in row['versions']:
  assert v['present'];b=(p/v['local_path']).read_bytes();assert b==git(v['revision'],row['path']);assert (len(b),len(b.splitlines()),sha(b),blob(b))==(v['bytes'],v['lines'][1],v['sha256'],v['git_blob']);bs.append(b)
  if v['revision'].startswith('90a'):
   c=catalog['rows'][row['original_index']];assert c['origin']=='git:'+v['revision']+':'+row['path'] and c['expected_sha256']==sha(b);assert pathlib.Path(v['frozen_catalog_object']).read_bytes()==b;assert pathlib.Path(v['archive_local']).read_bytes()==b==pathlib.Path(v['handoff_archive']).read_bytes()
 assert bs[0]!=bs[1] and bs[1]==bs[2];assert read['original_index']==row['original_index'] and not read['historical_unread_ranges'] and not read['current_unread_ranges'] and not read['pr_working_personal_display_ranges'];assert complete(read['fresh_personal_snapshot_ranges'],len(bs[0].splitlines())) and complete(read['fresh_personal_current_ranges'],len(bs[2].splitlines()));checkref(read['p17_to_current_diff'])
 diff=''.join(difflib.unified_diff(bs[0].decode().splitlines(keepends=True),bs[2].decode().splitlines(keepends=True),fromfile='report-p17:90a422:'+str(row['original_index']),tofile='current:95e636:'+str(row['original_index'])));assert diff.encode()==(p/read['p17_to_current_diff']['path']).read_bytes()
registered=[]
for z in report['support_registrations']:checkref(z);registered+=json.loads((p/z['path']).read_text())['sources']
assert len(registered)==len(report['support'])
for s,actual in zip(registered,report['support']):
 assert s['present'];b=(p/s['local_path']).read_bytes();assert b==git(s['revision'],s['path']);assert (len(b),len(b.splitlines()),sha(b),blob(b))==(s['bytes'],s['registered_range'][1],s['sha256'],s['git_blob']);assert actual['path']==s['path'] and actual['revision']==s['revision'] and actual['sha256']==s['sha256'];assert all(1<=a<=z<=s['registered_range'][1] for a,z in actual['actual_body_ranges']);assert all(1<=n<=s['registered_range'][1] for n in actual['navigation_only_displayed_line_numbers'])
for z in report['navigation_receipts']:checkref(z)
checkref(report['historical_manifest']);h=json.loads((p/'historical-manifest.json').read_text());assert not h['unavailable'];transport={x['path']:x for x in json.loads(gzip.decompress((p/'reference/original-transport-manifest.json.gz').read_bytes()))['entries']}
for x in h['records']:
 b=(p/x['copy_path']).read_bytes();e=transport[x['original_transport_path']];assert (len(b),sha(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])==(e['bytes'],e['sha256'],e['git_blob'])
checkref(report['reference_archives']);refs=json.loads((p/'reference/manifest.json').read_text())
for x in refs['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256']);assert 'uncompressed_sha256' not in x or sha(gzip.decompress(b))==x['uncompressed_sha256']
checkref(report['older_774_selection']);old=json.loads((p/'reference/older-774-selection.json').read_text());assert refs['older_manifest_sha256']==report['older_774_selection']['sha256'];mb=gzip.decompress((p/old['manifest_compressed']).read_bytes());assert sha(mb)==old['manifest_uncompressed_sha256'];ix={e['path']:e for e in json.loads(mb)['files']}
for x in old['records']:
 b=gzip.decompress((p/x['compressed_copy']).read_bytes());e=ix[x['manifest_path']];assert (len(b),sha(b))==(x['bytes'],x['sha256'])==(e['bytes'],e['sha256']);assert x['merged_copy'] is None or b==pathlib.Path(x['merged_copy']).read_bytes()
coverage=next(x for x in old['records'] if x['manifest_path'].endswith('native/coverage.jsonl'));lines=[json.loads(x) for x in gzip.decompress((p/coverage['compressed_copy']).read_bytes()).splitlines()]
for role,indexes in [(reg['roles'][0],[274,613]),(reg['roles'][1],[275,614])]:
 for i in indexes:
  x=lines[i];assert x['source_id']=='report-p17:'+role['path'] and x['observed_sha256']==role['versions'][0]['sha256'] and x['read_ranges']==[role['versions'][0]['lines']]
checkref(report['prior_current_selection']);prior=json.loads((p/'reference/prior-current-selection.json').read_text());assert refs['prior_manifest_sha256']==report['prior_current_selection']['sha256'];count=0
for x in prior['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
 for s in x['source_records']:
  raw=(p/s['copy']).read_bytes();assert sha(raw)==s['compressed_sha256'];b=gzip.decompress(raw);assert sha(b)==s['sha256'] and b==git(s['revision_as_recorded'],s['path']);count+=1
checkref(report['prior_own_support']);own=json.loads((p/'reference/prior-own-support.json').read_text());assert refs['prior_own_manifest_sha256']==report['prior_own_support']['sha256']
for x in own['records']:
 b=(p/x['copy']).read_bytes();assert (len(b),sha(b))==(x['bytes'],x['sha256'])
assert (p/'reference/prior-own-support__03-mod.rs').read_bytes()==git(own['revision'],own['path']);assert own['prior_personal_support_ranges']==[[1,179]]
q=json.loads(gzip.decompress((p/'reference/queue-059.json.gz').read_bytes()))
for x in report['historical_queue']:assert (q['entries'][x['index']]['contract_id'],q['entries'][x['index']].get('status'))==(x['id'],x['status_as_recovered'])
assert len(report['lens_notes'])==13
print('Evidence integrity passed: 2 P17 objects independently match 90a, catalog and both 774 archives; distinct 6533/current matches with complete P17/current display unions;',len(registered),'registered support objects,',len(h['records']),'059 transport records,',len(old['records']),'774 manifest records,',len(prior['records']),'prior current assessments with',count,'source traces, earlier own support receipt,',len(report['historical_queue']),'queue identities and 13 bounded lenses.')
print('Only source object, JSON, gzip, hash, range and provenance checks. No product/test/fixture execution, builds, browser or probes.')
