# Physical-P16 armor admission roles 2724–2725

This source-only packet is by `/root/hair_ops`. Start with `REPORT.json`,
`registration.json` and `read-receipt.json`. The original P16 archive bodies
and pinned 95e bodies were independently displayed. Original material is lib
86–171 and breastplate design 1–128; other P16 lines were separately
registered and displayed only as contextual support, without retroactive
historical role credit. Direct a120 and 6533 file comparisons were not displayed.

The P16 breastplate file equals 95e bytes; the lib file changed. The reconstructed
`2724-old-current.diff` gives exact source comparison, not full product or
visual equivalence. Earlier rig/pr-working, native/P16, 059 root/delegate and
prior current reviewer scopes retain their authors and ranges. Proposal 951 is
not shown adopted in the supplied extraction. The native 774 support report's
"F007/RigF049" reference is preserved: the actual NATIVE-ADMISSION03-F007
record concerns quest IDs, so it is not assumed to alias the armor RIG F049.

`recovered/` preserves the original registry, source archive, 059 ledger and
queue, older reconstructed catalogue, and later hash-matching tracked P16
patch. Seven untracked objects are separately archived, not included in the
tracked patch. `historical/` contains exact historical records;
`historical-selections-reconstructed.json` is a new selection. Git object proofs
show per-file identity and 774 evidence transport offline. `MANIFEST.json`
hashes every packet file except the top-level manifest, including the nested
recovered manifest.

Run `python3 verify-evidence.py` only for offline evidence integrity. Thirteen
bounded perspectives are not whole-lens clearance. The user prohibits product
validation, overriding modeling and visual-review workflows for this task. No
checkpoint 3821 promotion, product, armor, GPU or fixture execution, builds,
tests, probes, repairs or publication edits were performed.
