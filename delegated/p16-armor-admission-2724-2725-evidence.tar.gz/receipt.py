from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();load=lambda n:json.loads((b/n).read_bytes())
def missing(n,r):
 a=set(range(1,n+1));[a.difference_update(range(x,y+1)) for x,y in r];out=[]
 for x in sorted(a):
  if not out or x!=out[-1][1]+1:out.append([x,x])
  else:out[-1][1]=x
 return out
reg=load('registration.json');assigned=[]
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  if row['original_index']==2724:
   material=[[86,171]] if j==0 else [];ctx=[[1,85]] if j==0 else [[1,130],[131,239]]
  else:
   material=[[1,128]] if j==0 else [];ctx=[[129,206]] if j==0 else [[1,128],[129,206]]
  assigned.append({'original_index':row['original_index'],'source_id':row['source_id'],'identity':v.get('identity','pinned95e current source'),'revision':v.get('revision'),'sha256':v['sha256'],'local':v['local'],'eof':v['eof'],'original_assigned_displays':material,'separately_registered_context_or_current_displays':ctx,'unread_complement':missing(v['eof'],material+ctx),'qualification':'Historical original material is only2724 86–171 /2725 1–128; other historical bodies are fresh support, current whole file independently read without copied historical line credit.'})
w={'crates/fabelgeist-armor/src/anime_design.rs':[[1,56]],'crates/fabelgeist-armor/src/design.rs':[[1,110]],'crates/fabelgeist-armor/src/plate_fluting.rs':[[1,150]],'crates/fabelgeist-armor/src/gpu/breastplate/mod.rs':[[80,145]],'crates/adventuresim-character-creator/src/design_input.rs':[[1,45]],'crates/adventuresim-character-creator/src/runtime_equipment/warmup.rs':[[1,85]],'crates/adventuresim-character-creator/src/armor_recipes.rs':[[55,110]],'crates/adventuresim-character-creator/src/runtime_equipment.rs':[[110,165],[230,260]],'crates/adventuresim-character-creator/src/device_torso.rs':[[150,180],[220,255]]};supports=[]
for n in ['support-registration.json','more-support-registration.json']:
 for x in load(n)['entries']:
  d=w[x['path']];supports.append({'revision':x['revision'],'path':x['path'],'sha256':x['sha256'],'local':x['local'],'eof':x['eof'],'displayed':d,'unread_complement':missing(x['eof'],d),'registration':n,'ordered_role_credit':0})
refs=[]
for n in ['registration.json','support-registration.json','more-support-registration.json']:refs.append({'path':n,'sha256':h((b/n).read_bytes()),'created_utc':load(n)['created_utc']})
d={'created_utc':datetime.now(timezone.utc).isoformat(),'reader':'/root/hair_ops','method':'Prospective register followed by bounded line-numbered personal displays; source text only, no fixture or product execution. This receipt is newly reconstructed, not an original historical record.','registrations':refs,'assigned':assigned,'support':supports,'prior_disclosure':'Earlier /root/hair_ops armor-anime-helmets 95e lib145–215 and breastplate1–155 were support only; separate /root/mhr_character role2607 displays and 774/059 readings remain separately attributed.','runtime_validation':'None; no armor, GPU, fixture, product, geometry, tests, builds, probes or repairs.'};(b/'read-receipt.json').write_text(json.dumps(d,indent=2)+'\n');print('receipt_sha256',h((b/'read-receipt.json').read_bytes()))
