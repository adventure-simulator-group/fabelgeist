'''Offline evidence-integrity verification only; no product, armor, fixture or test execution.'''
from pathlib import Path
from datetime import datetime
import difflib,gzip,hashlib,json,tarfile
b=Path(__file__).resolve().parent;h=lambda x:hashlib.sha256(x).hexdigest();oid=lambda t,x:hashlib.sha1(t.encode()+b' '+str(len(x)).encode()+b'\0'+x).hexdigest();load=lambda n:json.loads((b/n).read_bytes());reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json');sel=load('historical-selections-reconstructed.json');report=load('REPORT.json')
for x in hist['records']:
 raw=(b/x['local']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['local']
rbytes=gzip.decompress((b/'recovered/registry.json.gz').read_bytes());assert h(rbytes)==reg['original_registry_uncompressed_sha256']==hist['registry_uncompressed_sha256']==sel['registry_uncompressed_sha256'];registry=json.loads(rbytes);original=registry['files'];assert all(original[i]==sel['registry_rows'][str(i)] for i in [2606,2607,2724,2725]);assert sel['snapshot_rows']==[x for x in registry['snapshots'] if x['id'] in ['physical-p16','pr-working']]
snapshot=next(x for x in sel['snapshot_rows'] if x['id']=='physical-p16');patch=(b/'recovered/physical-p16-patch-recovery/tracked.patch').read_bytes();assert h(patch)==snapshot['patch_sha256']=='fc9002ab1135a438f68eede9217f67d22ef737d2c6938509e6e6660f2fc5b7f7';recovery=load('prior/RECOVERY-PHYSICAL-P16-PATCH-20261111.json');assert recovery['recovered_patch']['sha256']==h(patch) and recovery['recovered_patch']['bytes']==len(patch) and recovery['live_comparison']['status_counts']['??']==7
qbytes=gzip.decompress((b/'recovered/original-059-queue.json.gz').read_bytes());assert h(qbytes)==sel['queue_uncompressed_sha256'];queue=json.loads(qbytes)['entries']
for i,x in sel['queue_rows'].items():assert queue[int(i)]==x
catalog=load('recovered/catalog-774.json')['rows'];expected={2724:[[86,171]],2725:[[1,128]]}
with tarfile.open(b/'recovered/objects.tar.gz','r:gz') as t:
 for row in reg['rows']:
  i=row['original_index'];old,cur=row['versions'];body=(b/old['local']).read_bytes();assert t.extractfile(old['sha256']).read()==body and h(body)==old['sha256']==original[i]['sha256']==catalog[i]['expected_sha256'];assert original[i]['material_ranges']==expected[i] and row['original_material_ranges']==expected[i];assert catalog[i]['origin']=='git:039329518e264f19206cf5b0b98d177433f40c17:'+row['path']
  for c in row['comparison_git_paths']:assert (b/c['local']).read_bytes()==body and c['display_planned']==False
  assert ((b/cur['local']).read_bytes()==body)==(i==2725)
a=(b/'source/2724-physical-p16.rs').read_text().splitlines(keepends=True);c=(b/'source/2724-95e6.rs').read_text().splitlines(keepends=True);assert a[94:171]==c[162:239];assert ''.join(difflib.unified_diff(a,c,fromfile='physical-p16 archived object',tofile='95e current source'))==(b/'2724-old-current.diff').read_text()
for x in rec['registrations']:assert h((b/x['path']).read_bytes())==x['sha256'] and datetime.fromisoformat(load(x['path'])['created_utc'])<=datetime.fromisoformat(rec['created_utc'])
def partition(n,ranges):
 nums=[i for a,z in ranges for i in range(a,z+1)];return len(nums)==n and set(nums)==set(range(1,n+1))
for row in reg['rows']:
 for j,v in enumerate(row['versions']):
  p=next(x for x in rec['assigned'] if x['local']==v['local']);raw=(b/v['local']).read_bytes();assert h(raw)==v['sha256']==p['sha256'] and len(raw.splitlines())==v['eof']==p['eof'];assert partition(v['eof'],p['original_assigned_displays']+p['separately_registered_context_or_current_displays']+p['unread_complement']) and p['unread_complement']==[];assert p['original_assigned_displays']==(expected[row['original_index']] if j==0 else [])
planned={}
for n in ['support-registration.json','more-support-registration.json']:
 for x in load(n)['entries']:planned[x['local']]=x
for x in rec['support']:
 e=planned[x['local']];raw=(b/x['local']).read_bytes();assert h(raw)==x['sha256']==e['sha256'] and len(raw.splitlines())==x['eof']==e['eof'];assert partition(x['eof'],x['displayed']+x['unread_complement']);assert all(any(a<=u<=v<=z for a,z in e['planned_display_ranges']) for u,v in x['displayed'])
objs={}
for key,x in proof['objects'].items():
 raw=gzip.decompress((b/x['preserved']).read_bytes());assert h(raw)==x['sha256'] and len(raw)==x['bytes'] and oid(x['type'],raw)==key;objs[key]=raw
def lookup(raw,n):
 i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);child=raw[z+1:z+21].hex();i=z+21
  if name.decode()==n:return mode.decode(),child
 raise AssertionError(n)
for x in proof['proofs']:
 tree=objs[x['revision']].splitlines()[0].split()[1].decode();assert tree==x['root_tree']
 for c in x['chain']:assert c['tree']==tree and lookup(objs[tree],c['name'])==(c['mode'],c['object']);tree=c['object']
 raw=(b/x['local']).read_bytes();assert tree==x['blob']==oid('blob',raw) and h(raw)==x['sha256']
readjsonl=lambda n:[json.loads(s) for s in (b/n).read_text().splitlines()];native=readjsonl('historical/774/native-range-registration.jsonl');nf=readjsonl('historical/774/native-final-qualifications.jsonl');nq=readjsonl('historical/774/native-camera-qualifications.jsonl');rig=readjsonl('historical/774/rig-range-registration.jsonl');ncontract=load('historical/774/native-p16-armor-admission.json')
for i in [2724,2725]:
 ob=original[i]['admission03_scope_observations'][0];j=ob['row_1based']-1;assert native[j]==ob['original_record'];qual=next(x for x in nf if x['registration_id']==ob['registration_id']);assert qual==ob['local_qualifications'][0];assert nq[i-2724]==qual['qualification_history'][0]['payload'];assert ncontract['registered_sources'][i-2724]==ob['original_record']
for i in [2606,2607]:
 ob=original[i]['admission03_scope_observations'][0];assert rig[ob['row_1based']-1]==ob['original_record']
rfind=readjsonl('historical/774/rig-findings.jsonl');nfind=readjsonl('historical/774/native-findings.jsonl');rf=next(x for x in rfind if x.get('id')=='RIG-ADMISSION03-F049');nf=next(x for x in nfind if x.get('id')=='NATIVE-ADMISSION03-F007');assert 'anime_design.rs' in rf['source_id'] and 'quest_generation/model.rs' in nf['source_id'];assert 'F007/RigF049' in ncontract['counterexample_or_qualification']
l11=load('historical/059/segovb/READ-L11-445.json')
for i,number in [(2724,1643),(2725,1644)]:
 x=next(x for x in l11['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected[i] and h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{number}.json').read_bytes())==x['registration_sha256']
for i,n,number,ranges in [(2606,426,1517,[[86,171]]),(2607,427,1519,[[1,129]])]:
 p=load(f'historical/059/segovb/READ-L11-{n}.json');x=next(x for x in p['sources'] if x['original_index']==i);assert x['fresh_personal_body_reads']==ranges and h((b/f'historical/059/segovb/REGISTRATION-SEGOVB-{number}.json').read_bytes())==x['registration_sha256']
for i,n,ranges in [(2606,888,[[86,171]]),(2607,889,[[1,129]])]:
 p=load(f'historical/059/segovb/READ-L12-{n}.json');x=next(x for x in p['rows'] if x['original_index']==i);assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution'] and p['root_personal_rereads']==[];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256']
p=load('historical/059/parallel-l12-20261029/PROPOSAL-L12-951.json');assert p['authoritative_ledger_written']==False and p['current_source_reconciled']==False
for i in [2724,2725]:
 x=next(x for x in p['rows'] if x['original_index']==i);assert x['fresh_personal_body_reads']==expected[i] and '/root/lens12_frontier' in x['attribution'];assert h((b/'historical/059'/x['registration']).read_bytes())==x['registration_sha256'];q=x['identity_specific_windows_qualification'];assert h((b/'historical/059'/q['path']).read_bytes())==q['sha256']
for x in p['partial_read_receipts']:assert h((b/'historical/059'/x['path']).read_bytes())==x['sha256']
p=load('prior/anime-helmets-read-receipt.json');assert p['agent']=='/root/hair_ops'
for name,ranges in [('crates/fabelgeist-armor/src/lib.rs',[[145,215]]),('crates/fabelgeist-armor/src/breastplate_design.rs',[[1,155]])]:
 x=next(x for x in p['support'] if x['path']==name);assert x['displayed']==ranges
p=load('prior/design-fluting-read-receipt.json');assert p['author']=='/root/mhr_character';x=[x for x in p['reads'] if x['original_index']==2607];assert len(x)==2 and {z['revision'] for z in x}=={'6533e444fa37552927070cc8d8190907fd3b413e','95e63628f9d70b8dd6e6fede64334696c6995009'} and all(z['actual_display_ranges']==[[1,100],[101,200],[201,206]] for z in x)
assert len(report['thirteen_lenses'])==13 and report['assigned_personal_displays']==rec['assigned']
if (b/'MANIFEST.json').exists():
 listed=set()
 for x in load('MANIFEST.json')['files']:
  raw=(b/x['path']).read_bytes();assert len(raw)==x['bytes'] and h(raw)==x['sha256'],x['path'];listed.add(x['path'])
 actual={str(x.relative_to(b)) for x in b.rglob('*') if x.is_file() and x!=b/'MANIFEST.json'};assert listed==actual,(listed^actual)
print('PASS: P16 role2724/2725 and current bodies independently displayed, original excluded contexts separate; changed lib and identical breastplate file proven; historical reviewers, unadopted951 and Native-F007/Rig-F049 conflict retained; tracked patch and untracked qualification; %d Git proofs and %d bounded supports. Thirteen partial perspectives; offline evidence integrity only, no armor/product/build/test/probe.'%(len(proof['proofs']),len(rec['support'])))
