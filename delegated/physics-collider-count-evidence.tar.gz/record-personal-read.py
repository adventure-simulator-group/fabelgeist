from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');cur='95e63628f9d70b8dd6e6fede64334696c6995009';old='6533e444fa37552927070cc8d8190907fd3b413e';p='crates/fabelgeist-physics/src/';gpu='crates/fabelgeist-gpu/src/data/gpu/buffer/'
scopes={p+'contact.rs':([[18,150]],[]),p+'wgsl.rs':([[1,195]],[]),'crates/fabelgeist-physics/Cargo.toml':([[1,21]],[]),gpu+'mod.rs':([[1,40],[115,155]],[]),gpu+'definition.rs':([[110,138]],[]),gpu+'upload.rs':([[1,58]],[]),'crates/adventuresim-building-generator/src/spatial_geometry/orientation.rs':([[1,115]],[]),'crates/AGENTS.md':([[21,86],[141,153],[182,192]],[])}
entries=[]
for e in json.loads((b/'support-registration.json').read_bytes())['entries']:
 displayed,snips=scopes[e['path']];n=e['actual_line_count'];covered={j for lo,hi in displayed for j in range(lo,hi+1)};missing=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in covered:
   if start is None:start=i
  elif start is not None:missing.append([start,i-1]);start=None
 entries.append({'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'actual_eof':n,'contiguously_displayed_body_ranges':displayed,'search_result_lines_outside_body_ranges':snips,'not_contiguously_displayed_ranges':missing,'scope':'Bounded support/rule only; uninspected ranges have no read credit.'})
assigned=[]
for rev,reg in [(old,'old-registration.json'),(cur,'current-registration.json')]:
 for e in json.loads((b/reg).read_bytes())['entries']:
  body=[[1,55]] if e['original_role']==2481 else [[1,133],[212,218]];extra=[] if e['original_role']==2481 else [[134,211]]
  assigned.append({'revision':rev,'role':e['original_role'],'path':e['path'],'original_role_scope_personally_displayed':body,'connected_personally_displayed_outside_original_scope':extra,'actual_full_source_displayed':[[1,e['actual_line_count']]],'registration':reg,'qualification':'Original collider scope remains narrow; 134–211 has separate personal support credit only, not original role expansion.'})
r={'schema':'726-physics-collider-count-personal-display-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','assigned_personal_reads':assigned,'support_personal_reads':entries,'previous_qualifications':'Prior physics-contact packet separately records this delegate 95e full bodies as support; earlier ordered 059 L11/L12 reused qualified personal reads with no fresh body reads. 774 owner-fit 013/014/015 registries and actual EOF coverage retain original qualification.','execution':'Source inspection/search, symbolic arithmetic and evidence verification only. No physics, model, GPU/shader, product, build, test, runtime probe, simulation, fixture or repair.'};raw=(json.dumps(r,indent=2)+'\n').encode();(b/'personal-read-receipt.json').write_bytes(raw);print('receipt SHA',hashlib.sha256(raw).hexdigest(),'assigned',len(assigned),'support',len(entries))
