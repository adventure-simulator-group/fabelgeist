from pathlib import Path
import gzip,hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda typ,d:hashlib.sha1(typ.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();objs={};proofs=[]
def git(*args):return subprocess.check_output(['git',*args])
def save(typ,k):
 if k not in objs:
  raw=git('cat-file',typ,k);assert oid(typ,raw)==k;p=f'git-objects/{k}.{typ}.gz';(b/p).parent.mkdir(parents=True,exist_ok=True);(b/p).write_bytes(gzip.compress(raw,mtime=0));objs[k]={'type':typ,'bytes':len(raw),'sha256':sha(raw),'preserved_bytes':p}
 return gzip.decompress((b/objs[k]['preserved_bytes']).read_bytes())
def entries(raw):
 d={};i=0
 while i<len(raw):
  j=raw.index(b'\0',i);mode,name=raw[i:j].split(b' ',1);d[name.decode()]=(mode.decode(),raw[j+1:j+21].hex());i=j+21
 assert i==len(raw);return d
for e in json.loads((b/'old-registration.json').read_bytes())['entries']:
 c=save('commit',e['revision']);root=c.splitlines()[0].split()[1].decode();cur=root;chain=[]
 for segment in e['path'].split('/'):
  mode,child=entries(save('tree',cur))[segment];chain.append({'tree':cur,'name':segment,'mode':mode,'object':child});cur=child
 raw=(b/'sources'/'6533'/e['path']).read_bytes();assert cur==e['git_blob']==oid('blob',raw) and sha(raw)==e['sha256'];proofs.append({'revision':e['revision'],'root_tree':root,'path':e['path'],'path_chain':chain,'git_blob':cur,'sha256':sha(raw)})
d={'schema':'726-physics-collider-original-git-proof-v1','objects':objs,'paths':proofs,'qualification':'Exact raw commit/tree membership and object hash checked before comparison with current source; no attribution transfer.'};raw=(json.dumps(d,indent=2)+'\n').encode();(b/'old-git-proofs.json').write_bytes(raw);print('old proofs',len(proofs),'raw objects',len(objs),'sha256',sha(raw))
