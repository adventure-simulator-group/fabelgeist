import gzip,hashlib,json,pathlib
b=pathlib.Path(__file__).resolve().parent;sha=lambda d:hashlib.sha256(d).hexdigest();oid=lambda k,d:hashlib.sha1(k.encode()+b' '+str(len(d)).encode()+b'\0'+d).hexdigest();report=json.loads((b/'REPORT.json').read_bytes());h=json.loads((b/'original-attribution.json').read_bytes());rec=json.loads((b/'older-774-recovery.json').read_bytes());tm=(b/'original-transport-manifest.json.gz').read_bytes();m=json.loads(gzip.decompress(tm));idx={e['path']:e for e in m['entries']};assert sha(tm)==h['original_transport_manifest_sha256'];count=0
for e in h['original_059_records']:
 d=(b/e['preserved_bytes']).read_bytes();want=idx[e['original_path']];assert len(d)==e['bytes']==want['bytes'] and sha(d)==e['sha256']==want['sha256'] and oid('blob',d)==e['git_blob']==want['git_blob'];count+=1
for e in h['older_774_receipts']+rec['records']:
 d=(b/e['preserved_bytes']).read_bytes();assert len(d)==e['bytes'] and sha(d)==e['sha256'] and oid('blob',d)==e['git_blob']
for name,digest in report['registrations'].items():
 raw=(b/name).read_bytes();assert sha(raw)==digest
 for e in json.loads(raw)['entries']:
  folder='sources' if name in ['old-registration.json','current-registration.json'] else 'support';d=(b/folder/e['revision'][:4]/e['path']).read_bytes();assert len(d)==e['bytes'] and sha(d)==e['sha256'] and oid('blob',d)==e['git_blob'] and len(d.splitlines())==e['actual_line_count']
for e in report['original_roles']:
 d=(b/e['historical_source']).read_bytes();assert sha(d)==e['historical_sha256'] and e['historical_personal_reads']==[[1,len(d.splitlines())]]
 d2=(b/e['current_source']).read_bytes();assert d==d2 and sha(d2)==e['current_sha256'] and e['current_personal_reads']==[[1,len(d2.splitlines())]]
for name,digest in [('queue','2e1f4430edb375adff24b6b46d434ac58bf5fd18c0d9dda4cf92fe215e5cfe08'),('ledger','3933e8654ea22a7273e3218d5bc329d052968f20c1512a803de9b002038a6aac')]:assert sha(gzip.decompress((b/('original-059-'+name+'.json.gz')).read_bytes()))==digest
registry=json.loads(gzip.decompress((b/'original-registry.json.gz').read_bytes()));selection=json.loads((b/'registry-selection-reconstructed.json').read_bytes());assert sha((b/'original-registry.json.gz').read_bytes())==selection['exact_registry_gzip_sha256']
for row in selection['rows']:assert {k:v for k,v in row.items() if k!='original_index'}==registry['files'][row['original_index']]
for e in report['original_roles']:
 row=registry['files'][e['role']];assert row['material_ranges']==e['historical_original_material_ranges']==e['current_original_material_ranges'] and row['sha256']==e['historical_sha256'] and row['source_id'].split(':',1)[1]==e['path']
assert (b/'6533-to-current.patch').read_bytes()==b''
pmraw=(b/'prior-physics-contact/MANIFEST.json').read_bytes();assert sha(pmraw)==h['prior_physics_manifest_sha256'];prior={e['path']:e for e in json.loads(pmraw)['files']}
for e in h['prior_physics_packet']:
 d=(b/e['preserved_bytes']).read_bytes();want=prior[e['original_bundle_path']];assert len(d)==e['bytes']==want['bytes'] and sha(d)==e['sha256']==want['sha256']
a=[json.loads(x) for x in (b/rec['records'][0]['preserved_bytes']).read_text().splitlines()];c=[json.loads(x) for x in (b/rec['records'][1]['preserved_bytes']).read_text().splitlines()];assert a[38]['read_ranges']==[[1,120]] and a[40]['read_ranges']==[[116,147]] and a[41]['read_ranges']==[[212,218]] and c[189]['id']=='RIG-OWNER-DELTA-SUPPORT-013-count.rs' and c[190]['id']=='RIG-OWNER-DELTA-SUPPORT-013-collider.rs'
proof=json.loads((b/'git-proofs.json').read_bytes());objects={}
for k,e in proof['objects'].items():
 raw=gzip.decompress((b/e['preserved_bytes']).read_bytes());assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and oid(e['type'],raw)==k;objects[k]=raw
def entries(raw):
 d={};i=0
 while i<len(raw):
  z=raw.index(b'\0',i);mode,name=raw[i:z].split(b' ',1);d[name.decode()]=(mode.decode(),raw[z+1:z+21].hex());i=z+21
 assert i==len(raw);return d
for e in proof['paths']:
 c=proof['commits'][e['revision']];assert objects[c['commit_object']].splitlines()[0]==b'tree '+c['root_tree'].encode();cur=c['root_tree']
 for link in e['path_chain']:
  assert link['tree']==cur;mode,child=entries(objects[cur])[link['name']];assert mode==link['mode'] and child==link['object'];cur=child
 assert cur==e['git_blob'] and '/'.join(link['name'] for link in e['path_chain'])==e['path'];d=(b/e['preserved_bytes']).read_bytes();assert len(d)==e['bytes'] and sha(d)==e['sha256'] and oid('blob',d)==e['git_blob']
receipt=json.loads((b/'personal-read-receipt.json').read_bytes());ranges={}
for e in report['original_roles']:
 ranges[(e['historical_revision'],e['path'])]=e['historical_personal_reads'];ranges[(e['current_revision'],e['path'])]=e['current_personal_reads']
for e in receipt['support_personal_reads']:ranges[(e['revision'],e['path'])]=e['contiguously_displayed_body_ranges']
for f in report['findings_and_qualified_questions']:
 for r in f['evidence']:assert any(lo<=r['range'][0]<=r['range'][1]<=hi for lo,hi in ranges[(r['revision'],r['path'])]),(f['id'],r)
assert not proof['absent_paths'] and not h['missing_original_records'] and len(report['thirteen_lens_dispositions'])==13
print('Evidence integrity passed:',count,'original 059 records,',len(h['older_774_receipts'])+len(rec['records']),'older 774 records,',len(proof['paths']),'Git memberships,',len(objects),'raw commit/tree objects; exact original scope and citation ranges verified. No product execution.')
