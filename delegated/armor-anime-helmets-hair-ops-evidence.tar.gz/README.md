# Bounded evidence: original armor roles 2609–2610

`REPORT.json` contains source observations, thirteen bounded perspectives,
open questions, and historical relationships. The registrations were written
before the old and current personal source displays in `read-receipt.json`.
The 6533 copies were compared byte-for-byte and via Git membership without a
separate body-read claim. The pr-working snapshot had unrelated modifications;
f82 is the object transport revision, not its source HEAD.

`source/` and `support/` hold exact registered bytes; `git-objects/` and
`git-proofs.json` retain commit-to-blob membership proofs. The historical
manifest distinguishes exact originals (some losslessly gzip-compressed) from
a reconstructed selection of 059 queue rows and hash-linked published
records. Prior 774/059 reviewers and read scopes remain their own. The P16
patch recovery has separate authority and does not change the source identity
of these pr-working roles or promote any earlier record into checkpoint 3821.

Run `python3 verify-evidence.py` for evidence-integrity checks; it assumes that
the linked evidence remains at its recorded absolute local path. Relocated
links must be resolved by their SHA-256 before verifying. The verifier reads
source bytes but does not execute or validate the product. No test, example,
browser, renderer, simulation, fixture, or device code was run.
