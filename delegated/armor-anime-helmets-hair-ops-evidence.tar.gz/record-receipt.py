import datetime,hashlib,json
from pathlib import Path
p=Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();names=['registration.json','support-registration.json','support-registration-2.json','support-registration-3.json','support-registration-4.json','support-registration-5.json']
def complement(n,rs):
 used={i for a,z in rs for i in range(a,z+1)};r=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):r.append([start,i-1]);start=None
 return r
reads=[]
for n in names[1:]:
 for x in json.loads((p/n).read_bytes())['sources']:
  ranges=x['prospective_ranges'];reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['eof'],'displayed':ranges,'unread_complement':complement(x['eof'],ranges),'qualification':'Current bounded support only; no earlier or ordered-role credit. Test text was not executed.'})
assigned=[{'role':2609,'pr_working_actual_display':[[1,56]],'current_95e_actual_display':[[1,56]],'unread_old_and_current':[]},{'role':2610,'pr_working_actual_display':[[1,140],[141,280],[281,414]],'current_95e_actual_display':[[1,140],[141,280],[281,414]],'unread_old_and_current':[]}]
o={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in names],'assigned':assigned,'other_revision':'6533 copies were verified by byte/Git identity only, not separately displayed. The pr-working and 95e bodies were personally displayed separately.','prior_current':'ASSESSMENT-HELMET-FOOTWEAR-95E.json records another reviewer current support on helmets.rs 270–405. Earlier /root/hair_ops role2472 packet records independent full 95e armor_browser_probe.rs 1–229 and cbbb rig-quality 1–231; this packet separately registered and displayed current support 1–75. Neither earlier read is transferred or reattributed.','support':reads,'constraints':'Source and evidence inspection only; displayed tests were source text, never executed.'};(p/'read-receipt.json').write_text(json.dumps(o,indent=2)+'\n');print('receipt sha256',h((p/'read-receipt.json').read_bytes()))
