'''Evidence-integrity verification only; no product execution or validation.'''
import gzip,hashlib,json,tarfile
from datetime import datetime
from pathlib import Path
p=Path(__file__).resolve().parent
h=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
load=lambda n:json.loads((p/n).read_bytes())
reg=load('registration.json');rec=load('read-receipt.json');hist=load('historical-manifest.json');proof=load('git-proofs.json')
for x in hist['hash_links']:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
for x in hist['exact_original_files']:
 b=(p/x['local']).read_bytes();b=gzip.decompress(b) if x['content_encoding']=='gzip' else b
 assert len(b)==x['bytes'] and h(b)==x['sha256'] and Path(x['source_path']).read_bytes()==b,x['local']
for x in rec['registrations']:
 assert h((p/x['path']).read_bytes())==x['sha256']
 assert datetime.fromisoformat(load(x['path'])['registered_utc'])<=datetime.fromisoformat(rec['recorded_utc'])
registry=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/registry.json.gz')))
b=gzip.decompress(registry.read_bytes());assert h(b)==reg['registry_uncompressed_sha256'];original=json.loads(b)['files']
archive=Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/objects.tar.gz')));assert h(archive.read_bytes())==reg['source_archive_sha256']
with tarfile.open(archive,'r:gz') as t:
 for x in reg['rows']:
  b=(p/x['old_archive']).read_bytes();new=(p/f"source/{x['role']}-95e6.rs").read_bytes();prev=(p/f"source/{x['role']}-6533.rs").read_bytes()
  assert original[x['role']]==x['original_registry_record'] and h(b)==x['old_sha256']
  assert b==new==prev==t.extractfile(x['old_sha256']).read() and len(b.splitlines())==x['old_lines']
  rr=next(v for v in rec['assigned'] if v['role']==x['role']);assert rr['unread_old_and_current']==[]
  for readkey,plankey in [('pr_working_actual_display','pr_working'),('current_95e_actual_display','current95e')]:
   ranges=rr[readkey];assert [i for a,z in ranges for i in range(a,z+1)]==list(range(1,x['old_lines']+1))
   for a,z in ranges:assert any(c<=a<=z<=d for c,d in x['prospective_display'][plankey])
planned={}
for n in [x['path'] for x in rec['registrations'] if x['path'].startswith('support-registration')]:
 for x in load(n)['sources']:
  assert x['saved'] not in planned;planned[x['saved']]=x
for x in rec['support']:
 s=planned[x['saved']];b=(p/x['saved']).read_bytes();assert h(b)==x['sha256']==s['sha256'] and len(b)==s['bytes'] and len(b.splitlines())==x['eof']==s['eof']
 used=[]
 for a,z in x['displayed']+x['unread_complement']:
  assert 1<=a<=z<=x['eof'];used.extend(range(a,z+1))
 assert len(used)==x['eof'] and set(used)==set(range(1,x['eof']+1))
 for a,z in x['displayed']:assert any(c<=a<=z<=d for c,d in s['prospective_ranges'])
objects={}
for oid,x in proof['objects'].items():
 b=gzip.decompress((p/x['archive']).read_bytes());assert len(b)==x['bytes'] and h(b)==x['sha256'];assert hashlib.sha1(x['type'].encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;objects[oid]=b
def lookup(b,name):
 i=0
 while i<len(b):
  a=b.index(b' ',i);z=b.index(b'\0',a);nm=b[a+1:z].decode();mode=b[i:a].decode();oid=b[z+1:z+21].hex();i=z+21
  if nm==name:return mode,oid
 raise ValueError(name)
for x in proof['proofs']:
 current=objects[x['revision']].splitlines()[0].split()[1].decode();assert current==x['commit_tree']
 for s in x['chain']:
  assert current==s['tree'] and lookup(objects[current],s['name'])==(s['mode'],s['object']);current=s['object']
 b=(p/x['local']).read_bytes();assert current==x['blob']==blob(b) and h(b)==x['sha256']
oldarchive=hist['prior_774_records_in_published_archive']['archive']
with tarfile.open(oldarchive,'r:gz') as t:
 rr=[json.loads(v) for v in t.extractfile('historical/774-rig-source-range-registration.jsonl').read().splitlines()]
 additional=[json.loads(v) for v in t.extractfile('historical/774-rig-additional-contracts.jsonl').read().splitlines()]
 for x,aid in zip(reg['rows'],['RIG-ADMISSION03-ADDITIONAL-052','RIG-ADMISSION03-ADDITIONAL-055']):
  for ob in x['original_registry_record']['admission03_scope_observations']:assert rr[ob['row_1based']-1]==ob['original_record']
  a=next(v for v in additional if v['id']==aid);assert a['source_id']==x['original_registry_record']['source_id'] and a['sha256']==x['old_sha256'] and a['actual_source_ranges']==x['original_registry_record']['material_ranges']
qualfile=next(x for x in hist['exact_original_files'] if x['source_path'].endswith('/assignments/qualifications/qualification-evidence.json'))
qrecords=json.loads(gzip.decompress((p/qualfile['local']).read_bytes()))
q=next(x['record'] for x in qrecords if x.get('record',{}).get('id')=='RIG-ADMISSION03-SOURCE-QUALIFICATION-016')
assert q==reg['rows'][1]['original_registry_record']['admission03_scope_observations'][0]['local_qualifications'][0]
findingfile=next(x for x in hist['exact_original_files'] if x['source_path'].endswith('/rig/admission03/findings.jsonl'))
findings=[json.loads(v) for v in gzip.decompress((p/findingfile['local']).read_bytes()).splitlines()]
f=next(x for x in findings if x['id']=='RIG-ADMISSION03-F049');assert f['source_id']==reg['rows'][0]['original_registry_record']['source_id']
l11=load('historical/059--segovb--READ-L11-427.json')
for x in reg['rows']:
 a=next(y for y in l11['sources'] if y['original_index']==x['role'])
 assert a['sha256']==x['old_sha256'] and a['fresh_personal_body_reads']==x['original_registry_record']['material_ranges']
ext=next(y for y in l11['sources'] if y['registration'].endswith('REGISTRATION-SEGOVB-1530.json'))
assert ext['fresh_personal_body_reads']==[[222,248],[276,294],[381,384],[386,391]]
l12=load('historical/059--segovb--READ-L12-891.json');assert l12['root_personal_rereads']==[] and l12['delegated_attribution_preserved']
for x in reg['rows']:
 a=next(y for y in l12['rows'] if y['original_index']==x['role']);assert a['source_sha256']==x['old_sha256'] and '/root/lens12_frontier' in a['attribution']
 if x['role']==2609:assert a['fresh_personal_body_reads']==[[1,56]]
 else:assert a['fresh_personal_body_reads']==[] and a['assessed_ranges']==[[1,414]]
for i,ranges in [(1,[[1,195]]),(2,[[196,390]]),(3,[[391,414]])]:
 x=load(f'historical/059--parallel-l12-20261029--PARTIAL-CONNECTED-PAR-L12-883-HELMET-OWNER-00{i}.json')['rows'][0];assert x['fresh_personal_body_reads']==ranges and '/root/lens12_frontier' in x['attribution']
reuse=load('historical/059--parallel-l12-20261029--QUALIFIED-REUSE-PAR-L12-891-ORIGINAL2610.json');assert reuse['new_personal_body_reads']==[] and reuse['new_original_credit_now']==0
prior=next(x['path'] for x in hist['hash_links'] if x['path'].endswith('rig-quality-export-hair-evidence.tar.gz'))
with tarfile.open(prior,'r:gz') as t:
 priorrec=json.load(t.extractfile('read-receipt.json'));x=next(x for x in priorrec['roles'] if x['original_index']==2472)
 assert priorrec['agent']=='/root/hair_ops' and x['current_actual_display_ranges']==[[1,70],[71,140],[141,205],[206,229]] and x['rig_quality_actual_display_ranges']==[[1,70],[71,140],[141,205],[206,231]]
sel=load(hist['reconstructed_queue_selection']);qb=Path(sel['source_path']).read_bytes();assert h(qb)==sel['source_sha256'];entries=json.loads(qb)['entries']
for x in sel['rows']:assert entries[x['index']]==x['entry']
if (p/'MANIFEST.json').exists():
 for x in load('MANIFEST.json')['files']:
  b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],x['path']
print(f"PASS: two full old/current source read partitions; {len(proof['proofs'])} Git membership chains; {len(rec['support'])} support partitions; exact 774/059 historical records and reconstructed queue links. Evidence integrity only; no product execution or validation.")
