'''Prospective support registration; no body display.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/adventuresim-character-creator/src/anime_controls.rs',[[1,100]]),('crates/adventuresim-character-creator/src/runtime_equipment/warmup.rs',[[1,90]]),('assets_src/equipment/breastplate-design.json',[[1,300]])]
a=[]
for i,(path,ranges) in enumerate(paths,10):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());ranges=[[x,min(y,eof)] for x,y in ranges if x<=eof];saved=f'support/{i:02}.source';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Bounded support; no ordered-role credit. Source and asset text only, no product execution.'})
o={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration-3.json').write_text(json.dumps(o,indent=2)+'\n');print('sha256',hashlib.sha256((p/'support-registration-3.json').read_bytes()).hexdigest());print(json.dumps([{k:x[k] for k in ('path','eof','prospective_ranges')} for x in a],indent=2))
