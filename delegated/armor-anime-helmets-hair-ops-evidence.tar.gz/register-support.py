'''Prospective bounded support registration; no bodies displayed.'''
import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009'
paths=[('crates/fabelgeist-armor/src/lib.rs',[[145,215]]),('crates/fabelgeist-armor/src/design.rs',[[1,115]]),('crates/fabelgeist-armor/src/gpu/breastplate/mod.rs',[[85,130]]),('crates/fabelgeist-armor/src/gpu/helmet/mod.rs',[[1,100]]),('crates/fabelgeist-armor/src/gpu/helmet/parts.rs',[[105,145]]),('crates/adventuresim-character-creator/src/item_design.rs',[[1,55]]),('crates/adventuresim-character-creator/src/armor_recipes.rs',[[1,65]]),('crates/adventuresim-character-creator/src/design_input.rs',[[1,55]]),('crates/adventuresim-character-creator/src/garment/selection.rs',[[190,230]])]
a=[]
for i,(path,ranges) in enumerate(paths):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);eof=len(b.splitlines());ranges=[[x,min(y,eof)] for x,y in ranges if x<=eof];saved=f'support/{i:02}.rs';(p/saved).write_bytes(b);a.append({'path':path,'revision':rev,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'eof':eof,'saved':saved,'prospective_ranges':ranges,'qualification':'Bounded support; no future ordered-role or prior reviewer credit.'})
out={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':a};(p/'support-registration.json').write_text(json.dumps(out,indent=2)+'\n');print('support registration sha256',hashlib.sha256((p/'support-registration.json').read_bytes()).hexdigest());print(json.dumps([{k:x[k] for k in ('path','eof','prospective_ranges')} for x in a],indent=2))
