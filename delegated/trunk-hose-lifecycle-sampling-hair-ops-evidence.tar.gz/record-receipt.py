import datetime,hashlib,json
from pathlib import Path
p=Path('<LOCAL_PATH_0>');h=lambda b:hashlib.sha256(b).hexdigest();names=['registration.json','support-registration.json','support-registration-2.json'];w={0:[[105,188]],1:[[1,103]],2:[[1,60]],3:[[1,100],[101,190],[225,300],[470,550]],4:[[1,170]],5:[[1,110]],6:[[1,100]],7:[[610,710]],8:[[230,315]],9:[[115,145]],10:[[20,42],[565,610]],11:[[390,410]],12:[[310,330]]}
def complement(n,rs):
 used=set()
 for a,z in rs:used.update(range(a,z+1))
 r=[];start=None
 for i in range(1,n+2):
  if i<=n and i not in used and start is None:start=i
  if start is not None and (i==n+1 or i in used):r.append([start,i-1]);start=None
 return r
reads=[]
for n in names[1:]:
 for x in json.loads((p/n).read_bytes())['sources']:
  i=int(Path(x['saved']).stem);ranges=w[i]
  for a,b in ranges:assert any(q<=a<=b<=z for q,z in x['prospective_ranges'])
  reads.append({'path':x['path'],'revision':x['revision'],'saved':x['saved'],'sha256':x['sha256'],'eof':x['eof'],'displayed':ranges,'unread_complement':complement(x['eof'],ranges),'qualification':'Current bounded support only; no transfer of prior personal reads or ordered-role credit.'})
obj={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','registrations':[{'path':n,'sha256':h((p/n).read_bytes())} for n in names],'assigned':[{'role':2599,'pr_working_actual_display':[[1,56]],'current_95e_actual_display':[[1,56]],'unread_old_and_current':[]},{'role':2600,'pr_working_actual_display':[[1,15]],'current_95e_actual_display':[[1,15]],'unread_old_and_current':[]}],'other_revision':'6533 copies were verified by byte/Git identity only, not separately displayed. pr-working and 95e bodies personally displayed separately.','prior_own_support':'The earlier <LOCAL_PATH_1> receipt separately records 95e underlayer_armor.rs 1–145; this packet freshly registered and displayed 105–188 as support. Prior attribution is unchanged; no prior credit transferred to the current assigned role.','support':reads,'constraints':'Source and evidence inspection only. Any displayed tests were source text and not executed.'};(p/'read-receipt.json').write_text(json.dumps(obj,indent=2)+'\n');print('receipt sha',h((p/'read-receipt.json').read_bytes()),'supports',len(reads))
