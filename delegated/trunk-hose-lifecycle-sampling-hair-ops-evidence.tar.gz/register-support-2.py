import datetime,hashlib,json,subprocess
from pathlib import Path
p=Path('<LOCAL_PATH_0>');repo='<LOCAL_PATH_1>';rev='95e63628f9d70b8dd6e6fede64334696c6995009';h=lambda b:hashlib.sha256(b).hexdigest();specs=[('crates/fabelgeist-determinism/src/stream.rs',[[115,145]]),('crates/adventuresim-core/src/courtship.rs',[[20,42],[565,610]]),('crates/adventuresim-stdb-module/src/relationship/model.rs',[[390,410]]),('crates/adventuresim-stdb-module/src/relationship/reproduction.rs',[[310,330]])];sources=[]
for i,(path,ranges) in enumerate(specs,9):
 b=subprocess.check_output(['git','-C',repo,'show',rev+':'+path]);n=len(b.splitlines());loc=f'support/{i:02d}.rs';(p/loc).write_bytes(b);sources.append({'path':path,'revision':rev,'sha256':h(b),'bytes':len(b),'eof':n,'git_blob':subprocess.check_output(['git','-C',repo,'rev-parse',rev+':'+path],text=True).strip(),'saved':loc,'prospective_ranges':[[a,min(z,n)] for a,z in ranges if a<=n],'scope':'Separately registered bounded current support only.'})
(p/'support-registration-2.json').write_text(json.dumps({'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'agent':'/root/hair_ops','sources':sources},indent=2)+'\n');print('registration',h((p/'support-registration-2.json').read_bytes()));
for s in sources:print(s['saved'],s['path'],s['eof'],s['prospective_ranges'])
