# Bounded source evidence: original roles 2599–2600

`REPORT.json` describes the source observations, all thirteen bounded lens
perspectives, open questions, and attribution. `registration.json` and the two
support registrations were written before the displays recorded in
`read-receipt.json`. The archived pr-working and pinned 95e bodies were read
separately; 6533 file equality was verified without a separate read credit.
The pr-working snapshot had unrelated modifications; f82 is evidence
transport, not its source head. These roles are not dirty P16 sources.

`source/` and `support/` contain the exact registered bytes, while
`git-proofs.json` and `git-objects/` preserve commit-to-blob proofs.
`historical-manifest.json` distinguishes exact old records from a reconstructed
selection and identifies hash-linked published evidence dependencies. The
prior published archive retains the earlier 774 and 059 records; those
reviewers and ranges are not transferred to the present review. Historical
records are not promoted to checkpoint 3821.

Run `python3 verify-evidence.py` to verify evidence integrity, including
linked dependencies at their recorded paths and the frozen `MANIFEST.json`.
The verifier reads source bytes as evidence and does not execute product code.
Relocating the linked evidence requires resolving it by its recorded SHA-256;
the current verifier assumes the original absolute local paths. Verification
does not establish source behavior or supported-input reachability.
