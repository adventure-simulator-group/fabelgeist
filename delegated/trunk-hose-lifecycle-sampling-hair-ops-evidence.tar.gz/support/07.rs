//! Pure rules for strategic relationships, housing, and family growth.
//!
//! Persistence deliberately lives in the strategic module.  Keeping the
//! thresholds and clock arithmetic here makes reducers deterministic and lets
//! callers advance a long interval in exactly the same way as smaller chunks.

use adventuresim_world_schema::BASIS_POINTS_PER_WHOLE;
use adventuresim_world_schema::calendar::MINUTES_PER_DAY;
use adventuresim_world_schema::calendar::{MINUTES_PER_YEAR, StrategicMinute};
use serde::{Deserialize, Serialize};
use std::{fmt, str::FromStr};

mod child_identity;
pub use child_identity::{
    ChildIdentitySeed, ChildNameSeed, ChildSeeds, HouseholdPlacementSeed, PregnancyOrdinal,
    deterministic_child_seeds,
};

pub const ADULT_AGE_YEARS: u16 = 16;
pub const FORMAL_COURTSHIP_AFFINITY: f32 = 45.0;
pub const FORMAL_FATHER_APPROVAL_AFFINITY: f32 = 35.0;
pub const INFORMAL_COURTSHIP_AFFINITY: f32 = 75.0;
pub const AMOROUS_INFORMAL_MODIFIER: f32 = -10.0;
pub const PROPER_INFORMAL_MODIFIER: f32 = 10.0;
pub const WEDDING_NOTICE_MINUTES: u64 = MINUTES_PER_YEAR;
pub const GESTATION_MINUTES: u64 = 280 * MINUTES_PER_DAY;
pub const SOCIALIZING_QUANTUM_MINUTES: u16 = 15;
pub const HOUSING_BILLING_PERIOD_MINUTES: u64 = 30 * MINUTES_PER_DAY;
/// Necessities are charged to the holding's owner for every person supported
/// by that home at the due minute. Dependents cost less than adults but are
/// never free, so marriage and children have an explicit household cost.
pub const ADULT_NECESSITIES_PER_30_DAYS: u32 = 4;
pub const DEPENDENT_NECESSITIES_PER_30_DAYS: u32 = 2;
pub const CONCEPTION_QUANTUM_MINUTES: u64 = 60;
pub const CONCEPTION_CHANCE_PER_TEN_THOUSAND: u16 = 40;

const COURTSHIP_REJECTION_PREFIX: &str = "[courtship_rejection:";

/// Stable, machine-readable reasons returned across the reducer boundary.
/// Human prose may change without breaking gateway behavior.
#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub enum CourtshipRejectionCode {
    Affinity,
    FatherApproval,
    FormalRoute,
    MutualAttraction,
    ExclusiveCommitment,
    AlreadyMarried,
    CoLocation,
    IneligibleCharacter,
    CloseRelative,
    ActiveCourtshipRequired,
    CeremonySettlementRequired,
    ResidenceRequired,
}

impl CourtshipRejectionCode {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Affinity => "affinity",
            Self::FatherApproval => "father_approval",
            Self::FormalRoute => "formal_route",
            Self::MutualAttraction => "mutual_attraction",
            Self::ExclusiveCommitment => "exclusive_commitment",
            Self::AlreadyMarried => "already_married",
            Self::CoLocation => "co_location",
            Self::IneligibleCharacter => "ineligible_character",
            Self::CloseRelative => "close_relative",
            Self::ActiveCourtshipRequired => "active_courtship_required",
            Self::CeremonySettlementRequired => "ceremony_settlement_required",
            Self::ResidenceRequired => "residence_required",
        }
    }
}

impl fmt::Display for CourtshipRejectionCode {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.as_str())
    }
}

impl FromStr for CourtshipRejectionCode {
    type Err = ();

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value {
            "affinity" => Ok(Self::Affinity),
            "father_approval" => Ok(Self::FatherApproval),
            "formal_route" => Ok(Self::FormalRoute),
            "mutual_attraction" => Ok(Self::MutualAttraction),
            "exclusive_commitment" => Ok(Self::ExclusiveCommitment),
            "already_married" => Ok(Self::AlreadyMarried),
            "co_location" => Ok(Self::CoLocation),
            "ineligible_character" => Ok(Self::IneligibleCharacter),
            "close_relative" => Ok(Self::CloseRelative),
            "active_courtship_required" => Ok(Self::ActiveCourtshipRequired),
            "ceremony_settlement_required" => Ok(Self::CeremonySettlementRequired),
            "residence_required" => Ok(Self::ResidenceRequired),
            _ => Err(()),
        }
    }
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct CourtshipRejection {
    pub code: CourtshipRejectionCode,
    pub detail: String,
}

impl CourtshipRejection {
    pub fn new(code: CourtshipRejectionCode, detail: impl Into<String>) -> Self {
        Self {
            code,
            detail: detail.into(),
        }
    }
}

/// Encode the stable reducer transport envelope. Domain code should carry
/// [`CourtshipRejection`] directly and call this only at a string ABI.
pub fn encode_courtship_rejection(rejection: &CourtshipRejection) -> String {
    format!(
        "{COURTSHIP_REJECTION_PREFIX}{}] {}",
        rejection.code, rejection.detail
    )
}

/// Parse the reducer transport envelope once at a string ABI.
pub fn parse_courtship_rejection(value: &str) -> Option<CourtshipRejection> {
    let start = value.find(COURTSHIP_REJECTION_PREFIX)? + COURTSHIP_REJECTION_PREFIX.len();
    let (code, detail) = value[start..].split_once(']')?;
    Some(CourtshipRejection {
        code: code.parse().ok()?,
        detail: detail.strip_prefix(' ').unwrap_or(detail).to_owned(),
    })
}

/// Residence Leisure is one refreshable source which lasts for one week.
pub const RESIDENCE_MORALE_CAP_MILLI: u32 = 8_000;
pub const RESIDENCE_MORALE_DURATION_MINUTES: u64 = 7 * MINUTES_PER_DAY;
/// Time with a spouse has a stronger, longer-lived refreshable benefit.
pub const SPOUSE_LEISURE_MORALE_CAP_MILLI: u32 = 12_000;
pub const SPOUSE_LEISURE_MORALE_DURATION_MINUTES: u64 = 30 * MINUTES_PER_DAY;
/// Both refreshable sources may coexist, but cannot exceed this total.
pub const LEISURE_MORALE_STACK_CAP_MILLI: u32 = 16_000;
pub const SPOUSE_MORALE_MILLI_PER_JOINT_MINUTE: u32 = 2;

/// Named rather than magic-number housing economy.  All amounts are paid in
/// the settlement's ordinary inventory currency.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct HousingEconomy {
    pub purchase_price: u32,
    pub rent_per_30_days: u32,
    pub owner_maintenance_per_30_days: u32,
    pub property_tax_per_30_days: u32,
    pub leisure_morale_basis_points: u16,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ResidencePeriodCharge {
    pub base_housing: u64,
    pub adult_necessities: u64,
    pub dependent_necessities: u64,
}

impl ResidencePeriodCharge {
    pub const fn total(self) -> u64 {
        self.base_housing
            .saturating_add(self.adult_necessities)
            .saturating_add(self.dependent_necessities)
    }
}

/// Produce the auditable line items for one holding and one due date.
pub const fn residence_period_charge(
    economy: HousingEconomy,
    owned: bool,
    supported_adults: u32,
    supported_dependents: u32,
) -> ResidencePeriodCharge {
    ResidencePeriodCharge {
        base_housing: if owned {
            economy
                .owner_maintenance_per_30_days
                .saturating_add(economy.property_tax_per_30_days) as u64
        } else {
            economy.rent_per_30_days as u64
        },
        adult_necessities: supported_adults.saturating_mul(ADULT_NECESSITIES_PER_30_DAYS) as u64,
        dependent_necessities: supported_dependents
            .saturating_mul(DEPENDENT_NECESSITIES_PER_30_DAYS)
            as u64,
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[cfg_attr(feature = "spacetimedb", derive(spacetimedb::SpacetimeType))]
pub enum HousingTier {
    Cheap,
    Moderate,
    Fancy,
}

impl HousingTier {
    pub const ALL: [Self; 3] = [Self::Cheap, Self::Moderate, Self::Fancy];

    pub const fn id(self) -> &'static str {
        match self {
            Self::Cheap => "cheap",
            Self::Moderate => "moderate",
            Self::Fancy => "fancy",
        }
    }

    pub const fn economy(self) -> HousingEconomy {
        match self {
            Self::Cheap => HousingEconomy {
                purchase_price: 120,
                rent_per_30_days: 8,
                owner_maintenance_per_30_days: 2,
                property_tax_per_30_days: 2,
                leisure_morale_basis_points: 11_000,
            },
            Self::Moderate => HousingEconomy {
                purchase_price: 500,
                rent_per_30_days: 24,
                owner_maintenance_per_30_days: 6,
                property_tax_per_30_days: 6,
                leisure_morale_basis_points: 13_000,
            },
            Self::Fancy => HousingEconomy {
                purchase_price: 1_800,
                rent_per_30_days: 70,
                owner_maintenance_per_30_days: 16,
                property_tax_per_30_days: 18,
                leisure_morale_basis_points: 16_000,
            },
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum HousingCatalogError {
    WrongOfferCount,
    WrongTierOrder,
    ValuesNotStrictlyOrdered,
    OwnershipNotCheaperThanRent,
}

/// Validate the authored invariant that every settlement exposes exactly one
/// offer in each tier, with every price and benefit strictly increasing.
pub fn validate_housing_catalog(
    offers: &[(HousingTier, HousingEconomy)],
) -> Result<(), HousingCatalogError> {
    if offers.len() != HousingTier::ALL.len() {
        return Err(HousingCatalogError::WrongOfferCount);
    }
    if !offers
        .iter()
        .zip(HousingTier::ALL)
        .all(|((actual, _), expected)| *actual == expected)
    {
        return Err(HousingCatalogError::WrongTierOrder);
    }
    if offers.iter().any(|(_, economy)| {
        economy
            .owner_maintenance_per_30_days
            .saturating_add(economy.property_tax_per_30_days)
            >= economy.rent_per_30_days
    }) {
        return Err(HousingCatalogError::OwnershipNotCheaperThanRent);
    }
    let ordered = offers.windows(2).all(|pair| {
        let low = pair[0].1;
        let high = pair[1].1;
        low.purchase_price < high.purchase_price
            && low.rent_per_30_days < high.rent_per_30_days
            && low.owner_maintenance_per_30_days < high.owner_maintenance_per_30_days
            && low.property_tax_per_30_days < high.property_tax_per_30_days
            && low.leisure_morale_basis_points < high.leisure_morale_basis_points
    });
    if !ordered {
        return Err(HousingCatalogError::ValuesNotStrictlyOrdered);
    }
    Ok(())
}

pub fn authored_housing_catalog() -> [(HousingTier, HousingEconomy); 3] {
    HousingTier::ALL.map(|tier| (tier, tier.economy()))
}

/// Chronological due dates beginning at `next_due_minute`, inclusive of the
/// requested frontier. Overflow terminates the finite authoritative timeline.
#[derive(Clone, Copy, Debug)]
pub struct DuePeriods {
    next: Option<StrategicMinute>,
    through_minute: StrategicMinute,
}

impl Iterator for DuePeriods {
    type Item = StrategicMinute;

    fn next(&mut self) -> Option<Self::Item> {
        let due = self.next?;
        if due > self.through_minute {
            self.next = None;
            return None;
        }
        self.next = due.checked_add_minutes(HOUSING_BILLING_PERIOD_MINUTES);
        Some(due)
    }
}

pub const fn due_periods(
    next_due_minute: StrategicMinute,
    through_minute: StrategicMinute,
) -> DuePeriods {
    DuePeriods {
        next: Some(next_due_minute),
        through_minute,
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DueSettlementPlan {
    pub periods_due: u64,
    pub periods_paid: u64,
    pub amount_spent: u64,
    pub funds_remaining: u64,
    /// The next date to persist after all successful payments. On failure this
    /// remains the first unpaid date, which makes retry and chunk behavior
    /// unambiguous.
    pub next_due_minute: StrategicMinute,
    pub first_unpaid_due_minute: Option<StrategicMinute>,
}

/// Settle recurring bills one period at a time. A bill is indivisible: funds
/// below one complete charge are retained and the first unpaid date is
/// reported. Calling this through an intermediate frontier and then the final
/// frontier produces the same plan as one call when the returned funds and
/// next due date are carried forward.
pub fn plan_due_period_settlement(
    next_due_minute: StrategicMinute,
    through_minute: StrategicMinute,
    available_funds: u64,
    charge_per_period: u64,
) -> DueSettlementPlan {
    let periods_due = due_periods(next_due_minute, through_minute).count() as u64;
    let affordable = available_funds
        .checked_div(charge_per_period)
        .unwrap_or(periods_due);
    let periods_paid = periods_due.min(affordable);
    let amount_spent = periods_paid.saturating_mul(charge_per_period);
    let first_unpaid_due_minute = (periods_paid < periods_due).then(|| {
        next_due_minute
            .saturating_add_minutes(periods_paid.saturating_mul(HOUSING_BILLING_PERIOD_MINUTES))
    });
    DueSettlementPlan {
        periods_due,
        periods_paid,
        amount_spent,
        funds_remaining: available_funds.saturating_sub(amount_spent),
        next_due_minute: next_due_minute
            .saturating_add_minutes(periods_paid.saturating_mul(HOUSING_BILLING_PERIOD_MINUTES)),
        first_unpaid_due_minute,
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct RefreshableMorale {
    pub milli_points: u32,
    pub expires_at_minute: StrategicMinute,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RefreshableMoraleSpec {
    pub cap_milli: u32,
    pub duration_minutes: u64,
}

pub const RESIDENCE_MORALE_SPEC: RefreshableMoraleSpec = RefreshableMoraleSpec {
    cap_milli: RESIDENCE_MORALE_CAP_MILLI,
    duration_minutes: RESIDENCE_MORALE_DURATION_MINUTES,
};
pub const SPOUSE_LEISURE_MORALE_SPEC: RefreshableMoraleSpec = RefreshableMoraleSpec {
    cap_milli: SPOUSE_LEISURE_MORALE_CAP_MILLI,
    duration_minutes: SPOUSE_LEISURE_MORALE_DURATION_MINUTES,
};

const fn min_u32(left: u32, right: u32) -> u32 {
    if left < right { left } else { right }
}

const fn min_u64(left: u64, right: u64) -> u64 {
    if left < right { left } else { right }
}

/// Add realized morale to one durable refreshable source. Expired value never
/// contributes, zero gain does not prolong it, and refreshes cannot stack
/// beyond the source cap.
pub const fn refresh_morale(
    current: RefreshableMorale,
    now_minute: StrategicMinute,
    earned_milli: u32,
    spec: RefreshableMoraleSpec,
) -> RefreshableMorale {
    if earned_milli == 0 {
        return current;
    }
    let live = if current.expires_at_minute.is_after(now_minute) {
        current.milli_points
    } else {
        0
    };
    RefreshableMorale {
        milli_points: min_u32(live.saturating_add(earned_milli), spec.cap_milli),
        expires_at_minute: now_minute.saturating_add_minutes(spec.duration_minutes),
    }
}

pub const fn bounded_leisure_morale_total(
    residence: RefreshableMorale,
    spouse: RefreshableMorale,
    at_minute: StrategicMinute,
) -> u32 {
    let residence = if residence.expires_at_minute.is_after(at_minute) {
        min_u32(residence.milli_points, RESIDENCE_MORALE_CAP_MILLI)
    } else {
        0
    };
    let spouse = if spouse.expires_at_minute.is_after(at_minute) {
        min_u32(spouse.milli_points, SPOUSE_LEISURE_MORALE_CAP_MILLI)
    } else {
        0
    };
    min_u32(
        residence.saturating_add(spouse),
        LEISURE_MORALE_STACK_CAP_MILLI,
    )
}

/// Refresh one Leisure source while reserving room for the other source's
/// still-live value. Calling this from either source updater gives the same
/// combined cap and ignores expired counterpart value.
pub const fn refresh_bounded_leisure_morale(
    current: RefreshableMorale,
    other: RefreshableMorale,
    now_minute: StrategicMinute,
    earned_milli: u32,
    spec: RefreshableMoraleSpec,
) -> RefreshableMorale {
    let refreshed = refresh_morale(current, now_minute, earned_milli, spec);
    if earned_milli == 0 {
        return refreshed;
    }
    let other_live = if other.expires_at_minute.is_after(now_minute) {
        other.milli_points
    } else {
        0
    };
    RefreshableMorale {
        milli_points: min_u32(
            refreshed.milli_points,
            LEISURE_MORALE_STACK_CAP_MILLI.saturating_sub(other_live),
        ),
        expires_at_minute: refreshed.expires_at_minute,
    }
}

/// Residence comfort is the tier's premium over baseline realized Leisure.
/// Integer milli-morale avoids checkpoint-dependent float rounding.
pub const fn residence_leisure_bonus_milli(
    realized_baseline_milli: u32,
    leisure_morale_basis_points: u16,
) -> u32 {
    let premium_basis_points = leisure_morale_basis_points.saturating_sub(BASIS_POINTS_PER_WHOLE);
    min_u64(
        realized_baseline_milli as u64 * premium_basis_points as u64
            / BASIS_POINTS_PER_WHOLE as u64,
        u32::MAX as u64,
    ) as u32
}

pub const fn spouse_leisure_earned_milli(joint_leisure_minutes: u64) -> u32 {
    min_u64(
        joint_leisure_minutes.saturating_mul(SPOUSE_MORALE_MILLI_PER_JOINT_MINUTE as u64),
        u32::MAX as u64,
    ) as u32
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LeisureInterval<'a> {
    pub start_minute: StrategicMinute,
    pub end_minute: StrategicMinute,
    pub location_id: &'a str,
}

/// Intersect two realized Leisure spans. Invalid/reversed spans accrue zero,
/// as do spans at different locations.
pub fn joint_leisure_minutes(left: LeisureInterval<'_>, right: LeisureInterval<'_>) -> u64 {
    if left.location_id != right.location_id {
        return 0;
    }
    left.end_minute
        .min(right.end_minute)
        .elapsed_since(left.start_minute.max(right.start_minute))
}

/// Accrue a joint span inside an arbitrary checkpoint interval. Integer
/// intersection makes adjacent checkpoints telescope without a remainder.
pub fn joint_leisure_minutes_in(
    left: LeisureInterval<'_>,
    right: LeisureInterval<'_>,
    checkpoint_start: StrategicMinute,
    checkpoint_end: StrategicMinute,
) -> u64 {
    joint_leisure_minutes(
        LeisureInterval {
            start_minute: left.start_minute.max(checkpoint_start),
            end_minute: left.end_minute.min(checkpoint_end),
            location_id: left.location_id,
        },
        LeisureInterval {
            start_minute: right.start_minute.max(checkpoint_start),
            end_minute: right.end_minute.min(checkpoint_end),
            location_id: right.location_id,
        },
    )
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MinuteSpan {
    pub start_minute: StrategicMinute,
    pub end_minute: StrategicMinute,
}

/// Return candidate coverage not already represented by existing spans.
/// Existing spans may be unordered, overlapping, or duplicated; the result is
/// sorted and disjoint so retries cannot create additional Leisure.
pub fn uncovered_minute_spans(
    candidate: MinuteSpan,
    existing: impl IntoIterator<Item = MinuteSpan>,
) -> Vec<MinuteSpan> {
    if candidate.end_minute <= candidate.start_minute {
        return Vec::new();
    }
    let mut covered: Vec<_> = existing
        .into_iter()
        .filter_map(|span| {
            let start = candidate.start_minute.max(span.start_minute);
            let end = candidate.end_minute.min(span.end_minute);
            (end > start).then_some(MinuteSpan {
                start_minute: start,
                end_minute: end,
            })
        })
        .collect();
    covered.sort_by_key(|span| (span.start_minute, span.end_minute));
    let mut result = Vec::new();
    let mut cursor = candidate.start_minute;
    for span in covered {
        if span.start_minute > cursor {
            result.push(MinuteSpan {
                start_minute: cursor,
                end_minute: span.start_minute,
            });
        }
        cursor = cursor.max(span.end_minute);
        if cursor >= candidate.end_minute {
            break;
        }
    }
    if cursor < candidate.end_minute {
        result.push(MinuteSpan {
            start_minute: cursor,
            end_minute: candidate.end_minute,
        });
    }
    result
}

/// Stable lifecycle identity derived from separately framed context fields.
pub fn stable_lifecycle_hash(domain: &str, parts: &[&str]) -> u64 {
    let fields: Vec<_> = parts.iter().map(|part| part.as_bytes()).collect();
    fabelgeist_determinism::Seed::derive(
        domain.as_bytes(),
        fabelgeist_determinism::StreamId::new("lifecycle.identity"),
        &fields,
    )
    .to_u64()
}

pub fn daily_location_target_score(
    actor_id: &str,
    location_id: &str,
    calendar_day: u64,
    target_id: &str,
) -> u64 {
    let day = calendar_day.to_string();
    stable_lifecycle_hash(
        "daily-location-target",
        &[actor_id, location_id, &day, target_id],
    )
}

pub fn select_stable_target_by_score<'a>(
    candidates: impl IntoIterator<Item = &'a str>,
    score: impl Fn(&str) -> u64,
) -> Option<&'a str> {
    candidates
        .into_iter()
        .min_by_key(|candidate| (score(candidate), *candidate))
}

/// Pick the lowest deterministic score. Character ID is the stable final tie
/// break, so storage or iteration order cannot affect an ambiguous choice.
pub fn select_daily_location_target<'a>(
    actor_id: &str,
    location_id: &str,
    calendar_day: u64,
    candidates: impl IntoIterator<Item = &'a str>,
) -> Option<&'a str> {
    select_stable_target_by_score(candidates, |candidate| {
        daily_location_target_score(actor_id, location_id, calendar_day, candidate)
    })
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ConceptionQuantumState {
    pub conserved_joint_minutes: u8,
    pub next_trial_ordinal: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ConceptionTrial {
    pub ordinal: u64,
    /// One-based minute offset from the start of this accrual interval.
    pub crossing_offset_minutes: u64,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ConceptionQuantumPlan {
    pub trials: Vec<ConceptionTrial>,
    pub state: ConceptionQuantumState,
}

/// Cross one deterministic conception trial per conserved joint Leisure hour.
/// Persisting the returned remainder and ordinal makes arbitrary checkpoint
/// partitioning equivalent to one whole interval.
pub fn conception_quantum_plan(
    state: ConceptionQuantumState,
    additional_joint_minutes: u64,
) -> ConceptionQuantumPlan {
    let carried = u64::from(state.conserved_joint_minutes) % CONCEPTION_QUANTUM_MINUTES;
    let first_crossing = CONCEPTION_QUANTUM_MINUTES - carried;
    let crossing_count = if additional_joint_minutes < first_crossing {
        0
    } else {
        1 + (additional_joint_minutes - first_crossing) / CONCEPTION_QUANTUM_MINUTES
    };
    let trials = (0..crossing_count)
        .map(|index| ConceptionTrial {
            ordinal: state.next_trial_ordinal.saturating_add(index),
            crossing_offset_minutes: first_crossing
                .saturating_add(index.saturating_mul(CONCEPTION_QUANTUM_MINUTES)),
        })
        .collect();
    ConceptionQuantumPlan {
        trials,
        state: ConceptionQuantumState {
            conserved_joint_minutes: ((carried
                + additional_joint_minutes % CONCEPTION_QUANTUM_MINUTES)
                % CONCEPTION_QUANTUM_MINUTES) as u8,
            next_trial_ordinal: state.next_trial_ordinal.saturating_add(crossing_count),
        },
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CourtshipDisposition {
    Amorous,
    Neutral,
    Proper,
}

pub const fn informal_affinity_threshold(disposition: CourtshipDisposition) -> f32 {
    match disposition {
        CourtshipDisposition::Amorous => INFORMAL_COURTSHIP_AFFINITY + AMOROUS_INFORMAL_MODIFIER,
        CourtshipDisposition::Neutral => INFORMAL_COURTSHIP_AFFINITY,
        CourtshipDisposition::Proper => INFORMAL_COURTSHIP_AFFINITY + PROPER_INFORMAL_MODIFIER,
    }
}

/// A stable Bernoulli trial keyed by a whole calendar day.  `numerator` is in
/// ten-thousandths; callers choose a hash-derived value in the same range.
pub const fn succeeds_daily_trial(day_entropy: u16, numerator: u16) -> bool {
    day_entropy < numerator
}

/// Count daily event boundaries crossed by an interval.  The event's state is
/// keyed by that day, so callers can process each returned day exactly once.
pub fn crossed_days(
    start_minute: StrategicMinute,
    end_minute: StrategicMinute,
) -> impl Iterator<Item = u64> {
    let first = start_minute.day_index();
    let last = end_minute.day_index();
    (first + 1)..=last
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn courtship_rejection_codes_round_trip_without_parsing_human_prose() {
        let rejection = CourtshipRejection::new(
            CourtshipRejectionCode::FatherApproval,
            "The family does not approve",
        );
        let encoded = encode_courtship_rejection(&rejection);
        assert_eq!(
            parse_courtship_rejection(&format!("Reducer failed: {encoded}")),
            Some(rejection.clone())
        );
        assert_eq!(
            parse_courtship_rejection("The family does not approve"),
            None
        );
        let changed = CourtshipRejection::new(
            CourtshipRejectionCode::FatherApproval,
            "Entirely different wording",
        );
        assert_eq!(
            parse_courtship_rejection(&encode_courtship_rejection(&changed))
                .unwrap()
                .code,
            rejection.code
        );
        assert_eq!(
            serde_json::from_value::<CourtshipRejection>(serde_json::to_value(&rejection).unwrap())
                .unwrap(),
            rejection
        );
    }

    #[test]
    fn courtship_trait_thresholds_are_ordered() {
        assert!(
            informal_affinity_threshold(CourtshipDisposition::Amorous)
                < informal_affinity_threshold(CourtshipDisposition::Neutral)
        );
        assert!(
            informal_affinity_threshold(CourtshipDisposition::Neutral)
                < informal_affinity_threshold(CourtshipDisposition::Proper)
        );
    }

    #[test]
    fn day_boundaries_are_chunk_invariant() {
        let start = StrategicMinute::new(20);
        let middle = StrategicMinute::new(MINUTES_PER_DAY + 20);
        let end = StrategicMinute::new(3 * MINUTES_PER_DAY + 20);
        let whole: Vec<_> = crossed_days(start, end).collect();
        let mut split = crossed_days(start, middle).collect::<Vec<_>>();
        split.extend(crossed_days(middle, end));
        assert_eq!(whole, split);
    }

    #[test]
    fn authored_housing_is_exactly_three_strictly_ordered_tiers() {
        let catalog = authored_housing_catalog();
        assert_eq!(validate_housing_catalog(&catalog), Ok(()));

        assert_eq!(
            validate_housing_catalog(&catalog[..2]),
            Err(HousingCatalogError::WrongOfferCount)
        );
        let mut swapped = catalog;
        swapped.swap(0, 1);
        assert_eq!(
            validate_housing_catalog(&swapped),
            Err(HousingCatalogError::WrongTierOrder)
        );
        let mut flat = catalog;
        flat[1].1.purchase_price = flat[0].1.purchase_price;
        assert_eq!(
            validate_housing_catalog(&flat),
            Err(HousingCatalogError::ValuesNotStrictlyOrdered)
        );
        let mut costly_owner = catalog;
        costly_owner[0].1.owner_maintenance_per_30_days = costly_owner[0].1.rent_per_30_days;
        assert_eq!(
            validate_housing_catalog(&costly_owner),
            Err(HousingCatalogError::OwnershipNotCheaperThanRent)
        );
    }

    #[test]
    fn due_periods_are_chronological_and_chunk_invariant() {
        let first = StrategicMinute::new(100);
        let through = first.saturating_add_minutes(4 * HOUSING_BILLING_PERIOD_MINUTES + 12);
        let whole: Vec<_> = due_periods(first, through).collect();
        let checkpoint = first.saturating_add_minutes(2 * HOUSING_BILLING_PERIOD_MINUTES - 1);
        let mut chunks: Vec<_> = due_periods(first, checkpoint).collect();
        let next = chunks.last().map_or(first, |paid| {
            paid.saturating_add_minutes(HOUSING_BILLING_PERIOD_MINUTES)
        });
        chunks.extend(due_periods(next, through));
        assert_eq!(whole, chunks);
        assert_eq!(whole.len(), 5);
        assert!(whole.windows(2).all(|pair| pair[1] > pair[0]));
    }

    #[test]
    fn due_plan_retains_partial_funds_and_stops_at_first_unpaid_period() {
        let first = StrategicMinute::new(HOUSING_BILLING_PERIOD_MINUTES);
        let through = StrategicMinute::new(4 * HOUSING_BILLING_PERIOD_MINUTES);
        let plan = plan_due_period_settlement(first, through, 25, 8);
        assert_eq!(
            plan,
            DueSettlementPlan {
                periods_due: 4,
                periods_paid: 3,
                amount_spent: 24,
                funds_remaining: 1,
                next_due_minute: StrategicMinute::new(4 * HOUSING_BILLING_PERIOD_MINUTES),
                first_unpaid_due_minute: Some(StrategicMinute::new(
                    4 * HOUSING_BILLING_PERIOD_MINUTES
                )),
            }
        );

        let whole = plan_due_period_settlement(first, through, 40, 8);
        let early = plan_due_period_settlement(
            first,
            StrategicMinute::new(2 * HOUSING_BILLING_PERIOD_MINUTES),
            40,
            8,
        );
        let late =
            plan_due_period_settlement(early.next_due_minute, through, early.funds_remaining, 8);
        assert_eq!(whole.periods_paid, early.periods_paid + late.periods_paid);
        assert_eq!(whole.amount_spent, early.amount_spent + late.amount_spent);
        assert_eq!(whole.funds_remaining, late.funds_remaining);
        assert_eq!(whole.next_due_minute, late.next_due_minute);
        assert_eq!(whole.first_unpaid_due_minute, late.first_unpaid_due_minute);
    }

    #[test]
    fn owned_property_is_cheaper_and_supported_people_add_necessities() {
        let economy = HousingTier::Moderate.economy();
        let renter = residence_period_charge(economy, false, 1, 0);
        let owner = residence_period_charge(economy, true, 1, 0);
        assert!(owner.base_housing < renter.base_housing);
        assert!(owner.base_housing >= u64::from(economy.property_tax_per_30_days));

        let family = residence_period_charge(economy, true, 2, 2);
        assert_eq!(
            family.total() - owner.total(),
            u64::from(ADULT_NECESSITIES_PER_30_DAYS + 2 * DEPENDENT_NECESSITIES_PER_30_DAYS)
        );
    }

    #[test]
    fn refreshable_morale_caps_expires_and_has_a_stack_bound() {
        let at = StrategicMinute::new(100);
        let residence = refresh_morale(
            RefreshableMorale::default(),
            at,
            RESIDENCE_MORALE_CAP_MILLI + 500,
            RESIDENCE_MORALE_SPEC,
        );
        let spouse = refresh_morale(
            RefreshableMorale::default(),
            at,
            SPOUSE_LEISURE_MORALE_CAP_MILLI + 500,
            SPOUSE_LEISURE_MORALE_SPEC,
        );
        assert_eq!(residence.milli_points, RESIDENCE_MORALE_CAP_MILLI);
        assert_eq!(spouse.milli_points, SPOUSE_LEISURE_MORALE_CAP_MILLI);
        assert_eq!(
            bounded_leisure_morale_total(residence, spouse, at),
            LEISURE_MORALE_STACK_CAP_MILLI
        );
        assert_eq!(
            bounded_leisure_morale_total(
                residence,
                spouse,
                at.saturating_add_minutes(RESIDENCE_MORALE_DURATION_MINUTES)
            ),
            SPOUSE_LEISURE_MORALE_CAP_MILLI
        );
        assert_eq!(
            refresh_morale(
                residence,
                StrategicMinute::new(200),
                0,
                RESIDENCE_MORALE_SPEC
            ),
            residence
        );
        assert_eq!(residence_leisure_bonus_milli(4_000, 11_000), 400);
        assert_eq!(residence_leisure_bonus_milli(4_000, 10_000), 0);
        assert_eq!(spouse_leisure_earned_milli(60), 120);
        assert_eq!(
            spouse_leisure_earned_milli(17) + spouse_leisure_earned_milli(43),
            spouse_leisure_earned_milli(60)
        );

        let residence_first = refresh_bounded_leisure_morale(
            RefreshableMorale::default(),
            RefreshableMorale::default(),
            at,
            8_000,
            RESIDENCE_MORALE_SPEC,
        );
        let spouse_second = refresh_bounded_leisure_morale(
            RefreshableMorale::default(),
            residence_first,
            at,
            12_000,
            SPOUSE_LEISURE_MORALE_SPEC,
        );
        let spouse_first = refresh_bounded_leisure_morale(
            RefreshableMorale::default(),
            RefreshableMorale::default(),
            at,
            12_000,
            SPOUSE_LEISURE_MORALE_SPEC,
        );
        let residence_second = refresh_bounded_leisure_morale(
            RefreshableMorale::default(),
            spouse_first,
            at,
            8_000,
            RESIDENCE_MORALE_SPEC,
        );
        assert_eq!(
            residence_first.milli_points + spouse_second.milli_points,
            LEISURE_MORALE_STACK_CAP_MILLI
        );
        assert_eq!(
            spouse_first.milli_points + residence_second.milli_points,
            LEISURE_MORALE_STACK_CAP_MILLI
        );
        let after_spouse_expiry = refresh_bounded_leisure_morale(
            residence_second,
            spouse_first,
            spouse_first.expires_at_minute,
            8_000,
            RESIDENCE_MORALE_SPEC,
        );
        assert_eq!(after_spouse_expiry.milli_points, RESIDENCE_MORALE_CAP_MILLI);
    }

    #[test]
    fn deterministic_target_selection_is_order_independent_and_ties_by_id() {
        let forward =
            select_daily_location_target("actor", "wittenberg", 42, ["c", "a", "b"]).unwrap();
        let reverse =
            select_daily_location_target("actor", "wittenberg", 42, ["b", "a", "c"]).unwrap();
        assert_eq!(forward, reverse);
        assert_eq!(
            select_stable_target_by_score(["zeta", "alpha"], |_| 7),
            Some("alpha")
        );
        assert_ne!(
            daily_location_target_score("actor", "wittenberg", 42, "a"),
            daily_location_target_score("actor", "wittenberg", 43, "a")
        );
    }

    #[test]
    fn joint_leisure_requires_overlap_and_identical_location() {
        let first = LeisureInterval {
            start_minute: StrategicMinute::new(100),
            end_minute: StrategicMinute::new(220),
            location_id: "town",
        };
        let overlapping = LeisureInterval {
            start_minute: StrategicMinute::new(160),
            end_minute: StrategicMinute::new(280),
            location_id: "town",
        };
        assert_eq!(joint_leisure_minutes(first, overlapping), 60);
        assert_eq!(
            joint_leisure_minutes(
                first,
                LeisureInterval {
                    location_id: "road",
                    ..overlapping
                }
            ),
            0
        );
        assert_eq!(
            joint_leisure_minutes(
                first,
                LeisureInterval {
                    start_minute: StrategicMinute::new(220),
                    end_minute: StrategicMinute::new(300),
                    location_id: "town",
                }
            ),
            0
        );
    }

    #[test]
    fn joint_leisure_checkpoint_accrual_telescopes() {
        let first = LeisureInterval {
            start_minute: StrategicMinute::new(10),
            end_minute: StrategicMinute::new(310),
            location_id: "town",
        };
        let second = LeisureInterval {
            start_minute: StrategicMinute::new(80),
            end_minute: StrategicMinute::new(260),
            location_id: "town",
        };
        let whole = joint_leisure_minutes_in(
            first,
            second,
            StrategicMinute::new(0),
            StrategicMinute::new(400),
        );
        let chunked = joint_leisure_minutes_in(
            first,
            second,
            StrategicMinute::new(0),
            StrategicMinute::new(137),
        ) + joint_leisure_minutes_in(
            first,
            second,
            StrategicMinute::new(137),
            StrategicMinute::new(400),
        );
        assert_eq!(whole, 180);
        assert_eq!(whole, chunked);
    }

    #[test]
    fn retries_and_alternative_slices_only_return_uncovered_time() {
        let candidate = MinuteSpan {
            start_minute: StrategicMinute::new(100),
            end_minute: StrategicMinute::new(300),
        };
        let existing = [
            MinuteSpan {
                start_minute: StrategicMinute::new(180),
                end_minute: StrategicMinute::new(240),
            },
            MinuteSpan {
                start_minute: StrategicMinute::new(120),
                end_minute: StrategicMinute::new(200),
            },
            MinuteSpan {
                start_minute: StrategicMinute::new(120),
                end_minute: StrategicMinute::new(200),
            },
        ];
        assert_eq!(
            uncovered_minute_spans(candidate, existing),
            vec![
                MinuteSpan {
                    start_minute: StrategicMinute::new(100),
                    end_minute: StrategicMinute::new(120),
                },
                MinuteSpan {
                    start_minute: StrategicMinute::new(240),
                    end_minute: StrategicMinute::new(300),
                },
            ]
        );
        assert!(uncovered_minute_spans(candidate, [candidate]).is_empty());
    }

    #[test]
    fn conception_quantum_preserves_remainder_ordinal_and_exact_offsets() {
        let initial = ConceptionQuantumState {
            conserved_joint_minutes: 20,
            next_trial_ordinal: 7,
        };
        let whole = conception_quantum_plan(initial, 151);
        assert_eq!(
            whole.trials,
            vec![
                ConceptionTrial {
                    ordinal: 7,
                    crossing_offset_minutes: 40,
                },
                ConceptionTrial {
                    ordinal: 8,
                    crossing_offset_minutes: 100,
                },
            ]
        );
        assert_eq!(
            whole.state,
            ConceptionQuantumState {
                conserved_joint_minutes: 51,
                next_trial_ordinal: 9,
            }
        );

        let early = conception_quantum_plan(initial, 55);
        let late = conception_quantum_plan(early.state, 96);
        let mut chunked = early.trials;
        chunked.extend(late.trials.into_iter().map(|trial| ConceptionTrial {
            crossing_offset_minutes: trial.crossing_offset_minutes + 55,
            ..trial
        }));
        assert_eq!(whole.trials, chunked);
        assert_eq!(whole.state, late.state);
        assert!(succeeds_daily_trial(39, CONCEPTION_CHANCE_PER_TEN_THOUSAND));
        assert!(!succeeds_daily_trial(
            40,
            CONCEPTION_CHANCE_PER_TEN_THOUSAND
        ));
    }

    #[test]
    fn child_seeds_are_parent_order_independent_and_domain_separated() {
        let first = deterministic_child_seeds(
            "anna",
            "beatrice",
            PregnancyOrdinal::new(3),
            StrategicMinute::new(900),
            "wittenberg",
        );
        let reversed = deterministic_child_seeds(
            "beatrice",
            "anna",
            PregnancyOrdinal::new(3),
            StrategicMinute::new(900),
            "wittenberg",
        );
        assert_eq!(first, reversed);
        assert_ne!(first.identity.get(), first.name.get().to_u64());
        assert_ne!(first.identity.get(), first.home.get().to_u64());
        assert_ne!(
            first,
            deterministic_child_seeds(
                "anna",
                "beatrice",
                PregnancyOrdinal::new(4),
                StrategicMinute::new(900),
                "wittenberg",
            )
        );
    }
}
