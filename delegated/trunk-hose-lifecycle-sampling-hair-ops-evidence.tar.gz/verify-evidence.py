'''Evidence integrity verification only; this does not run or validate product code.'''
import gzip, hashlib, json, tarfile
from datetime import datetime
from pathlib import Path

p = Path(__file__).resolve().parent
h = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
load = lambda n: json.loads((p / n).read_bytes())
reg = load('registration.json')
rec = load('read-receipt.json')
hist = load('historical-manifest.json')
proof = load('git-proofs.json')
for x in hist['hash_links']:
    b = Path(x['path']).read_bytes()
    assert len(b) == x['bytes'] and h(b) == x['sha256'], x['path']
for x in hist['exact_original_files']:
    b = (p / x['local']).read_bytes()
    assert len(b) == x['bytes'] and h(b) == x['sha256'] and Path(x['source_path']).read_bytes() == b, x['local']
for x in rec['registrations']:
    assert h((p / x['path']).read_bytes()) == x['sha256'], x['path']
    assert datetime.fromisoformat(load(x['path'])['registered_utc']) <= datetime.fromisoformat(rec['recorded_utc'])
registry = Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/registry.json.gz')))
b = gzip.decompress(registry.read_bytes())
assert h(b) == reg['registry_uncompressed_sha256']
orig = json.loads(b)['files']
archive = Path(next(x['path'] for x in hist['hash_links'] if x['path'].endswith('/objects.tar.gz')))
assert h(archive.read_bytes()) == reg['source_archive_sha256']
with tarfile.open(archive, 'r:gz') as t:
    for x in reg['rows']:
        b = (p / x['old_archive']).read_bytes()
        new = (p / f"source/{x['role']}-95e6.rs").read_bytes()
        prev = (p / f"source/{x['role']}-6533.rs").read_bytes()
        assert orig[x['role']] == x['original_registry_record']
        assert h(b) == x['old_sha256'] and b == new == prev == t.extractfile(x['old_sha256']).read()
        assert len(b.splitlines()) == x['old_lines']
        rr = next(r for r in rec['assigned'] if r['role'] == x['role'])
        assert rr['pr_working_actual_display'] == x['prospective_display']['pr_working']
        assert rr['current_95e_actual_display'] == x['prospective_display']['current95e']
        assert rr['unread_old_and_current'] == []
        assert [i for a, z in rr['pr_working_actual_display'] for i in range(a, z + 1)] == list(range(1, x['old_lines'] + 1))
planned = {}
for n in [x['path'] for x in rec['registrations'] if x['path'].startswith('support-registration')]:
    for x in load(n)['sources']:
        assert x['saved'] not in planned
        planned[x['saved']] = x
for x in rec['support']:
    s = planned[x['saved']]
    b = (p / x['saved']).read_bytes()
    assert h(b) == x['sha256'] == s['sha256'] and len(b) == s['bytes'] and len(b.splitlines()) == x['eof'] == s['eof']
    used = []
    for a, z in x['displayed'] + x['unread_complement']:
        assert 1 <= a <= z <= x['eof']
        used.extend(range(a, z + 1))
    assert len(used) == x['eof'] and set(used) == set(range(1, x['eof'] + 1))
    for a, z in x['displayed']:
        assert any(c <= a <= z <= d for c, d in s['prospective_ranges'])
objects = {}
for oid, x in proof['objects'].items():
    b = gzip.decompress((p / x['archive']).read_bytes())
    assert len(b) == x['bytes'] and h(b) == x['sha256']
    assert hashlib.sha1(x['type'].encode() + b' ' + str(len(b)).encode() + b'\0' + b).hexdigest() == oid
    objects[oid] = b
def lookup(b, name):
    i = 0
    while i < len(b):
        a = b.index(b' ', i); z = b.index(b'\0', a)
        nm = b[a + 1:z].decode(); mode = b[i:a].decode(); oid = b[z + 1:z + 21].hex(); i = z + 21
        if nm == name:
            return mode, oid
    raise ValueError(name)
for x in proof['proofs']:
    current = objects[x['revision']].splitlines()[0].split()[1].decode()
    assert current == x['commit_tree']
    for s in x['chain']:
        assert current == s['tree'] and lookup(objects[current], s['name']) == (s['mode'], s['object'])
        current = s['object']
    b = (p / x['local']).read_bytes()
    assert current == x['blob'] == blob(b) and h(b) == x['sha256']
prior = hist['prior_published_packet']
assert h(Path(prior['archive']).read_bytes()) == prior['sha256']
with tarfile.open(prior['archive'], 'r:gz') as t:
    contents = {}
    for x in prior['members']:
        b = t.extractfile(x['member']).read()
        assert len(b) == x['bytes'] and h(b) == x['sha256']
        contents[x['member']] = b
    rr = [json.loads(x) for x in contents['historical/774-rig-source-range-registration.jsonl'].splitlines()]
    additional = [json.loads(x) for x in contents['historical/774-rig-additional-contracts.jsonl'].splitlines()]
    l11 = json.loads(contents['historical/059-segovb--READ-L11-425.json'])
    l13 = json.loads(contents['historical/059-segovb--READ-L13-PARALLEL-126.json'])
    l12 = load('historical/059-segovb--READ-L12-884.json')
    assert l12['delegated_attribution_preserved'] and l12['root_personal_rereads'] == []
    for x, addid in zip(reg['rows'], ['RIG-ADMISSION03-ADDITIONAL-039', 'RIG-ADMISSION03-ADDITIONAL-040']):
        for ob in x['original_registry_record']['admission03_scope_observations']:
            assert rr[ob['row_1based'] - 1] == ob['original_record']
        r = next(y for y in additional if y['id'] == addid)
        assert r['sha256'] == x['old_sha256'] and r['actual_source_ranges'] == x['original_registry_record']['material_ranges']
        a = next(y for y in l11['sources'] if y['original_index'] == x['role'])
        b = next(y for y in l12['rows'] if y['original_index'] == x['role'])
        assert a['sha256'] == b['source_sha256'] == x['old_sha256']
        assert a['fresh_personal_body_reads'] == b['fresh_personal_body_reads'] == x['original_registry_record']['material_ranges']
        assert '/root/lens12_frontier' in b['attribution']
    c = next(y['row'] for y in l13['qualified_connected_reads'] if y['row']['original'] == 2599)
    assert c['sha256'] == reg['rows'][0]['old_sha256'] and c['fresh_personal_assessed_ranges'] == [[1, 56]]
    assert c['original_credit_now'] == 0 and l13['root_personal_rereads'] == []
sel = load(hist['reconstructed_queue_selection'])
qb = Path(sel['source_path']).read_bytes()
assert h(qb) == sel['source_sha256']
q = json.loads(qb)['entries']
for x in sel['rows']:
    assert q[x['index']] == x['entry']
if (p / 'MANIFEST.json').exists():
    for x in load('MANIFEST.json')['files']:
        b = (p / x['path']).read_bytes()
        assert len(b) == x['bytes'] and h(b) == x['sha256'], x['path']
print(f"PASS: two full old/current registered source reads; {len(proof['proofs'])} Git membership proofs; {len(rec['support'])} exact support partitions; linked 774/059 records and reconstructed queue rows. Evidence integrity only, no product execution or validation.")
