'''Freeze this evidence packet; does not touch product or historical evidence.'''
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path
p = Path(__file__).resolve().parent
files = []
for f in sorted(p.rglob('*')):
    if f.is_file() and f.name != 'MANIFEST.json' and '__pycache__' not in f.parts:
        b = f.read_bytes()
        files.append({'path': str(f.relative_to(p)), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
m = {'kind': 'bounded source audit evidence manifest', 'created_utc': datetime.now(timezone.utc).isoformat(), 'author': '/root/hair_ops', 'files': files, 'qualification': 'Local packet bytes only; external dependencies and their hashes are separately listed in historical-manifest.json. No product execution or validation.'}
(p / 'MANIFEST.json').write_text(json.dumps(m, indent=2, ensure_ascii=False) + '\n')
