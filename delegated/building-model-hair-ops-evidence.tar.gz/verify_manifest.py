"""Read-only verification of this frozen evidence packet, not product tests."""
import hashlib,json,pathlib
p=pathlib.Path(__file__).resolve().parent;m=json.loads((p/'packet-manifest.json').read_bytes()); expected={x['path'] for x in m['files']};actual={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file() and x.name!='packet-manifest.json'}
assert expected==actual,(sorted(expected-actual),sorted(actual-expected))
for x in m['files']:
 b=(p/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
print('Verified',len(expected),'frozen evidence files; no product execution.')
