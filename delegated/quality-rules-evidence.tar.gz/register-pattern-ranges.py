from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');original=json.loads((b/'registration.json').read_bytes());ranges={'95e6':[[6983,7017],[9461,9509]],'6533':[[7011,7045],[9496,9544]]};entries=[]
for e in original['entries']:
 if e['original_role']==2434:entries.append({'original_role':2434,'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'git_blob':e['git_blob'],'actual_line_count':e['actual_line_count'],'planned_personal_body_ranges':ranges[e['revision'][:4]]})
r={'schema':'726-delegated-prospective-selected-ranges-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity','basis':'Before displaying selected baseline fingerprints corresponding to current source match patterns; structural location alone carries no body-read credit.','entries':entries};(b/'pattern-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('pattern registration sha256',hashlib.sha256((b/'pattern-registration.json').read_bytes()).hexdigest())
