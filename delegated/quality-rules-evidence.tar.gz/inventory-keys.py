from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,tomllib
b=Path('<LOCAL_PATH_0>');res={}
for short in ['95e6','6533']:
 d=tomllib.loads((b/'sources'/short/'rust-quality-baseline.toml').read_text());defs={'files':lambda x:(x.get('path'),),'functions':lambda x:(x.get('path'),x.get('item')),'findings':lambda x:(x.get('rule'),x.get('path'),x.get('item'),x.get('fingerprint'))};r={}
 for name,fun in defs.items():
  counts=Counter(fun(x) for x in d[name]);r[name]={'records':len(d[name]),'distinct_consumer_keys':len(counts),'duplicates':[{'key':key,'count':n} for key,n in counts.items() if n>1],'missing_required_key':sum(any(z is None for z in fun(x)) for x in d[name])}
 r['nonpositive_ceilings']=sum(x.get('ceiling',0)<=0 for name in ['files','functions'] for x in d[name]);r['nonpositive_occurrences']=sum(x.get('occurrences',0)<=0 for x in d['findings']);res[short]=r
out={'schema':'726-quality-baseline-consumer-key-inventory-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'basis':'Whole-source Python TOML structural extraction only, using key fields named by separately displayed native consumer; no scanner, lint, product or test execution and no inferred personal line-read coverage.','revisions':res};(b/'consumer-key-inventory.json').write_text(json.dumps(out,indent=2)+'\n');print('key inventory sha256',hashlib.sha256((b/'consumer-key-inventory.json').read_bytes()).hexdigest());print(json.dumps(res,indent=2))
