from pathlib import Path
import hashlib,json,re,tomllib
b=Path('<LOCAL_PATH_0>');targets={'string:leftarm','string:leftleg','string:rightarm','string:rightleg','string:LclRotation','string:LclScaling','string:LclTranslation','string:Lcl Rotation','string:Lcl Scaling','string:Lcl Translation'};res={}
for short in ['95e6','6533']:
 lines=(b/'sources'/short/'rust-quality-baseline.toml').read_text().splitlines();start=[i for i,x in enumerate(lines) if re.fullmatch(r'\[\[(files|functions|findings)\]\]',x)];rows=[]
 for k,i in enumerate(start):
  j=start[k+1] if k+1<len(start) else len(lines)
  if lines[i]!='[[findings]]':continue
  e=tomllib.loads('\n'.join(lines[i:j]))['findings'][0]
  if e.get('fingerprint') in targets and e.get('path') in ['crates/adventuresim-stdb-module/src/corpse.rs','crates/fabelgeist-fbx/src/animation.rs']:rows.append({'range':[i+1,j],'path':e['path'],'item':e['item'],'fingerprint':e['fingerprint']})
 res[short]=rows
r={'schema':'726-quality-pattern-record-locator-v1','method':'Structural offsets for exact selected records; locating and parsing do not constitute body display.','rows':res};(b/'pattern-record-locator.json').write_text(json.dumps(r,indent=2)+'\n');print('locator sha256',hashlib.sha256((b/'pattern-record-locator.json').read_bytes()).hexdigest());print(json.dumps(res,indent=2))
