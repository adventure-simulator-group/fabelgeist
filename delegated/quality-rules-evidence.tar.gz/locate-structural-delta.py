from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,tomllib
b=Path('<LOCAL_PATH_0>');inventory=json.loads((b/'structural-inventory.json').read_bytes());out={}
for label,short,action in [('current','95e6','added'),('historical','6533','removed')]:
 lines=(b/'sources'/short/'rust-quality-baseline.toml').read_text().splitlines();start=[i for i,x in enumerate(lines) if re.fullmatch(r'\[\[(files|functions|findings)\]\]',x)];rows=[]
 for k,i in enumerate(start):
  j=start[k+1] if k+1<len(start) else len(lines);section=tomllib.loads('\n'.join(lines[i:j]));name=next(iter(section));entry=section[name][0]
  if any(x['entry']==entry for x in inventory['structural_delta'][name][action]):rows.append({'section':name,'record_index':sum(1 for z in start[:k] if lines[z]==lines[i]),'line_range':[i+1,j],'path':entry.get('path'),'item':entry.get('item'),'fingerprint':entry.get('fingerprint')})
 out[label]={'record_ranges':rows,'section_first_lines':{name:next(i+1 for i,x in enumerate(lines) if x==f'[[{name}]]') for name in ['files','functions','findings']}}
r={'schema':'726-structural-delta-locator-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'method':'Locate changed structured record spans from exact pinned TOML bytes; automatic parse is not personal body display. Use these offsets solely to prospectively register selected reads.','revisions':out};(b/'structural-delta-locator.json').write_text(json.dumps(r,indent=2)+'\n');print('locator sha256',hashlib.sha256((b/'structural-delta-locator.json').read_bytes()).hexdigest());
for label,v in out.items():
 print('\n',label,'sections',v['section_first_lines'])
 for row in v['record_ranges']:
  if any(z in str(row) for z in ['character/skin.rs','character/skeleton.rs','character.rs','tactical-client/src/equipment.rs','tactical-client/src/ui.rs']):print(row)
