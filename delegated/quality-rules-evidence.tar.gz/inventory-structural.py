from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,tomllib
b=Path('<LOCAL_PATH_0>');revs={'current':'95e6','historical':'6533'};models={};summ={}
for label,short in revs.items():
 raw=(b/'sources'/short/'rust-quality-baseline.toml').read_bytes();doc=tomllib.loads(raw.decode());models[label]=doc
 normalize=lambda row:json.dumps(row,sort_keys=True,ensure_ascii=False,separators=(',',':'))
 entry_counts={name:len(v) if isinstance(v,list) else None for name,v in doc.items()};shapes={name:dict(Counter(tuple(sorted(row)) for row in rows)) for name,rows in doc.items() if isinstance(rows,list)}
 shapes={name:{','.join(k):v for k,v in shape.items()} for name,shape in shapes.items()}
 rules=Counter(row.get('rule','<none>') for row in doc.get('findings',[]));paths=Counter(row.get('path','<none>') for row in doc.get('files',[]));identities=Counter(normalize(row) for row in doc.get('findings',[]));
 summ[label]={'sha256':hashlib.sha256(raw).hexdigest(),'line_count':len(raw.splitlines()),'top_level_keys':list(doc),'array_counts':entry_counts,'array_record_key_shapes':shapes,'finding_rule_counts':dict(sorted(rules.items())),'duplicate_file_paths':{k:v for k,v in paths.items() if v>1},'duplicate_exact_findings_count':sum(v-1 for v in identities.values() if v>1),'ceiling_value_types':dict(Counter(type(x.get('ceiling')).__name__ for x in doc.get('files',[])))}
key=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'));delta={}
for name in sorted(set(models['current'])|set(models['historical'])):
 a=models['historical'].get(name,[]);c=models['current'].get(name,[])
 if not isinstance(a,list) or not isinstance(c,list):delta[name]={'old':a,'current':c};continue
 old=Counter(map(key,a));new=Counter(map(key,c));delta[name]={'added':[{'entry':json.loads(k),'count':n} for k,n in sorted((new-old).items())],'removed':[{'entry':json.loads(k),'count':n} for k,n in sorted((old-new).items())]}
out={'schema':'726-quality-baseline-structural-inventory-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'method':'Python standard-library TOML parser over exact registered source bytes; array counts, record-key shapes and multiset structural differences only. Parsing entire bytes is not a personal body read, audit verdict, scanner run or product validation.','revisions':summ,'structural_delta':delta};(b/'structural-inventory.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print('structural inventory sha256',hashlib.sha256((b/'structural-inventory.json').read_bytes()).hexdigest());print(json.dumps({'summaries':summ,'delta_counts':{k:{x:len(v[x]) for x in ['added','removed']} for k,v in delta.items() if 'added' in v}},indent=2))
