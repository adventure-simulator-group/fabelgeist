from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
b=Path('<LOCAL_PATH_0>');revs=['95e63628f9d70b8dd6e6fede64334696c6995009','6533e444fa37552927070cc8d8190907fd3b413e'];roles={2354:'crates/strategic-web/AGENTS.md',2434:'rust-quality-baseline.toml'};entries=[];pending=[]
for i,p in roles.items():
 for rev in revs:
  raw=subprocess.check_output(['git','show',rev+':'+p]);length=len(raw.splitlines());ranges=[[1,length]] if i==2354 else [[1,min(100,length)],[max(101,length-39),length]];entries.append({'original_role':i,'revision':rev,'path':p,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw),'actual_line_count':length,'planned_personal_body_ranges':ranges,'structural_parse_entire_file':i==2434,'qualification':'Structural parsing and preserved bytes do not confer body-read credit; additional displayed ranges require new prospective registration.'});pending.append((rev,p,raw))
r={'schema':'726-delegated-prospective-source-registration-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity, quality and rules source family','registration':'Before any assigned source body display; scoped personal reads and separate whole-file structural inventory only.','entries':entries};(b/'registration.json').write_text(json.dumps(r,indent=2)+'\n')
for rev,p,raw in pending:
 d=b/'sources'/rev[:4]/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
print('registration sha256',hashlib.sha256((b/'registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
