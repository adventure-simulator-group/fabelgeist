from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
b=Path('<LOCAL_PATH_0>');original=json.loads((b/'registration.json').read_bytes());ranges={'95e6':[[525,544],[820,850],[3230,3265],[3280,3310],[9992,10020],[12738,12772]],'6533':[[525,544],[565,580],[830,860],[2280,2300],[2388,2400],[3258,3293],[3308,3338],[8643,8658],[10027,10055],[12773,12807]]};entries=[]
for e in original['entries']:
 if e['original_role']!=2434:continue
 entries.append({'original_role':2434,'revision':e['revision'],'path':e['path'],'sha256':e['sha256'],'git_blob':e['git_blob'],'actual_line_count':e['actual_line_count'],'planned_personal_body_ranges':ranges[e['revision'][:4]]})
r={'schema':'726-delegated-prospective-selected-ranges-v1','created_utc':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'reader':'current-session delegate /root/rig_identity, quality and rules','basis':'Prospective bounded source display selected from structural section/delta offsets. Entire-file structural parsing is separately qualified, never read credit.','entries':entries};(b/'selected-registration.json').write_text(json.dumps(r,indent=2)+'\n');print('selected registration sha256',hashlib.sha256((b/'selected-registration.json').read_bytes()).hexdigest());print(json.dumps(entries,indent=2))
