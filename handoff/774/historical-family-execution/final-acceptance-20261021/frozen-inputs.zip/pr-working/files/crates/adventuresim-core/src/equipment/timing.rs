//! Authored melee cadence from rotational inertia and attack style.

use crate::combat_style::MeleeAttackStyle;
use crate::elapsed::{AnimationElapsed, ElapsedResult};

/// Real-time attack schedule for one ordinary melee strike. Preparation ends
/// at contact; recovery ends when another non-continuation attack may begin.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MeleeAttackTiming {
    pub preparation_secs: AnimationElapsed,
    pub recovery_secs: AnimationElapsed,
}

/// Initial tactical cadence synthesized from physical rotational inertia and
/// attack style. Weapon family is intentionally absent: two weapons with the
/// same inertia take the same baseline time to redirect.
pub fn melee_attack_timing(
    style: MeleeAttackStyle,
    moment_of_inertia_kg_m2: f32,
    unarmed: bool,
) -> ElapsedResult<MeleeAttackTiming> {
    let inertia = if moment_of_inertia_kg_m2.is_finite() {
        moment_of_inertia_kg_m2.max(0.0)
    } else {
        0.3
    };
    let base_cycle = if unarmed {
        0.36
    } else {
        // Saturation prevents long weapons from becoming unusably slow while
        // retaining a steep distinction among knives, swords, and polearms.
        0.24 + 0.40 * (inertia / (inertia + 0.45)).sqrt()
    };
    let (style_scale, contact_share) = if style == MeleeAttackStyle::Stab {
        (1.18, 0.56)
    } else {
        (1.0, 0.55)
    };
    let cycle = base_cycle * style_scale;
    Ok(MeleeAttackTiming {
        preparation_secs: AnimationElapsed::from_seconds(cycle * contact_share)?,
        recovery_secs: AnimationElapsed::from_seconds(cycle * (1.0 - contact_share))?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn melee_timing_is_inferred_from_moment_and_style() {
        let cases = [
            ("fists", MeleeAttackStyle::Swing, 0.0, true, 0.36),
            (
                "knife cut",
                MeleeAttackStyle::Swing,
                0.009216,
                false,
                0.24 + 0.40 * f32::sqrt(0.009216 / (0.009216 + 0.45)),
            ),
            (
                "knife thrust",
                MeleeAttackStyle::Stab,
                0.009216,
                false,
                (0.24 + 0.40 * f32::sqrt(0.009216 / (0.009216 + 0.45))) * 1.18,
            ),
            (
                "sword",
                MeleeAttackStyle::Swing,
                0.26325,
                false,
                0.24 + 0.40 * f32::sqrt(0.26325 / (0.26325 + 0.45)),
            ),
            (
                "mace",
                MeleeAttackStyle::Swing,
                0.170555,
                false,
                0.24 + 0.40 * f32::sqrt(0.170555 / (0.170555 + 0.45)),
            ),
        ];
        for (label, style, inertia, unarmed, expected_cycle) in cases {
            let timing = melee_attack_timing(style, inertia, unarmed).unwrap();
            let cycle = timing.preparation_secs.seconds() + timing.recovery_secs.seconds();
            assert!((cycle - expected_cycle).abs() < 1.0e-5, "{label}: {cycle}");
        }
    }
    #[test]
    fn greater_moment_of_inertia_slows_cadence() {
        let low_inertia = melee_attack_timing(MeleeAttackStyle::Swing, 0.05, false).unwrap();
        let high_inertia = melee_attack_timing(MeleeAttackStyle::Swing, 1.0, false).unwrap();
        assert!(
            high_inertia.preparation_secs.seconds() + high_inertia.recovery_secs.seconds()
                > low_inertia.preparation_secs.seconds() + low_inertia.recovery_secs.seconds()
        );
    }
}
