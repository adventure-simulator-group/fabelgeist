//! Supported-foot displacement from current captured native bone positions.

use super::*;
use adventuresim_tactical_core::animation::NonnegativeLength;

pub(super) fn supported_foot_slip(
    metadata: &ScenarioMetadata<'_>,
    before: &FrameSample,
    after: &FrameSample,
) -> AnimationValueResult<NonnegativeLength> {
    let mut maximum_slip = 0.0_f32;
    let body_turn = Quat::from_array(before.body_rotation_xyzw)
        .angle_between(Quat::from_array(after.body_rotation_xyzw))
        .to_degrees();
    for (foot, support) in [
        (
            BoneRole::FootLeft,
            before
                .left_support_weight
                .fraction()
                .min(after.left_support_weight.fraction()),
        ),
        (
            BoneRole::FootRight,
            before
                .right_support_weight
                .fraction()
                .min(after.right_support_weight.fraction()),
        ),
    ] {
        // A body turn deliberately slides an old world plant onto
        // its new anatomical side corridor. Treat that bounded
        // adaptation separately from skating under a stable body.
        let procedural_plant_active =
            metadata.kind() == ScenarioKind::Terrain || (before.guard_action && after.guard_action);
        if procedural_plant_active
            && support >= 0.9
            && body_turn <= 0.5
            && let (Some(a), Some(b)) = (before.bones.get(foot), after.bones.get(foot))
        {
            let distance = (Vec3::from_array(b.position) - Vec3::from_array(a.position))
                .xz()
                .length();
            if !distance.is_finite() {
                return Err(
                    adventuresim_tactical_core::animation::AnimationValueError::Overflow {
                        quantity: adventuresim_tactical_core::animation::AnimationQuantity::Length,
                    },
                );
            }
            maximum_slip = maximum_slip.max(distance);
        }
    }
    NonnegativeLength::from_arithmetic(maximum_slip)
}
