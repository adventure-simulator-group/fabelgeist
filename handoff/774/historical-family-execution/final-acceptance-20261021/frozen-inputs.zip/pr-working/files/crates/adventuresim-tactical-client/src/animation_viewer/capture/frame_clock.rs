//! Deterministic capture tick progression and finite frame-interval admission.

use super::*;
use adventuresim_tactical_core::animation::{
    AnimationElapsed, AnimationQuantity, AnimationSampleRate, AnimationSampleTick,
    AnimationValueError, AnimationValueResult,
};
use std::time::Duration;

/// Bevy's native clock requires a nonzero Duration. Preserve its f64 Hz
/// reciprocal and native nanosecond rounding rather than the f32 pose interval.
pub(crate) fn capture_fixed_clock(rate: AnimationSampleRate) -> AnimationValueResult<Time<Fixed>> {
    let seconds = 1.0 / f64::from(rate.hertz());
    let interval =
        Duration::try_from_secs_f64(seconds).map_err(|_| AnimationValueError::Overflow {
            quantity: AnimationQuantity::NativeSampleInterval,
        })?;
    if interval.is_zero() {
        return Err(AnimationValueError::NonPositive {
            quantity: AnimationQuantity::NativeSampleInterval,
        });
    }
    Ok(Time::from_duration(interval))
}

pub(super) fn next_capture_simulation_tick(
    current: AnimationSampleTick,
    absolute_first_sample: bool,
) -> AnimationSampleTick {
    if absolute_first_sample {
        current
    } else {
        current.wrapping_next()
    }
}

pub(super) fn capture_frame_elapsed(scenario_frame: usize) -> AnimationElapsed {
    if scenario_frame == 0 {
        AnimationElapsed::ZERO
    } else {
        locomotion_sample_rate().interval().elapsed()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn capture_ticks_remain_unique_across_consecutive_scenario_boundaries() {
        let first = next_capture_simulation_tick(AnimationSampleTick::ZERO, true);
        let second = next_capture_simulation_tick(first, false);
        let next_scenario_frame_zero = next_capture_simulation_tick(second, false);
        assert_eq!(first, AnimationSampleTick::from(0u64));
        assert_eq!(second, AnimationSampleTick::from(1u64));
        assert_eq!(next_scenario_frame_zero, AnimationSampleTick::from(2u64));
    }
}
