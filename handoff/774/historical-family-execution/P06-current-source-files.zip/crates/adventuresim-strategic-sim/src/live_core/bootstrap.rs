
pub(super) fn leader_is_actionable(
    party_id: &str,
    authoritative_leader_id: u64,
    character_id: u64,
    alive: bool,
    character_party_id: Option<&str>,
) -> bool {
    alive && character_id == authoritative_leader_id && character_party_id == Some(party_id)
}

pub(super) fn equipment_utility(profile: &AgentProfile, item: &Item) -> Option<f32> {
    let preference = &profile.equipment;
    let armor = matches!(
        item.kind,
        CatalogItemKind::Armor | CatalogItemKind::Clothing
    );
    let compatible = match preference.style {
        EquipmentStyle::Unarmored => !armor && item.melee && item.weight <= 2.5,
        EquipmentStyle::Ranged => !armor && item.ranged,
        EquipmentStyle::Light => (armor && item.weight <= 8.0) || (!armor && item.melee),
        EquipmentStyle::Heavy => armor || item.melee,
    };
    if !compatible || item.base_value.is_none() || item.equipment_placements.is_empty() {
        return None;
    }
    let protection = item.coverage + item.resistance + item.padding;
    let mobility = item.flexibility + item.range_of_motion - item.weight * 0.1;
    let price = 1.0 / (1.0 + item.base_value.unwrap_or(1) as f32 / 100.0);
    Some(
        preference.protection_weight * protection
            + preference.mobility_weight * mobility
            + preference.price_weight * price
            + preference.reach_weight * item.reach,
    )
}

pub(super) fn root_requirement_matches_slot(
    requirement: &OccupancyRequirement,
    slot: Slot,
) -> bool {
    match slot {
        Slot::LeftHolding => {
            requirement.location == EquipmentLocation::LeftHand
                && requirement.channel == EquipmentChannel::Held
        }
        Slot::RightHolding => {
            requirement.location == EquipmentLocation::RightHand
                && requirement.channel == EquipmentChannel::Held
        }
        Slot::AnyHolding => requirement.channel == EquipmentChannel::Held,
        Slot::LeftArm => requirement.location == EquipmentLocation::LeftArm,
        Slot::RightArm => requirement.location == EquipmentLocation::RightArm,
        Slot::AnyArm => matches!(
            requirement.location,
            EquipmentLocation::LeftArm | EquipmentLocation::RightArm
        ),
        Slot::LeftLeg => requirement.location == EquipmentLocation::LeftLeg,
        Slot::RightLeg => requirement.location == EquipmentLocation::RightLeg,
        Slot::AnyLeg => matches!(
            requirement.location,
            EquipmentLocation::LeftLeg | EquipmentLocation::RightLeg
        ),
        Slot::Head => requirement.location == EquipmentLocation::Head,
        Slot::Chest => requirement.location == EquipmentLocation::Chest,
        Slot::Stomach => requirement.location == EquipmentLocation::Stomach,
        Slot::None => true,
    }
}

pub(super) fn select_public_quest_fixture(
    rows: impl IntoIterator<Item = SimulationQuestFixture>,
    expected_run_id: u64,
    expected_parties: &[(u64, String); 2],
) -> Result<SimulationQuestFixture, String> {
    let mut rows = rows.into_iter().take(2);
    let fixture = rows
        .next()
        .ok_or("required quest fixture completed without receipt-backed public provenance")?;
    if rows.next().is_some() {
        return Err("required quest fixture public provenance is ambiguous".into());
    }
    if fixture.id != 0 || fixture.run_id != expected_run_id {
        return Err("required quest fixture public provenance identifies the wrong run".into());
    }
    let direct = (fixture.direct_leader_id, fixture.direct_party_id.as_str());
    let generated = (
        fixture.generated_leader_id,
        fixture.generated_party_id.as_str(),
    );
    let first = (expected_parties[0].0, expected_parties[0].1.as_str());
    let second = (expected_parties[1].0, expected_parties[1].1.as_str());
    if !((direct == first && generated == second) || (direct == second && generated == first)) {
        return Err("required quest fixture public provenance identifies the wrong parties".into());
    }
    Ok(fixture)
}

pub(super) fn select_public_quest_fixture_if_present(
    rows: impl IntoIterator<Item = SimulationQuestFixture>,
    expected_run_id: u64,
    expected_parties: &[(u64, String); 2],
) -> Result<Option<SimulationQuestFixture>, String> {
    let rows = rows.into_iter().take(2).collect::<Vec<_>>();
    if rows.is_empty() {
        return Ok(None);
    }
    select_public_quest_fixture(rows, expected_run_id, expected_parties).map(Some)
}

fn wait_for_new_public_direct_contract(
    runner: &LiveRunner,
    existing_contract_ids: &HashSet<String>,
    settlement_id: &str,
    direct_party_id: &str,
) -> Result<String, String> {
    let deadline = std::time::Instant::now() + ACTION_TIMEOUT;
    loop {
        let mut candidates = runner
            .connection
            .db
            .backend_contracts()
            .iter()
            .filter(|contract| {
                !existing_contract_ids.contains(&contract.id)
                    && contract.settlement_id == settlement_id
                    && contract.status == ContractStatus::Offered
                    && runner
                        .public_party_contract_assessment(direct_party_id, contract)
                        .eligible
            })
            .map(|contract| contract.id)
            .collect::<Vec<_>>();
        candidates.sort();
        candidates.dedup();
        match candidates.as_slice() {
            [contract_id] => return Ok(contract_id.clone()),
            [] if std::time::Instant::now() < deadline => {
                std::thread::sleep(Duration::from_millis(5));
            }
            [] => return Err("required direct fixture contract was not publicly projected".into()),
            _ => return Err("required direct fixture contract projection is ambiguous".into()),
        }
    }
}

pub fn run_core_loop(config: CoreLoopConfig) -> CoreLoopRunResult<CoreLoopReport> {
    let failure_recorder = FailureRecorder::new(
        config.failure_output.clone(),
        config.fixture_disease.clone(),
    );
    let error = match run_core_loop_inner(config, failure_recorder.clone()) {
        Ok(report) => return Ok(report),
        Err(error) => error,
    };
    if let Err(report) = failure_recorder.write(&error) {
        return Err(CoreLoopRunError::FailureReport { error, report });
    }
    Err(error.into())
}

fn run_core_loop_inner(
    config: CoreLoopConfig,
    failure_recorder: FailureRecorder,
) -> CoreLoopResult<CoreLoopReport> {
    config.validate()?;
    let bootstrap_token =
        bootstrap_token_from_environment(std::env::var(BOOTSTRAP_TOKEN_ENV).ok())?;
    let (connected_tx, connected_rx) = mpsc::sync_channel(1);
    let connect_error_tx = connected_tx.clone();
    let connection = DbConnection::builder()
        .with_uri(&config.host)
        .with_database_name(&config.database)
        .on_connect(move |_, _, _| {
            let _ = connected_tx.send(Ok(()));
        })
        .on_connect_error(move |_, error| {
            let _ = connect_error_tx.send(Err(error.to_string()));
        })
        .build()
        .map_err(|error| error.to_string())?;
    let (subscription_tx, subscription_rx) = mpsc::sync_channel(1);
    let subscription_error_tx = subscription_tx.clone();
    connection
        .subscription_builder()
        .on_applied(move |_| {
            let _ = subscription_tx.send(Ok(()));
        })
        .on_error(move |_, error| {
            let _ = subscription_error_tx.send(Err(error.to_string()));
        })
        // Deliberately enumerate the policy observation surface. In
        // particular, never transport backend infection episodes, committed
        // cuts, or full medical examinations into the simulator process.
        .add_query(|query| query.from.autoresolve_report())
        .add_query(|query| query.from.backend_authority_arrest_actions())
        .add_query(|query| query.from.backend_case_battles())
        .add_query(|query| query.from.backend_case_site_pins())
        .add_query(|query| query.from.backend_dialogue_sessions())
        .add_query(|query| query.from.backend_dialogue_topic_options())
        .add_query(|query| query.from.backend_investigation_action_outcomes())
        .add_query(|query| query.from.backend_investigation_actions())
        .add_query(|query| query.from.backend_investigation_cases())
        .add_query(|query| query.from.backend_investigation_journal())
        .add_query(|query| query.from.backend_investigation_leads())
        .add_query(|query| query.from.backend_local_problem_trade_effects())
        .add_query(|query| query.from.battle_loot_item())
        .add_query(|query| query.from.battle_result())
        .add_query(|query| query.from.backend_characters())
        .add_query(|query| query.from.backend_character_attributes())
        .add_query(|query| query.from.backend_character_capabilities())
        .add_query(|query| query.from.backend_character_conditions())
        .add_query(|query| query.from.backend_character_deaths())
        .add_query(|query| query.from.backend_character_limbs())
        .add_query(|query| query.from.backend_character_stats())
        .add_query(|query| query.from.character_equipped_item())
        .add_query(|query| query.from.equipment_occupancy())
        .add_query(|query| query.from.character_illness_status())
        .add_query(|query| query.from.backend_character_needs())
        .add_query(|query| query.from.backend_character_strategic_conditions())
        .add_query(|query| query.from.backend_character_times())
        .add_query(|query| query.from.backend_character_training_schedules())
        .add_query(|query| query.from.inventory_item())
        .add_query(|query| query.from.inventory_item_amount())
        .add_query(|query| query.from.inventory_object())
        .add_query(|query| query.from.inventory_containment())
        .add_query(|query| query.from.container_liquid())
        .add_query(|query| query.from.food_lot())
        .add_query(|query| query.from.item())
        .add_query(|query| query.from.item_condition())
        .add_query(|query| query.from.limb_injury())
        .add_query(|query| query.from.local_problem_symptom())
        .add_query(|query| query.from.party())
        .add_query(|query| query.from.party_inventory_item())
        .add_query(|query| query.from.party_item_amount())
        .add_query(|query| query.from.party_journey())
        .add_query(|query| query.from.party_join_request())
        .add_query(|query| query.from.party_member())
        .add_query(|query| query.from.party_stake())
        .add_query(|query| query.from.backend_contracts())
        .add_query(|query| query.from.backend_road_challenges())
        .add_query(|query| query.from.backend_settlement_residents())
        .add_query(|query| query.from.strategic_encounter())
        .add_query(|query| query.from.repair_order())
        .add_query(|query| query.from.settlement())
        .add_query(|query| query.from.settlement_resident_presence())
        .add_query(|query| query.from.settlement_smith())
        .add_query(|query| query.from.simulation_run())
        .add_query(|query| query.from.simulation_quest_fixture())
        .add_query(|query| query.from.world_clock())
        .add_query(|query| query.from.world_data_import())
        .subscribe();
    connection.run_threaded();
    connected_rx
        .recv_timeout(ACTION_TIMEOUT)
        .map_err(|_| "connection timed out".to_string())??;
    subscription_rx
        .recv_timeout(ACTION_TIMEOUT)
        .map_err(|_| "subscription timed out".to_string())??;

    let profiles = (0..config.population)
        .map(|id| generate_profile(config.seed, id))
        .collect::<Vec<_>>();
    let character_ids = (0..config.population)
        .map(|id| fabelgeist_determinism::StreamId::new("simulation.character-identity").seed(config.seed, &[u64::from(id)]).to_u64())
        .collect::<Vec<_>>();
    let mut runner = LiveRunner {
        connection,
        profiles,
        character_ids,
        metrics: CoreLoopMetrics::default(),
        trace: Vec::new(),
        semantic_event_keys: Vec::new(),
        sequence: 0,
        dialogue_nonce: 0,
        last_semantic_event: None,
        recorded_deaths: HashSet::new(),
        medically_paused_schedules: HashSet::new(),
        generated_seen_cases: HashSet::new(),
        generated_terminal_cases: HashSet::new(),
        generated_exact_site_cases: HashSet::new(),
        generated_traveled_cases: HashSet::new(),
        generated_case_site_recoveries: HashSet::new(),
        generated_active_cases: HashMap::new(),
        generated_case_cursors: HashMap::new(),
        generated_finance_blocks: HashMap::new(),
        generated_discovery_backoff: HashMap::new(),
        generated_dialogue_no_progress: HashMap::new(),
        generated_defeat_fingerprints: HashMap::new(),
        observed_activity_site_origins: HashMap::new(),
        failure_recorder,
    };
    if runner
        .connection
        .db
        .simulation_run()
        .iter()
        .next()
        .is_some()
    {
        return Err("refusing reused simulation database".into());
    }
    let world_import = runner.connection.db.world_data_import().iter().next();
    if config.use_imported_world {
        let imported = world_import
            .as_ref()
            .filter(|import| import.completed)
            .ok_or("full-world mode requires a completed world_data_import")?;
        if Some(imported.manifest_digest.as_str())
            != config.expected_world_manifest_digest.as_deref()
        {
            return Err(
                "imported world manifest does not match the pinned expected manifest".into(),
            );
        }
        if imported.artifact_id.trim().is_empty()
            || imported.manifest_digest.len() != 64
            || runner.connection.db.settlement().iter().next().is_none()
        {
            return Err(
                "completed world_data_import has invalid provenance or no settlements".into(),
            );
        }
    } else if world_import.is_some() || runner.connection.db.settlement().iter().next().is_some() {
        return Err("fixture mode refuses imported or pre-existing settlement state".into());
    }
    let result = reducer_call!(runner, ReducerOperation::ClaimSimulationRun, |cb| runner
        .connection
        .reducers
        .claim_simulation_run_then(
            bootstrap_token.clone(),
            config.run_nonce.clone(),
            config.seed.into(),
            cb,
        ));
    runner.call(result)?;
    let claimed_run_ids = runner
        .connection
        .db
        .simulation_run()
        .iter()
        .filter(|run| run.nonce == config.run_nonce)
        .map(|run| run.id)
        .take(2)
        .collect::<Vec<_>>();
    let claimed_run_id = match claimed_run_ids.as_slice() {
        [run_id] => *run_id,
        [] => return Err("claim reducer completed without a coherent simulation run".into()),
        _ => return Err("claim reducer completed with ambiguous simulation runs".into()),
    };
    // The disposable simulation owns this otherwise-empty database, so its
    // authenticated connection is also the trusted strategic gateway.
    let result = reducer_call!(runner, ReducerOperation::RegisterStrategicGateway, |cb| runner
        .connection
        .reducers
        .register_strategic_gateway_then(None, 0, cb));
    runner.call(result)?;
    // Re-subscribe the gateway-only observation surface after registration.
    // This does not rely on an already-applied subscription recomputing views
    // when gateway authority changes.
    let (gateway_subscription_tx, gateway_subscription_rx) = mpsc::sync_channel(1);
    let gateway_subscription_error_tx = gateway_subscription_tx.clone();
    runner
        .connection
        .subscription_builder()
        .on_applied(move |_| {
            let _ = gateway_subscription_tx.send(Ok(()));
        })
        .on_error(move |_, error| {
            let _ = gateway_subscription_error_tx.send(Err(error.to_string()));
        })
        .add_query(|query| query.from.backend_authority_arrest_actions())
        .add_query(|query| query.from.backend_case_battles())
        .add_query(|query| query.from.backend_case_site_pins())
        .add_query(|query| query.from.backend_contracts())
        .add_query(|query| query.from.backend_dialogue_sessions())
        .add_query(|query| query.from.backend_dialogue_topic_options())
        .add_query(|query| query.from.backend_investigation_action_outcomes())
        .add_query(|query| query.from.backend_investigation_actions())
        .add_query(|query| query.from.backend_investigation_cases())
        .add_query(|query| query.from.backend_investigation_journal())
        .add_query(|query| query.from.backend_investigation_leads())
        .add_query(|query| query.from.backend_local_problem_trade_effects())
        .add_query(|query| query.from.backend_physiology_charts())
        .add_query(|query| query.from.backend_characters())
        .add_query(|query| query.from.backend_character_capabilities())
        .add_query(|query| query.from.backend_character_needs())
        .add_query(|query| query.from.backend_character_stats())
        .add_query(|query| query.from.backend_character_strategic_conditions())
        .add_query(|query| query.from.backend_character_times())
        .add_query(|query| query.from.backend_character_training_schedules())
        .add_query(|query| query.from.backend_settlement_residents())
        .add_query(|query| query.from.party())
        .add_query(|query| query.from.settlement_resident_presence())
        .subscribe();
    gateway_subscription_rx
        .recv_timeout(ACTION_TIMEOUT)
        .map_err(|_| "gateway subscription timed out".to_string())??;
    if !config.use_imported_world {
        let result = reducer_call!(runner, ReducerOperation::SeedSimulationWorld, |cb| runner
            .connection
            .reducers
            .seed_simulation_world_then(config.run_nonce.clone(), cb));
        runner.call(result)?;
    }
    let starting_settlement_id = runner
        .connection
        .db
        .settlement()
        .iter()
        .map(|settlement| settlement.id)
        .min()
        .ok_or("simulation world has no starting settlement")?;
    for (agent, character_id) in runner.character_ids.clone().into_iter().enumerate() {
        let name = format!("sim-{}-{agent}", config.seed);
        let result = reducer_call!(runner, ReducerOperation::CreateNamedCharacterWithId, |cb| runner
            .connection
            .reducers
            .create_named_character_with_id_then(character_id, name.clone(), cb));
        runner.call(result)?;
        let settlement = starting_settlement_id.clone();
        let profile = runner.profiles[agent].clone();
        let attributes = live_attributes(character_id, &profile);
        let skills = live_skills(character_id, &profile);
        let downtime = live_schedule(&profile);
        let personality = live_personality(character_id, &profile.personality);
        let result = reducer_call!(runner, ReducerOperation::ConfigureSimulationCharacter, |cb| runner
            .connection
            .reducers
            .configure_simulation_character_then(
                config.run_nonce.clone(),
                character_id,
                agent as u32,
                settlement.clone(),
                attributes.clone(),
                skills.clone(),
                downtime.clone(),
                personality.clone(),
                cb,
            ));
        runner.call(result)?;
        let fixture_item = runner
            .connection
            .db
            .inventory_item()
            .iter()
            .find(|row| {
                row.character_id == character_id
                    && runner
                        .connection
                        .db
                        .item()
                        .iter()
                        .find(|item| item.id == row.item_id)
                        .is_some_and(|item| {
                            matches!(
                                item.kind,
                                CatalogItemKind::Weapon
                                    | CatalogItemKind::Armor
                                    | CatalogItemKind::Shield
                            )
                        })
            })
            .ok_or("simulation character has no durable fixture item")?;
        let result = reducer_call!(runner, ReducerOperation::SeedSimulationEquipmentDamage, |cb| runner
            .connection
            .reducers
            .seed_simulation_equipment_damage_then(
                config.run_nonce.clone(),
                character_id,
                fixture_item.id,
                cb,
            ));
        runner.call(result)?;
        if agent == 0 {
            let result = reducer_call!(runner, ReducerOperation::SeedSimulationDisease, |cb| runner
                .connection
                .reducers
                .seed_simulation_disease_then(
                    config.run_nonce.clone(),
                    character_id,
                    config.fixture_disease.clone(),
                    cb,
                ));
            runner.call(result)?;
        }
        runner.metrics.parties_formed += 1;
        runner.character_event(
            agent as u32,
            CoreLoopEventKind::FormParty,
            character_id,
            name,
        );
    }

    // Joining is demonstrated with the same ordinary request/accept reducers as players.
    // The bounded bootstrap co-locates fresh sim-* solo parties before they use
    // the ordinary request/accept reducers to merge.
    let settlement = runner
        .party_for(runner.character_ids[0])?
        .current_settlement_id
        .clone()
        .ok_or("leader not at settlement")?;
    let mut party_ids = Vec::new();
    let party_groups = balanced_party_groups(&runner.profiles, config.party_size as usize);
    for group in party_groups {
        let first = group[0];
        let leader = runner.character_ids[first];
        let leader_party = runner.party_for(leader)?;
        party_ids.push(leader_party.id.clone());
        for agent in group.into_iter().skip(1) {
            let member = runner.character_ids[agent];
            let result = reducer_call!(runner, ReducerOperation::RequestGeneralPartyJoin, |cb| runner
                .connection
                .reducers
                .request_general_party_join_then(member, leader_party.id.clone(), cb));
            runner.call(result)?;
            runner.metrics.joins_requested += 1;
            runner.event(
                agent as u32,
                CoreLoopEventKind::RequestJoin,
                leader_party.id.clone(),
            );
            let request = runner
                .connection
                .db
                .party_join_request()
                .iter()
                .find(|row| row.character_id == member && row.party_id == leader_party.id)
                .ok_or("join reducer completed without a coherent request row")?;
            let result = reducer_call!(runner, ReducerOperation::AcceptPartyJoinRequest, |cb| runner
                .connection
                .reducers
                .accept_party_join_request_then(leader, request.id, cb));
            runner.call(result)?;
            runner.metrics.joins_accepted += 1;
            runner.event(
                agent as u32,
                CoreLoopEventKind::AcceptJoin,
                leader_party.id.clone(),
            );
        }
    }
    let mut expected_quest_fixture_parties = None;
    let mut quest_lane_plan = None;
    if config.require_quest_coverage {
        if party_ids.len() < 2 {
            return Err("quest coverage fixture requires two formed parties".into());
        }
        let fixture_enemy = adventuresim_core::autoresolve::authored_threat_combatant(
            u64::MAX,
            "cultist",
            1,
            u32::from(adventuresim_world_schema::BASIS_POINTS_PER_WHOLE),
            u32::from(adventuresim_world_schema::BASIS_POINTS_PER_WHOLE),
        )?;
        let fixture_enemy_power =
            adventuresim_core::autoresolve::autoresolve_combat_power(&fixture_enemy);
        let mut candidates = Vec::new();
        for party_id in party_ids.iter().take(2) {
            let leader = runner
                .current_leader(party_id)
                .map(|(leader, _)| leader)
                .ok_or("quest coverage party has no leader")?;
            let assessment =
                runner.public_party_matchup_assessment(party_id, 1, 1, fixture_enemy_power);
            candidates.push(FixturePartyCandidate {
                identity: FixturePartyIdentity {
                    leader_id: leader,
                    party_id: party_id.clone(),
                },
                assessment,
            });
        }
        let FixturePartySelection {
            direct:
                FixturePartyIdentity {
                    leader_id: direct_leader,
                    party_id: direct_party,
                },
            generated:
                FixturePartyIdentity {
                    leader_id: generated_leader,
                    party_id: generated_party,
                },
        } = select_strongest_fixture_party(candidates)?;
        let existing_contract_ids = runner
            .connection
            .db
            .backend_contracts()
            .iter()
            .map(|contract| contract.id)
            .collect::<HashSet<_>>();
        let direct_settlement_id = runner
            .party_by_id(&direct_party)?
            .current_settlement_id
            .clone()
            .ok_or("quest coverage direct party is not in a settlement")?;
        let result = reducer_call!(runner, ReducerOperation::SeedSimulationQuestFixture, |cb| runner
            .connection
            .reducers
            .seed_simulation_quest_fixture_then(
                config.run_nonce.clone(),
                direct_leader,
                generated_leader,
                cb,
            ));
        runner.call(result)?;
        expected_quest_fixture_parties = Some([
            (direct_leader, direct_party),
            (generated_leader, generated_party),
        ]);
        let direct_contract_id = wait_for_new_public_direct_contract(
            &runner,
            &existing_contract_ids,
            &direct_settlement_id,
            &expected_quest_fixture_parties
                .as_ref()
                .expect("quest fixture parties were just designated")[0]
                .1,
        )?;
        quest_lane_plan = Some(FixtureLanePlan {
            direct_contract_id,
            generated_case_id: None,
            direct_leader_id: expected_quest_fixture_parties.as_ref().unwrap()[0].0,
            generated_leader_id: expected_quest_fixture_parties.as_ref().unwrap()[1].0,
            direct_party_id: expected_quest_fixture_parties.as_ref().unwrap()[0]
                .1
                .clone(),
            generated_party_id: expected_quest_fixture_parties.as_ref().unwrap()[1]
                .1
                .clone(),
        });
    }
    let result = reducer_call!(runner, ReducerOperation::EnsureSettlementActivity, |cb| runner
        .connection
        .reducers
        .ensure_settlement_activity_then(settlement.clone(), cb));
    runner.call(result)?;

    // Character clocks are absolute world minutes. Capture the post-bootstrap
    // baseline so a mature imported/disposable world does not make a fresh
    // simulation appear to have already exhausted its duration budget.
    let simulation_start_minutes = runner
        .character_ids
        .iter()
        .map(|character_id| {
            runner
                .connection
                .db
                .backend_character_times()
                .iter()
                .find(|row| row.character_id == *character_id)
                .map(|row| (*character_id, StrategicMinute::new(row.minutes.minutes)))
                .ok_or("missing simulation-start character clock")
        })
        .collect::<Result<HashMap<_, _>, _>>()?;
    let duration_minutes =
        u64::from(config.duration_days) * adventuresim_world_schema::calendar::MINUTES_PER_DAY;
    for cycle in 0..config.cycles {
        let mut active = false;
        let mut held = false;
        for party_id in &party_ids {
            runner.observe_deaths();
            runner.observe_external_generated_closures();
            if quest_lane_plan
                .as_ref()
                .is_some_and(|plan| plan.generated_case_id.is_none())
                && let Some(fixture) = select_public_quest_fixture_if_present(
                    runner.connection.db.simulation_quest_fixture().iter(),
                    claimed_run_id,
                    expected_quest_fixture_parties
                        .as_ref()
                        .expect("fixture lane plan requires designated parties"),
                )?
            {
                let plan = quest_lane_plan
                    .as_mut()
                    .expect("fixture projection appeared for an active lane plan");
                if fixture.direct_contract_id != plan.direct_contract_id {
                    return Err(
                            "required quest fixture public provenance identifies the wrong direct contract"
                                .into(),
                        );
                }
                plan.generated_case_id = Some(fixture.generated_case_id);
            }
            let party_time_before = runner.public_party_elapsed_max(party_id);
            let Some((pre_recovery_leader, _)) = runner.current_leader(party_id) else {
                continue;
            };
            let recovery_started_at = runner
                .connection
                .db
                .backend_character_times()
                .iter()
                .find(|row| row.character_id == pre_recovery_leader)
                .ok_or("missing pre-recovery leader clock")?
                .minutes;
            let recovery_started_in_budget = simulation_elapsed_minutes(
                *simulation_start_minutes
                    .get(&pre_recovery_leader)
                    .ok_or("missing simulation-start leader clock")?,
                StrategicMinute::new(recovery_started_at.minutes),
            ) < duration_minutes;
            if !recovery_started_in_budget {
                continue;
            }
            let recovery_outcome = runner.recover_or_evacuate_off_settlement(party_id, cycle)?;
            match recovery_outcome {
                ExpeditionRecoveryOutcome::None | ExpeditionRecoveryOutcome::Resumed => {}
                ExpeditionRecoveryOutcome::Returned => {
                    active = true;
                    let result = reducer_call!(runner, ReducerOperation::EnsureSettlementActivityAfterIdleSiteReturn,
                        |cb| {
                            runner
                                .connection
                                .reducers
                                .ensure_settlement_activity_then(settlement.clone(), cb)
                        }
                    );
                    runner.call(result)?;
                    continue;
                }
                ExpeditionRecoveryOutcome::Evacuated => {
                    active = true;
                    let result = reducer_call!(runner, ReducerOperation::EnsureSettlementActivityAfterEvacuation,
                        |cb| {
                            runner
                                .connection
                                .reducers
                                .ensure_settlement_activity_then(settlement.clone(), cb)
                        }
                    );
                    runner.call(result)?;
                    continue;
                }
                ExpeditionRecoveryOutcome::Held => {
                    held = true;
                    if runner.public_party_elapsed_max(party_id) > party_time_before {
                        active = true;
                    }
                    continue;
                }
            }
            let Some((leader, _)) = runner.current_leader(party_id) else {
                continue;
            };
            let elapsed = runner
                .connection
                .db
                .backend_character_times()
                .iter()
                .find(|row| row.character_id == leader)
                .ok_or("missing leader clock")?
                .minutes;
            let elapsed = simulation_elapsed_minutes(
                *simulation_start_minutes
                    .get(&leader)
                    .ok_or("missing simulation-start leader clock")?,
                StrategicMinute::new(elapsed.minutes),
            );
            if elapsed >= duration_minutes
                && !(recovery_outcome == ExpeditionRecoveryOutcome::Resumed
                    && recovery_started_in_budget)
            {
                continue;
            }
            match runner.continue_public_active_journey(party_id)? {
                None | Some(JourneyTravelOutcome::Completed) => {}
                Some(
                    JourneyTravelOutcome::DeferredForDaylightWindow
                    | JourneyTravelOutcome::HeldNoActionableActor
                    | JourneyTravelOutcome::HeldForRecovery,
                ) => {
                    held = true;
                    if runner.public_party_elapsed_max(party_id) > party_time_before {
                        active = true;
                    }
                    continue;
                }
            }
            let Some((leader, leader_agent)) = runner.current_leader(party_id) else {
                continue;
            };
            active = true;
            let profile = runner.profiles[leader_agent as usize].clone();
            let fixture_lane = fixture_quest_lane(quest_lane_plan.as_ref(), leader, party_id);
            let selector = fabelgeist_determinism::StreamId::new("simulation.quest-decision")
                .rng(config.seed, &[u64::from(leader_agent), u64::from(cycle)]).unit_f64();
            let quest_propensity = profile.activity_vs_quest_propensity;
            let wants_quest = fixture_lane.is_some()
                || (!profile.build.activity_only && selector < f64::from(quest_propensity));
            let party = runner.party_for(leader)?;
            let settlement_id = party.current_settlement_id.as_deref();
            let offered_contracts = settlement_id.map_or(0, |settlement_id| {
                runner
                    .connection
                    .db
                    .backend_contracts()
                    .iter()
                    .filter(|contract| {
                        contract.settlement_id == settlement_id
                            && contract.status == ContractStatus::Offered
                    })
                    .count()
            });
            let safe_offered_contracts = settlement_id.map_or(0, |settlement_id| {
                runner
                    .connection
                    .db
                    .backend_contracts()
                    .iter()
                    .filter(|contract| {
                        contract.settlement_id == settlement_id
                            && contract.status == ContractStatus::Offered
                            && runner
                                .public_party_contract_assessment(&party.id, contract)
                                .eligible
                    })
                    .count()
            });
            let mut open_generated_cases = runner.owned_open_generated_cases(leader);
            if fixture_lane == Some(FixtureQuestLane::Generated) {
                let generated_case_id = quest_lane_plan
                    .as_ref()
                    .expect("generated fixture lane has a plan")
                    .generated_case_id
                    .as_deref();
                open_generated_cases.retain(|(case_id, _)| {
                    generated_case_id.is_some_and(|expected| case_id == expected)
                });
            }
            for (case_id, title) in &open_generated_cases {
                runner.observe_generated_case_intake(
                    leader_agent,
                    leader,
                    case_id,
                    title,
                    GeneratedCaseIntakeSource::OwnerProjectionContinuation,
                );
            }
            let projected_investigation_actions = runner
                .connection
                .db
                .backend_investigation_actions()
                .iter()
                .filter(|row| {
                    row.owner_character_id == leader
                        && open_generated_cases
                            .iter()
                            .any(|(case_id, _)| case_id == &row.case_id)
                })
                .count();
            let safe_direct_quest = match fixture_lane {
                Some(FixtureQuestLane::Direct) => quest_lane_plan.as_ref().and_then(|fixture| {
                    runner
                        .connection
                        .db
                        .backend_contracts()
                        .iter()
                        .find(|contract| {
                            contract.id == fixture.direct_contract_id
                                && contract.settlement_id
                                    == party.current_settlement_id.clone().unwrap_or_default()
                                && contract.status == ContractStatus::Offered
                                && runner
                                    .public_party_contract_assessment(&party.id, contract)
                                    .eligible
                        })
                }),
                Some(FixtureQuestLane::Generated) => None,
                None => runner.choose_quest(&party, &profile),
            };
            let direct_quest_chosen = wants_quest && safe_direct_quest.is_some();
            let active_direct_contract = runner.active_direct_contract(&party).filter(|contract| {
                fixture_lane != Some(FixtureQuestLane::Direct)
                    || quest_lane_plan
                        .as_ref()
                        .is_some_and(|fixture| contract.id == fixture.direct_contract_id)
            });
            let quest_path = if fixture_lane == Some(FixtureQuestLane::Direct) {
                if active_direct_contract.is_some() {
                    "direct_contract_continuation"
                } else if safe_direct_quest.is_some() {
                    "direct_contract"
                } else {
                    "activity"
                }
            } else if fixture_lane == Some(FixtureQuestLane::Generated) {
                if !open_generated_cases.is_empty() {
                    "generated_open_case"
                } else {
                    "generated_discovery"
                }
            } else if profile.build.activity_only {
                "activity"
            } else if active_direct_contract.is_some() {
                "direct_contract_continuation"
            } else if !open_generated_cases.is_empty() {
                "generated_open_case"
            } else if direct_quest_chosen {
                "direct_contract"
            } else if wants_quest {
                "generated_discovery"
            } else {
                "activity"
            };
            let quest_selected = quest_path != "activity";
            runner.event(
                leader_agent,
                CoreLoopEventKind::QuestDecision,
                format_quest_decision_detail(QuestDecisionObservation {
                    cycle,
                    wants_quest,
                    selector,
                    quest_propensity,
                    settlement_id,
                    offered_contracts,
                    safe_offered_contracts,
                    open_generated_cases: open_generated_cases.len(),
                    projected_investigation_actions,
                    quest_path,
                    quest_intended: wants_quest,
                    quest_selected,
                    selection_reason: if wants_quest
                        && offered_contracts > 0
                        && safe_direct_quest.is_none()
                    {
                        "no_safe_contract"
                    } else if quest_selected {
                        "none"
                    } else {
                        "policy_prefers_activity"
                    },
                }),
            );
            match quest_path {
                "generated_open_case" => {
                    let selected = if fixture_lane == Some(FixtureQuestLane::Generated) {
                        open_generated_cases.first().cloned()
                    } else {
                        runner.select_owned_open_generated_case(leader)
                    };
                    let Some((case_id, title)) = selected else {
                        continue;
                    };
                    let before = runner.public_dialogue_progress_fingerprint(leader, &case_id);
                    let advance_result = runner.advance_generated_case(
                        party_id,
                        leader,
                        leader_agent,
                        cycle,
                        &case_id,
                        &title,
                    )?;
                    runner.record_generated_case_attempt(leader, &case_id, &before);
                    if advance_result == GeneratedAdvanceResult::NoProgress
                        && runner.party_for(leader)?.current_settlement_id.is_some()
                    {
                        runner.settlement_activity_day(leader_agent)?;
                    }
                }
                "direct_contract" | "direct_contract_continuation" => {
                    let reserved = (fixture_lane == Some(FixtureQuestLane::Direct)).then(|| {
                        quest_lane_plan
                            .as_ref()
                            .expect("direct fixture lane has a plan")
                            .direct_contract_id
                            .as_str()
                    });
                    runner.cycle(party_id, cycle, reserved)?
                }
                "generated_discovery" => {
                    let discovery = runner.discover_generated_case(leader, leader_agent, cycle)?;
                    if discovery.case_discovered() {
                        let selected = if fixture_lane == Some(FixtureQuestLane::Generated) {
                            let generated_case_id = quest_lane_plan
                                .as_ref()
                                .expect("generated fixture lane has a plan")
                                .generated_case_id
                                .as_deref();
                            runner.owned_open_generated_cases(leader).into_iter().find(
                                |(case_id, _)| {
                                    generated_case_id.is_some_and(|expected| case_id == expected)
                                },
                            )
                        } else {
                            runner.select_owned_open_generated_case(leader)
                        };
                        let Some((case_id, title)) = selected else {
                            continue;
                        };
                        let before = runner.public_dialogue_progress_fingerprint(leader, &case_id);
                        let advance_result = runner.advance_generated_case(
                            party_id,
                            leader,
                            leader_agent,
                            cycle,
                            &case_id,
                            &title,
                        )?;
                        runner.record_generated_case_attempt(leader, &case_id, &before);
                        if advance_result == GeneratedAdvanceResult::NoProgress
                            && runner.party_for(leader)?.current_settlement_id.is_some()
                        {
                            runner.settlement_activity_day(leader_agent)?;
                        }
                    } else {
                        runner.settlement_activity_day(leader_agent)?;
                    }
                }
                _ => runner.settlement_activity_day(leader_agent)?,
            }
            let result = reducer_call!(runner, ReducerOperation::EnsureSettlementActivity, |cb| runner
                .connection
                .reducers
                .ensure_settlement_activity_then(settlement.clone(), cb));
            runner.call(result)?;
        }
        if active {
            let result = reducer_call!(runner, ReducerOperation::AdvanceSimulationWorldTime, |cb| runner
                .connection
                .reducers
                .advance_simulation_world_time_then(
                    config.run_nonce.clone(),
                    adventuresim_world_schema::calendar::MINUTES_PER_DAY,
                    cb,
                ));
            runner.call(result)?;
            let result = reducer_call!(runner, ReducerOperation::EnsureSettlementActivity, |cb| runner
                .connection
                .reducers
                .ensure_settlement_activity_then(settlement.clone(), cb));
            runner.call(result)?;
        }
        if !active && held {
            break;
        }
        if !active {
            break;
        }
    }
    // One final bounded rescue pass runs even when the scenario duration or
    // cycle budget ended immediately after an off-settlement injury.
    for party_id in &party_ids {
        runner.observe_deaths();
        runner.recover_or_evacuate_off_settlement(party_id, config.cycles)?;
    }
    // Bounded final settlement cleanup prevents a duration cutoff from
    // stranding medical care or completed smith orders.
    for agent in 0..runner.character_ids.len() as u32 {
        let character_id = runner.character_ids[agent as usize];
        let at_settlement = runner
            .connection
            .db
            .backend_characters()
            .iter()
            .find(|row| row.id == character_id)
            .is_some_and(|row| row.alive && row.current_settlement_id.is_some());
        if at_settlement && runner.ensure_medically_safe(agent)? {
            runner.maintain_equipment(agent)?;
        }
    }
    runner.observe_deaths();
    for party_id in &party_ids {
        runner.observe_survival_telemetry(party_id);
    }

    let final_agents = runner
        .character_ids
        .iter()
        .enumerate()
        .map(|(agent, character_id)| {
            let character = runner
                .connection
                .db
                .backend_characters()
                .iter()
                .find(|row| row.id == *character_id)
                .ok_or("missing final character")?;
            let equipped_ids = runner
                .connection
                .db
                .character_equipped_item()
                .iter()
                .filter(|row| row.character_id == *character_id)
                .map(|row| row.inventory_item_id)
                .collect::<HashSet<_>>();
            let mut equipment_item_ids: Vec<String> = runner
                .connection
                .db
                .inventory_item()
                .iter()
                .filter(|row| row.character_id == *character_id)
                .filter(|row| equipped_ids.contains(&row.id))
                .map(|row| row.item_id)
                .collect();
            equipment_item_ids.sort();
            let capability = runner
                .connection
                .db
                .backend_character_capabilities()
                .iter()
                .find(|row| row.character_id == *character_id)
                .ok_or("missing final capability")?;
            let condition = runner
                .connection
                .db
                .backend_character_strategic_conditions()
                .iter()
                .find(|row| row.character_id == *character_id)
                .ok_or("missing final condition")?;
            let elapsed_minutes = runner
                .connection
                .db
                .backend_character_times()
                .iter()
                .find(|row| row.character_id == *character_id)
                .ok_or("missing final clock")?
                .minutes;
            let personal_gold_coin: u64 = runner
                .connection
                .db
                .inventory_item()
                .iter()
                .filter(|row| row.character_id == *character_id && is_currency_id(&row.item_id))
                .map(|row| u64::from(row.quantity))
                .sum();
            let worst_equipment_condition = equipped_ids
                .into_iter()
                .filter_map(|id| {
                    runner
                        .connection
                        .db
                        .item_condition()
                        .iter()
                        .find(|row| row.inventory_item_id == id)
                })
                .map(|row| {
                    1.0 - (row.tier_1 + row.tier_2 + row.tier_3 + row.tier_4 + row.tier_5)
                        .clamp(0.0, 1.0)
                })
                .fold(1.0_f32, f32::min);
            let outstanding_repair_orders = runner
                .connection
                .db
                .repair_order()
                .iter()
                .filter(|row| row.owner_character_id == *character_id)
                .count() as u32;
            let party_id = character.party_id.clone().ok_or("missing final party")?;
            let party_treasury = runner
                .connection
                .db
                .party_inventory_item()
                .iter()
                .filter(|row| row.party_id == party_id && is_currency_id(&row.item_id))
                .map(|row| u64::from(row.quantity))
                .sum();
            let party_stake = runner
                .connection
                .db
                .party_stake()
                .iter()
                .find(|row| row.party_id == party_id && row.character_id == *character_id)
                .map_or(0, |row| row.value);
            let public = runner
                .public_failure_agent(agent as u32, *character_id)
                .ok_or("missing final public diagnostic state")?;
            let survival = runner
                .public_survival_observation(*character_id)
                .ok_or("missing final public survival state")?;
            Ok(FinalAgentState {
                agent_id: agent as u32,
                character_id: *character_id,
                gold: personal_gold_coin.min(u64::from(u32::MAX)) as u32,
                equipment_item_ids,
                capability_summary: format!(
                    "melee={};ranged={};heavy={};athletics={:.2};endurance={:.2}",
                    capability.melee,
                    capability.ranged,
                    capability.heavy,
                    capability.athletics,
                    capability.endurance
                ),
                condition_status: domain_incapacitation_status(condition.status),
                thermal: survival.thermal,
                wetness_bps: survival.wetness_bps,
                thermal_strain: survival.thermal_strain,
                ammunition: survival.ammunition,
                carried_load_kg: survival.carried_load_kg,
                carry_capacity_kg: survival.carry_capacity_kg,
                encumbrance_remaining_bps: survival.encumbrance_remaining_bps,
                equipment_ready: survival.equipment_ready,
                party_tent_quantity: survival.party_tent_quantity,
                worst_equipment_condition,
                outstanding_repair_orders,
                alive: character.alive,
                elapsed_minutes: simulation_elapsed_minutes(
                    *simulation_start_minutes
                        .get(&character.id)
                        .ok_or("missing simulation-start final character clock")?,
                    StrategicMinute::new(elapsed_minutes.minutes),
                ),
                personal_gold_coin,
                party_treasury,
                party_stake,
                hunger: public.hunger,
                thirst: public.thirst,
                food_days: public.food_days,
                water_days: public.water_days,
                visible_food_kcal: public.visible_food_kcal,
                visible_water_ml: public.visible_water_ml,
                settlement_id: public.settlement_id,
                current_case_site_id: public.current_case_site_id,
                journey_destination: public.journey_destination,
                symptomatic: public.symptomatic,
                critical: public.critical,
                settlement_services: public.settlement_services,
                visible_herbalist_quote: public.visible_herbalist_quote,
                visible_inn_full_board_cost: public.visible_inn_full_board_cost,
            })
        })
        .collect::<Result<Vec<_>, String>>()?;
    let elapsed_game_minutes = final_agents
        .iter()
        .map(|agent| agent.elapsed_minutes)
        .max()
        .unwrap_or(0);
    let total_event_count = runner.sequence;
    let trace_truncated = total_event_count > runner.trace.len() as u64;
    let quest_fixture = if let Some(expected_parties) = expected_quest_fixture_parties.as_ref() {
        Some(select_public_quest_fixture(
            runner.connection.db.simulation_quest_fixture().iter(),
            claimed_run_id,
            expected_parties,
        )?)
    } else {
        None
    };
    let quest_coverage = quest_fixture.map(|fixture| {
        let direct_agent = runner
            .character_ids
            .iter()
            .position(|id| *id == fixture.direct_leader_id)
            .map(|agent| agent as u32);
        let generated_agent = runner
            .character_ids
            .iter()
            .position(|id| *id == fixture.generated_leader_id)
            .map(|agent| agent as u32);
        let direct_event = |kind: CoreLoopEventKind| {
            direct_agent.is_some_and(|agent| {
                runner.semantic_event_keys.iter().any(|key| {
                    key.agent_id == agent
                        && key.kind == kind
                        && matches!(
                            &key.subject,
                            CoreLoopEventSubject::DirectContract {
                                party_id,
                                contract_id,
                            } if party_id == &fixture.direct_party_id
                                && contract_id == &fixture.direct_contract_id
                        )
                })
            })
        };
        let generated_event = |kind: CoreLoopEventKind| {
            generated_agent.is_some_and(|agent| {
                runner.semantic_event_keys.iter().any(|key| {
                    key.agent_id == agent
                        && key.kind == kind
                        && matches!(
                            &key.subject,
                            CoreLoopEventSubject::GeneratedCase { party_id, case_id }
                                if party_id == &fixture.generated_party_id
                                    && case_id == &fixture.generated_case_id
                        )
                })
            })
        };
        QuestCoverageEvidence {
            direct_contract_id: fixture.direct_contract_id.clone(),
            generated_case_id: fixture.generated_case_id.clone(),
            direct_leader_id: fixture.direct_leader_id,
            generated_leader_id: fixture.generated_leader_id,
            direct_party_id: fixture.direct_party_id.clone(),
            generated_party_id: fixture.generated_party_id.clone(),
            direct_accepted: direct_event(CoreLoopEventKind::AcceptContract),
            direct_traveled: direct_event(CoreLoopEventKind::Travel),
            direct_encountered: direct_event(CoreLoopEventKind::AutoresolveVictory)
                || direct_event(CoreLoopEventKind::AutoresolveDefeat),
            direct_reported: direct_event(CoreLoopEventKind::TurnIn),
            direct_safely_abandoned: direct_event(CoreLoopEventKind::AbandonQuest),
            generated_intake: generated_event(CoreLoopEventKind::GeneratedCaseIntake),
            generated_discovered: generated_event(CoreLoopEventKind::GeneratedQuestDiscovered),
            generated_completed: generated_event(CoreLoopEventKind::GeneratedQuestCompleted),
        }
    });
    Ok(CoreLoopReport {
        format_version: crate::FORMAT_VERSION,
        backend_kind: "spacetimedb_authoritative_core_loop".into(),
        seed: config.seed,
        server_origin: config.host.clone(),
        database: config.database,
        run_nonce: config.run_nonce,
        fixture_disease: config.fixture_disease,
        deployment_identity_note: "server origin, database, and claimed run nonce identify this deployment; the SDK does not expose a deployed module binary digest".into(),
        world_artifact_id: world_import.as_ref().map(|import| import.artifact_id.clone()),
        world_manifest_digest: world_import
            .as_ref()
            .map(|import| import.manifest_digest.clone()),
        starting_settlement_id,
        profiles: runner.profiles,
        metrics: runner.metrics,
        quest_coverage,
        trace: runner.trace,
        trace_truncated,
        total_event_count,
        final_agents,
        elapsed_game_minutes,
        policy_seed_note: "seed controls profiles and policy choices only; authoritative autoresolve seeds are server RNG values recorded in the trace".into(),
    })
}
