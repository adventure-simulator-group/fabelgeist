//! Versioned, bounded input for deterministic tactical scene generation.
//!
//! This is deliberately data-only. Production dispatchers can sample the
//! imported terrain pack into it, while tactical-only tools can serialize a
//! synthetic fixture. Short-lived servers consume the identical format and
//! never need access to the continental source pack.

use adventuresim_core::weather::{Precipitation, WEATHER_RULES_VERSION, WeatherSnapshot};
use adventuresim_world_schema::BASIS_POINTS_PER_WHOLE;
use adventuresim_world_schema::calendar::{MINUTES_PER_DAY, StrategicMinute};
use bevy::prelude::Component;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};

use crate::scene_ground::build_scene_ground;
#[cfg(test)]
use crate::scene_ground::tree_leaf_litter_probability;
use crate::terrain_streams as streams;
use crate::{
    city_layout::{CityStreetPatch, CityYardPatch},
    scene::{GroundCover, GroundSubstrate, GroundSurface, SceneGround, SceneTerrain},
    volumetric_terrain::TerrainLandformRecipe,
};

pub use buildings::{
    BuildingOrientation, DistantBuildingPlacement, DistantBuildingVariant, GeneratedBuilding,
    SceneBuilding, SceneBuildingId, SceneDoor, SceneDoorError, SceneWindow, SceneWindowError,
    TacticalBuildingPlacement, compile_tactical_building_collider,
};
pub use compounds::{GeneratedBoundary, SceneBoundary};
pub use descriptor::{
    MAX_SCENE_INPUT_BYTES, TACTICAL_SCENE_GENERATION_VERSION, TACTICAL_SCENE_SCHEMA_VERSION,
    TacticalSceneInput,
};
use detail_noise::value_noise;
pub use environment::{SceneEnvironment, SceneEnvironmentFixture};
pub use error::{SceneInputError, SceneInputResult};
pub use establishments::SceneEstablishment;
pub use gardens::{GardenPlantSupport, GardenSupportError, SceneGarden};
pub use generated::{GeneratedTacticalScene, SceneRepairReport};
pub use generation::{SupportedSceneTerrain, UngradedSceneTerrain};
pub use recipes::{GeneratedBuildingRecipe, GeneratedBuildingRecipes, ProgramFurnitureSite};
use rock_recipe::rock_recipe;
pub use terrain_samples::{
    EnvironmentalSample, SceneSource, TacticalSurface, TerrainSampleGrid, VistaLevelIndex,
    VistaLod, VistaSample,
};
pub use validation_error::{SampleGridKind, SceneValidationError};

mod absolute_elevation_wire;
pub(crate) mod buildings;
mod compounds;
mod descriptor;
mod detail_noise;
mod detail_obstacles;
mod environment;
mod error;
mod establishments;
pub mod furniture;
mod gardens;
mod generated;
mod generation;
mod parishes;
mod properties;
mod recipes;
mod refinement;
mod rock_recipe;
mod rock_streams;
mod terrain_samples;
mod urban;
mod validation;
mod validation_error;

pub const TREE_TRUNK_RADIUS_METRES: f32 = 0.35;
pub const TREE_TRUNK_HEIGHT_METRES: f32 = 5.0;
/// Conservative ground footprint of the generated English-oak crown.
pub const TREE_CANOPY_GROUND_RADIUS_METRES: f32 = 5.75;
/// The trunk base is reliably leaf-covered; the outer crown uses a tapered
/// mosaic so sparse woodland does not stamp grass-free canopy discs.
pub(crate) const TREE_DENSE_LEAF_LITTER_RADIUS_METRES: f32 = 2.25;
pub const ROCK_RADIUS_METRES: f32 = 0.75;
const MAX_PLAYABLE_SIDE: usize = 601;
const MAX_VISTA_LEVELS: usize = 8;
const MAX_VISTA_SAMPLES: usize = 2_000_000;
const MAX_TEMPLATE_BYTES: usize = 128;
const MAX_SOURCE_ID_BYTES: usize = 128;

/// Data-only recipe for a client-generated boulder mesh.
///
/// Dimensions describe the full local-space bounds in centimetres. The
/// authoritative server uses only `collision_radius_cm` for a conservative
/// sphere proxy; it never samples the field or extracts render geometry.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RockRecipe {
    pub seed: fabelgeist_determinism::Seed,
    pub archetype: RockArchetype,
    pub lithology: RockLithology,
    pub dimensions_cm: [u16; 3],
    pub collision_radius_cm: u16,
}

/// Broad procedural silhouette family for a collider-bearing rock.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RockArchetype {
    Rounded,
    Angular,
    Slab,
}

/// Compact material family for generated geological geometry.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RockLithology {
    Granite,
    Limestone,
    Sandstone,
}

/// Compact replicated identity for a server-authoritative static obstacle.
/// Its Transform locates the collider center; presentation derives matching
/// proxy geometry from this recipe on each client.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Component, Serialize, Deserialize)]
#[component(immutable)]
#[serde(rename_all = "snake_case")]
pub enum SceneObstacle {
    Tree,
    Rock(RockRecipe),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum GeneratedObstacle {
    Tree { x: u16, z: u16 },
    Rock { x: u16, z: u16, recipe: RockRecipe },
}

impl RockRecipe {
    pub fn collision_radius_metres(self) -> f32 {
        f32::from(self.collision_radius_cm) / 100.0
    }

    pub fn dimensions_metres(self) -> [f32; 3] {
        self.dimensions_cm
            .map(|dimension| f32::from(dimension) / 100.0)
    }
}

impl TacticalSceneInput {
    pub fn load(path: &Path) -> SceneInputResult<Self> {
        let length = fs::metadata(path)?.len();
        if length == 0 || length > MAX_SCENE_INPUT_BYTES {
            return Err(SceneInputError::Validation(SceneValidationError::FileSize));
        }
        let input: Self = serde_json::from_slice(&fs::read(path)?)?;
        input.validate()?;
        Ok(input)
    }

    pub fn validate(&self) -> SceneInputResult<()> {
        self.validate_source()?;
        self.validate_grounding()
    }

    pub fn digest(&self) -> SceneInputResult<String> {
        self.validate()?;
        let bytes = serde_json::to_vec(self)?;
        Ok(Sha256::digest(bytes)
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect())
    }

    pub fn environment_snapshot(&self, scene_digest: String) -> SceneEnvironment {
        let count = self.playable.environment.len().max(1) as u64;
        let sum = self
            .playable
            .environment
            .iter()
            .fold([0u64; 5], |mut sum, sample| {
                sum[0] += u64::from(sample.canopy_bps);
                sum[1] += u64::from(sample.wetland_bps);
                sum[2] += u64::from(sample.cultivation_bps);
                sum[3] += u64::from(sample.water_bps);
                sum[4] += u64::from(sample.hilly_bps);
                sum
            });
        SceneEnvironment {
            scene_digest,
            generation_version: self.generation_version,
            latitude_microdegrees: self.latitude_microdegrees,
            longitude_microdegrees: self.longitude_microdegrees,
            absolute_minute: self.absolute_minute,
            lunar_phase_minute: self.lunar_phase_minute,
            absolute_elevation_metres: self.absolute_elevation_metres,
            weather: self.weather,
            canopy_bps: (sum[0] / count) as u16,
            wetland_bps: (sum[1] / count) as u16,
            cultivation_bps: (sum[2] / count) as u16,
            water_bps: (sum[3] / count) as u16,
            hilly_bps: (sum[4] / count) as u16,
        }
    }
}

pub(crate) fn base_ground_surface(sample: EnvironmentalSample) -> GroundSurface {
    if sample.crossing_bps >= 5_000 || matches!(sample.surface, TacticalSurface::Road) {
        return GroundSurface {
            substrate: GroundSubstrate::Road,
            cover: GroundCover::Bare,
            cover_density_bps: 0,
            cover_height_cm: 0,
        };
    }
    if sample.water_bps >= 5_000 || matches!(sample.surface, TacticalSurface::Water) {
        return GroundSurface {
            substrate: GroundSubstrate::Water,
            cover: GroundCover::Bare,
            cover_density_bps: 0,
            cover_height_cm: 0,
        };
    }
    if sample.wetland_bps >= 5_000 || matches!(sample.surface, TacticalSurface::Wetland) {
        return GroundSurface {
            substrate: GroundSubstrate::Mud,
            cover: GroundCover::Reeds,
            cover_density_bps: sample.wetland_bps.max(5_000),
            cover_height_cm: 110,
        };
    }
    if sample.hilly_bps >= 6_500 {
        return GroundSurface {
            substrate: if sample.hilly_bps >= 8_500 {
                GroundSubstrate::Stone
            } else {
                GroundSubstrate::Gravel
            },
            cover: GroundCover::LooseStone,
            cover_density_bps: (sample.hilly_bps / 2).clamp(3_250, 5_000),
            cover_height_cm: 4,
        };
    }
    GroundSurface {
        substrate: GroundSubstrate::Soil,
        cover: GroundCover::TallGrass,
        cover_density_bps: 9_600u16.saturating_sub(sample.canopy_bps / 5),
        cover_height_cm: 82,
    }
}

fn upsample_playable_grid(
    source: &TerrainSampleGrid,
) -> (usize, usize, f32, Vec<f32>, Vec<EnvironmentalSample>) {
    const TARGET_SPACING_METRES: f32 = 2.0;
    let source_width = usize::from(source.width);
    let source_depth = usize::from(source.depth);
    if source.spacing_metres <= TARGET_SPACING_METRES {
        return (
            source_width,
            source_depth,
            source.spacing_metres,
            source.heights_metres.clone(),
            source.environment.clone(),
        );
    }
    let largest_source_side = (source_width - 1).max(source_depth - 1);
    let maximum_subdivisions = ((MAX_PLAYABLE_SIDE - 1) / largest_source_side).max(1);
    let subdivisions = (source.spacing_metres / TARGET_SPACING_METRES)
        .ceil()
        .max(1.0) as usize;
    let subdivisions = subdivisions.min(maximum_subdivisions);
    let cells_x = (source_width - 1) * subdivisions;
    let cells_z = (source_depth - 1) * subdivisions;
    let width = cells_x + 1;
    let depth = cells_z + 1;
    let spacing = source.spacing_metres / subdivisions as f32;
    let mut heights = Vec::with_capacity(width * depth);
    let mut environment = Vec::with_capacity(width * depth);
    for z in 0..depth {
        for x in 0..width {
            let source_x = x as f32 / subdivisions as f32;
            let source_z = z as f32 / subdivisions as f32;
            let x0 = source_x.floor() as usize;
            let z0 = source_z.floor() as usize;
            let x1 = (x0 + 1).min(source_width - 1);
            let z1 = (z0 + 1).min(source_depth - 1);
            let tx = source_x - x0 as f32;
            let tz = source_z - z0 as f32;
            let north = lerp(
                source.heights_metres[z0 * source_width + x0],
                source.heights_metres[z0 * source_width + x1],
                tx,
            );
            let south = lerp(
                source.heights_metres[z1 * source_width + x0],
                source.heights_metres[z1 * source_width + x1],
                tx,
            );
            heights.push(lerp(north, south, tz));
            let nearest_x = source_x.round() as usize;
            let nearest_z = source_z.round() as usize;
            environment.push(source.environment[nearest_z * source_width + nearest_x]);
        }
    }
    (width, depth, spacing, heights, environment)
}

fn lerp(left: f32, right: f32, amount: f32) -> f32 {
    left + (right - left) * amount
}

/// Adds sub-source-resolution detail before constructing the shared terrain.
/// The result therefore feeds the rendered mesh, height queries, IK, and the
/// authoritative server collider instead of becoming client-only displacement.
fn add_authoritative_microrelief(
    seed: fabelgeist_determinism::Seed,
    width: usize,
    depth: usize,
    spacing: f32,
    heights: &mut [f32],
    environment: &[EnvironmentalSample],
) -> u32 {
    let mut adjusted = 0;
    for z in 0..depth {
        for x in 0..width {
            let index = z * width + x;
            let sample = environment[index];
            if is_reserved_playability_cell(x, z, width, depth)
                || sample.water_bps >= 5_000
                || sample.crossing_bps >= 5_000
                || matches!(
                    sample.surface,
                    TacticalSurface::Road | TacticalSurface::Water
                )
            {
                continue;
            }
            let hilly = f32::from(sample.hilly_bps) / f32::from(BASIS_POINTS_PER_WHOLE);
            let wetland = f32::from(sample.wetland_bps) / f32::from(BASIS_POINTS_PER_WHOLE);
            let amplitude = (0.055 + hilly * 0.22) * (1.0 - wetland * 0.55);
            let world_x = x as f32 * spacing;
            let world_z = z as f32 * spacing;
            let broad = value_noise(seed, world_x, world_z, 6.0);
            let fine = value_noise(
                streams::MICRORELIEF_FINE.seed(seed, &[]),
                world_x,
                world_z,
                2.25,
            );
            let offset = (broad * 0.72 + fine * 0.28) * amplitude;
            if offset.abs() > 0.0 {
                heights[index] += offset;
                adjusted += 1;
            }
        }
    }
    adjusted
}

fn repair_playable_terrain(
    width: usize,
    depth: usize,
    spacing: f32,
    heights: &mut [f32],
    environment: &mut [EnvironmentalSample],
) -> SceneInputResult<SceneRepairReport> {
    let original_heights = heights.to_vec();
    crate::scene::grade::constrain(
        heights,
        width,
        depth,
        spacing,
        crate::scene::TerrainGradeLimit::PLAYABLE.ratio(),
    )?;

    let mut repaired_water_samples = 0;
    for z in 0..depth {
        for x in 0..width {
            if is_reserved_playability_cell(x, z, width, depth)
                && environment[z * width + x].water_bps >= 8_000
            {
                let sample = &mut environment[z * width + x];
                sample.water_bps = 0;
                sample.wetland_bps = sample.wetland_bps.min(4_000);
                sample.canopy_bps = 0;
                sample.surface = TacticalSurface::Open;
                repaired_water_samples += 1;
            }
        }
    }
    Ok(SceneRepairReport {
        upsampled_height_samples: 0,
        microrelief_adjusted_samples: 0,
        adjusted_height_samples: heights
            .iter()
            .zip(original_heights)
            .filter(|(after, before)| (*after - before).abs() > 0.0)
            .count() as u32,
        repaired_water_samples,
        removed_corridor_obstacles: 0,
        levelled_building_samples: 0,
        removed_building_obstacles: 0,
    })
}

fn is_reserved_playability_cell(x: usize, z: usize, width: usize, depth: usize) -> bool {
    let center_z = depth / 2;
    let party_x = width / 4;
    let enemy_x = width * 3 / 4;
    z == center_z
        || [party_x, enemy_x]
            .into_iter()
            .any(|center_x| x.abs_diff(center_x) <= 1 && z.abs_diff(center_z) <= 1)
}

fn is_tree_camera_clearance_cell(_x: usize, z: usize, depth: usize) -> bool {
    let center_z = depth / 2;
    // Players currently enter within a bounded five-metre square around the
    // scene origin. Keep only large tree crowns out of the centre row and its
    // immediate neighbours so they cannot enter the production third-person
    // camera envelope. Rocks and terrain repair retain the narrower gameplay
    // corridor contract above.
    z.abs_diff(center_z) <= 1
}

fn validate_grid(
    grid: &TerrainSampleGrid,
    max_side: usize,
    grid_kind: SampleGridKind,
) -> SceneInputResult<()> {
    let width = usize::from(grid.width);
    let depth = usize::from(grid.depth);
    if width < 2 || depth < 2 || width > max_side || depth > max_side {
        return invalid(SceneValidationError::GridDimensions { grid: grid_kind });
    }
    if !grid.spacing_metres.is_finite() || !(0.25..=2_000.0).contains(&grid.spacing_metres) {
        return invalid(SceneValidationError::GridSpacing { grid: grid_kind });
    }
    let expected = width.checked_mul(depth).ok_or({
        SceneInputError::Validation(SceneValidationError::GridOverflow { grid: grid_kind })
    })?;
    if grid.heights_metres.len() != expected || grid.environment.len() != expected {
        return invalid(SceneValidationError::GridSamples { grid: grid_kind });
    }
    if grid
        .heights_metres
        .iter()
        .any(|height| !height.is_finite() || !(-12_000.0..=12_000.0).contains(height))
    {
        return invalid(SceneValidationError::GridHeight { grid: grid_kind });
    }
    if grid.environment.iter().any(|sample| {
        [
            sample.canopy_bps,
            sample.wetland_bps,
            sample.cultivation_bps,
            sample.water_bps,
            sample.hilly_bps,
            sample.crossing_bps,
        ]
        .into_iter()
        .any(|value| value > BASIS_POINTS_PER_WHOLE)
    }) {
        return invalid(SceneValidationError::GridEnvironment { grid: grid_kind });
    }
    Ok(())
}

fn validate_weather(weather: WeatherSnapshot) -> SceneInputResult<()> {
    if weather.rules_version != WEATHER_RULES_VERSION
        || weather.wind_speed_bps > BASIS_POINTS_PER_WHOLE
        || weather.intensity_bps > BASIS_POINTS_PER_WHOLE
        || weather.ground_moisture_bps > BASIS_POINTS_PER_WHOLE
        || weather.snow_cover_bps > BASIS_POINTS_PER_WHOLE
        || weather.atmosphere.relative_humidity_bps > BASIS_POINTS_PER_WHOLE
        || weather.atmosphere.dew_point_deci_c > weather.temperature_deci_c + 5
        || !(8_700..=10_850).contains(&weather.atmosphere.sea_level_pressure_deci_hpa)
        || weather.atmosphere.wind_direction_degrees >= 360
        || weather.atmosphere.wind_shear_bps > BASIS_POINTS_PER_WHOLE
        || weather.atmosphere.instability_bps > BASIS_POINTS_PER_WHOLE
        || !(-i16::try_from(BASIS_POINTS_PER_WHOLE).unwrap()
            ..=i16::try_from(BASIS_POINTS_PER_WHOLE).unwrap())
            .contains(&weather.atmosphere.lift_bps)
        || weather.cloud_layers().any(|layer| {
            layer.coverage_bps > BASIS_POINTS_PER_WHOLE
                || layer.optical_density_bps > BASIS_POINTS_PER_WHOLE
                || layer.top_metres <= layer.base_metres
        })
        || (matches!(weather.precipitation, Precipitation::Clear) && weather.intensity_bps != 0)
        || (!matches!(weather.precipitation, Precipitation::Clear)
            && (weather.intensity_bps == 0
                || !weather.cloud_layers().any(|layer| {
                    matches!(
                        layer.form,
                        adventuresim_core::weather::CloudForm::Cumulonimbus
                            | adventuresim_core::weather::CloudForm::Nimbostratus
                    )
                })))
    {
        return invalid(SceneValidationError::Weather);
    }
    Ok(())
}

fn invalid<T>(issue: SceneValidationError) -> SceneInputResult<T> {
    Err(SceneInputError::Validation(issue))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::scene_coordinates::ScenePlanPoint;
    mod occupied;
    use crate::volumetric_terrain::TerrainSurfaceSource;
    use adventuresim_core::weather::weather_at;
    use adventuresim_world_schema::{
        IgneousRock, MixedLithology, SedimentaryRock, SurfaceLithology, UnconsolidatedDeposit,
    };
    use std::time::SystemTime;

    pub(super) fn fixture() -> TacticalSceneInput {
        let environment = vec![
            EnvironmentalSample {
                canopy_bps: 8_000,
                ..Default::default()
            };
            9
        ];
        TacticalSceneInput {
            grounding: None,
            properties: None,
            schema_version: TACTICAL_SCENE_SCHEMA_VERSION,
            generation_version: TACTICAL_SCENE_GENERATION_VERSION,
            seed: 42.into(),
            scene_key: "woodland".into(),
            source: SceneSource::SyntheticFixture("dense-woodland".into()),
            latitude_microdegrees:
                adventuresim_world_schema::coordinates::LatitudeMicrodegrees::new(53_500_000)
                    .unwrap(),
            longitude_microdegrees:
                adventuresim_world_schema::coordinates::LongitudeMicrodegrees::new(10_000_000)
                    .unwrap(),
            absolute_minute: StrategicMinute::new(123_456),
            lunar_phase_minute: StrategicMinute::new(123_456),
            absolute_elevation_metres: adventuresim_world_schema::ElevationMeters::new(80).unwrap(),
            playable: TerrainSampleGrid {
                width: 3,
                depth: 3,
                spacing_metres: 1.0,
                heights_metres: vec![0.0, 0.1, 0.0, 0.1, 0.2, 0.1, 0.0, 0.1, 0.0],
                environment,
            },
            landform: None,
            streets: Vec::new(),
            yards: Vec::new(),
            parishes: Vec::new(),
            compounds: Vec::new(),
            gardens: Vec::new(),
            buildings: Vec::new(),
            distant_buildings: Vec::new(),
            establishments: Vec::new(),
            vista: VistaSample::default(),
            weather: weather_at(
                fabelgeist_determinism::Seed::from_u64(42),
                adventuresim_world_schema::calendar::StrategicMinute::new(123_456),
                53_500_000,
                10_000_000,
                80,
            ),
        }
    }

    #[test]
    fn generation_and_digest_are_reproducible() {
        let input = fixture();
        let first = input.generate().unwrap();
        let second = input.generate().unwrap();
        assert_eq!(first.digest, second.digest);
        assert_eq!(first.obstacles, second.obstacles);
        assert_eq!(
            first.terrain.height_at(ScenePlanPoint::ORIGIN),
            second.terrain.height_at(ScenePlanPoint::ORIGIN)
        );
        assert_eq!(
            first.repairs.microrelief_adjusted_samples,
            second.repairs.microrelief_adjusted_samples
        );
    }

    #[test]
    fn city_streets_replace_grass_with_their_authored_substrate() {
        let mut input = fixture();
        input.streets = vec![
            CityStreetPatch::Corridor {
                start_metres: bevy::math::Vec2::new(-2.0, 0.0),
                end_metres: bevy::math::Vec2::new(2.0, 0.0),
                half_width_metres: 1.0,
                surface: crate::city_layout::CityStreetSurface::CompactedEarth,
            },
            CityStreetPatch::Corridor {
                start_metres: bevy::math::Vec2::new(-1.0, -2.0),
                end_metres: bevy::math::Vec2::new(-1.0, 2.0),
                half_width_metres: 1.0,
                surface: crate::city_layout::CityStreetSurface::Fieldstone,
            },
        ];

        let generated = input.generate().unwrap();
        assert_eq!(
            generated
                .ground
                .ground_at(ScenePlanPoint::from_metres(bevy::math::Vec2::new(1.0, 0.0)).unwrap()),
            Some(GroundSurface {
                substrate: GroundSubstrate::Soil,
                cover: GroundCover::Bare,
                cover_density_bps: 0,
                cover_height_cm: 0,
            })
        );
        assert_eq!(
            generated
                .ground
                .ground_at(ScenePlanPoint::from_metres(bevy::math::Vec2::new(-1.0, 0.0)).unwrap()),
            Some(GroundSurface {
                substrate: GroundSubstrate::Road,
                cover: GroundCover::Bare,
                cover_density_bps: 0,
                cover_height_cm: 0,
            })
        );
    }

    #[test]
    fn developed_city_yards_replace_meadow_cover_with_bare_soil() {
        let mut input = fixture();
        input.yards.push(CityYardPatch {
            corners_metres: [
                bevy::math::Vec2::new(-1.0, -1.0),
                bevy::math::Vec2::new(1.0, -1.0),
                bevy::math::Vec2::new(1.0, 1.0),
                bevy::math::Vec2::new(-1.0, 1.0),
            ],
            surface: crate::city_layout::CityYardSurface::PackedEarth,
        });

        let generated = input.generate().unwrap();
        assert_eq!(
            generated.ground.ground_at(ScenePlanPoint::ORIGIN),
            Some(GroundSurface {
                substrate: GroundSubstrate::Soil,
                cover: GroundCover::Bare,
                cover_density_bps: 0,
                cover_height_cm: 0,
            })
        );
    }

    #[test]
    fn microrelief_is_bounded_deterministic_and_preserves_the_combat_corridor() {
        let width = 25;
        let depth = 25;
        let environment = vec![
            EnvironmentalSample {
                hilly_bps: 10_000,
                ..Default::default()
            };
            width * depth
        ];
        let mut first = vec![0.0; width * depth];
        let mut second = first.clone();
        let first_count =
            add_authoritative_microrelief(91.into(), width, depth, 1.0, &mut first, &environment);
        let second_count =
            add_authoritative_microrelief(91.into(), width, depth, 1.0, &mut second, &environment);
        assert_eq!(first, second);
        assert_eq!(first_count, second_count);
        assert!(first_count > 0);
        assert!(first.iter().all(|height| height.abs() <= 0.275 + 0.001));
        assert!((0..width).all(|x| first[(depth / 2) * width + x] == 0.0));
    }

    #[test]
    fn coarse_source_grid_is_upsampled_without_changing_extent() {
        let source = TerrainSampleGrid {
            width: 3,
            depth: 2,
            spacing_metres: 12.5,
            heights_metres: vec![0.0, 1.0, 2.0, 2.0, 3.0, 4.0],
            environment: vec![EnvironmentalSample::default(); 6],
        };
        let (width, depth, spacing, heights, environment) = upsample_playable_grid(&source);
        assert!(spacing <= 2.0);
        assert_eq!((width - 1) as f32 * spacing, 25.0);
        assert_eq!((depth - 1) as f32 * spacing, 12.5);
        assert_eq!(heights.len(), width * depth);
        assert_eq!(environment.len(), width * depth);
        assert!((heights[(depth - 1) * width + width - 1] - 4.0).abs() < 0.0001);
    }

    #[test]
    fn rejects_versions_bounds_and_malformed_sample_counts() {
        let mut input = fixture();
        input.schema_version += 1;
        assert!(input.validate().is_err());
        input = fixture();
        input.playable.heights_metres.pop();
        assert!(input.validate().is_err());
        input = fixture();
        let mut encoded = serde_json::to_value(&input).unwrap();
        encoded["latitude_microdegrees"] = serde_json::json!(90_000_001);
        assert!(serde_json::from_value::<TacticalSceneInput>(encoded).is_err());
    }

    #[test]
    fn unknown_json_fields_fail_closed() {
        let mut value = serde_json::to_value(fixture()).unwrap();
        value
            .as_object_mut()
            .unwrap()
            .insert("tick_state".into(), 1.into());
        assert!(serde_json::from_value::<TacticalSceneInput>(value).is_err());
    }

    #[test]
    fn oversized_scene_file_fails_before_deserialization() {
        let nonce = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "adventuresim-oversized-scene-{}-{nonce}.json",
            std::process::id()
        ));
        let file = fs::File::create(&path).unwrap();
        file.set_len(MAX_SCENE_INPUT_BYTES + 1).unwrap();
        drop(file);
        let error = TacticalSceneInput::load(&path).unwrap_err();
        fs::remove_file(path).unwrap();
        assert!(error.to_string().contains("32 MiB"));
    }

    #[test]
    fn committed_synthetic_fixture_catalog_uses_the_production_format() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../assets/tactical-scenes");
        let names = [
            "flat-dry-grassland",
            "steep-open-hillside",
            "dense-woodland",
            "sparse-woodland",
            "saturated-wetland",
            "cultivated-roadside",
            "snow-covered-ground",
            "heavy-rain-high-wind",
            "valley-distant-ridge",
            "narrow-peak-lod-boundary",
            "playability-repair-required",
        ];
        for name in names {
            let input = TacticalSceneInput::load(&root.join(format!("{name}.json"))).unwrap();
            assert_eq!(input.source, SceneSource::SyntheticFixture(name.into()));
            assert_eq!(input.absolute_minute.minute_of_day(), 10 * 60);
            let generated = input.generate().unwrap();
            assert_eq!(generated.terrain.width(), 100.0);
            assert!(generated.terrain.grid_scale() <= 2.0);
            assert!(generated.repairs.upsampled_height_samples > 0);
            assert_eq!(input.vista.lods.len(), 3);
            let playable_center =
                input.playable.heights_metres[usize::from(input.playable.depth / 2)
                    * usize::from(input.playable.width)
                    + usize::from(input.playable.width / 2)];
            for lod in &input.vista.lods {
                let vista_center = lod.heights_metres[usize::from(lod.depth / 2)
                    * usize::from(lod.width)
                    + usize::from(lod.width / 2)];
                assert!(
                    (vista_center - playable_center).abs() < 0.001,
                    "{name} vista LOD {} must share the playable height datum",
                    lod.level
                );
            }
            let horizon = input.vista.lods.last().unwrap();
            assert_eq!(
                f32::from(horizon.width - 1) * horizon.spacing_metres,
                50_000.0
            );
        }
    }

    #[test]
    fn every_committed_landform_fixture_authors_its_surface_truth() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../assets/tactical-scenes");
        let expected = [
            (
                "fault-scarp-cliff",
                SurfaceLithology::Mixed(MixedLithology::Breccia),
            ),
            (
                "sandstone-alcove",
                SurfaceLithology::Sedimentary(SedimentaryRock::Sandstone),
            ),
            (
                "carbonate-dissolution",
                SurfaceLithology::Sedimentary(SedimentaryRock::Limestone),
            ),
            (
                "granite-joint-rockfall",
                SurfaceLithology::Igneous(IgneousRock::Granite),
            ),
            (
                "basalt-cooling-columns",
                SurfaceLithology::Igneous(IgneousRock::Basalt),
            ),
            (
                "cohesive-slump-headscarp",
                SurfaceLithology::Unconsolidated(UnconsolidatedDeposit::Clay),
            ),
        ];
        for (name, lithology) in expected {
            let input = TacticalSceneInput::load(&root.join(format!("{name}.json"))).unwrap();
            let recipe = input.landform.expect("landform fixture has a recipe");
            assert_eq!(recipe.surface().lithology(), lithology, "{name}");
            assert_eq!(
                recipe.surface().source(),
                TerrainSurfaceSource::AuthoredFixture
            );
            recipe.surface().validate().unwrap();
        }

        let mut missing_surface: serde_json::Value =
            serde_json::from_str(&fs::read_to_string(root.join("sandstone-alcove.json")).unwrap())
                .unwrap();
        missing_surface["landform"]
            .as_object_mut()
            .unwrap()
            .remove("surface");
        assert!(serde_json::from_value::<TacticalSceneInput>(missing_surface).is_err());
    }

    #[test]
    fn narrow_peak_is_preserved_on_the_regional_horizon_lod_boundary() {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../assets/tactical-scenes/narrow-peak-lod-boundary.json");
        let input = TacticalSceneInput::load(&path).unwrap();
        let regional = &input.vista.lods[1];
        let horizon = &input.vista.lods[2];
        let peak_column = |lod: &VistaLod| {
            usize::from(lod.width / 2) + (5_000.0 / lod.spacing_metres).round() as usize
        };
        let regional_peak = regional.heights_metres
            [usize::from(regional.depth / 2) * usize::from(regional.width) + peak_column(regional)];
        let horizon_peak = horizon.heights_metres
            [usize::from(horizon.depth / 2) * usize::from(horizon.width) + peak_column(horizon)];
        assert!(regional_peak >= 899.0);
        assert!((regional_peak - horizon_peak).abs() < 0.001);
    }

    #[test]
    fn committed_obstacle_fixtures_exercise_sparse_trees_and_hilly_rocks() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../assets/tactical-scenes");
        let flat = TacticalSceneInput::load(&root.join("flat-dry-grassland.json"))
            .unwrap()
            .generate()
            .unwrap();
        let sparse_input = TacticalSceneInput::load(&root.join("sparse-woodland.json")).unwrap();
        let sparse_spacing = sparse_input.playable.spacing_metres;
        let sparse = sparse_input.generate().unwrap();
        let hillside = TacticalSceneInput::load(&root.join("steep-open-hillside.json"))
            .unwrap()
            .generate()
            .unwrap();
        assert!(flat.obstacles.is_empty());
        assert!(flat.terrain.grid_scale() <= refinement::AUTHORITATIVE_DETAIL_SPACING_METRES);
        assert!(flat.terrain.coarse_grid_scale() > flat.terrain.grid_scale());
        assert!(
            sparse
                .obstacles
                .iter()
                .any(|obstacle| matches!(obstacle, GeneratedObstacle::Tree { .. }))
        );
        assert!(
            hillside
                .obstacles
                .iter()
                .any(|obstacle| matches!(obstacle, GeneratedObstacle::Rock { .. }))
        );
        assert!(
            flat.ground.cover_count(GroundCover::TallGrass)
                > flat.ground.cover_count(GroundCover::LeafLitter)
        );
        for obstacle in &sparse.obstacles {
            let GeneratedObstacle::Tree { x, z } = *obstacle else {
                continue;
            };
            let position = bevy::math::Vec2::new(
                f32::from(x) * sparse_spacing - sparse.terrain.width() * 0.5,
                f32::from(z) * sparse_spacing - sparse.terrain.depth() * 0.5,
            );
            assert_eq!(
                sparse
                    .ground
                    .ground_at(ScenePlanPoint::from_metres(position).unwrap())
                    .unwrap()
                    .cover,
                GroundCover::LeafLitter
            );
        }
        assert!(sparse.ground.cover_count(GroundCover::LeafLitter) > 0);
        assert!(
            sparse.ground.cover_count(GroundCover::TallGrass)
                > sparse.ground.cover_count(GroundCover::LeafLitter),
            "sparse crowns should retain a dappled grass matrix"
        );
    }

    #[test]
    fn tree_leaf_litter_tapers_from_a_dense_trunk_core() {
        assert_eq!(tree_leaf_litter_probability(0.0), 1.0);
        assert_eq!(
            tree_leaf_litter_probability(TREE_DENSE_LEAF_LITTER_RADIUS_METRES),
            1.0
        );
        let inner = tree_leaf_litter_probability(3.0);
        let middle = tree_leaf_litter_probability(4.0);
        let edge = tree_leaf_litter_probability(TREE_CANOPY_GROUND_RADIUS_METRES);
        assert!(1.0 > inner && inner > middle && middle > edge);
        assert_eq!(edge, 0.12);
    }

    #[test]
    fn obstacle_kind_has_a_stable_wire_round_trip() {
        let recipe = rock_recipe(42.into());
        for obstacle in [SceneObstacle::Tree, SceneObstacle::Rock(recipe)] {
            let bytes = postcard::to_allocvec(&obstacle).unwrap();
            assert_eq!(
                postcard::from_bytes::<SceneObstacle>(&bytes).unwrap(),
                obstacle
            );
        }
    }

    #[test]
    fn generated_rock_recipes_are_deterministic_and_fit_the_collision_proxy() {
        for seed in [0, 1, 42, u64::MAX].map(fabelgeist_determinism::Seed::from_u64) {
            let recipe = rock_recipe(seed);
            assert_eq!(recipe, rock_recipe(seed));
            assert_eq!(recipe.seed, seed);
            assert!(
                recipe
                    .dimensions_cm
                    .iter()
                    .all(|dimension| *dimension <= recipe.collision_radius_cm * 2)
            );
            assert_eq!(recipe.collision_radius_metres(), ROCK_RADIUS_METRES);
        }
    }

    #[test]
    fn invalid_fixture_is_repaired_deterministically_into_a_connected_battlefield() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../assets/tactical-scenes");
        let input =
            TacticalSceneInput::load(&root.join("playability-repair-required.json")).unwrap();
        let first = input.generate().unwrap();
        let second = input.generate().unwrap();
        assert_eq!(first.repairs, second.repairs);
        assert!(first.repairs.adjusted_height_samples > 0);
        assert!(first.repairs.repaired_water_samples > 0);

        let width = usize::from(input.playable.width);
        let depth = usize::from(input.playable.depth);
        let spacing = input.playable.spacing_metres;
        let world_width = (width - 1) as f32 * spacing;
        let world_depth = (depth - 1) as f32 * spacing;
        let height = |x: usize, z: usize| {
            first
                .terrain
                .height_at(
                    ScenePlanPoint::from_metres(bevy::math::Vec2::new(
                        x as f32 * spacing - world_width * 0.5,
                        z as f32 * spacing - world_depth * 0.5,
                    ))
                    .unwrap(),
                )
                .unwrap()
        };
        for z in 0..depth {
            for x in 0..width {
                if x + 1 < width {
                    assert!(
                        (height(x, z).metres() - height(x + 1, z).metres()).abs()
                            <= spacing * crate::scene::TerrainGradeLimit::PLAYABLE.ratio() + 0.001
                    );
                }
                if z + 1 < depth {
                    assert!(
                        (height(x, z).metres() - height(x, z + 1).metres()).abs()
                            <= spacing * crate::scene::TerrainGradeLimit::PLAYABLE.ratio() + 0.001
                    );
                }
            }
        }
        assert!(first.obstacles.iter().all(|obstacle| match *obstacle {
            GeneratedObstacle::Tree { x, z } => {
                !is_tree_camera_clearance_cell(usize::from(x), usize::from(z), depth)
            }
            GeneratedObstacle::Rock { x, z, .. } => {
                !is_reserved_playability_cell(usize::from(x), usize::from(z), width, depth)
            }
        }));
    }

    #[test]
    fn reserved_playability_corridor_covers_the_spawn_camera_envelope() {
        let width = 9;
        let depth = 9;
        for x in 0..width {
            for z in 3..=5 {
                assert!(is_tree_camera_clearance_cell(x, z, depth));
            }
            assert!(!is_tree_camera_clearance_cell(x, 2, depth));
            assert!(!is_tree_camera_clearance_cell(x, 6, depth));
        }
        assert!(!is_reserved_playability_cell(0, 3, width, depth));
        assert!(is_reserved_playability_cell(2, 3, width, depth));
    }
}
