//! Bounded implicit terrain patches and deterministic marching tetrahedra.
//!
//! The server selects a compact, immutable landform recipe. Server collision
//! and client presentation extract the same field after heightfield repair;
//! no terrain simulation or mesh persistence runs during tactical ticks.
//! The heightfield remains authoritative outside the transition collar.

use bevy::{
    math::{FloatExt, Vec2, Vec3, Vec3Swizzles},
    prelude::Component,
};
pub use error::{TerrainRecipeError, TerrainRecipeResult};
use fabelgeist_determinism::StreamId;
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

use crate::marching_tetrahedra::marching_height_surface;
use crate::{
    city_layout::grounding::SupportElevation,
    scene::{SceneElevationRange, SceneTerrain},
    scene_coordinates::ScenePlanPoint,
    terrain_transition::TerrainTransitionCollar,
};
use resistance::{ScarpResistance, ScarpResistanceGrid};
use support::height_at_extended_edge;

pub use recipe::{
    QuantizedLandformRecipe, TerrainLandformKind, TerrainLandformLod, TerrainLandformRecipe,
};
pub use surface_recipe::{
    TerrainGeologicStructure, TerrainSurfaceParameters, TerrainSurfacePreset, TerrainSurfaceRecipe,
    TerrainSurfaceSource,
};

pub use patch::{SceneTerrainPatch, TerrainMeshBuffers};

mod error;
mod patch;
mod recipe;
mod resistance;
pub(crate) mod support;
mod surface_recipe;

const SCARP_EROSION_STEPS: usize = 224;
const SCARP_COLLUVIAL_GRADE: f32 = 0.46;
const SCARP_RESISTANT_FACE_GRADE_RANGE: f32 = 2.6;
const SCARP_MAXIMUM_TRANSFER_FRACTION: f32 = 0.20;
const SCARP_RUPTURE_WANDER_METRES: f32 = 1.25;
const SCARP_WIDTH_VARIATION_BPS: u16 = 1_200;

struct SimulatedScarpSurface {
    minimum: ScenePlanPoint,
    spacing: f32,
    side: usize,
    offsets: Vec<f32>,
}

impl SceneTerrainPatch {
    pub fn collider(&self) -> avian3d::prelude::Collider {
        avian3d::prelude::Collider::trimesh(
            self.positions
                .iter()
                .copied()
                .map(Vec3::from_array)
                .collect(),
            self.indices
                .as_chunks::<3>()
                .0
                .iter()
                .map(|triangle| [triangle[0], triangle[1], triangle[2]])
                .collect(),
        )
    }

    pub fn colliders_with_terrain(
        &self,
        terrain: &SceneTerrain,
    ) -> Result<Vec<avian3d::prelude::Collider>, crate::city_layout::grounding::SupportColliderError>
    {
        let (mut positions, mut triangles) =
            terrain.natural_collision_mesh_with_transition(self.transition_collar);
        let total = positions
            .len()
            .checked_add(self.positions.len())
            .ok_or(crate::city_layout::grounding::SupportGeometryIssue::Topology)?;
        u32::try_from(total)
            .map_err(|_| crate::city_layout::grounding::SupportGeometryIssue::Topology)?;
        let patch_offset = positions.len() as u32;
        positions.extend(self.positions.iter().copied().map(Vec3::from_array));
        triangles.extend(self.indices.as_chunks::<3>().0.iter().map(|triangle| {
            [
                triangle[0] + patch_offset,
                triangle[1] + patch_offset,
                triangle[2] + patch_offset,
            ]
        }));
        let mut colliders = terrain.foundation_colliders()?;
        colliders.push(avian3d::prelude::Collider::trimesh(positions, triangles));
        Ok(colliders)
    }

    pub fn triangle_count(&self) -> usize {
        self.indices.len() / 3
    }
}

impl SimulatedScarpSurface {
    fn offset_at(&self, point: ScenePlanPoint) -> f32 {
        let grid = (point.metres() - self.minimum.metres()) / self.spacing;
        let x0 = (grid.x.floor() as usize).min(self.side - 2);
        let z0 = (grid.y.floor() as usize).min(self.side - 2);
        let fraction = (grid - Vec2::new(x0 as f32, z0 as f32)).clamp(Vec2::ZERO, Vec2::ONE);
        let a = self.offsets[z0 * self.side + x0];
        let b = self.offsets[z0 * self.side + x0 + 1];
        let c = self.offsets[(z0 + 1) * self.side + x0];
        let d = self.offsets[(z0 + 1) * self.side + x0 + 1];
        a.lerp(b, fraction.x)
            .lerp(c.lerp(d, fraction.x), fraction.y)
    }

    fn height_range(&self, terrain: &SceneTerrain) -> TerrainRecipeResult<SceneElevationRange> {
        if self.offsets.is_empty() {
            return Err(TerrainRecipeError::EmptySurface);
        }
        let (minimum, maximum) = self
            .offsets
            .par_iter()
            .enumerate()
            .map(|(index, offset)| -> TerrainRecipeResult<(f32, f32)> {
                let x = index % self.side;
                let z = index / self.side;
                let point = ScenePlanPoint::from_metres(
                    self.minimum.metres() + Vec2::new(x as f32, z as f32) * self.spacing,
                )
                .ok_or(TerrainRecipeError::NonFiniteField)?;
                let height = height_at_extended_edge(terrain, point)?.metres() + offset;
                if !height.is_finite() {
                    return Err(TerrainRecipeError::NonFiniteField);
                }
                Ok((height, height))
            })
            .try_reduce(
                || (f32::INFINITY, f32::NEG_INFINITY),
                |(left_minimum, left_maximum), (right_minimum, right_maximum)| {
                    Ok((
                        left_minimum.min(right_minimum),
                        left_maximum.max(right_maximum),
                    ))
                },
            )?;
        SceneElevationRange::new(
            SupportElevation::from_metres(minimum).ok_or(TerrainRecipeError::NonFiniteField)?,
            SupportElevation::from_metres(maximum).ok_or(TerrainRecipeError::NonFiniteField)?,
        )
        .ok_or(TerrainRecipeError::NonFiniteField)
    }
}

pub fn terrain_landform_patch(
    terrain: &SceneTerrain,
    recipe: TerrainLandformRecipe,
) -> TerrainRecipeResult<SceneTerrainPatch> {
    recipe.validate(terrain)?;
    if recipe.kind != TerrainLandformKind::FaultScarp {
        return crate::erosional_terrain::patch(terrain, recipe);
    }
    let spacing = f32::from(recipe.lod.voxel_cm()) / 100.0;
    let origin = Vec2::new(recipe.origin_cm[0] as f32, recipe.origin_cm[1] as f32) / 100.0;
    let radius = f32::from(recipe.half_length_cm.max(recipe.half_width_cm)) / 100.0
        + SCARP_RUPTURE_WANDER_METRES;
    // March one sample beyond the transition's outer edge. An isosurface that
    // lands exactly on the final voxel plane has no neighbouring cell from
    // which marching tetrahedra can emit its last triangles, which otherwise
    // leaves a thin rectangular opening at the fault tips.
    let radius = (radius / spacing).ceil() * spacing + spacing;
    let side = ((radius * 2.0 / spacing).round() as usize).saturating_add(1);
    let throw = f32::from(recipe.relief_cm) / 100.0;
    let minimum = ScenePlanPoint::from_metres(origin - Vec2::splat(radius))
        .ok_or(TerrainRecipeError::NonFiniteField)?;
    let surface = simulate_fault_scarp(terrain, recipe, side, spacing, minimum)?;
    let range = surface.height_range(terrain)?;
    // Offset the vertical lattice so a flat heightfield cannot coincide with
    // an entire voxel plane. Coincident zero-valued edges collapse otherwise
    // valid tetrahedra at the zero-displacement collar contour.
    let bottom = ((range.minimum().metres() - throw - spacing * 2.0) / spacing).floor() * spacing
        - spacing * 0.5;
    let required_top = range.maximum().metres() + throw + spacing * 2.0;
    let vertical = ((required_top - bottom) / spacing).ceil() as usize + 1;
    if side > 195 || vertical > 96 {
        return Err(TerrainRecipeError::VoxelGridBound);
    }
    let dimensions = [side, vertical, side];
    let sample_position = |index: [usize; 3]| {
        Vec3::new(
            origin.x + index[0] as f32 * spacing - radius,
            bottom + index[1] as f32 * spacing,
            origin.y + index[2] as f32 * spacing - radius,
        )
    };
    // A fault is a displaced height surface. Every vertical sample in a
    // column shares the exact same terrain lookup and displacement. Reuse the
    // producer's coordinate expression so ownership-edge rounding is unchanged.
    let surface_heights = (0..side * side)
        .into_par_iter()
        .map(|index| -> TerrainRecipeResult<f32> {
            let point =
                ScenePlanPoint::from_metres(sample_position([index % side, 0, index / side]).xz())
                    .ok_or(TerrainRecipeError::NonFiniteField)?;
            Ok(height_at_extended_edge(terrain, point)?.metres() + surface.offset_at(point))
        })
        .collect::<TerrainRecipeResult<Vec<_>>>()?;
    marching_height_surface(
        dimensions,
        sample_position,
        &surface_heights,
        recipe.transition_collar(),
    )
}

fn simulate_fault_scarp(
    terrain: &SceneTerrain,
    recipe: TerrainLandformRecipe,
    side: usize,
    spacing: f32,
    minimum: ScenePlanPoint,
) -> TerrainRecipeResult<SimulatedScarpSurface> {
    let collar = recipe.transition_collar();
    let throw = f32::from(recipe.relief_cm) / 100.0;
    // Keep both displaced blocks clear of the original heightfield.  A zero
    // offset on either side makes the replacement isosurface coincide with
    // the removed heightfield and can leave an unmeshed ownership hole.  The
    // unequal split leaves most relief on the footwall while retaining a
    // lower source surface from which the erosion pass can build its apron.
    let footwall_uplift = throw * 0.875;
    let hanging_wall_drop = -throw * 0.125;
    let mut offsets = vec![0.0; side * side];
    let mut masks = vec![0.0; side * side];
    let mut base_heights = vec![0.0; side * side];
    offsets
        .par_iter_mut()
        .zip(masks.par_iter_mut())
        .zip(base_heights.par_iter_mut())
        .enumerate()
        .try_for_each(
            |(index, ((offset, mask), base_height))| -> TerrainRecipeResult<()> {
                let x = index % side;
                let z = index / side;
                let point = ScenePlanPoint::from_metres(
                    minimum.metres() + Vec2::new(x as f32, z as f32) * spacing,
                )
                .ok_or(TerrainRecipeError::NonFiniteField)?;
                let local = collar.local_coordinates(point.metres());
                let along = local.x;
                let across = local.y;
                *mask = collar.blend_weight(point.metres());
                let throw_variation = 0.84
                    + (smooth_value_noise(
                        StreamId::new("terrain.volume.throw").seed(recipe.seed, &[]),
                        along / 3.6,
                    ) * 0.5
                        + 0.5)
                        * 0.16;
                *offset = if across >= 0.0 {
                    hanging_wall_drop
                } else {
                    footwall_uplift
                } * *mask
                    * throw_variation;
                *base_height = height_at_extended_edge(terrain, point)?.metres();
                Ok(())
            },
        )?;

    erode_surface(
        &mut offsets,
        &masks,
        &base_heights,
        recipe,
        collar,
        side,
        spacing,
        minimum,
    );

    Ok(SimulatedScarpSurface {
        minimum,
        spacing,
        side,
        offsets,
    })
}

#[expect(
    clippy::too_many_arguments,
    reason = "the erosion grid inputs are independent"
)]
fn erode_surface(
    offsets: &mut [f32],
    masks: &[f32],
    base_heights: &[f32],
    recipe: TerrainLandformRecipe,
    collar: TerrainTransitionCollar,
    side: usize,
    spacing: f32,
    minimum: ScenePlanPoint,
) {
    let resistances = ScarpResistanceGrid::new(masks, recipe, collar, side, spacing, minimum);
    let mut horizontal_transfers = vec![0.0; offsets.len()];
    let mut vertical_transfers = vec![0.0; offsets.len()];
    for _ in 0..SCARP_EROSION_STEPS {
        horizontal_transfers
            .par_iter_mut()
            .zip(vertical_transfers.par_iter_mut())
            .enumerate()
            .for_each(|(source, (horizontal, vertical))| {
                let x = source % side;
                let z = source / side;
                let cell = resistances.cell(source);
                let transfer_to = |nx: usize, nz: usize, resistance: Option<ScarpResistance>| {
                    let Some(resistance) = resistance else {
                        return 0.0;
                    };
                    let target = nz * side + nx;
                    let difference = (base_heights[source] + offsets[source])
                        - (base_heights[target] + offsets[target]);
                    let resistance = resistance.coefficient();
                    let threshold = spacing
                        * (SCARP_COLLUVIAL_GRADE + resistance * SCARP_RESISTANT_FACE_GRADE_RANGE);
                    let excess = difference.abs() - threshold;
                    if excess <= 0.0 {
                        return 0.0;
                    }
                    let transfer =
                        excess * SCARP_MAXIMUM_TRANSFER_FRACTION * (1.0 - resistance * 0.55);
                    transfer * difference.signum()
                };
                *horizontal = transfer_to(x + 1, z, cell.x_neighbor);
                *vertical = transfer_to(x, z + 1, cell.z_neighbor);
            });
        offsets
            .par_iter_mut()
            .enumerate()
            .for_each(|(index, offset)| {
                if masks[index] <= 0.0 {
                    *offset = 0.0;
                    return;
                }
                let x = index % side;
                let z = index / side;
                let mut transfer = 0.0;
                if z > 0 {
                    transfer += vertical_transfers[index - side];
                }
                if x > 0 {
                    transfer += horizontal_transfers[index - 1];
                }
                transfer -= horizontal_transfers[index];
                transfer -= vertical_transfers[index];
                *offset += transfer;
            });
    }
}

fn smooth_value_noise(seed: fabelgeist_determinism::Seed, coordinate: f32) -> f32 {
    let cell = coordinate.floor() as i64;
    let fraction = smoothstep01(coordinate - coordinate.floor());
    let sample = |offset: i64| {
        StreamId::new("terrain.volume.lattice")
            .rng(seed, &[cell.wrapping_add(offset) as u64])
            .inclusive_unit_f32()
            * 2.0
            - 1.0
    };
    sample(0).lerp(sample(1), fraction)
}

fn smoothstep01(value: f32) -> f32 {
    let value = value.clamp(0.0, 1.0);
    value * value * (3.0 - 2.0 * value)
}

#[cfg(test)]
mod tests {
    use super::*;
    use adventuresim_world_schema::{SedimentaryRock, SurfaceLithology};
    use std::collections::HashMap;

    fn test_surface(seed: fabelgeist_determinism::Seed) -> TerrainSurfaceRecipe {
        TerrainSurfaceRecipe::new(
            SurfaceLithology::Sedimentary(SedimentaryRock::Sandstone),
            TerrainSurfaceSource::AuthoredFixture,
            seed,
            [10_000, 0],
        )
        .unwrap()
    }

    #[test]
    fn fault_scarp_is_deterministic_and_has_a_vertical_face() {
        let terrain = SceneTerrain::new(40, 40, 1.0, |_| 0.0).unwrap();
        let recipe = TerrainLandformRecipe::from_quantized(
            crate::volumetric_terrain::QuantizedLandformRecipe {
                kind: TerrainLandformKind::FaultScarp,
                surface: test_surface(17.into()),
                seed: 17.into(),
                origin_cm: [0, 0],
                tangent_permyriad: [10_000, 0],
                relief_cm: 600,
                half_length_cm: 1_000,
                half_width_cm: 800,
                collar_cm: 200,
                lod: TerrainLandformLod::Detail,
            },
        )
        .unwrap();
        let generate_with_threads = |threads| {
            rayon::ThreadPoolBuilder::new()
                .num_threads(threads)
                .build()
                .unwrap()
                .install(|| terrain_landform_patch(&terrain, recipe).unwrap())
        };
        let first = generate_with_threads(1);
        let second = generate_with_threads(4);
        assert_eq!(first, second);
        assert!(first.triangle_count() > 100);
        assert!(first.normals.iter().any(|normal| normal[1].abs() < 0.25));
        assert!(
            first
                .positions
                .iter()
                .any(|position| position[0].abs() > 10.0),
            "the extracted surface must extend beyond the transition edge"
        );
        let rupture_depths = first
            .positions
            .iter()
            .zip(&first.normals)
            .filter(|(position, normal)| {
                position[0].abs() < 7.0 && normal[1].abs() < 0.55 && normal[2].abs() > 0.5
            })
            .map(|(position, _)| position[2])
            .collect::<Vec<_>>();
        let rupture_minimum = rupture_depths.iter().copied().fold(f32::INFINITY, f32::min);
        let rupture_maximum = rupture_depths
            .iter()
            .copied()
            .fold(f32::NEG_INFINITY, f32::max);
        assert!(rupture_maximum - rupture_minimum > 0.5);
        let mut edges = HashMap::<(u32, u32), usize>::new();
        for triangle in first.indices.as_chunks::<3>().0 {
            for edge in [
                (triangle[0], triangle[1]),
                (triangle[1], triangle[2]),
                (triangle[2], triangle[0]),
            ] {
                let key = if edge.0 < edge.1 {
                    edge
                } else {
                    (edge.1, edge.0)
                };
                *edges.entry(key).or_default() += 1;
            }
        }
        assert!(edges.values().all(|&uses| uses <= 2));
    }

    #[test]
    fn fringe_lod_keeps_the_full_feature_across_the_playable_edge() {
        let terrain = SceneTerrain::new(100, 100, 1.0, |_| 0.0).unwrap();
        let recipe = TerrainLandformRecipe::from_quantized(
            crate::volumetric_terrain::QuantizedLandformRecipe {
                kind: TerrainLandformKind::FaultScarp,
                surface: test_surface(29.into()),
                seed: 29.into(),
                origin_cm: [0, 6_000],
                tangent_permyriad: [10_000, 0],
                relief_cm: 800,
                half_length_cm: 4_500,
                half_width_cm: 1_800,
                collar_cm: 400,
                lod: TerrainLandformLod::Fringe,
            },
        )
        .unwrap();

        let patch = terrain_landform_patch(&terrain, recipe).unwrap();

        assert!(patch.positions.iter().any(|position| position[2] <= 50.0));
        assert!(patch.positions.iter().any(|position| position[2] > 50.0));
        assert_eq!(patch.transition_collar, recipe.transition_collar());
    }

    #[test]
    fn collar_matches_the_heightfield_exactly() {
        let terrain = SceneTerrain::new(40, 40, 1.0, |point| point.x * 0.02).unwrap();
        let recipe = TerrainLandformRecipe::from_quantized(
            crate::volumetric_terrain::QuantizedLandformRecipe {
                kind: TerrainLandformKind::FaultScarp,
                surface: test_surface(17.into()),
                seed: 17.into(),
                origin_cm: [0, 0],
                tangent_permyriad: [10_000, 0],
                relief_cm: 600,
                half_length_cm: 1_000,
                half_width_cm: 800,
                collar_cm: 200,
                lod: TerrainLandformLod::Detail,
            },
        )
        .unwrap();
        let spacing = f32::from(recipe.lod.voxel_cm()) / 100.0;
        let radius = f32::from(recipe.half_length_cm.max(recipe.half_width_cm)) / 100.0;
        let side = (radius * 2.0 / spacing).round() as usize + 1;
        let minimum = ScenePlanPoint::from_metres(Vec2::splat(-radius)).unwrap();
        let surface = simulate_fault_scarp(&terrain, recipe, side, spacing, minimum).unwrap();
        assert_eq!(
            surface.offset_at(ScenePlanPoint::from_metres(Vec2::new(0.0, 8.0)).unwrap()),
            0.0
        );
        assert_eq!(
            surface.offset_at(ScenePlanPoint::from_metres(Vec2::new(10.0, 0.0)).unwrap()),
            0.0
        );
    }
}
