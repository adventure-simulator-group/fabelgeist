//! Core adventuresim bevy-centric library that is used both by
//! tactical client and tactical server.
//!
//! It defines how the tactical world works in minimal environemnt,
//! which can be extended by networking and visuals in other crates.

pub mod animation;
pub mod city_layout;
pub mod combat;
pub mod combat_config;
pub mod doors;
mod erosional_terrain;
pub mod geometry_transport;
pub mod inventory;
mod inventory_armor;
mod marching_tetrahedra;
pub mod physics;
pub mod player;
pub mod regional_city;
pub mod regional_environment;
pub mod regional_map;
pub mod regional_terrain;
pub mod scene;
pub mod scene_coordinates;
mod scene_fault;
mod scene_ground;
pub mod scene_input;
mod scene_transition_mesh;
pub mod terrain_streams;
mod terrain_transition;
pub mod volumetric_terrain;

pub use avian3d;

pub mod prelude {
    pub use crate::AdventureSimulatorCorePlugins;
    pub use crate::animation::{
        ActionState, ActionTransitionError, AnimationElapsed, AnimationEvaluation, AnimationPack,
        AnimationPackLibrary, AnimationSampleRate, AnimationSampleSpan, AnimationSampleTick,
        AttackAnimation, AttackAnimations, AttackCurve, AttackHand, AttackLine, AttackPreparation,
        AttackSpec, BlendWeight, BlockSpec, BodyFacingTurn, BodyState, ClipMirror, ContactSequence,
        CycleDelta, CyclePhase, DIVE_GROUND_CONTACT_PHASE, DiveDirection, DiveTrajectory,
        DodgeSpec, DownedFacingAim, DownedFacingPose, DownedFacingStep, DownedMotion,
        DownedRollMotion, GroundContact, GroundedPosture, GuardContacts, GuardFootworkPlan,
        GuardStepPlan, GuardedLocomotionMode, HeightDistance, HeightSpeed, JumpAnticipation,
        LandingImpactSpeed, LandingProfile, LeadFoot, LocomotionGait, LocomotionProfile,
        MeleePreparationInput, PackValidationError, PoseSample, PoseSampling, Posture,
        PostureTransitionKind, PostureTransitionState, RaisedLocomotionIntent, ResolvedPose,
        RollDirection, SemanticPose, SignedHalfTurns, SkeletonAction, SkeletonFamily,
        SkeletonLocomotionInput, SkeletonState, StanceState, StrikeFamily, WeaponGuardState,
        advance_body_facing, advance_body_facing_with_turn, advance_downed_body_facing,
        advance_downed_body_facing_with_speed, body_facing_turn, controller_yaw,
        dive_landing_facing_delta, downed_camera_roll_target, downed_turn_speed_radians,
        gait_cycle_phase_delta, gait_support_weights, guard_closed_foot_separation,
        guard_contact_margin_metres, guard_contact_travel_distance, guard_maximum_foot_separation,
        guard_maximum_lateral_foot_separation, guard_maximum_unsupported_contact_duration,
        guard_movement_front_foot, guard_open_foot_separation, guard_rear_contact_separation,
        guard_step_length, locomotion_profile, locomotion_sample_rate, ordinary_step_distance,
        project_skeleton_locomotion, project_skeleton_locomotion_with_body_rotation,
        project_skeleton_locomotion_with_intent, raised_guard_locomotion_profile,
        run_locomotion_profile, set_weapon_guard, supine_get_up_counter_yaw_delta,
        walk_locomotion_profile,
    };
    pub use crate::city_layout::{
        CityBoundary, CityBoundaryMaterial, CityBoundaryMember, CityBuildingLot, CityCompound,
        CityGarden, CityHouseClass, CityPlotBounds, CityPropertyId, CitySite, CityStreetPatch,
        CityStreetSurface, CityYardPatch, CityYardSurface, GeneratedCityLayout, MAX_CITY_LOTS,
        MAX_CITY_STREET_PATCHES, MAX_CITY_YARD_PATCHES,
    };
    pub use crate::combat::{
        Attack, Dodge, ForwardLungeAcceleration, MeleeAttackKey, MeleeContactTiming, MeleeLunge,
        MeleeLungeArrival, conservative_forward_lunge_acceleration, maximum_melee_lunge_range,
        melee_interaction_range, melee_lunge, melee_lunge_arrival,
        melee_lunge_quickstep_threshold_metres, melee_lunge_range_window_metres,
    };
    pub use crate::combat_config::*;
    pub use crate::doors::{
        DOOR_GRAB_DEPTH_METRES, DOOR_GRAB_LATERAL_MARGIN_METRES, DoorPassageExemptions,
        TACTICAL_DOOR_LAYER, TACTICAL_WINDOW_LAYER, can_grab_door_from_inside,
        can_grab_window_from_inside,
    };
    pub use crate::inventory::{
        ArmorItem, ArmorSide, ArmorSlot, EquipSlot, EquipmentActionState, EquipmentRevision,
        EquipmentSequence, EquipmentTopology, EquipmentTopologyOccupancy, InventoryItems, ItemOf,
        ItemProperties, ShieldItem, TACTICAL_ITEM_LAYER, TACTICAL_TERRAIN_LAYER,
        TacticalEquipmentAnchor, TacticalEquipmentPhysical, TacticalInventoryItemId,
        TacticalItemQuantity, TacticalSceneItem, WeaponAppearance, WeaponHolderAppearance,
        WeaponItem, rebuild_inventory_holding_cache,
    };
    pub use crate::physics::{
        AdventureSimulatorPhysicsSet, BREATH_PER_METRE_PER_SECOND, CharacterMotionSnapshot,
        MeleeLungeMovement, MovementPace, QuickstepPush, TACTICAL_BREATH_RESPONSE_SCALE,
        TACTICAL_GUARD_SPEED_METRES_PER_SECOND, TACTICAL_PRONE_LATERAL_SPEED_SCALE,
        TACTICAL_PRONE_SPEED_METRES_PER_SECOND, TACTICAL_PRONE_WALK_SPEED_METRES_PER_SECOND,
        TACTICAL_ROLL_SPEED_METRES_PER_SECOND, TACTICAL_RUN_SPEED_METRES_PER_SECOND,
        TACTICAL_WALK_SPEED_METRES_PER_SECOND, quickstep_action_contact_ticks,
        quickstep_force_curve, quickstep_peak_horizontal_force_newtons, quickstep_push_duration,
        quickstep_target_displacement_metres, tactical_breath_recovery_per_second,
        tactical_character_controller, tactical_exhaustion_change_per_second, tactical_jog_speed,
        tactical_movement_exhaustion_change_per_second, tactical_movement_speed,
        tactical_movement_speed_for_guard, tactical_movement_speed_for_pace, tactical_sprint_speed,
    };
    pub use crate::player::{
        BestiaryCategories, CharacterDimensions, CharacterId, ControlledPlayer, Limbs, Player,
        PlayerInputTick, Skills, Stats, TacticalAttributes, TacticalCombatSide,
        TacticalCombatState, TacticalIncapacitationSources, TacticalPlayerView,
        TacticalPlayerViewer, attack_preparation_secs, attack_recovery_secs,
        configure_attack_curve, default_tactical_character_id, effective_weapon_handling_skill,
    };
    pub use crate::scene::{
        GroundCover, GroundSubstrate, GroundSurface, SceneElevationRange, SceneGround, SceneId,
        SceneTerrain, TerrainGenerator, UrbanGroundLookup,
    };
    pub use crate::scene_input::furniture::{
        FurnitureAnchor, FurnitureFootprint, FurnitureGroup, FurnitureGroupId, FurnitureGroupKind,
        FurnitureInstanceId, FurnitureLayout, FurnitureLocation, GeneratedFurniture,
        SceneFurniture, SceneFurnitureGroup, SceneVistaFurniture, furniture_collider,
    };
    pub use crate::scene_input::{
        BuildingOrientation, DistantBuildingPlacement, EnvironmentalSample, GardenPlantSupport,
        GeneratedBoundary, GeneratedBuilding, GeneratedObstacle, GeneratedTacticalScene,
        ROCK_RADIUS_METRES, RockArchetype, RockLithology, RockRecipe, SceneBoundary, SceneBuilding,
        SceneDoor, SceneEnvironment, SceneEnvironmentFixture, SceneEstablishment, SceneGarden,
        SceneInputError, SceneObstacle, SceneRepairReport, SceneSource, SceneWindow,
        TACTICAL_SCENE_GENERATION_VERSION, TACTICAL_SCENE_SCHEMA_VERSION,
        TREE_CANOPY_GROUND_RADIUS_METRES, TREE_TRUNK_HEIGHT_METRES, TREE_TRUNK_RADIUS_METRES,
        TacticalBuildingPlacement, TacticalSceneInput, TacticalSurface, TerrainSampleGrid,
        VistaLod, VistaSample,
    };
    pub use crate::terrain_transition::{
        CollarWidthVariation, RuptureWander, TerrainCollarParameters, TerrainTransitionCollar,
    };
    pub use crate::volumetric_terrain::{
        SceneTerrainPatch, TerrainGeologicStructure, TerrainLandformKind, TerrainLandformLod,
        TerrainLandformRecipe, TerrainSurfaceParameters, TerrainSurfacePreset,
        TerrainSurfaceRecipe, TerrainSurfaceSource, terrain_landform_patch,
    };
    pub use adventuresim_core::item_catalog;
    pub use adventuresim_core::item_catalog::{EquipmentChannel, EquipmentLocation};
    pub use adventuresim_core::linear_speed::{NonnegativeSpeed, PositiveSpeed, SignedSpeed};
    pub use adventuresim_core::prelude::*;
    pub use avian3d::prelude::*;
    pub use bevy_ahoy::{
        AhoySystems, CharacterController, CharacterControllerState, CharacterLook,
        camera::{CharacterControllerCamera, CharacterControllerCameraOf},
        input,
    };
    pub use bevy_enhanced_input::{self, prelude::*};
}

bevy::app::plugin_group! {
    #[derive(Debug)]
    pub struct AdventureSimulatorCorePlugins {
        physics:::AdventureSimulatorPhysicsPlugin,
    }
}

/// Canonical vista vertex heights and clipped cell topology.
pub mod vista_surface;
