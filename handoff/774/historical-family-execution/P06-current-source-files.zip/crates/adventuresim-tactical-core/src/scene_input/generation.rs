use super::*;
use bevy::math::Vec2;
use fabelgeist_determinism::StreamId;
mod geographic;
mod grounding;
mod support_obstacles;
mod supported;
pub use geographic::UngradedSceneTerrain;
pub use supported::SupportedSceneTerrain;

impl TacticalSceneInput {
    pub fn generate(&self) -> Result<GeneratedTacticalScene, SceneInputError> {
        let mut generated = self.generate_unfurnished(GeneratedBuildingRecipes::default())?;
        generated
            .furniture
            .furnish_interiors(&generated.buildings)?;
        Ok(generated)
    }

    /// Generate terrain and outdoor assets before independent interior jobs.
    pub fn generate_unfurnished(
        &self,
        mut building_recipes: GeneratedBuildingRecipes,
    ) -> Result<GeneratedTacticalScene, SceneInputError> {
        let SupportedSceneTerrain {
            terrain,
            ground,
            buildings,
            obstacles,
            repairs,
        } = self.prepare_supported_terrain(&mut building_recipes)?;
        let terrain_patch = crate::scene_fault::generate(self.landform, &terrain)?;
        let furniture = furniture::generate(
            self,
            &buildings,
            &terrain,
            &ground,
            &obstacles,
            &mut building_recipes,
        )?;
        let gardens = gardens::generate(&self.gardens, &buildings, &terrain)?;
        let boundaries = compounds::generate(&self.compounds, &buildings, &terrain)?;
        Ok(GeneratedTacticalScene {
            digest: self.digest()?,
            terrain,
            ground,
            obstacles,
            terrain_patch,
            boundaries,
            gardens,
            buildings,
            building_recipes,
            furniture,
            repairs,
        })
    }
}

fn prepare_terrain(
    input: &TacticalSceneInput,
    width: usize,
    depth: usize,
    spacing: f32,
    heights: &mut [f32],
    environment: &mut [EnvironmentalSample],
) -> Result<SceneRepairReport, SceneInputError> {
    let upsampled_height_samples = heights
        .len()
        .saturating_sub(input.playable.heights_metres.len())
        as u32;
    let microrelief_adjusted_samples =
        add_authoritative_microrelief(input.seed, width, depth, spacing, heights, environment);
    let mut repairs = repair_playable_terrain(width, depth, spacing, heights, environment)?;
    repairs.upsampled_height_samples = upsampled_height_samples;
    repairs.microrelief_adjusted_samples = microrelief_adjusted_samples;
    Ok(repairs)
}

fn generated_obstacles(input: &TacticalSceneInput) -> Vec<GeneratedObstacle> {
    input
        .playable
        .environment
        .iter()
        .enumerate()
        .filter_map(|(index, sample)| {
            let x = (index % usize::from(input.playable.width)) as u16;
            let z = (index / usize::from(input.playable.width)) as u16;
            let point = (Vec2::new(f32::from(x), f32::from(z))
                - Vec2::new(
                    f32::from(input.playable.width - 1),
                    f32::from(input.playable.depth - 1),
                ) * 0.5)
                * input.playable.spacing_metres;
            if input.landform.is_some_and(|recipe| {
                crate::scene_coordinates::ScenePlanPoint::try_from(point)
                    .is_ok_and(|point| recipe.transition_collar().contains(point))
            }) {
                return None;
            }
            let context = [u64::from(x), u64::from(z)];
            let tree_roll = StreamId::new("scene.tree-placement")
                .rng(input.seed, &context)
                .index(usize::from(BASIS_POINTS_PER_WHOLE)) as u64;
            let rock_seed = StreamId::new("scene.rock-placement").seed(input.seed, &context);
            let rock_roll = StreamId::new("scene.rock-presence")
                .rng(rock_seed, &[])
                .index(usize::from(BASIS_POINTS_PER_WHOLE)) as u64;
            if tree_roll < u64::from(sample.canopy_bps) / 12 {
                Some(GeneratedObstacle::Tree { x, z })
            } else if rock_roll < u64::from(sample.hilly_bps) / 20 && sample.water_bps < 5_000 {
                Some(GeneratedObstacle::Rock {
                    x,
                    z,
                    recipe: rock_recipe(rock_seed),
                })
            } else {
                None
            }
        })
        .collect()
}

fn remove_reserved_obstacles(
    input: &TacticalSceneInput,
    obstacles: &mut Vec<GeneratedObstacle>,
    repairs: &mut SceneRepairReport,
) {
    let before = obstacles.len();
    obstacles.retain(|obstacle| {
        let width = usize::from(input.playable.width);
        let depth = usize::from(input.playable.depth);
        match *obstacle {
            GeneratedObstacle::Tree { x, z } => {
                !is_tree_camera_clearance_cell(usize::from(x), usize::from(z), depth)
            }
            GeneratedObstacle::Rock { x, z, .. } => {
                !is_reserved_playability_cell(usize::from(x), usize::from(z), width, depth)
            }
        }
    });
    repairs.removed_corridor_obstacles = (before - obstacles.len()) as u32;
}

fn remove_building_obstacles(
    input: &TacticalSceneInput,
    terrain: &SceneTerrain,
    reservations: &[buildings::ObstacleReservation],
    obstacles: &mut Vec<GeneratedObstacle>,
    repairs: &mut SceneRepairReport,
) -> SceneInputResult<()> {
    let before = obstacles.len();
    let terrain_extent = bevy::math::Vec2::new(terrain.width(), terrain.depth());
    let mut retained = Vec::with_capacity(obstacles.len());
    for obstacle in obstacles.iter().copied() {
        if !buildings::obstacle_intersects_building(
            obstacle,
            input.playable.spacing_metres,
            terrain_extent,
            reservations,
        )? {
            retained.push(obstacle);
        }
    }
    *obstacles = retained;
    repairs.removed_building_obstacles = (before - obstacles.len()) as u32;
    Ok(())
}

#[cfg(test)]
mod landform_tests {
    use super::*;

    #[test]
    fn replacement_terrain_never_leaves_obstacles_at_the_old_surface() {
        let input = TacticalSceneInput::load(Path::new(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../assets/tactical-scenes/sandstone-alcove.json"
        )))
        .unwrap();
        let collar = input.landform.unwrap().transition_collar();
        let mut dense = input.clone();
        for sample in &mut dense.playable.environment {
            sample.canopy_bps = 10000;
            sample.hilly_bps = 10000;
        }
        let obstacles = generated_obstacles(&dense);
        assert!(!obstacles.is_empty());
        for obstacle in obstacles {
            let (x, z) = match obstacle {
                GeneratedObstacle::Tree { x, z } | GeneratedObstacle::Rock { x, z, .. } => (x, z),
            };
            let point = (Vec2::new(f32::from(x), f32::from(z))
                - Vec2::new(
                    f32::from(input.playable.width - 1),
                    f32::from(input.playable.depth - 1),
                ) * 0.5)
                * input.playable.spacing_metres;
            assert!(
                !crate::scene_coordinates::ScenePlanPoint::try_from(point)
                    .is_ok_and(|point| collar.contains(point))
            );
        }
    }
}
