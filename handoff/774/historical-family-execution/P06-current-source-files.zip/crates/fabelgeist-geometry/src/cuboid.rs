//! Checked cuboid axes shared by authored catalogues and native scene geometry.

#[cfg(feature = "reflect")]
use bevy_reflect::Reflect;
use serde::{Deserialize, Serialize, de, ser::SerializeTupleStruct};

use crate::{CoordinateAxis, GeometryError, GeometryResult as Result, GeometryRole, SignedLength};

/// Nonnegative finite X/Y/Z extents in metres. Point and line solids are valid.
#[derive(Clone, Copy, Debug, PartialEq)]
#[cfg_attr(feature = "reflect", derive(Reflect))]
#[repr(transparent)]
#[cfg_attr(feature = "reflect", reflect(opaque))]
pub struct CuboidDimensions([SignedLength; 3]);

impl CuboidDimensions {
    pub const ZERO: Self = Self([SignedLength::ZERO; 3]);

    /// Admit an authored array or native vector in local X/Y/Z axis order.
    pub fn from_metres(value: impl Into<[f32; 3]>) -> Result<Self> {
        let value = value.into();
        for (axis, component) in [CoordinateAxis::X, CoordinateAxis::Y, CoordinateAxis::Z]
            .into_iter()
            .zip(value)
        {
            if !component.is_finite() {
                return Err(GeometryError::NonFinite {
                    role: GeometryRole::CuboidDimensions,
                    axis,
                });
            }
        }
        Self::from_axis_lengths(
            SignedLength::from_metres(value[0])?,
            SignedLength::from_metres(value[1])?,
            SignedLength::from_metres(value[2])?,
        )
    }

    /// Retain existing leaves after checking their cuboid extent roles.
    pub fn from_axis_lengths(x: SignedLength, y: SignedLength, z: SignedLength) -> Result<Self> {
        let value = [x, y, z];
        for (axis, component) in [CoordinateAxis::X, CoordinateAxis::Y, CoordinateAxis::Z]
            .into_iter()
            .zip(value)
        {
            if component.metres() < 0.0 {
                return Err(GeometryError::NegativeExtent {
                    role: GeometryRole::CuboidDimensions,
                    axis,
                });
            }
        }
        Ok(Self(value))
    }

    pub fn x_length(self) -> SignedLength {
        self.0[0]
    }

    pub fn y_length(self) -> SignedLength {
        self.0[1]
    }

    pub fn z_length(self) -> SignedLength {
        self.0[2]
    }

    /// Native local-axis array for model and storage boundaries without Bevy.
    pub fn axis_metres(self) -> [f32; 3] {
        self.0.map(SignedLength::metres)
    }

    /// Native scene-vector projection is available only to engine consumers.
    #[cfg(feature = "bevy-math")]
    pub fn metres(self) -> bevy_math::Vec3 {
        bevy_math::Vec3::from_array(self.axis_metres())
    }
}

impl Serialize for CuboidDimensions {
    fn serialize<S: serde::Serializer>(
        &self,
        serializer: S,
    ) -> std::result::Result<S::Ok, S::Error> {
        // Preserve pinned glam Vec3's tuple-struct identity and axis order.
        let mut state = serializer.serialize_tuple_struct("Vec3", 3)?;
        for component in self.axis_metres() {
            state.serialize_field(&component)?;
        }
        state.end()
    }
}

impl<'de> Deserialize<'de> for CuboidDimensions {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> std::result::Result<Self, D::Error> {
        struct AxesVisitor;

        impl<'de> de::Visitor<'de> for AxesVisitor {
            type Value = [f32; 3];

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("a sequence of 3 f32 values")
            }

            fn visit_seq<A: de::SeqAccess<'de>>(
                self,
                mut seq: A,
            ) -> std::result::Result<Self::Value, A::Error> {
                let x = seq
                    .next_element()?
                    .ok_or_else(|| de::Error::invalid_length(0, &self))?;
                let y = seq
                    .next_element()?
                    .ok_or_else(|| de::Error::invalid_length(1, &self))?;
                let z = seq
                    .next_element()?
                    .ok_or_else(|| de::Error::invalid_length(2, &self))?;
                Ok([x, y, z])
            }
        }

        let axes = d.deserialize_tuple_struct("Vec3", 3, AxesVisitor)?;
        Self::from_metres(axes).map_err(de::Error::custom)
    }
}
