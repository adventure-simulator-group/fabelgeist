//! Melee-only iteration roster assembled from canonical character and item data.

use super::*;
use crate::{
    item_catalog_schema::ItemKind,
    starting_character::{StartingAttributes, StartingCharacterSpec, StartingSkills},
};
use adventuresim_world_schema::{Culture, person_names::PersonalNameIdentity};

pub use error::{MeleeIterationError, MeleeIterationResult};
pub use evidence::*;

mod error;
mod evidence;

#[derive(Clone, Debug)]
pub struct MeleeIterationBuild {
    pub key: &'static str,
    pub name: String,
    pub description: &'static str,
    pub equipment_description: &'static str,
    pub weapon_id: &'static str,
    pub armor_ids: Vec<&'static str>,
    pub shield_id: Option<&'static str>,
    pub combatant: Combatant,
}

pub fn melee_iteration_roster()
-> MeleeIterationResult<(MeleeIterationBuild, Vec<MeleeIterationBuild>)> {
    let john_spec = crate::starting_character::default_character("melee-iteration");
    let john_name = john_spec.native_everyday_name()?.into_string();
    let john = build_from_spec(
        "john",
        &john_name,
        "Combat-trained adventurer; strong and agile, with broadly advanced melee training.",
        "Longsword, morion, breastplate, paired steel vambraces, ordinary clothing and boots.",
        &john_spec,
        "longsword",
        &["morion", "breastplate", "vambrace", "vambrace"],
        None,
    )?;
    let mut hammer_brute = purpose_build(
        "hammer_brute",
        "Hammer Brute",
        4.5,
        2.25,
        "war_hammer",
        &["brigandine", "arming_cap"],
        None,
        "Exceptionally strong but only moderately agile fighter with competent hammer training.",
        "War hammer, brigandine, and arming cap.",
    )?;
    hammer_brute.combatant.attributes.instinct = 3.0;
    hammer_brute.combatant.attributes.left_arm_agility = 3.0;
    hammer_brute.combatant.attributes.right_arm_agility = 3.0;
    hammer_brute.combatant.attributes.left_leg_agility = 3.0;
    hammer_brute.combatant.attributes.right_leg_agility = 3.0;
    let opponents = vec![
        purpose_build(
            "militia",
            "Shield Militiaman",
            3.0,
            2.5,
            "arming_sword",
            &["arming_doublet", "arming_cap"],
            Some("buckler"),
            "Healthy adult militia fighter with competent sword, shield, dodge, and balance training.",
            "Arming sword and buckler over an arming doublet and cap.",
        )?,
        purpose_build(
            "demi_lancer",
            "Demi-lancer",
            3.5,
            3.25,
            "arming_sword",
            &["morion", "cuirass", "tassets", "vambrace", "vambrace"],
            None,
            "Fit professional mounted soldier fighting on foot, with advanced sword, defense, and balance training.",
            "Arming sword and demi-lancer steel plate armor.",
        )?,
        purpose_build(
            "polearm_veteran",
            "Polearm Veteran",
            3.5,
            4.0,
            "halberd",
            &["jack_of_plates", "sallet"],
            None,
            "Seasoned professional with expert polearm skill, strong balance, and advanced defensive training.",
            "Halberd, jack of plates, and sallet.",
        )?,
        hammer_brute,
        purpose_build(
            "knife_novice",
            "Knife Novice",
            2.5,
            1.0,
            "baselard",
            &["arming_doublet"],
            None,
            "Below-average novice with rudimentary knife, dodge, block, will, and balance training.",
            "Baselard and an arming doublet.",
        )?,
    ];
    Ok((john, opponents))
}

#[expect(
    clippy::too_many_arguments,
    reason = "fixture construction keeps reviewer context with its build"
)]
fn purpose_build(
    key: &'static str,
    name: &'static str,
    physical: f32,
    skill_rank: f32,
    weapon: &'static str,
    armor: &[&'static str],
    shield: Option<&'static str>,
    description: &'static str,
    equipment_description: &'static str,
) -> MeleeIterationResult<MeleeIterationBuild> {
    let hours = Skill::Sword.hours_for_rank(skill_rank);
    let attributes = StartingAttributes {
        endurance: physical,
        immunity: physical,
        gut: physical,
        intelligence: 3.0,
        instinct: physical,
        eyesight: 3.0,
        hearing: 3.0,
        strength: physical,
        agility: physical,
    };
    let skills = StartingSkills {
        sword: hours,
        polearm: hours,
        bludgeon: hours,
        knife: hours,
        dodge: hours,
        block: hours,
        will: hours,
        balance: hours,
        ..StartingSkills::default()
    };
    let spec = StartingCharacterSpec {
        id: stable_id(key),
        name_identity: PersonalNameIdentity::authored(name, Culture::German),
        age_years: 28,
        background: description.into(),
        personality: crate::starting_character::default_character(key).personality,
        attributes,
        skills,
        currency: 0,
        settlement_selector: fabelgeist_determinism::Seed::from_u64(0),
        inventory: Vec::new(),
        age_tier: crate::starting_character::StartingAgeTier::Adult,
        profession: None,
        organization: None,
        religion_id: None,
    };
    build_from_spec(
        key,
        name,
        description,
        equipment_description,
        &spec,
        weapon,
        armor,
        shield,
    )
}

fn stable_id(value: &str) -> u64 {
    value.bytes().fold(0xcbf2_9ce4_8422_2325, |hash, byte| {
        (hash ^ u64::from(byte)).wrapping_mul(0x100_0000_01b3)
    })
}

#[expect(
    clippy::too_many_arguments,
    reason = "fixture construction names combat and reviewer context"
)]
fn build_from_spec(
    key: &'static str,
    name: &str,
    description: &'static str,
    equipment_description: &'static str,
    spec: &StartingCharacterSpec,
    weapon_id: &'static str,
    armor_ids: &[&'static str],
    shield_id: Option<&'static str>,
) -> MeleeIterationResult<MeleeIterationBuild> {
    let a = &spec.attributes;
    let mut combatant = Combatant::new(spec.id);
    combatant.attributes = PlayerAttributeValues {
        endurance: a.endurance,
        immunity: a.immunity,
        gut: a.gut,
        intelligence: a.intelligence,
        instinct: a.instinct,
        eyesight: a.eyesight,
        hearing: a.hearing,
        left_arm_strength: a.strength,
        right_arm_strength: a.strength,
        left_leg_strength: a.strength,
        right_leg_strength: a.strength,
        left_arm_agility: a.agility,
        right_arm_agility: a.agility,
        left_leg_agility: a.agility,
        right_leg_agility: a.agility,
    };
    combatant.skills = combat_skills(&spec.skills);
    combatant.body.weight_kg = 75.0;
    combatant.equipment = authored_equipment(weapon_id, armor_ids, shield_id)?;
    Ok(MeleeIterationBuild {
        key,
        name: name.to_owned(),
        description,
        equipment_description,
        weapon_id,
        armor_ids: armor_ids.to_vec(),
        shield_id,
        combatant,
    })
}

fn combat_skills(s: &StartingSkills) -> CombatSkills {
    CombatSkills {
        polearm_hours: s.polearm,
        axe_hours: s.axe,
        bludgeon_hours: s.bludgeon,
        sword_hours: s.sword,
        knife_hours: s.knife,
        dodge_hours: s.dodge,
        block_hours: s.block,
        bow_hours: 0.0,
        crossbow_hours: 0.0,
        firearm_hours: 0.0,
        throw_hours: s.throw,
        will_hours: s.will,
        insight_hours: s.insight,
        charm_hours: s.charm,
        command_hours: s.command,
        deception_hours: s.deception,
        physiology_hours: s.physiology,
        religion_hours: s.religion.total_direct(),
        stealth_hours: s.stealth,
        balance_hours: s.balance,
        bestiary_hours: s.bestiary,
        surgery_hours: s.surgery,
        tailoring_hours: s.tailoring,
        smithing_hours: s.smithing,
    }
}

fn authored_equipment(
    weapon_id: &str,
    armor_ids: &[&str],
    shield_id: Option<&str>,
) -> MeleeIterationResult<CombatEquipment> {
    let definition = crate::item_catalog::definition(weapon_id).ok_or_else(|| {
        MeleeIterationError::UnknownWeapon {
            weapon: weapon_id.to_owned(),
        }
    })?;
    let weapon = CombatWeapon::from_authored_melee_definition(definition)?;
    let mut equipment = CombatEquipment {
        weapon: Some(weapon),
        melee_weapon: Some(weapon),
        melee_weapon_id: Some(stable_id(weapon_id)),
        inventory_weight: definition.weight_kg,
        ..CombatEquipment::default()
    };
    if let Some(shield_id) = shield_id {
        let shield = crate::item_catalog::definition(shield_id).ok_or_else(|| {
            MeleeIterationError::UnknownShield {
                shield: shield_id.to_owned(),
            }
        })?;
        let ItemKind::Shield { block, .. } = shield.kind else {
            return Err(MeleeIterationError::NotShield {
                shield: shield_id.to_owned(),
            });
        };
        equipment.shield_block_bonus = block;
        equipment.shield_side = Some(match equipment.melee_holding_side {
            BodySide::Left => BodySide::Right,
            BodySide::Right => BodySide::Left,
            BodySide::Both => BodySide::Left,
        });
        equipment.defense_item_id = Some(stable_id(shield_id));
        equipment.inventory_weight += shield.weight_kg;
    }
    apply_authored_armor(&mut equipment, armor_ids)?;
    Ok(equipment)
}

fn apply_authored_armor(
    equipment: &mut CombatEquipment,
    armor_ids: &[&str],
) -> MeleeIterationResult<()> {
    for (index, armor_id) in armor_ids.iter().enumerate() {
        let armor = crate::item_catalog::definition(armor_id).ok_or_else(|| {
            MeleeIterationError::UnknownArmor {
                armor: (*armor_id).to_owned(),
            }
        })?;
        let ItemKind::Armor {
            coverage,
            resistance,
            padding,
            flexibility,
            range_of_motion,
            ..
        } = armor.kind
        else {
            continue;
        };
        let authored = armor.equipment.as_ref().ok_or_else(|| {
            MeleeIterationError::ArmorProjectionUnavailable {
                armor: (*armor_id).to_owned(),
            }
        })?;
        let occurrence = armor_ids[..index]
            .iter()
            .filter(|prior| *prior == armor_id)
            .count();
        let placement = authored
            .placements
            .get(occurrence % authored.placements.len().max(1))
            .ok_or_else(|| MeleeIterationError::ArmorPlacementUnavailable {
                armor: (*armor_id).to_owned(),
            })?;
        if placement.protection.is_empty() {
            return Err(MeleeIterationError::EmptyArmorProtection {
                armor: (*armor_id).to_owned(),
            });
        }
        for authored_part in &placement.protection {
            let part = crate::equipment::equipment_body_part(*authored_part);
            let coverage_geometry =
                crate::combat::AuthoredArmorCoverage::from_placement(placement, part);
            equipment.armor[body_part_index(part)] = CombatArmor {
                inventory_item_id: Some(stable_id(&format!("{armor_id}:{occurrence}"))),
                material: authored.material,
                resistance,
                padding,
                flexibility,
                range_of_motion,
                coverage,
                coverage_geometry,
            };
        }
        equipment.inventory_weight += armor.weight_kg;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roster_is_varied_and_melee_only() {
        let (john, opponents) = melee_iteration_roster().unwrap();
        assert_eq!(opponents.len(), 5);
        assert!(std::iter::once(&john).chain(&opponents).all(|build| {
            build.combatant.equipment.melee_weapon.is_some()
                && build.combatant.equipment.ranged_weapon.is_none()
        }));
        assert!(opponents.iter().any(|build| build.shield_id.is_some()));
        let hammer = opponents
            .iter()
            .find(|build| build.key == "hammer_brute")
            .unwrap()
            .combatant
            .equipment
            .melee_weapon
            .unwrap();
        let knife = opponents
            .iter()
            .find(|build| build.key == "knife_novice")
            .unwrap()
            .combatant
            .equipment
            .melee_weapon
            .unwrap();
        assert!(hammer.moment_of_inertia_kg_m2 > knife.moment_of_inertia_kg_m2);
        assert!(hammer.attack_interval_seconds > knife.attack_interval_seconds);
        assert_ne!(hammer.balance, knife.balance);
    }

    #[test]
    fn every_roster_weapon_uses_authored_physics_for_autoresolve_cadence_and_balance() {
        let (john, opponents) = melee_iteration_roster().unwrap();
        for build in std::iter::once(john).chain(opponents) {
            let definition = crate::item_catalog::definition(build.weapon_id).unwrap();
            let ItemKind::Weapon {
                preferred_attack,
                moment_of_inertia_kg_m2,
                ..
            } = definition.kind
            else {
                panic!("{} is not an authored weapon", build.weapon_id);
            };
            let grip_to_tip_m = definition
                .equipment
                .as_ref()
                .unwrap()
                .physical
                .grip_to_tip_m;
            let projected = build.combatant.equipment.melee_weapon.unwrap();
            let expected_timing = crate::equipment::melee_attack_timing(
                preferred_attack,
                moment_of_inertia_kg_m2,
                false,
            )
            .unwrap();
            let expected_interval = EMBEDDED_AUTORESOLVE_PARAMETERS
                .melee_windup_seconds
                .seconds()
                + expected_timing.recovery_secs.seconds();
            let expected_balance = crate::equipment::weapon_balance_from_moment(
                moment_of_inertia_kg_m2,
                definition.weight_kg,
                grip_to_tip_m,
            );
            assert!(
                (projected.attack_interval_seconds.seconds() - expected_interval).abs() < 1.0e-6
            );
            assert!((projected.balance - expected_balance).abs() < 1.0e-6);
        }
    }

    #[test]
    fn dodge_skill_participates_in_the_shared_exchange_equation() {
        let (_john, opponents) = melee_iteration_roster().unwrap();
        let attacker = opponents
            .iter()
            .find(|build| build.key == "knife_novice")
            .unwrap();
        let mut untrained = opponents[0].combatant.clone();
        untrained.skills.dodge_hours = 0.0;
        let mut expert = untrained.clone();
        expert.skills.dodge_hours = 100_000.0;
        let response = DefenderResponse::Dodge { input_reflex: 1.0 };
        let samples = MeleeExchangeSamples {
            contact: 0.4,
            defense_alignment: 0.5,
        };
        let separated = (1..=100).any(|step| {
            let precision = step as f32 / 100.0;
            let low = melee_exchange(
                &attacker.combatant,
                &untrained,
                precision,
                0.0,
                response,
                samples,
            )
            .unwrap();
            let high = melee_exchange(
                &attacker.combatant,
                &expert,
                precision,
                0.0,
                response,
                samples,
            )
            .unwrap();
            matches!(low.result, AttackResult::ToDefender { .. })
                && matches!(
                    high.result,
                    AttackResult::ToAttacker {
                        physical_contact: false,
                        ..
                    }
                )
        });
        assert!(separated);
    }

    fn assert_bounded_progress(outcome: &BattleOutcome) {
        let terminal = outcome.timeline.last().expect("terminal timeline event");
        assert_eq!(terminal.kind, MeleeTimelineKind::Terminal);
        assert_eq!(terminal.terminal_resolution, Some(outcome.resolution));
        assert!(outcome.rounds <= AUTORESOLVE_MAX_COMBAT_ROUNDS);
        assert!(outcome.timeline.iter().all(|event| {
            event.time_seconds.seconds().is_finite()
                && event.time_seconds >= BattleTime::ZERO
                && event.tick == MeleeTimelineEvent::tick_at(event.time_seconds)
        }));
        assert!(
            terminal.time_seconds.seconds()
                <= outcome.rounds as f32
                    * crate::combat::EMBEDDED_AUTORESOLVE_PARAMETERS
                        .combat_round_seconds
                        .seconds()
        );
        assert!(outcome.timeline.windows(2).all(|events| {
            events[0].sequence < events[1].sequence
                && events[0].tick <= events[1].tick
                && events[0].time_seconds <= events[1].time_seconds
        }));
        if outcome.resolution != BattleResolution::Timeout {
            return;
        }
        assert_eq!(outcome.rounds, AUTORESOLVE_MAX_COMBAT_ROUNDS);
        assert!(outcome.summary.melee_attacks > 0);
        assert!(outcome.summary.hits > 0);
        assert!(
            outcome.summary.total_health_damage.is_finite()
                && outcome.summary.total_health_damage > 0.0
        );
        for side in [&outcome.allies, &outcome.enemies] {
            assert!(
                side.iter()
                    .any(|fighter| !fighter.incapacitated && !fighter.yielded)
            );
        }
        let continuing = outcome
            .allies
            .iter()
            .chain(&outcome.enemies)
            .filter(|fighter| !fighter.incapacitated && !fighter.yielded)
            .any(|fighter| {
                let ongoing_bleeding = fighter.blood_loss_fraction.is_finite()
                    && fighter.blood_loss_fraction > 0.0
                    && fighter.wound_flow_fraction_per_second.is_finite()
                    && fighter.wound_flow_fraction_per_second > 0.0;
                // Read the most recent readiness projection, including cancellation
                // and transformation updates, so an obsolete deadline cannot pass.
                let scheduled = outcome
                    .timeline
                    .iter()
                    .rev()
                    .filter(|event| event.combatant_id == Some(fighter.id))
                    .find_map(|event| event.readiness_after_seconds)
                    .is_some_and(|ready| {
                        ready.seconds().is_finite() && ready > terminal.time_seconds
                    });
                ongoing_bleeding || scheduled
            });
        assert!(
            continuing,
            "bounded duel stopped making physiological or scheduled combat progress"
        );
    }

    #[test]
    fn iteration_duels_make_terminal_progress() {
        let (john, opponents) = melee_iteration_roster().unwrap();
        for opponent in opponents {
            let outcomes = || {
                (1..=32)
                    .map(fabelgeist_determinism::Seed::from_u64)
                    .map(|seed| {
                        let outcome = resolve_battle(
                            vec![john.combatant.clone()],
                            vec![opponent.combatant.clone()],
                            seed,
                            BattleOpening::Normal,
                        )
                        .unwrap();
                        assert_bounded_progress(&outcome);
                        outcome.resolution
                    })
                    .collect::<Vec<_>>()
            };
            assert_eq!(
                outcomes(),
                outcomes(),
                "{} was not reproducible",
                opponent.name
            );
        }
    }

    #[test]
    fn shorter_reach_combatants_land_contacts_across_bounded_property_seeds() {
        let (john, opponents) = melee_iteration_roster().unwrap();
        for opponent in opponents {
            let john_reach = john.combatant.equipment.weapon_reach();
            let opponent_reach = opponent.combatant.equipment.weapon_reach();
            if (john_reach - opponent_reach) == 0.0 {
                continue;
            }
            let shorter_id = if john_reach < opponent_reach {
                john.combatant.id
            } else {
                opponent.combatant.id
            };
            let landed = (1..=64)
                .map(fabelgeist_determinism::Seed::from_u64)
                .any(|seed| {
                    resolve_battle(
                        vec![john.combatant.clone()],
                        vec![opponent.combatant.clone()],
                        seed,
                        BattleOpening::Normal,
                    )
                    .unwrap()
                    .log
                    .iter()
                    .any(|entry| {
                        entry.attacker_id == shorter_id
                            && matches!(
                                entry.outcome,
                                BattleAttackOutcome::HitHealth | BattleAttackOutcome::HitArmor
                            )
                    })
                });
            assert!(landed, "{} shorter-reach side never landed", opponent.name);
        }
    }

    #[test]
    fn entering_reach_does_not_complete_a_committed_windup_early() {
        let (john, opponents) = melee_iteration_roster().unwrap();
        let hammer_brute = opponents
            .iter()
            .find(|build| build.key == "hammer_brute")
            .unwrap();
        let outcome = resolve_battle(
            vec![john.combatant],
            vec![hammer_brute.combatant.clone()],
            fabelgeist_determinism::Seed::from_u64(1),
            BattleOpening::Normal,
        )
        .unwrap();
        let scheduled_contacts = outcome
            .timeline
            .iter()
            .filter(|event| event.kind == MeleeTimelineKind::AttackStarted)
            .map(|event| (event.attack_id.unwrap(), event.attack_contact_tick.unwrap()))
            .collect::<std::collections::HashMap<_, _>>();
        for contact in outcome
            .timeline
            .iter()
            .filter(|event| event.kind == MeleeTimelineKind::Contact)
        {
            let scheduled_tick = scheduled_contacts[&contact.attack_id.unwrap()];
            assert!(
                contact.tick >= scheduled_tick,
                "movement into reach cannot manufacture the remaining windup: {contact:?}"
            );
        }
    }

    #[test]
    fn polearm_contact_uses_only_movement_elapsed_before_contact() {
        let (john, opponents) = melee_iteration_roster().unwrap();
        let veteran = opponents
            .iter()
            .find(|build| build.key == "polearm_veteran")
            .unwrap();
        let outcome = resolve_battle(
            vec![john.combatant],
            vec![veteran.combatant.clone()],
            fabelgeist_determinism::Seed::from_u64(1),
            BattleOpening::Normal,
        )
        .unwrap();
        for movement in outcome
            .timeline
            .iter()
            .filter(|event| event.kind == MeleeTimelineKind::Movement)
        {
            let elapsed = movement.movement_elapsed_seconds.unwrap().seconds();
            assert!(elapsed <= 1.0 / 64.0 + 1.0e-6);
            let displacement = movement.movement_displacement_metres.unwrap().abs();
            let speed_limit = movement
                .movement_speed_limit_metres_per_second
                .unwrap()
                .metres_per_second();
            assert!(displacement <= speed_limit * elapsed + 1.0e-6);
        }
        let first_contact = outcome
            .timeline
            .iter()
            .find(|event| event.kind == MeleeTimelineKind::Contact)
            .unwrap();
        assert!(
            outcome.timeline[..first_contact.sequence as usize]
                .iter()
                .all(|event| event.time_seconds <= first_contact.time_seconds)
        );
        let first_log = outcome.log.first().unwrap();
        assert_eq!(
            first_log
                .melee_telemetry
                .as_ref()
                .unwrap()
                .actual_contact_measure_metres,
            first_contact.engagement_distance_before_metres.unwrap()
        );
    }

    #[test]
    fn authored_brigandine_and_jack_plate_surfaces_stop_longsword_edges() {
        let (john, opponents) = melee_iteration_roster().unwrap();
        let attacker = &john.combatant;
        let attacker_equipment = attacker.equipment.for_melee();
        for key in ["hammer_brute", "polearm_veteran"] {
            let defender = &opponents
                .iter()
                .find(|build| build.key == key)
                .unwrap()
                .combatant;
            let defender_equipment = defender.equipment.for_melee();
            let surface = defender_equipment
                .armor_surface(BodyPart::Chest, 0.4)
                .expect("authored torso armor must expose its engaged surface");
            assert!(surface.material.is_some_and(|material| material.is_metal()));

            let result = resolve_melee_attack_by_parts(
                &attacker.skills,
                &attacker.attributes,
                &attacker.body,
                &attacker.essentials,
                &attacker_equipment,
                EMBEDDED_COMBAT_RESOLUTION_PARAMETERS,
                attacker_equipment.holding_side,
                attacker_equipment.weapon_preferred_melee_style(),
                1.0,
                1.0,
                MeleeContactLocation {
                    body_part: BodyPart::Chest,
                    anatomical_subregion: AnatomicalSubregion::ChestSternum,
                    surface_coordinate: 0.2,
                    armor_surface: Some(surface),
                },
                MeleeContactAtTime::intended(0.0),
                DefenderResponse::None,
                &defender.skills,
                &defender.attributes,
                &defender.body,
                &defender.essentials,
                &defender_equipment,
            );
            assert!(matches!(
                result,
                AttackResult::ToDefender {
                    cut_damage,
                    armor_impact: Some(ArmorImpact {
                        outcome: ArmorImpactOutcome::Stopped | ArmorImpactOutcome::Deflected,
                        ..
                    }),
                    ..
                } if cut_damage == 0.0
            ));
        }
    }

    #[test]
    fn acceptance_evidence_exercises_surface_gaps_and_nonbinary_defense() {
        let evidence = melee_iteration_acceptance_evidence().unwrap();
        assert_eq!(evidence.armor_contacts.len(), 2);
        assert!(evidence.armor_contacts[0].armor_layer_chain[0].intersected);
        assert!(!evidence.armor_contacts[1].armor_layer_chain[0].intersected);
        assert!(matches!(
            evidence.armor_contacts[0].result,
            AttackResult::ToDefender {
                armor_impact: Some(_),
                ..
            }
        ));
        assert_eq!(evidence.mirrored_vambrace_contacts.len(), 4);
        let left_surface = &evidence.mirrored_vambrace_contacts[0];
        let right_surface = &evidence.mirrored_vambrace_contacts[1];
        let left_gap = &evidence.mirrored_vambrace_contacts[2];
        let right_gap = &evidence.mirrored_vambrace_contacts[3];
        assert_eq!(
            left_surface
                .layer
                .geometry
                .segments()
                .map(|s| s.span)
                .collect::<Vec<_>>(),
            right_surface
                .layer
                .geometry
                .segments()
                .map(|s| s.span)
                .collect::<Vec<_>>()
        );
        assert!(left_surface.layer.intersected && right_surface.layer.intersected);
        assert!(!left_gap.layer.intersected && !right_gap.layer.intersected);
        assert!(matches!(
            evidence.armor_contacts[1].result,
            AttackResult::ToDefender {
                armor_impact: None,
                ..
            }
        ));
        assert!(!evidence.defense_matrix[0].defended);
        assert!(evidence.defense_matrix[1].defended);
        assert_eq!(evidence.disabled_weapon_arm.len(), 2);
        assert!(
            evidence
                .disabled_weapon_arm
                .iter()
                .all(|entry| entry.capability == "disabled_weapon_arm" && !entry.attack_available)
        );
        assert!(evidence.fatigue_cadence.fatigue > 0.0);
        assert!(evidence.fatigue_cadence.fatigue < 1.0);
        assert!(
            evidence
                .fatigue_cadence
                .fatigued_recovery_seconds
                .available()
                .unwrap()
                > evidence
                    .fatigue_cadence
                    .fresh_recovery_seconds
                    .available()
                    .unwrap()
        );
        assert!(
            evidence
                .autoresolve_timeline
                .normalized_nonterminal_sequences_equal
        );
        assert_eq!(evidence.autoresolve_timeline.simultaneous_contacts.len(), 2);
        assert_eq!(
            evidence.autoresolve_timeline.simultaneous_contacts[0].simultaneous_batch_id,
            evidence.autoresolve_timeline.simultaneous_contacts[1].simultaneous_batch_id
        );
        assert!(
            evidence
                .autoresolve_timeline
                .polearm_opening_measure
                .iter()
                .any(|event| event.kind == MeleeTimelineKind::Movement)
        );
        assert!(!evidence.autoresolve_timeline.canceled_attack_ids.is_empty());
        assert!(
            evidence
                .autoresolve_timeline
                .canceled_attack_ids_that_contacted
                .is_empty()
        );
        assert!(evidence.all_weapon_contact_bands.iter().all(|contact| {
            contact.center_separation_metres >= HUMANOID_MELEE_MINIMUM_CENTER_SEPARATION_METRES
                && (contact.transformed_energy_joules
                    - contact.incident_energy_joules * contact.energy_fraction)
                    .abs()
                    < 1.0e-4
                && contact.transformed_energy_joules <= contact.incident_energy_joules + 1.0e-4
        }));
        assert!(evidence.all_weapon_contact_bands.iter().any(|contact| {
            contact.weapon == "war_hammer"
                && matches!(
                    contact.classification,
                    MeleeContactClassification::Haft | MeleeContactClassification::Pommel
                )
                && contact.energy_fraction < 1.0
        }));
        assert!(evidence.all_weapon_contact_bands.iter().any(|contact| {
            contact.weapon == "longsword"
                && contact.surface_measure_metres <= 0.000_1
                && contact.energy_fraction < 1.0
        }));
    }
}
