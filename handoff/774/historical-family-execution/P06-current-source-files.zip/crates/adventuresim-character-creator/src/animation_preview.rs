use super::*;
use bevy::{
    animation::{AnimatedBy, AnimationTargetId},
    gltf::Gltf,
    mesh::{
        VertexAttributeValues,
        skinning::{SkinnedMesh, SkinnedMeshInverseBindposes},
    },
};
pub use binding::{ClothBinding, skin, skin_mesh};
use cloth_motion::ClothMotion;
#[cfg(test)]
use cloth_motion::simulate;
pub use colliders::ArmorSkin;

mod binding;
mod cloth_motion;
mod cloth_render;
mod colliders;

#[derive(Resource, Default)]
pub struct WalkPreview {
    requested: Handle<Gltf>,
    graph: Option<Handle<AnimationGraph>>,
    node: Option<AnimationNodeIndex>,
    pub player: Option<Entity>,
    skeleton: Option<Entity>,
    pub joints: fabelgeist_rig::RigJointTable<Entity>,
    pub inverse_bindposes: Handle<SkinnedMeshInverseBindposes>,
    pub playing: bool,
    pub physics: bool,
    pub ignore_cloth_weights: bool,
    pub simulation: SimulationSettings,
}

#[derive(Clone, Debug)]
pub struct SimulationSettings {
    pub self_collision: bool,
    pub cloth_thickness: f32,
    pub contact_iterations: u32,
    pub gravity: f32,
    pub damping: f32,
    pub stretch_stiffness: f32,
    pub follow_strength: f32,
    pub collision_margin: f32,
    pub collision_distance: f32,
    pub substeps: u32,
    pub iterations: u32,
}

#[derive(Component)]
struct PreviewSkeleton;

// Preserve all eight exported influences. Reducing each vertex independently
// to four can discard the opposite leg precisely at the centre transition.
#[derive(Component)]
pub struct BodySkin {
    pub positions: Vec<[f32; 3]>,
    pub faces: Vec<[u32; 3]>,
    pub indices: fabelgeist_rig::PackedRigSkin<8>,
    pub weights: Vec<[f32; 8]>,
}

#[derive(Component)]
pub struct ClothSkin {
    render_vertices: Option<Vec<usize>>,
    form: GarmentForm,
    positions: Vec<[f32; 3]>,
    faces: Vec<[u32; 3]>,
    edges: Vec<[u32; 2]>,
    binding: ClothBinding,
    current: Vec<Vec3>,
    previous: Vec<Vec3>,
    motion: ClothMotion,
}

#[derive(Default)]
pub struct BodyMotion {
    rig: Option<Entity>,
    positions: Vec<Vec3>,
}

impl Default for SimulationSettings {
    fn default() -> Self {
        Self {
            self_collision: true,
            cloth_thickness: 0.004,
            contact_iterations: 3,
            gravity: 9.81,
            damping: 0.015,
            stretch_stiffness: 0.96,
            follow_strength: 1.0,
            collision_margin: 0.006,
            collision_distance: 0.08,
            substeps: 2,
            iterations: 3,
        }
    }
}

impl WalkPreview {
    pub fn ready(&self) -> bool {
        self.player.is_some() && self.graph.is_some() && self.node.is_some()
    }

    pub fn start_or_resume(&self, player: &mut AnimationPlayer) {
        if player.playing_animations().next().is_none() {
            player
                .play(self.node.expect("ready walk preview has a graph node"))
                .repeat();
        } else {
            player.resume_all();
        }
    }
}

impl ClothSkin {
    pub fn new(
        form: GarmentForm,
        positions: Vec<[f32; 3]>,
        _normals: Vec<[f32; 3]>,
        faces: Vec<[u32; 3]>,
        binding: ClothBinding,
    ) -> Result<Self> {
        if let ClothBinding::Weighted { indices, weights } = &binding {
            anyhow::ensure!(
                indices.len() == positions.len() && weights.len() == positions.len(),
                "cloth skin rows and positions have different vertex counts"
            );
        }
        let mut edges = std::collections::BTreeSet::new();
        for face in &faces {
            for [a, b] in [[face[0], face[1]], [face[1], face[2]], [face[2], face[0]]] {
                edges.insert(if a < b { [a, b] } else { [b, a] });
            }
        }
        let current: Vec<Vec3> = positions.iter().copied().map(Vec3::from_array).collect();
        Ok(Self {
            render_vertices: None,
            form,
            positions,
            faces,
            edges: edges.into_iter().collect(),
            binding,
            previous: current.clone(),
            current,
            motion: ClothMotion::Skinned,
        })
    }
}

pub fn request(mut preview: ResMut<WalkPreview>, assets: Res<AssetServer>) {
    preview.requested = assets.load("animations/biped/unarmed/walk.glb");
}

pub fn prepare(
    mut commands: Commands,
    mut preview: ResMut<WalkPreview>,
    gltfs: Res<Assets<Gltf>>,
    mut graphs: ResMut<Assets<AnimationGraph>>,
) {
    if preview.graph.is_none()
        && let Some(gltf) = gltfs.get(&preview.requested)
        && let Some(clip) = gltf.animations.first()
    {
        let (graph, node) = AnimationGraph::from_clip(clip.clone());
        preview.graph = Some(graphs.add(graph));
        preview.node = Some(node);
    }
    let (Some(player), Some(graph)) = (preview.player, preview.graph.clone()) else {
        return;
    };
    if let Ok(mut entity) = commands.get_entity(player) {
        entity.try_insert(AnimationGraphHandle(graph));
    }
}

pub fn rebuild(
    preview: &mut WalkPreview,
    commands: &mut Commands,
    inverse_bindposes: &mut Assets<SkinnedMeshInverseBindposes>,
    model: &BodyModel,
    generated: &GeneratedCharacter,
) {
    if let Some(root) = preview.skeleton.take() {
        commands.entity(root).despawn();
    }
    if let Some(player) = preview.player.take() {
        commands.entity(player).despawn();
    }
    preview.playing = false;

    let player = commands
        .spawn((
            Name::new("Character walk player"),
            AnimationPlayer::default(),
        ))
        .id();
    if let Some(graph) = preview.graph.clone() {
        commands.entity(player).insert(AnimationGraphHandle(graph));
    }
    let skeleton_name = Name::new("Skeleton");
    let skeleton = commands
        .spawn((
            PreviewSkeleton,
            skeleton_name.clone(),
            Transform::default(),
            AnimationTargetId::from_names([&skeleton_name].into_iter()),
            AnimatedBy(player),
            Visibility::Hidden,
        ))
        .id();

    let character = &model.mhr.character;
    let globals: fabelgeist_rig::RigJointTable<_> = generated
        .global_joint_states
        .iter()
        .copied()
        .map(mhr_state)
        .collect();
    let mut joints = fabelgeist_rig::RigJointTable::default();
    for (index, name) in character.skeleton.names.indexed() {
        let parent = character.skeleton.parents[index];
        let local = match parent {
            None => globals[index],
            Some(parent) => globals[parent].inverse().compose(&globals[index]),
        };
        let mut path = vec![skeleton_name.clone()];
        let mut lineage = vec![index];
        let mut ancestor = parent;
        while let Some(joint) = ancestor {
            lineage.push(joint);
            ancestor = character.skeleton.parents[joint];
        }
        for joint in lineage.into_iter().rev() {
            path.push(bevy_joint_name(&character.skeleton.names[joint]));
        }
        let entity = commands
            .spawn((
                bevy_joint_name(name),
                bevy_transform(local),
                AnimationTargetId::from_names(path.iter()),
                AnimatedBy(player),
            ))
            .id();
        let parent_entity = parent.map_or(skeleton, |parent| joints[parent]);
        commands.entity(parent_entity).add_child(entity);
        joints.push(entity);
    }
    let matrices = globals
        .into_iter()
        .map(|state| {
            let inverse = state.inverse();
            Mat4::from_scale_rotation_translation(
                Vec3::splat(inverse.scale as f32),
                Quat::from_xyzw(
                    inverse.rotation[0] as f32,
                    inverse.rotation[1] as f32,
                    inverse.rotation[2] as f32,
                    inverse.rotation[3] as f32,
                ),
                Vec3::new(
                    inverse.translation[0] as f32,
                    inverse.translation[1] as f32,
                    inverse.translation[2] as f32,
                ),
            )
        })
        .collect::<Vec<_>>();
    preview.inverse_bindposes = inverse_bindposes.add(SkinnedMeshInverseBindposes::from(matrices));
    preview.player = Some(player);
    preview.skeleton = Some(skeleton);
    preview.joints = joints;
}

#[expect(
    clippy::too_many_arguments,
    reason = "Bevy injects these system parameters independently"
)]
pub fn deform_cloth(
    preview: Res<WalkPreview>,
    time: Res<Time>,
    binds: Res<Assets<SkinnedMeshInverseBindposes>>,
    joints: Query<&GlobalTransform>,
    bodies: Query<&BodySkin>,
    armor: Query<&ArmorSkin>,
    mut cloth: Query<(&Mesh3d, &mut ClothSkin)>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut body_motion: Local<BodyMotion>,
) {
    if !preview.playing {
        return;
    }
    let Some(bind) = binds.get(&preview.inverse_bindposes) else {
        return;
    };
    let Some(matrices) = preview
        .joints
        .iter()
        .zip(bind.iter())
        .map(|(entity, inverse)| {
            joints
                .get(*entity)
                .ok()
                .map(|global| global.to_matrix() * *inverse)
        })
        .collect::<Option<fabelgeist_rig::RigJointTable<_>>>()
    else {
        return;
    };
    let rig = preview.joints.first().copied();
    let body = bodies.iter().next().map(|body| {
        let (rest, end, faces) = colliders::posed_colliders(body, &armor, &matrices);
        let start = if body_motion.rig == rig && body_motion.positions.len() == end.len() {
            body_motion.positions.clone()
        } else {
            rest
        };
        (start, end, faces)
    });
    let targets = cloth
        .iter()
        .map(|(_, skin)| {
            if preview.physics && preview.ignore_cloth_weights {
                return Some(None);
            }
            let ClothBinding::Weighted { indices, weights } = &skin.binding else {
                return None;
            };
            if indices.joint_count().len() != matrices.len() {
                return None;
            }
            Some(Some(skinned_positions(
                &skin.positions,
                indices,
                weights,
                &matrices,
            )))
        })
        .collect::<Option<Vec<_>>>();
    let Some(targets) = targets else {
        // Weighted playback cannot evaluate unbound cloth. Keep its last
        // geometry until a binding or unweighted physics is selected.
        return;
    };

    if preview.physics {
        cloth_motion::simulate_outfit(
            &mut cloth,
            &body,
            &targets,
            time.delta_secs(),
            &preview.simulation,
        );
    } else {
        for (index, (_, mut skin)) in cloth.iter_mut().enumerate() {
            let Some(target) = targets[index].as_ref() else {
                return;
            };
            skin.current.clone_from(target);
            skin.previous.clone_from(target);
            skin.motion = ClothMotion::Skinned;
        }
    }
    if let Some((_, end, _)) = body {
        body_motion.rig = rig;
        body_motion.positions = end;
    } else {
        body_motion.positions.clear();
        body_motion.rig = None;
    }
    for (handle, skin) in &cloth {
        if let Some(mut mesh) = meshes.get_mut(handle) {
            skin.update_render_mesh(&mut mesh);
        }
    }
}

/// Native Bevy naming boundary. A `From` implementation here is forbidden by
/// orphan rules: both `Name` and `RigJointName` belong to other crates. Keeping
/// this adapter here also keeps the shared rig owner independent of Bevy.
fn bevy_joint_name(name: &fabelgeist_rig::RigJointName) -> Name {
    Name::new(std::borrow::Cow::from(name.clone()))
}

fn mhr_state(value: [f32; 8]) -> fabelgeist_mhr::math::Transform {
    fabelgeist_mhr::math::Transform {
        translation: [value[0] as f64, value[1] as f64, value[2] as f64],
        rotation: [
            value[3] as f64,
            value[4] as f64,
            value[5] as f64,
            value[6] as f64,
        ],
        scale: value[7] as f64,
    }
}

fn bevy_transform(value: fabelgeist_mhr::math::Transform) -> Transform {
    Transform {
        translation: Vec3::new(
            value.translation[0] as f32,
            value.translation[1] as f32,
            value.translation[2] as f32,
        ),
        rotation: Quat::from_xyzw(
            value.rotation[0] as f32,
            value.rotation[1] as f32,
            value.rotation[2] as f32,
            value.rotation[3] as f32,
        ),
        scale: Vec3::splat(value.scale as f32),
    }
}

fn collision_vector(p: Vec3) -> fabelgeist_math::Vec3 {
    fabelgeist_math::Vec3::new(p.x, p.y, p.z)
}

fn skinned_positions(
    positions: &[[f32; 3]],
    indices: &fabelgeist_rig::PackedRigSkin<8>,
    weights: &[[f32; 8]],
    matrices: &fabelgeist_rig::RigJointTable<Mat4>,
) -> Vec<Vec3> {
    positions
        .iter()
        .enumerate()
        .map(|(v, p)| {
            blend_point(
                Vec3::from_array(*p),
                indices.vertex(v),
                weights[v],
                matrices,
            )
        })
        .collect()
}

fn surface_normals(positions: &[Vec3], faces: &[[u32; 3]]) -> Vec<Vec3> {
    let mut normals = vec![Vec3::ZERO; positions.len()];
    for face in faces {
        let [a, b, c] = face.map(|v| v as usize);
        let normal = (positions[b] - positions[a]).cross(positions[c] - positions[a]);
        normals[a] += normal;
        normals[b] += normal;
        normals[c] += normal;
    }
    normals.into_iter().map(|n| n.normalize_or_zero()).collect()
}

fn blend_point(
    point: Vec3,
    indices: [fabelgeist_rig::RigJointOrdinal; 8],
    weights: [f32; 8],
    matrices: &fabelgeist_rig::RigJointTable<Mat4>,
) -> Vec3 {
    indices
        .into_iter()
        .zip(weights)
        .filter(|(_, w)| *w > 0.0)
        .fold(Vec3::ZERO, |sum, (joint, weight)| {
            sum + matrices[joint].transform_point3(point) * weight
        })
}

#[cfg(test)]
mod deformation_tests {
    use super::*;

    #[test]
    fn cloth_preserves_opposite_leg_motion_in_last_four_influences() {
        let matrices = (0..8)
            .map(|i| Mat4::from_translation(Vec3::Z * if i < 4 { 1.0 } else { -1.0 }))
            .collect::<fabelgeist_rig::RigJointTable<_>>();
        let point = Vec3::new(0.0, 0.5, 0.0);
        let centre = blend_point(
            point,
            [0usize, 1, 2, 3, 4, 5, 6, 7].map(fabelgeist_rig::RigJointOrdinal::from),
            [0.125; 8],
            &matrices,
        );
        assert!((centre - point).length() < 1e-6);
        let left = blend_point(
            point,
            [0usize, 1, 2, 3, 4, 5, 6, 7].map(fabelgeist_rig::RigJointOrdinal::from),
            [0.2, 0.2, 0.2, 0.2, 0.05, 0.05, 0.05, 0.05],
            &matrices,
        );
        assert!((left.z - 0.6).abs() < 1e-6);
    }

    #[test]
    fn simulated_edges_preserve_the_draped_rest_length() {
        let positions = vec![[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]];
        let mut skin = ClothSkin::new(
            GarmentForm::Legged,
            positions.clone(),
            vec![[0.0, 0.0, 1.0]; 3],
            vec![[0, 1, 2]],
            ClothBinding::Weighted {
                indices: fabelgeist_rig::PackedRigSkin::from_native(
                    vec![[0; 8]; 3],
                    fabelgeist_rig::RigJointCount::from_native_joint_count(1),
                )
                .unwrap(),
                weights: vec![[0.0; 8]; 3],
            },
        )
        .unwrap();
        skin.current[1].x = 3.0;
        skin.previous.clone_from(&skin.current);
        let targets = positions
            .into_iter()
            .map(Vec3::from_array)
            .collect::<Vec<_>>();
        simulate(
            &mut skin,
            Some(&targets),
            None,
            0.0,
            &SimulationSettings::default(),
        );
        assert!((skin.current[1] - skin.current[0]).length() < 1.2);
    }

    #[test]
    fn unweighted_physics_preserves_rest_shape() {
        let positions = vec![[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]];
        let mut skin = ClothSkin::new(
            GarmentForm::Legged,
            positions.clone(),
            vec![[0.0, 0.0, 1.0]; 3],
            vec![[0, 1, 2]],
            ClothBinding::Unweighted,
        )
        .unwrap();
        // A translated garment must not be pulled back toward its rest location.
        for point in &mut skin.current {
            *point += Vec3::X * 5.0;
        }
        skin.previous = skin.current.clone();
        simulate(
            &mut skin,
            None,
            None,
            1.0 / 60.0,
            &SimulationSettings::default(),
        );
        for (v, rest) in positions.iter().enumerate() {
            assert!((skin.current[v].x - rest[0] - 5.0).abs() < 1e-5);
            assert!(skin.current[v].y < rest[1]);
            assert!(skin.current[v].is_finite());
        }
        assert!(((skin.current[1] - skin.current[0]).length() - 1.0).abs() < 1e-5);
    }

    #[test]
    fn animation_contact_world_separates_two_garments_without_launching_them() {
        use bevy::ecs::system::RunSystemOnce;
        let mut world = World::new();
        world.insert_resource(Time::<()>::default());
        world.insert_resource(Assets::<Mesh>::default());
        let mut binds = Assets::<SkinnedMeshInverseBindposes>::default();
        let inverse_bindposes = binds.add(SkinnedMeshInverseBindposes::from(vec![Mat4::IDENTITY]));
        world.insert_resource(binds);
        let joint = world.spawn(GlobalTransform::IDENTITY).id();
        world.insert_resource(WalkPreview {
            playing: true,
            physics: true,
            ignore_cloth_weights: true,
            joints: vec![joint].into(),
            inverse_bindposes,
            simulation: SimulationSettings {
                gravity: 0.0,
                ..Default::default()
            },
            ..Default::default()
        });
        let mut entities = Vec::new();
        for height in [-0.001, 0.001] {
            let positions = vec![
                [-1.0, height, -1.0],
                [0.0, height, 1.0],
                [1.0, height, -1.0],
            ];
            let mesh = Mesh::new(
                PrimitiveTopology::TriangleList,
                RenderAssetUsages::default(),
            );
            let handle = world.resource_mut::<Assets<Mesh>>().add(mesh);
            let skin = ClothSkin::new(
                GarmentForm::Skirted,
                positions,
                vec![],
                vec![[0, 1, 2]],
                ClothBinding::Weighted {
                    indices: fabelgeist_rig::PackedRigSkin::from_native(
                        vec![[0; 8]; 3],
                        fabelgeist_rig::RigJointCount::from_native_joint_count(1),
                    )
                    .unwrap(),
                    weights: vec![[0.0; 8]; 3],
                },
            )
            .unwrap();
            entities.push(world.spawn((Mesh3d(handle), skin)).id());
        }
        world.run_system_once(deform_cloth).unwrap();
        let a = world.get::<ClothSkin>(entities[0]).unwrap();
        let b = world.get::<ClothSkin>(entities[1]).unwrap();
        let gap = (b.current.iter().map(|p| p.y).sum::<f32>()
            - a.current.iter().map(|p| p.y).sum::<f32>())
            / 3.0;
        assert!(gap > 0.0035, "garments stayed only {gap} m apart");
        for skin in [a, b] {
            for (p, previous) in skin.current.iter().zip(&skin.previous) {
                assert!(
                    (*p - *previous).length() < 1e-5,
                    "contact injected velocity"
                );
            }
        }
    }

    #[test]
    fn animated_body_ccd_retains_pose_history_across_frames() {
        let mut world = World::new();
        world.insert_resource(Time::<()>::default());
        world.insert_resource(Assets::<Mesh>::default());
        let mut binds = Assets::<SkinnedMeshInverseBindposes>::default();
        let inverse_bindposes = binds.add(SkinnedMeshInverseBindposes::from(vec![Mat4::IDENTITY]));
        world.insert_resource(binds);
        let joint = world.spawn(GlobalTransform::IDENTITY).id();
        world.insert_resource(WalkPreview {
            playing: true,
            physics: true,
            ignore_cloth_weights: true,
            joints: vec![joint].into(),
            inverse_bindposes,
            simulation: SimulationSettings {
                gravity: 0.0,
                ..Default::default()
            },
            ..Default::default()
        });
        world.spawn(BodySkin {
            positions: vec![[-10.0, -10.0, -1.0], [10.0, -10.0, -1.0], [0.0, 10.0, -1.0]],
            faces: vec![[0, 1, 2]],
            indices: fabelgeist_rig::PackedRigSkin::from_native(
                vec![[0; 8]; 3],
                fabelgeist_rig::RigJointCount::from_native_joint_count(1),
            )
            .unwrap(),
            weights: vec![[1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]; 3],
        });
        let mesh = world.resource_mut::<Assets<Mesh>>().add(Mesh::new(
            PrimitiveTopology::TriangleList,
            RenderAssetUsages::default(),
        ));
        let cloth = world
            .spawn((
                Mesh3d(mesh),
                ClothSkin::new(
                    GarmentForm::Skirted,
                    vec![[-0.1, -0.1, 0.0], [0.1, -0.1, 0.0], [0.0, 0.1, 0.0]],
                    vec![],
                    vec![[0, 1, 2]],
                    ClothBinding::Weighted {
                        indices: fabelgeist_rig::PackedRigSkin::from_native(
                            vec![[0; 8]; 3],
                            fabelgeist_rig::RigJointCount::from_native_joint_count(1),
                        )
                        .unwrap(),
                        weights: vec![[0.0; 8]; 3],
                    },
                )
                .unwrap(),
            ))
            .id();
        let mut schedule = Schedule::default();
        schedule.add_systems(deform_cloth);
        schedule.run(&mut world);
        // Each jump exceeds the discrete body's collision-search distance.
        // Neither final frame alone would discover the swept plane crossing.
        for displacement in [2.0, 4.0] {
            *world.get_mut::<GlobalTransform>(joint).unwrap() =
                GlobalTransform::from_translation(Vec3::Z * displacement);
            schedule.run(&mut world);
            let skin = world.get::<ClothSkin>(cloth).unwrap();
            assert!(
                skin.current.iter().all(|p| p.z > displacement - 1.0),
                "moving body tunneled through cloth: {:?}",
                skin.current
            );
            assert!(skin.current.iter().all(|p| p.is_finite()));
        }
    }
}
