use super::*;
use fabelgeist_rig::RigJointName;

pub(super) async fn prepare(
    input: &DrapeInput,
    build: &fabelgeist_garment_fit::GarmentBuild,
    settings: &FitSettings,
    fabric: Fabric,
) -> Result<(Fit, fabelgeist_bvh::TriangleBvh)> {
    let context = fabelgeist_gpu::prelude::WgpuContext::new().await?;
    let mut fit = Fit::new(context, build, fabric, settings)?;
    // A fitted surface is built where it is worn; only a pattern is placed.
    let fitted = input.selection.is_fitted();
    let mut pose = fabelgeist_garment_fit::GarmentPose::for_mesh(&build.mesh);
    if !fitted {
        // Pattern placement is measured from the floor and the pelvis centre.
        // Keep the actual body size: translate the garment, never scale the body.
        let floor = input
            .positions
            .iter()
            .map(|p| p[1])
            .fold(f32::INFINITY, f32::min);
        let hip = |name: &RigJointName| -> Result<[f32; 8]> {
            Ok(input.joints[name.require_in(&input.names)?])
        };
        let (left, right) = (hip(&RigJointName::L_UPLEG)?, hip(&RigJointName::R_UPLEG)?);
        let hip_center_x = (left[0] + right[0]) * 0.5;
        let lateral_offset = if hip_center_x.abs() < 0.005 {
            0.0
        } else {
            hip_center_x
        };
        pose.garment.offset = Vec3::new(lateral_offset, floor, (left[2] + right[2]) * 0.5);
    }
    fit.set_pose(pose)?;
    let vertices = input
        .positions
        .iter()
        .copied()
        .map(vector)
        .collect::<Vec<_>>();
    let collision = collision_surface(input);
    if !fitted {
        let mut placed = fit.placed_positions();
        clear_panels(
            &mut placed,
            &build.mesh,
            &collision,
            settings.body_offset_cm * 0.01 + fabric.particle_radius(),
        );
        fit.cloth.particles.write_positions(&fit.context, &placed)?;
    }
    fit.set_body(&vertices, &input.faces, settings, &fabric)
        .await?;
    if !input.obstacles.is_empty() {
        fit.set_collision_mesh(
            &collision.positions,
            &collision.triangles,
            settings,
            &fabric,
        )?;
    }
    Ok((fit, collision))
}

/// The wearer and every inner garment, as one surface the cloth must clear.
pub(super) fn collision_surface(input: &DrapeInput) -> fabelgeist_bvh::TriangleBvh {
    let mut vertices: Vec<_> = input.positions.iter().copied().map(vector).collect();
    let mut faces = input.faces.clone();
    for garment in &input.obstacles {
        let offset = vertices.len() as u32;
        vertices.extend(garment.positions.iter().copied().map(vector));
        faces.extend(garment.faces.iter().map(|face| face.map(|i| i + offset)));
    }
    fabelgeist_bvh::TriangleBvh::new(vertices, faces)
}
