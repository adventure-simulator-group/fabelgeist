//! Separate hip defense, rear-knee strips and standing neck mail.
use super::*;
use fabelgeist_rig::{RigJointName, RigJointPart};

use crate::armor_frames::FittingPlacement;
const BRAYETTE_WAIST_ABOVE_PELVIS_M: f32 = 0.10;
const BRAYETTE_LEG_FRACTION: f32 = 0.30;
const STANDARD_COLLAR_HEIGHT_M: f32 = 0.065;
const STANDARD_BIB_DEPTH_M: f32 = 0.13;
const KNEE_STRIP_GAP_M: f32 = 0.024;
const KNEE_STRIP_LENGTH_M: f32 = 0.12;

pub(super) fn brayette(
    design: &UnderlayerDesign,
    frame: RegionFrame<'_>,
    joint: &impl Fn(&RigJointName) -> Result<[f32; 3]>,
) -> Result<Vec<ConvexRegion>> {
    let pelvis = joint(&RigJointName::C_SPINE0)?;
    let hip = joint(&RigJointName::L_UPLEG)?;
    let knee = joint(&RigJointName::L_LOWLEG)?;
    let top = pelvis[1] + BRAYETTE_WAIST_ABOVE_PELVIS_M;
    let hem = hip[1] - (hip[1] - knee[1]) * BRAYETTE_LEG_FRACTION;
    let bottom = top - (top - hem) * design.length.unit();
    let extent = frame(FitRegion::Hips)?.half_extents;
    // A continuous pelvic surface supplies the crotch bridge and both leg
    // openings, rather than two disconnected thigh sleeves.
    Ok(vec![box_region(
        [
            pelvis[0] - extent[0] * 2.,
            bottom,
            pelvis[2] - extent[2] * 2.,
        ],
        [pelvis[0] + extent[0] * 2., top, pelvis[2] + extent[2] * 2.],
    )])
}

pub(super) fn knee(
    design: &UnderlayerDesign,
    placement: FittingPlacement,
    frame: RegionFrame<'_>,
    joint: &impl Fn(&RigJointName) -> Result<[f32; 3]>,
) -> Result<Vec<ConvexRegion>> {
    let side = placement.side()?;

    let knee = joint(&side.joint(RigJointPart::Lowleg))?;
    let knee_frame = frame(FitRegion::Knee(side))?;
    let half_height = KNEE_STRIP_LENGTH_M * design.length.unit() * 0.5;
    let half_width = design.patch_width.metres() * 0.5;
    let rear_depth = knee_frame.half_extents[2] * 2.;
    // The A 6147 cutting pattern places narrow longitudinal mail strips
    // alongside one another across the knee flexion zone.
    Ok([
        [-half_width, -KNEE_STRIP_GAP_M * 0.5],
        [KNEE_STRIP_GAP_M * 0.5, half_width],
    ]
    .map(|[low, high]| {
        box_region(
            [knee[0] + low, knee[1] - half_height, knee[2] - rear_depth],
            [knee[0] + high, knee[1] + half_height, knee[2]],
        )
    })
    .to_vec())
}

pub(super) fn standard(
    design: &UnderlayerDesign,
    frame: RegionFrame<'_>,
    joint: &impl Fn(&RigJointName) -> Result<[f32; 3]>,
) -> Result<Vec<ConvexRegion>> {
    let neck = joint(&RigJointName::C_NECK)?;
    let neck_frame = frame(FitRegion::Neck)?;
    let half_width = neck_frame.half_extents[0] + design.patch_width.metres() * 0.5;
    let depth = neck_frame.half_extents[2] * 2.;
    let mut region = box_region(
        [
            neck[0] - half_width,
            neck[1] - STANDARD_BIB_DEPTH_M * design.length.unit(),
            neck[2] - depth,
        ],
        [
            neck[0] + half_width,
            neck[1] + STANDARD_COLLAR_HEIGHT_M * design.length.unit(),
            neck[2] + depth,
        ],
    );
    let drop = STANDARD_BIB_DEPTH_M * design.length.unit();
    for sign in [-1., 1.] {
        region.push(Plane {
            normal: [sign * drop / half_width, -1., 0.],
            offset: drop - neck[1] + sign * drop / half_width * neck[0],
        });
    }
    Ok(vec![region])
}
