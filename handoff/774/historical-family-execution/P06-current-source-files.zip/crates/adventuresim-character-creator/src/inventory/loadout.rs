//! The worn articles, grouped by the generator that builds each on the body.

use super::{Article, EquipConflict, Inventory, InventoryItemId};
use crate::{
    equipment_catalog::{CatalogPlacement, ItemCatalog, is_wearable},
    garment::{GarmentSelection, SettledDrape},
    item_design::ItemDesign,
};

/// Everything worn, validated to fit together.
#[derive(Debug, Default)]
pub struct Loadout<'a> {
    /// Catalog clothing shells offset from the body surface.
    pub clothing: Vec<CatalogPiece<'a>>,
    /// Catalog items built from a parametric design.
    pub fitted: Vec<FittedPiece<'a>>,
    /// Cloth, from the innermost layer out, in draping order.
    pub draped: Vec<DrapedPiece<'a>>,
}

#[derive(Clone, Copy, Debug)]
pub struct CatalogPiece<'a> {
    pub id: InventoryItemId,
    pub selection: CatalogPlacement<'a>,
}

#[derive(Clone, Debug)]
pub struct FittedPiece<'a> {
    pub piece: CatalogPiece<'a>,
    pub design: ItemDesign,
    /// Its engraving and trim, applied when its material is plate steel.
    pub decoration: crate::decoration::Decoration,
    /// How it is built, when its material is plate steel.
    pub construction: fabelgeist_armor::Construction,
}

#[derive(Clone, Copy, Debug)]
pub struct DrapedPiece<'a> {
    pub id: InventoryItemId,
    pub selection: &'a GarmentSelection,
    /// The saved drape fitted instead of simulating, for settled cloth.
    pub drape: Option<&'a SettledDrape>,
}

impl Inventory {
    /// The worn articles, or the first reason they cannot be worn together.
    pub fn loadout<'a>(
        &'a self,
        catalog: &'a ItemCatalog,
    ) -> Result<Loadout<'a>, (InventoryItemId, EquipConflict)> {
        self.fit(catalog)?;
        let mut loadout = Loadout::default();
        let mut draped = Vec::new();
        for item in self.worn() {
            let fail = |conflict| (item.id, conflict);
            match &item.article {
                Article::Catalog(article) => {
                    let selection = article.resolve(catalog).map_err(fail)?;
                    if !is_wearable(selection.item().definition()) || selection.surface.is_empty() {
                        return Err(fail(EquipConflict::Invalid(format!(
                            "{} has no generated body surface",
                            selection.item().display_name
                        ))));
                    }
                    let piece = CatalogPiece {
                        id: item.id,
                        selection,
                    };
                    match article
                        .design_for(&catalog.designs, selection)
                        .map_err(fail)?
                    {
                        Some(design) => loadout.fitted.push(FittedPiece {
                            piece,
                            design,
                            decoration: article.decoration.clone(),
                            construction: article.construction.clone(),
                        }),
                        None => loadout.clothing.push(piece),
                    }
                }
                Article::Draped(selection) => {
                    let layer = item.article.occupancy(catalog).map_err(fail)?.layer();
                    draped.push((
                        layer.order(),
                        DrapedPiece {
                            id: item.id,
                            selection,
                            drape: None,
                        },
                    ));
                }
                Article::Settled(garment) => {
                    let layer = item.article.occupancy(catalog).map_err(fail)?.layer();
                    draped.push((
                        layer.order(),
                        DrapedPiece {
                            id: item.id,
                            selection: &garment.selection,
                            drape: Some(&garment.drape),
                        },
                    ));
                }
            }
        }
        draped.sort_by_key(|(layer, _)| *layer);
        loadout.draped = draped.into_iter().map(|(_, piece)| piece).collect();
        Ok(loadout)
    }
}
