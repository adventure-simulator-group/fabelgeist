use super::*;
use adventuresim_tactical_core::scene_coordinates::ScenePlanPoint;

pub(super) fn setup_viewer(
    mut commands: Commands,
    mut sequence: ResMut<CaptureSequence>,
    proportions: Res<CaptureBodyProportions>,
    armor: Res<harness::ArmorCapture>,
) -> Result {
    let default_player = Player::default();
    let mut generator = TerrainGenerator::new(0xA11C_E5E1.into());
    generator.period = 200.0;
    let terrain = generator.generate(100, if sequence.uses_flat_grid() { 0 } else { 30 }, 100)?;
    let Some(height) = sequence.admit_terrain_height(&terrain, ScenePlanPoint::ORIGIN) else {
        return Ok(());
    };
    let Some(position) = sequence.admit_scene_position(Vec3::new(
        0.0,
        height.metres() + CAPTURE_ROOT_GROUND_OFFSET_METRES,
        0.0,
    )) else {
        return Ok(());
    };
    commands.spawn((
        Name::new(if sequence.uses_flat_grid() {
            "Animation review flat-grid scene"
        } else {
            "Animation review hills scene"
        }),
        SceneId("hills".to_owned()),
        SceneEnvironmentFixture::TemperateHills.snapshot("hills"),
        terrain,
        Transform::default(),
    ));

    let subject = commands
        .spawn((
            Name::new(default_player.name),
            CaptureSubject,
            Player::default(),
            CharacterId(default_tactical_character_id()),
            CharacterLook::default(),
            SkeletonState::default(),
            Transform::from_translation(position.metres()),
            Collider::cylinder(0.4, 1.9),
            CollisionMargin(0.01),
            tactical_character_controller(),
        ))
        .id();
    armor.spawn(&mut commands, subject);
    if let Some(proportions) = proportions.0 {
        commands.entity(subject).insert(
            crate::animation::skeletal_proportions::CharacterSkeletalProportions(proportions),
        );
    }
    commands.spawn((
        Name::new("Animation review fill light"),
        DirectionalLight {
            illuminance: 35_000.0,
            shadow_maps_enabled: false,
            ..default()
        },
        Transform::from_xyz(8.0, 12.0, -8.0).looking_at(Vec3::ZERO, Vec3::Y),
    ));
    commands.spawn((
        CaptureLabel,
        Text::new("Loading authored animation rig..."),
        TextFont::from_font_size(22.0),
        TextColor(Color::WHITE),
        Node {
            position_type: PositionType::Absolute,
            top: px(16),
            left: px(16),
            ..default()
        },
    ));
    Ok(())
}

pub(super) fn write_body_proportions(
    output: &std::path::Path,
    explicit: Option<adventuresim_core::character_proportions::CharacterProportions>,
) {
    let proportions = explicit.unwrap_or_else(|| {
        adventuresim_core::character_proportions::CharacterProportions::from_seed(
            fabelgeist_determinism::Seed::from_u64(default_tactical_character_id()),
        )
    });
    fs::write(
        output.join("body-proportions.json"),
        serde_json::to_vec_pretty(&proportions).expect("finite body proportions"),
    )
    .expect("write captured body proportions");
}
