//! Clips semantic city patches to the terrain renderer's own triangle lattice.

use super::*;

const SURFACE_LIFT_METRES: f32 = 0.006;
const SURFACE_PRIORITY_LIFT_METRES: f32 = 0.001;
const MARKET_PRIORITY_LIFT_METRES: f32 = 0.002;
const YARD_SURFACE_LIFT_METRES: f32 = 0.003;

#[derive(Default)]
pub(super) struct CitySurfaceMeshBuilder {
    chunks: std::collections::BTreeMap<traffic::TrafficTile, SurfaceVertices>,
}

#[derive(Clone, Default, serde::Serialize, serde::Deserialize)]
pub(super) struct SurfaceVertices {
    #[serde(with = "adventuresim_tactical_core::geometry_transport::binary")]
    positions: Vec<[f32; 3]>,
    #[serde(with = "adventuresim_tactical_core::geometry_transport::binary")]
    normals: Vec<[f32; 3]>,
    #[serde(with = "adventuresim_tactical_core::geometry_transport::binary")]
    uvs: Vec<[f32; 2]>,
    #[serde(with = "adventuresim_tactical_core::geometry_transport::binary")]
    footprints: Vec<[f32; 4]>,
    #[serde(with = "adventuresim_tactical_core::geometry_transport::binary")]
    activities: Vec<[f32; 2]>,
}

struct SurfacePatch {
    corners: [Vec2; 4],
    lift_metres: f32,
    kind: PatchKind,
}

#[derive(Clone, Copy)]
#[repr(u8)]
enum PatchKind {
    Corridor,
    Market,
    Yard,
}

impl CitySurfaceMeshBuilder {
    pub(super) fn append_street(
        &mut self,
        street: CityStreetPatch,
        support: &GroundSupport,
        groups: &partition::SpatialIndex<'_, FurnitureGroup>,
    ) {
        let lift_metres = SURFACE_LIFT_METRES
            + f32::from(street.surface().priority()) * SURFACE_PRIORITY_LIFT_METRES;
        let patch = match street {
            CityStreetPatch::Corridor {
                start_metres,
                end_metres,
                half_width_metres,
                ..
            } => {
                let tangent = (end_metres - start_metres).normalize();
                let normal = Vec2::new(-tangent.y, tangent.x) * half_width_metres;
                SurfacePatch {
                    corners: [
                        start_metres - normal,
                        start_metres + normal,
                        end_metres + normal,
                        end_metres - normal,
                    ],
                    lift_metres,
                    kind: PatchKind::Corridor,
                }
            }
            CityStreetPatch::Market { corners_metres, .. } => SurfacePatch {
                corners: corners_metres,
                // The plaza owns crossing wear above the streets beneath it.
                lift_metres: lift_metres + MARKET_PRIORITY_LIFT_METRES,
                kind: PatchKind::Market,
            },
        };
        self.append(patch, &[], support, groups);
    }

    pub(super) fn append_yard(
        &mut self,
        yard: CityYardPatch,
        beds: &partition::SpatialIndex<'_, [Vec2; 4]>,
        support: &GroundSupport,
        groups: &partition::SpatialIndex<'_, FurnitureGroup>,
    ) {
        let exclusions = beds
            .candidates(yard.corners_metres)
            .into_iter()
            .copied()
            .filter(|bed| {
                yard.surface == CityYardSurface::PackedEarth
                    && partition::overlaps(yard.corners_metres, *bed)
            })
            .collect::<Vec<_>>();
        self.append(
            SurfacePatch {
                corners: yard.corners_metres,
                lift_metres: YARD_SURFACE_LIFT_METRES,
                kind: PatchKind::Yard,
            },
            &exclusions,
            support,
            groups,
        );
    }

    fn append(
        &mut self,
        patch: SurfacePatch,
        exclusions: &[[Vec2; 4]],
        support: &GroundSupport,
        groups: &partition::SpatialIndex<'_, FurnitureGroup>,
    ) {
        let [a, b, c, d] = patch.corners;
        let width = a.distance(b).max(d.distance(c));
        let depth = a.distance(d).max(b.distance(c));
        let activity = activity::ActivityWear::for_patch(patch.corners, groups);
        support.clip(patch.corners, |triangle| {
            let plane_normal = (triangle[1] - triangle[0]).cross(triangle[2] - triangle[0]);
            let normal = plane_normal.normalize().as_vec3();
            let minimum = triangle
                .map(|p| p.xz().as_vec2())
                .into_iter()
                .fold(Vec2::splat(f32::INFINITY), Vec2::min);
            let maximum = triangle
                .map(|p| p.xz().as_vec2())
                .into_iter()
                .fold(Vec2::splat(f32::NEG_INFINITY), Vec2::max);
            for polygon in partition::subtract(triangle.to_vec(), exclusions) {
                for tile in traffic::TrafficTile::covering(minimum, maximum) {
                    let polygon = support::clip_polygon(polygon.clone(), tile.corners());
                    for index in 1..polygon.len().saturating_sub(1) {
                        let clipped = [polygon[0], polygon[index], polygon[index + 1]];
                        if (clipped[1] - clipped[0])
                            .cross(clipped[2] - clipped[0])
                            .length_squared()
                            == 0.0
                        {
                            continue;
                        }
                        let vertices = self.chunks.entry(tile).or_default();
                        for point in clipped {
                            // Represent the completed intersection once. Its Y
                            // follows the same physical plane at the final X/Z,
                            // rather than at a pre-rounded intermediate point.
                            let mut point = point.as_vec3();
                            let anchor = triangle[0];
                            point.y = (anchor.y
                                - (plane_normal.x * (f64::from(point.x) - anchor.x)
                                    + plane_normal.z * (f64::from(point.z) - anchor.z))
                                    / plane_normal.y) as f32;
                            let uv = support::footprint_uv(patch.corners, point.xz());
                            vertices.uvs.push(uv.to_array());
                            vertices.activities.push(activity.at(point.xz()).to_array());
                            vertices.footprints.push([
                                width,
                                depth,
                                f32::from(patch.kind as u8),
                                1.0,
                            ]);
                            point.y += patch.lift_metres;
                            vertices.positions.push(point.to_array());
                            vertices.normals.push(normal.to_array());
                        }
                    }
                }
            }
        });
    }

    pub(super) fn into_vertices(
        self,
    ) -> impl Iterator<Item = (traffic::TrafficTile, SurfaceVertices)> {
        self.chunks.into_iter()
    }

    #[cfg(test)]
    pub(super) fn build(self) -> impl Iterator<Item = (traffic::TrafficTile, Mesh)> {
        self.chunks
            .into_iter()
            .map(|(tile, vertices)| (tile, vertices.build()))
    }
}

impl SurfaceVertices {
    pub(super) fn build(self) -> Mesh {
        let mut mesh = Mesh::new(
            PrimitiveTopology::TriangleList,
            RenderAssetUsages::RENDER_WORLD,
        );
        mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, self.normals);
        mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, self.positions);
        mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, self.uvs);
        mesh.insert_attribute(Mesh::ATTRIBUTE_UV_1, self.activities);
        // RGB encodes physical patch dimensions and shape, not a vertex tint.
        mesh.insert_attribute(Mesh::ATTRIBUTE_COLOR, self.footprints);
        mesh
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn empty_groups() -> partition::SpatialIndex<'static, FurnitureGroup> {
        partition::SpatialIndex::new(&[], |group| partition::bounds(group.footprint.corners()))
    }

    #[test]
    fn short_surveyed_street_segment_has_finite_nonempty_ground_triangles() {
        let terrain = SceneTerrain::new(12, 12, 1.0, |_| 0.0).unwrap();
        let mut support = GroundSupport::default();
        support.add_mesh(&terrain.mesh(), Vec3::ZERO);
        let mut builder = CitySurfaceMeshBuilder::default();
        let groups = empty_groups();
        builder.append_street(
            CityStreetPatch::Corridor {
                start_metres: Vec2::ZERO,
                end_metres: Vec2::new(0.5, 0.01),
                half_width_metres: 3.5,
                surface: CityStreetSurface::Fieldstone,
            },
            &support,
            &groups,
        );
        assert!(!builder.chunks.is_empty());
        for vertices in builder.chunks.values() {
            assert!(vertices.positions.iter().flatten().all(|v| v.is_finite()));
            assert!(
                vertices
                    .positions
                    .as_chunks::<3>()
                    .0
                    .iter()
                    .all(|triangle| {
                        let [a, b, c] = triangle.map(Vec3::from_array);
                        (b - a).cross(c - a).length_squared() > 0.0
                    })
            );
        }
    }

    #[test]
    fn clipped_road_clears_spikes_and_true_terrain_diagonals_at_triangle_interiors() {
        let terrain = SceneTerrain::new(12, 12, 1.0, |point| {
            if point.x == 6.0 && point.y == 6.0 {
                0.4
            } else {
                point.x * 0.013 + point.y * 0.007
            }
        })
        .unwrap();
        let mut support = GroundSupport::default();
        support.add_mesh(&terrain.mesh(), Vec3::ZERO);
        let groups = empty_groups();
        for reverse in [false, true] {
            let mut corners = [
                Vec2::new(-4.1, -3.2),
                Vec2::new(3.3, -4.0),
                Vec2::new(4.2, 3.7),
                Vec2::new(-3.8, 4.1),
            ];
            if reverse {
                corners.reverse();
            }
            let mut builder = CitySurfaceMeshBuilder::default();
            builder.append_street(
                CityStreetPatch::Market {
                    corners_metres: corners,
                    surface: CityStreetSurface::Fieldstone,
                },
                &support,
                &groups,
            );
            assert!(!builder.chunks.is_empty());
            for vertices in builder.chunks.values() {
                for points in vertices.positions.as_chunks::<3>().0 {
                    let [a, b, c] = [points[0], points[1], points[2]].map(Vec3::from_array);
                    assert!((b - a).cross(c - a).y > 0.0);
                    // Several interior barycentric probes catch missing spikes
                    // and the wrong diagonal, rather than just testing vertices.
                    for weights in [
                        Vec3::splat(1.0 / 3.0),
                        Vec3::new(0.1, 0.3, 0.6),
                        Vec3::new(0.6, 0.1, 0.3),
                    ] {
                        let point = a * weights.x + b * weights.y + c * weights.z;
                        let clearance = point.y - terrain.height_at(adventuresim_tactical_core::scene_coordinates::ScenePlanPoint::from_metres(point.xz()).unwrap()).unwrap().metres();
                        assert!(
                            (clearance - 0.01).abs() < 0.0001,
                            "clearance {clearance} at {point:?}"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn absent_source_terrain_cannot_create_default_height_geometry() {
        let terrain = SceneTerrain::new(8, 8, 1.0, |_| 7.0).unwrap();
        let mut support = GroundSupport::default();
        support.add_mesh(&terrain.mesh(), Vec3::ZERO);
        let mut builder = CitySurfaceMeshBuilder::default();
        let groups = empty_groups();
        builder.append_street(
            CityStreetPatch::Corridor {
                start_metres: Vec2::new(-12.0, 0.0),
                end_metres: Vec2::new(12.0, 0.0),
                half_width_metres: 2.0,
                surface: CityStreetSurface::Fieldstone,
            },
            &support,
            &groups,
        );
        assert!(!builder.chunks.is_empty());
        assert!(
            builder
                .chunks
                .values()
                .flat_map(|v| &v.positions)
                .all(|point| point[1] > 7.0 && point[0].abs() <= 4.0001)
        );
    }
}

#[cfg(test)]
mod grounding_tests;
