use super::*;
use adventuresim_tactical_core::prelude::SceneEnvironmentFixture;

#[test]
fn autumn_woodland_fixture_contains_ground_fruiting_fungi() {
    let input = adventuresim_tactical_core::scene_input::TacticalSceneInput::load(
        std::path::Path::new(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../assets/tactical-scenes/fungi-woodland.json"
        )),
    )
    .unwrap();
    let scene = input.generate().unwrap();
    let environment = input.environment_snapshot(scene.digest.clone());
    let seed = stable_text_seed("fungi-woodland")
        .xor_word(stable_text_seed(&environment.scene_digest).to_u64())
        .xor_word(PLANT_SEED.to_u64());
    let sites = placements(&scene.terrain, &scene.ground, &environment, seed).unwrap();
    assert!(!sites.is_empty());
    for species in adventuresim_plant_generator::fungus::FungusSpecies::ALL {
        assert!(
            sites
                .iter()
                .any(|site| site.species == PlantSpecies::Fungus(species)),
            "missing {species:?}"
        );
    }
}

#[test]
fn seasonal_catalog_shares_population_budget_and_preserves_spring_flowers() {
    let terrain = SceneTerrain::from_heightmap(65, 65, 2.0, vec![0.0; 65 * 65]).unwrap();
    let ground = SceneGround::from_samples(
        65,
        65,
        2.0,
        vec![
            GroundSurface {
                substrate: GroundSubstrate::Soil,
                cover: GroundCover::LeafLitter,
                cover_density_bps: 9000,
                cover_height_cm: 4
            };
            65 * 65
        ],
    )
    .unwrap();
    let mut environment =
        SceneEnvironmentFixture::TemperateHills.snapshot("seasonal-botanical-budget");
    environment.canopy_bps = 6500;
    environment.cultivation_bps = 0;
    environment.weather.ground_moisture_bps = 7000;
    environment.absolute_minute =
        adventuresim_world_schema::calendar::StrategicMinute::day_start_for_index(110);
    let spring = placements(
        &terrain,
        &ground,
        &environment,
        fabelgeist_determinism::Seed::from_u64(42),
    )
    .unwrap();
    assert_eq!(spring.len(), MAX_SPECIMENS);
    assert!(
        spring
            .iter()
            .all(|s| matches!(s.species, PlantSpecies::Flower(_)))
    );
    environment.absolute_minute =
        adventuresim_world_schema::calendar::StrategicMinute::day_start_for_index(270);
    let autumn = placements(
        &terrain,
        &ground,
        &environment,
        fabelgeist_determinism::Seed::from_u64(42),
    )
    .unwrap();
    assert_eq!(autumn.len(), MAX_SPECIMENS);
    assert!(
        autumn
            .iter()
            .all(|s| matches!(s.species, PlantSpecies::Fungus(_)))
    );
    for species in adventuresim_plant_generator::fungus::FungusSpecies::ALL {
        assert!(
            autumn
                .iter()
                .any(|s| s.species == PlantSpecies::Fungus(species))
        );
    }
}

#[test]
fn spring_woodland_fixture_has_suitable_flower_openings() {
    let input = adventuresim_tactical_core::scene_input::TacticalSceneInput::load(
        std::path::Path::new(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../assets/tactical-scenes/flower-woodland-edge.json"
        )),
    )
    .unwrap();
    let scene = input.generate().unwrap();
    let environment = input.environment_snapshot(scene.digest.clone());
    let sites = placements(
        &scene.terrain,
        &scene.ground,
        &environment,
        fabelgeist_determinism::Seed::from_u64(42),
    )
    .unwrap();
    let litter = scene
        .ground
        .samples()
        .iter()
        .filter(|s| s.cover == GroundCover::LeafLitter)
        .count();
    assert!(
        !sites.is_empty(),
        "litter={litter}; environment={environment:?}; obstacles={}",
        scene.obstacles.len()
    );
}

#[test]
fn placement_is_repeatable_bounded_grounded_and_excludes_roads_water_and_winter() {
    let terrain = SceneTerrain::from_heightmap(65, 65, 2.0, vec![2.0; 65 * 65]).unwrap();
    let make_ground = |substrate| {
        SceneGround::from_samples(
            65,
            65,
            2.0,
            vec![
                GroundSurface {
                    substrate,
                    ..default()
                };
                65 * 65
            ],
        )
        .unwrap()
    };
    let mut environment = SceneEnvironmentFixture::TemperateHills.snapshot("plant-placement");
    environment.absolute_minute =
        adventuresim_world_schema::calendar::StrategicMinute::day_start_for_index(180);
    environment.weather.ground_moisture_bps = 5000;
    let ground = make_ground(GroundSubstrate::Soil);
    let sites = placements(
        &terrain,
        &ground,
        &environment,
        fabelgeist_determinism::Seed::from_u64(42),
    )
    .unwrap();
    assert!(!sites.is_empty());
    assert!(sites.len() <= MAX_SPECIMENS);
    assert_eq!(
        sites,
        placements(
            &terrain,
            &ground,
            &environment,
            fabelgeist_determinism::Seed::from_u64(42)
        )
        .unwrap()
    );
    assert!(
        sites
            .iter()
            .all(|s| (s.root.metres().y - (2.0 - ROOT_EMBED_METRES)).abs() < 0.0001)
    );
    assert!(sites.iter().any(|s| s.root.metres().x > 0.0));
    assert!(sites.iter().any(|s| s.root.metres().x < 0.0));
    let dense_sward = SceneGround::from_samples(
        65,
        65,
        2.0,
        vec![
            GroundSurface {
                substrate: GroundSubstrate::Soil,
                cover: GroundCover::TallGrass,
                cover_density_bps: 10000,
                cover_height_cm: 82,
            };
            65 * 65
        ],
    )
    .unwrap();
    assert!(
        placements(
            &terrain,
            &dense_sward,
            &environment,
            fabelgeist_determinism::Seed::from_u64(42)
        )
        .unwrap()
        .is_empty(),
        "dense tall grass has no low-herb openings"
    );
    for substrate in [
        GroundSubstrate::Water,
        GroundSubstrate::Road,
        GroundSubstrate::Stone,
    ] {
        assert!(
            placements(
                &terrain,
                &make_ground(substrate),
                &environment,
                fabelgeist_determinism::Seed::from_u64(42)
            )
            .unwrap()
            .is_empty()
        );
    }
    environment.absolute_minute =
        adventuresim_world_schema::calendar::StrategicMinute::day_start_for_index(10);
    assert!(
        placements(
            &terrain,
            &ground,
            &environment,
            fabelgeist_determinism::Seed::from_u64(42)
        )
        .unwrap()
        .is_empty()
    );
}

#[test]
fn scene_plugin_spawns_batches_and_is_idempotent() {
    let mut app = App::new();
    app.add_plugins(MinimalPlugins)
        .init_resource::<Assets<Mesh>>()
        .init_resource::<Assets<StandardMaterial>>()
        .add_plugins(PlantPresentationPlugin);
    let mut environment = SceneEnvironmentFixture::TemperateHills.snapshot("plant-ecs");
    environment.absolute_minute =
        adventuresim_world_schema::calendar::StrategicMinute::day_start_for_index(180);
    let entity = app
        .world_mut()
        .spawn((
            SceneId("plant-ecs".into()),
            SceneTerrain::from_heightmap(17, 17, 2.0, vec![0.0; 17 * 17]).unwrap(),
            SceneGround::from_samples(17, 17, 2.0, vec![GroundSurface::default(); 17 * 17])
                .unwrap(),
            environment,
        ))
        .id();
    app.update();
    let count = app
        .world_mut()
        .query_filtered::<Entity, With<Mesh3d>>()
        .iter(app.world())
        .count();
    assert!(count > 0);
    assert_eq!(app.world().resource::<Assets<Mesh>>().len(), 27);
    assert_eq!(app.world().resource::<Assets<StandardMaterial>>().len(), 1);
    let mut groups = std::collections::BTreeMap::new();
    let world = app.world_mut();
    let mut query = world.query::<(
        &lod::PlantLodInstance,
        &Transform,
        &bevy::camera::primitives::Aabb,
        &bevy::camera::visibility::VisibilityRange,
    )>();
    for (instance, transform, bounds, range) in query.iter(world) {
        assert!(*range == instance.range());
        let key = transform.translation.to_array().map(f32::to_bits);
        groups
            .entry(key)
            .or_insert_with(Vec::new)
            .push((*instance, *transform, *bounds));
    }
    assert_eq!(groups.len() * 3, count);
    for group in groups.values() {
        assert_eq!(group.len(), 3);
        for (instance, transform, bounds) in group {
            assert_eq!(instance.species, group[0].0.species);
            assert_eq!(*transform, group[0].1);
            assert_eq!(bounds.center, group[0].2.center);
            assert_eq!(bounds.half_extents, group[0].2.half_extents);
        }
        let mut levels = group.iter().map(|g| g.0.level.index()).collect::<Vec<_>>();
        levels.sort_unstable();
        assert_eq!(levels, [0, 1, 2]);
    }
    assert!(
        !app.world()
            .get::<PlantCaptureAnchors>(entity)
            .unwrap()
            .0
            .is_empty()
    );
    app.update();
    assert_eq!(
        count,
        app.world_mut()
            .query_filtered::<Entity, With<Mesh3d>>()
            .iter(app.world())
            .count()
    );
}
