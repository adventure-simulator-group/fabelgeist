use adventuresim_tactical_core::prelude::{
    GroundCover, GroundSubstrate, GroundSurface, SceneGround, SceneTerrain,
};
use adventuresim_tactical_core::scene_coordinates::ScenePlanPoint;
use bevy::prelude::Vec2;
use fabelgeist_determinism::Seed;

mod streams;

#[derive(Clone, Copy, Debug)]
pub(super) struct UnderstoryHabitat {
    pub(super) canopy: f32,
    pub(super) wetland: f32,
    pub(super) cultivation: f32,
    pub(super) moisture: f32,
}

/// One shrub site produced by the shared placement walk, consumed by both
/// the legacy per-entity renderer and the instanced batches.
pub(super) struct ShrubPlacement {
    pub(super) species: UnderstorySpecies,
    pub(super) point: ScenePlanPoint,
    pub(super) hash: Seed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum UnderstorySpecies {
    CommonHazel,
    Blackthorn,
    CommonHawthorn,
}

pub(super) fn select_species(hash: Seed, habitat: UnderstoryHabitat) -> UnderstorySpecies {
    // This temporary habitat model intentionally uses only scene data already
    // available to the client. Hazel favors shaded, mesic woodland; blackthorn
    // favors brighter, drier scrub; hawthorn gains weight at open/cultivated
    // edges. A later world-data source can replace these weights without
    // changing species geometry or scatter identity.
    let dry = 1.0 - habitat.moisture;
    let open = 1.0 - habitat.canopy;
    let hazel = 0.25 + habitat.canopy * 1.55 + habitat.moisture * 0.35;
    let blackthorn = (0.2 + open * 0.82 + dry * 0.34 + habitat.cultivation * 0.22)
        * (1.0 - habitat.wetland * 0.55);
    let hawthorn =
        (0.24 + open * 0.48 + habitat.cultivation * 0.88) * (1.0 - habitat.wetland * 0.38);
    let weights = [hazel, blackthorn, hawthorn].map(|weight| {
        (weight * f32::from(adventuresim_world_schema::BASIS_POINTS_PER_WHOLE)).round() as u64
    });
    let index = streams::SPECIES
        .rng(hash, &[])
        .weighted_index(&weights)
        .expect("habitat base weights are positive and bounded");
    [
        UnderstorySpecies::CommonHazel,
        UnderstorySpecies::Blackthorn,
        UnderstorySpecies::CommonHawthorn,
    ][index]
}

/// Deterministic shrub placement walk shared by both renderers, so the
/// instanced path reproduces the legacy thickets exactly.
pub(super) fn placements(
    terrain: &SceneTerrain,
    ground: &SceneGround,
    base_seed: Seed,
    chance: f32,
    habitat: UnderstoryHabitat,
) -> Vec<ShrubPlacement> {
    let spacing = 3.2;
    let count_x = (terrain.width() / spacing).floor() as i32;
    let count_z = (terrain.depth() / spacing).floor() as i32;
    let half_x = terrain.width() * 0.5;
    let half_z = terrain.depth() * 0.5;
    let mut sites = Vec::new();
    for z in 0..count_z {
        for x in 0..count_x {
            let hash = streams::SPECIMEN.seed(base_seed, &[x as u32 as u64, z as u32 as u64]);
            let community = community_hash(base_seed, x, z);
            let local_chance = (chance * community_density_multiplier(community)).min(0.82);
            if streams::PRESENCE.rng(hash, &[]).inclusive_unit_f32() >= local_chance {
                continue;
            }
            let jitter_x = streams::JITTER_X.rng(hash, &[]).inclusive_unit_f32() - 0.5;
            let jitter_z = streams::JITTER_Z.rng(hash, &[]).inclusive_unit_f32() - 0.5;
            let world_x = -half_x + (x as f32 + 0.5 + jitter_x * 0.72) * spacing;
            let world_z = -half_z + (z as f32 + 0.5 + jitter_z * 0.72) * spacing;
            let Some(point) = ScenePlanPoint::from_metres(Vec2::new(world_x, world_z)) else {
                continue;
            };
            let species = select_species(community, habitat);
            if ground
                .ground_at(point)
                .is_none_or(|sample| !ground_allows_species(sample, species))
            {
                continue;
            }
            sites.push(ShrubPlacement {
                species,
                point,
                hash,
            });
        }
    }
    sites
}

fn community_hash(base_seed: Seed, x: i32, z: i32) -> Seed {
    // Four-by-four lattice communities produce roughly 13-metre thickets.
    // Species identity varies between communities, while each specimen keeps
    // its independent placement/rotation hash within the selected thicket.
    let community_x = x.div_euclid(4);
    let community_z = z.div_euclid(4);
    streams::COMMUNITY.seed(
        base_seed,
        &[community_x as u32 as u64, community_z as u32 as u64],
    )
}

fn community_density_multiplier(hash: Seed) -> f32 {
    // Concentrate the same approximate population into legible thickets.
    // Dense cores, loose margins, and mostly open cells keep shrubs from
    // reading as evenly-spaced miniature trees across the whole landscape.
    let structure = streams::COMMUNITY_STRUCTURE
        .rng(hash, &[])
        .inclusive_unit_f32();
    if structure < 0.25 {
        2.5
    } else if structure < 0.60 {
        1.0
    } else {
        0.15
    }
}

fn ground_allows_species(surface: GroundSurface, species: UnderstorySpecies) -> bool {
    if surface.substrate == GroundSubstrate::Water
        || surface.cover == GroundCover::Reeds
        || (surface.cover == GroundCover::Bare && surface.cover_density_bps == 0)
    {
        return false;
    }
    match surface.cover {
        // Hazel is a normal woodland-floor shrub, and hawthorn can enter
        // brighter gaps. Blackthorn remains biased to open scrub and edges.
        GroundCover::LeafLitter => species != UnderstorySpecies::Blackthorn,
        GroundCover::LooseStone => false,
        GroundCover::Bare | GroundCover::TallGrass => true,
        GroundCover::Reeds => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::presentation::obstacles::tree::{
        BLACKTHORN_PARAMETERS, COMMON_HAWTHORN_PARAMETERS, COMMON_HAZEL_PARAMETERS,
        procedural_oak_leaf_card_mesh, procedural_woody_plant_leaves,
        procedural_woody_plant_skeleton, procedural_woody_sparse_leaf_card_mesh,
    };
    use bevy::prelude::Mesh;

    #[test]
    fn understory_species_form_coherent_four_by_four_communities() {
        let seed = fabelgeist_determinism::Seed::from_u64(42);
        let habitat = UnderstoryHabitat {
            canopy: 0.45,
            wetland: 0.08,
            cultivation: 0.12,
            moisture: 0.55,
        };
        let expected = select_species(community_hash(seed, 0, 0), habitat);
        for z in 0..4 {
            for x in 0..4 {
                assert_eq!(
                    select_species(community_hash(seed, x, z), habitat),
                    expected
                );
            }
        }
        assert_ne!(community_hash(seed, 0, 0), community_hash(seed, 4, 0));
    }

    #[test]
    fn shrub_communities_include_dense_thickets_and_open_relief() {
        let mut dense = 0;
        let mut open = 0;
        let mut mean = 0.0;
        for cell in 0..4_096_u64 {
            let multiplier =
                community_density_multiplier(streams::TEST_COMMUNITY.seed(cell.into(), &[]));
            dense += usize::from(multiplier > 2.0);
            open += usize::from(multiplier < 0.2);
            mean += multiplier;
        }
        mean /= 4_096.0;
        assert!(dense > 800);
        assert!(open > 1_300);
        assert!((mean - 1.0).abs() < 0.08);
    }

    #[test]
    fn habitat_weights_shift_species_composition_without_excluding_any_preset() {
        let count = |habitat, species| {
            (0..4_096_u64)
                .filter(|seed| {
                    select_species(streams::TEST_SPECIES.seed((*seed).into(), &[]), habitat)
                        == species
                })
                .count()
        };
        let shaded = UnderstoryHabitat {
            canopy: 0.9,
            wetland: 0.05,
            cultivation: 0.0,
            moisture: 0.7,
        };
        let open_edge = UnderstoryHabitat {
            canopy: 0.1,
            wetland: 0.02,
            cultivation: 0.65,
            moisture: 0.35,
        };
        assert!(
            count(shaded, UnderstorySpecies::CommonHazel)
                > count(open_edge, UnderstorySpecies::CommonHazel)
        );
        assert!(
            count(open_edge, UnderstorySpecies::CommonHawthorn)
                > count(shaded, UnderstorySpecies::CommonHawthorn)
        );
        for species in [
            UnderstorySpecies::CommonHazel,
            UnderstorySpecies::Blackthorn,
            UnderstorySpecies::CommonHawthorn,
        ] {
            assert!(count(open_edge, species) > 0);
        }
    }

    #[test]
    fn managed_bare_ground_excludes_every_wild_shrub_species() {
        for species in [
            UnderstorySpecies::CommonHazel,
            UnderstorySpecies::Blackthorn,
            UnderstorySpecies::CommonHawthorn,
        ] {
            assert!(!ground_allows_species(
                GroundSurface {
                    substrate: GroundSubstrate::Soil,
                    cover: GroundCover::Bare,
                    cover_density_bps: 0,
                    cover_height_cm: 0,
                },
                species
            ));
        }
    }

    #[test]
    fn woodland_leaf_litter_accepts_hazel_and_gap_hawthorn_but_not_blackthorn() {
        let litter = GroundSurface {
            substrate: GroundSubstrate::Soil,
            cover: GroundCover::LeafLitter,
            ..GroundSurface::default()
        };
        assert!(ground_allows_species(
            litter,
            UnderstorySpecies::CommonHazel
        ));
        assert!(ground_allows_species(
            litter,
            UnderstorySpecies::CommonHawthorn
        ));
        assert!(!ground_allows_species(
            litter,
            UnderstorySpecies::Blackthorn
        ));
        assert!(!ground_allows_species(
            GroundSurface {
                substrate: GroundSubstrate::Water,
                ..GroundSurface::default()
            },
            UnderstorySpecies::CommonHazel
        ));
    }

    #[test]
    fn minimal_shrub_cards_pin_the_per_species_geometry_budget() {
        let mut budgets = Vec::new();
        for parameters in [
            COMMON_HAZEL_PARAMETERS,
            BLACKTHORN_PARAMETERS,
            COMMON_HAWTHORN_PARAMETERS,
        ] {
            let branches = procedural_woody_plant_skeleton(
                fabelgeist_determinism::Seed::from_u64(42),
                0.0,
                parameters,
            );
            let leaves = procedural_woody_plant_leaves(
                fabelgeist_determinism::Seed::from_u64(42),
                &branches,
                0.0,
                parameters,
            );
            let full = procedural_oak_leaf_card_mesh(&leaves);
            let sparse = procedural_woody_sparse_leaf_card_mesh(&leaves);
            budgets.push((
                full.count_vertices(),
                full.indices().unwrap().len() / 3,
                sparse.count_vertices(),
                sparse.indices().unwrap().len() / 3,
            ));
            assert!(sparse.count_vertices() * 3 <= full.count_vertices());
        }

        assert_eq!(
            budgets,
            vec![
                // full vertices, full triangles, sparse vertices, sparse triangles
                (19_800, 9_900, 4_960, 2_480),
                (21_780, 10_890, 5_400, 2_700),
                (11_880, 5_940, 2_944, 1_472),
            ]
        );
    }

    #[test]
    fn minimal_shrub_cards_are_deterministic_when_source_order_changes() {
        let branches = procedural_woody_plant_skeleton(
            fabelgeist_determinism::Seed::from_u64(42),
            0.0,
            COMMON_HAZEL_PARAMETERS,
        );
        let leaves = procedural_woody_plant_leaves(
            fabelgeist_determinism::Seed::from_u64(42),
            &branches,
            0.0,
            COMMON_HAZEL_PARAMETERS,
        );
        let first = procedural_woody_sparse_leaf_card_mesh(&leaves);
        let mut reordered = leaves;
        reordered.reverse();
        let repeated = procedural_woody_sparse_leaf_card_mesh(&reordered);

        assert_eq!(first.count_vertices(), repeated.count_vertices());
        assert_eq!(first.indices(), repeated.indices());
        assert_eq!(
            first.attribute(Mesh::ATTRIBUTE_POSITION),
            repeated.attribute(Mesh::ATTRIBUTE_POSITION)
        );
        assert_eq!(
            first.attribute(Mesh::ATTRIBUTE_COLOR),
            repeated.attribute(Mesh::ATTRIBUTE_COLOR)
        );
    }
}
