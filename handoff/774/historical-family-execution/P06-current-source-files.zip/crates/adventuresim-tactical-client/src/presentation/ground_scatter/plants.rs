//! Habitat-filtered, instanced botanical meshes shared with Plant Studio.
use super::{GroundScatterLayer, scatter_ground_without_patch};
use crate::presentation::{bps, stable_text_seed};
use adventuresim_building_generator::spatial_geometry::{GeometryResult, Position};
use adventuresim_plant_generator::{
    PlantSpecies,
    habitat::{PlantGround, PlantHabitat},
};
use adventuresim_tactical_core::prelude::{
    GroundCover, GroundSubstrate, GroundSurface, SceneEnvironment, SceneGround, SceneId,
    SceneTerrain, TerrainLandformRecipe,
};
use adventuresim_tactical_core::scene_coordinates::{Scene, ScenePlanPoint};
use adventuresim_world_schema::calendar::StrategicMinute;
use bevy::prelude::*;
use fabelgeist_determinism::Seed;
pub(crate) use lod::PlantLodInstance;
use lod::SpecimenCache;

mod lod;
mod streams;

const SITE_SPACING_METRES: f32 = 2.0;
const MAX_SPECIMENS: usize = 512;
const MIN_SLOPE_NORMAL_Y: f32 = 0.8;
const ROOT_EMBED_METRES: f32 = 0.002;
const OCCUPANCY: f32 = 0.32;
const PLANT_SEED: Seed = Seed::from_u64(0x504c_414e_5453);

type NewPlantScenes<'w, 's> = Query<
    'w,
    's,
    (
        Entity,
        &'static SceneId,
        &'static SceneTerrain,
        &'static SceneGround,
        &'static SceneEnvironment,
        Option<&'static TerrainLandformRecipe>,
    ),
    Without<PlantsPresented>,
>;

pub(in crate::presentation) struct PlantPresentationPlugin;
#[derive(Component)]
struct PlantsPresented;
/// Actual production roots retained for capture framing and placement diagnostics.
#[derive(Component)]
pub(crate) struct PlantCaptureAnchors(pub Vec<PlantCaptureAnchor>);
#[derive(Clone, Copy)]
pub(crate) struct PlantCaptureAnchor {
    pub root: Position<Scene>,
    pub species: PlantSpecies,
}
#[derive(Debug, PartialEq)]
struct PlantSite {
    root: Position<Scene>,
    species: PlantSpecies,
    hash: Seed,
}

impl Plugin for PlantPresentationPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<SpecimenCache>()
            .add_systems(Update, present);
    }
}

fn present(
    mut commands: Commands,
    scenes: NewPlantScenes,
    mut cache: ResMut<SpecimenCache>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    for (entity, id, terrain, ground, environment, landform) in &scenes {
        let masked = landform.map(|l| scatter_ground_without_patch(ground, l.transition_collar()));
        let ground = masked.as_ref().unwrap_or(ground);
        let seed = stable_text_seed(&id.0)
            .xor_word(stable_text_seed(&environment.scene_digest).to_u64())
            .xor_word(PLANT_SEED.to_u64());
        let sites = match placements(terrain, ground, environment, seed) {
            Ok(sites) => sites,
            Err(error) => {
                warn!(%error, ?entity, "Invalid botanical ground mask");
                continue;
            }
        };
        cache.prepare(&mut meshes, &mut materials);
        let mut anchors = Vec::new();
        for site in sites {
            let transform = Transform::from_translation(site.root.metres())
                .with_rotation(Quat::from_rotation_y(
                    streams::YAW.rng(site.hash, &[]).inclusive_unit_f32() * std::f32::consts::TAU,
                ))
                .with_scale(Vec3::splat(
                    0.85 + streams::SCALE.rng(site.hash, &[]).inclusive_unit_f32() * 0.3,
                ));
            cache.spawn(&mut commands, site.species, transform);
            anchors.push(PlantCaptureAnchor {
                root: site.root,
                species: site.species,
            });
        }
        commands
            .entity(entity)
            .insert((PlantsPresented, PlantCaptureAnchors(anchors)));
    }
}

fn placements(
    terrain: &SceneTerrain,
    ground: &SceneGround,
    environment: &SceneEnvironment,
    seed: Seed,
) -> GeometryResult<Vec<PlantSite>> {
    let count_x = (terrain.width() / SITE_SPACING_METRES).floor() as i32;
    let count_z = (terrain.depth() / SITE_SPACING_METRES).floor() as i32;
    let mut candidates = Vec::new();
    let cover =
        super::cover_mask::CoverageMask::new(ground, stable_text_seed(&environment.scene_digest))?;
    for z in 0..count_z {
        for x in 0..count_x {
            let hash = streams::SITE.seed(seed, &[x as u64, z as u64]);
            if streams::PRESENCE.rng(hash, &[]).inclusive_unit_f32() > OCCUPANCY {
                continue;
            }
            let world = Vec2::new(
                -terrain.width() * 0.5
                    + (x as f32
                        + 0.15
                        + streams::JITTER_X.rng(hash, &[]).inclusive_unit_f32() * 0.7)
                        * SITE_SPACING_METRES,
                -terrain.depth() * 0.5
                    + (z as f32
                        + 0.15
                        + streams::JITTER_Z.rng(hash, &[]).inclusive_unit_f32() * 0.7)
                        * SITE_SPACING_METRES,
            );
            let Some(world) = ScenePlanPoint::from_metres(world) else {
                continue;
            };
            let (Some(surface), Some(height), Some(normal)) = (
                ground.ground_at(world),
                terrain.height_at(world),
                terrain.normal_at(world),
            ) else {
                continue;
            };
            if normal.y < MIN_SLOPE_NORMAL_Y || !open_understory_site(&cover, world) {
                continue;
            }
            let habitat = habitat(surface, environment);
            // A shared macro-cell roll gives patches botanical coherence; roots
            // retain independent jitter so the planting lattice is not visible.
            let community = streams::COMMUNITY.seed(seed, &[(x / 3) as u64, (z / 3) as u64]);
            let weights = PlantSpecies::ALL.map(|species| {
                (species.habitat_weight(habitat)
                    * f32::from(adventuresim_world_schema::BASIS_POINTS_PER_WHOLE))
                .round() as u64
            });
            let Ok(species) = streams::SPECIES
                .rng(community, &[])
                .weighted_index(&weights)
            else {
                continue;
            };
            let Ok(root) = Position::from_metres(Vec3::new(
                world.metres().x,
                height.metres() - ROOT_EMBED_METRES,
                world.metres().y,
            )) else {
                continue;
            };
            candidates.push(PlantSite {
                root,
                species: PlantSpecies::ALL[species],
                hash,
            });
        }
    }
    // Stable priority sampling spreads the bounded population over the entire
    // scene; truncating row order would leave one populated corner.
    candidates.sort_by_key(|site| {
        (
            site.hash,
            site.root.metres().x.to_bits(),
            site.root.metres().z.to_bits(),
        )
    });
    candidates.truncate(MAX_SPECIMENS);
    Ok(candidates)
}

/// Shoots occupy existing vegetation openings, never clear their own.
fn open_understory_site(cover: &super::cover_mask::CoverageMask, point: ScenePlanPoint) -> bool {
    const MAX_GRASS_COVERAGE: u8 = 64;
    const SHOOT_CLEARANCE_METRES: f32 = 0.4;
    [Vec2::ZERO, Vec2::X, Vec2::NEG_X, Vec2::Y, Vec2::NEG_Y]
        .into_iter()
        .all(|offset| {
            ScenePlanPoint::from_metres(point.metres() + offset * SHOOT_CLEARANCE_METRES)
                .is_some_and(|point| cover.coverage_byte(point) <= MAX_GRASS_COVERAGE)
        })
}

fn habitat(surface: GroundSurface, e: &SceneEnvironment) -> PlantHabitat {
    let ground = if !matches!(
        surface.substrate,
        GroundSubstrate::Soil | GroundSubstrate::Mud
    ) {
        PlantGround::Unsuitable
    } else {
        match surface.cover {
            GroundCover::LeafLitter => PlantGround::WoodlandLitter,
            GroundCover::TallGrass => PlantGround::Grass,
            GroundCover::Bare => PlantGround::Soil,
            GroundCover::LooseStone | GroundCover::Reeds => PlantGround::Unsuitable,
        }
    };
    PlantHabitat {
        canopy: bps(e.canopy_bps),
        cultivation: bps(e.cultivation_bps),
        moisture: bps(e.weather.ground_moisture_bps),
        snow: bps(e.weather.snow_cover_bps),
        day_of_year: e.absolute_minute.day_of_year(),
        ground,
    }
}

#[cfg(test)]
mod tests;
