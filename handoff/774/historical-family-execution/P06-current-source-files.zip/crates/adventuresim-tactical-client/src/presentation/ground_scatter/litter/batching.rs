//! Keep reusable litter prototypes on the CPU and upload only assembled batches.

use super::*;
use bevy::asset::RenderAssetUsages;

pub(super) fn append_litter_batch(
    meshes: &bevy::prelude::Assets<Mesh>,
    source: &Handle<Mesh>,
    placement: LitterPlacement,
    batches: &mut BTreeMap<(i32, i32), LitterBatch>,
) -> Result<(), bevy::mesh::MeshMergeError> {
    let mut transform = Transform {
        translation: placement.root.metres(),
        rotation: placement.rotation,
        scale: placement.scale,
    };
    let cell_size = LITTER_BATCH_CELL_METRES;
    let cell = (
        (transform.translation.x / cell_size).floor() as i32,
        (transform.translation.z / cell_size).floor() as i32,
    );
    transform.translation.x -= cell.0 as f32 * cell_size;
    transform.translation.z -= cell.1 as f32 * cell_size;
    let Some(source) = meshes.get(source) else {
        return Ok(());
    };
    let mut transformed = source.clone().transformed_by(transform);
    transformed.asset_usage = RenderAssetUsages::RENDER_WORLD;
    let batch = batches.entry(cell).or_default();
    let slot = match placement.kind {
        BatchKind::Leaves => &mut batch.leaves,
        BatchKind::Twigs => &mut batch.twigs,
        BatchKind::Plants => &mut batch.plants,
    };
    if let Some(batch) = slot {
        batch.merge(&transformed)?;
    } else {
        *slot = Some(transformed);
    }
    Ok(())
}

pub(super) fn spawn_batches(
    commands: &mut Commands,
    meshes: &mut bevy::prelude::Assets<Mesh>,
    assets: &Assets,
    batches: BTreeMap<(i32, i32), LitterBatch>,
) {
    for ((cell_x, cell_z), batch) in batches {
        let transform = Transform::from_xyz(
            cell_x as f32 * LITTER_BATCH_CELL_METRES,
            0.0,
            cell_z as f32 * LITTER_BATCH_CELL_METRES,
        );
        if let Some(mesh) = batch.leaves {
            commands.spawn((
                Name::new("Batched tactical dry leaves"),
                GroundScatterLayer::DryLeaves,
                NotShadowCaster,
                Mesh3d(meshes.add(mesh)),
                MeshMaterial3d(assets.dry_leaf_material.clone()),
                batched_litter_visibility(DRY_LEAF_LOCAL_END_METRES),
                transform,
            ));
        }
        if let Some(mesh) = batch.twigs {
            commands.spawn((
                Name::new("Batched tactical twigs"),
                GroundScatterLayer::Twigs,
                NotShadowCaster,
                Mesh3d(meshes.add(mesh)),
                MeshMaterial3d(assets.twig_material.clone()),
                batched_litter_visibility(TWIG_LOCAL_END_METRES),
                transform,
            ));
        }
        if let Some(mesh) = batch.plants {
            commands.spawn((
                Name::new("Batched tactical woodland-floor plants"),
                GroundScatterLayer::Understory,
                NotShadowCaster,
                Mesh3d(meshes.add(mesh)),
                MeshMaterial3d(assets.woodland_plant_material.clone()),
                batched_litter_visibility(WOODLAND_PLANT_LOCAL_END_METRES),
                transform,
            ));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use bevy::asset::RenderAssetUsages;

    #[test]
    fn prototypes_survive_between_scenes_while_batches_upload_only() {
        let mut meshes = bevy::prelude::Assets::<Mesh>::default();
        for prototype in [
            dry_leaf_patch_mesh(0).unwrap(),
            twig_patch_mesh(0).unwrap(),
            woodland_plant_patch_mesh(0).unwrap(),
        ] {
            assert_eq!(prototype.asset_usage, RenderAssetUsages::MAIN_WORLD);
            let source = meshes.add(prototype);
            for _scene in 0..2 {
                let mut batches = BTreeMap::new();
                append_litter_batch(
                    &meshes,
                    &source,
                    LitterPlacement {
                        root: Position::ORIGIN,
                        rotation: bevy::prelude::Quat::IDENTITY,
                        scale: Vec3::ONE,
                        kind: BatchKind::Leaves,
                    },
                    &mut batches,
                )
                .unwrap();
                let batch = batches[&(0, 0)].leaves.as_ref().unwrap();
                assert_eq!(batch.asset_usage, RenderAssetUsages::RENDER_WORLD);
                assert_eq!(
                    batch.count_vertices(),
                    meshes.get(&source).unwrap().count_vertices()
                );
            }
        }
    }
}
