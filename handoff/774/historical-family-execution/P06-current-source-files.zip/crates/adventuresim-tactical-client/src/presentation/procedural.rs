use super::*;
use adventuresim_tactical_core::scene_coordinates::ScenePlanPoint;
use fabelgeist_determinism::Seed;
use fabelgeist_determinism::StreamId;

pub(super) fn obstacle_seed(point: ScenePlanPoint) -> Seed {
    let position = point.metres();
    StreamId::new("visual.obstacle.position").seed(
        0.into(),
        &[
            u64::from(position.x.to_bits()),
            u64::from(position.y.to_bits()),
        ],
    )
}

pub(super) fn stable_text_seed(value: &str) -> Seed {
    fabelgeist_determinism::Seed::derive(
        value.as_bytes(),
        StreamId::new("visual.text-identity"),
        &[],
    )
}

pub(super) fn bps(value: u16) -> f32 {
    adventuresim_world_schema::UnitBasisPoints::saturating(value).as_unit_f32()
}

pub(super) fn color_vec4(color: Color) -> Vec4 {
    Vec4::from_array(color.to_linear().to_f32_array())
}
