use adventuresim_building_generator::spatial_geometry::{
    Displacement, Elevation, GeometryResult, PlanDirection, Position, PositiveLength,
};
use adventuresim_tactical_core::{animation::NonnegativeLength, scene_coordinates::ScenePlanPoint};
pub(super) use assets::{PatchMeshes, prepare_meshes};
use batching::append_litter_batch;
pub(crate) use capture::GroundLitterCapturePair;
use fabelgeist_determinism::Seed;
use geometry::{
    BentTwig, CamberedLeaf, LitterPatch, RosetteLeaf, TwigBase, TwigCrossSection, TwigStation,
};
use mesh::GroundLitterMeshData;
use placement::LitterPlacement;

use adventuresim_tactical_core::prelude::{GroundCover, SceneGround, SceneTerrain};
use bevy::{
    camera::visibility::VisibilityRange,
    color::ColorToComponents,
    light::NotShadowCaster,
    math::FloatExt,
    prelude::{
        Color, Commands, Handle, Mesh, Mesh3d, MeshMaterial3d, Name, StandardMaterial, Transform,
        Vec2, Vec3, default,
    },
};
use std::collections::BTreeMap;

#[cfg(test)]
use crate::presentation::generate_procedural_textures;
use crate::presentation::{ProceduralTextureAssets, bps, leaf_material};

use super::{
    GroundLitterCaptureAnchors, GroundScatterLayer, TacticalFoliageMaterial,
    TacticalTreeLeafCardMaterial,
};

mod assets;
mod batching;
mod capture;
mod geometry;
mod mesh;
mod placement;
mod streams;

const DRY_LEAF_PASSES_PER_SAMPLE: u64 = 8;
const TWIG_PASSES_PER_SAMPLE: u64 = 4;
const WOODLAND_PLANT_PASSES_PER_SAMPLE: u64 = 1;
const WOODLAND_FLOOR_TRANSITION_METRES: f32 = 3.2;
const LITTER_BATCH_CELL_METRES: f32 = 24.0;
const LITTER_BATCH_HALF_DIAGONAL_METRES: f32 =
    LITTER_BATCH_CELL_METRES * core::f32::consts::FRAC_1_SQRT_2;
// Physical forest-floor detail is close-camera dressing. Beyond these local
// ranges the terrain's existing canopy-floor/litter material carries the
// forest-floor read; the batch visibility helper adds its AABB safety pad.
const DRY_LEAF_LOCAL_END_METRES: f32 = 16.0;
const TWIG_LOCAL_END_METRES: f32 = 12.0;
const WOODLAND_PLANT_LOCAL_END_METRES: f32 = 14.0;
const DRY_LEAVES_PER_PATCH: u64 = 56;
const TWIGS_PER_PATCH: u64 = 8;

pub(super) const DRY_LEAF_MESH_VARIANTS: u64 = 4;
pub(super) const TWIG_MESH_VARIANTS: u64 = 3;
pub(super) const WOODLAND_PLANT_MESH_VARIANTS: u64 = 3;

pub(super) struct Assets {
    pub dry_leaf_meshes: Vec<Handle<Mesh>>,
    pub twig_meshes: Vec<Handle<Mesh>>,
    pub dry_leaf_material: Handle<TacticalTreeLeafCardMaterial>,
    pub twig_material: Handle<StandardMaterial>,
    pub woodland_plant_meshes: Vec<Handle<Mesh>>,
    pub woodland_plant_material: Handle<TacticalFoliageMaterial>,
}

#[derive(Default)]
struct LitterBatch {
    leaves: Option<Mesh>,
    twigs: Option<Mesh>,
    plants: Option<Mesh>,
}

#[derive(Clone, Copy)]
enum BatchKind {
    Leaves,
    Twigs,
    Plants,
}

/// Static, vertex-colored wood for batched forest-floor twigs.
///
/// Twigs are fully modeled opaque geometry, so the stock PBR path preserves
/// their per-vertex bark pigment, fog, and lighting without foliage wind,
/// interaction, coverage-mask, or transmission work.
pub(super) fn static_twig_material() -> StandardMaterial {
    StandardMaterial {
        base_color: Color::WHITE,
        perceptual_roughness: 0.96,
        double_sided: true,
        cull_mode: None,
        ..default()
    }
}

pub(super) fn spawn(
    commands: &mut Commands,
    meshes: &mut bevy::prelude::Assets<Mesh>,
    terrain: &SceneTerrain,
    ground: &SceneGround,
    base_seed: Seed,
    assets: &Assets,
) -> Result<(), bevy::mesh::MeshMergeError> {
    let mut batches = BTreeMap::<(i32, i32), LitterBatch>::new();
    let mut leaf_anchors = Vec::new();
    let mut twig_anchors = Vec::new();
    let mut dry_leaf_patch_instances = 0;
    for (index, sample) in ground.samples().iter().enumerate() {
        let grid_x = index % ground.grid_width();
        let grid_z = index / ground.grid_width();
        let transition = match sample.cover {
            GroundCover::LeafLitter => 1.0,
            GroundCover::TallGrass => leaf_litter_proximity(ground, grid_x, grid_z),
            _ => 0.0,
        };
        if transition <= 0.0 {
            continue;
        }
        let cell_origin = Vec2::new(
            grid_x as f32 * ground.grid_scale() - ground.width() * 0.5,
            grid_z as f32 * ground.grid_scale() - ground.depth() * 0.5,
        );
        let Some(cell_origin) = ScenePlanPoint::from_metres(cell_origin) else {
            continue;
        };
        let density = if sample.cover == GroundCover::LeafLitter {
            bps(sample.cover_density_bps)
        } else {
            transition * 0.34
        };
        for pass in 0..DRY_LEAF_PASSES_PER_SAMPLE {
            let hash = streams::LEAF_PATCH.seed(base_seed, &[index as u64, pass]);
            if streams::PRESENCE.rng(hash, &[]).inclusive_unit_f32() >= density * 0.97 {
                continue;
            }
            let Some(placement) =
                LitterPlacement::new(terrain, ground, cell_origin, hash, BatchKind::Leaves)
            else {
                continue;
            };
            if sample.cover == GroundCover::LeafLitter {
                leaf_anchors.push(placement.root);
            }
            dry_leaf_patch_instances += 1;
            append_litter_batch(
                meshes,
                &assets.dry_leaf_meshes[streams::DRY_LEAF_MESHES_VARIANT
                    .rng(hash, &[])
                    .index(assets.dry_leaf_meshes.len())],
                placement,
                &mut batches,
            )?;
        }
        for pass in 0..TWIG_PASSES_PER_SAMPLE {
            let hash = streams::TWIG_PATCH.seed(base_seed, &[index as u64, pass]);
            if streams::PRESENCE.rng(hash, &[]).inclusive_unit_f32() >= density * 0.62 {
                continue;
            }
            let Some(placement) =
                LitterPlacement::new(terrain, ground, cell_origin, hash, BatchKind::Twigs)
            else {
                continue;
            };
            if sample.cover == GroundCover::LeafLitter {
                twig_anchors.push(placement.root);
            }
            append_litter_batch(
                meshes,
                &assets.twig_meshes[streams::TWIG_MESHES_VARIANT
                    .rng(hash, &[])
                    .index(assets.twig_meshes.len())],
                placement,
                &mut batches,
            )?;
        }
        let plant_chance = if sample.cover == GroundCover::LeafLitter {
            0.055
        } else {
            transition * 0.38
        };
        for pass in 0..WOODLAND_PLANT_PASSES_PER_SAMPLE {
            let hash = streams::PLANT_PATCH.seed(base_seed, &[index as u64, pass]);
            if streams::PRESENCE.rng(hash, &[]).inclusive_unit_f32() >= plant_chance {
                continue;
            }
            let Some(placement) =
                LitterPlacement::new(terrain, ground, cell_origin, hash, BatchKind::Plants)
            else {
                continue;
            };
            append_litter_batch(
                meshes,
                &assets.woodland_plant_meshes[streams::WOODLAND_PLANT_MESHES_VARIANT
                    .rng(hash, &[])
                    .index(assets.woodland_plant_meshes.len())],
                placement,
                &mut batches,
            )?;
        }
    }
    let pairs = GroundLitterCapturePair::closest(
        &leaf_anchors,
        &twig_anchors,
        GroundLitterCapturePair::MAXIMUM_SEPARATION,
        64,
    );
    if !pairs.is_empty() {
        commands.spawn((
            Name::new("Tactical litter capture anchors"),
            GroundLitterCaptureAnchors { pairs },
        ));
    }
    commands.spawn((
        Name::new("Tactical litter diagnostics"),
        super::GroundLitterDiagnostics {
            dry_leaf_patch_instances,
            physical_dry_leaf_count: dry_leaf_patch_instances * DRY_LEAVES_PER_PATCH as usize,
        },
    ));
    batching::spawn_batches(commands, meshes, assets, batches);
    Ok(())
}

pub(super) fn forest_floor_leaf_material(
    assets: &ProceduralTextureAssets,
) -> TacticalTreeLeafCardMaterial {
    let mut material = leaf_material(&assets.dry_oak_leaf, 0.28, 0.72, 0.0, 0.035);
    // Fallen leaves reuse the oak surface maps/PBR response but do not inherit
    // canopy wind displacement. NotShadowCaster on every litter entity keeps
    // their dense alpha geometry out of the shadow pass.
    material.parameters.z = 0.0;
    material.surface_parameters.z = 0.0;
    material.surface_parameters.w = 0.035;
    // The dry-leaf height map remains available to close inspection, but its
    // embossed midrib must not make every geometry leaf readable from the
    // acceptance distance when the terrain layer's relief has minified.
    material.surface_parameters.y = 0.18;
    material.physical_parameters.x = 0.96;
    material.physical_parameters.y = 0.00035;
    // Fallen-leaf meshes already carry deterministic dry pigments per leaf.
    // Blend those pigments over the shared dry-oak texture; live canopy cards
    // keep zero here and retain their species albedo unchanged.
    material.physical_parameters.z = 0.38;
    material
}

pub(super) fn dry_leaf_patch_mesh(variant: u64) -> GeometryResult<Mesh> {
    let mut data = GroundLitterMeshData::default();
    // Keep the vertex pigments in the same narrow value bands as the packed
    // terrain litter. Variation remains legible up close without turning the
    // physical leaves into isolated copper markers.
    let leaf_colors = [
        Color::srgb_u8(106, 90, 69),
        Color::srgb_u8(99, 86, 68),
        Color::srgb_u8(112, 95, 72),
        Color::srgb_u8(95, 83, 67),
        Color::srgb_u8(104, 91, 72),
    ];
    // Keep a clustered tail even after reducing the patch population so
    // variants retain their loose-pile silhouette differences.
    const STRATIFIED_LEAVES: u64 = 40;
    const STRATIFIED_COLUMNS: u64 = 8;
    const CLUSTER_COUNT: u64 = 7;
    let clusters = (0..CLUSTER_COUNT)
        .map(|cluster| {
            let hash = streams::LEAF_CLUSTER.seed(variant.into(), &[cluster]);
            Vec2::new(
                streams::CENTER_X.rng(hash, &[]).inclusive_unit_f32() - 0.5,
                streams::CENTER_Z.rng(hash, &[]).inclusive_unit_f32() - 0.5,
            ) * 0.68
        })
        .collect::<Vec<_>>();
    for leaf in 0..DRY_LEAVES_PER_PATCH {
        let hash = streams::LEAF.seed(variant.into(), &[leaf]);
        let scatter_angle =
            streams::SCATTER_ANGLE.rng(hash, &[]).inclusive_unit_f32() * core::f32::consts::TAU;
        let centre = if leaf < STRATIFIED_LEAVES {
            let column = leaf % STRATIFIED_COLUMNS;
            let row = leaf / STRATIFIED_COLUMNS;
            let jitter = Vec2::new(
                streams::STRATUM_JITTER_X
                    .rng(hash, &[])
                    .inclusive_unit_f32()
                    - 0.5,
                streams::STRATUM_JITTER_Z
                    .rng(hash, &[])
                    .inclusive_unit_f32()
                    - 0.5,
            ) * 0.075;
            Vec2::new(
                (column as f32 + 0.5) / STRATIFIED_COLUMNS as f32 - 0.5,
                (row as f32 + 0.5) / (STRATIFIED_LEAVES / STRATIFIED_COLUMNS) as f32 - 0.5,
            ) * 0.90
                + jitter
        } else {
            let cluster = clusters[leaf as usize % clusters.len()];
            let radial = 0.025 + streams::RADIAL.rng(hash, &[]).inclusive_unit_f32() * 0.12;
            cluster + Vec2::new(scatter_angle.cos(), scatter_angle.sin()) * radial
        };
        let angle = streams::ANGLE.rng(hash, &[]).inclusive_unit_f32() * core::f32::consts::TAU;
        let long = Vec2::new(angle.cos(), angle.sin())
            * (0.045 + streams::LENGTH.rng(hash, &[]).inclusive_unit_f32() * 0.040);
        let side = Vec2::new(-long.y, long.x)
            * (0.45 + streams::WIDTH.rng(hash, &[]).inclusive_unit_f32() * 0.18);
        data.append_cambered_leaf(
            CamberedLeaf {
                centre: Position::<LitterPatch>::from_metres(Vec3::new(centre.x, 0.0, centre.y))?,
                long: Displacement::from_metres(Vec3::new(long.x, 0.0, long.y))?,
                side: Displacement::from_metres(Vec3::new(side.x, 0.0, side.y))?,
                height: Elevation::from_metres(if leaf % 5 == 0 {
                    0.004 + streams::LEAF_HEIGHT.rng(hash, &[]).inclusive_unit_f32() * 0.008
                } else {
                    streams::LEAF_HEIGHT.rng(hash, &[]).inclusive_unit_f32() * 0.0015
                })?,
            },
            hash,
            leaf_colors[leaf as usize % leaf_colors.len()],
        );
    }
    Ok(data.into_mesh())
}

/// Independent twig mesh. Longer, thinner pieces and a lower spawn density
/// let twigs form irregular accents over the denser dry-leaf carpet.
pub(super) fn twig_patch_mesh(variant: u64) -> GeometryResult<Mesh> {
    let mut data = GroundLitterMeshData::default();
    let twig_colors = [
        Color::srgb_u8(79, 47, 24),
        Color::srgb_u8(102, 62, 29),
        Color::srgb_u8(62, 40, 25),
    ];
    for twig in 0..TWIGS_PER_PATCH {
        let hash = streams::TWIG.seed(variant.into(), &[twig]);
        let centre = Vec2::new(
            streams::CENTER_X.rng(hash, &[]).inclusive_unit_f32() - 0.5,
            streams::CENTER_Z.rng(hash, &[]).inclusive_unit_f32() - 0.5,
        ) * 1.02;
        let angle = streams::ANGLE.rng(hash, &[]).inclusive_unit_f32() * core::f32::consts::TAU;
        let long = Vec2::new(angle.cos(), angle.sin())
            * (0.075 + streams::LENGTH.rng(hash, &[]).inclusive_unit_f32() * 0.07);
        let lateral = Vec2::new(-long.y, long.x).normalize_or_zero();
        let start = Vec3::new(centre.x - long.x, -0.004, centre.y - long.y);
        let bend = (streams::WIDTH.rng(hash, &[]).inclusive_unit_f32() - 0.5) * 0.055;
        let middle = Vec3::new(
            centre.x + lateral.x * bend,
            0.002 + streams::TWIG_LIFT.rng(hash, &[]).inclusive_unit_f32() * 0.004,
            centre.y + lateral.y * bend,
        );
        let end = Vec3::new(centre.x + long.x, -0.006, centre.y + long.y);
        let cross_section = if streams::TWIG_SIDES.rng(hash, &[]).index(2) == 0 {
            TwigCrossSection::Pentagonal
        } else {
            TwigCrossSection::Hexagonal
        };
        let radius = 0.006 + streams::TWIG_RADIUS.rng(hash, &[]).inclusive_unit_f32() * 0.005;
        let color = twig_colors[twig as usize % twig_colors.len()];
        data.append_bent_twig(
            BentTwig {
                stations: [
                    TwigStation {
                        centre: Position::from_metres(start)?,
                        radius: PositiveLength::from_metres(radius)?,
                    },
                    TwigStation {
                        centre: Position::from_metres(middle)?,
                        radius: PositiveLength::from_metres(radius * 0.58)?,
                    },
                    TwigStation {
                        centre: Position::from_metres(end)?,
                        radius: PositiveLength::from_metres(radius * 0.08)?,
                    },
                ],
                cross_section,
                base: TwigBase::Closed,
                root: Position::from_metres(Vec3::new(centre.x, 0.0, centre.y))?,
            },
            color,
        );
        if twig < 2 && streams::TWIG_FORK.rng(hash, &[]).inclusive_unit_f32() > 0.46 {
            let attach = middle.lerp(end, 0.22);
            let direction = (end - middle).normalize();
            let lateral = Vec3::new(-direction.z, 0.12, direction.x).normalize();
            let fork_end = attach
                + (direction * 0.38
                    + lateral
                        * if streams::TWIG_FORK_SIDE.rng(hash, &[]).boolean() {
                            0.62
                        } else {
                            -0.62
                        })
                .normalize()
                    * long.length()
                    * 0.72;
            let fork_middle = attach.lerp(fork_end, 0.52) + Vec3::Y * 0.002;
            data.append_bent_twig(
                BentTwig {
                    stations: [
                        TwigStation {
                            centre: Position::from_metres(attach)?,
                            radius: PositiveLength::from_metres(radius * 0.55)?,
                        },
                        TwigStation {
                            centre: Position::from_metres(fork_middle)?,
                            radius: PositiveLength::from_metres(radius * 0.3)?,
                        },
                        TwigStation {
                            centre: Position::from_metres(fork_end)?,
                            radius: PositiveLength::from_metres(radius * 0.05)?,
                        },
                    ],
                    cross_section,
                    base: TwigBase::ForkAttachment,
                    root: Position::from_metres(Vec3::new(centre.x, 0.0, centre.y))?,
                },
                color,
            );
        }
    }
    Ok(data.into_mesh())
}

/// A sparse shade-floor rosette. Seven-vertex cambered leaves provide a
/// readable close silhouette without introducing a textured albedo or the
/// single-triangle markers formerly used for tiny meadow accents.
pub(super) fn woodland_plant_patch_mesh(variant: u64) -> GeometryResult<Mesh> {
    let mut data = GroundLitterMeshData::default();
    let palette = [
        Color::srgb_u8(48, 79, 35),
        Color::srgb_u8(57, 91, 40),
        Color::srgb_u8(40, 68, 31),
    ];
    let plant_count = 2 + variant % 2;
    for plant in 0..plant_count {
        let plant_hash = streams::PLANT.seed(variant.into(), &[plant]);
        let centre = Vec2::new(
            streams::PLANT_CENTER_X
                .rng(plant_hash, &[])
                .inclusive_unit_f32()
                - 0.5,
            streams::PLANT_CENTER_Z
                .rng(plant_hash, &[])
                .inclusive_unit_f32()
                - 0.5,
        ) * 0.62;
        let leaf_count = 5 + streams::LEAF_COUNT.rng(plant_hash, &[]).index(3) as u64;
        let phase = streams::PLANT_PHASE
            .rng(plant_hash, &[])
            .inclusive_unit_f32()
            * core::f32::consts::TAU;
        for leaf in 0..leaf_count {
            let hash = streams::PLANT_LEAF.seed(plant_hash, &[leaf]);
            let angle = phase
                + leaf as f32 * core::f32::consts::TAU / leaf_count as f32
                + (streams::CENTER_X.rng(hash, &[]).inclusive_unit_f32() - 0.5) * 0.28;
            let length = 0.11 + streams::LENGTH.rng(hash, &[]).inclusive_unit_f32() * 0.075;
            let width = length * (0.19 + streams::WIDTH.rng(hash, &[]).inclusive_unit_f32() * 0.08);
            data.append_rosette_leaf(
                RosetteLeaf {
                    root: Position::from_metres(Vec3::new(centre.x, 0.0, centre.y))?,
                    direction: PlanDirection::from_normalized(Vec2::new(angle.cos(), angle.sin()))?,
                    length: PositiveLength::from_metres(length)?,
                    width: PositiveLength::from_metres(width)?,
                    rise: Elevation::from_metres(
                        0.055 + streams::TWIG_RADIUS.rng(hash, &[]).inclusive_unit_f32() * 0.055,
                    )?,
                },
                palette[(plant as usize + leaf as usize) % palette.len()],
            );
        }
    }
    Ok(data.into_mesh())
}

fn batched_litter_visibility(local_end_metres: f32) -> VisibilityRange {
    // Each entity contains debris distributed across a large cell. Measuring
    // visibility from the cell-corner entity translation can therefore hide
    // geometry beside the camera. Use the merged mesh bounds and pad the
    // cutoff by the greatest possible centre-to-edge distance so the range
    // still describes distance from the debris itself.
    let batch_end = local_end_metres + LITTER_BATCH_HALF_DIAGONAL_METRES;
    VisibilityRange {
        start_margin: 0.0..0.0,
        end_margin: batch_end..batch_end,
        use_aabb: true,
    }
}

fn leaf_litter_proximity(ground: &SceneGround, grid_x: usize, grid_z: usize) -> f32 {
    let radius = (WOODLAND_FLOOR_TRANSITION_METRES / ground.grid_scale()).ceil() as isize;
    let mut nearest: Option<NonnegativeLength> = None;
    for dz in -radius..=radius {
        for dx in -radius..=radius {
            let x = grid_x as isize + dx;
            let z = grid_z as isize + dz;
            if x < 0
                || z < 0
                || x >= ground.grid_width() as isize
                || z >= ground.grid_depth() as isize
                || ground.samples()[z as usize * ground.grid_width() + x as usize].cover
                    != GroundCover::LeafLitter
            {
                continue;
            }
            let distance = Vec2::new(dx as f32, dz as f32).length() * ground.grid_scale();
            let Ok(distance) = NonnegativeLength::from_arithmetic(distance) else {
                continue;
            };
            nearest = Some(nearest.map_or(distance, |nearest| {
                if distance < nearest {
                    distance
                } else {
                    nearest
                }
            }));
        }
    }
    nearest.map_or(0.0, |nearest| {
        (1.0 - nearest.metres() / WOODLAND_FLOOR_TRANSITION_METRES).clamp(0.0, 1.0)
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::presentation::obstacles::tree::oak_leaf_material;
    use adventuresim_tactical_core::prelude::GroundSurface;
    use bevy::{
        asset::{AssetApp, AssetPlugin},
        mesh::VertexAttributeValues,
        prelude::{App, Assets as BevyAssets, Image, TaskPoolPlugin, World, default},
    };

    #[test]
    fn litter_batches_use_static_twigs_and_tactical_foliage_for_plants() {
        let terrain = SceneTerrain::from_heightmap(3, 3, 1.0, vec![0.0; 9]).unwrap();
        let ground = SceneGround::from_samples(
            3,
            3,
            1.0,
            vec![
                GroundSurface {
                    cover: GroundCover::LeafLitter,
                    cover_density_bps: 10_000,
                    ..default()
                };
                9
            ],
        )
        .unwrap();
        let mut meshes = BevyAssets::<Mesh>::default();
        let assets = Assets {
            dry_leaf_meshes: vec![meshes.add(dry_leaf_patch_mesh(0).unwrap())],
            twig_meshes: vec![meshes.add(twig_patch_mesh(0).unwrap())],
            dry_leaf_material: Handle::default(),
            twig_material: Handle::default(),
            woodland_plant_meshes: vec![meshes.add(woodland_plant_patch_mesh(0).unwrap())],
            woodland_plant_material: Handle::default(),
        };
        let base_seed = (0..100)
            .map(fabelgeist_determinism::Seed::from_u64)
            .find(|base_seed| {
                (0..9).any(|index| {
                    streams::PRESENCE
                        .rng(streams::PLANT_PATCH.seed(*base_seed, &[index, 0]), &[])
                        .inclusive_unit_f32()
                        < 0.055
                })
            })
            .expect("a deterministic seed with a woodland-floor plant");
        let mut world = World::new();
        {
            let mut commands = world.commands();
            spawn(
                &mut commands,
                &mut meshes,
                &terrain,
                &ground,
                base_seed,
                &assets,
            )
            .unwrap();
        }
        world.flush();

        let mut batches = world.query::<(
            &GroundScatterLayer,
            Option<&MeshMaterial3d<StandardMaterial>>,
            Option<&MeshMaterial3d<TacticalFoliageMaterial>>,
            Option<&NotShadowCaster>,
        )>();
        let mut twig_batches = 0;
        let mut plant_batches = 0;
        for (layer, standard, foliage, not_shadow_caster) in batches.iter(&world) {
            match layer {
                GroundScatterLayer::Twigs => {
                    twig_batches += 1;
                    assert!(standard.is_some());
                    assert!(foliage.is_none());
                    assert!(not_shadow_caster.is_some());
                }
                GroundScatterLayer::Understory => {
                    plant_batches += 1;
                    assert!(standard.is_none());
                    assert!(foliage.is_some());
                    assert!(not_shadow_caster.is_some());
                }
                _ => {}
            }
        }
        assert!(twig_batches > 0);
        assert!(plant_batches > 0);
    }

    #[test]
    fn static_twig_material_is_rough_double_sided_and_fog_lit() {
        let material = static_twig_material();
        assert_eq!(material.base_color, Color::WHITE);
        assert_eq!(material.perceptual_roughness, 0.96);
        assert!(material.double_sided);
        assert_eq!(material.cull_mode, None);
        assert!(material.fog_enabled);
        assert!(!material.unlit);
    }

    #[test]
    fn batched_litter_visibility_cannot_cull_debris_inside_its_local_range() {
        let local_end = DRY_LEAF_LOCAL_END_METRES;
        let range = batched_litter_visibility(local_end);
        assert!(range.use_aabb);
        assert!(range.is_visible_at_all(LITTER_BATCH_HALF_DIAGONAL_METRES + local_end - 0.01));
        assert!(!range.is_visible_at_all(LITTER_BATCH_HALF_DIAGONAL_METRES + local_end + 0.01));
    }

    #[test]
    fn forest_floor_litter_uses_close_local_ranges_with_batch_safety_padding() {
        assert_eq!(DRY_LEAF_LOCAL_END_METRES, 16.0);
        assert_eq!(TWIG_LOCAL_END_METRES, 12.0);
        assert_eq!(WOODLAND_PLANT_LOCAL_END_METRES, 14.0);

        for (local_end, expected_padded_end) in [
            (DRY_LEAF_LOCAL_END_METRES, 32.970_562),
            (TWIG_LOCAL_END_METRES, 28.970_562),
            (WOODLAND_PLANT_LOCAL_END_METRES, 30.970_562),
        ] {
            let range = batched_litter_visibility(local_end);
            assert!((range.end_margin.end - expected_padded_end).abs() < 0.000_1);
        }
    }

    #[test]
    fn capture_anchors_preserve_distinct_placements_inside_one_batch_cell() {
        let leaves = [Vec3::new(0.18, 1.0, 0.24), Vec3::new(4.0, 1.0, 4.0)]
            .map(|point| Position::from_metres(point).unwrap());
        let twigs = [Vec3::new(0.42, 1.01, 0.27), Vec3::new(7.0, 1.0, 7.0)]
            .map(|point| Position::from_metres(point).unwrap());
        let pairs = GroundLitterCapturePair::closest(
            &leaves,
            &twigs,
            GroundLitterCapturePair::MAXIMUM_SEPARATION,
            4,
        );
        assert_eq!(pairs[0].dry_leaf, leaves[0]);
        assert_eq!(pairs[0].twig, twigs[0]);
        assert_ne!(pairs[0].dry_leaf, Position::ORIGIN);
        assert_ne!(pairs[0].twig, Position::ORIGIN);
        assert_ne!(pairs[0].dry_leaf, pairs[0].twig);
        assert!(pairs.len() <= 4);
    }

    #[test]
    fn woodland_floor_transition_decays_outward_from_litter() {
        let mut samples = vec![
            GroundSurface {
                cover: GroundCover::TallGrass,
                cover_density_bps: 10_000,
                cover_height_cm: 82,
                ..default()
            };
            9 * 9
        ];
        samples[4 * 9 + 4].cover = GroundCover::LeafLitter;
        let ground = SceneGround::from_samples(9, 9, 1.0, samples).unwrap();
        let edge = leaf_litter_proximity(&ground, 5, 4);
        let middle = leaf_litter_proximity(&ground, 6, 4);
        let outside = leaf_litter_proximity(&ground, 8, 4);
        assert!(1.0 > edge && edge > middle && middle > outside);
        assert_eq!(outside, 0.0);
    }

    #[test]
    fn dry_leaf_density_uses_the_reduced_physical_geometry_budget() {
        assert_eq!(DRY_LEAF_PASSES_PER_SAMPLE, 8);
        assert_eq!(DRY_LEAVES_PER_PATCH, 56);

        let old_leaf_budget = 12_u64 * 84;
        let new_leaf_budget = DRY_LEAF_PASSES_PER_SAMPLE * DRY_LEAVES_PER_PATCH;
        assert_eq!(new_leaf_budget, 448);
        assert_eq!(new_leaf_budget * 9, old_leaf_budget * 4);
    }

    #[test]
    fn forest_floor_meshes_are_deterministic_bounded_and_volumetric() {
        let leaves = dry_leaf_patch_mesh(0).unwrap();
        let repeated_leaves = dry_leaf_patch_mesh(0).unwrap();
        let alternate_leaves = dry_leaf_patch_mesh(1).unwrap();
        let twigs = twig_patch_mesh(0).unwrap();
        let repeated_twigs = twig_patch_mesh(0).unwrap();
        let plants = woodland_plant_patch_mesh(0).unwrap();
        let repeated_plants = woodland_plant_patch_mesh(0).unwrap();
        let leaf_positions = leaves
            .attribute(Mesh::ATTRIBUTE_POSITION)
            .and_then(VertexAttributeValues::as_float3)
            .unwrap();
        let twig_positions = twigs
            .attribute(Mesh::ATTRIBUTE_POSITION)
            .and_then(VertexAttributeValues::as_float3)
            .unwrap();
        let plant_positions = plants
            .attribute(Mesh::ATTRIBUTE_POSITION)
            .and_then(VertexAttributeValues::as_float3)
            .unwrap();
        let leaf_normals = leaves
            .attribute(Mesh::ATTRIBUTE_NORMAL)
            .and_then(VertexAttributeValues::as_float3)
            .unwrap();
        let twig_normals = twigs
            .attribute(Mesh::ATTRIBUTE_NORMAL)
            .and_then(VertexAttributeValues::as_float3)
            .unwrap();
        assert_eq!(leaf_positions.len(), DRY_LEAVES_PER_PATCH as usize * 9);
        assert_eq!(
            leaves.indices().unwrap().len() / 3,
            DRY_LEAVES_PER_PATCH as usize * 8
        );
        assert!((168..=288).contains(&twig_positions.len()));
        assert!((320..=496).contains(&(twigs.indices().unwrap().len() / 3)));
        assert_eq!(
            leaves.attribute(Mesh::ATTRIBUTE_POSITION),
            repeated_leaves.attribute(Mesh::ATTRIBUTE_POSITION)
        );
        assert_eq!(
            twigs.attribute(Mesh::ATTRIBUTE_POSITION),
            repeated_twigs.attribute(Mesh::ATTRIBUTE_POSITION)
        );
        assert_eq!(
            plants.attribute(Mesh::ATTRIBUTE_POSITION),
            repeated_plants.attribute(Mesh::ATTRIBUTE_POSITION)
        );
        assert_ne!(
            leaves.attribute(Mesh::ATTRIBUTE_POSITION),
            alternate_leaves.attribute(Mesh::ATTRIBUTE_POSITION)
        );
        for mesh in [&leaves, &twigs, &plants] {
            assert!(mesh.attribute(Mesh::ATTRIBUTE_COLOR).is_some());
            assert!(mesh.attribute(Mesh::ATTRIBUTE_UV_1).is_some());
        }
        assert!(
            leaf_normals
                .iter()
                .all(|normal| Vec3::from_array(*normal).is_normalized())
        );
        assert!(
            twig_normals
                .iter()
                .all(|normal| Vec3::from_array(*normal).is_normalized())
        );
        assert!(
            leaf_normals
                .iter()
                .any(|normal| Vec3::from_array(*normal).distance(Vec3::Y) > 0.03)
        );
        let mut contacting_leaves = 0;
        let mut seated_leaves = 0;
        let leaf_spans = leaf_positions
            .as_chunks::<9>()
            .0
            .iter()
            .map(|leaf| {
                let minimum = leaf
                    .iter()
                    .map(|point| point[1])
                    .fold(f32::INFINITY, f32::min);
                let maximum = leaf
                    .iter()
                    .map(|point| point[1])
                    .fold(f32::NEG_INFINITY, f32::max);
                contacting_leaves += usize::from(minimum <= -0.0006);
                seated_leaves += usize::from(minimum <= 0.004);
                assert!(maximum <= 0.032, "leaf lift must stay bounded: {maximum}");
                maximum - minimum
            })
            .collect::<Vec<_>>();
        assert!(
            contacting_leaves >= 4,
            "each loose pile needs seated base leaves"
        );
        assert!(
            seated_leaves >= DRY_LEAVES_PER_PATCH as usize * 3 / 4,
            "most leaves must sit within four millimetres: {seated_leaves}"
        );
        assert!(leaf_spans.iter().all(|span| *span > 0.0008));
        assert!(
            leaf_spans
                .windows(2)
                .any(|pair| (pair[0] - pair[1]).abs() > 0.001)
        );
        let Some(VertexAttributeValues::Float32x2(leaf_uvs)) =
            leaves.attribute(Mesh::ATTRIBUTE_UV_0)
        else {
            panic!("fallen-leaf UVs must use Float32x2 storage");
        };
        assert!(leaf_uvs.contains(&[0.5, 0.0]));
        assert!(leaf_uvs.contains(&[1.0, 0.5]));
        assert!(leaf_uvs.contains(&[0.5, 1.0]));
        assert!(leaf_uvs.contains(&[0.0, 0.5]));
        assert!(!leaf_uvs.contains(&[0.0, 0.0]));
        assert!(!leaf_uvs.contains(&[1.0, 1.0]));
        let leaf_indices = leaves.indices().unwrap().iter().collect::<Vec<_>>();
        for triangle in leaf_indices.as_chunks::<3>().0 {
            let a = Vec3::from_array(leaf_positions[triangle[0]]);
            let b = Vec3::from_array(leaf_positions[triangle[1]]);
            let c = Vec3::from_array(leaf_positions[triangle[2]]);
            let average_normal = (Vec3::from_array(leaf_normals[triangle[0]])
                + Vec3::from_array(leaf_normals[triangle[1]])
                + Vec3::from_array(leaf_normals[triangle[2]]))
            .normalize();
            assert!((b - a).cross(c - a).dot(average_normal) > 0.0);
        }
        for positions in [leaf_positions, twig_positions, plant_positions] {
            assert!(positions.iter().flatten().all(|value| value.is_finite()));
        }
        assert!(
            leaf_positions
                .iter()
                .all(|point| point[0].abs() < 0.7 && point[2].abs() < 0.7)
        );
        assert!(
            twig_positions
                .iter()
                .all(|point| point[0].abs() < 0.9 && point[2].abs() < 0.9)
        );
        assert!((70..=150).contains(&plant_positions.len()));
        assert!(plant_positions.iter().any(|point| point[1] > 0.08));
        let leaf_height_bounds = leaf_positions.iter().fold(
            (f32::INFINITY, f32::NEG_INFINITY),
            |(minimum, maximum), point| (minimum.min(point[1]), maximum.max(point[1])),
        );
        assert!(
            leaf_height_bounds.0 >= -0.05 && leaf_height_bounds.1 <= 0.06,
            "fallen leaf height bounds: {leaf_height_bounds:?}"
        );
        assert!(
            twig_positions
                .iter()
                .all(|point| (-0.02..0.20).contains(&point[1]))
        );
    }

    #[test]
    fn forest_floor_leaves_use_dry_oak_palette_and_surface_contract() {
        let mut app = App::new();
        app.add_plugins(TaskPoolPlugin::default());
        app.add_plugins(AssetPlugin::default());
        app.init_asset::<Image>();
        let assets = generate_procedural_textures(
            &adventuresim_procedural_textures::TextureParameters::default(),
            &mut app
                .world_mut()
                .resource_mut::<bevy::prelude::Assets<Image>>(),
        );
        let floor = forest_floor_leaf_material(&assets);
        let oak = oak_leaf_material(&assets);
        assert_eq!(floor.opacity, assets.dry_oak_leaf.opacity);
        assert_ne!(floor.front_albedo, oak.front_albedo);
        assert_ne!(floor.back_albedo, oak.back_albedo);
        assert_eq!(floor.arm, assets.dry_oak_leaf.arm);
        assert_eq!(floor.parameters.z, 0.0);
        assert_eq!(floor.surface_parameters.z, 0.0);
        assert!(floor.surface_parameters.w < oak.surface_parameters.w * 0.2);
        assert!(floor.physical_parameters.y < oak.physical_parameters.y);
        assert!((0.3..0.5).contains(&floor.physical_parameters.z));
        assert_eq!(oak.physical_parameters.z, 0.0);
        let shader = include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../adventuresim-procedural-materials/src/shaders/tactical_tree_leaf_card.wgsl"
        ))
        .replace("\r\n", "\n");
        assert!(shader.contains("pbr_input.material.base_color = vec4<f32>(\n        albedo,"));
        assert!(shader.contains("albedo = mix(albedo, in.color.rgb"));
        assert!(!shader.contains("spatial_hue"));
    }

    #[test]
    fn fallen_leaf_vertex_pigments_are_dry_warm_and_varied() {
        let leaves = dry_leaf_patch_mesh(0).unwrap();
        let Some(VertexAttributeValues::Float32x4(colors)) =
            leaves.attribute(Mesh::ATTRIBUTE_COLOR)
        else {
            panic!("fallen-leaf pigments must use Float32x4 storage");
        };
        assert!(colors.iter().all(|color| {
            color[0] > color[1] && color[1] > color[2] && color[0] - color[2] < 0.58
        }));
        let pigments = colors
            .as_chunks::<9>()
            .0
            .iter()
            .map(|leaf| leaf[0])
            .collect::<Vec<_>>();
        assert!(pigments.windows(2).any(|pair| pair[0] != pair[1]));
    }

    #[test]
    fn twig_variants_have_exact_bounded_topology_and_only_fork_base_boundaries() {
        for variant in 0..TWIG_MESH_VARIANTS {
            let mesh = twig_patch_mesh(variant).unwrap();
            let mut expected_vertices = 0;
            let mut expected_triangles = 0;
            let mut expected_boundaries = 0;
            for twig in 0..TWIGS_PER_PATCH {
                let hash = streams::TWIG.seed(variant.into(), &[twig]);
                let sides = 5 + (hash.to_u64() % 2) as usize;
                expected_vertices += sides * 4 + 2;
                expected_triangles += sides * 8;
                if twig < 2 && streams::TWIG_FORK.rng(hash, &[]).inclusive_unit_f32() > 0.46 {
                    expected_vertices += sides * 4 + 1;
                    expected_triangles += sides * 7;
                    expected_boundaries += sides;
                }
            }
            assert_eq!(mesh.count_vertices(), expected_vertices);
            assert_eq!(mesh.indices().unwrap().len() / 3, expected_triangles);
            let mut edges = std::collections::BTreeMap::new();
            let indices = mesh.indices().unwrap().iter().collect::<Vec<_>>();
            for triangle in indices.as_chunks::<3>().0 {
                for edge in [
                    (triangle[0], triangle[1]),
                    (triangle[1], triangle[2]),
                    (triangle[2], triangle[0]),
                ] {
                    *edges
                        .entry(if edge.0 < edge.1 {
                            edge
                        } else {
                            (edge.1, edge.0)
                        })
                        .or_insert(0) += 1;
                }
            }
            assert!(edges.values().all(|count| *count <= 2));
            assert_eq!(
                edges.values().filter(|count| **count == 1).count(),
                expected_boundaries
            );
        }
    }
}
