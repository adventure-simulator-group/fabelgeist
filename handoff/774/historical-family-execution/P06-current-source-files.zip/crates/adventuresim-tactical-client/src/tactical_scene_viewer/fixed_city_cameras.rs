//! Frozen poses and presentation selection retain accepted geographic support.
use super::{capture_state::BuildingReviewCamera, capture_state::SceneCaptureState};
use adventuresim_building_generator::spatial_geometry::Position;
use bevy::prelude::*;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

pub(crate) const PROFILE: &str = "terrain-grounding";
const CONTRACT_VERSION: u16 = 2;

mod promotion;

#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct Camera {
    position_metres: [f32; 3],
    target_metres: [f32; 3],
}

impl Camera {
    fn validate(&self) -> bool {
        let position = Vec3::from_array(self.position_metres);
        let target = Vec3::from_array(self.target_metres);
        position.is_finite()
            && target.is_finite()
            && (target - position).cross(Vec3::Y).length_squared() > 0.0
    }

    fn review(&self) -> Result<BuildingReviewCamera> {
        Ok(BuildingReviewCamera {
            position: Position::from_metres(Vec3::from_array(self.position_metres))?,
            target: Position::from_metres(Vec3::from_array(self.target_metres))?,
            plaster_raking_light: None,
        })
    }
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct Document {
    version: u16,
    /// Scene-relative metres, with the same seven indexes as city-review.
    exterior: Vec<Camera>,
    /// Frozen eye-height pose; scene-performance uses its established 80° FOV.
    benchmark: Option<Camera>,
    /// Explicit physical members to inspect with the production playable LODs.
    playable_building_ids: Vec<adventuresim_tactical_core::scene_input::SceneBuildingId>,
}

#[derive(Resource)]
pub(super) struct Contract(Option<Document>);

impl Contract {
    pub(super) fn load(path: Option<PathBuf>, profile: &str) -> Self {
        assert!(
            path.is_some() || profile != PROFILE,
            "terrain-grounding requires --city-cameras"
        );
        let document = path.map(|path| {
            let bytes = std::fs::read(&path).expect("read explicit camera contract");
            let document: Document =
                serde_json::from_slice(&bytes).expect("decode camera contract");
            assert_eq!(
                document.version, CONTRACT_VERSION,
                "camera contract version"
            );
            assert!(
                document.exterior.len() == 7,
                "camera contract requires all seven fixed city poses"
            );
            assert!(document.exterior.iter().all(Camera::validate));
            assert!(document.benchmark.as_ref().is_none_or(Camera::validate));
            document
        });
        Self(document)
    }
}

pub(super) fn apply(contract: Res<Contract>, mut state: ResMut<SceneCaptureState>) -> Result {
    let Some(document) = &contract.0 else {
        return Ok(());
    };
    let exterior = document
        .exterior
        .iter()
        .map(Camera::review)
        .collect::<Result<Vec<_>>>()?;
    let benchmark = document
        .benchmark
        .as_ref()
        .map(Camera::review)
        .transpose()?;
    state.city_exterior_cameras = exterior;
    if let Some(camera) = benchmark {
        state.ground_eye_position = camera.position;
        state.ground_eye_target = camera.target;
    }
    std::fs::write(
        state.output.join("fixed-camera-contract.json"),
        serde_json::to_vec_pretty(document)?,
    )?;
    Ok(())
}

use super::{
    building_review::ReviewLod,
    view_specs::{CapturePose, CaptureViewSpec},
};

// Indices match the established city-review profile. Foundation LOD views use
// one identical pose, FOV and lighting; only the production LOD range changes.
pub(super) const VIEWS: [CaptureViewSpec; 9] = [
    CaptureViewSpec::new(
        "warmup",
        "Production pipeline warmup",
        CapturePose::CityExterior { camera: 0 },
        58.0,
        100,
    )
    .warmup()
    .vista(),
    CaptureViewSpec::new(
        "foundation-detail",
        "Foundation and threshold: detail",
        CapturePose::CityExterior { camera: 0 },
        58.0,
        100,
    )
    .building_lod(ReviewLod::Detail)
    .vista(),
    CaptureViewSpec::new(
        "foundation-facade",
        "Foundation and threshold: facade",
        CapturePose::CityExterior { camera: 0 },
        58.0,
        100,
    )
    .building_lod(ReviewLod::Facade)
    .vista(),
    CaptureViewSpec::new(
        "foundation-shell",
        "Foundation and threshold: shell",
        CapturePose::CityExterior { camera: 0 },
        58.0,
        100,
    )
    .building_lod(ReviewLod::Shell)
    .vista(),
    CaptureViewSpec::new(
        "street",
        "Street access and local relief",
        CapturePose::CityExterior { camera: 1 },
        72.0,
        100,
    )
    .vista(),
    CaptureViewSpec::new(
        "property-oblique",
        "Whole property grading boundary",
        CapturePose::CityExterior { camera: 2 },
        60.0,
        100,
    )
    .vista(),
    CaptureViewSpec::new(
        "city-oblique",
        "Settlement and geographic relief",
        CapturePose::CityExterior { camera: 4 },
        58.0,
        100,
    )
    .vista(),
    CaptureViewSpec::new(
        "overhead",
        "Development and bounded grading",
        CapturePose::CityExterior { camera: 5 },
        62.0,
        100,
    )
    .vista(),
    CaptureViewSpec::new(
        "horizon",
        "Geographic horizon",
        CapturePose::CityExterior { camera: 6 },
        50.0,
        100,
    )
    .vista(),
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn camera_contract_rejects_degenerate_and_nonfinite_poses() {
        assert!(
            !Camera {
                position_metres: [0., 10., 0.],
                target_metres: [0.; 3]
            }
            .validate()
        );
        assert!(
            !Camera {
                position_metres: [f32::NAN, 2., 4.],
                target_metres: [0.; 3]
            }
            .validate()
        );
        assert!(
            Camera {
                position_metres: [0., 10., 0.01],
                target_metres: [0.; 3]
            }
            .validate()
        );
    }

    #[test]
    fn forced_foundation_levels_have_identical_pose_fov_and_lighting() {
        let reference = VIEWS[1];
        for view in &VIEWS[2..=3] {
            assert_eq!(view.pose, reference.pose);
            assert_eq!(view.fov_degrees, reference.fov_degrees);
            assert_eq!(view.lighting_mode, reference.lighting_mode);
        }
        assert_eq!(VIEWS[1].building_lod_override, Some(ReviewLod::Detail));
        assert_eq!(VIEWS[2].building_lod_override, Some(ReviewLod::Facade));
        assert_eq!(VIEWS[3].building_lod_override, Some(ReviewLod::Shell));
    }
}
