//! Catalog staging and route-based cameras; all furniture uses production ECS presentation.
use adventuresim_building_generator::furniture::{FurnitureKey, FurnitureKind, FurnitureVariant};
use adventuresim_tactical_core::{prelude::*, scene_coordinates::ScenePlanPoint};
use adventuresim_world_schema::settlement_buildings::BuildingUse;
use bevy::prelude::*;

use super::{
    capture_state::BuildingReviewCamera,
    view_specs::{CapturePose, CaptureViewSpec},
};

use catalog::catalog_camera;
#[cfg(test)]
use catalog::catalog_pair_gap;
pub(super) use catalog::setup_catalog;

mod catalog;
mod finishes;
mod rooms;

pub(super) const PROFILE: &str = "interior-furniture-catalog";
pub(super) const ROOMS_PROFILE: &str = "furnished-room-review";
const CATALOG_COLUMNS: usize = 5;
const CATALOG_BAY_SPACING_METRES: f32 = 20.0;
const CATALOG_PAIR_GAP_METRES: f32 = 0.8;
const CATALOG_INSTANCE_ID_BASE: u64 = 0x6361_7461_6c6f_6700;
const CAMERA_EYE_HEIGHT_METRES: f32 = 1.55;
const CATALOG_FOV_DEGREES: f32 = 48.0;
const ROOM_FOV_DEGREES: f32 = 78.0;
const CATALOG_FRAMING_MARGIN: f32 = 1.1;

const CATALOG: [(&str, &str); FurnitureKind::INTERIOR.len()] = [
    ("dining-table", "Trestle dining tables"),
    ("bench", "Joined benches"),
    ("chair", "Joined chairs"),
    ("stool", "Stools"),
    ("bed", "Domestic beds"),
    ("bunk-bed", "Bunk beds and integral ladders"),
    ("storage-chest", "Iron-bound chests"),
    ("cupboard", "Panelled cupboards"),
    ("shelving", "Empty shelving"),
    ("writing-desk", "Sloped writing desks"),
    ("lectern", "Lecterns"),
    ("church-bench", "Church benches"),
    ("altar", "Plain altars"),
    ("ward-bed", "Open-frame ward beds"),
    ("bath-tub", "Open stave bathing tubs"),
    ("wash-stand", "Wash stands"),
    ("workbench", "Workbenches"),
    ("cutting-table", "Cutting tables"),
    ("tool-rack", "Empty tool racks"),
    ("weapon-rack", "Empty weapon racks"),
    ("armour-stand", "Armour stands"),
    ("grain-bin", "Empty grain bins"),
    ("storage-crate", "Storage crates"),
    ("counter", "Modular counters"),
    ("counter-left-end", "Left counter endcaps"),
    ("counter-right-end", "Right counter endcaps"),
    ("counter-corner", "Corner counters"),
    ("display-counter", "Empty display counters"),
    ("drying-rack", "Drying racks"),
    ("kneading-trough", "Kneading troughs"),
    ("butchers-block", "Butchers' blocks"),
    ("cask-rack", "Empty cask racks"),
    ("hay-rack", "Empty hay racks"),
    ("feed-trough", "Empty feed troughs"),
    ("candle-stand", "Socket candles on iron stands"),
    ("spinning-stool", "Distaff and drop spindle"),
    ("balance-table", "Beam balance with pans and weights"),
    ("reckoning-table", "Line reckoning with counters"),
    ("treadle-loom", "Hand-operated treadle looms"),
    ("printing-press", "Wooden screw printing presses"),
    ("type-case", "Compositor's partitioned type cases"),
    ("baptismal-font", "Octagonal hollow stone font"),
    ("pulpit", "Pulpit with integral stair"),
    ("bima", "Reading platform with steps"),
    ("torah-shrine", "Torah shrine with textile screen"),
];

const ROOM_USES: [BuildingUse; 16] = [
    BuildingUse::Dwelling,
    BuildingUse::Inn,
    BuildingUse::GeneralShop,
    BuildingUse::Smithy,
    BuildingUse::ParishChurch,
    BuildingUse::Hospital,
    BuildingUse::Guardhouse,
    BuildingUse::Warehouse,
    BuildingUse::Castle,
    BuildingUse::Dwelling,
    BuildingUse::Cathedral,
    BuildingUse::Weaver,
    BuildingUse::PrintingHouse,
    BuildingUse::WeighHouse,
    BuildingUse::Weaver,
    BuildingUse::Dwelling,
];
const ROOM_LABELS: [(&str, &str); ROOM_USES.len()] = [
    ("house", "Furnished dwelling"),
    ("inn", "Furnished inn"),
    ("shop", "Furnished shop"),
    ("workshop", "Furnished workshop"),
    ("church", "Furnished parish church"),
    ("hospital", "Furnished hospital ward"),
    ("barracks", "Furnished guardhouse"),
    ("warehouse", "Furnished warehouse"),
    ("keep-upper", "Keep upper floor and spiral landing"),
    ("bedroom", "Dwelling upper bedchamber"),
    ("cathedral", "Furnished cathedral nave"),
    ("weaver", "Loom and domestic spinning workshop"),
    ("printing-house", "Press and composing workshop"),
    ("weigh-house", "Weighing and line reckoning"),
    (
        "loom-operation",
        "Loom seat, treadles and operator approach",
    ),
    (
        "spinning-operation",
        "Spinning seat and drawing-fibre workspace",
    ),
];

pub(super) const VIEWS: [CaptureViewSpec; CATALOG.len() + 2 + finishes::LABELS.len()] =
    catalog_views();
pub(super) const ROOM_VIEWS: [CaptureViewSpec; ROOM_LABELS.len() + 1] = room_views();

#[derive(Debug, thiserror::Error)]
enum CatalogAdmissionError {
    #[error("catalog fixture must have no placed furniture")]
    AlreadyPlaced,
    #[error("catalog key {key:?} is absent from the authored catalogue")]
    MissingCatalogueEntry { key: FurnitureKey },
    #[error("catalog orientation must be finite")]
    InvalidOrientation,
}

const fn catalog_views() -> [CaptureViewSpec; CATALOG.len() + 2 + finishes::LABELS.len()] {
    let warmup = CaptureViewSpec::new(
        "warmup",
        "Production furniture catalog warmup",
        CapturePose::CityExterior { camera: 0 },
        CATALOG_FOV_DEGREES,
        100,
    )
    .warmup()
    .vista();
    let mut views = [warmup; CATALOG.len() + 2 + finishes::LABELS.len()];
    let mut index = 0;
    while index < CATALOG.len() {
        views[index + 1] = CaptureViewSpec::new(
            CATALOG[index].0,
            CATALOG[index].1,
            CapturePose::CityExterior {
                camera: index as u8,
            },
            CATALOG_FOV_DEGREES,
            100,
        )
        .vista()
        .settled_readback_pair();
        index += 1;
    }
    views[CATALOG.len() + 1] = CaptureViewSpec::new(
        "joined-counters",
        "Contiguous counter runs with corner and endcaps",
        CapturePose::CityExterior {
            camera: CATALOG.len() as u8,
        },
        CATALOG_FOV_DEGREES,
        100,
    )
    .vista()
    .settled_readback_pair();
    let mut finish = 0;
    while finish < finishes::LABELS.len() {
        views[CATALOG.len() + 2 + finish] = CaptureViewSpec::new(
            finishes::LABELS[finish].0,
            finishes::LABELS[finish].1,
            CapturePose::CityExterior {
                camera: (CATALOG.len() + 1 + finish) as u8,
            },
            CATALOG_FOV_DEGREES,
            100,
        )
        .vista()
        .settled_readback_pair();
        finish += 1;
    }
    views
}

const fn room_views() -> [CaptureViewSpec; ROOM_LABELS.len() + 1] {
    let warmup = CaptureViewSpec::new(
        "warmup",
        "Production furnished room warmup",
        CapturePose::BuildingInterior { camera: 0 },
        ROOM_FOV_DEGREES,
        100,
    )
    .warmup();
    let mut views = [warmup; ROOM_LABELS.len() + 1];
    let mut index = 0;
    while index < ROOM_LABELS.len() {
        views[index + 1] = CaptureViewSpec::new(
            ROOM_LABELS[index].0,
            ROOM_LABELS[index].1,
            CapturePose::BuildingInterior {
                camera: index as u8,
            },
            ROOM_FOV_DEGREES,
            100,
        )
        .settled_readback_pair();
        index += 1;
    }
    views
}

pub(super) fn is_profile(profile: &str) -> bool {
    matches!(profile, PROFILE | ROOMS_PROFILE)
}

pub(super) fn setup_rooms(
    commands: &mut Commands,
    buildings: &[GeneratedBuilding],
    layout: &FurnitureLayout,
    profile: &str,
    output: &std::path::Path,
) -> Result<Option<Vec<BuildingReviewCamera>>> {
    if profile != ROOMS_PROFILE {
        return Ok(None);
    }
    super::building_review::setup_geometry_requirements(commands, buildings, output)?;
    let cameras = ROOM_USES
        .into_iter()
        .enumerate()
        .map(|(index, usage)| {
            let building = buildings
                .iter()
                .find(|building| building.placement.program.usage == Some(usage))
                .ok_or_else(|| format!("furnished room fixture lacks {usage:?}"))?;
            use adventuresim_building_generator::RoomKind;
            let selection = match index {
                0 | 1 => rooms::RoomSelection::Role(RoomKind::CommonRoom),
                2 => rooms::RoomSelection::Role(RoomKind::Shop),
                3 | 11 | 12 => rooms::RoomSelection::Role(RoomKind::Workshop),
                4 | 10 => rooms::RoomSelection::Role(RoomKind::Nave),
                5 => rooms::RoomSelection::Role(RoomKind::Ward),
                6 => rooms::RoomSelection::Role(RoomKind::Guardroom),
                7 => rooms::RoomSelection::Role(RoomKind::Storage),
                8 => rooms::RoomSelection::UpperKeep,
                9 => rooms::RoomSelection::Bedroom,
                13 => rooms::RoomSelection::Role(RoomKind::CountingRoom),
                14 => rooms::RoomSelection::Operating(FurnitureKind::TreadleLoom),
                15 => rooms::RoomSelection::Operating(FurnitureKind::SpinningStool),
                _ => unreachable!("every authored room view has a semantic selection"),
            };
            rooms::camera(building, layout, selection)
        })
        .collect::<Result<Vec<_>>>()?;
    expect_furniture(commands, layout)?;
    std::fs::write(
        output.join("interior-access-proofs.json"),
        serde_json::to_vec_pretty(&layout.interiors).unwrap(),
    )
    .expect("write room access proofs");
    Ok(Some(cameras))
}

fn envelope_corners(size: Vec3) -> [Vec3; 8] {
    std::array::from_fn(|index| {
        Vec3::new(
            if index & 1 == 0 {
                -size.x * 0.5
            } else {
                size.x * 0.5
            },
            if index & 2 == 0 { 0.0 } else { size.y },
            if index & 4 == 0 {
                -size.z * 0.5
            } else {
                size.z * 0.5
            },
        )
    })
}

fn expect_furniture(commands: &mut Commands, layout: &FurnitureLayout) -> Result {
    commands.insert_resource(super::furniture_readiness::ExpectedFurniture {
        instances: layout.instances.len() + layout.distant_instances.len(),
        batches: layout
            .instances
            .iter()
            .chain(&layout.distant_instances)
            .map(|instance| instance.scene.key.recipe().map(|r| r.meshes.len()))
            .collect::<std::result::Result<Vec<_>, _>>()?
            .into_iter()
            .sum(),
    });
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn catalog_framing_contains_every_variant_envelope_corner() {
        for kind in FurnitureKind::INTERIOR {
            let sizes = FurnitureVariant::ALL.map(|variant| {
                FurnitureKey::natural(kind, variant)
                    .interior_spec()
                    .unwrap()
                    .size_metres
                    .metres()
            });
            let size = Vec3::new(
                sizes[0].x + sizes[1].x + catalog_pair_gap(kind),
                sizes[0].y.max(sizes[1].y),
                sizes[0].z.max(sizes[1].z),
            );
            let camera = catalog_camera(
                kind,
                adventuresim_building_generator::spatial_geometry::CuboidDimensions::from_metres(
                    size,
                )
                .unwrap(),
                adventuresim_building_generator::spatial_geometry::Position::ORIGIN,
            )
            .unwrap();
            let view = Transform::from_translation(camera.position.metres())
                .looking_at(camera.target.metres(), Vec3::Y);
            let tangent = (CATALOG_FOV_DEGREES.to_radians() * 0.5).tan();
            for corner in envelope_corners(size) {
                let local = view.rotation.inverse() * (corner - camera.position.metres());
                assert!(local.z < 0.0, "{kind:?} behind camera");
                assert!(
                    local.y.abs() < -local.z * tangent,
                    "{kind:?} vertical clipping"
                );
                assert!(
                    local.x.abs()
                        < -local.z
                            * tangent
                            * super::super::capture_resolution::CAPTURE_ASPECT_RATIO,
                    "{kind:?} horizontal clipping"
                );
            }
        }
    }

    #[test]
    fn every_interior_recipe_family_has_a_unique_catalog_plate() {
        assert_eq!(CATALOG.len(), FurnitureKind::INTERIOR.len());
        let slugs = VIEWS
            .iter()
            .map(|view| view.slug)
            .collect::<std::collections::BTreeSet<_>>();
        assert_eq!(slugs.len(), VIEWS.len());
        for (index, view) in VIEWS.iter().skip(1).enumerate() {
            assert_eq!(
                view.pose,
                CapturePose::CityExterior {
                    camera: index as u8
                }
            );
            assert!(!view.warmup);
        }
        assert!(VIEWS[0].warmup && ROOM_VIEWS[0].warmup);
        assert!(
            VIEWS
                .iter()
                .chain(ROOM_VIEWS.iter())
                .filter(|view| !view.warmup)
                .all(|view| view.verify_settled_readbacks),
            "every recorded furniture review must verify its final settled pixel pair"
        );
    }
}
