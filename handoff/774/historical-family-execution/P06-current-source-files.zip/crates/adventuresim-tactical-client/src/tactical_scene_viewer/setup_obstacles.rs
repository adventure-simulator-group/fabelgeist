//! Admit obstacle support before publishing the capture's physics and overlays.
use super::*;
use adventuresim_building_generator::spatial_geometry::Position;
use adventuresim_tactical_core::scene_coordinates::Scene;

#[derive(Default)]
pub(super) struct CapturedObstacles {
    pub(super) expected_trees: usize,
    pub(super) expected_rocks: usize,
    pub(super) position_sum: Vec3,
    pub(super) count: usize,
    pub(super) tree_focus: Option<Position<Scene>>,
    pub(super) rock_focus: Option<Position<Scene>>,
    pub(super) tree_focus_entity: Option<Entity>,
}

struct SupportedObstacle {
    kind: SceneObstacle,
    position: Position<Scene>,
}

struct ObstacleVisual {
    collider: Collider,
    overlay_mesh: Handle<Mesh>,
    overlay_color: Color,
}

impl CapturedObstacles {
    pub(super) fn spawn(
        commands: &mut Commands,
        meshes: &mut Assets<Mesh>,
        materials: &mut Assets<StandardMaterial>,
        terrain: &SceneTerrain,
        grid: &TerrainSampleGrid,
        obstacles: Vec<GeneratedObstacle>,
    ) -> Result<Self> {
        let supported = obstacles
            .into_iter()
            .map(|obstacle| SupportedObstacle::new(obstacle, terrain, grid))
            .collect::<Result<Vec<_>>>()?;
        let mut result = Self::default();
        for obstacle in supported {
            obstacle.spawn(commands, meshes, materials, &mut result);
        }
        Ok(result)
    }
}

impl SupportedObstacle {
    fn new(
        obstacle: GeneratedObstacle,
        terrain: &SceneTerrain,
        grid: &TerrainSampleGrid,
    ) -> Result<Self> {
        let (x, z, kind, offset) = match obstacle {
            GeneratedObstacle::Tree { x, z } => {
                (x, z, SceneObstacle::Tree, TREE_TRUNK_HEIGHT_METRES * 0.5)
            }
            GeneratedObstacle::Rock { x, z, recipe } => (
                x,
                z,
                SceneObstacle::Rock(recipe),
                recipe.collision_radius_metres(),
            ),
        };
        // Decode the serialized grid with its original multiply-then-subtract order.
        let point = ScenePlanPoint::try_from(Vec2::new(
            f32::from(x) * grid.spacing_metres - terrain.width() * 0.5,
            f32::from(z) * grid.spacing_metres - terrain.depth() * 0.5,
        ))?;
        let elevation = terrain.required_height_at(point)?;
        let position = Position::from_metres(Vec3::new(
            point.metres().x,
            elevation.metres() + offset,
            point.metres().y,
        ))?;
        Ok(Self { kind, position })
    }

    fn spawn(
        self,
        commands: &mut Commands,
        meshes: &mut Assets<Mesh>,
        materials: &mut Assets<StandardMaterial>,
        state: &mut CapturedObstacles,
    ) {
        let kind = self.kind;
        match kind {
            SceneObstacle::Tree => state.expected_trees += 1,
            SceneObstacle::Rock(_) => state.expected_rocks += 1,
        }
        let visual = ObstacleVisual::new(kind, meshes);
        let position = self.position.metres();
        let focuses_tree = matches!(kind, SceneObstacle::Tree)
            && state.tree_focus.is_none_or(|focus| {
                position.xz().length_squared() < focus.metres().xz().length_squared()
            });
        if focuses_tree {
            state.tree_focus = Some(self.position);
        }
        let focuses_rock = matches!(kind, SceneObstacle::Rock(_))
            && state.rock_focus.is_none_or(|focus| {
                position.xz().length_squared() < focus.metres().xz().length_squared()
            });
        if focuses_rock {
            state.rock_focus = Some(self.position);
        }
        state.position_sum += position;
        state.count += 1;
        let yaw = match kind {
            SceneObstacle::Rock(recipe) => {
                (recipe.seed.to_u64() >> 40) as f32 / ((1_u32 << 24) - 1) as f32
                    * core::f32::consts::TAU
            }
            SceneObstacle::Tree => 0.0,
        };
        let transform =
            Transform::from_translation(position).with_rotation(Quat::from_rotation_y(yaw));
        let obstacle_entity = commands
            .spawn((
                Name::new("Captured tactical obstacle"),
                kind,
                RigidBody::Static,
                CollisionLayers::new(TACTICAL_TERRAIN_LAYER, LayerMask::ALL),
                visual.collider,
                transform,
            ))
            .id();
        if focuses_tree {
            state.tree_focus_entity = Some(obstacle_entity);
        }
        commands.spawn((
            Name::new("Capture collider overlay"),
            CaptureOverlay,
            Mesh3d(visual.overlay_mesh),
            MeshMaterial3d(materials.add(StandardMaterial {
                base_color: visual.overlay_color,
                emissive: LinearRgba::new(6.0, 6.0, 6.0, 1.0),
                unlit: true,
                ..default()
            })),
            Visibility::Hidden,
            transform,
        ));
    }
}

impl ObstacleVisual {
    fn new(kind: SceneObstacle, meshes: &mut Assets<Mesh>) -> Self {
        match kind {
            SceneObstacle::Tree => Self {
                collider: Collider::cylinder(TREE_TRUNK_RADIUS_METRES, TREE_TRUNK_HEIGHT_METRES),
                overlay_mesh: meshes.add(Cylinder::new(
                    TREE_TRUNK_RADIUS_METRES * 1.08,
                    TREE_TRUNK_HEIGHT_METRES * 1.02,
                )),
                overlay_color: Color::srgb(0.1, 1.0, 0.85),
            },
            SceneObstacle::Rock(recipe) => Self {
                collider: Collider::sphere(recipe.collision_radius_metres()),
                overlay_mesh: meshes.add(Sphere::new(recipe.collision_radius_metres() * 1.08)),
                overlay_color: Color::srgb(1.0, 0.08, 0.72),
            },
        }
    }
}
