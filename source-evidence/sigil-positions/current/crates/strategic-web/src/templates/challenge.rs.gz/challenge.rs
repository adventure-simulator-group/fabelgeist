use adventuresim_core::errantry::{
    FeyPresenterCatalogId, FeySpeechPart, fey_clue_text, fey_puzzle_speech,
};
use adventuresim_puzzles::{PuzzleProjection, PuzzleSubmission};
use maud::{Markup, html};

use super::journal_layout;

#[expect(
    clippy::too_many_arguments,
    reason = "the challenge page renders independent authoritative puzzle and submission projections"
)]
pub fn puzzle_page(
    challenge_id: &str,
    case_id: &str,
    catalog: FeyPresenterCatalogId,
    revision: u32,
    projection: &PuzzleProjection,
    solved: bool,
    last_attempt_correct: Option<bool>,
    last_submission: Option<&PuzzleSubmission>,
    tactical_insight_text: Option<&str>,
    tactical_preparation_text: Option<&str>,
    character_name: &str,
) -> Markup {
    let kind = projection.kind();
    let content = html! {
        aside class="left-sidebar challenge-rail" aria-hidden="true" {}
        main class="center-content challenge-page" data-live-navigation-static {
            section class="settlement-chat challenge-chat" aria-label="Fey conversation"
                data-challenge-id=(challenge_id) data-presenter-catalog=(catalog.slug())
                data-puzzle-kind=(kind.slug()) {
                div class="settlement-chat-layout" {
                    div class="settlement-chat-conversation" {
                        div class="settlement-chat-messages" aria-live="polite" {
                            div class="chat-system-message" data-chat-channel="info" {
                                "A trial of discernment interrupts the road."
                            }
                            @for line in fey_puzzle_speech(catalog, kind, FeySpeechPart::Introduction) {
                                p class="supernatural-spoken-line" {
                                    strong { (catalog.name()) ": " }
                                    (line)
                                }
                            }
                            @for line in fey_puzzle_speech(catalog, kind, FeySpeechPart::Instruction) {
                                p class="supernatural-spoken-line" {
                                    strong { (catalog.name()) ": " }
                                    (line)
                                }
                            }
                            (puzzle_observations(catalog, projection))
                            @if let Some(submission) = last_submission {
                                p class="player-spoken-line" data-puzzle-submission {
                                    strong { (character_name) ": " }
                                    (submission_text(submission, projection))
                                }
                            }
                            @if solved {
                                @for line in fey_puzzle_speech(catalog, kind, FeySpeechPart::Correct) {
                                    p class="supernatural-spoken-line notice success" role="status" {
                                        strong { (catalog.name()) ": " }
                                        (line)
                                    }
                                }
                                @if let (Some(finding), Some(preparation)) = (tactical_insight_text, tactical_preparation_text) {
                                    div class="chat-system-message notice success" data-chat-channel="info"
                                        data-tactical-insight-source=(challenge_id) {
                                        p { strong { "Learned weakness: " } (finding) }
                                        p { strong { "Preparation: " } (preparation) }
                                    }
                                }
                                a class="btn btn-primary" href=(crate::location_urls::patterns::CAMP.pattern()) { "Return to camp" }
                            } @else {
                                @if last_attempt_correct == Some(false) {
                                    @for line in fey_puzzle_speech(catalog, kind, FeySpeechPart::Wrong) {
                                        p class="supernatural-spoken-line notice warning" role="alert" {
                                            strong { (catalog.name()) ": " }
                                            (line)
                                        }
                                    }
                                }
                                form method="post"
                                    action=(format!("/quests/{case_id}/challenges/{challenge_id}"))
                                    class="challenge-ordering-form settlement-chat-composer" {
                                    input type="hidden" name="expected_revision" value=(revision);
                                    (puzzle_answer_fields(projection))
                                    button type="submit" class="btn btn-primary" { "Answer the Lady" }
                                }
                            }
                        }
                    }
                }
            }
        }
        aside class="right-sidebar challenge-rail" aria-hidden="true" {}
    };
    journal_layout(content, Some(character_name))
}

fn puzzle_observations(catalog: FeyPresenterCatalogId, projection: &PuzzleProjection) -> Markup {
    match projection {
        PuzzleProjection::OrderedSigils(puzzle) => html! {
            ol aria-label="The Lady's spoken clues" {
                @for clue in &puzzle.clues {
                    li class="supernatural-spoken-line" { (fey_clue_text(catalog, clue)) }
                }
            }
        },
        PuzzleProjection::TruthfulWitnesses(puzzle) => html! {
            div class="chat-system-message" data-chat-channel="info" {
                "Exactly one witness lies. Each witness is otherwise consistent, and exactly one path is safe."
            }
            ol aria-label="Witness statements" {
                @for statement in puzzle.statements {
                    li { (statement.text()) }
                }
            }
        },
        PuzzleProjection::RuneTransformation(puzzle) => html! {
            div class="chat-system-message" data-chat-channel="info" {
                "The five sigils are Crown, Hart, Moon, Rose, and Sword. "
                "Each gate independently chooses one and only one rule below and uses it for both of its examples. "
                "Never combine rules within a gate; different gates may use the same rule."
            }
            ul aria-label="Possible rune transformation rules" {
                @for (index, rule) in puzzle.candidate_rules.into_iter().enumerate() {
                    li { "Candidate " ((b'A' + index as u8) as char) ": " (rule.rule_text()) }
                }
            }
            ol aria-label="Rune transformation examples" {
                @for example in &puzzle.examples {
                    li { ((*example).text()) }
                }
            }
            p class="chat-system-message" {
                "Question: the " (puzzle.query.label()) " passes through "
                @for (index, gate) in puzzle.route.iter().enumerate() {
                    @if index > 0 { ", then " }
                    (gate.label())
                }
                ". Which sigil finally emerges?"
            }
        },
        PuzzleProjection::LogicGrid(puzzle) => html! {
            div class="chat-system-message" data-chat-channel="info" {
                "Each traveler carried exactly one token and took exactly one road. Every token and road was used once."
            }
            p class="chat-system-message" {
                strong { "Travelers: " } (puzzle.travelers.join(", ")) br;
                strong { "Tokens: " } (puzzle.tokens.join(", ")) br;
                strong { "Roads: " } (puzzle.roads.join(", "))
            }
            ol aria-label="Logic-grid clues" {
                @for clue in &puzzle.clues {
                    li { (clue.text()) }
                }
            }
        },
        PuzzleProjection::ResourceAllocation(puzzle) => html! {
            div class="chat-system-message" data-chat-channel="info" {
                "Choose provisions whose total weight is at most " (puzzle.capacity) ". "
                "The pack must answer every named hazard. Among legal packs, maximize readiness; ties favor lower weight, then fewer items."
            }
            p class="chat-system-message" {
                strong { "Hazards: " }
                (puzzle.hazards.iter().map(|hazard| hazard.label()).collect::<Vec<_>>().join(", "))
            }
            ul aria-label="Available provisions" {
                @for item in &puzzle.provisions {
                    li {
                        strong { (item.id.label()) }
                        ": weight " (item.weight) ", readiness " (item.readiness)
                        "; answers "
                        (item.protections.iter().map(|hazard| hazard.label()).collect::<Vec<_>>().join(" and "))
                        "."
                    }
                }
            }
        },
    }
}

fn submission_text(submission: &PuzzleSubmission, projection: &PuzzleProjection) -> String {
    match submission {
        PuzzleSubmission::OrderedSigils { ordering } => format!(
            "I place the sigils thus: {}.",
            ordering
                .iter()
                .map(|sigil| sigil.label())
                .collect::<Vec<_>>()
                .join(", ")
        ),
        PuzzleSubmission::TruthfulWitnesses { safe_path } => {
            format!("I choose the {}.", safe_path.label())
        }
        PuzzleSubmission::RuneTransformation { result } => {
            format!("The answer is the {}.", result.label())
        }
        PuzzleSubmission::LogicGrid { assignments } => {
            let PuzzleProjection::LogicGrid(puzzle) = projection else {
                return "I submit the completed matching.".into();
            };
            format!(
                "I match them thus: {}.",
                assignments
                    .iter()
                    .map(|item| format!(
                        "{} bears the {} upon the {}",
                        puzzle.travelers[usize::from(item.traveler)],
                        puzzle.tokens[usize::from(item.token)],
                        puzzle.roads[usize::from(item.road)]
                    ))
                    .collect::<Vec<_>>()
                    .join("; ")
            )
        }
        PuzzleSubmission::ResourceAllocation { provisions } => format!(
            "I choose this pack: {}.",
            provisions
                .iter()
                .map(|item| item.label())
                .collect::<Vec<_>>()
                .join(", ")
        ),
    }
}

fn puzzle_answer_fields(projection: &PuzzleProjection) -> Markup {
    match projection {
        PuzzleProjection::OrderedSigils(puzzle) => html! {
            fieldset {
                legend { "Arrange the five sigils from first to fifth" }
                div class="challenge-ordering" {
                    @for position in 0..puzzle.sigils.len() {
                        label {
                            span { (ordinal(position)) }
                            select name=(format!("sigil_{position}")) required {
                                option value="" { "Choose a sigil" }
                                @for sigil in puzzle.sigils {
                                    option value=(sigil.stable_id()) { (sigil.label()) }
                                }
                            }
                        }
                    }
                }
            }
        },
        PuzzleProjection::TruthfulWitnesses(puzzle) => html! {
            fieldset {
                legend { "Choose the path proved safe" }
                label {
                    span { "Safe path" }
                    select name="safe_path" required {
                        option value="" { "Choose a path" }
                        @for path in puzzle.paths {
                            option value=(path.stable_id()) { (path.label()) }
                        }
                    }
                }
            }
        },
        PuzzleProjection::RuneTransformation(puzzle) => html! {
            fieldset {
                legend { "Choose the sigil produced after the complete gate route" }
                label {
                    span { "Result" }
                    select name="rune_result" required {
                        option value="" { "Choose a sigil" }
                        @for sigil in puzzle.sigils {
                            option value=(sigil.stable_id()) { (sigil.label()) }
                        }
                    }
                }
            }
        },
        PuzzleProjection::LogicGrid(puzzle) => html! {
            fieldset {
                legend { "Match each traveler to a token and road" }
                div class="challenge-ordering" {
                    @for (traveler, name) in puzzle.travelers.iter().enumerate() {
                        div class="challenge-grid-assignment" {
                            strong { (name) }
                            label {
                                span { "Token" }
                                select name=(format!("grid_token_{traveler}")) required {
                                    option value="" { "Choose a token" }
                                    @for token in &puzzle.tokens {
                                        option value=(token) { (token) }
                                    }
                                }
                            }
                            label {
                                span { "Road" }
                                select name=(format!("grid_road_{traveler}")) required {
                                    option value="" { "Choose a road" }
                                    @for road in &puzzle.roads {
                                        option value=(road) { (road) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        PuzzleProjection::ResourceAllocation(puzzle) => html! {
            fieldset {
                legend { "Choose the optimal provision pack" }
                @for (index, item) in puzzle.provisions.iter().enumerate() {
                    label class="challenge-provision-choice" {
                        input type="checkbox" name=(format!("provision_{index}")) value="selected";
                        span {
                            strong { (item.id.label()) }
                            " — weight " (item.weight) ", readiness " (item.readiness)
                        }
                    }
                }
            }
        },
    }
}

fn ordinal(position: usize) -> &'static str {
    match position {
        0 => "First",
        1 => "Second",
        2 => "Third",
        3 => "Fourth",
        _ => "Fifth",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use adventuresim_puzzles::{PuzzleAuthority, Sigil};

    #[test]
    fn every_puzzle_is_a_no_js_shared_chat_visual_without_private_truth() {
        for kind in adventuresim_puzzles::PuzzleKind::ALL {
            let puzzle = PuzzleAuthority::generate(kind, fabelgeist_determinism::Seed::from_u64(4));
            let markup = puzzle_page(
                "challenge:test",
                "case:test",
                FeyPresenterCatalogId::LadyBeneathThornV1,
                0,
                &puzzle.projection(),
                false,
                Some(false),
                None,
                None,
                None,
                "Ada",
            )
            .into_string();
            assert!(markup.contains("settlement-chat"));
            assert!(markup.contains("settlement-chat-messages"));
            assert!(markup.contains("data-live-navigation-static"));
            assert!(markup.contains("method=\"post\""));
            assert!(markup.contains("<fieldset>"));
            assert!(markup.contains("role=\"alert\""));
            assert!(!markup.contains("solution"));
            assert!(!markup.contains("data-private-seed"));
            assert!(!markup.contains("operation"));
        }
    }

    #[test]
    fn submitted_answer_remains_in_the_solved_chat_until_the_player_leaves() {
        let puzzle = PuzzleAuthority::generate(
            adventuresim_puzzles::PuzzleKind::RuneTransformation,
            fabelgeist_determinism::Seed::from_u64(4),
        );
        let submission = PuzzleSubmission::RuneTransformation {
            result: Sigil::Sword,
        };
        let markup = puzzle_page(
            "challenge:test",
            "case:test",
            FeyPresenterCatalogId::LadyBeneathThornV1,
            1,
            &puzzle.projection(),
            true,
            Some(true),
            Some(&submission),
            Some("The armed retainers carry no missile weapons and must close to melee range before striking."),
            Some("Bring bows and arrows; archers can strike while these enemies close."),
            "Ada",
        )
        .into_string();

        assert!(markup.contains("data-puzzle-submission"));
        assert!(markup.contains("Ada: "));
        assert!(markup.contains("The answer is the Sword."));
        assert!(markup.contains("Learned weakness:"));
        assert!(markup.contains("bows and arrows"));
        assert!(!markup.contains("combat scale"));
        assert!(markup.contains("Return to camp"));
        assert!(
            include_str!("../../static/live-state.js").contains("[data-live-navigation-static]")
        );
    }

    #[test]
    fn rune_prompt_requires_three_inferred_gate_laws_in_route_order() {
        let puzzle = PuzzleAuthority::generate(
            adventuresim_puzzles::PuzzleKind::RuneTransformation,
            fabelgeist_determinism::Seed::from_u64(19),
        );
        let markup = puzzle_page(
            "challenge:test",
            "case:test",
            FeyPresenterCatalogId::LadyBeneathThornV1,
            0,
            &puzzle.projection(),
            false,
            None,
            None,
            None,
            None,
            "Ada",
        )
        .into_string();

        assert!(markup.contains("one and only one rule"));
        assert!(markup.contains("Never combine rules within a gate"));
        assert!(markup.contains("Candidate A"));
        assert!(markup.contains("Gate of Ash"));
        assert!(markup.contains("Gate of Briar"));
        assert!(markup.contains("Gate of Glass"));
        assert!(markup.contains("after the complete gate route"));
    }

    #[test]
    fn new_puzzle_families_are_fully_chat_native() {
        let grid = PuzzleAuthority::generate(
            adventuresim_puzzles::PuzzleKind::LogicGrid,
            fabelgeist_determinism::Seed::from_u64(41),
        );
        let grid_markup = puzzle_page(
            "challenge:grid",
            "case:test",
            FeyPresenterCatalogId::LadyBeneathThornV1,
            0,
            &grid.projection(),
            false,
            None,
            None,
            None,
            None,
            "Ada",
        )
        .into_string();
        assert!(grid_markup.contains("Each traveler carried exactly one token"));
        assert!(grid_markup.contains("grid_token_0"));
        assert!(grid_markup.contains("grid_road_0"));

        let allocation = PuzzleAuthority::generate(
            adventuresim_puzzles::PuzzleKind::ResourceAllocation,
            fabelgeist_determinism::Seed::from_u64(42),
        );
        let allocation_markup = puzzle_page(
            "challenge:allocation",
            "case:test",
            FeyPresenterCatalogId::LadyBeneathThornV1,
            0,
            &allocation.projection(),
            false,
            None,
            None,
            None,
            None,
            "Ada",
        )
        .into_string();
        assert!(allocation_markup.contains("maximize readiness"));
        assert!(allocation_markup.contains("provision_0"));
        assert!(allocation_markup.contains("total weight is at most"));
        let css = include_str!("../../static/css/strategic.css");
        assert!(css.contains(".challenge-page .challenge-chat"));
        assert!(css.contains("overflow-wrap: anywhere"));
    }
}
